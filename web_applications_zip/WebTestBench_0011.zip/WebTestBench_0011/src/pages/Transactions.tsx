import { useState } from 'react';
import { useCashFlow } from '@/contexts/CashFlowContext';
import { TransactionFilters } from '@/components/transactions/TransactionFilters';
import { TransactionList } from '@/components/transactions/TransactionList';
import { TransactionForm } from '@/components/transactions/TransactionForm';
import { Transaction } from '@/data/mockData';

const Transactions = () => {
  const { filteredTransactions, transactions, activeView, customViews } = useCashFlow();
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  
  const currentView = activeView ? customViews.find((v) => v.id === activeView) : null;

  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
            {currentView ? currentView.name : 'Transactions'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {currentView ? currentView.description : 'Manage and track all your transactions'}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">
            {filteredTransactions.length} of {transactions.length} transactions
          </span>
          <TransactionForm />
        </div>
      </header>

      {/* Filters */}
      <TransactionFilters />

      {/* Transaction List */}
      <TransactionList
        onEdit={(id) => {
          const txn = transactions.find((t) => t.id === id);
          if (txn) setEditingTransaction(txn);
        }}
      />

      {/* Edit Modal */}
      {editingTransaction && (
        <TransactionForm
          editTransaction={editingTransaction}
          onClose={() => setEditingTransaction(null)}
        />
      )}
    </div>
  );
};

export default Transactions;
