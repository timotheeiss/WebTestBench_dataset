import { CreateViewForm } from '@/components/views/CreateViewForm';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const CreateView = () => {
  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <header className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Create Custom View</h1>
          <p className="text-muted-foreground mt-1">
            Create a filtered view for specific business areas or clients
          </p>
        </div>
      </header>

      {/* Form */}
      <CreateViewForm />
    </div>
  );
};

export default CreateView;
