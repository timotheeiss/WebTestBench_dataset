import { useCashFlow } from '@/contexts/CashFlowContext';
import { AnalyticsCharts } from '@/components/analytics/AnalyticsCharts';

const Analytics = () => {
  const { activeView, customViews } = useCashFlow();
  const currentView = activeView ? customViews.find((v) => v.id === activeView) : null;

  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <header>
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
          {currentView ? `${currentView.name} Analytics` : 'Analytics'}
        </h1>
        <p className="text-muted-foreground mt-1">
          {currentView ? currentView.description : 'Insights and breakdowns of your cash flow'}
        </p>
      </header>

      {/* Charts */}
      <AnalyticsCharts />
    </div>
  );
};

export default Analytics;
