import { ForecastChart } from '@/components/forecast/ForecastChart';

const Forecast = () => {
  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <header>
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Forecast</h1>
        <p className="text-muted-foreground mt-1">
          Projected cash flow based on recurring items and expected transactions
        </p>
      </header>

      {/* Forecast Content */}
      <ForecastChart />
    </div>
  );
};

export default Forecast;
