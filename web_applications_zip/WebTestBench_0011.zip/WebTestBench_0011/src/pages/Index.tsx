import { useCashFlow } from '@/contexts/CashFlowContext';
import { SummaryCards } from '@/components/dashboard/SummaryCards';
import { CashFlowChart } from '@/components/dashboard/CashFlowChart';
import { TransactionList } from '@/components/transactions/TransactionList';
import { TransactionForm } from '@/components/transactions/TransactionForm';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Index = () => {
  const { activeView, customViews } = useCashFlow();
  const currentView = activeView ? customViews.find((v) => v.id === activeView) : null;

  return (
    <div className="p-6 lg:p-8 space-y-8 animate-fade-in">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
            {currentView ? currentView.name : 'Dashboard'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {currentView ? currentView.description : 'Overview of your business cash flow'}
          </p>
        </div>
        <TransactionForm />
      </header>

      {/* Summary Cards */}
      <SummaryCards />

      {/* Chart */}
      <CashFlowChart />

      {/* Recent Transactions */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Recent Transactions</h2>
          <Button variant="ghost" asChild className="gap-2">
            <Link to="/transactions">
              View all
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
        <TransactionList compact limit={5} />
      </section>
    </div>
  );
};

export default Index;
