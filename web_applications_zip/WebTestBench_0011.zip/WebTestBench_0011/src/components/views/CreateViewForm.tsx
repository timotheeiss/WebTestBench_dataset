import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCashFlow } from '@/contexts/CashFlowContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { TransactionStatus, TransactionType } from '@/data/mockData';
import { Palette, Save } from 'lucide-react';

const colorOptions = [
  '#8b5cf6', '#06b6d4', '#22c55e', '#f59e0b', '#ec4899', '#f43f5e', '#14b8a6', '#64748b',
];

export function CreateViewForm() {
  const navigate = useNavigate();
  const { categories, projects, addCustomView, setActiveView } = useCashFlow();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: colorOptions[0],
    selectedCategories: [] as string[],
    selectedProjects: [] as string[],
    selectedTypes: [] as TransactionType[],
    selectedStatuses: [] as TransactionStatus[],
  });

  const toggleCategory = (categoryId: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedCategories: prev.selectedCategories.includes(categoryId)
        ? prev.selectedCategories.filter((c) => c !== categoryId)
        : [...prev.selectedCategories, categoryId],
    }));
  };

  const toggleProject = (projectId: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedProjects: prev.selectedProjects.includes(projectId)
        ? prev.selectedProjects.filter((p) => p !== projectId)
        : [...prev.selectedProjects, projectId],
    }));
  };

  const toggleType = (type: TransactionType) => {
    setFormData((prev) => ({
      ...prev,
      selectedTypes: prev.selectedTypes.includes(type)
        ? prev.selectedTypes.filter((t) => t !== type)
        : [...prev.selectedTypes, type],
    }));
  };

  const toggleStatus = (status: TransactionStatus) => {
    setFormData((prev) => ({
      ...prev,
      selectedStatuses: prev.selectedStatuses.includes(status)
        ? prev.selectedStatuses.filter((s) => s !== status)
        : [...prev.selectedStatuses, status],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    addCustomView({
      name: formData.name,
      description: formData.description,
      color: formData.color,
      filters: {
        categories: formData.selectedCategories.length > 0 ? formData.selectedCategories : undefined,
        projects: formData.selectedProjects.length > 0 ? formData.selectedProjects : undefined,
        types: formData.selectedTypes.length > 0 ? formData.selectedTypes : undefined,
        statuses: formData.selectedStatuses.length > 0 ? formData.selectedStatuses : undefined,
      },
    });

    navigate('/');
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>View Details</CardTitle>
          <CardDescription>Give your view a name and description</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">View Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Marketing Overview"
              required
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="What does this view show?"
              rows={2}
            />
          </div>
          <div>
            <Label className="flex items-center gap-2 mb-3">
              <Palette className="w-4 h-4" />
              Color
            </Label>
            <div className="flex gap-2">
              {colorOptions.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setFormData({ ...formData, color })}
                  className={`w-8 h-8 rounded-full transition-transform ${
                    formData.color === color ? 'scale-125 ring-2 ring-offset-2 ring-offset-background ring-white' : ''
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Filter by Type</CardTitle>
          <CardDescription>Include only specific transaction types</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            {(['income', 'expense'] as TransactionType[]).map((type) => (
              <label key={type} className="flex items-center gap-2 cursor-pointer">
                <Checkbox
                  checked={formData.selectedTypes.includes(type)}
                  onCheckedChange={() => toggleType(type)}
                />
                <span className="capitalize">{type}</span>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Filter by Status</CardTitle>
          <CardDescription>Include only specific statuses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            {(['paid', 'pending', 'expected'] as TransactionStatus[]).map((status) => (
              <label key={status} className="flex items-center gap-2 cursor-pointer">
                <Checkbox
                  checked={formData.selectedStatuses.includes(status)}
                  onCheckedChange={() => toggleStatus(status)}
                />
                <span className="capitalize">{status}</span>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Filter by Categories</CardTitle>
          <CardDescription>Select categories to include in this view</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {categories.map((category) => (
              <label
                key={category.id}
                className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-muted/50 transition-colors"
              >
                <Checkbox
                  checked={formData.selectedCategories.includes(category.id)}
                  onCheckedChange={() => toggleCategory(category.id)}
                />
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: category.color }}
                />
                <span className="text-sm">{category.name}</span>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Filter by Projects</CardTitle>
          <CardDescription>Select projects to include in this view</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {projects.map((project) => (
              <label
                key={project.id}
                className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-muted/50 transition-colors"
              >
                <Checkbox
                  checked={formData.selectedProjects.includes(project.id)}
                  onCheckedChange={() => toggleProject(project.id)}
                />
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: project.color }}
                />
                <span className="text-sm">{project.name}</span>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      <Button type="submit" size="lg" className="w-full gap-2">
        <Save className="w-4 h-4" />
        Create View
      </Button>
    </form>
  );
}
