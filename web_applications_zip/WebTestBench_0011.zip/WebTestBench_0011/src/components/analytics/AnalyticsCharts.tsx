import { useMemo } from 'react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { useCashFlow } from '@/contexts/CashFlowContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export function AnalyticsCharts() {
  const { filteredTransactions, categories, projects } = useCashFlow();

  // Category breakdown
  const categoryData = useMemo(() => {
    const expenseTransactions = filteredTransactions.filter(
      (t) => t.type === 'expense' && t.status === 'paid'
    );

    const grouped = expenseTransactions.reduce((acc, txn) => {
      const category = categories.find((c) => c.id === txn.category);
      if (category) {
        acc[category.name] = (acc[category.name] || 0) + txn.amount;
      }
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped)
      .map(([name, value]) => ({
        name,
        value,
        color: categories.find((c) => c.name === name)?.color || '#64748b',
      }))
      .sort((a, b) => b.value - a.value);
  }, [filteredTransactions, categories]);

  // Project breakdown
  const projectData = useMemo(() => {
    const paidTransactions = filteredTransactions.filter((t) => t.status === 'paid');

    const grouped = paidTransactions.reduce((acc, txn) => {
      const project = projects.find((p) => p.id === txn.project);
      if (project) {
        if (!acc[project.name]) {
          acc[project.name] = { income: 0, expense: 0, color: project.color };
        }
        if (txn.type === 'income') {
          acc[project.name].income += txn.amount;
        } else {
          acc[project.name].expense += txn.amount;
        }
      }
      return acc;
    }, {} as Record<string, { income: number; expense: number; color: string }>);

    return Object.entries(grouped)
      .map(([name, data]) => ({
        name,
        income: data.income,
        expense: data.expense,
        net: data.income - data.expense,
        color: data.color,
      }))
      .sort((a, b) => b.net - a.net);
  }, [filteredTransactions, projects]);

  // Income sources
  const incomeData = useMemo(() => {
    const incomeTransactions = filteredTransactions.filter(
      (t) => t.type === 'income' && t.status === 'paid'
    );

    const grouped = incomeTransactions.reduce((acc, txn) => {
      const category = categories.find((c) => c.id === txn.category);
      if (category) {
        acc[category.name] = (acc[category.name] || 0) + txn.amount;
      }
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped)
      .map(([name, value]) => ({
        name,
        value,
        color: categories.find((c) => c.name === name)?.color || '#14b8a6',
      }))
      .sort((a, b) => b.value - a.value);
  }, [filteredTransactions, categories]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload || !payload[0]) return null;

    return (
      <div className="bg-popover/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-xl">
        <p className="text-sm font-medium text-foreground">{payload[0].name || payload[0].payload.name}</p>
        <p className="text-sm font-mono text-muted-foreground">
          {formatCurrency(payload[0].value)}
        </p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Expense by Category */}
        <Card>
          <CardHeader>
            <CardTitle>Expenses by Category</CardTitle>
            <CardDescription>Breakdown of paid expenses</CardDescription>
          </CardHeader>
          <CardContent>
            {categoryData.length === 0 ? (
              <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                No expense data available
              </div>
            ) : (
              <div className="flex items-center gap-6">
                <div className="h-[200px] w-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex-1 space-y-2">
                  {categoryData.slice(0, 5).map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-muted-foreground truncate max-w-[120px]">
                          {item.name}
                        </span>
                      </div>
                      <span className="font-mono">{formatCurrency(item.value)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Income by Source */}
        <Card>
          <CardHeader>
            <CardTitle>Income by Source</CardTitle>
            <CardDescription>Breakdown of received income</CardDescription>
          </CardHeader>
          <CardContent>
            {incomeData.length === 0 ? (
              <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                No income data available
              </div>
            ) : (
              <div className="flex items-center gap-6">
                <div className="h-[200px] w-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={incomeData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {incomeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex-1 space-y-2">
                  {incomeData.slice(0, 5).map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-muted-foreground truncate max-w-[120px]">
                          {item.name}
                        </span>
                      </div>
                      <span className="font-mono">{formatCurrency(item.value)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Project Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Project Performance</CardTitle>
          <CardDescription>Income vs expenses by project</CardDescription>
        </CardHeader>
        <CardContent>
          {projectData.length === 0 ? (
            <div className="flex items-center justify-center h-[300px] text-muted-foreground">
              No project data available
            </div>
          ) : (
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={projectData} layout="vertical">
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(222, 30%, 16%)"
                    horizontal={false}
                  />
                  <XAxis
                    type="number"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
                    tickFormatter={(value) => `$${value / 1000}k`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
                    width={120}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload || !payload[0]) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-popover/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-xl">
                          <p className="text-sm font-medium text-foreground mb-2">{data.name}</p>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between gap-4">
                              <span className="text-income">Income:</span>
                              <span className="font-mono">{formatCurrency(data.income)}</span>
                            </div>
                            <div className="flex justify-between gap-4">
                              <span className="text-expense">Expenses:</span>
                              <span className="font-mono">{formatCurrency(data.expense)}</span>
                            </div>
                            <div className="border-t border-border pt-1 flex justify-between gap-4">
                              <span>Net:</span>
                              <span className={`font-mono font-medium ${data.net >= 0 ? 'text-income' : 'text-expense'}`}>
                                {formatCurrency(data.net)}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Bar dataKey="income" fill="hsl(172, 66%, 50%)" radius={[0, 4, 4, 0]} />
                  <Bar dataKey="expense" fill="hsl(346, 77%, 60%)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
