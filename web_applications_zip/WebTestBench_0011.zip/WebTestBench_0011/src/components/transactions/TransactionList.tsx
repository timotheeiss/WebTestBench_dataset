import { useCashFlow } from '@/contexts/CashFlowContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  MoreHorizontal,
  Pencil,
  Trash2,
  TrendingUp,
  TrendingDown,
  Repeat,
  Building,
  CreditCard,
  Wallet,
  Zap,
  ArrowRightLeft,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

const paymentMethodIcons: Record<string, React.ReactNode> = {
  building: <Building className="w-4 h-4" />,
  'credit-card': <CreditCard className="w-4 h-4" />,
  wallet: <Wallet className="w-4 h-4" />,
  zap: <Zap className="w-4 h-4" />,
  'arrow-right-left': <ArrowRightLeft className="w-4 h-4" />,
};

interface TransactionListProps {
  onEdit?: (id: string) => void;
  compact?: boolean;
  limit?: number;
}

export function TransactionList({ onEdit, compact = false, limit }: TransactionListProps) {
  const {
    filteredTransactions,
    categories,
    projects,
    paymentMethods,
    deleteTransaction,
    updateTransaction,
  } = useCashFlow();

  const displayedTransactions = limit
    ? filteredTransactions.slice(0, limit)
    : filteredTransactions;

  const getCategoryName = (categoryId: string) =>
    categories.find((c) => c.id === categoryId)?.name || 'Unknown';

  const getProjectName = (projectId: string) =>
    projects.find((p) => p.id === projectId)?.name || 'Unknown';

  const getProjectColor = (projectId: string) =>
    projects.find((p) => p.id === projectId)?.color || '#64748b';

  const getPaymentMethod = (pmId: string) =>
    paymentMethods.find((pm) => pm.id === pmId);

  if (displayedTransactions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
          <TrendingUp className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-1">
          No transactions found
        </h3>
        <p className="text-sm text-muted-foreground">
          Try adjusting your filters or add a new transaction
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {displayedTransactions.map((transaction, index) => (
        <div
          key={transaction.id}
          className={cn(
            'group flex items-center gap-4 p-4 rounded-lg border border-border bg-card/50 hover:bg-card transition-all duration-200 animate-fade-in',
            compact && 'p-3'
          )}
          style={{ animationDelay: `${index * 50}ms` }}
        >
          {/* Icon */}
          <div
            className={cn(
              'w-10 h-10 rounded-lg flex items-center justify-center shrink-0',
              transaction.type === 'income'
                ? 'bg-income/10 text-income'
                : 'bg-expense/10 text-expense'
            )}
          >
            {transaction.type === 'income' ? (
              <TrendingUp className="w-5 h-5" />
            ) : (
              <TrendingDown className="w-5 h-5" />
            )}
          </div>

          {/* Main Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-medium text-foreground truncate">
                {transaction.description}
              </h4>
              {transaction.isRecurring && (
                <Repeat className="w-3.5 h-3.5 text-muted-foreground" />
              )}
            </div>
            <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
              <span>{format(new Date(transaction.date), 'MMM d, yyyy')}</span>
              <span>•</span>
              <div className="flex items-center gap-1">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: getProjectColor(transaction.project) }}
                />
                <span className="truncate">{getProjectName(transaction.project)}</span>
              </div>
            </div>
          </div>

          {/* Category & Payment Method */}
          {!compact && (
            <div className="hidden md:flex items-center gap-4">
              <Badge variant="outline" className="text-xs">
                {getCategoryName(transaction.category)}
              </Badge>
              <div className="flex items-center gap-1 text-muted-foreground">
                {paymentMethodIcons[getPaymentMethod(transaction.paymentMethod)?.icon || 'building']}
              </div>
            </div>
          )}

          {/* Status */}
          <Badge
            variant={
              transaction.status === 'paid'
                ? 'paid'
                : transaction.status === 'pending'
                ? 'pending'
                : 'expected'
            }
            className="capitalize"
          >
            {transaction.status}
          </Badge>

          {/* Amount */}
          <div
            className={cn(
              'font-mono font-semibold text-right min-w-[100px]',
              transaction.type === 'income' ? 'text-income' : 'text-expense'
            )}
          >
            {transaction.type === 'income' ? '+' : '-'}
            {formatCurrency(transaction.amount)}
          </div>

          {/* Actions */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit?.(transaction.id)}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit
              </DropdownMenuItem>
              {transaction.status === 'pending' && (
                <DropdownMenuItem
                  onClick={() =>
                    updateTransaction(transaction.id, { status: 'paid' })
                  }
                >
                  Mark as Paid
                </DropdownMenuItem>
              )}
              {transaction.status === 'expected' && (
                <DropdownMenuItem
                  onClick={() =>
                    updateTransaction(transaction.id, { status: 'pending' })
                  }
                >
                  Mark as Pending
                </DropdownMenuItem>
              )}
              <DropdownMenuItem
                onClick={() => deleteTransaction(transaction.id)}
                className="text-destructive focus:text-destructive"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ))}
    </div>
  );
}
