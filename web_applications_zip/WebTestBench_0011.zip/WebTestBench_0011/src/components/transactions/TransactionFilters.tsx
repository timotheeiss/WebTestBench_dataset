import { useCashFlow } from '@/contexts/CashFlowContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Filter, X, ArrowUpDown } from 'lucide-react';
import { TransactionStatus, TransactionType } from '@/data/mockData';

export function TransactionFilters() {
  const {
    filters,
    setFilters,
    resetFilters,
    categories,
    projects,
    sortBy,
    sortOrder,
    setSortBy,
    setSortOrder,
  } = useCashFlow();

  const hasActiveFilters =
    filters.search ||
    filters.types.length > 0 ||
    filters.statuses.length > 0 ||
    filters.categories.length > 0 ||
    filters.projects.length > 0;

  const toggleType = (type: TransactionType) => {
    const current = filters.types;
    if (current.includes(type)) {
      setFilters({ types: current.filter((t) => t !== type) });
    } else {
      setFilters({ types: [...current, type] });
    }
  };

  const toggleStatus = (status: TransactionStatus) => {
    const current = filters.statuses;
    if (current.includes(status)) {
      setFilters({ statuses: current.filter((s) => s !== status) });
    } else {
      setFilters({ statuses: [...current, status] });
    }
  };

  const toggleCategory = (categoryId: string) => {
    const current = filters.categories;
    if (current.includes(categoryId)) {
      setFilters({ categories: current.filter((c) => c !== categoryId) });
    } else {
      setFilters({ categories: [...current, categoryId] });
    }
  };

  const toggleProject = (projectId: string) => {
    const current = filters.projects;
    if (current.includes(projectId)) {
      setFilters({ projects: current.filter((p) => p !== projectId) });
    } else {
      setFilters({ projects: [...current, projectId] });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search transactions..."
            value={filters.search}
            onChange={(e) => setFilters({ search: e.target.value })}
            className="pl-9 bg-secondary border-border"
          />
        </div>

        {/* Type Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Type
              {filters.types.length > 0 && (
                <Badge variant="secondary" className="ml-1 px-1.5">
                  {filters.types.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48" align="start">
            <div className="space-y-2">
              {(['income', 'expense'] as TransactionType[]).map((type) => (
                <label
                  key={type}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <Checkbox
                    checked={filters.types.includes(type)}
                    onCheckedChange={() => toggleType(type)}
                  />
                  <span className="capitalize">{type}</span>
                </label>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Status Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Status
              {filters.statuses.length > 0 && (
                <Badge variant="secondary" className="ml-1 px-1.5">
                  {filters.statuses.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48" align="start">
            <div className="space-y-2">
              {(['paid', 'pending', 'expected'] as TransactionStatus[]).map(
                (status) => (
                  <label
                    key={status}
                    className="flex items-center gap-2 cursor-pointer"
                  >
                    <Checkbox
                      checked={filters.statuses.includes(status)}
                      onCheckedChange={() => toggleStatus(status)}
                    />
                    <span className="capitalize">{status}</span>
                  </label>
                )
              )}
            </div>
          </PopoverContent>
        </Popover>

        {/* Category Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Category
              {filters.categories.length > 0 && (
                <Badge variant="secondary" className="ml-1 px-1.5">
                  {filters.categories.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56" align="start">
            <div className="space-y-2 max-h-60 overflow-auto">
              {categories.map((category) => (
                <label
                  key={category.id}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <Checkbox
                    checked={filters.categories.includes(category.id)}
                    onCheckedChange={() => toggleCategory(category.id)}
                  />
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-sm">{category.name}</span>
                </label>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Project Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Project
              {filters.projects.length > 0 && (
                <Badge variant="secondary" className="ml-1 px-1.5">
                  {filters.projects.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56" align="start">
            <div className="space-y-2 max-h-60 overflow-auto">
              {projects.map((project) => (
                <label
                  key={project.id}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <Checkbox
                    checked={filters.projects.includes(project.id)}
                    onCheckedChange={() => toggleProject(project.id)}
                  />
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: project.color }}
                  />
                  <span className="text-sm">{project.name}</span>
                </label>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Sort */}
        <div className="flex items-center gap-2">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="amount">Amount</SelectItem>
              <SelectItem value="description">Name</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
          >
            <ArrowUpDown className="w-4 h-4" />
          </Button>
        </div>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button variant="ghost" onClick={resetFilters} className="gap-2">
            <X className="w-4 h-4" />
            Clear
          </Button>
        )}
      </div>
    </div>
  );
}
