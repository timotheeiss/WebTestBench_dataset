import { useState } from 'react';
import { useCashFlow } from '@/contexts/CashFlowContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Transaction, TransactionType, TransactionStatus, RecurringFrequency } from '@/data/mockData';

interface TransactionFormProps {
  editTransaction?: Transaction;
  onClose?: () => void;
}

export function TransactionForm({ editTransaction, onClose }: TransactionFormProps) {
  const { categories, projects, paymentMethods, addTransaction, updateTransaction } = useCashFlow();
  const [open, setOpen] = useState(!!editTransaction);

  const [formData, setFormData] = useState({
    type: editTransaction?.type || ('expense' as TransactionType),
    description: editTransaction?.description || '',
    amount: editTransaction?.amount?.toString() || '',
    date: editTransaction?.date || new Date().toISOString().split('T')[0],
    category: editTransaction?.category || '',
    project: editTransaction?.project || '',
    paymentMethod: editTransaction?.paymentMethod || '',
    status: editTransaction?.status || ('pending' as TransactionStatus),
    isRecurring: editTransaction?.isRecurring || false,
    recurringFrequency: editTransaction?.recurringFrequency || (null as RecurringFrequency),
    notes: editTransaction?.notes || '',
  });

  const filteredCategories = categories.filter((c) => c.type === formData.type);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const transactionData = {
      ...formData,
      amount: parseFloat(formData.amount) || 0,
    };

    if (editTransaction) {
      updateTransaction(editTransaction.id, transactionData);
    } else {
      addTransaction(transactionData);
    }

    setOpen(false);
    onClose?.();
    
    // Reset form
    setFormData({
      type: 'expense',
      description: '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      category: '',
      project: '',
      paymentMethod: '',
      status: 'pending',
      isRecurring: false,
      recurringFrequency: null,
      notes: '',
    });
  };

  const dialogContent = (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Type Toggle */}
      <div className="flex gap-2">
        <Button
          type="button"
          variant={formData.type === 'income' ? 'income' : 'outline'}
          className="flex-1"
          onClick={() => {
            setFormData({ ...formData, type: 'income', category: '' });
          }}
        >
          <TrendingUp className="w-4 h-4 mr-2" />
          Income
        </Button>
        <Button
          type="button"
          variant={formData.type === 'expense' ? 'expense' : 'outline'}
          className="flex-1"
          onClick={() => {
            setFormData({ ...formData, type: 'expense', category: '' });
          }}
        >
          <TrendingDown className="w-4 h-4 mr-2" />
          Expense
        </Button>
      </div>

      {/* Description & Amount */}
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <Label htmlFor="description">Description</Label>
          <Input
            id="description"
            value={formData.description}
            onChange={(e) =>
              setFormData({ ...formData, description: e.target.value })
            }
            placeholder="e.g., Monthly software subscription"
            required
          />
        </div>
        <div>
          <Label htmlFor="amount">Amount ($)</Label>
          <Input
            id="amount"
            type="number"
            step="0.01"
            min="0"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            placeholder="0.00"
            required
          />
        </div>
        <div>
          <Label htmlFor="date">Date</Label>
          <Input
            id="date"
            type="date"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            required
          />
        </div>
      </div>

      {/* Category & Project */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Category</Label>
          <Select
            value={formData.category}
            onValueChange={(value) =>
              setFormData({ ...formData, category: value })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {filteredCategories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: cat.color }}
                    />
                    {cat.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Project</Label>
          <Select
            value={formData.project}
            onValueChange={(value) =>
              setFormData({ ...formData, project: value })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((proj) => (
                <SelectItem key={proj.id} value={proj.id}>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: proj.color }}
                    />
                    {proj.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Payment Method & Status */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Payment Method</Label>
          <Select
            value={formData.paymentMethod}
            onValueChange={(value) =>
              setFormData({ ...formData, paymentMethod: value })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select method" />
            </SelectTrigger>
            <SelectContent>
              {paymentMethods.map((pm) => (
                <SelectItem key={pm.id} value={pm.id}>
                  {pm.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Status</Label>
          <Select
            value={formData.status}
            onValueChange={(value) =>
              setFormData({ ...formData, status: value as TransactionStatus })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="expected">Expected</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Recurring */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="recurring">Recurring Transaction</Label>
          <Switch
            id="recurring"
            checked={formData.isRecurring}
            onCheckedChange={(checked) =>
              setFormData({
                ...formData,
                isRecurring: checked,
                recurringFrequency: checked ? 'monthly' : null,
              })
            }
          />
        </div>
        {formData.isRecurring && (
          <Select
            value={formData.recurringFrequency || 'monthly'}
            onValueChange={(value) =>
              setFormData({
                ...formData,
                recurringFrequency: value as RecurringFrequency,
              })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Notes */}
      <div>
        <Label htmlFor="notes">Notes (optional)</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Add any additional notes..."
          rows={2}
        />
      </div>

      {/* Submit */}
      <Button type="submit" className="w-full">
        {editTransaction ? 'Update Transaction' : 'Add Transaction'}
      </Button>
    </form>
  );

  if (editTransaction) {
    return (
      <Dialog open={open} onOpenChange={(isOpen) => { setOpen(isOpen); if (!isOpen) onClose?.(); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Transaction</DialogTitle>
          </DialogHeader>
          {dialogContent}
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Add Transaction
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>New Transaction</DialogTitle>
        </DialogHeader>
        {dialogContent}
      </DialogContent>
    </Dialog>
  );
}
