import { useCashFlow } from '@/contexts/CashFlowContext';
import { TrendingUp, TrendingDown, Wallet, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

interface SummaryCardProps {
  title: string;
  amount: number;
  icon: React.ReactNode;
  variant: 'income' | 'expense' | 'neutral' | 'pending';
  subtitle?: string;
}

function SummaryCard({ title, amount, icon, variant, subtitle }: SummaryCardProps) {
  return (
    <div
      className={cn(
        'relative p-6 rounded-xl border transition-all duration-300 hover:scale-[1.02] overflow-hidden',
        'bg-card border-border',
        variant === 'income' && 'hover:shadow-lg hover:shadow-income/10',
        variant === 'expense' && 'hover:shadow-lg hover:shadow-expense/10',
        variant === 'neutral' && 'hover:shadow-lg hover:shadow-primary/10',
        variant === 'pending' && 'hover:shadow-lg hover:shadow-warning/10'
      )}
    >
      {/* Background glow effect */}
      <div
        className={cn(
          'absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-10',
          variant === 'income' && 'bg-income',
          variant === 'expense' && 'bg-expense',
          variant === 'neutral' && 'bg-primary',
          variant === 'pending' && 'bg-warning'
        )}
      />

      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium text-muted-foreground">{title}</span>
          <div
            className={cn(
              'w-10 h-10 rounded-lg flex items-center justify-center',
              variant === 'income' && 'bg-income/10 text-income',
              variant === 'expense' && 'bg-expense/10 text-expense',
              variant === 'neutral' && 'bg-primary/10 text-primary',
              variant === 'pending' && 'bg-warning/10 text-warning'
            )}
          >
            {icon}
          </div>
        </div>
        <div className="space-y-1">
          <p
            className={cn(
              'text-3xl font-bold font-mono tracking-tight',
              variant === 'income' && 'text-income',
              variant === 'expense' && 'text-expense',
              variant === 'neutral' && (amount >= 0 ? 'text-income' : 'text-expense'),
              variant === 'pending' && 'text-warning'
            )}
          >
            {variant === 'neutral' && amount >= 0 ? '+' : ''}
            {formatCurrency(amount)}
          </p>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
      </div>
    </div>
  );
}

export function SummaryCards() {
  const { summary } = useCashFlow();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <SummaryCard
        title="Total Income"
        amount={summary.totalIncome}
        icon={<TrendingUp className="w-5 h-5" />}
        variant="income"
        subtitle="Paid transactions"
      />
      <SummaryCard
        title="Total Expenses"
        amount={summary.totalExpenses}
        icon={<TrendingDown className="w-5 h-5" />}
        variant="expense"
        subtitle="Paid transactions"
      />
      <SummaryCard
        title="Net Cash Flow"
        amount={summary.netCashFlow}
        icon={<Wallet className="w-5 h-5" />}
        variant="neutral"
        subtitle="Income - Expenses"
      />
      <SummaryCard
        title="Pending"
        amount={summary.pendingIncome - summary.pendingExpenses}
        icon={<Clock className="w-5 h-5" />}
        variant="pending"
        subtitle={`${formatCurrency(summary.pendingIncome)} in / ${formatCurrency(summary.pendingExpenses)} out`}
      />
    </div>
  );
}
