import { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
} from 'recharts';
import { useCashFlow } from '@/contexts/CashFlowContext';
import { forecastData } from '@/data/mockData';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertCircle, Calendar } from 'lucide-react';
import { format, addDays, addMonths } from 'date-fns';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    value: number;
    dataKey: string;
    payload: {
      month: string;
      balance: number;
      income: number;
      expenses: number;
    };
  }>;
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || !payload[0]) return null;

  const data = payload[0].payload;

  return (
    <div className="bg-popover/95 backdrop-blur-sm border border-border rounded-lg p-4 shadow-xl">
      <p className="text-sm font-medium text-foreground mb-2">{data.month} (Projected)</p>
      <div className="space-y-1 text-sm">
        <div className="flex justify-between gap-4">
          <span className="text-income">Income:</span>
          <span className="font-mono">{formatCurrency(data.income)}</span>
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-expense">Expenses:</span>
          <span className="font-mono">{formatCurrency(data.expenses)}</span>
        </div>
        <div className="border-t border-border pt-1 mt-1 flex justify-between gap-4">
          <span className="text-foreground">Net:</span>
          <span className={`font-mono font-medium ${data.balance >= 0 ? 'text-income' : 'text-expense'}`}>
            {formatCurrency(data.balance)}
          </span>
        </div>
      </div>
    </div>
  );
}

export function ForecastChart() {
  const { transactions, summary } = useCashFlow();

  // Calculate upcoming expected transactions
  const upcomingTransactions = useMemo(() => {
    const now = new Date();
    const threeMonthsLater = addMonths(now, 3);

    return transactions
      .filter((t) => {
        const date = new Date(t.date);
        return (
          (t.status === 'pending' || t.status === 'expected') &&
          date >= now &&
          date <= threeMonthsLater
        );
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [transactions]);

  // Calculate projected balance
  const currentBalance = summary.netCashFlow;
  const projectedBalance = currentBalance + summary.pendingIncome - summary.pendingExpenses;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Current Balance</p>
                <p className={`text-2xl font-bold font-mono ${currentBalance >= 0 ? 'text-income' : 'text-expense'}`}>
                  {formatCurrency(currentBalance)}
                </p>
              </div>
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${currentBalance >= 0 ? 'bg-income/10 text-income' : 'bg-expense/10 text-expense'}`}>
                {currentBalance >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Projected (3 months)</p>
                <p className={`text-2xl font-bold font-mono ${projectedBalance >= 0 ? 'text-income' : 'text-expense'}`}>
                  {formatCurrency(projectedBalance)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-primary/10 text-primary">
                <Calendar className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Upcoming Transactions</p>
                <p className="text-2xl font-bold font-mono text-foreground">
                  {upcomingTransactions.length}
                </p>
              </div>
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-warning/10 text-warning">
                <AlertCircle className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Forecast Chart */}
      <Card>
        <CardHeader>
          <CardTitle>3-Month Forecast</CardTitle>
          <CardDescription>Projected cash flow based on recurring items and expected transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" vertical={false} />
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
                  tickFormatter={(value) => `$${value / 1000}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={0} stroke="hsl(222, 30%, 20%)" />
                <Bar dataKey="balance" radius={[4, 4, 0, 0]}>
                  {forecastData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.balance >= 0 ? 'hsl(172, 66%, 50%)' : 'hsl(346, 77%, 60%)'}
                      fillOpacity={0.8}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Transactions</CardTitle>
          <CardDescription>Expected and pending payments in the next 3 months</CardDescription>
        </CardHeader>
        <CardContent>
          {upcomingTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No upcoming transactions scheduled
            </p>
          ) : (
            <div className="space-y-3">
              {upcomingTransactions.slice(0, 10).map((txn) => (
                <div
                  key={txn.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/30"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        txn.type === 'income' ? 'bg-income/10 text-income' : 'bg-expense/10 text-expense'
                      }`}
                    >
                      {txn.type === 'income' ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{txn.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(txn.date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={txn.status === 'pending' ? 'pending' : 'expected'}>
                      {txn.status}
                    </Badge>
                    <span
                      className={`font-mono font-medium ${
                        txn.type === 'income' ? 'text-income' : 'text-expense'
                      }`}
                    >
                      {txn.type === 'income' ? '+' : '-'}
                      {formatCurrency(txn.amount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
