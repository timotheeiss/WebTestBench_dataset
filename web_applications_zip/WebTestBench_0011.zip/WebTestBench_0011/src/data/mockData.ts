export type TransactionType = 'income' | 'expense';
export type TransactionStatus = 'paid' | 'pending' | 'expected';
export type RecurringFrequency = 'weekly' | 'monthly' | 'quarterly' | 'yearly' | null;

export interface Transaction {
  id: string;
  type: TransactionType;
  description: string;
  amount: number;
  date: string;
  category: string;
  project: string;
  paymentMethod: string;
  status: TransactionStatus;
  isRecurring: boolean;
  recurringFrequency: RecurringFrequency;
  notes?: string;
}

export interface Category {
  id: string;
  name: string;
  type: TransactionType;
  color: string;
}

export interface Project {
  id: string;
  name: string;
  color: string;
  budget?: number;
}

export interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
}

export interface CustomView {
  id: string;
  name: string;
  description: string;
  filters: {
    categories?: string[];
    projects?: string[];
    types?: TransactionType[];
    statuses?: TransactionStatus[];
  };
  color: string;
}

export const categories: Category[] = [
  { id: 'cat-1', name: 'Client Services', type: 'income', color: '#14b8a6' },
  { id: 'cat-2', name: 'Product Sales', type: 'income', color: '#22d3ee' },
  { id: 'cat-3', name: 'Consulting', type: 'income', color: '#06b6d4' },
  { id: 'cat-4', name: 'Subscriptions', type: 'income', color: '#0891b2' },
  { id: 'cat-5', name: 'Salaries', type: 'expense', color: '#f43f5e' },
  { id: 'cat-6', name: 'Marketing', type: 'expense', color: '#e11d48' },
  { id: 'cat-7', name: 'Software & Tools', type: 'expense', color: '#be123c' },
  { id: 'cat-8', name: 'Office & Utilities', type: 'expense', color: '#9f1239' },
  { id: 'cat-9', name: 'Travel', type: 'expense', color: '#881337' },
  { id: 'cat-10', name: 'Professional Services', type: 'expense', color: '#f97316' },
];

export const projects: Project[] = [
  { id: 'proj-1', name: 'Marketing Campaigns', color: '#8b5cf6', budget: 50000 },
  { id: 'proj-2', name: 'Operations', color: '#06b6d4', budget: 100000 },
  { id: 'proj-3', name: 'Client: TechCorp', color: '#22c55e', budget: 75000 },
  { id: 'proj-4', name: 'Client: RetailMax', color: '#f59e0b', budget: 45000 },
  { id: 'proj-5', name: 'Product Development', color: '#ec4899', budget: 120000 },
  { id: 'proj-6', name: 'General', color: '#64748b' },
];

export const paymentMethods: PaymentMethod[] = [
  { id: 'pm-1', name: 'Business Checking', icon: 'building' },
  { id: 'pm-2', name: 'Business Credit Card', icon: 'credit-card' },
  { id: 'pm-3', name: 'PayPal', icon: 'wallet' },
  { id: 'pm-4', name: 'Stripe', icon: 'zap' },
  { id: 'pm-5', name: 'Wire Transfer', icon: 'arrow-right-left' },
];

export const customViews: CustomView[] = [
  {
    id: 'view-1',
    name: 'Marketing Overview',
    description: 'All marketing-related transactions',
    filters: {
      categories: ['cat-6'],
      projects: ['proj-1'],
    },
    color: '#8b5cf6',
  },
  {
    id: 'view-2',
    name: 'Operations',
    description: 'Operational costs and income',
    filters: {
      projects: ['proj-2'],
    },
    color: '#06b6d4',
  },
  {
    id: 'view-3',
    name: 'TechCorp Client',
    description: 'All transactions for TechCorp',
    filters: {
      projects: ['proj-3'],
    },
    color: '#22c55e',
  },
  {
    id: 'view-4',
    name: 'Pending Payments',
    description: 'All pending transactions',
    filters: {
      statuses: ['pending'],
    },
    color: '#f59e0b',
  },
];

// Generate dates for the past 6 months and future 3 months
const today = new Date();
const getDate = (daysOffset: number) => {
  const date = new Date(today);
  date.setDate(date.getDate() + daysOffset);
  return date.toISOString().split('T')[0];
};

export const transactions: Transaction[] = [
  // Recent Past Transactions
  {
    id: 'txn-1',
    type: 'income',
    description: 'TechCorp Monthly Retainer',
    amount: 15000,
    date: getDate(-2),
    category: 'cat-1',
    project: 'proj-3',
    paymentMethod: 'pm-4',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-2',
    type: 'expense',
    description: 'Google Ads Campaign',
    amount: 3500,
    date: getDate(-5),
    category: 'cat-6',
    project: 'proj-1',
    paymentMethod: 'pm-2',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-3',
    type: 'expense',
    description: 'Team Salaries',
    amount: 28000,
    date: getDate(-1),
    category: 'cat-5',
    project: 'proj-2',
    paymentMethod: 'pm-1',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-4',
    type: 'income',
    description: 'RetailMax Consulting',
    amount: 8500,
    date: getDate(-8),
    category: 'cat-3',
    project: 'proj-4',
    paymentMethod: 'pm-5',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-5',
    type: 'expense',
    description: 'AWS Hosting',
    amount: 1200,
    date: getDate(-10),
    category: 'cat-7',
    project: 'proj-5',
    paymentMethod: 'pm-2',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-6',
    type: 'income',
    description: 'Product License Sale',
    amount: 4500,
    date: getDate(-12),
    category: 'cat-2',
    project: 'proj-5',
    paymentMethod: 'pm-4',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-7',
    type: 'expense',
    description: 'Office Rent',
    amount: 4500,
    date: getDate(-3),
    category: 'cat-8',
    project: 'proj-2',
    paymentMethod: 'pm-1',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  // Pending Transactions
  {
    id: 'txn-8',
    type: 'income',
    description: 'TechCorp Project Milestone',
    amount: 25000,
    date: getDate(5),
    category: 'cat-1',
    project: 'proj-3',
    paymentMethod: 'pm-5',
    status: 'pending',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-9',
    type: 'expense',
    description: 'Conference Sponsorship',
    amount: 5000,
    date: getDate(7),
    category: 'cat-6',
    project: 'proj-1',
    paymentMethod: 'pm-2',
    status: 'pending',
    isRecurring: false,
    recurringFrequency: null,
  },
  // Expected Future Transactions
  {
    id: 'txn-10',
    type: 'income',
    description: 'TechCorp Monthly Retainer',
    amount: 15000,
    date: getDate(28),
    category: 'cat-1',
    project: 'proj-3',
    paymentMethod: 'pm-4',
    status: 'expected',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-11',
    type: 'expense',
    description: 'Team Salaries',
    amount: 28000,
    date: getDate(29),
    category: 'cat-5',
    project: 'proj-2',
    paymentMethod: 'pm-1',
    status: 'expected',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-12',
    type: 'income',
    description: 'RetailMax Q1 Payment',
    amount: 35000,
    date: getDate(15),
    category: 'cat-1',
    project: 'proj-4',
    paymentMethod: 'pm-5',
    status: 'expected',
    isRecurring: false,
    recurringFrequency: null,
  },
  // Historical Transactions (past months)
  {
    id: 'txn-13',
    type: 'income',
    description: 'TechCorp Monthly Retainer',
    amount: 15000,
    date: getDate(-32),
    category: 'cat-1',
    project: 'proj-3',
    paymentMethod: 'pm-4',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-14',
    type: 'expense',
    description: 'Team Salaries',
    amount: 28000,
    date: getDate(-31),
    category: 'cat-5',
    project: 'proj-2',
    paymentMethod: 'pm-1',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-15',
    type: 'income',
    description: 'Consulting Workshop',
    amount: 12000,
    date: getDate(-45),
    category: 'cat-3',
    project: 'proj-6',
    paymentMethod: 'pm-3',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-16',
    type: 'expense',
    description: 'Marketing Software',
    amount: 800,
    date: getDate(-50),
    category: 'cat-7',
    project: 'proj-1',
    paymentMethod: 'pm-2',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: 'txn-17',
    type: 'income',
    description: 'Product Sales Q4',
    amount: 22000,
    date: getDate(-60),
    category: 'cat-2',
    project: 'proj-5',
    paymentMethod: 'pm-4',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-18',
    type: 'expense',
    description: 'Business Travel',
    amount: 2800,
    date: getDate(-65),
    category: 'cat-9',
    project: 'proj-4',
    paymentMethod: 'pm-2',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-19',
    type: 'expense',
    description: 'Legal Consultation',
    amount: 3500,
    date: getDate(-20),
    category: 'cat-10',
    project: 'proj-6',
    paymentMethod: 'pm-1',
    status: 'paid',
    isRecurring: false,
    recurringFrequency: null,
  },
  {
    id: 'txn-20',
    type: 'income',
    description: 'Annual Subscription',
    amount: 9600,
    date: getDate(-90),
    category: 'cat-4',
    project: 'proj-5',
    paymentMethod: 'pm-4',
    status: 'paid',
    isRecurring: true,
    recurringFrequency: 'yearly',
  },
];

// Historical data for charts (last 6 months)
export const historicalCashFlow = [
  { month: 'Jul', income: 48000, expenses: 35000, balance: 13000 },
  { month: 'Aug', income: 52000, expenses: 38000, balance: 14000 },
  { month: 'Sep', income: 61000, expenses: 42000, balance: 19000 },
  { month: 'Oct', income: 55000, expenses: 40000, balance: 15000 },
  { month: 'Nov', income: 68000, expenses: 45000, balance: 23000 },
  { month: 'Dec', income: 72000, expenses: 48000, balance: 24000 },
];

// Forecast data (next 3 months)
export const forecastData = [
  { month: 'Jan', income: 65000, expenses: 46000, balance: 19000, isProjected: true },
  { month: 'Feb', income: 70000, expenses: 48000, balance: 22000, isProjected: true },
  { month: 'Mar', income: 75000, expenses: 50000, balance: 25000, isProjected: true },
];
