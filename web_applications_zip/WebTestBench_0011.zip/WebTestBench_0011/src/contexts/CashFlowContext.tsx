import React, { createContext, useContext, useState, useMemo, ReactNode } from 'react';
import {
  transactions as initialTransactions,
  categories,
  projects,
  paymentMethods,
  customViews as initialCustomViews,
  Transaction,
  Category,
  Project,
  PaymentMethod,
  CustomView,
  TransactionType,
  TransactionStatus,
} from '@/data/mockData';

interface Filters {
  search: string;
  types: TransactionType[];
  statuses: TransactionStatus[];
  categories: string[];
  projects: string[];
  dateRange: { from: string | null; to: string | null };
}

interface CashFlowContextType {
  transactions: Transaction[];
  categories: Category[];
  projects: Project[];
  paymentMethods: PaymentMethod[];
  customViews: CustomView[];
  filters: Filters;
  activeView: string | null;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  
  // Actions
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (id: string, updates: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  setFilters: (filters: Partial<Filters>) => void;
  resetFilters: () => void;
  setActiveView: (viewId: string | null) => void;
  addCustomView: (view: Omit<CustomView, 'id'>) => void;
  deleteCustomView: (id: string) => void;
  setSortBy: (field: string) => void;
  setSortOrder: (order: 'asc' | 'desc') => void;
  
  // Computed
  filteredTransactions: Transaction[];
  summary: {
    totalIncome: number;
    totalExpenses: number;
    netCashFlow: number;
    pendingIncome: number;
    pendingExpenses: number;
  };
}

const defaultFilters: Filters = {
  search: '',
  types: [],
  statuses: [],
  categories: [],
  projects: [],
  dateRange: { from: null, to: null },
};

const CashFlowContext = createContext<CashFlowContextType | undefined>(undefined);

export function CashFlowProvider({ children }: { children: ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [customViews, setCustomViews] = useState<CustomView[]>(initialCustomViews);
  const [filters, setFiltersState] = useState<Filters>(defaultFilters);
  const [activeView, setActiveView] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const setFilters = (newFilters: Partial<Filters>) => {
    setFiltersState(prev => ({ ...prev, ...newFilters }));
    setActiveView(null);
  };

  const resetFilters = () => {
    setFiltersState(defaultFilters);
    setActiveView(null);
  };

  const handleSetActiveView = (viewId: string | null) => {
    setActiveView(viewId);
    if (viewId) {
      const view = customViews.find(v => v.id === viewId);
      if (view) {
        setFiltersState({
          ...defaultFilters,
          categories: view.filters.categories || [],
          projects: view.filters.projects || [],
          types: view.filters.types || [],
          statuses: view.filters.statuses || [],
        });
      }
    } else {
      resetFilters();
    }
  };

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const id = `txn-${Date.now()}`;
    setTransactions(prev => [...prev, { ...transaction, id }]);
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    setTransactions(prev =>
      prev.map(txn => (txn.id === id ? { ...txn, ...updates } : txn))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(txn => txn.id !== id));
  };

  const addCustomView = (view: Omit<CustomView, 'id'>) => {
    const id = `view-${Date.now()}`;
    setCustomViews(prev => [...prev, { ...view, id }]);
  };

  const deleteCustomView = (id: string) => {
    setCustomViews(prev => prev.filter(v => v.id !== id));
    if (activeView === id) {
      setActiveView(null);
      resetFilters();
    }
  };

  const filteredTransactions = useMemo(() => {
    let result = [...transactions];

    // Apply search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        txn =>
          txn.description.toLowerCase().includes(searchLower) ||
          txn.notes?.toLowerCase().includes(searchLower)
      );
    }

    // Apply type filter
    if (filters.types.length > 0) {
      result = result.filter(txn => filters.types.includes(txn.type));
    }

    // Apply status filter
    if (filters.statuses.length > 0) {
      result = result.filter(txn => filters.statuses.includes(txn.status));
    }

    // Apply category filter
    if (filters.categories.length > 0) {
      result = result.filter(txn => filters.categories.includes(txn.category));
    }

    // Apply project filter
    if (filters.projects.length > 0) {
      result = result.filter(txn => filters.projects.includes(txn.project));
    }

    // Apply date range filter
    if (filters.dateRange.from) {
      result = result.filter(txn => txn.date >= filters.dateRange.from!);
    }
    if (filters.dateRange.to) {
      result = result.filter(txn => txn.date <= filters.dateRange.to!);
    }

    // Apply sorting
    result.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'date':
          comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
          break;
        case 'amount':
          comparison = a.amount - b.amount;
          break;
        case 'description':
          comparison = a.description.localeCompare(b.description);
          break;
        default:
          comparison = 0;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [transactions, filters, sortBy, sortOrder]);

  const summary = useMemo(() => {
    const paidTransactions = filteredTransactions.filter(t => t.status === 'paid');
    const pendingTransactions = filteredTransactions.filter(t => t.status === 'pending' || t.status === 'expected');

    return {
      totalIncome: paidTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0),
      totalExpenses: paidTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0),
      netCashFlow: paidTransactions.reduce(
        (sum, t) => sum + (t.type === 'income' ? t.amount : -t.amount),
        0
      ),
      pendingIncome: pendingTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0),
      pendingExpenses: pendingTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0),
    };
  }, [filteredTransactions]);

  return (
    <CashFlowContext.Provider
      value={{
        transactions,
        categories,
        projects,
        paymentMethods,
        customViews,
        filters,
        activeView,
        sortBy,
        sortOrder,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        setFilters,
        resetFilters,
        setActiveView: handleSetActiveView,
        addCustomView,
        deleteCustomView,
        setSortBy,
        setSortOrder,
        filteredTransactions,
        summary,
      }}
    >
      {children}
    </CashFlowContext.Provider>
  );
}

export function useCashFlow() {
  const context = useContext(CashFlowContext);
  if (!context) {
    throw new Error('useCashFlow must be used within a CashFlowProvider');
  }
  return context;
}
