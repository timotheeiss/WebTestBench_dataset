export type AppointmentStatus = "upcoming" | "completed" | "cancelled";

export interface Appointment {
  id: string;
  doctorId: string;
  patientName: string;
  date: string;
  time: string;
  status: AppointmentStatus;
  symptoms: string;
  consultationFee: number;
  paymentStatus: "paid" | "pending" | "refunded";
  visitNotes?: string;
  followUpInstructions?: string;
}

export const initialAppointments: Appointment[] = [
  {
    id: "apt-001",
    doctorId: "dr-002",
    patientName: "John Doe",
    date: "2024-12-10",
    time: "10:00 AM",
    status: "completed",
    symptoms: "Persistent headache and mild fever for 3 days",
    consultationFee: 80,
    paymentStatus: "paid",
    visitNotes: "Patient presented with tension-type headache and low-grade fever. Physical examination showed no concerning findings. Vital signs were stable.",
    followUpInstructions: "1. Take prescribed medication (Acetaminophen 500mg) as needed for pain, not exceeding 4 doses per day.\n2. Stay well hydrated - aim for 8 glasses of water daily.\n3. Get adequate rest and maintain regular sleep schedule.\n4. If fever persists beyond 5 days or headache worsens, schedule a follow-up immediately.\n5. Avoid screen time for extended periods.",
  },
  {
    id: "apt-002",
    doctorId: "dr-001",
    patientName: "John Doe",
    date: "2024-12-15",
    time: "2:30 PM",
    status: "upcoming",
    symptoms: "Occasional chest discomfort and shortness of breath",
    consultationFee: 150,
    paymentStatus: "paid",
  },
  {
    id: "apt-003",
    doctorId: "dr-003",
    patientName: "John Doe",
    date: "2024-11-28",
    time: "11:00 AM",
    status: "completed",
    symptoms: "Skin rash on arms and back",
    consultationFee: 120,
    paymentStatus: "paid",
    visitNotes: "Diagnosed with contact dermatitis, likely caused by new laundry detergent. Affected areas show mild inflammation without signs of infection.",
    followUpInstructions: "1. Apply prescribed hydrocortisone cream twice daily for 7 days.\n2. Switch to hypoallergenic, fragrance-free laundry products.\n3. Avoid scratching the affected areas.\n4. Take oral antihistamine if itching is severe.\n5. Follow up in 2 weeks if rash does not improve.",
  },
  {
    id: "apt-004",
    doctorId: "dr-006",
    patientName: "John Doe",
    date: "2024-11-20",
    time: "3:00 PM",
    status: "cancelled",
    symptoms: "Anxiety and stress management",
    consultationFee: 180,
    paymentStatus: "refunded",
  },
];
