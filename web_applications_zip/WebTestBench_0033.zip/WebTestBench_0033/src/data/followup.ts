export type TaskStatus = "pending" | "completed" | "skipped";

export interface FollowUpTask {
  id: string;
  appointmentId: string;
  description: string;
  frequency: string;
  status: TaskStatus;
  dueDate: string;
  completedAt?: string;
}

export interface VitalSign {
  id: string;
  patientId: string;
  type: "blood_pressure" | "blood_glucose" | "heart_rate" | "weight" | "temperature";
  value: string;
  unit: string;
  recordedAt: string;
  notes?: string;
}

export interface FollowUpPlan {
  id: string;
  appointmentId: string;
  doctorId: string;
  patientName: string;
  tasks: FollowUpTask[];
  createdAt: string;
  updatedAt: string;
}

export const initialFollowUpPlans: FollowUpPlan[] = [
  {
    id: "fp-001",
    appointmentId: "apt-001",
    doctorId: "dr-002",
    patientName: "John Doe",
    tasks: [
      {
        id: "task-001",
        appointmentId: "apt-001",
        description: "Take Acetaminophen 500mg as needed for pain",
        frequency: "Up to 4 times daily",
        status: "completed",
        dueDate: "2024-12-17",
        completedAt: "2024-12-11",
      },
      {
        id: "task-002",
        appointmentId: "apt-001",
        description: "Drink 8 glasses of water daily",
        frequency: "Daily",
        status: "completed",
        dueDate: "2024-12-17",
        completedAt: "2024-12-12",
      },
      {
        id: "task-003",
        appointmentId: "apt-001",
        description: "Get adequate rest (7-8 hours sleep)",
        frequency: "Daily",
        status: "pending",
        dueDate: "2024-12-17",
      },
      {
        id: "task-004",
        appointmentId: "apt-001",
        description: "Avoid screen time for extended periods",
        frequency: "Daily",
        status: "pending",
        dueDate: "2024-12-17",
      },
    ],
    createdAt: "2024-12-10",
    updatedAt: "2024-12-12",
  },
  {
    id: "fp-002",
    appointmentId: "apt-003",
    doctorId: "dr-003",
    patientName: "John Doe",
    tasks: [
      {
        id: "task-005",
        appointmentId: "apt-003",
        description: "Apply hydrocortisone cream to affected areas",
        frequency: "Twice daily for 7 days",
        status: "completed",
        dueDate: "2024-12-05",
        completedAt: "2024-12-05",
      },
      {
        id: "task-006",
        appointmentId: "apt-003",
        description: "Switch to hypoallergenic laundry products",
        frequency: "Ongoing",
        status: "completed",
        dueDate: "2024-12-01",
        completedAt: "2024-11-29",
      },
      {
        id: "task-007",
        appointmentId: "apt-003",
        description: "Avoid scratching affected areas",
        frequency: "Ongoing",
        status: "completed",
        dueDate: "2024-12-12",
        completedAt: "2024-12-10",
      },
    ],
    createdAt: "2024-11-28",
    updatedAt: "2024-12-10",
  },
];

export const initialVitalSigns: VitalSign[] = [
  {
    id: "vs-001",
    patientId: "patient-001",
    type: "blood_pressure",
    value: "120/80",
    unit: "mmHg",
    recordedAt: "2024-12-10T09:00:00",
    notes: "Morning reading, before breakfast",
  },
  {
    id: "vs-002",
    patientId: "patient-001",
    type: "blood_glucose",
    value: "95",
    unit: "mg/dL",
    recordedAt: "2024-12-10T08:30:00",
    notes: "Fasting glucose",
  },
  {
    id: "vs-003",
    patientId: "patient-001",
    type: "blood_pressure",
    value: "118/78",
    unit: "mmHg",
    recordedAt: "2024-12-11T09:15:00",
  },
  {
    id: "vs-004",
    patientId: "patient-001",
    type: "blood_glucose",
    value: "102",
    unit: "mg/dL",
    recordedAt: "2024-12-11T08:45:00",
    notes: "After light snack",
  },
  {
    id: "vs-005",
    patientId: "patient-001",
    type: "heart_rate",
    value: "72",
    unit: "bpm",
    recordedAt: "2024-12-12T10:00:00",
  },
];

export const vitalSignTypes = [
  { type: "blood_pressure", label: "Blood Pressure", unit: "mmHg", placeholder: "120/80" },
  { type: "blood_glucose", label: "Blood Glucose", unit: "mg/dL", placeholder: "100" },
  { type: "heart_rate", label: "Heart Rate", unit: "bpm", placeholder: "72" },
  { type: "weight", label: "Weight", unit: "kg", placeholder: "70" },
  { type: "temperature", label: "Temperature", unit: "°C", placeholder: "36.5" },
] as const;
