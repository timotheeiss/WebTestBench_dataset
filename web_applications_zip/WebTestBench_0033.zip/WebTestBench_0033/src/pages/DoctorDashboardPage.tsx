import { useState } from "react";
import { Users, ClipboardCheck, TrendingUp, Plus, X, Edit2 } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TaskList } from "@/components/followup/TaskList";
import { VitalSignHistory } from "@/components/followup/VitalSignHistory";
import { useApp } from "@/context/AppContext";
import { doctors } from "@/data/doctors";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

export default function DoctorDashboardPage() {
  const { followUpPlans, vitalSigns, addTaskToPlan, removeTaskFromPlan } = useApp();
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const [newTaskFrequency, setNewTaskFrequency] = useState("");
  const [newTaskDueDate, setNewTaskDueDate] = useState("");
  const [isAddingTask, setIsAddingTask] = useState(false);

  const totalPatients = new Set(followUpPlans.map((p) => p.patientName)).size;
  const totalTasks = followUpPlans.reduce((acc, plan) => acc + plan.tasks.length, 0);
  const completedTasks = followUpPlans.reduce(
    (acc, plan) => acc + plan.tasks.filter((t) => t.status === "completed").length,
    0
  );
  const overallCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const getDoctorName = (doctorId: string) => {
    const doctor = doctors.find((d) => d.id === doctorId);
    return doctor?.name || "Unknown Doctor";
  };

  const getPatientCompletionRate = (plan: typeof followUpPlans[0]) => {
    const total = plan.tasks.length;
    const completed = plan.tasks.filter((t) => t.status === "completed").length;
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };

  const handleAddTask = () => {
    if (!selectedPlanId || !newTaskDescription || !newTaskFrequency || !newTaskDueDate) {
      toast.error("Please fill in all fields");
      return;
    }

    addTaskToPlan(selectedPlanId, {
      description: newTaskDescription,
      frequency: newTaskFrequency,
      dueDate: newTaskDueDate,
    });

    setNewTaskDescription("");
    setNewTaskFrequency("");
    setNewTaskDueDate("");
    setIsAddingTask(false);
    toast.success("Task added to follow-up plan");
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Doctor Dashboard</h1>
          <p className="text-muted-foreground mt-1">Monitor patient progress and manage follow-up plans</p>
        </div>

        {/* Stats Overview */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Patients</p>
                  <p className="text-2xl font-bold">{totalPatients}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-green-500/10">
                  <ClipboardCheck className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tasks Completed</p>
                  <p className="text-2xl font-bold">{completedTasks} / {totalTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-coral/10">
                  <TrendingUp className="h-6 w-6 text-coral" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">Overall Compliance</p>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold">{overallCompletionRate}%</p>
                  </div>
                  <Progress value={overallCompletionRate} className="mt-2 h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Patient Follow-up Plans */}
        <div className="space-y-6">
          <h2 className="text-xl font-semibold">Patient Follow-up Plans</h2>
          
          {followUpPlans.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No follow-up plans yet</h3>
                <p className="text-muted-foreground mt-1">
                  Follow-up plans will appear here after appointments
                </p>
              </CardContent>
            </Card>
          ) : (
            followUpPlans.map((plan) => {
              const completionRate = getPatientCompletionRate(plan);
              const pendingTasks = plan.tasks.filter((t) => t.status === "pending").length;

              return (
                <Card key={plan.id}>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-lg">{plan.patientName}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          Assigned by {getDoctorName(plan.doctorId)} • Updated: {new Date(plan.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <Badge variant={pendingTasks > 0 ? "outline" : "secondary"} className={pendingTasks > 0 ? "border-amber-500 text-amber-600" : ""}>
                              {pendingTasks} pending
                            </Badge>
                            <span className="font-medium">{completionRate}%</span>
                          </div>
                          <Progress value={completionRate} className="mt-1 h-2 w-24" />
                        </div>
                        <Dialog open={isAddingTask && selectedPlanId === plan.id} onOpenChange={(open) => {
                          setIsAddingTask(open);
                          if (open) setSelectedPlanId(plan.id);
                        }}>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline">
                              <Edit2 className="h-4 w-4 mr-1" />
                              Modify Plan
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Add New Task</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4 mt-4">
                              <div className="space-y-2">
                                <Label>Task Description</Label>
                                <Input
                                  value={newTaskDescription}
                                  onChange={(e) => setNewTaskDescription(e.target.value)}
                                  placeholder="e.g., Take medication twice daily"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Frequency</Label>
                                <Input
                                  value={newTaskFrequency}
                                  onChange={(e) => setNewTaskFrequency(e.target.value)}
                                  placeholder="e.g., Daily, Twice daily, Weekly"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Due Date</Label>
                                <Input
                                  type="date"
                                  value={newTaskDueDate}
                                  onChange={(e) => setNewTaskDueDate(e.target.value)}
                                />
                              </div>
                              <Button onClick={handleAddTask} className="w-full">
                                <Plus className="h-4 w-4 mr-2" />
                                Add Task
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <TaskList
                      tasks={plan.tasks}
                      onUpdateStatus={() => {}}
                      readonly
                    />
                    
                    {/* Remove task buttons for doctor */}
                    <div className="pt-4 border-t">
                      <p className="text-sm text-muted-foreground mb-2">Remove pending tasks:</p>
                      <div className="flex flex-wrap gap-2">
                        {plan.tasks.filter(t => t.status === "pending").map((task) => (
                          <Badge
                            key={task.id}
                            variant="outline"
                            className="cursor-pointer hover:bg-destructive/10 hover:border-destructive"
                            onClick={() => {
                              removeTaskFromPlan(plan.id, task.id);
                              toast.success("Task removed from plan");
                            }}
                          >
                            {task.description.slice(0, 30)}...
                            <X className="h-3 w-3 ml-1" />
                          </Badge>
                        ))}
                        {plan.tasks.filter(t => t.status === "pending").length === 0 && (
                          <span className="text-sm text-muted-foreground">No pending tasks to remove</span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Patient Vital Signs */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Patient Vital Signs History</h2>
          <VitalSignHistory vitalSigns={vitalSigns} />
        </div>
      </div>
    </Layout>
  );
}
