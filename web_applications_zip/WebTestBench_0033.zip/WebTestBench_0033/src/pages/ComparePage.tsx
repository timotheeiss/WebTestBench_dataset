import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { useApp } from "@/context/AppContext";
import { doctors } from "@/data/doctors";
import { Link } from "react-router-dom";
import {
  Star,
  Clock,
  DollarSign,
  X,
  ArrowLeft,
  Calendar,
  GraduationCap,
  Building,
} from "lucide-react";
import { BookingModal } from "@/components/booking/BookingModal";
import { useState } from "react";
import { Doctor } from "@/data/doctors";

const ComparePage = () => {
  const { compareList, removeFromCompare, clearCompare } = useApp();
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const comparedDoctors = compareList
    .map((id) => doctors.find((d) => d.id === id))
    .filter(Boolean) as Doctor[];

  const handleBook = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setIsBookingOpen(true);
  };

  if (comparedDoctors.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto flex min-h-[60vh] flex-col items-center justify-center px-4 text-center">
          <h1 className="font-display text-2xl font-bold text-foreground">
            No doctors to compare
          </h1>
          <p className="mt-2 text-muted-foreground">
            Add doctors to your compare list from the doctors page
          </p>
          <Link to="/doctors" className="mt-6">
            <Button className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Find Doctors
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <Link
              to="/doctors"
              className="mb-2 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Doctors
            </Link>
            <h1 className="font-display text-3xl font-bold text-foreground">
              Compare Doctors
            </h1>
            <p className="mt-2 text-muted-foreground">
              Compare up to 3 doctors side by side
            </p>
          </div>
          <Button variant="outline" onClick={clearCompare}>
            Clear All
          </Button>
        </div>

        <div className="overflow-x-auto">
          <div className="inline-flex min-w-full gap-4">
            {comparedDoctors.map((doctor) => (
              <div
                key={doctor.id}
                className="w-80 shrink-0 rounded-xl border border-border bg-card shadow-sm"
              >
                {/* Header */}
                <div className="relative p-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-2 h-8 w-8"
                    onClick={() => removeFromCompare(doctor.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                  <div className="flex flex-col items-center text-center">
                    <img
                      src={doctor.avatar}
                      alt={doctor.name}
                      className="h-24 w-24 rounded-xl object-cover"
                    />
                    <h3 className="mt-4 font-display text-lg font-semibold text-foreground">
                      {doctor.name}
                    </h3>
                    <p className="text-primary">{doctor.specialty}</p>
                  </div>
                </div>

                {/* Stats */}
                <div className="border-t border-border p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Star className="h-4 w-4 text-warning" fill="currentColor" />
                        Rating
                      </span>
                      <span className="font-semibold text-foreground">
                        {doctor.rating} ({doctor.reviewCount})
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4 text-primary" />
                        Experience
                      </span>
                      <span className="font-semibold text-foreground">
                        {doctor.experience} years
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <DollarSign className="h-4 w-4 text-success" />
                        Consultation
                      </span>
                      <span className="font-semibold text-foreground">
                        ${doctor.consultationFee}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <GraduationCap className="h-4 w-4 text-primary" />
                        Education
                      </span>
                      <span className="text-right text-sm font-medium text-foreground">
                        {doctor.education.split(",")[0]}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Building className="h-4 w-4 text-primary" />
                        Hospital
                      </span>
                      <span className="text-right text-sm font-medium text-foreground">
                        {doctor.hospital}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 text-primary" />
                        Available
                      </span>
                      <span className="text-sm font-medium text-foreground">
                        {doctor.availability.join(", ")}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="border-t border-border p-4">
                  <div className="grid gap-2">
                    <Link to={`/doctor/${doctor.id}`}>
                      <Button variant="outline" className="w-full">
                        View Profile
                      </Button>
                    </Link>
                    <Button className="w-full gap-2" onClick={() => handleBook(doctor)}>
                      <Calendar className="h-4 w-4" />
                      Book Now
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedDoctor && (
        <BookingModal
          doctor={selectedDoctor}
          isOpen={isBookingOpen}
          onClose={() => {
            setIsBookingOpen(false);
            setSelectedDoctor(null);
          }}
        />
      )}
    </Layout>
  );
};

export default ComparePage;
