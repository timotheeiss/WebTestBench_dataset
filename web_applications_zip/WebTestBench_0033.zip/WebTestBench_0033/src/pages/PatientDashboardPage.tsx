import { useState } from "react";
import { ClipboardList, Activity, TrendingUp } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { TaskList } from "@/components/followup/TaskList";
import { VitalSignForm } from "@/components/followup/VitalSignForm";
import { VitalSignHistory } from "@/components/followup/VitalSignHistory";
import { useApp } from "@/context/AppContext";
import { doctors } from "@/data/doctors";

export default function PatientDashboardPage() {
  const { followUpPlans, updateTaskStatus, vitalSigns, addVitalSign } = useApp();
  const [activeTab, setActiveTab] = useState("tasks");

  const activePlans = followUpPlans.filter((plan) =>
    plan.tasks.some((task) => task.status === "pending")
  );

  const totalTasks = followUpPlans.reduce((acc, plan) => acc + plan.tasks.length, 0);
  const completedTasks = followUpPlans.reduce(
    (acc, plan) => acc + plan.tasks.filter((t) => t.status === "completed").length,
    0
  );
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const getDoctorName = (doctorId: string) => {
    const doctor = doctors.find((d) => d.id === doctorId);
    return doctor?.name || "Unknown Doctor";
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">My Health Dashboard</h1>
          <p className="text-muted-foreground mt-1">Track your follow-up tasks and vital signs</p>
        </div>

        {/* Stats Overview */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <ClipboardList className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Plans</p>
                  <p className="text-2xl font-bold">{activePlans.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-green-500/10">
                  <TrendingUp className="h-6 w-6 text-green-500" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">Task Completion</p>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold">{completionRate}%</p>
                    <span className="text-sm text-muted-foreground">
                      ({completedTasks}/{totalTasks})
                    </span>
                  </div>
                  <Progress value={completionRate} className="mt-2 h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-coral/10">
                  <Activity className="h-6 w-6 text-coral" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Vital Signs Recorded</p>
                  <p className="text-2xl font-bold">{vitalSigns.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="tasks">Follow-up Tasks</TabsTrigger>
            <TabsTrigger value="vitals">Vital Signs</TabsTrigger>
          </TabsList>

          <TabsContent value="tasks" className="space-y-6">
            {followUpPlans.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <ClipboardList className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No follow-up plans yet</h3>
                  <p className="text-muted-foreground mt-1">
                    Complete an appointment to receive follow-up instructions
                  </p>
                </CardContent>
              </Card>
            ) : (
              followUpPlans.map((plan) => (
                <Card key={plan.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Follow-up from {getDoctorName(plan.doctorId)}</span>
                      <span className="text-sm font-normal text-muted-foreground">
                        Created: {new Date(plan.createdAt).toLocaleDateString()}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <TaskList
                      tasks={plan.tasks}
                      onUpdateStatus={(taskId, status) => updateTaskStatus(plan.id, taskId, status)}
                    />
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="vitals" className="space-y-6">
            <VitalSignForm onSubmit={addVitalSign} />
            <VitalSignHistory vitalSigns={vitalSigns} />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
