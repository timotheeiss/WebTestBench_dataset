import { useParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { BookingModal } from "@/components/booking/BookingModal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { doctors } from "@/data/doctors";
import { useApp } from "@/context/AppContext";
import { useState } from "react";
import {
  Star,
  Clock,
  DollarSign,
  GraduationCap,
  Building,
  Globe,
  Calendar,
  Plus,
  Check,
  ArrowLeft,
} from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const DoctorProfilePage = () => {
  const { id } = useParams<{ id: string }>();
  const doctor = doctors.find((d) => d.id === id);
  const { compareList, addToCompare, removeFromCompare } = useApp();
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  if (!doctor) {
    return (
      <Layout>
        <div className="container mx-auto flex min-h-[60vh] flex-col items-center justify-center px-4">
          <h1 className="font-display text-2xl font-bold text-foreground">
            Doctor not found
          </h1>
          <Link to="/doctors" className="mt-4">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Doctors
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const isInCompare = compareList.includes(doctor.id);

  const handleCompareToggle = () => {
    if (isInCompare) {
      removeFromCompare(doctor.id);
    } else {
      addToCompare(doctor.id);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Back Link */}
        <Link
          to="/doctors"
          className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Doctors
        </Link>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Header Card */}
            <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
              <div className="flex flex-col gap-6 sm:flex-row">
                <img
                  src={doctor.avatar}
                  alt={doctor.name}
                  className="h-32 w-32 rounded-xl object-cover"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h1 className="font-display text-2xl font-bold text-foreground">
                        {doctor.name}
                      </h1>
                      <p className="text-lg text-primary">{doctor.specialty}</p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className={cn(
                        "gap-2",
                        isInCompare && "bg-primary/10 text-primary border-primary"
                      )}
                      onClick={handleCompareToggle}
                      disabled={compareList.length >= 3 && !isInCompare}
                    >
                      {isInCompare ? (
                        <>
                          <Check className="h-4 w-4" />
                          In Compare
                        </>
                      ) : (
                        <>
                          <Plus className="h-4 w-4" />
                          Compare
                        </>
                      )}
                    </Button>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <Clock className="h-4 w-4 text-primary" />
                      {doctor.experience} years experience
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Star className="h-4 w-4 text-warning" fill="currentColor" />
                      {doctor.rating} ({doctor.reviewCount} reviews)
                    </span>
                    <span className="flex items-center gap-1.5">
                      <DollarSign className="h-4 w-4 text-success" />
                      ${doctor.consultationFee} per consultation
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* About */}
            <div className="mt-6 rounded-xl border border-border bg-card p-6 shadow-sm">
              <h2 className="font-display text-lg font-semibold text-foreground">
                About
              </h2>
              <p className="mt-3 text-muted-foreground">{doctor.bio}</p>
            </div>

            {/* Details */}
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <GraduationCap className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Education</p>
                    <p className="font-medium text-foreground">
                      {doctor.education}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Building className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Hospital</p>
                    <p className="font-medium text-foreground">
                      {doctor.hospital}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Globe className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Languages</p>
                    <p className="font-medium text-foreground">
                      {doctor.languages.join(", ")}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Available</p>
                    <p className="font-medium text-foreground">
                      {doctor.availability.join(", ")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Conditions Treated */}
            <div className="mt-6 rounded-xl border border-border bg-card p-6 shadow-sm">
              <h2 className="font-display text-lg font-semibold text-foreground">
                Conditions Treated
              </h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {doctor.symptoms.map((symptom) => (
                  <Badge key={symptom} variant="secondary">
                    {symptom}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Booking */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 rounded-xl border border-border bg-card p-6 shadow-sm">
              <h2 className="font-display text-lg font-semibold text-foreground">
                Book Appointment
              </h2>
              <div className="mt-4 flex items-center justify-between rounded-lg bg-muted/50 p-4">
                <span className="text-muted-foreground">Consultation Fee</span>
                <span className="text-2xl font-bold text-foreground">
                  ${doctor.consultationFee}
                </span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">
                Video consultations available on {doctor.availability.join(", ")}
              </p>
              <Button
                size="lg"
                className="mt-6 w-full gap-2"
                onClick={() => setIsBookingOpen(true)}
              >
                <Calendar className="h-5 w-5" />
                Book Now
              </Button>
            </div>
          </div>
        </div>
      </div>

      <BookingModal
        doctor={doctor}
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
      />
    </Layout>
  );
};

export default DoctorProfilePage;
