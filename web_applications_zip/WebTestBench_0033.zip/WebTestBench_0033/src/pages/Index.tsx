import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Layout } from "@/components/layout/Layout";
import {
  Search,
  Calendar,
  Shield,
  Clock,
  Star,
  ArrowRight,
  Heart,
  Stethoscope,
  Brain,
  Bone,
  Baby,
  Eye,
} from "lucide-react";
import { specialties, doctors } from "@/data/doctors";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const features = [
  {
    icon: Calendar,
    title: "Easy Scheduling",
    description: "Book appointments online 24/7 with instant confirmation",
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your health data is protected with enterprise-grade security",
  },
  {
    icon: Clock,
    title: "No Wait Times",
    description: "See a doctor within minutes, not weeks",
  },
  {
    icon: Star,
    title: "Top Doctors",
    description: "Access to verified specialists across all specialties",
  },
];

const specialtyIcons: Record<string, React.ElementType> = {
  Cardiologist: Heart,
  "General Physician": Stethoscope,
  Neurologist: Brain,
  Orthopedic: Bone,
  Pediatrician: Baby,
  Ophthalmologist: Eye,
};

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/doctors?search=${encodeURIComponent(searchQuery)}`);
  };

  const topDoctors = doctors.slice(0, 4);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background py-20 lg:py-28">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center">
            <Badge
              variant="secondary"
              className="mb-6 bg-primary/10 text-primary"
            >
              Trusted by 50,000+ patients
            </Badge>
            <h1 className="font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Quality Healthcare,{" "}
              <span className="text-gradient">Anywhere</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground lg:text-xl">
              Connect with top doctors online. Book appointments, get
              consultations, and receive personalized care from the comfort of
              your home.
            </p>

            {/* Search Bar */}
            <form
              onSubmit={handleSearch}
              className="mx-auto mt-10 flex max-w-xl gap-2"
            >
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search doctors, specialties, or symptoms..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-14 pl-12 text-base"
                />
              </div>
              <Button type="submit" size="lg" className="h-14 px-8">
                Search
              </Button>
            </form>

            {/* Quick Links */}
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <span className="text-sm text-muted-foreground">Popular:</span>
              {["Fever", "Anxiety", "Skin Rash", "Headache"].map((symptom) => (
                <Link key={symptom} to={`/doctors?symptom=${symptom}`}>
                  <Badge
                    variant="outline"
                    className="cursor-pointer transition-colors hover:bg-primary/10 hover:text-primary hover:border-primary"
                  >
                    {symptom}
                  </Badge>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-accent/5 blur-3xl" />
      </section>

      {/* Features */}
      <section className="py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="group rounded-xl border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:shadow-primary/5"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary">
                  <feature.icon className="h-6 w-6 text-primary transition-colors group-hover:text-primary-foreground" />
                </div>
                <h3 className="font-display text-lg font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specialties */}
      <section className="bg-muted/30 py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="mb-10 text-center">
            <h2 className="font-display text-3xl font-bold text-foreground">
              Browse by Specialty
            </h2>
            <p className="mt-2 text-muted-foreground">
              Find the right specialist for your health needs
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
            {specialties.slice(0, 10).map((specialty) => {
              const Icon = specialtyIcons[specialty] || Stethoscope;
              return (
                <Link
                  key={specialty}
                  to={`/doctors?specialty=${encodeURIComponent(specialty)}`}
                  className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-md hover:shadow-primary/5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 transition-colors group-hover:bg-primary">
                    <Icon className="h-5 w-5 text-primary transition-colors group-hover:text-primary-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {specialty}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Top Doctors */}
      <section className="py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <h2 className="font-display text-3xl font-bold text-foreground">
                Top-Rated Doctors
              </h2>
              <p className="mt-2 text-muted-foreground">
                Highly recommended by our patients
              </p>
            </div>
            <Link to="/doctors">
              <Button variant="outline" className="hidden gap-2 sm:flex">
                View All Doctors
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {topDoctors.map((doctor) => (
              <Link
                key={doctor.id}
                to={`/doctor/${doctor.id}`}
                className="group overflow-hidden rounded-xl border border-border bg-card shadow-sm transition-all duration-300 hover:shadow-lg hover:shadow-primary/5"
              >
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={doctor.avatar}
                    alt={doctor.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="font-display text-lg font-semibold text-primary-foreground">
                      {doctor.name}
                    </h3>
                    <p className="text-sm text-primary-foreground/80">
                      {doctor.specialty}
                    </p>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Star
                        className="h-4 w-4 text-warning"
                        fill="currentColor"
                      />
                      <span className="font-medium text-foreground">
                        {doctor.rating}
                      </span>
                      <span>({doctor.reviewCount})</span>
                    </div>
                    <span className="font-semibold text-primary">
                      ${doctor.consultationFee}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Link to="/doctors">
              <Button variant="outline" className="gap-2">
                View All Doctors
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="relative overflow-hidden rounded-2xl bg-primary p-8 text-center lg:p-16">
            <h2 className="font-display text-3xl font-bold text-primary-foreground lg:text-4xl">
              Ready to Get Started?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-primary-foreground/80">
              Book your first consultation today and experience healthcare that
              fits your schedule.
            </p>
            <Link to="/doctors">
              <Button
                size="lg"
                variant="secondary"
                className="mt-8 gap-2"
              >
                Find a Doctor
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>

            {/* Decorative */}
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-primary-foreground/10 blur-2xl" />
            <div className="absolute -bottom-10 -right-10 h-40 w-40 rounded-full bg-primary-foreground/10 blur-2xl" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Heart
                  className="h-4 w-4 text-primary-foreground"
                  fill="currentColor"
                />
              </div>
              <span className="font-display font-semibold text-foreground">
                MediCare
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 MediCare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </Layout>
  );
};

export default Index;
