import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { DoctorCard } from "@/components/doctors/DoctorCard";
import { SearchFilters } from "@/components/doctors/SearchFilters";
import { BookingModal } from "@/components/booking/BookingModal";
import { doctors, Doctor } from "@/data/doctors";
import { Users } from "lucide-react";

const DoctorsPage = () => {
  const [searchParams] = useSearchParams();
  const initialSearch = searchParams.get("search") || "";
  const initialSpecialty = searchParams.get("specialty") || "";
  const initialSymptom = searchParams.get("symptom") || "";

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedSpecialty, setSelectedSpecialty] = useState(initialSpecialty);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(
    initialSymptom ? [initialSymptom] : []
  );
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const filteredDoctors = useMemo(() => {
    return doctors.filter((doctor) => {
      // Search query filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesName = doctor.name.toLowerCase().includes(query);
        const matchesSpecialty = doctor.specialty.toLowerCase().includes(query);
        const matchesSymptoms = doctor.symptoms.some((s) =>
          s.toLowerCase().includes(query)
        );
        if (!matchesName && !matchesSpecialty && !matchesSymptoms) {
          return false;
        }
      }

      // Specialty filter
      if (selectedSpecialty && selectedSpecialty !== "all") {
        if (doctor.specialty !== selectedSpecialty) {
          return false;
        }
      }

      // Symptoms filter
      if (selectedSymptoms.length > 0) {
        const hasMatchingSymptom = selectedSymptoms.some((symptom) =>
          doctor.symptoms.some(
            (s) => s.toLowerCase() === symptom.toLowerCase()
          )
        );
        if (!hasMatchingSymptom) {
          return false;
        }
      }

      return true;
    });
  }, [searchQuery, selectedSpecialty, selectedSymptoms]);

  const handleBook = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setIsBookingOpen(true);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground">
            Find a Doctor
          </h1>
          <p className="mt-2 text-muted-foreground">
            Search from our network of qualified healthcare professionals
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-4">
          {/* Sidebar Filters */}
          <aside className="lg:col-span-1">
            <SearchFilters
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedSpecialty={selectedSpecialty}
              setSelectedSpecialty={setSelectedSpecialty}
              selectedSymptoms={selectedSymptoms}
              setSelectedSymptoms={setSelectedSymptoms}
            />
          </aside>

          {/* Results */}
          <div className="lg:col-span-3">
            <div className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{filteredDoctors.length} doctors found</span>
            </div>

            {filteredDoctors.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2">
                {filteredDoctors.map((doctor) => (
                  <DoctorCard
                    key={doctor.id}
                    doctor={doctor}
                    onBook={() => handleBook(doctor)}
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card py-16 text-center">
                <Users className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="font-display text-lg font-semibold text-foreground">
                  No doctors found
                </h3>
                <p className="mt-2 text-muted-foreground">
                  Try adjusting your filters or search query
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedDoctor && (
        <BookingModal
          doctor={selectedDoctor}
          isOpen={isBookingOpen}
          onClose={() => {
            setIsBookingOpen(false);
            setSelectedDoctor(null);
          }}
        />
      )}
    </Layout>
  );
};

export default DoctorsPage;
