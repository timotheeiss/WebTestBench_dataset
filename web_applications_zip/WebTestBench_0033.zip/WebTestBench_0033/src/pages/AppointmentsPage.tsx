import { Layout } from "@/components/layout/Layout";
import { AppointmentCard } from "@/components/appointments/AppointmentCard";
import { useApp } from "@/context/AppContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, CheckCircle, XCircle, Clock } from "lucide-react";

const AppointmentsPage = () => {
  const { appointments } = useApp();

  const upcomingAppointments = appointments.filter(
    (apt) => apt.status === "upcoming"
  );
  const completedAppointments = appointments.filter(
    (apt) => apt.status === "completed"
  );
  const cancelledAppointments = appointments.filter(
    (apt) => apt.status === "cancelled"
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground">
            My Appointments
          </h1>
          <p className="mt-2 text-muted-foreground">
            View and manage your healthcare appointments
          </p>
        </div>

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="mb-6 grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="upcoming" className="gap-2">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">Upcoming</span>
              <span className="inline sm:hidden">Soon</span>
              {upcomingAppointments.length > 0 && (
                <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                  {upcomingAppointments.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="completed" className="gap-2">
              <CheckCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Completed</span>
              <span className="inline sm:hidden">Done</span>
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="gap-2">
              <XCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Cancelled</span>
              <span className="inline sm:hidden">Cancelled</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <AppointmentCard
                    key={appointment.id}
                    appointment={appointment}
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Clock}
                title="No upcoming appointments"
                description="Book an appointment with a doctor to get started"
              />
            )}
          </TabsContent>

          <TabsContent value="completed">
            {completedAppointments.length > 0 ? (
              <div className="space-y-4">
                {completedAppointments.map((appointment) => (
                  <AppointmentCard
                    key={appointment.id}
                    appointment={appointment}
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={CheckCircle}
                title="No completed appointments"
                description="Your completed consultations will appear here"
              />
            )}
          </TabsContent>

          <TabsContent value="cancelled">
            {cancelledAppointments.length > 0 ? (
              <div className="space-y-4">
                {cancelledAppointments.map((appointment) => (
                  <AppointmentCard
                    key={appointment.id}
                    appointment={appointment}
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={XCircle}
                title="No cancelled appointments"
                description="Cancelled appointments will appear here"
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

interface EmptyStateProps {
  icon: React.ElementType;
  title: string;
  description: string;
}

function EmptyState({ icon: Icon, title, description }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card py-16 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
        <Icon className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="font-display text-lg font-semibold text-foreground">
        {title}
      </h3>
      <p className="mt-2 text-muted-foreground">{description}</p>
    </div>
  );
}

export default AppointmentsPage;
