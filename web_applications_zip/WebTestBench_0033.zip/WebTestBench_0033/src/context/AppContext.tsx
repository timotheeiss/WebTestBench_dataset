import React, { createContext, useContext, useState, ReactNode } from "react";
import { Appointment, initialAppointments } from "@/data/appointments";
import { FollowUpPlan, VitalSign, TaskStatus, initialFollowUpPlans, initialVitalSigns } from "@/data/followup";

interface AppContextType {
  appointments: Appointment[];
  addAppointment: (appointment: Appointment) => void;
  cancelAppointment: (appointmentId: string) => void;
  compareList: string[];
  addToCompare: (doctorId: string) => void;
  removeFromCompare: (doctorId: string) => void;
  clearCompare: () => void;
  followUpPlans: FollowUpPlan[];
  updateTaskStatus: (planId: string, taskId: string, status: TaskStatus) => void;
  addTaskToPlan: (planId: string, task: { description: string; frequency: string; dueDate: string }) => void;
  removeTaskFromPlan: (planId: string, taskId: string) => void;
  vitalSigns: VitalSign[];
  addVitalSign: (vitalSign: Omit<VitalSign, "id">) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [followUpPlans, setFollowUpPlans] = useState<FollowUpPlan[]>(initialFollowUpPlans);
  const [vitalSigns, setVitalSigns] = useState<VitalSign[]>(initialVitalSigns);

  const addAppointment = (appointment: Appointment) => {
    setAppointments((prev) => [...prev, appointment]);
  };

  const cancelAppointment = (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === appointmentId
          ? { ...apt, status: "cancelled" as const, paymentStatus: "refunded" as const }
          : apt
      )
    );
  };

  const addToCompare = (doctorId: string) => {
    if (compareList.length < 3 && !compareList.includes(doctorId)) {
      setCompareList((prev) => [...prev, doctorId]);
    }
  };

  const removeFromCompare = (doctorId: string) => {
    setCompareList((prev) => prev.filter((id) => id !== doctorId));
  };

  const clearCompare = () => {
    setCompareList([]);
  };

  const updateTaskStatus = (planId: string, taskId: string, status: TaskStatus) => {
    setFollowUpPlans((prev) =>
      prev.map((plan) =>
        plan.id === planId
          ? {
              ...plan,
              tasks: plan.tasks.map((task) =>
                task.id === taskId
                  ? { ...task, status, completedAt: status === "completed" ? new Date().toISOString().split("T")[0] : undefined }
                  : task
              ),
              updatedAt: new Date().toISOString().split("T")[0],
            }
          : plan
      )
    );
  };

  const addTaskToPlan = (planId: string, taskData: { description: string; frequency: string; dueDate: string }) => {
    setFollowUpPlans((prev) =>
      prev.map((plan) =>
        plan.id === planId
          ? {
              ...plan,
              tasks: [
                ...plan.tasks,
                {
                  id: `task-${Date.now()}`,
                  appointmentId: plan.appointmentId,
                  description: taskData.description,
                  frequency: taskData.frequency,
                  status: "pending" as TaskStatus,
                  dueDate: taskData.dueDate,
                },
              ],
              updatedAt: new Date().toISOString().split("T")[0],
            }
          : plan
      )
    );
  };

  const removeTaskFromPlan = (planId: string, taskId: string) => {
    setFollowUpPlans((prev) =>
      prev.map((plan) =>
        plan.id === planId
          ? {
              ...plan,
              tasks: plan.tasks.filter((task) => task.id !== taskId),
              updatedAt: new Date().toISOString().split("T")[0],
            }
          : plan
      )
    );
  };

  const addVitalSign = (vitalSign: Omit<VitalSign, "id">) => {
    const newVitalSign: VitalSign = {
      ...vitalSign,
      id: `vs-${Date.now()}`,
    };
    setVitalSigns((prev) => [...prev, newVitalSign]);
  };

  return (
    <AppContext.Provider
      value={{
        appointments,
        addAppointment,
        cancelAppointment,
        compareList,
        addToCompare,
        removeFromCompare,
        clearCompare,
        followUpPlans,
        updateTaskStatus,
        addTaskToPlan,
        removeTaskFromPlan,
        vitalSigns,
        addVitalSign,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
