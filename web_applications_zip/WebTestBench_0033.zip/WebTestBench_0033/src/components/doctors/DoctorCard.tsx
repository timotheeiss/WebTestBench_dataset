import { Doctor } from "@/data/doctors";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, DollarSign, Plus, Check, Calendar } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface DoctorCardProps {
  doctor: Doctor;
  onBook?: () => void;
}

export function DoctorCard({ doctor, onBook }: DoctorCardProps) {
  const { compareList, addToCompare, removeFromCompare } = useApp();
  const isInCompare = compareList.includes(doctor.id);

  const handleCompareToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isInCompare) {
      removeFromCompare(doctor.id);
    } else {
      addToCompare(doctor.id);
    }
  };

  return (
    <div className="group relative overflow-hidden rounded-xl border border-border bg-card p-5 shadow-sm transition-all duration-300 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex gap-4">
        {/* Avatar */}
        <div className="relative">
          <img
            src={doctor.avatar}
            alt={doctor.name}
            className="h-20 w-20 rounded-xl object-cover"
          />
          <div className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-success text-[10px] font-semibold text-success-foreground">
            {doctor.rating}
          </div>
        </div>

        {/* Info */}
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <Link
                to={`/doctor/${doctor.id}`}
                className="font-display text-lg font-semibold text-foreground transition-colors hover:text-primary"
              >
                {doctor.name}
              </Link>
              <p className="text-sm text-primary">{doctor.specialty}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                "h-8 w-8 shrink-0",
                isInCompare && "bg-primary/10 text-primary"
              )}
              onClick={handleCompareToggle}
              disabled={compareList.length >= 3 && !isInCompare}
            >
              {isInCompare ? (
                <Check className="h-4 w-4" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
            </Button>
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {doctor.experience} yrs
            </span>
            <span className="flex items-center gap-1">
              <Star className="h-3.5 w-3.5 text-warning" fill="currentColor" />
              {doctor.rating} ({doctor.reviewCount})
            </span>
            <span className="flex items-center gap-1">
              <DollarSign className="h-3.5 w-3.5" />
              ${doctor.consultationFee}
            </span>
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {doctor.availability.slice(0, 3).map((day) => (
              <Badge
                key={day}
                variant="secondary"
                className="text-xs font-normal"
              >
                {day}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-4 flex gap-2">
        <Link to={`/doctor/${doctor.id}`} className="flex-1">
          <Button variant="outline" className="w-full">
            View Profile
          </Button>
        </Link>
        <Button onClick={onBook} className="flex-1 gap-2">
          <Calendar className="h-4 w-4" />
          Book Now
        </Button>
      </div>
    </div>
  );
}
