import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, X, SlidersHorizontal } from "lucide-react";
import { specialties, commonSymptoms } from "@/data/doctors";
import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SearchFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedSpecialty: string;
  setSelectedSpecialty: (specialty: string) => void;
  selectedSymptoms: string[];
  setSelectedSymptoms: (symptoms: string[]) => void;
}

export function SearchFilters({
  searchQuery,
  setSearchQuery,
  selectedSpecialty,
  setSelectedSpecialty,
  selectedSymptoms,
  setSelectedSymptoms,
}: SearchFiltersProps) {
  const toggleSymptom = (symptom: string) => {
    if (selectedSymptoms.includes(symptom)) {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== symptom));
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
    }
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedSpecialty("");
    setSelectedSymptoms([]);
  };

  const hasFilters =
    searchQuery || selectedSpecialty || selectedSymptoms.length > 0;

  return (
    <div className="space-y-4 rounded-xl border border-border bg-card p-5">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search doctors by name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Specialty Select */}
      <div>
        <label className="mb-2 block text-sm font-medium text-foreground">
          Specialty
        </label>
        <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
          <SelectTrigger>
            <SelectValue placeholder="All Specialties" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Specialties</SelectItem>
            {specialties.map((specialty) => (
              <SelectItem key={specialty} value={specialty}>
                {specialty}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Symptoms */}
      <div>
        <label className="mb-2 block text-sm font-medium text-foreground">
          Symptoms
        </label>
        <div className="flex flex-wrap gap-2">
          {commonSymptoms.map((symptom) => (
            <Badge
              key={symptom}
              variant={selectedSymptoms.includes(symptom) ? "default" : "outline"}
              className={cn(
                "cursor-pointer transition-colors",
                selectedSymptoms.includes(symptom)
                  ? "bg-primary hover:bg-primary/90"
                  : "hover:bg-primary/10 hover:text-primary hover:border-primary"
              )}
              onClick={() => toggleSymptom(symptom)}
            >
              {symptom}
            </Badge>
          ))}
        </div>
      </div>

      {/* Clear Filters */}
      {hasFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={clearFilters}
          className="w-full gap-2 text-muted-foreground"
        >
          <X className="h-4 w-4" />
          Clear all filters
        </Button>
      )}
    </div>
  );
}
