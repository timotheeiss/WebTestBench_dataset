import { Check, Clock, SkipForward } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FollowUpTask, TaskStatus } from "@/data/followup";

interface TaskListProps {
  tasks: FollowUpTask[];
  onUpdateStatus: (taskId: string, status: TaskStatus) => void;
  readonly?: boolean;
}

export function TaskList({ tasks, onUpdateStatus, readonly = false }: TaskListProps) {
  const getStatusBadge = (status: TaskStatus) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500/10 text-green-600 border-green-500/20">Completed</Badge>;
      case "skipped":
        return <Badge variant="secondary">Skipped</Badge>;
      default:
        return <Badge variant="outline" className="border-amber-500/50 text-amber-600">Pending</Badge>;
    }
  };

  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case "completed":
        return <Check className="h-5 w-5 text-green-500" />;
      case "skipped":
        return <SkipForward className="h-5 w-5 text-muted-foreground" />;
      default:
        return <Clock className="h-5 w-5 text-amber-500" />;
    }
  };

  return (
    <div className="space-y-3">
      {tasks.map((task) => (
        <Card key={task.id} className={`transition-all ${task.status === "completed" ? "bg-green-50/50 dark:bg-green-950/20" : ""}`}>
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <div className="mt-0.5">{getStatusIcon(task.status)}</div>
              <div className="flex-1 min-w-0">
                <p className={`font-medium ${task.status === "completed" ? "line-through text-muted-foreground" : ""}`}>
                  {task.description}
                </p>
                <div className="flex flex-wrap items-center gap-2 mt-2 text-sm text-muted-foreground">
                  <span>{task.frequency}</span>
                  <span>•</span>
                  <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                  {task.completedAt && (
                    <>
                      <span>•</span>
                      <span className="text-green-600">Completed: {new Date(task.completedAt).toLocaleDateString()}</span>
                    </>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusBadge(task.status)}
                {!readonly && task.status === "pending" && (
                  <div className="flex gap-1 ml-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 px-2"
                      onClick={() => onUpdateStatus(task.id, "completed")}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 px-2"
                      onClick={() => onUpdateStatus(task.id, "skipped")}
                    >
                      <SkipForward className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
