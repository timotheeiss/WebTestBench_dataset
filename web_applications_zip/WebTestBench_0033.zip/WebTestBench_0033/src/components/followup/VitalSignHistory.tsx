import { Activity, Heart, Thermometer, Scale, Droplet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { VitalSign } from "@/data/followup";

interface VitalSignHistoryProps {
  vitalSigns: VitalSign[];
}

const getVitalIcon = (type: VitalSign["type"]) => {
  switch (type) {
    case "blood_pressure":
      return <Activity className="h-4 w-4" />;
    case "blood_glucose":
      return <Droplet className="h-4 w-4" />;
    case "heart_rate":
      return <Heart className="h-4 w-4" />;
    case "weight":
      return <Scale className="h-4 w-4" />;
    case "temperature":
      return <Thermometer className="h-4 w-4" />;
  }
};

const getVitalLabel = (type: VitalSign["type"]) => {
  switch (type) {
    case "blood_pressure":
      return "Blood Pressure";
    case "blood_glucose":
      return "Blood Glucose";
    case "heart_rate":
      return "Heart Rate";
    case "weight":
      return "Weight";
    case "temperature":
      return "Temperature";
  }
};

export function VitalSignHistory({ vitalSigns }: VitalSignHistoryProps) {
  const sortedVitals = [...vitalSigns].sort(
    (a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime()
  );

  if (sortedVitals.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          No vital signs recorded yet. Start by adding your first measurement above.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Measurements</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {sortedVitals.map((vital) => (
            <div
              key={vital.id}
              className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <div className="p-2 rounded-full bg-primary/10 text-primary">
                {getVitalIcon(vital.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{getVitalLabel(vital.type)}</span>
                  <Badge variant="secondary" className="font-mono">
                    {vital.value} {vital.unit}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {new Date(vital.recordedAt).toLocaleString()}
                </p>
                {vital.notes && (
                  <p className="text-sm text-muted-foreground mt-1 italic">
                    "{vital.notes}"
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
