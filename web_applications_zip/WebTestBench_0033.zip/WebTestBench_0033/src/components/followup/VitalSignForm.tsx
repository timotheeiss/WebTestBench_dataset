import { useState } from "react";
import { Activity, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { vitalSignTypes, VitalSign } from "@/data/followup";
import { toast } from "sonner";

interface VitalSignFormProps {
  onSubmit: (vitalSign: Omit<VitalSign, "id">) => void;
}

export function VitalSignForm({ onSubmit }: VitalSignFormProps) {
  const [selectedType, setSelectedType] = useState<string>("");
  const [value, setValue] = useState("");
  const [notes, setNotes] = useState("");

  const selectedVitalType = vitalSignTypes.find((v) => v.type === selectedType);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedType || !value) {
      toast.error("Please fill in all required fields");
      return;
    }

    const vitalSign: Omit<VitalSign, "id"> = {
      patientId: "patient-001",
      type: selectedType as VitalSign["type"],
      value,
      unit: selectedVitalType?.unit || "",
      recordedAt: new Date().toISOString(),
      notes: notes || undefined,
    };

    onSubmit(vitalSign);
    setValue("");
    setNotes("");
    setSelectedType("");
    toast.success("Vital sign recorded successfully");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Activity className="h-5 w-5 text-primary" />
          Record Vital Signs
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="type">Measurement Type</Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {vitalSignTypes.map((type) => (
                    <SelectItem key={type.type} value={type.type}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="value">
                Value {selectedVitalType && `(${selectedVitalType.unit})`}
              </Label>
              <Input
                id="value"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={selectedVitalType?.placeholder || "Enter value"}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any relevant notes..."
              rows={2}
            />
          </div>
          <Button type="submit" className="w-full sm:w-auto">
            <Plus className="h-4 w-4 mr-2" />
            Record Measurement
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
