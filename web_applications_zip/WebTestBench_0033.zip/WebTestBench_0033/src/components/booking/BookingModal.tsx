import { useState } from "react";
import { Doctor } from "@/data/doctors";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useApp } from "@/context/AppContext";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Clock, CreditCard, Check, Loader2 } from "lucide-react";
import { format, addDays } from "date-fns";

interface BookingModalProps {
  doctor: Doctor;
  isOpen: boolean;
  onClose: () => void;
}

const timeSlots = [
  "9:00 AM",
  "9:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "2:00 PM",
  "2:30 PM",
  "3:00 PM",
  "3:30 PM",
  "4:00 PM",
  "4:30 PM",
];

export function BookingModal({ doctor, isOpen, onClose }: BookingModalProps) {
  const { addAppointment } = useApp();
  const { toast } = useToast();

  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  // Generate available dates (next 14 days)
  const availableDates = Array.from({ length: 14 }, (_, i) => {
    const date = addDays(new Date(), i + 1);
    const dayName = format(date, "EEE");
    if (doctor.availability.includes(dayName)) {
      return {
        value: format(date, "yyyy-MM-dd"),
        label: format(date, "EEE, MMM d"),
      };
    }
    return null;
  }).filter(Boolean) as { value: string; label: string }[];

  const handlePayment = async () => {
    if (!cardNumber || cardNumber.length < 16) {
      toast({
        title: "Invalid card",
        description: "Please enter a valid card number",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const newAppointment = {
      id: `apt-${Date.now()}`,
      doctorId: doctor.id,
      patientName: "John Doe",
      date: selectedDate,
      time: selectedTime,
      status: "upcoming" as const,
      symptoms,
      consultationFee: doctor.consultationFee,
      paymentStatus: "paid" as const,
    };

    addAppointment(newAppointment);
    setIsProcessing(false);
    setIsComplete(true);

    toast({
      title: "Appointment Booked!",
      description: `Your appointment with ${doctor.name} is confirmed.`,
    });

    setTimeout(() => {
      onClose();
      resetForm();
    }, 2000);
  };

  const resetForm = () => {
    setStep(1);
    setSelectedDate("");
    setSelectedTime("");
    setSymptoms("");
    setCardNumber("");
    setIsComplete(false);
  };

  const handleClose = () => {
    onClose();
    resetForm();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {isComplete
              ? "Booking Confirmed!"
              : step === 1
              ? "Select Date & Time"
              : step === 2
              ? "Describe Your Symptoms"
              : "Payment Details"}
          </DialogTitle>
        </DialogHeader>

        {isComplete ? (
          <div className="flex flex-col items-center py-8">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-success/10">
              <Check className="h-8 w-8 text-success" />
            </div>
            <p className="text-center text-muted-foreground">
              Your appointment with {doctor.name} has been confirmed for{" "}
              {format(new Date(selectedDate), "MMMM d, yyyy")} at {selectedTime}.
            </p>
          </div>
        ) : (
          <>
            {/* Doctor Summary */}
            <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
              <img
                src={doctor.avatar}
                alt={doctor.name}
                className="h-12 w-12 rounded-lg object-cover"
              />
              <div>
                <p className="font-medium text-foreground">{doctor.name}</p>
                <p className="text-sm text-muted-foreground">
                  {doctor.specialty}
                </p>
              </div>
              <div className="ml-auto text-right">
                <p className="font-semibold text-foreground">
                  ${doctor.consultationFee}
                </p>
                <p className="text-xs text-muted-foreground">Consultation</p>
              </div>
            </div>

            {/* Step 1: Date & Time */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <label className="mb-2 flex items-center gap-2 text-sm font-medium">
                    <Calendar className="h-4 w-4 text-primary" />
                    Select Date
                  </label>
                  <Select value={selectedDate} onValueChange={setSelectedDate}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a date" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableDates.map((date) => (
                        <SelectItem key={date.value} value={date.value}>
                          {date.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="mb-2 flex items-center gap-2 text-sm font-medium">
                    <Clock className="h-4 w-4 text-primary" />
                    Select Time
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        className="text-xs"
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={() => setStep(2)}
                  disabled={!selectedDate || !selectedTime}
                  className="w-full"
                >
                  Continue
                </Button>
              </div>
            )}

            {/* Step 2: Symptoms */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-medium">
                    Describe your symptoms
                  </label>
                  <Textarea
                    placeholder="Please describe what you're experiencing..."
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    rows={4}
                  />
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Back
                  </Button>
                  <Button
                    onClick={() => setStep(3)}
                    disabled={!symptoms.trim()}
                    className="flex-1"
                  >
                    Continue to Payment
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Payment */}
            {step === 3 && (
              <div className="space-y-4">
                <div className="rounded-lg border border-border bg-muted/30 p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      Consultation Fee
                    </span>
                    <span className="font-semibold">${doctor.consultationFee}</span>
                  </div>
                </div>

                <div>
                  <label className="mb-2 flex items-center gap-2 text-sm font-medium">
                    <CreditCard className="h-4 w-4 text-primary" />
                    Card Number
                  </label>
                  <Input
                    placeholder="1234 5678 9012 3456"
                    value={cardNumber}
                    onChange={(e) =>
                      setCardNumber(e.target.value.replace(/\D/g, "").slice(0, 16))
                    }
                  />
                  <p className="mt-1 text-xs text-muted-foreground">
                    Demo mode: Enter any 16 digits
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
                    Back
                  </Button>
                  <Button
                    onClick={handlePayment}
                    disabled={isProcessing}
                    className="flex-1 gap-2"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>Pay ${doctor.consultationFee}</>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
