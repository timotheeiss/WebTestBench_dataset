import { Appointment } from "@/data/appointments";
import { doctors } from "@/data/doctors";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useApp } from "@/context/AppContext";
import { useToast } from "@/hooks/use-toast";
import {
  Calendar,
  Clock,
  FileText,
  X,
  Video,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface AppointmentCardProps {
  appointment: Appointment;
}

export function AppointmentCard({ appointment }: AppointmentCardProps) {
  const doctor = doctors.find((d) => d.id === appointment.doctorId);
  const { cancelAppointment } = useApp();
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);

  if (!doctor) return null;

  const handleCancel = () => {
    cancelAppointment(appointment.id);
    toast({
      title: "Appointment Cancelled",
      description: "Your appointment has been cancelled and refund initiated.",
    });
  };

  const statusColors = {
    upcoming: "bg-primary/10 text-primary border-primary/20",
    completed: "bg-success/10 text-success border-success/20",
    cancelled: "bg-destructive/10 text-destructive border-destructive/20",
  };

  const paymentColors = {
    paid: "bg-success/10 text-success",
    pending: "bg-warning/10 text-warning",
    refunded: "bg-muted text-muted-foreground",
  };

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
      {/* Header */}
      <div className="p-5">
        <div className="flex items-start gap-4">
          <img
            src={doctor.avatar}
            alt={doctor.name}
            className="h-14 w-14 rounded-xl object-cover"
          />
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display font-semibold text-foreground">
                  {doctor.name}
                </h3>
                <p className="text-sm text-primary">{doctor.specialty}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={cn(
                    "capitalize",
                    statusColors[appointment.status]
                  )}
                >
                  {appointment.status}
                </Badge>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                {format(new Date(appointment.date), "MMM d, yyyy")}
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                {appointment.time}
              </span>
              <Badge
                variant="secondary"
                className={cn("font-normal", paymentColors[appointment.paymentStatus])}
              >
                ${appointment.consultationFee} • {appointment.paymentStatus}
              </Badge>
            </div>

            <p className="mt-3 text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Symptoms: </span>
              {appointment.symptoms}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-4 flex items-center gap-2">
          {appointment.status === "upcoming" && (
            <>
              <Button size="sm" className="gap-2">
                <Video className="h-4 w-4" />
                Join Consultation
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <X className="h-4 w-4" />
                    Cancel
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancel Appointment?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to cancel this appointment? A full
                      refund of ${appointment.consultationFee} will be processed.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Keep Appointment</AlertDialogCancel>
                    <AlertDialogAction onClick={handleCancel}>
                      Yes, Cancel
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}

          {appointment.status === "completed" && appointment.visitNotes && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="gap-2"
            >
              <FileText className="h-4 w-4" />
              Visit Notes
              {isExpanded ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Expanded Visit Notes */}
      {isExpanded && appointment.visitNotes && (
        <div className="border-t border-border bg-muted/30 p-5">
          <div className="space-y-4">
            <div>
              <h4 className="mb-2 font-medium text-foreground">Visit Notes</h4>
              <p className="text-sm text-muted-foreground">
                {appointment.visitNotes}
              </p>
            </div>
            {appointment.followUpInstructions && (
              <div>
                <h4 className="mb-2 font-medium text-foreground">
                  Follow-up Instructions
                </h4>
                <div className="rounded-lg bg-primary/5 p-4">
                  <pre className="whitespace-pre-wrap font-sans text-sm text-foreground">
                    {appointment.followUpInstructions}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
