import { useState, useCallback } from "react";
import { ParameterSet, Parameter, Snapshot, SnapshotValue } from "@/types/experiment";
import { defaultParameterSets, defaultSnapshots } from "@/data/defaultData";

export function useExperimentStore() {
  const [parameterSets, setParameterSets] = useState<ParameterSet[]>(defaultParameterSets);
  const [snapshots, setSnapshots] = useState<Snapshot[]>(defaultSnapshots);

  const createParameterSet = useCallback((name: string, description: string) => {
    const newSet: ParameterSet = {
      id: `ps-${Date.now()}`,
      name,
      description,
      parameters: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setParameterSets((prev) => [...prev, newSet]);
    return newSet;
  }, []);

  const updateParameterSet = useCallback(
    (id: string, updates: Partial<Pick<ParameterSet, "name" | "description">>) => {
      setParameterSets((prev) =>
        prev.map((set) =>
          set.id === id
            ? { ...set, ...updates, updatedAt: new Date() }
            : set
        )
      );
    },
    []
  );

  const deleteParameterSet = useCallback((id: string) => {
    setParameterSets((prev) => prev.filter((set) => set.id !== id));
    setSnapshots((prev) => prev.filter((snap) => snap.parameterSetId !== id));
  }, []);

  const addParameter = useCallback(
    (setId: string, parameter: Omit<Parameter, "id">) => {
      const newParam: Parameter = {
        ...parameter,
        id: `p-${Date.now()}`,
      };
      setParameterSets((prev) =>
        prev.map((set) =>
          set.id === setId
            ? {
                ...set,
                parameters: [...set.parameters, newParam],
                updatedAt: new Date(),
              }
            : set
        )
      );
      return newParam;
    },
    []
  );

  const updateParameter = useCallback(
    (setId: string, paramId: string, updates: Partial<Omit<Parameter, "id">>) => {
      setParameterSets((prev) =>
        prev.map((set) =>
          set.id === setId
            ? {
                ...set,
                parameters: set.parameters.map((param) =>
                  param.id === paramId ? { ...param, ...updates } : param
                ),
                updatedAt: new Date(),
              }
            : set
        )
      );
    },
    []
  );

  const deleteParameter = useCallback((setId: string, paramId: string) => {
    setParameterSets((prev) =>
      prev.map((set) =>
        set.id === setId
          ? {
              ...set,
              parameters: set.parameters.filter((p) => p.id !== paramId),
              updatedAt: new Date(),
            }
          : set
      )
    );
  }, []);

  const createSnapshot = useCallback(
    (setId: string, values: SnapshotValue[], notes: string) => {
      const set = parameterSets.find((s) => s.id === setId);
      if (!set) return null;

      const newSnapshot: Snapshot = {
        id: `snap-${Date.now()}`,
        parameterSetId: setId,
        parameterSetName: set.name,
        values,
        notes,
        createdAt: new Date(),
      };
      setSnapshots((prev) => [newSnapshot, ...prev]);
      return newSnapshot;
    },
    [parameterSets]
  );

  const getSnapshotsForSet = useCallback(
    (setId: string) => {
      return snapshots.filter((snap) => snap.parameterSetId === setId);
    },
    [snapshots]
  );

  const getParameterSetById = useCallback(
    (id: string) => {
      return parameterSets.find((set) => set.id === id);
    },
    [parameterSets]
  );

  return {
    parameterSets,
    snapshots,
    createParameterSet,
    updateParameterSet,
    deleteParameterSet,
    addParameter,
    updateParameter,
    deleteParameter,
    createSnapshot,
    getSnapshotsForSet,
    getParameterSetById,
  };
}
