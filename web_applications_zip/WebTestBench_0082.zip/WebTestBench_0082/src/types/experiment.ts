export interface Parameter {
  id: string;
  name: string;
  defaultValue: number;
  min: number;
  max: number;
}

export interface ParameterSet {
  id: string;
  name: string;
  description: string;
  parameters: Parameter[];
  createdAt: Date;
  updatedAt: Date;
}

export interface SnapshotValue {
  parameterId: string;
  parameterName: string;
  value: number;
}

export interface Snapshot {
  id: string;
  parameterSetId: string;
  parameterSetName: string;
  values: SnapshotValue[];
  notes: string;
  createdAt: Date;
}
