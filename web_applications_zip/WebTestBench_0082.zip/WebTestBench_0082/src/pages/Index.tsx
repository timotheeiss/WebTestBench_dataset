import { useState } from "react";
import { useExperimentStore } from "@/hooks/useExperimentStore";
import { ParameterSet, SnapshotValue } from "@/types/experiment";
import { Header } from "@/components/Header";
import { ParameterSetCard } from "@/components/ParameterSetCard";
import { CreateParameterSetDialog } from "@/components/CreateParameterSetDialog";
import { EditParameterSetDialog } from "@/components/EditParameterSetDialog";
import { RunExperimentDialog } from "@/components/RunExperimentDialog";
import { SnapshotViewer } from "@/components/SnapshotViewer";
import { DeleteConfirmDialog } from "@/components/DeleteConfirmDialog";
import { Button } from "@/components/ui/button";
import { Plus, FlaskConical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const { toast } = useToast();
  const {
    parameterSets,
    createParameterSet,
    updateParameterSet,
    deleteParameterSet,
    addParameter,
    updateParameter,
    deleteParameter,
    createSnapshot,
    getSnapshotsForSet,
  } = useExperimentStore();

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingSet, setEditingSet] = useState<ParameterSet | null>(null);
  const [runningSet, setRunningSet] = useState<ParameterSet | null>(null);
  const [viewingSnapshotsSet, setViewingSnapshotsSet] = useState<ParameterSet | null>(null);
  const [deletingSet, setDeletingSet] = useState<ParameterSet | null>(null);

  const handleCreate = (name: string, description: string) => {
    createParameterSet(name, description);
    toast({
      title: "Parameter set created",
      description: `"${name}" has been created successfully.`,
    });
  };

  const handleRun = (values: SnapshotValue[], notes: string) => {
    if (runningSet) {
      createSnapshot(runningSet.id, values, notes);
      toast({
        title: "Experiment run saved",
        description: "A snapshot of the parameter values has been recorded.",
      });
    }
  };

  const handleDelete = () => {
    if (deletingSet) {
      deleteParameterSet(deletingSet.id);
      toast({
        title: "Parameter set deleted",
        description: `"${deletingSet.name}" has been deleted.`,
      });
      setDeletingSet(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Parameter Sets</h2>
            <p className="text-muted-foreground mt-1">
              Manage experiment configurations and track runs
            </p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Set
          </Button>
        </div>

        {parameterSets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="h-20 w-20 rounded-full bg-muted flex items-center justify-center mb-6">
              <FlaskConical className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No parameter sets yet</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Create your first parameter set to start managing experiment configurations.
            </p>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Parameter Set
            </Button>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {parameterSets.map((set) => (
              <ParameterSetCard
                key={set.id}
                parameterSet={set}
                snapshotCount={getSnapshotsForSet(set.id).length}
                onEdit={() => setEditingSet(set)}
                onRun={() => setRunningSet(set)}
                onViewSnapshots={() => setViewingSnapshotsSet(set)}
                onDelete={() => setDeletingSet(set)}
              />
            ))}
          </div>
        )}
      </main>

      <CreateParameterSetDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onCreate={handleCreate}
      />

      <EditParameterSetDialog
        parameterSet={editingSet}
        open={!!editingSet}
        onOpenChange={(open) => !open && setEditingSet(null)}
        onUpdate={(updates) => editingSet && updateParameterSet(editingSet.id, updates)}
        onAddParameter={(param) => editingSet && addParameter(editingSet.id, param)}
        onUpdateParameter={(paramId, updates) =>
          editingSet && updateParameter(editingSet.id, paramId, updates)
        }
        onDeleteParameter={(paramId) => editingSet && deleteParameter(editingSet.id, paramId)}
      />

      <RunExperimentDialog
        parameterSet={runningSet}
        open={!!runningSet}
        onOpenChange={(open) => !open && setRunningSet(null)}
        onRun={handleRun}
      />

      <SnapshotViewer
        snapshots={viewingSnapshotsSet ? getSnapshotsForSet(viewingSnapshotsSet.id) : []}
        parameterSetName={viewingSnapshotsSet?.name ?? ""}
        open={!!viewingSnapshotsSet}
        onOpenChange={(open) => !open && setViewingSnapshotsSet(null)}
      />

      <DeleteConfirmDialog
        open={!!deletingSet}
        onOpenChange={(open) => !open && setDeletingSet(null)}
        onConfirm={handleDelete}
        title="Delete Parameter Set?"
        description={`This will permanently delete "${deletingSet?.name}" and all associated snapshots. This action cannot be undone.`}
      />
    </div>
  );
};

export default Index;
