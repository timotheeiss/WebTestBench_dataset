import { useState, useEffect } from "react";
import { ParameterSet, Parameter } from "@/types/experiment";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ParameterEditor } from "./ParameterEditor";
import { Settings } from "lucide-react";

interface EditParameterSetDialogProps {
  parameterSet: ParameterSet | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: (updates: Partial<Pick<ParameterSet, "name" | "description">>) => void;
  onAddParameter: (param: Omit<Parameter, "id">) => void;
  onUpdateParameter: (paramId: string, updates: Partial<Omit<Parameter, "id">>) => void;
  onDeleteParameter: (paramId: string) => void;
}

export function EditParameterSetDialog({
  parameterSet,
  open,
  onOpenChange,
  onUpdate,
  onAddParameter,
  onUpdateParameter,
  onDeleteParameter,
}: EditParameterSetDialogProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (parameterSet) {
      setName(parameterSet.name);
      setDescription(parameterSet.description);
    }
  }, [parameterSet]);

  const handleSave = () => {
    if (name.trim()) {
      onUpdate({ name: name.trim(), description: description.trim() });
    }
  };

  if (!parameterSet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            Edit Parameter Set
          </DialogTitle>
          <DialogDescription>
            Modify the parameter set configuration and its variables.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4 space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={handleSave}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                onBlur={handleSave}
                className="min-h-[60px]"
              />
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-base font-semibold">Parameters</Label>
            <ParameterEditor
              parameters={parameterSet.parameters}
              onAdd={onAddParameter}
              onUpdate={onUpdateParameter}
              onDelete={onDeleteParameter}
            />
          </div>
        </div>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
