import { useState, useEffect } from "react";
import { ParameterSet, SnapshotValue } from "@/types/experiment";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Play, RotateCcw } from "lucide-react";

interface RunExperimentDialogProps {
  parameterSet: ParameterSet | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRun: (values: SnapshotValue[], notes: string) => void;
}

export function RunExperimentDialog({
  parameterSet,
  open,
  onOpenChange,
  onRun,
}: RunExperimentDialogProps) {
  const [values, setValues] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState("");

  useEffect(() => {
    if (parameterSet) {
      const initialValues: Record<string, number> = {};
      parameterSet.parameters.forEach((param) => {
        initialValues[param.id] = param.defaultValue;
      });
      setValues(initialValues);
      setNotes("");
    }
  }, [parameterSet]);

  const handleRun = () => {
    if (!parameterSet) return;

    const snapshotValues: SnapshotValue[] = parameterSet.parameters.map((param) => ({
      parameterId: param.id,
      parameterName: param.name,
      value: values[param.id] ?? param.defaultValue,
    }));

    onRun(snapshotValues, notes);
    onOpenChange(false);
  };

  const handleReset = () => {
    if (!parameterSet) return;
    const resetValues: Record<string, number> = {};
    parameterSet.parameters.forEach((param) => {
      resetValues[param.id] = param.defaultValue;
    });
    setValues(resetValues);
  };

  if (!parameterSet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Play className="h-5 w-5 text-accent" />
            Run Experiment
          </DialogTitle>
          <DialogDescription>
            Configure parameters for <span className="font-medium">{parameterSet.name}</span> and create a snapshot.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4 space-y-6">
          {parameterSet.parameters.map((param) => (
            <div key={param.id} className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="font-mono text-sm">{param.name}</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={values[param.id] ?? param.defaultValue}
                    onChange={(e) =>
                      setValues({ ...values, [param.id]: parseFloat(e.target.value) || 0 })
                    }
                    className="w-24 font-mono text-sm text-right"
                    min={param.min}
                    max={param.max}
                    step={(param.max - param.min) / 100}
                  />
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-xs font-mono text-muted-foreground w-16 text-right">
                  {param.min}
                </span>
                <Slider
                  value={[values[param.id] ?? param.defaultValue]}
                  onValueChange={([val]) => setValues({ ...values, [param.id]: val })}
                  min={param.min}
                  max={param.max}
                  step={(param.max - param.min) / 100}
                  className="flex-1"
                />
                <span className="text-xs font-mono text-muted-foreground w-16">
                  {param.max}
                </span>
              </div>
            </div>
          ))}

          <div className="space-y-2 pt-4 border-t">
            <Label>Notes (optional)</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Describe the purpose of this experiment run..."
              className="min-h-[80px]"
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
          <Button variant="accent" onClick={handleRun}>
            <Play className="h-4 w-4 mr-2" />
            Run & Save Snapshot
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
