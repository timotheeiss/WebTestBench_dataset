import { useState } from "react";
import { Parameter } from "@/types/experiment";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, Save } from "lucide-react";

interface ParameterEditorProps {
  parameters: Parameter[];
  onAdd: (param: Omit<Parameter, "id">) => void;
  onUpdate: (id: string, updates: Partial<Omit<Parameter, "id">>) => void;
  onDelete: (id: string) => void;
}

export function ParameterEditor({
  parameters,
  onAdd,
  onUpdate,
  onDelete,
}: ParameterEditorProps) {
  const [newParam, setNewParam] = useState({
    name: "",
    defaultValue: 0,
    min: 0,
    max: 100,
  });
  const [isAdding, setIsAdding] = useState(false);

  const handleAddParameter = () => {
    if (newParam.name.trim()) {
      onAdd(newParam);
      setNewParam({ name: "", defaultValue: 0, min: 0, max: 100 });
      setIsAdding(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        {parameters.map((param, index) => (
          <div
            key={param.id}
            className="grid grid-cols-12 gap-3 items-end p-3 bg-muted/50 rounded-lg animate-fade-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="col-span-4">
              <Label className="text-xs text-muted-foreground">Name</Label>
              <Input
                value={param.name}
                onChange={(e) => onUpdate(param.id, { name: e.target.value })}
                className="font-mono text-sm"
              />
            </div>
            <div className="col-span-2">
              <Label className="text-xs text-muted-foreground">Default</Label>
              <Input
                type="number"
                value={param.defaultValue}
                onChange={(e) =>
                  onUpdate(param.id, { defaultValue: parseFloat(e.target.value) || 0 })
                }
                className="font-mono text-sm"
              />
            </div>
            <div className="col-span-2">
              <Label className="text-xs text-muted-foreground">Min</Label>
              <Input
                type="number"
                value={param.min}
                onChange={(e) =>
                  onUpdate(param.id, { min: parseFloat(e.target.value) || 0 })
                }
                className="font-mono text-sm"
              />
            </div>
            <div className="col-span-2">
              <Label className="text-xs text-muted-foreground">Max</Label>
              <Input
                type="number"
                value={param.max}
                onChange={(e) =>
                  onUpdate(param.id, { max: parseFloat(e.target.value) || 0 })
                }
                className="font-mono text-sm"
              />
            </div>
            <div className="col-span-2 flex justify-end">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onDelete(param.id)}
                className="text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {isAdding ? (
        <div className="grid grid-cols-12 gap-3 items-end p-3 border border-dashed border-primary/50 rounded-lg bg-primary/5 animate-fade-in">
          <div className="col-span-4">
            <Label className="text-xs text-muted-foreground">Name</Label>
            <Input
              value={newParam.name}
              onChange={(e) => setNewParam({ ...newParam, name: e.target.value })}
              placeholder="parameter_name"
              className="font-mono text-sm"
              autoFocus
            />
          </div>
          <div className="col-span-2">
            <Label className="text-xs text-muted-foreground">Default</Label>
            <Input
              type="number"
              value={newParam.defaultValue}
              onChange={(e) =>
                setNewParam({ ...newParam, defaultValue: parseFloat(e.target.value) || 0 })
              }
              className="font-mono text-sm"
            />
          </div>
          <div className="col-span-2">
            <Label className="text-xs text-muted-foreground">Min</Label>
            <Input
              type="number"
              value={newParam.min}
              onChange={(e) =>
                setNewParam({ ...newParam, min: parseFloat(e.target.value) || 0 })
              }
              className="font-mono text-sm"
            />
          </div>
          <div className="col-span-2">
            <Label className="text-xs text-muted-foreground">Max</Label>
            <Input
              type="number"
              value={newParam.max}
              onChange={(e) =>
                setNewParam({ ...newParam, max: parseFloat(e.target.value) || 0 })
              }
              className="font-mono text-sm"
            />
          </div>
          <div className="col-span-2 flex gap-1 justify-end">
            <Button variant="ghost" size="sm" onClick={() => setIsAdding(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleAddParameter} disabled={!newParam.name.trim()}>
              <Save className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : (
        <Button
          variant="outline"
          onClick={() => setIsAdding(true)}
          className="w-full border-dashed"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Parameter
        </Button>
      )}
    </div>
  );
}
