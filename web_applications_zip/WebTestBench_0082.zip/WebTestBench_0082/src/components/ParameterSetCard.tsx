import { ParameterSet } from "@/types/experiment";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Play, History, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ParameterSetCardProps {
  parameterSet: ParameterSet;
  snapshotCount: number;
  onEdit: () => void;
  onRun: () => void;
  onViewSnapshots: () => void;
  onDelete: () => void;
}

export function ParameterSetCard({
  parameterSet,
  snapshotCount,
  onEdit,
  onRun,
  onViewSnapshots,
  onDelete,
}: ParameterSetCardProps) {
  return (
    <Card className="group animate-fade-in hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/30">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-semibold">{parameterSet.name}</CardTitle>
            <CardDescription className="line-clamp-2">
              {parameterSet.description}
            </CardDescription>
          </div>
          <Badge variant="secondary" className="font-mono text-xs">
            {parameterSet.parameters.length} params
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {parameterSet.parameters.slice(0, 3).map((param) => (
            <div
              key={param.id}
              className="px-2 py-1 bg-muted rounded text-xs font-mono text-muted-foreground"
            >
              {param.name}
            </div>
          ))}
          {parameterSet.parameters.length > 3 && (
            <div className="px-2 py-1 bg-muted rounded text-xs text-muted-foreground">
              +{parameterSet.parameters.length - 3} more
            </div>
          )}
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Updated {formatDistanceToNow(parameterSet.updatedAt, { addSuffix: true })}</span>
          {snapshotCount > 0 && (
            <span className="flex items-center gap-1">
              <History className="h-3 w-3" />
              {snapshotCount} snapshot{snapshotCount !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="accent" size="sm" className="flex-1" onClick={onRun}>
            <Play className="h-4 w-4" />
            Run
          </Button>
          <Button variant="outline" size="sm" onClick={onEdit}>
            <Settings className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={onViewSnapshots}>
            <History className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onDelete} className="text-destructive hover:text-destructive hover:bg-destructive/10">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
