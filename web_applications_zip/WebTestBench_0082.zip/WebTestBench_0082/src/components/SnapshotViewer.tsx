import { Snapshot } from "@/types/experiment";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import { History, FileText } from "lucide-react";

interface SnapshotViewerProps {
  snapshots: Snapshot[];
  parameterSetName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SnapshotViewer({
  snapshots,
  parameterSetName,
  open,
  onOpenChange,
}: SnapshotViewerProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-accent" />
            Snapshot History
          </SheetTitle>
          <SheetDescription>
            Experiment runs for <span className="font-medium">{parameterSetName}</span>
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-8rem)] mt-6 pr-4">
          {snapshots.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <FileText className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No snapshots yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Run an experiment to create your first snapshot
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {snapshots.map((snapshot, index) => (
                <div
                  key={snapshot.id}
                  className="p-4 border rounded-lg bg-card animate-slide-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <Badge variant="outline" className="font-mono text-xs">
                        {format(snapshot.createdAt, "MMM d, yyyy")}
                      </Badge>
                      <span className="text-xs text-muted-foreground ml-2">
                        {format(snapshot.createdAt, "HH:mm")}
                      </span>
                    </div>
                  </div>

                  {snapshot.notes && (
                    <p className="text-sm text-muted-foreground mb-3 italic">
                      "{snapshot.notes}"
                    </p>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    {snapshot.values.map((val) => (
                      <div
                        key={val.parameterId}
                        className="flex items-center justify-between px-2 py-1.5 bg-muted/50 rounded text-sm"
                      >
                        <span className="font-mono text-muted-foreground truncate">
                          {val.parameterName}
                        </span>
                        <span className="font-mono font-medium ml-2">{val.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
