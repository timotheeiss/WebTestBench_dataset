import { Beaker, FlaskConical } from "lucide-react";

export function Header() {
  return (
    <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <FlaskConical className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
              ParamLab
              <Beaker className="h-4 w-4 text-accent" />
            </h1>
            <p className="text-xs text-muted-foreground">
              Experiment Parameter Management
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}
