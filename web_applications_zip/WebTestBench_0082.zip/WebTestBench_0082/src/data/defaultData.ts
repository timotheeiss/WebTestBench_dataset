import { ParameterSet, Snapshot } from "@/types/experiment";

export const defaultParameterSets: ParameterSet[] = [
  {
    id: "ps-1",
    name: "Neural Network Training",
    description: "Hyperparameters for training a deep neural network",
    parameters: [
      { id: "p-1-1", name: "learning_rate", defaultValue: 0.001, min: 0.0001, max: 0.1 },
      { id: "p-1-2", name: "batch_size", defaultValue: 32, min: 8, max: 256 },
      { id: "p-1-3", name: "epochs", defaultValue: 100, min: 10, max: 1000 },
      { id: "p-1-4", name: "dropout_rate", defaultValue: 0.2, min: 0, max: 0.8 },
    ],
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-02-10"),
  },
  {
    id: "ps-2",
    name: "Image Processing Pipeline",
    description: "Parameters for image enhancement and filtering",
    parameters: [
      { id: "p-2-1", name: "brightness", defaultValue: 1.0, min: 0.5, max: 2.0 },
      { id: "p-2-2", name: "contrast", defaultValue: 1.0, min: 0.5, max: 2.0 },
      { id: "p-2-3", name: "saturation", defaultValue: 1.0, min: 0, max: 2.0 },
      { id: "p-2-4", name: "blur_radius", defaultValue: 0, min: 0, max: 20 },
    ],
    createdAt: new Date("2024-02-01"),
    updatedAt: new Date("2024-02-20"),
  },
  {
    id: "ps-3",
    name: "Simulation Physics",
    description: "Physical constants and simulation parameters",
    parameters: [
      { id: "p-3-1", name: "gravity", defaultValue: 9.81, min: 0, max: 20 },
      { id: "p-3-2", name: "friction", defaultValue: 0.3, min: 0, max: 1 },
      { id: "p-3-3", name: "time_step", defaultValue: 0.016, min: 0.001, max: 0.1 },
      { id: "p-3-4", name: "max_velocity", defaultValue: 100, min: 10, max: 500 },
    ],
    createdAt: new Date("2024-01-20"),
    updatedAt: new Date("2024-01-25"),
  },
];

export const defaultSnapshots: Snapshot[] = [
  {
    id: "snap-1",
    parameterSetId: "ps-1",
    parameterSetName: "Neural Network Training",
    values: [
      { parameterId: "p-1-1", parameterName: "learning_rate", value: 0.0005 },
      { parameterId: "p-1-2", parameterName: "batch_size", value: 64 },
      { parameterId: "p-1-3", parameterName: "epochs", value: 150 },
      { parameterId: "p-1-4", parameterName: "dropout_rate", value: 0.3 },
    ],
    notes: "Initial training run with adjusted hyperparameters",
    createdAt: new Date("2024-02-12T10:30:00"),
  },
  {
    id: "snap-2",
    parameterSetId: "ps-1",
    parameterSetName: "Neural Network Training",
    values: [
      { parameterId: "p-1-1", parameterName: "learning_rate", value: 0.001 },
      { parameterId: "p-1-2", parameterName: "batch_size", value: 128 },
      { parameterId: "p-1-3", parameterName: "epochs", value: 200 },
      { parameterId: "p-1-4", parameterName: "dropout_rate", value: 0.25 },
    ],
    notes: "Testing larger batch size for faster convergence",
    createdAt: new Date("2024-02-14T14:15:00"),
  },
  {
    id: "snap-3",
    parameterSetId: "ps-2",
    parameterSetName: "Image Processing Pipeline",
    values: [
      { parameterId: "p-2-1", parameterName: "brightness", value: 1.2 },
      { parameterId: "p-2-2", parameterName: "contrast", value: 1.1 },
      { parameterId: "p-2-3", parameterName: "saturation", value: 1.3 },
      { parameterId: "p-2-4", parameterName: "blur_radius", value: 2 },
    ],
    notes: "Enhanced settings for outdoor photography",
    createdAt: new Date("2024-02-21T09:00:00"),
  },
];
