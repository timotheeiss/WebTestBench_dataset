import { Article, ViewMode } from '@/data/articles';
import { Clock, Calendar, ChevronRight, ExternalLink, Code2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface ArticleCardProps {
  article: Article;
  viewMode: ViewMode;
  onSelect: (article: Article) => void;
  isSelected: boolean;
}

export function ArticleCard({ article, viewMode, onSelect, isSelected }: ArticleCardProps) {
  return (
    <article
      className={`group rounded-xl border border-border bg-card p-6 transition-all duration-300 cursor-pointer
        ${isSelected ? 'ring-2 ring-primary shadow-card-hover' : 'shadow-card hover:shadow-card-hover hover:border-primary/30'}
        animate-fade-in`}
      onClick={() => onSelect(article)}
    >
      {/* Header - Always visible */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{article.icon}</span>
          <div>
            <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
              {article.title}
            </h2>
            <Badge variant="secondary" className="mt-1">
              {article.category}
            </Badge>
          </div>
        </div>
        <ChevronRight className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${isSelected ? 'rotate-90' : 'group-hover:translate-x-1'}`} />
      </div>

      {/* Meta info */}
      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
        <span className="flex items-center gap-1.5">
          <Clock className="w-4 h-4" />
          {article.readTime}
        </span>
        <span className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4" />
          {article.lastUpdated}
        </span>
      </div>

      {/* Overview Mode: Key Points */}
      {viewMode === 'overview' && (
        <div className="animate-slide-up">
          <h3 className="text-sm font-medium text-foreground mb-2">Key Points</h3>
          <ul className="space-y-1.5">
            {article.keyPoints.map((point, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                {point}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Standard Mode: Introduction + Content */}
      {viewMode === 'standard' && (
        <div className="animate-slide-up prose-docs">
          <p className="text-muted-foreground mb-4">{article.introduction}</p>
          <div className="space-y-3">
            {article.content.slice(0, 2).map((paragraph, idx) => (
              <p key={idx} className="text-sm text-muted-foreground">
                {paragraph}
              </p>
            ))}
          </div>
          {article.content.length > 2 && (
            <p className="text-sm text-primary font-medium mt-4">
              + {article.content.length - 2} more sections...
            </p>
          )}
        </div>
      )}

      {/* Detailed Mode: Full Content + Code Examples + References */}
      {viewMode === 'detailed' && (
        <div className="animate-slide-up space-y-6">
          {/* Introduction */}
          <div className="prose-docs">
            <p className="text-muted-foreground">{article.introduction}</p>
          </div>

          {/* Full Content */}
          <div className="prose-docs space-y-4">
            {article.content.map((paragraph, idx) => (
              <p key={idx} className="text-sm text-muted-foreground">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Code Examples */}
          {article.codeExamples.length > 0 && (
            <div className="space-y-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Code2 className="w-4 h-4 text-primary" />
                Code Examples
              </h3>
              {article.codeExamples.map((example, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">{example.title}</span>
                    <Badge variant="outline" className="text-xs">
                      {example.language}
                    </Badge>
                  </div>
                  <pre className="code-block text-xs">
                    <code>{example.code}</code>
                  </pre>
                </div>
              ))}
            </div>
          )}

          {/* References */}
          {article.references.length > 0 && (
            <div className="space-y-3 pt-4 border-t border-border">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <ExternalLink className="w-4 h-4 text-primary" />
                References
              </h3>
              <ul className="space-y-2">
                {article.references.map((ref, idx) => (
                  <li key={idx} className="group/link">
                    <a
                      href={ref.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary hover:underline font-medium"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {ref.title}
                    </a>
                    <p className="text-xs text-muted-foreground">{ref.description}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </article>
  );
}
