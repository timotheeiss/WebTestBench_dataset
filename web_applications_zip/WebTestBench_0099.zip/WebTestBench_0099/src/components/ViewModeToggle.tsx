import { ViewMode } from '@/data/articles';
import { Eye, FileText, BookOpen } from 'lucide-react';

interface ViewModeToggleProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
}

const modes: { value: ViewMode; label: string; icon: typeof Eye }[] = [
  { value: 'overview', label: 'Overview', icon: Eye },
  { value: 'standard', label: 'Standard', icon: FileText },
  { value: 'detailed', label: 'Detailed', icon: BookOpen },
];

export function ViewModeToggle({ viewMode, onViewModeChange }: ViewModeToggleProps) {
  return (
    <div className="view-mode-toggle">
      {modes.map((mode) => {
        const Icon = mode.icon;
        const isActive = viewMode === mode.value;
        
        return (
          <button
            key={mode.value}
            onClick={() => onViewModeChange(mode.value)}
            className={`view-mode-button flex items-center gap-2 ${
              isActive ? 'view-mode-button-active' : 'view-mode-button-inactive'
            }`}
            aria-pressed={isActive}
          >
            <Icon className="w-4 h-4" />
            <span className="hidden sm:inline">{mode.label}</span>
          </button>
        );
      })}
    </div>
  );
}
