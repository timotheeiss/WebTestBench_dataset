export type ViewMode = 'overview' | 'standard' | 'detailed';

export interface CodeExample {
  language: string;
  title: string;
  code: string;
}

export interface Reference {
  title: string;
  url: string;
  description: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  category: string;
  icon: string;
  lastUpdated: string;
  readTime: string;
  keyPoints: string[];
  introduction: string;
  content: string[];
  codeExamples: CodeExample[];
  references: Reference[];
}

export const articles: Article[] = [
  {
    id: '1',
    title: 'Understanding React Hooks',
    slug: 'react-hooks',
    category: 'React',
    icon: '⚛️',
    lastUpdated: '2024-01-15',
    readTime: '8 min',
    keyPoints: [
      'Hooks let you use state and lifecycle features in functional components',
      'useState and useEffect are the most commonly used hooks',
      'Custom hooks allow you to extract and reuse stateful logic',
      'Rules of Hooks must be followed for proper functionality'
    ],
    introduction: 'React Hooks revolutionized how we write React components by allowing functional components to have state and lifecycle methods. This guide covers the fundamentals of hooks and best practices for using them effectively.',
    content: [
      'React Hooks were introduced in React 16.8 as a way to use state and other React features without writing a class. They provide a more direct API to the React concepts you already know: props, state, context, refs, and lifecycle.',
      'The useState hook is the most fundamental hook. It returns a stateful value and a function to update it. During the initial render, the returned state is the same as the value passed as the first argument.',
      'The useEffect hook lets you perform side effects in function components. It serves the same purpose as componentDidMount, componentDidUpdate, and componentWillUnmount in React classes, but unified into a single API.',
      'Custom hooks are a mechanism to reuse stateful logic between components. When we want to share logic between two JavaScript functions, we extract it to a third function. Both components and hooks are functions, so this works for them too.'
    ],
    codeExamples: [
      {
        language: 'typescript',
        title: 'Basic useState Example',
        code: `import { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
}`
      },
      {
        language: 'typescript',
        title: 'useEffect with Cleanup',
        code: `import { useEffect, useState } from 'react';

function WindowSize() {
  const [size, setSize] = useState(window.innerWidth);

  useEffect(() => {
    const handler = () => setSize(window.innerWidth);
    window.addEventListener('resize', handler);
    
    // Cleanup function
    return () => window.removeEventListener('resize', handler);
  }, []);

  return <p>Window width: {size}px</p>;
}`
      }
    ],
    references: [
      {
        title: 'React Hooks Documentation',
        url: 'https://react.dev/reference/react',
        description: 'Official React documentation for all built-in hooks'
      },
      {
        title: 'Rules of Hooks',
        url: 'https://react.dev/warnings/invalid-hook-call-warning',
        description: 'Understanding the rules that hooks must follow'
      }
    ]
  },
  {
    id: '2',
    title: 'TypeScript Generics Deep Dive',
    slug: 'typescript-generics',
    category: 'TypeScript',
    icon: '📘',
    lastUpdated: '2024-01-12',
    readTime: '12 min',
    keyPoints: [
      'Generics enable type-safe reusable components',
      'Constraints limit what types can be used with generics',
      'Generic interfaces and classes provide flexible type definitions',
      'Utility types like Partial and Pick are built with generics'
    ],
    introduction: 'TypeScript generics provide a way to create reusable components that work with multiple types while maintaining type safety. This deep dive explores how to leverage generics effectively in your TypeScript projects.',
    content: [
      'Generics are one of the main tools in the toolbox for creating reusable components in languages like TypeScript. They allow us to create components that can work over a variety of types rather than a single one.',
      'A generic type is a way of creating a component that can work with multiple types. Instead of using any and losing type information, generics preserve the type information while still allowing flexibility.',
      'Type constraints allow you to limit the types that can be used with a generic. Using the extends keyword, you can specify that a generic type must satisfy certain requirements.',
      'Generic utility types like Partial<T>, Required<T>, Pick<T, K>, and Omit<T, K> are powerful tools built using generics. Understanding how they work helps you create your own utility types.'
    ],
    codeExamples: [
      {
        language: 'typescript',
        title: 'Generic Function',
        code: `function identity<T>(arg: T): T {
  return arg;
}

// Type is inferred
const num = identity(42);      // number
const str = identity("hello"); // string

// Explicit type
const explicit = identity<boolean>(true);`
      },
      {
        language: 'typescript',
        title: 'Generic with Constraints',
        code: `interface HasLength {
  length: number;
}

function logLength<T extends HasLength>(arg: T): T {
  console.log(arg.length);
  return arg;
}

logLength("hello");     // OK - string has length
logLength([1, 2, 3]);   // OK - array has length
// logLength(42);       // Error - number has no length`
      }
    ],
    references: [
      {
        title: 'TypeScript Handbook - Generics',
        url: 'https://www.typescriptlang.org/docs/handbook/2/generics.html',
        description: 'Official TypeScript documentation on generics'
      },
      {
        title: 'Utility Types',
        url: 'https://www.typescriptlang.org/docs/handbook/utility-types.html',
        description: 'Built-in generic utility types in TypeScript'
      }
    ]
  },
  {
    id: '3',
    title: 'CSS Grid Layout Mastery',
    slug: 'css-grid',
    category: 'CSS',
    icon: '🎨',
    lastUpdated: '2024-01-10',
    readTime: '10 min',
    keyPoints: [
      'Grid creates two-dimensional layouts with rows and columns',
      'grid-template-columns and grid-template-rows define the track structure',
      'Grid areas allow naming and placing items intuitively',
      'auto-fit and minmax() enable responsive layouts without media queries'
    ],
    introduction: 'CSS Grid Layout is a powerful two-dimensional layout system that allows you to create complex web layouts with ease. Master the fundamentals and advanced techniques to build responsive, flexible layouts.',
    content: [
      'CSS Grid Layout introduces a two-dimensional grid system to CSS. It lets you lay out content in rows and columns, and has many features that make building complex layouts straightforward.',
      'A grid container is established by setting display: grid on an element. Its direct children become grid items automatically. The container defines the grid structure using properties like grid-template-columns and grid-template-rows.',
      'Grid lines are the dividing lines that make up the structure of the grid. They can be horizontal or vertical, and you can refer to them by number or by name when placing grid items.',
      'The fr unit represents a fraction of the available space in the grid container. Using fr units allows you to create flexible grids that distribute space proportionally.'
    ],
    codeExamples: [
      {
        language: 'css',
        title: 'Basic Grid Setup',
        code: `.container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: auto;
  gap: 1rem;
}

.item {
  background: #e0e0e0;
  padding: 1rem;
}`
      },
      {
        language: 'css',
        title: 'Responsive Grid with auto-fit',
        code: `.responsive-grid {
  display: grid;
  grid-template-columns: repeat(
    auto-fit,
    minmax(250px, 1fr)
  );
  gap: 1.5rem;
}

/* Items automatically wrap and resize */`
      }
    ],
    references: [
      {
        title: 'CSS Grid Layout - MDN',
        url: 'https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout',
        description: 'Comprehensive MDN guide to CSS Grid'
      },
      {
        title: 'A Complete Guide to Grid',
        url: 'https://css-tricks.com/snippets/css/complete-guide-grid/',
        description: 'CSS-Tricks visual guide to CSS Grid properties'
      }
    ]
  },
  {
    id: '4',
    title: 'REST API Design Best Practices',
    slug: 'rest-api-design',
    category: 'API',
    icon: '🔌',
    lastUpdated: '2024-01-08',
    readTime: '15 min',
    keyPoints: [
      'Use nouns for resource names, not verbs',
      'HTTP methods convey the action (GET, POST, PUT, DELETE)',
      'Proper status codes communicate response state clearly',
      'Version your APIs to maintain backward compatibility'
    ],
    introduction: 'Designing a well-structured REST API is crucial for building maintainable and scalable applications. Learn the best practices and conventions that make APIs intuitive and developer-friendly.',
    content: [
      'REST (Representational State Transfer) is an architectural style for designing networked applications. A well-designed REST API should be intuitive, consistent, and follow established conventions.',
      'Resources are the key abstraction in REST. They should be named using nouns, not verbs. For example, use /users instead of /getUsers. The HTTP method indicates the action being performed.',
      'HTTP status codes are essential for communicating the result of an API request. Use 2xx for success, 4xx for client errors, and 5xx for server errors. Be specific with status codes to help clients handle responses appropriately.',
      'API versioning ensures backward compatibility as your API evolves. Common strategies include URL versioning (/v1/users), header versioning, and query parameter versioning.'
    ],
    codeExamples: [
      {
        language: 'plaintext',
        title: 'RESTful Endpoint Examples',
        code: `GET    /api/v1/users          # List all users
GET    /api/v1/users/123      # Get specific user
POST   /api/v1/users          # Create new user
PUT    /api/v1/users/123      # Update user
DELETE /api/v1/users/123      # Delete user

# Nested resources
GET    /api/v1/users/123/posts    # User's posts
POST   /api/v1/users/123/posts    # Create post for user`
      },
      {
        language: 'json',
        title: 'Error Response Format',
        code: `{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": [
      {
        "field": "email",
        "message": "Must be a valid email address"
      }
    ]
  }
}`
      }
    ],
    references: [
      {
        title: 'REST API Tutorial',
        url: 'https://restfulapi.net/',
        description: 'Comprehensive guide to REST API concepts'
      },
      {
        title: 'HTTP Status Codes',
        url: 'https://httpstatuses.com/',
        description: 'Complete reference for HTTP status codes'
      }
    ]
  },
  {
    id: '5',
    title: 'Git Branching Strategies',
    slug: 'git-branching',
    category: 'Git',
    icon: '🌿',
    lastUpdated: '2024-01-05',
    readTime: '7 min',
    keyPoints: [
      'Git Flow uses feature, develop, and release branches',
      'GitHub Flow is simpler with feature branches and main',
      'Trunk-based development minimizes long-lived branches',
      'Choose a strategy that fits your team size and release cycle'
    ],
    introduction: 'Choosing the right Git branching strategy is essential for team collaboration and continuous delivery. Explore different approaches and learn which one best fits your development workflow.',
    content: [
      'A Git branching strategy defines how a team uses branches to organize development work. The right strategy depends on your team size, release frequency, and deployment practices.',
      'Git Flow is a robust branching model that uses multiple long-lived branches: main, develop, feature, release, and hotfix branches. It works well for projects with scheduled releases.',
      'GitHub Flow is a simpler alternative that uses only feature branches and main. Developers create feature branches, open pull requests, and merge to main after review. This works well for continuous deployment.',
      'Trunk-based development focuses on keeping branches short-lived and merging to main frequently. This reduces merge conflicts and enables continuous integration effectively.'
    ],
    codeExamples: [
      {
        language: 'bash',
        title: 'Git Flow Commands',
        code: `# Start a new feature
git checkout develop
git checkout -b feature/user-auth

# Complete feature
git checkout develop
git merge --no-ff feature/user-auth
git branch -d feature/user-auth

# Create release
git checkout -b release/1.0.0 develop`
      },
      {
        language: 'bash',
        title: 'GitHub Flow Commands',
        code: `# Create feature branch from main
git checkout main
git pull origin main
git checkout -b feature/new-dashboard

# Push and create PR
git push -u origin feature/new-dashboard

# After PR approval and merge
git checkout main
git pull origin main
git branch -d feature/new-dashboard`
      }
    ],
    references: [
      {
        title: 'Git Flow by Vincent Driessen',
        url: 'https://nvie.com/posts/a-successful-git-branching-model/',
        description: 'The original Git Flow blog post'
      },
      {
        title: 'GitHub Flow Guide',
        url: 'https://docs.github.com/en/get-started/quickstart/github-flow',
        description: 'Official GitHub Flow documentation'
      }
    ]
  }
];

export const categories = [...new Set(articles.map(a => a.category))];
