import { useState, useMemo } from 'react';
import { Header } from '@/components/Header';
import { ArticleCard } from '@/components/ArticleCard';
import { CategoryFilter } from '@/components/CategoryFilter';
import { articles, Article } from '@/data/articles';
import { useViewMode } from '@/hooks/useViewMode';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const Index = () => {
  const { viewMode, setViewMode } = useViewMode('standard');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const filteredArticles = useMemo(() => {
    return articles.filter((article) => {
      const matchesCategory = !selectedCategory || article.category === selectedCategory;
      const matchesSearch = !searchQuery || 
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.keyPoints.some(kp => kp.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleArticleSelect = (article: Article) => {
    setSelectedArticle(selectedArticle?.id === article.id ? null : article);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header viewMode={viewMode} onViewModeChange={setViewMode} />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12 gradient-subtle rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Technical Documentation
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Explore our library of technical articles. Switch between view modes to see 
            overviews, full content, or detailed documentation with code examples.
          </p>
          
          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 rounded-full border-border bg-card shadow-card"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <CategoryFilter 
            selectedCategory={selectedCategory} 
            onCategoryChange={setSelectedCategory} 
          />
          <p className="text-sm text-muted-foreground">
            {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} found
          </p>
        </div>

        {/* Articles Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
          {filteredArticles.map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
              viewMode={viewMode}
              onSelect={handleArticleSelect}
              isSelected={selectedArticle?.id === article.id}
            />
          ))}
        </div>

        {/* Empty State */}
        {filteredArticles.length === 0 && (
          <div className="text-center py-16">
            <p className="text-lg text-muted-foreground">
              No articles found matching your criteria.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory(null);
              }}
              className="mt-4 text-primary hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}

        {/* View Mode Info */}
        <div className="mt-12 p-6 rounded-xl border border-border bg-card shadow-card">
          <h3 className="font-semibold text-foreground mb-2">About View Modes</h3>
          <div className="grid gap-4 md:grid-cols-3 text-sm text-muted-foreground">
            <div>
              <span className="font-medium text-foreground">Overview</span>
              <p>Quick scan with title and key points only.</p>
            </div>
            <div>
              <span className="font-medium text-foreground">Standard</span>
              <p>Introduction and main content for regular reading.</p>
            </div>
            <div>
              <span className="font-medium text-foreground">Detailed</span>
              <p>Full content with code examples and references.</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            💡 Your preferred view mode is saved automatically for future visits.
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>DevDocs — Your Technical Documentation Library</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
