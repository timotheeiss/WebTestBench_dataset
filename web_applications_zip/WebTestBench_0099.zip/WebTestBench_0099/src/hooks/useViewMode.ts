import { useState, useEffect } from 'react';
import { ViewMode } from '@/data/articles';

const STORAGE_KEY = 'docs-preferred-view-mode';

export function useViewMode(initialMode: ViewMode = 'standard') {
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    if (typeof window === 'undefined') return initialMode;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && ['overview', 'standard', 'detailed'].includes(stored)) {
      return stored as ViewMode;
    }
    return initialMode;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, viewMode);
  }, [viewMode]);

  return { viewMode, setViewMode };
}
