import { Link } from 'react-router-dom';
import { Heart, MapPin, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Exhibitor } from '@/data/exhibitors';
import { AreaBadge } from './AreaBadge';
import { useFavorites } from '@/contexts/FavoritesContext';
import { cn } from '@/lib/utils';

interface ExhibitorCardProps {
  exhibitor: Exhibitor;
  index?: number;
}

export function ExhibitorCard({ exhibitor, index = 0 }: ExhibitorCardProps) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const favorite = isFavorite(exhibitor.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      className="group relative bg-card rounded-xl border border-border shadow-card hover:shadow-card-hover transition-all duration-300"
    >
      <button
        onClick={(e) => {
          e.preventDefault();
          toggleFavorite(exhibitor.id);
        }}
        className={cn(
          'absolute top-4 right-4 z-10 p-2 rounded-full transition-all duration-200',
          favorite
            ? 'bg-destructive text-destructive-foreground'
            : 'bg-card/80 backdrop-blur-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10'
        )}
        aria-label={favorite ? 'Remove from favorites' : 'Add to favorites'}
      >
        <Heart className={cn('w-5 h-5', favorite && 'fill-current')} />
      </button>

      <Link to={`/exhibitor/${exhibitor.id}`} className="block p-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-16 h-16 rounded-lg bg-muted overflow-hidden">
            <img
              src={exhibitor.logo}
              alt={`${exhibitor.name} logo`}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <AreaBadge area={exhibitor.area} size="sm" />
            <h3 className="mt-2 font-display font-semibold text-lg text-foreground group-hover:text-accent transition-colors truncate">
              {exhibitor.name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-1">{exhibitor.tagline}</p>
          </div>
        </div>

        <p className="mt-4 text-sm text-muted-foreground line-clamp-2">
          {exhibitor.description}
        </p>

        <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>{exhibitor.hall} • Booth {exhibitor.booth}</span>
          </div>
          <span className="flex items-center gap-1 text-sm font-medium text-accent group-hover:gap-2 transition-all">
            View Details
            <ArrowRight className="w-4 h-4" />
          </span>
        </div>
      </Link>
    </motion.div>
  );
}
