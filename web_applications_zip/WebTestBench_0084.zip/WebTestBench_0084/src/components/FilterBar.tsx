import { Search, Filter, X } from 'lucide-react';
import { ExhibitionArea, areaLabels } from '@/data/exhibitors';
import { cn } from '@/lib/utils';

interface FilterBarProps {
  search: string;
  onSearchChange: (value: string) => void;
  selectedArea: ExhibitionArea | null;
  onAreaChange: (area: ExhibitionArea | null) => void;
}

const areaButtonStyles: Record<ExhibitionArea, { active: string; inactive: string }> = {
  electronics: {
    active: 'bg-area-electronics text-white border-area-electronics',
    inactive: 'border-area-electronics/30 text-area-electronics hover:bg-area-electronics/10',
  },
  healthcare: {
    active: 'bg-area-healthcare text-white border-area-healthcare',
    inactive: 'border-area-healthcare/30 text-area-healthcare hover:bg-area-healthcare/10',
  },
  manufacturing: {
    active: 'bg-area-manufacturing text-white border-area-manufacturing',
    inactive: 'border-area-manufacturing/30 text-area-manufacturing hover:bg-area-manufacturing/10',
  },
};

export function FilterBar({ search, onSearchChange, selectedArea, onAreaChange }: FilterBarProps) {
  const areas: ExhibitionArea[] = ['electronics', 'healthcare', 'manufacturing'];

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search exhibitors..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent transition-all"
        />
        {search && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted transition-colors"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        )}
      </div>

      {/* Area Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Filter className="w-4 h-4" />
          <span>Filter:</span>
        </div>
        <button
          onClick={() => onAreaChange(null)}
          className={cn(
            'px-4 py-2 text-sm font-medium rounded-lg border transition-all',
            selectedArea === null
              ? 'bg-primary text-primary-foreground border-primary'
              : 'border-border text-muted-foreground hover:text-foreground hover:bg-muted'
          )}
        >
          All Areas
        </button>
        {areas.map(area => (
          <button
            key={area}
            onClick={() => onAreaChange(selectedArea === area ? null : area)}
            className={cn(
              'px-4 py-2 text-sm font-medium rounded-lg border transition-all',
              selectedArea === area
                ? areaButtonStyles[area].active
                : areaButtonStyles[area].inactive
            )}
          >
            {areaLabels[area]}
          </button>
        ))}
      </div>
    </div>
  );
}
