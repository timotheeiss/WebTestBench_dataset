import { ExhibitionArea, areaLabels } from '@/data/exhibitors';
import { cn } from '@/lib/utils';

interface AreaBadgeProps {
  area: ExhibitionArea;
  size?: 'sm' | 'md';
  className?: string;
}

const areaStyles: Record<ExhibitionArea, string> = {
  electronics: 'bg-area-electronics/10 text-area-electronics border-area-electronics/20',
  healthcare: 'bg-area-healthcare/10 text-area-healthcare border-area-healthcare/20',
  manufacturing: 'bg-area-manufacturing/10 text-area-manufacturing border-area-manufacturing/20',
};

export function AreaBadge({ area, size = 'md', className }: AreaBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center font-medium border rounded-full',
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
        areaStyles[area],
        className
      )}
    >
      {areaLabels[area]}
    </span>
  );
}
