import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { exhibitors, ExhibitionArea } from '@/data/exhibitors';
import { ExhibitorCard } from '@/components/ExhibitorCard';
import { FilterBar } from '@/components/FilterBar';
import { Header } from '@/components/Header';
import { Building2 } from 'lucide-react';

const Index = () => {
  const [search, setSearch] = useState('');
  const [selectedArea, setSelectedArea] = useState<ExhibitionArea | null>(null);

  const filteredExhibitors = useMemo(() => {
    return exhibitors.filter(exhibitor => {
      const matchesSearch = search === '' || 
        exhibitor.name.toLowerCase().includes(search.toLowerCase()) ||
        exhibitor.tagline.toLowerCase().includes(search.toLowerCase()) ||
        exhibitor.description.toLowerCase().includes(search.toLowerCase());
      
      const matchesArea = selectedArea === null || exhibitor.area === selectedArea;
      
      return matchesSearch && matchesArea;
    });
  }, [search, selectedArea]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-primary py-16 sm:py-20">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,hsl(var(--primary))_0%,hsl(222_47%_35%)_100%)]" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-accent rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        </div>
        
        <div className="container relative mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-accent/20 rounded-full text-accent text-sm font-medium mb-4">
              <Building2 className="w-4 h-4" />
              <span>TechExpo 2024 • January 15-18</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-primary-foreground mb-4">
              Exhibitor Directory
            </h1>
            <p className="text-lg text-primary-foreground/80">
              Discover {exhibitors.length} innovative companies across electronics, healthcare, and manufacturing. 
              Save your favorites and plan your visit.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <FilterBar
          search={search}
          onSearchChange={setSearch}
          selectedArea={selectedArea}
          onAreaChange={setSelectedArea}
        />

        <div className="mt-6 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {filteredExhibitors.length} of {exhibitors.length} exhibitors
          </p>
        </div>

        {filteredExhibitors.length > 0 ? (
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredExhibitors.map((exhibitor, index) => (
              <ExhibitorCard key={exhibitor.id} exhibitor={exhibitor} index={index} />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-16 text-center"
          >
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Building2 className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-display font-semibold text-lg text-foreground">No exhibitors found</h3>
            <p className="mt-2 text-muted-foreground">
              Try adjusting your search or filter criteria
            </p>
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default Index;
