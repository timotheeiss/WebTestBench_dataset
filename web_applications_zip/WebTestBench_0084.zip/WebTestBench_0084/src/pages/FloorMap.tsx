import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Info, X } from 'lucide-react';
import { exhibitors, ExhibitionArea, areaLabels } from '@/data/exhibitors';
import { Header } from '@/components/Header';
import { AreaBadge } from '@/components/AreaBadge';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

const hallColors: Record<string, string> = {
  'Hall A': 'bg-area-electronics/20 border-area-electronics',
  'Hall B': 'bg-area-healthcare/20 border-area-healthcare',
  'Hall C': 'bg-area-manufacturing/20 border-area-manufacturing',
};

const hallAreas: Record<string, ExhibitionArea> = {
  'Hall A': 'electronics',
  'Hall B': 'healthcare',
  'Hall C': 'manufacturing',
};

export default function FloorMap() {
  const [selectedHall, setSelectedHall] = useState<string | null>(null);
  const [hoveredBooth, setHoveredBooth] = useState<string | null>(null);

  const halls = ['Hall A', 'Hall B', 'Hall C'];

  const getExhibitorsInHall = (hall: string) => {
    return exhibitors.filter(e => e.hall === hall);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="font-display text-3xl font-bold text-foreground">Floor Map</h1>
          <p className="mt-2 text-muted-foreground">
            Navigate the exhibition halls and find booth locations
          </p>
        </motion.div>

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 p-4 rounded-xl border border-border bg-card"
        >
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Exhibition Areas</h3>
          <div className="flex flex-wrap gap-4">
            {Object.entries(hallAreas).map(([hall, area]) => (
              <div key={hall} className="flex items-center gap-2">
                <div className={cn('w-4 h-4 rounded border-2', hallColors[hall])} />
                <span className="text-sm text-foreground">{hall}: {areaLabels[area]}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Map Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid gap-6 lg:grid-cols-3"
        >
          {halls.map((hall, i) => (
            <motion.div
              key={hall}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 * i }}
              className={cn(
                'relative p-6 rounded-2xl border-2 transition-all cursor-pointer',
                hallColors[hall],
                selectedHall === hall ? 'ring-2 ring-offset-2 ring-accent' : ''
              )}
              onClick={() => setSelectedHall(selectedHall === hall ? null : hall)}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-xl font-bold text-foreground">{hall}</h3>
                <AreaBadge area={hallAreas[hall]} size="sm" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                {getExhibitorsInHall(hall).map(exhibitor => (
                  <Link
                    key={exhibitor.id}
                    to={`/exhibitor/${exhibitor.id}`}
                    onMouseEnter={() => setHoveredBooth(exhibitor.id)}
                    onMouseLeave={() => setHoveredBooth(null)}
                    onClick={(e) => e.stopPropagation()}
                    className={cn(
                      'relative p-3 rounded-lg bg-card border border-border text-left transition-all hover:shadow-card-hover',
                      hoveredBooth === exhibitor.id ? 'ring-2 ring-accent' : ''
                    )}
                  >
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                      <MapPin className="w-3 h-3" />
                      {exhibitor.booth}
                    </div>
                    <p className="text-sm font-medium text-foreground line-clamp-1">
                      {exhibitor.name}
                    </p>
                  </Link>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {getExhibitorsInHall(hall).length} exhibitors
                </span>
                <span className="text-accent font-medium flex items-center gap-1">
                  <Info className="w-4 h-4" />
                  Click to explore
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Selected Hall Details */}
        {selectedHall && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 rounded-xl border border-border bg-card"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-xl font-bold text-foreground">{selectedHall} Exhibitors</h3>
              <button
                onClick={() => setSelectedHall(null)}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {getExhibitorsInHall(selectedHall).map(exhibitor => (
                <Link
                  key={exhibitor.id}
                  to={`/exhibitor/${exhibitor.id}`}
                  className="flex items-center gap-4 p-4 rounded-lg border border-border bg-background hover:shadow-card transition-all"
                >
                  <div className="w-12 h-12 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                    <img
                      src={exhibitor.logo}
                      alt={exhibitor.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-foreground truncate">{exhibitor.name}</p>
                    <p className="text-sm text-muted-foreground">Booth {exhibitor.booth}</p>
                  </div>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}
