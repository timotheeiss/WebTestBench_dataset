import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Heart, 
  MapPin, 
  ExternalLink, 
  Mail, 
  Calendar, 
  FileText,
  ChevronDown,
  Sparkles,
  Settings,
  Users,
  HelpCircle
} from 'lucide-react';
import { exhibitors } from '@/data/exhibitors';
import { AreaBadge } from '@/components/AreaBadge';
import { Header } from '@/components/Header';
import { useFavorites } from '@/contexts/FavoritesContext';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function ExhibitorDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isFavorite, toggleFavorite } = useFavorites();
  
  const exhibitor = exhibitors.find(e => e.id === id);
  
  if (!exhibitor) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold text-foreground mb-4">Exhibitor Not Found</h1>
          <p className="text-muted-foreground mb-8">The exhibitor you're looking for doesn't exist.</p>
          <Link to="/" className="text-accent hover:underline">Back to Directory</Link>
        </div>
      </div>
    );
  }

  const favorite = isFavorite(exhibitor.id);

  const handleScheduleMeeting = () => {
    toast.success('Meeting request sent!', {
      description: `We'll connect you with ${exhibitor.name} shortly.`,
    });
  };

  const handleRequestMaterials = () => {
    toast.success('Materials requested!', {
      description: 'Product information will be sent to your email.',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Breadcrumb & Actions */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              onClick={() => toggleFavorite(exhibitor.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
                favorite
                  ? 'bg-destructive text-destructive-foreground'
                  : 'bg-muted text-muted-foreground hover:text-destructive hover:bg-destructive/10'
              )}
            >
              <Heart className={cn('w-4 h-4', favorite && 'fill-current')} />
              {favorite ? 'Saved' : 'Save'}
            </button>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-6"
            >
              <div className="flex-shrink-0 w-24 h-24 rounded-xl bg-muted overflow-hidden shadow-card">
                <img
                  src={exhibitor.logo}
                  alt={`${exhibitor.name} logo`}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <AreaBadge area={exhibitor.area} />
                <h1 className="mt-2 font-display text-3xl font-bold text-foreground">
                  {exhibitor.name}
                </h1>
                <p className="mt-1 text-lg text-muted-foreground">{exhibitor.tagline}</p>
              </div>
            </motion.div>

            {/* Description */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <p className="text-foreground leading-relaxed">{exhibitor.description}</p>
            </motion.div>

            {/* Accordion Sections */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Accordion type="multiple" defaultValue={['highlights']} className="space-y-4">
                <AccordionItem value="highlights" className="border border-border rounded-xl px-6 bg-card">
                  <AccordionTrigger className="hover:no-underline py-5">
                    <span className="flex items-center gap-3 font-display font-semibold text-lg">
                      <Sparkles className="w-5 h-5 text-accent" />
                      Highlights
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-5">
                    <ul className="space-y-3">
                      {exhibitor.highlights.map((highlight, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <span className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/10 text-accent text-sm font-medium flex items-center justify-center">
                            {i + 1}
                          </span>
                          <span className="text-foreground">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="specifications" className="border border-border rounded-xl px-6 bg-card">
                  <AccordionTrigger className="hover:no-underline py-5">
                    <span className="flex items-center gap-3 font-display font-semibold text-lg">
                      <Settings className="w-5 h-5 text-accent" />
                      Specifications
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-5">
                    <div className="grid gap-3 sm:grid-cols-2">
                      {exhibitor.specifications.map((spec, i) => (
                        <div key={i} className="flex justify-between gap-4 p-3 rounded-lg bg-muted">
                          <span className="text-muted-foreground">{spec.label}</span>
                          <span className="font-medium text-foreground">{spec.value}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="audience" className="border border-border rounded-xl px-6 bg-card">
                  <AccordionTrigger className="hover:no-underline py-5">
                    <span className="flex items-center gap-3 font-display font-semibold text-lg">
                      <Users className="w-5 h-5 text-accent" />
                      Target Audience
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-5">
                    <div className="flex flex-wrap gap-2">
                      {exhibitor.targetAudience.map((audience, i) => (
                        <span
                          key={i}
                          className="px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground text-sm"
                        >
                          {audience}
                        </span>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faqs" className="border border-border rounded-xl px-6 bg-card">
                  <AccordionTrigger className="hover:no-underline py-5">
                    <span className="flex items-center gap-3 font-display font-semibold text-lg">
                      <HelpCircle className="w-5 h-5 text-accent" />
                      Frequently Asked Questions
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-5">
                    <div className="space-y-4">
                      {exhibitor.faqs.map((faq, i) => (
                        <div key={i} className="p-4 rounded-lg bg-muted">
                          <h4 className="font-medium text-foreground mb-2">{faq.question}</h4>
                          <p className="text-sm text-muted-foreground">{faq.answer}</p>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </motion.div>
          </div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Location Card */}
            <div className="p-6 rounded-xl border border-border bg-card">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                Location
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Hall & Booth</p>
                    <p className="font-medium text-foreground">{exhibitor.hall} • Booth {exhibitor.booth}</p>
                  </div>
                </div>
                <Link
                  to="/map"
                  className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  View on Floor Map
                </Link>
              </div>
            </div>

            {/* Actions Card */}
            <div className="p-6 rounded-xl border border-border bg-card">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                On-site Actions
              </h3>
              <div className="space-y-3">
                <Button
                  onClick={handleScheduleMeeting}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule a Meeting
                </Button>
                <Button
                  onClick={handleRequestMaterials}
                  variant="outline"
                  className="w-full"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Request Materials
                </Button>
              </div>
            </div>

            {/* Contact Card */}
            <div className="p-6 rounded-xl border border-border bg-card">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                Contact
              </h3>
              <div className="space-y-3">
                {exhibitor.website && (
                  <a
                    href={exhibitor.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Visit Website
                  </a>
                )}
                {exhibitor.contactEmail && (
                  <a
                    href={`mailto:${exhibitor.contactEmail}`}
                    className="flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    {exhibitor.contactEmail}
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
