import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ArrowRight } from 'lucide-react';
import { exhibitors } from '@/data/exhibitors';
import { ExhibitorCard } from '@/components/ExhibitorCard';
import { Header } from '@/components/Header';
import { useFavorites } from '@/contexts/FavoritesContext';

export default function Favorites() {
  const { favorites } = useFavorites();
  
  const favoriteExhibitors = exhibitors.filter(e => favorites.has(e.id));

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="font-display text-3xl font-bold text-foreground">Your Favorites</h1>
          <p className="mt-2 text-muted-foreground">
            Exhibitors you've saved during this session
          </p>
        </motion.div>

        {favoriteExhibitors.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {favoriteExhibitors.map((exhibitor, index) => (
              <ExhibitorCard key={exhibitor.id} exhibitor={exhibitor} index={index} />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-16 text-center"
          >
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
              <Heart className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-display font-semibold text-xl text-foreground">No favorites yet</h3>
            <p className="mt-2 text-muted-foreground max-w-md mx-auto">
              Browse the exhibitor directory and tap the heart icon to save companies you're interested in visiting.
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 mt-6 px-6 py-3 rounded-lg bg-accent text-accent-foreground font-medium hover:bg-accent/90 transition-colors"
            >
              Browse Exhibitors
              <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        )}
      </main>
    </div>
  );
}
