export type ExhibitionArea = 'electronics' | 'healthcare' | 'manufacturing';

export interface Exhibitor {
  id: string;
  name: string;
  tagline: string;
  description: string;
  logo: string;
  area: ExhibitionArea;
  booth: string;
  hall: string;
  highlights: string[];
  specifications: { label: string; value: string }[];
  targetAudience: string[];
  faqs: { question: string; answer: string }[];
  website?: string;
  contactEmail?: string;
}

export const exhibitors: Exhibitor[] = [
  {
    id: 'quantech-systems',
    name: 'QuantTech Systems',
    tagline: 'Next-Generation Quantum Computing Solutions',
    description: 'QuantTech Systems is pioneering accessible quantum computing for enterprise applications. Our hybrid quantum-classical systems enable businesses to solve complex optimization problems in logistics, finance, and drug discovery.',
    logo: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=200&h=200&fit=crop',
    area: 'electronics',
    booth: 'E-101',
    hall: 'Hall A',
    highlights: [
      'Live quantum computing demos every hour',
      'New QT-500 processor launch',
      'Free workshop on quantum algorithms',
      'Partner ecosystem showcase'
    ],
    specifications: [
      { label: 'Qubits', value: '127 superconducting qubits' },
      { label: 'Coherence Time', value: '100+ microseconds' },
      { label: 'Gate Fidelity', value: '99.5%' },
      { label: 'Operating Temp', value: '15 millikelvin' }
    ],
    targetAudience: [
      'CTOs and Technology Leaders',
      'Research Scientists',
      'Financial Institutions',
      'Pharmaceutical Companies'
    ],
    faqs: [
      { question: 'Do I need quantum expertise to use your systems?', answer: 'No! Our cloud platform includes intuitive APIs and pre-built algorithms. We also offer comprehensive training programs.' },
      { question: 'What industries benefit most from quantum computing?', answer: 'Finance (portfolio optimization), pharma (molecular simulation), logistics (route optimization), and AI/ML (quantum machine learning).' },
      { question: 'Is there a trial period available?', answer: 'Yes, we offer a 30-day free trial with 100 hours of quantum computing time.' }
    ],
    website: 'https://quanttech.example.com',
    contactEmail: 'contact@quanttech.example.com'
  },
  {
    id: 'medicore-innovations',
    name: 'MediCore Innovations',
    tagline: 'AI-Powered Diagnostic Imaging',
    description: 'MediCore Innovations combines advanced AI with medical imaging to deliver faster, more accurate diagnoses. Our FDA-cleared solutions help radiologists detect conditions earlier and improve patient outcomes.',
    logo: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=200&h=200&fit=crop',
    area: 'healthcare',
    booth: 'H-205',
    hall: 'Hall B',
    highlights: [
      'FDA-cleared AI diagnostic tools',
      'Real-time imaging analysis demos',
      'Case study presentations at 2PM daily',
      'Integration partner meetups'
    ],
    specifications: [
      { label: 'Accuracy', value: '98.7% detection rate' },
      { label: 'Processing Time', value: '<2 seconds per scan' },
      { label: 'Modalities', value: 'CT, MRI, X-ray, Ultrasound' },
      { label: 'Integration', value: 'PACS, EHR, HL7 FHIR' }
    ],
    targetAudience: [
      'Hospital Administrators',
      'Radiologists',
      'Healthcare IT Directors',
      'Medical Device Manufacturers'
    ],
    faqs: [
      { question: 'Is your AI solution FDA approved?', answer: 'Yes, our core diagnostic modules have received FDA 510(k) clearance for clinical use.' },
      { question: 'How does it integrate with existing systems?', answer: 'We support all major PACS systems and offer HL7 FHIR APIs for seamless EHR integration.' },
      { question: 'What training is required for staff?', answer: 'Most users are proficient within 2-4 hours. We provide on-site training and 24/7 support.' }
    ],
    website: 'https://medicore.example.com',
    contactEmail: 'info@medicore.example.com'
  },
  {
    id: 'autoforge-robotics',
    name: 'AutoForge Robotics',
    tagline: 'Collaborative Robots for Smart Manufacturing',
    description: 'AutoForge Robotics designs collaborative robots (cobots) that work safely alongside human workers. Our solutions increase productivity while reducing workplace injuries and training time.',
    logo: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=200&h=200&fit=crop',
    area: 'manufacturing',
    booth: 'M-312',
    hall: 'Hall C',
    highlights: [
      'Live cobot assembly demonstrations',
      'New AF-7 lightweight arm reveal',
      'Safety certification workshop',
      'Integration case studies'
    ],
    specifications: [
      { label: 'Payload', value: 'Up to 20kg' },
      { label: 'Reach', value: '1300mm' },
      { label: 'Repeatability', value: '±0.03mm' },
      { label: 'Safety Rating', value: 'ISO 10218-1, ISO/TS 15066' }
    ],
    targetAudience: [
      'Manufacturing Plant Managers',
      'Automation Engineers',
      'Operations Directors',
      'Safety Compliance Officers'
    ],
    faqs: [
      { question: 'Can cobots work without safety cages?', answer: 'Yes! Our cobots are designed for direct human collaboration with built-in force limiting and collision detection.' },
      { question: 'What programming knowledge is needed?', answer: 'None! Our teach pendant and drag-to-program interface allows operators to set up tasks in minutes.' },
      { question: 'What is the typical ROI timeline?', answer: 'Most customers see full ROI within 12-18 months through increased throughput and reduced labor costs.' }
    ],
    website: 'https://autoforge.example.com',
    contactEmail: 'sales@autoforge.example.com'
  },
  {
    id: 'neuralsense-ai',
    name: 'NeuralSense AI',
    tagline: 'Edge AI for Industrial IoT',
    description: 'NeuralSense AI brings machine learning to the edge with low-power chips designed for industrial environments. Process data in real-time without cloud connectivity for predictive maintenance and quality control.',
    logo: 'https://images.unsplash.com/photo-1555255707-c07966088b7b?w=200&h=200&fit=crop',
    area: 'electronics',
    booth: 'E-118',
    hall: 'Hall A',
    highlights: [
      'Edge AI chip showcase',
      'Predictive maintenance demos',
      'Developer workshop at 11AM',
      'SDK and toolkit giveaways'
    ],
    specifications: [
      { label: 'Power', value: '<500mW' },
      { label: 'Inference', value: '15 TOPS' },
      { label: 'Memory', value: '16MB on-chip SRAM' },
      { label: 'Interfaces', value: 'SPI, I2C, UART, Ethernet' }
    ],
    targetAudience: [
      'Embedded Systems Engineers',
      'IoT Solution Architects',
      'Industrial OEMs',
      'Maintenance Teams'
    ],
    faqs: [
      { question: 'Does edge processing compromise accuracy?', answer: 'Our optimized models maintain 95%+ accuracy while running entirely on-device without cloud dependency.' },
      { question: 'What development tools are available?', answer: 'We provide a complete SDK with model training, optimization, and deployment tools plus extensive documentation.' },
      { question: 'Can existing ML models be ported?', answer: 'Yes, we support TensorFlow Lite, ONNX, and PyTorch models with our conversion toolkit.' }
    ],
    website: 'https://neuralsense.example.com',
    contactEmail: 'dev@neuralsense.example.com'
  },
  {
    id: 'biosynth-labs',
    name: 'BioSynth Labs',
    tagline: 'Precision Medicine Through Genomics',
    description: 'BioSynth Labs offers next-generation sequencing solutions and bioinformatics platforms that enable personalized medicine. From sample to insight in under 24 hours.',
    logo: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=200&h=200&fit=crop',
    area: 'healthcare',
    booth: 'H-221',
    hall: 'Hall B',
    highlights: [
      'Rapid sequencing technology demo',
      'Clinical trial partnership announcements',
      'Genomics data workshop',
      'Sample analysis service trials'
    ],
    specifications: [
      { label: 'Throughput', value: '6 Tb per run' },
      { label: 'Read Length', value: 'Up to 300bp paired-end' },
      { label: 'Turnaround', value: '<24 hours' },
      { label: 'Accuracy', value: '>99.9% Q30' }
    ],
    targetAudience: [
      'Clinical Geneticists',
      'Research Lab Directors',
      'Pharma R&D Teams',
      'Oncologists'
    ],
    faqs: [
      { question: 'Is your platform CLIA certified?', answer: 'Yes, our clinical testing services operate from a CLIA-certified, CAP-accredited laboratory.' },
      { question: 'What types of samples can you process?', answer: 'Blood, saliva, tissue, and FFPE samples with optimized protocols for each.' },
      { question: 'Do you offer data analysis services?', answer: 'Yes, our bioinformatics team provides variant calling, annotation, and clinical interpretation services.' }
    ],
    website: 'https://biosynth.example.com',
    contactEmail: 'clinical@biosynth.example.com'
  },
  {
    id: 'precision-dynamics',
    name: 'Precision Dynamics',
    tagline: 'Smart CNC Solutions for Industry 4.0',
    description: 'Precision Dynamics delivers connected CNC machining centers with built-in AI optimization. Our machines learn from every cut to continuously improve quality and reduce cycle times.',
    logo: 'https://images.unsplash.com/photo-1565043666747-69f6646db940?w=200&h=200&fit=crop',
    area: 'manufacturing',
    booth: 'M-340',
    hall: 'Hall C',
    highlights: [
      '5-axis machining demos',
      'AI optimization showcase',
      'Industry 4.0 integration panel',
      'Financing options presentation'
    ],
    specifications: [
      { label: 'Axes', value: '5-axis simultaneous' },
      { label: 'Spindle Speed', value: '24,000 RPM' },
      { label: 'Positioning', value: '±0.002mm' },
      { label: 'Tool Capacity', value: '120 tools ATC' }
    ],
    targetAudience: [
      'Machine Shop Owners',
      'Production Engineers',
      'Aerospace Manufacturers',
      'Automotive Suppliers'
    ],
    faqs: [
      { question: 'How does AI improve machining?', answer: 'Our AI analyzes sensor data to optimize feeds, speeds, and toolpaths in real-time, reducing cycle time by up to 30%.' },
      { question: 'What connectivity options are available?', answer: 'Built-in OPC UA, MTConnect, and REST APIs for seamless MES/ERP integration.' },
      { question: 'Do you offer operator training?', answer: 'Yes, comprehensive training packages including on-site training, online courses, and certification programs.' }
    ],
    website: 'https://precisiondynamics.example.com',
    contactEmail: 'info@precisiondynamics.example.com'
  },
  {
    id: 'voltaic-energy',
    name: 'Voltaic Energy',
    tagline: 'Next-Gen Battery Technology',
    description: 'Voltaic Energy develops solid-state batteries with unprecedented energy density and safety. Our technology powers everything from EVs to grid storage with faster charging and longer life.',
    logo: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=200&h=200&fit=crop',
    area: 'electronics',
    booth: 'E-125',
    hall: 'Hall A',
    highlights: [
      'Solid-state battery prototype reveal',
      'EV partnership announcements',
      'Technical deep-dive sessions',
      'Sustainability impact report'
    ],
    specifications: [
      { label: 'Energy Density', value: '500 Wh/kg' },
      { label: 'Charge Time', value: '10-80% in 12 min' },
      { label: 'Cycle Life', value: '5000+ cycles' },
      { label: 'Operating Temp', value: '-30°C to 60°C' }
    ],
    targetAudience: [
      'EV Manufacturers',
      'Energy Storage Companies',
      'Consumer Electronics OEMs',
      'Aerospace Engineers'
    ],
    faqs: [
      { question: 'When will solid-state batteries be commercially available?', answer: 'We are beginning limited production in Q4 2024 with mass production scaling in 2025.' },
      { question: 'Are solid-state batteries safer?', answer: 'Yes, our batteries use non-flammable solid electrolytes, eliminating thermal runaway risks.' },
      { question: 'What form factors are available?', answer: 'Pouch, prismatic, and cylindrical cells with custom configurations available for OEM partners.' }
    ],
    website: 'https://voltaic.example.com',
    contactEmail: 'partnerships@voltaic.example.com'
  },
  {
    id: 'healix-therapeutics',
    name: 'Healix Therapeutics',
    tagline: 'Wearable Health Monitoring',
    description: 'Healix Therapeutics creates medical-grade wearable devices that continuously monitor vital signs and detect health anomalies before they become emergencies.',
    logo: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=200&h=200&fit=crop',
    area: 'healthcare',
    booth: 'H-238',
    hall: 'Hall B',
    highlights: [
      'New cardiac monitoring patch',
      'Clinical trial results presentation',
      'Wearable device try-on station',
      'Telehealth integration demos'
    ],
    specifications: [
      { label: 'Battery Life', value: '14 days continuous' },
      { label: 'Sensors', value: 'ECG, SpO2, Temp, Motion' },
      { label: 'Water Resistance', value: 'IP68' },
      { label: 'Data Sync', value: 'BLE 5.0, WiFi' }
    ],
    targetAudience: [
      'Cardiologists',
      'Remote Patient Monitoring Teams',
      'Health Insurance Providers',
      'Senior Care Facilities'
    ],
    faqs: [
      { question: 'Are the devices FDA cleared for clinical use?', answer: 'Yes, our cardiac monitoring devices have FDA 510(k) clearance for arrhythmia detection.' },
      { question: 'How is patient data protected?', answer: 'All data is encrypted end-to-end and stored in HIPAA-compliant cloud infrastructure.' },
      { question: 'Can patients shower or swim with the device?', answer: 'Yes, our devices are rated IP68 and can be worn during showering and swimming.' }
    ],
    website: 'https://healix.example.com',
    contactEmail: 'clinical@healix.example.com'
  }
];

export const areaLabels: Record<ExhibitionArea, string> = {
  electronics: 'Electronics & Technology',
  healthcare: 'Healthcare & Medical',
  manufacturing: 'Manufacturing & Automation'
};

export const areaColors: Record<ExhibitionArea, string> = {
  electronics: 'bg-area-electronics',
  healthcare: 'bg-area-healthcare',
  manufacturing: 'bg-area-manufacturing'
};
