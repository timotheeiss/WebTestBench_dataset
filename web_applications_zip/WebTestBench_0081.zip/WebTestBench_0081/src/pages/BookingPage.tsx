import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import StepIndicator from "@/components/StepIndicator";
import ApplianceCard from "@/components/ApplianceCard";
import TimeSlotPicker from "@/components/TimeSlotPicker";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { appliances, commonIssues } from "@/data/appliances";
import { TimeSlot } from "@/data/timeSlots";
import { useBooking } from "@/context/BookingContext";

const steps = [
  { number: 1, label: "Appliance" },
  { number: 2, label: "Issue" },
  { number: 3, label: "Time Slot" },
];

const BookingPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { setCurrentBooking, getAppliancePrice } = useBooking();

  const [currentStep, setCurrentStep] = useState(1);
  const [selectedAppliance, setSelectedAppliance] = useState<string | null>(
    searchParams.get("appliance")
  );
  const [selectedIssue, setSelectedIssue] = useState<string | null>(null);
  const [issueDescription, setIssueDescription] = useState("");
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);

  const selectedApplianceData = appliances.find(
    (a) => a.id === selectedAppliance
  );
  const issues = selectedAppliance ? commonIssues[selectedAppliance] || [] : [];

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return !!selectedAppliance;
      case 2:
        return !!selectedIssue;
      case 3:
        return !!selectedSlot;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else if (selectedSlot && selectedAppliance && selectedIssue) {
      // Proceed to payment
      setCurrentBooking({
        applianceId: selectedAppliance,
        issue: selectedIssue,
        issueDescription,
        timeSlotId: selectedSlot.id,
        date: format(selectedSlot.date, "yyyy-MM-dd"),
        timeSlot: `${selectedSlot.startTime} - ${selectedSlot.endTime}`,
      });
      navigate("/payment");
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  // Reset selections when changing appliance
  useEffect(() => {
    setSelectedIssue(null);
    setIssueDescription("");
  }, [selectedAppliance]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8">
        <div className="container max-w-4xl">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Book Your Repair
            </h1>
            <p className="text-muted-foreground">
              Complete the steps below to schedule your appliance repair
            </p>
          </div>

          <StepIndicator steps={steps} currentStep={currentStep} />

          <div className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-sm">
            {/* Step 1: Select Appliance */}
            {currentStep === 1 && (
              <div className="animate-fade-in">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  What appliance needs repair?
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {appliances.map((appliance) => (
                    <ApplianceCard
                      key={appliance.id}
                      {...appliance}
                      selected={selectedAppliance === appliance.id}
                      onClick={() => setSelectedAppliance(appliance.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Describe Issue */}
            {currentStep === 2 && (
              <div className="animate-fade-in">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  What's the problem with your {selectedApplianceData?.name}?
                </h2>

                <div className="space-y-6">
                  <div>
                    <Label className="text-base font-medium mb-3 block">
                      Select the issue
                    </Label>
                    <RadioGroup
                      value={selectedIssue || ""}
                      onValueChange={setSelectedIssue}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-3"
                    >
                      {issues.map((issue) => (
                        <div key={issue}>
                          <RadioGroupItem
                            value={issue}
                            id={issue}
                            className="peer sr-only"
                          />
                          <Label
                            htmlFor={issue}
                            className="flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover:border-primary/50"
                          >
                            <div className="h-4 w-4 rounded-full border-2 border-current flex items-center justify-center peer-data-[state=checked]:border-primary">
                              {selectedIssue === issue && (
                                <div className="h-2 w-2 rounded-full bg-primary" />
                              )}
                            </div>
                            <span className="text-foreground">{issue}</span>
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>

                  <div>
                    <Label
                      htmlFor="description"
                      className="text-base font-medium mb-3 block"
                    >
                      Additional details (optional)
                    </Label>
                    <Textarea
                      id="description"
                      placeholder="Provide any additional information about the issue..."
                      value={issueDescription}
                      onChange={(e) => setIssueDescription(e.target.value)}
                      className="min-h-[120px] resize-none"
                    />
                  </div>

                  {selectedIssue && (
                    <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                      <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="font-medium text-foreground">
                          Estimated Service Fee
                        </p>
                        <p className="text-2xl font-bold text-primary">
                          ${getAppliancePrice(selectedAppliance!)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Final price may vary based on diagnosis
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Step 3: Select Time Slot */}
            {currentStep === 3 && (
              <div className="animate-fade-in">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Choose your preferred time slot
                </h2>
                <TimeSlotPicker
                  selectedSlotId={selectedSlot?.id || null}
                  onSelectSlot={setSelectedSlot}
                />
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
              <Button
                variant="ghost"
                onClick={handleBack}
                disabled={currentStep === 1}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>

              <Button
                variant="hero"
                onClick={handleNext}
                disabled={!canProceed()}
                className="gap-2"
              >
                {currentStep === 3 ? "Continue to Payment" : "Continue"}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default BookingPage;
