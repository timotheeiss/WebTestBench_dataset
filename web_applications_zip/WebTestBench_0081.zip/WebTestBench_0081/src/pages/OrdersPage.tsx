import { Link } from "react-router-dom";
import { ClipboardList, Plus } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BookingCard from "@/components/BookingCard";
import { Button } from "@/components/ui/button";
import { useBooking } from "@/context/BookingContext";
import { toast } from "@/hooks/use-toast";

const OrdersPage = () => {
  const { bookings, cancelBooking } = useBooking();

  const handleCancel = (id: string) => {
    cancelBooking(id);
    toast({
      title: "Booking Cancelled",
      description: "Your appointment has been cancelled successfully.",
    });
  };

  // Sort bookings by date, most recent first
  const sortedBookings = [...bookings].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8">
        <div className="container max-w-4xl">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                My Orders
              </h1>
              <p className="text-muted-foreground">
                View and manage your repair appointments
              </p>
            </div>
            <Link to="/book">
              <Button variant="hero" className="gap-2">
                <Plus className="h-4 w-4" />
                Book New Repair
              </Button>
            </Link>
          </div>

          {sortedBookings.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-12 text-center">
              <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <ClipboardList className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">
                No Bookings Yet
              </h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                You haven't made any repair bookings yet. Book your first
                appliance repair and we'll get it fixed in no time!
              </p>
              <Link to="/book">
                <Button variant="hero" size="lg">
                  Book Your First Repair
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedBookings.map((booking) => (
                <BookingCard
                  key={booking.id}
                  booking={booking}
                  onCancel={handleCancel}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default OrdersPage;
