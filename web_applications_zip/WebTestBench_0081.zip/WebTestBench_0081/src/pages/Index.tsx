import { Link } from "react-router-dom";
import { ArrowRight, Shield, Clock, ThumbsUp, Star, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { appliances } from "@/data/appliances";

const Index = () => {
  const features = [
    {
      icon: Clock,
      title: "Same-Day Service",
      description: "Get your appliances fixed fast with our quick response team.",
    },
    {
      icon: Shield,
      title: "90-Day Warranty",
      description: "All repairs come with a comprehensive warranty for peace of mind.",
    },
    {
      icon: ThumbsUp,
      title: "Expert Technicians",
      description: "Certified professionals with years of experience.",
    },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      rating: 5,
      text: "Absolutely fantastic service! My fridge was fixed within hours of booking.",
      appliance: "Refrigerator Repair",
    },
    {
      name: "Mike Chen",
      rating: 5,
      text: "Professional, punctual, and reasonably priced. Highly recommend!",
      appliance: "Washing Machine",
    },
    {
      name: "Emily Davis",
      rating: 5,
      text: "The technician explained everything clearly. Great experience overall.",
      appliance: "AC Repair",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden gradient-hero">
          <div className="container py-20 md:py-32">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <Star className="h-4 w-4 fill-current" />
                Trusted by 50,000+ customers
              </div>
              <h1 className="text-4xl md:text-6xl font-extrabold text-foreground mb-6 leading-tight">
                Expert Appliance Repair{" "}
                <span className="text-primary">At Your Doorstep</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Fast, reliable, and affordable home appliance repair services.
                Book online in minutes and get your appliances working again.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/book">
                  <Button variant="hero" size="xl" className="w-full sm:w-auto">
                    Book a Repair
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/orders">
                  <Button variant="outline" size="xl" className="w-full sm:w-auto">
                    View My Orders
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Decorative elements */}
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />
        </section>

        {/* Features Section */}
        <section className="py-16 bg-card">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center text-center p-6 rounded-2xl bg-background border border-border hover:shadow-lg transition-shadow animate-slide-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="h-14 w-14 rounded-2xl gradient-primary flex items-center justify-center mb-4 shadow-lg">
                    <feature.icon className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                What We Repair
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                From refrigerators to air conditioners, we've got all your home
                appliance repairs covered.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {appliances.map((appliance, index) => (
                <Link
                  key={appliance.id}
                  to={`/book?appliance=${appliance.id}`}
                  className="group p-5 rounded-xl bg-card border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 animate-slide-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                    <appliance.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">
                    {appliance.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {appliance.description}
                  </p>
                  <p className="text-sm font-semibold text-primary">
                    From ${appliance.basePrice}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20 bg-card">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                How It Works
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Booking a repair has never been easier. Just follow these simple
                steps.
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              {[
                { step: 1, title: "Select Appliance", desc: "Choose what needs fixing" },
                { step: 2, title: "Describe Issue", desc: "Tell us what's wrong" },
                { step: 3, title: "Pick Time Slot", desc: "Select convenient time" },
                { step: 4, title: "Confirm & Pay", desc: "Secure online payment" },
              ].map((item, index) => (
                <div key={index} className="text-center relative">
                  <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-4 text-2xl font-bold text-primary-foreground shadow-lg">
                    {item.step}
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                  {index < 3 && (
                    <div className="hidden md:block absolute top-8 left-[60%] w-[80%] h-0.5 bg-border" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                What Our Customers Say
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="h-5 w-5 text-accent fill-accent"
                      />
                    ))}
                  </div>
                  <p className="text-foreground mb-4">"{testimonial.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-semibold">
                      {testimonial.name[0]}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {testimonial.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {testimonial.appliance}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 gradient-hero">
          <div className="container">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Ready to Fix Your Appliance?
              </h2>
              <p className="text-muted-foreground mb-8">
                Book now and get same-day service. Our expert technicians are
                ready to help.
              </p>
              <Link to="/book">
                <Button variant="hero" size="xl">
                  Book Your Repair Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center justify-center gap-6 mt-8 text-sm text-muted-foreground">
                <span className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  No hidden fees
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  90-day warranty
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  Expert technicians
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
