import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { format, parseISO } from "date-fns";
import {
  ArrowLeft,
  CreditCard,
  Lock,
  CheckCircle,
  Calendar,
  Clock,
  Wrench,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useBooking } from "@/context/BookingContext";
import { appliances } from "@/data/appliances";
import { toast } from "@/hooks/use-toast";

const PaymentPage = () => {
  const navigate = useNavigate();
  const { currentBooking, addBooking, getAppliancePrice } = useBooking();
  const [isProcessing, setIsProcessing] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!currentBooking) {
    navigate("/book");
    return null;
  }

  const appliance = appliances.find((a) => a.id === currentBooking.applianceId);
  const price = getAppliancePrice(currentBooking.applianceId);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = "Invalid email format";
    if (!formData.phone.trim()) newErrors.phone = "Phone is required";
    if (!formData.address.trim()) newErrors.address = "Address is required";
    if (!formData.cardNumber.trim())
      newErrors.cardNumber = "Card number is required";
    else if (formData.cardNumber.replace(/\s/g, "").length < 16)
      newErrors.cardNumber = "Invalid card number";
    if (!formData.expiry.trim()) newErrors.expiry = "Expiry is required";
    if (!formData.cvv.trim()) newErrors.cvv = "CVV is required";
    else if (formData.cvv.length < 3) newErrors.cvv = "Invalid CVV";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value;

    // Format card number with spaces
    if (field === "cardNumber") {
      formattedValue = value
        .replace(/\D/g, "")
        .replace(/(\d{4})/g, "$1 ")
        .trim()
        .slice(0, 19);
    }

    // Format expiry date
    if (field === "expiry") {
      formattedValue = value
        .replace(/\D/g, "")
        .replace(/(\d{2})(\d)/, "$1/$2")
        .slice(0, 5);
    }

    // CVV only numbers
    if (field === "cvv") {
      formattedValue = value.replace(/\D/g, "").slice(0, 4);
    }

    // Phone formatting
    if (field === "phone") {
      formattedValue = value
        .replace(/\D/g, "")
        .replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3")
        .slice(0, 14);
    }

    setFormData((prev) => ({ ...prev, [field]: formattedValue }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsProcessing(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    addBooking({
      applianceId: currentBooking.applianceId,
      applianceName: appliance?.name || "",
      issue: currentBooking.issue,
      issueDescription: currentBooking.issueDescription,
      date: currentBooking.date,
      timeSlot: currentBooking.timeSlot,
      price,
      status: "confirmed",
      customerName: formData.name,
      customerEmail: formData.email,
      customerPhone: formData.phone,
      address: formData.address,
    });

    toast({
      title: "Booking Confirmed!",
      description: "Your repair appointment has been scheduled successfully.",
    });

    navigate("/orders");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8">
        <div className="container max-w-4xl">
          <Button
            variant="ghost"
            onClick={() => navigate("/book")}
            className="mb-6 gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Booking
          </Button>

          <div className="grid md:grid-cols-5 gap-8">
            {/* Payment Form */}
            <div className="md:col-span-3">
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                <h1 className="text-2xl font-bold text-foreground mb-6">
                  Complete Your Booking
                </h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Contact Information */}
                  <div>
                    <h2 className="text-lg font-semibold text-foreground mb-4">
                      Contact Information
                    </h2>
                    <div className="grid gap-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          placeholder="John Smith"
                          value={formData.name}
                          onChange={(e) =>
                            handleInputChange("name", e.target.value)
                          }
                          className={errors.name ? "border-destructive" : ""}
                        />
                        {errors.name && (
                          <p className="text-sm text-destructive mt-1">
                            {errors.name}
                          </p>
                        )}
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="john@example.com"
                            value={formData.email}
                            onChange={(e) =>
                              handleInputChange("email", e.target.value)
                            }
                            className={errors.email ? "border-destructive" : ""}
                          />
                          {errors.email && (
                            <p className="text-sm text-destructive mt-1">
                              {errors.email}
                            </p>
                          )}
                        </div>
                        <div>
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            placeholder="(555) 123-4567"
                            value={formData.phone}
                            onChange={(e) =>
                              handleInputChange("phone", e.target.value)
                            }
                            className={errors.phone ? "border-destructive" : ""}
                          />
                          {errors.phone && (
                            <p className="text-sm text-destructive mt-1">
                              {errors.phone}
                            </p>
                          )}
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="address">Service Address</Label>
                        <Input
                          id="address"
                          placeholder="123 Main Street, Apt 4B, City, State 12345"
                          value={formData.address}
                          onChange={(e) =>
                            handleInputChange("address", e.target.value)
                          }
                          className={errors.address ? "border-destructive" : ""}
                        />
                        {errors.address && (
                          <p className="text-sm text-destructive mt-1">
                            {errors.address}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Payment Details */}
                  <div>
                    <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Payment Details
                    </h2>
                    <div className="grid gap-4">
                      <div>
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input
                          id="cardNumber"
                          placeholder="1234 5678 9012 3456"
                          value={formData.cardNumber}
                          onChange={(e) =>
                            handleInputChange("cardNumber", e.target.value)
                          }
                          className={
                            errors.cardNumber ? "border-destructive" : ""
                          }
                        />
                        {errors.cardNumber && (
                          <p className="text-sm text-destructive mt-1">
                            {errors.cardNumber}
                          </p>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input
                            id="expiry"
                            placeholder="MM/YY"
                            value={formData.expiry}
                            onChange={(e) =>
                              handleInputChange("expiry", e.target.value)
                            }
                            className={
                              errors.expiry ? "border-destructive" : ""
                            }
                          />
                          {errors.expiry && (
                            <p className="text-sm text-destructive mt-1">
                              {errors.expiry}
                            </p>
                          )}
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV</Label>
                          <Input
                            id="cvv"
                            placeholder="123"
                            value={formData.cvv}
                            onChange={(e) =>
                              handleInputChange("cvv", e.target.value)
                            }
                            className={errors.cvv ? "border-destructive" : ""}
                          />
                          {errors.cvv && (
                            <p className="text-sm text-destructive mt-1">
                              {errors.cvv}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-4 rounded-lg bg-success/5 border border-success/20 text-sm text-muted-foreground">
                    <Lock className="h-4 w-4 text-success" />
                    Your payment information is secure and encrypted
                  </div>

                  <Button
                    type="submit"
                    variant="hero"
                    size="lg"
                    className="w-full"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-5 w-5" />
                        Confirm & Pay ${price}
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </div>

            {/* Order Summary */}
            <div className="md:col-span-2">
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm sticky top-24">
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  Order Summary
                </h2>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    {appliance && (
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                        <appliance.icon className="h-6 w-6 text-primary" />
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-foreground">
                        {appliance?.name} Repair
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {currentBooking.issue}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border space-y-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      {format(parseISO(currentBooking.date), "EEEE, MMMM d, yyyy")}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {currentBooking.timeSlot}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Wrench className="h-4 w-4" />
                      {appliance?.estimatedTime}
                    </div>
                  </div>

                  {currentBooking.issueDescription && (
                    <div className="pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        {currentBooking.issueDescription}
                      </p>
                    </div>
                  )}

                  <div className="pt-4 border-t border-border">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Service Fee</span>
                      <span className="font-medium text-foreground">
                        ${price}
                      </span>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-muted-foreground">Tax</span>
                      <span className="font-medium text-foreground">$0</span>
                    </div>
                    <div className="flex justify-between items-center mt-4 pt-4 border-t border-border">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="text-2xl font-bold text-primary">
                        ${price}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PaymentPage;
