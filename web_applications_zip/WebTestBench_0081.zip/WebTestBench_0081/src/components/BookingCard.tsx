import { format, parseISO } from "date-fns";
import { Calendar, Clock, MapPin, AlertCircle, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { Booking } from "@/types/booking";
import { appliances } from "@/data/appliances";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";

interface BookingCardProps {
  booking: Booking;
  onCancel: (id: string) => void;
}

const statusConfig = {
  confirmed: {
    label: "Confirmed",
    icon: CheckCircle,
    className: "bg-success/10 text-success border-success/20",
  },
  pending: {
    label: "Pending",
    icon: Loader2,
    className: "bg-warning/10 text-warning border-warning/20",
  },
  cancelled: {
    label: "Cancelled",
    icon: XCircle,
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
  completed: {
    label: "Completed",
    icon: CheckCircle,
    className: "bg-primary/10 text-primary border-primary/20",
  },
};

const BookingCard = ({ booking, onCancel }: BookingCardProps) => {
  const appliance = appliances.find((a) => a.id === booking.applianceId);
  const Icon = appliance?.icon;
  const status = statusConfig[booking.status];
  const StatusIcon = status.icon;
  const canCancel = booking.status === "confirmed" || booking.status === "pending";

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow animate-fade-in">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          {Icon && (
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Icon className="h-6 w-6 text-primary" />
            </div>
          )}
          <div>
            <h3 className="font-semibold text-foreground">{booking.applianceName}</h3>
            <p className="text-sm text-muted-foreground">{booking.issue}</p>
          </div>
        </div>
        <div
          className={cn(
            "flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border",
            status.className
          )}
        >
          <StatusIcon className={cn("h-3 w-3", booking.status === "pending" && "animate-spin")} />
          {status.label}
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          {format(parseISO(booking.date), "EEEE, MMMM d, yyyy")}
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          {booking.timeSlot}
        </div>
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 mt-0.5" />
          {booking.address}
        </div>
      </div>

      {booking.issueDescription && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-secondary/50 text-sm mb-4">
          <AlertCircle className="h-4 w-4 text-muted-foreground mt-0.5" />
          <p className="text-muted-foreground">{booking.issueDescription}</p>
        </div>
      )}

      <div className="flex items-center justify-between pt-4 border-t border-border">
        <div>
          <span className="text-sm text-muted-foreground">Service Fee</span>
          <p className="text-xl font-bold text-foreground">${booking.price}</p>
        </div>
        {canCancel && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onCancel(booking.id)}
            className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            Cancel Booking
          </Button>
        )}
      </div>
    </div>
  );
};

export default BookingCard;
