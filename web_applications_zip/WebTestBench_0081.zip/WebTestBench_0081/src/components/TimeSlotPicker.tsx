import { useState, useMemo } from "react";
import { format, parseISO } from "date-fns";
import { Calendar, Clock } from "lucide-react";
import { generateTimeSlots, groupSlotsByDate, TimeSlot } from "@/data/timeSlots";
import { cn } from "@/lib/utils";

interface TimeSlotPickerProps {
  selectedSlotId: string | null;
  onSelectSlot: (slot: TimeSlot) => void;
}

const TimeSlotPicker = ({ selectedSlotId, onSelectSlot }: TimeSlotPickerProps) => {
  const slots = useMemo(() => generateTimeSlots(), []);
  const groupedSlots = useMemo(() => groupSlotsByDate(slots), [slots]);
  const dateKeys = Object.keys(groupedSlots);
  const [selectedDate, setSelectedDate] = useState(dateKeys[0]);

  return (
    <div className="space-y-6">
      {/* Date selector */}
      <div>
        <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-3">
          <Calendar className="h-4 w-4 text-primary" />
          Select a Date
        </label>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {dateKeys.map((dateKey) => {
            const date = parseISO(dateKey);
            const isSelected = selectedDate === dateKey;
            const availableCount = groupedSlots[dateKey].filter(
              (s) => s.available
            ).length;

            return (
              <button
                key={dateKey}
                onClick={() => setSelectedDate(dateKey)}
                className={cn(
                  "flex-shrink-0 flex flex-col items-center p-3 rounded-xl border-2 transition-all duration-200 min-w-[80px]",
                  isSelected
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card hover:border-primary/50"
                )}
              >
                <span className="text-xs text-muted-foreground uppercase">
                  {format(date, "EEE")}
                </span>
                <span
                  className={cn(
                    "text-xl font-bold",
                    isSelected ? "text-primary" : "text-foreground"
                  )}
                >
                  {format(date, "d")}
                </span>
                <span className="text-xs text-muted-foreground">
                  {format(date, "MMM")}
                </span>
                <span
                  className={cn(
                    "text-[10px] mt-1 px-2 py-0.5 rounded-full",
                    availableCount > 5
                      ? "bg-success/10 text-success"
                      : availableCount > 0
                      ? "bg-warning/10 text-warning"
                      : "bg-destructive/10 text-destructive"
                  )}
                >
                  {availableCount} slots
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Time slots */}
      <div>
        <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-3">
          <Clock className="h-4 w-4 text-primary" />
          Available Time Slots for {format(parseISO(selectedDate), "EEEE, MMMM d")}
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {groupedSlots[selectedDate]?.map((slot) => (
            <button
              key={slot.id}
              disabled={!slot.available}
              onClick={() => onSelectSlot(slot)}
              className={cn(
                "p-3 rounded-lg border-2 text-sm font-medium transition-all duration-200",
                !slot.available
                  ? "border-border bg-muted text-muted-foreground cursor-not-allowed opacity-50"
                  : selectedSlotId === slot.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:border-primary/50 text-foreground"
              )}
            >
              {slot.startTime}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TimeSlotPicker;
