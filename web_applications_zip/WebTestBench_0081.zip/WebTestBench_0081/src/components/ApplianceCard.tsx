import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface ApplianceCardProps {
  id: string;
  name: string;
  icon: LucideIcon;
  description: string;
  basePrice: number;
  estimatedTime: string;
  selected: boolean;
  onClick: () => void;
}

const ApplianceCard = ({
  id,
  name,
  icon: Icon,
  description,
  basePrice,
  estimatedTime,
  selected,
  onClick,
}: ApplianceCardProps) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative w-full p-5 rounded-xl border-2 text-left transition-all duration-300 group",
        selected
          ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
          : "border-border bg-card hover:border-primary/50 hover:shadow-md"
      )}
    >
      {selected && (
        <div className="absolute top-3 right-3 h-5 w-5 rounded-full gradient-primary flex items-center justify-center animate-scale-in">
          <svg
            className="h-3 w-3 text-primary-foreground"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M5 13l4 4L19 7"
            />
          </svg>
        </div>
      )}

      <div
        className={cn(
          "h-12 w-12 rounded-xl flex items-center justify-center mb-3 transition-all duration-300",
          selected
            ? "gradient-primary shadow-md"
            : "bg-secondary group-hover:bg-primary/10"
        )}
      >
        <Icon
          className={cn(
            "h-6 w-6 transition-colors",
            selected ? "text-primary-foreground" : "text-primary"
          )}
        />
      </div>

      <h3 className="font-semibold text-foreground mb-1">{name}</h3>
      <p className="text-sm text-muted-foreground mb-3">{description}</p>

      <div className="flex items-center justify-between text-sm">
        <span className="font-semibold text-primary">From ${basePrice}</span>
        <span className="text-muted-foreground">{estimatedTime}</span>
      </div>
    </button>
  );
};

export default ApplianceCard;
