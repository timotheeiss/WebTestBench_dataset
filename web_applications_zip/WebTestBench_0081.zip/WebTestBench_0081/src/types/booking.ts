export interface Booking {
  id: string;
  applianceId: string;
  applianceName: string;
  issue: string;
  issueDescription: string;
  date: string;
  timeSlot: string;
  price: number;
  status: "confirmed" | "pending" | "cancelled" | "completed";
  createdAt: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  address: string;
}

export interface BookingFormData {
  applianceId: string;
  issue: string;
  issueDescription: string;
  timeSlotId: string;
  date: string;
  timeSlot: string;
}
