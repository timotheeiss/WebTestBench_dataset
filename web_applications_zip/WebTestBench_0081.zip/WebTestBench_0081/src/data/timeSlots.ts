import { addDays, format, setHours, setMinutes } from "date-fns";

export interface TimeSlot {
  id: string;
  date: Date;
  startTime: string;
  endTime: string;
  available: boolean;
}

export const generateTimeSlots = (): TimeSlot[] => {
  const slots: TimeSlot[] = [];
  const today = new Date();
  
  // Generate slots for the next 7 days
  for (let dayOffset = 1; dayOffset <= 7; dayOffset++) {
    const date = addDays(today, dayOffset);
    
    // Skip Sundays
    if (date.getDay() === 0) continue;
    
    // Morning slots: 8am, 9am, 10am, 11am
    // Afternoon slots: 1pm, 2pm, 3pm, 4pm, 5pm
    const hours = [8, 9, 10, 11, 13, 14, 15, 16, 17];
    
    hours.forEach((hour, index) => {
      const slotDate = setMinutes(setHours(date, hour), 0);
      
      // Randomly make some slots unavailable for realism
      const available = Math.random() > 0.3;
      
      slots.push({
        id: `${format(date, "yyyy-MM-dd")}-${hour}`,
        date: slotDate,
        startTime: format(slotDate, "h:mm a"),
        endTime: format(setHours(date, hour + 1), "h:mm a"),
        available,
      });
    });
  }
  
  return slots;
};

export const groupSlotsByDate = (slots: TimeSlot[]): Record<string, TimeSlot[]> => {
  return slots.reduce((acc, slot) => {
    const dateKey = format(slot.date, "yyyy-MM-dd");
    if (!acc[dateKey]) {
      acc[dateKey] = [];
    }
    acc[dateKey].push(slot);
    return acc;
  }, {} as Record<string, TimeSlot[]>);
};
