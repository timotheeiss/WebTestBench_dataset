import { Refrigerator, WashingMachine, Wind, Microwave, Tv, Flame, Droplets, Zap } from "lucide-react";

export interface Appliance {
  id: string;
  name: string;
  icon: typeof Refrigerator;
  description: string;
  basePrice: number;
  estimatedTime: string;
}

export const appliances: Appliance[] = [
  {
    id: "refrigerator",
    name: "Refrigerator",
    icon: Refrigerator,
    description: "Cooling issues, leaks, strange noises",
    basePrice: 89,
    estimatedTime: "1-2 hours",
  },
  {
    id: "washing-machine",
    name: "Washing Machine",
    icon: WashingMachine,
    description: "Won't spin, drainage problems, leaks",
    basePrice: 79,
    estimatedTime: "1-2 hours",
  },
  {
    id: "air-conditioner",
    name: "Air Conditioner",
    icon: Wind,
    description: "Not cooling, strange sounds, filter issues",
    basePrice: 99,
    estimatedTime: "1-3 hours",
  },
  {
    id: "microwave",
    name: "Microwave",
    icon: Microwave,
    description: "Not heating, sparking, turntable issues",
    basePrice: 59,
    estimatedTime: "30-60 mins",
  },
  {
    id: "television",
    name: "Television",
    icon: Tv,
    description: "No picture, sound issues, connectivity",
    basePrice: 69,
    estimatedTime: "1-2 hours",
  },
  {
    id: "oven",
    name: "Oven/Stove",
    icon: Flame,
    description: "Heating issues, ignition problems",
    basePrice: 89,
    estimatedTime: "1-2 hours",
  },
  {
    id: "dishwasher",
    name: "Dishwasher",
    icon: Droplets,
    description: "Not cleaning, drainage, leaks",
    basePrice: 79,
    estimatedTime: "1-2 hours",
  },
  {
    id: "dryer",
    name: "Dryer",
    icon: Zap,
    description: "Not heating, won't tumble, noise",
    basePrice: 79,
    estimatedTime: "1-2 hours",
  },
];

export const commonIssues: Record<string, string[]> = {
  refrigerator: [
    "Not cooling properly",
    "Making strange noises",
    "Leaking water",
    "Ice buildup in freezer",
    "Door seal damaged",
    "Other issue",
  ],
  "washing-machine": [
    "Won't start",
    "Not draining",
    "Excessive vibration",
    "Leaking water",
    "Door won't lock",
    "Other issue",
  ],
  "air-conditioner": [
    "Not cooling",
    "Strange odor",
    "Water dripping inside",
    "Making loud noises",
    "Remote not working",
    "Other issue",
  ],
  microwave: [
    "Not heating food",
    "Turntable not spinning",
    "Sparking inside",
    "Buttons not responding",
    "Door won't close",
    "Other issue",
  ],
  television: [
    "No picture",
    "No sound",
    "Screen flickering",
    "Won't turn on",
    "Remote issues",
    "Other issue",
  ],
  oven: [
    "Not heating",
    "Uneven cooking",
    "Gas smell",
    "Ignition problems",
    "Timer not working",
    "Other issue",
  ],
  dishwasher: [
    "Dishes not clean",
    "Not draining",
    "Leaking",
    "Strange noises",
    "Door latch broken",
    "Other issue",
  ],
  dryer: [
    "Not heating",
    "Takes too long",
    "Making noise",
    "Won't start",
    "Drum not spinning",
    "Other issue",
  ],
};
