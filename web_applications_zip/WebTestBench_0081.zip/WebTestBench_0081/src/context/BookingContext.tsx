import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Booking, BookingFormData } from "@/types/booking";
import { appliances } from "@/data/appliances";

interface BookingContextType {
  bookings: Booking[];
  currentBooking: BookingFormData | null;
  setCurrentBooking: (booking: BookingFormData | null) => void;
  addBooking: (booking: Omit<Booking, "id" | "createdAt">) => void;
  cancelBooking: (id: string) => void;
  getAppliancePrice: (applianceId: string) => number;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

const STORAGE_KEY = "repair_bookings";

// Sample default bookings
const defaultBookings: Booking[] = [
  {
    id: "booking-1",
    applianceId: "refrigerator",
    applianceName: "Refrigerator",
    issue: "Not cooling properly",
    issueDescription: "The fridge is not maintaining cold temperature. Food is spoiling quickly.",
    date: "2025-12-28",
    timeSlot: "10:00 AM - 11:00 AM",
    price: 89,
    status: "confirmed",
    createdAt: "2025-12-24T10:30:00Z",
    customerName: "John Smith",
    customerEmail: "john@example.com",
    customerPhone: "(555) 123-4567",
    address: "123 Main Street, Apt 4B, New York, NY 10001",
  },
  {
    id: "booking-2",
    applianceId: "washing-machine",
    applianceName: "Washing Machine",
    issue: "Not draining",
    issueDescription: "Water remains in the drum after wash cycle completes.",
    date: "2025-12-30",
    timeSlot: "2:00 PM - 3:00 PM",
    price: 79,
    status: "pending",
    createdAt: "2025-12-23T14:15:00Z",
    customerName: "John Smith",
    customerEmail: "john@example.com",
    customerPhone: "(555) 123-4567",
    address: "123 Main Street, Apt 4B, New York, NY 10001",
  },
];

export const BookingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [currentBooking, setCurrentBooking] = useState<BookingFormData | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      setBookings(JSON.parse(stored));
    } else {
      // Initialize with default bookings
      setBookings(defaultBookings);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultBookings));
    }
  }, []);

  const saveBookings = (newBookings: Booking[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newBookings));
    setBookings(newBookings);
  };

  const addBooking = (booking: Omit<Booking, "id" | "createdAt">) => {
    const newBooking: Booking = {
      ...booking,
      id: `booking-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    saveBookings([...bookings, newBooking]);
  };

  const cancelBooking = (id: string) => {
    const updated = bookings.map((b) =>
      b.id === id ? { ...b, status: "cancelled" as const } : b
    );
    saveBookings(updated);
  };

  const getAppliancePrice = (applianceId: string): number => {
    const appliance = appliances.find((a) => a.id === applianceId);
    return appliance?.basePrice || 0;
  };

  return (
    <BookingContext.Provider
      value={{
        bookings,
        currentBooking,
        setCurrentBooking,
        addBooking,
        cancelBooking,
        getAppliancePrice,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error("useBooking must be used within a BookingProvider");
  }
  return context;
};
