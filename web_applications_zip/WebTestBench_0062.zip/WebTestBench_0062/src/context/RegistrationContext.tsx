import React, { createContext, useContext, useState, useEffect } from 'react';
import { Course } from '@/data/courses';

export interface Registration {
  id: string;
  courseId: string;
  courseName: string;
  userName: string;
  userEmail: string;
  registeredAt: string;
}

interface RegistrationContextType {
  registrations: Registration[];
  registerForCourse: (course: Course, userName: string, userEmail: string) => void;
  isRegistered: (courseId: string) => boolean;
  getRegistrationCount: (courseId: string) => number;
}

const RegistrationContext = createContext<RegistrationContextType | undefined>(undefined);

const STORAGE_KEY = 'course_registrations';

export const RegistrationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [registrations, setRegistrations] = useState<Registration[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(registrations));
  }, [registrations]);

  const registerForCourse = (course: Course, userName: string, userEmail: string) => {
    const newRegistration: Registration = {
      id: `reg_${Date.now()}`,
      courseId: course.id,
      courseName: course.title,
      userName,
      userEmail,
      registeredAt: new Date().toISOString(),
    };
    setRegistrations((prev) => [...prev, newRegistration]);
  };

  const isRegistered = (courseId: string) => {
    return registrations.some((reg) => reg.courseId === courseId);
  };

  const getRegistrationCount = (courseId: string) => {
    return registrations.filter((reg) => reg.courseId === courseId).length;
  };

  return (
    <RegistrationContext.Provider
      value={{ registrations, registerForCourse, isRegistered, getRegistrationCount }}
    >
      {children}
    </RegistrationContext.Provider>
  );
};

export const useRegistration = () => {
  const context = useContext(RegistrationContext);
  if (!context) {
    throw new Error('useRegistration must be used within a RegistrationProvider');
  }
  return context;
};
