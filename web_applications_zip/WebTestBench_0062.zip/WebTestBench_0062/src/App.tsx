import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { RegistrationProvider } from "@/context/RegistrationContext";
import Header from "@/components/Header";
import Index from "./pages/Index";
import MyRegistrations from "./pages/MyRegistrations";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <RegistrationProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="flex min-h-screen flex-col">
            <Header />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/my-registrations" element={<MyRegistrations />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </BrowserRouter>
      </RegistrationProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
