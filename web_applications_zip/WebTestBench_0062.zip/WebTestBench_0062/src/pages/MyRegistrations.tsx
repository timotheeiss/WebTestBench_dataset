import { Link } from 'react-router-dom';
import { Calendar, Mail, User, ArrowRight, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useRegistration } from '@/context/RegistrationContext';
import { courses } from '@/data/courses';

const MyRegistrations = () => {
  const { registrations } = useRegistration();

  const getCourseByCourseId = (courseId: string) => {
    return courses.find((c) => c.id === courseId);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <main className="min-h-screen py-12 md:py-16">
      <div className="container">
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
            My Registrations
          </h1>
          <p className="mt-2 text-muted-foreground">
            View and manage your course registrations
          </p>
        </div>

        {registrations.length > 0 ? (
          <div className="grid gap-4">
            {registrations.map((registration, index) => {
              const course = getCourseByCourseId(registration.courseId);
              return (
                <Card
                  key={registration.id}
                  className="overflow-hidden transition-all duration-300 hover:shadow-md animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex flex-col md:flex-row">
                    {course && (
                      <div className="relative h-48 w-full md:h-auto md:w-64 shrink-0">
                        <img
                          src={course.image}
                          alt={course.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    <div className="flex flex-1 flex-col">
                      <CardHeader>
                        <CardTitle className="font-serif text-xl">
                          {registration.courseName}
                        </CardTitle>
                        <CardDescription>
                          {course?.instructor && `Instructor: ${course.instructor}`}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <User className="h-4 w-4" />
                            <span>{registration.userName}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Mail className="h-4 w-4" />
                            <span>{registration.userEmail}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            <span>Registered: {formatDate(registration.registeredAt)}</span>
                          </div>
                        </div>
                        {course && (
                          <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                            <span className="rounded-md bg-muted px-2 py-1">
                              {course.schedule}
                            </span>
                            <span className="rounded-md bg-muted px-2 py-1">
                              {course.duration}
                            </span>
                          </div>
                        )}
                      </CardContent>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="py-16 text-center">
            <CardContent className="flex flex-col items-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <BookOpen className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold text-foreground">
                No registrations yet
              </h3>
              <p className="mb-6 max-w-md text-muted-foreground">
                You haven't registered for any courses yet. Browse our catalog to find the perfect
                course for you.
              </p>
              <Button variant="accent" asChild>
                <Link to="/">
                  Browse Courses
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
};

export default MyRegistrations;
