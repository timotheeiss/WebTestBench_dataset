import { Link, useLocation } from 'react-router-dom';
import { GraduationCap, BookOpen, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRegistration } from '@/context/RegistrationContext';

const Header = () => {
  const location = useLocation();
  const { registrations } = useRegistration();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-serif text-xl font-semibold text-foreground">LearnHub</span>
        </Link>

        <nav className="flex items-center gap-1">
          <Button
            variant={location.pathname === '/' ? 'secondary' : 'ghost'}
            asChild
            className="gap-2"
          >
            <Link to="/">
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Courses</span>
            </Link>
          </Button>
          <Button
            variant={location.pathname === '/my-registrations' ? 'secondary' : 'ghost'}
            asChild
            className="gap-2"
          >
            <Link to="/my-registrations">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">My Registrations</span>
              {registrations.length > 0 && (
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground">
                  {registrations.length}
                </span>
              )}
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
