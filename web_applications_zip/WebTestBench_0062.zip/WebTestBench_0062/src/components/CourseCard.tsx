import { Calendar, Clock, Users, User, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Course } from '@/data/courses';
import { useRegistration } from '@/context/RegistrationContext';

interface CourseCardProps {
  course: Course;
  onRegister: (course: Course) => void;
  index: number;
}

const levelColors = {
  Beginner: 'bg-success/10 text-success border-success/20',
  Intermediate: 'bg-accent/10 text-accent border-accent/20',
  Advanced: 'bg-primary/10 text-primary border-primary/20',
};

const CourseCard = ({ course, onRegister, index }: CourseCardProps) => {
  const { isRegistered, getRegistrationCount } = useRegistration();
  const registered = isRegistered(course.id);
  const registrationCount = getRegistrationCount(course.id);
  const actualAvailableSeats = course.availableSeats - registrationCount;
  const seatsLow = actualAvailableSeats <= 5 && actualAvailableSeats > 0;
  const soldOut = actualAvailableSeats <= 0;

  return (
    <article
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={course.image}
          alt={course.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
          <Badge variant="secondary" className={levelColors[course.level]}>
            {course.level}
          </Badge>
          <span className="rounded-md bg-background/90 px-2 py-1 text-sm font-semibold text-foreground backdrop-blur-sm">
            ${course.price}
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <div className="mb-2">
          <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
            {course.category}
          </Badge>
        </div>

        <h3 className="mb-2 font-serif text-lg font-semibold leading-tight text-card-foreground line-clamp-2">
          {course.title}
        </h3>

        <p className="mb-4 text-sm text-muted-foreground line-clamp-2">
          {course.description}
        </p>

        <div className="mt-auto space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <User className="h-4 w-4 shrink-0" />
            <span className="truncate">{course.instructor}</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4 shrink-0" />
            <span className="truncate">{course.schedule}</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4 shrink-0" />
            <span>{course.duration}</span>
          </div>

          <div className="flex items-center gap-2 text-sm">
            <Users className="h-4 w-4 shrink-0 text-muted-foreground" />
            {soldOut ? (
              <span className="font-medium text-destructive">Sold out</span>
            ) : seatsLow ? (
              <span className="font-medium text-accent">
                Only {actualAvailableSeats} seats left!
              </span>
            ) : (
              <span className="text-muted-foreground">
                {actualAvailableSeats} of {course.totalSeats} seats available
              </span>
            )}
          </div>

          <Button
            variant={registered ? 'success' : soldOut ? 'secondary' : 'accent'}
            className="w-full mt-2"
            onClick={() => onRegister(course)}
            disabled={registered || soldOut}
          >
            {registered ? (
              'Registered ✓'
            ) : soldOut ? (
              'Sold Out'
            ) : (
              <>
                Register Now
                <ChevronRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </div>
    </article>
  );
};

export default CourseCard;
