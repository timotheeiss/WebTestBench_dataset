export interface Course {
  id: string;
  title: string;
  instructor: string;
  description: string;
  schedule: string;
  duration: string;
  availableSeats: number;
  totalSeats: number;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  price: number;
  image: string;
}

export const courses: Course[] = [
  {
    id: '1',
    title: 'Introduction to Web Development',
    instructor: 'Sarah Chen',
    description: 'Learn the fundamentals of HTML, CSS, and JavaScript to build your first website from scratch.',
    schedule: 'Mon & Wed, 6:00 PM - 8:00 PM',
    duration: '8 weeks',
    availableSeats: 12,
    totalSeats: 20,
    category: 'Technology',
    level: 'Beginner',
    price: 299,
    image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=600&fit=crop',
  },
  {
    id: '2',
    title: 'Data Science Fundamentals',
    instructor: 'Dr. Michael Foster',
    description: 'Master Python, statistics, and machine learning basics to kickstart your data science journey.',
    schedule: 'Tue & Thu, 7:00 PM - 9:00 PM',
    duration: '10 weeks',
    availableSeats: 5,
    totalSeats: 15,
    category: 'Technology',
    level: 'Intermediate',
    price: 449,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop',
  },
  {
    id: '3',
    title: 'Digital Marketing Mastery',
    instructor: 'Emma Rodriguez',
    description: 'From SEO to social media, learn how to create and execute winning digital marketing strategies.',
    schedule: 'Sat, 10:00 AM - 1:00 PM',
    duration: '6 weeks',
    availableSeats: 18,
    totalSeats: 25,
    category: 'Marketing',
    level: 'Beginner',
    price: 249,
    image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=800&h=600&fit=crop',
  },
  {
    id: '4',
    title: 'UX/UI Design Principles',
    instructor: 'Alex Thompson',
    description: 'Create beautiful, user-centered designs using industry-standard tools like Figma and Adobe XD.',
    schedule: 'Mon & Fri, 5:30 PM - 7:30 PM',
    duration: '8 weeks',
    availableSeats: 8,
    totalSeats: 18,
    category: 'Design',
    level: 'Intermediate',
    price: 379,
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=600&fit=crop',
  },
  {
    id: '5',
    title: 'Project Management Professional',
    instructor: 'Jennifer Walsh',
    description: 'Prepare for PMP certification while learning agile methodologies and leadership skills.',
    schedule: 'Wed & Fri, 6:00 PM - 8:30 PM',
    duration: '12 weeks',
    availableSeats: 3,
    totalSeats: 20,
    category: 'Business',
    level: 'Advanced',
    price: 599,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=600&fit=crop',
  },
  {
    id: '6',
    title: 'Creative Writing Workshop',
    instructor: 'David Park',
    description: 'Develop your unique voice and storytelling skills through guided exercises and peer feedback.',
    schedule: 'Sun, 2:00 PM - 5:00 PM',
    duration: '6 weeks',
    availableSeats: 10,
    totalSeats: 12,
    category: 'Arts',
    level: 'Beginner',
    price: 199,
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&h=600&fit=crop',
  },
];

export const categories = ['All', 'Technology', 'Marketing', 'Design', 'Business', 'Arts'];
