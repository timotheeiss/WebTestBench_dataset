export type PostCategory = 'safety-alert' | 'lost-and-found' | 'community-event';

export interface User {
  id: string;
  name: string;
  avatar: string;
  neighborhood: string;
  joinedAt: Date;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  content: string;
  createdAt: Date;
}

export interface Post {
  id: string;
  authorId: string;
  title: string;
  content: string;
  category: PostCategory;
  isResolved: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export const CATEGORY_CONFIG: Record<PostCategory, { label: string; icon: string; color: string }> = {
  'safety-alert': {
    label: 'Safety Alert',
    icon: 'AlertTriangle',
    color: 'destructive',
  },
  'lost-and-found': {
    label: 'Lost & Found',
    icon: 'Search',
    color: 'warning',
  },
  'community-event': {
    label: 'Community Event',
    icon: 'Calendar',
    color: 'primary',
  },
};
