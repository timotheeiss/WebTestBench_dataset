import { useState, useMemo } from 'react';
import { Header } from '@/components/Header';
import { FilterBar } from '@/components/FilterBar';
import { PostCard } from '@/components/PostCard';
import { CreatePostDialog } from '@/components/CreatePostDialog';
import { EmptyState } from '@/components/EmptyState';
import { StatsBar } from '@/components/StatsBar';
import { Post, Comment, PostCategory } from '@/types';
import { initialPosts, initialComments, currentUser } from '@/data/mockData';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<PostCategory | null>(null);
  const [showResolved, setShowResolved] = useState(true);
  const { toast } = useToast();

  const filteredPosts = useMemo(() => {
    return posts
      .filter((post) => {
        // Category filter
        if (selectedCategory && post.category !== selectedCategory) return false;

        // Resolved filter
        if (!showResolved && post.isResolved) return false;

        // Search filter
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          return (
            post.title.toLowerCase().includes(query) ||
            post.content.toLowerCase().includes(query)
          );
        }

        return true;
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }, [posts, searchQuery, selectedCategory, showResolved]);

  const handleCreatePost = (title: string, content: string, category: PostCategory) => {
    const newPost: Post = {
      id: `post-${Date.now()}`,
      authorId: currentUser.id,
      title,
      content,
      category,
      isResolved: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    setPosts((prev) => [newPost, ...prev]);
    toast({
      title: 'Post created',
      description: 'Your post has been shared with the neighborhood.',
    });
  };

  const handleToggleResolved = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? { ...post, isResolved: !post.isResolved, updatedAt: new Date() }
          : post
      )
    );

    const post = posts.find((p) => p.id === postId);
    toast({
      title: post?.isResolved ? 'Post reopened' : 'Post resolved',
      description: post?.isResolved
        ? 'This issue has been marked as active again.'
        : 'Great news! This issue has been resolved.',
    });
  };

  const handleAddComment = (postId: string, content: string) => {
    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      postId,
      authorId: currentUser.id,
      content,
      createdAt: new Date(),
    };

    setComments((prev) => [...prev, newComment]);
  };

  return (
    <div className="min-h-screen gradient-warm">
      <Header onCreatePost={() => setIsCreateDialogOpen(true)} />

      <main className="container py-6 space-y-6">
        <div className="space-y-2">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-foreground">
            Neighborhood Feed
          </h2>
          <p className="text-muted-foreground">
            Stay connected with what's happening in Maple Heights
          </p>
        </div>

        <StatsBar posts={posts} comments={comments} />

        <FilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          showResolved={showResolved}
          onShowResolvedChange={setShowResolved}
        />

        <div className="space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                comments={comments}
                onToggleResolved={handleToggleResolved}
                onAddComment={handleAddComment}
              />
            ))
          ) : (
            <EmptyState
              title="No posts found"
              description={
                searchQuery || selectedCategory
                  ? 'Try adjusting your filters or search query.'
                  : "Be the first to share something with your neighborhood!"
              }
              actionLabel={!searchQuery && !selectedCategory ? 'Create First Post' : undefined}
              onAction={!searchQuery && !selectedCategory ? () => setIsCreateDialogOpen(true) : undefined}
            />
          )}
        </div>
      </main>

      <CreatePostDialog
        open={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        onSubmit={handleCreatePost}
      />
    </div>
  );
};

export default Index;
