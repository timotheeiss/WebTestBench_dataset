import { User, Post, Comment } from '@/types';

export const users: User[] = [
  {
    id: 'user-1',
    name: 'Sarah Mitchell',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    neighborhood: 'Maple Heights',
    joinedAt: new Date('2023-06-15'),
  },
  {
    id: 'user-2',
    name: 'Marcus Johnson',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    neighborhood: 'Maple Heights',
    joinedAt: new Date('2023-08-20'),
  },
  {
    id: 'user-3',
    name: 'Elena Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    neighborhood: 'Maple Heights',
    joinedAt: new Date('2024-01-10'),
  },
  {
    id: 'user-4',
    name: 'David Chen',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    neighborhood: 'Maple Heights',
    joinedAt: new Date('2024-02-28'),
  },
];

export const currentUser = users[0];

export const initialPosts: Post[] = [
  {
    id: 'post-1',
    authorId: 'user-2',
    title: 'Suspicious vehicle spotted on Oak Street',
    content: 'A dark blue van has been parked on Oak Street near the playground for the past three evenings. No plates visible from my vantage point. Has anyone else noticed this? Please be vigilant and report any unusual activity.',
    category: 'safety-alert',
    isResolved: false,
    createdAt: new Date('2024-12-09T18:30:00'),
    updatedAt: new Date('2024-12-09T18:30:00'),
  },
  {
    id: 'post-2',
    authorId: 'user-3',
    title: 'Missing orange tabby cat - answers to "Mango"',
    content: 'Our beloved cat Mango escaped through an open window yesterday around 5 PM. He\'s an orange tabby with a white chest and green eyes. Very friendly but might be scared. Last seen near the corner of Elm and 3rd. Please contact me if you spot him!',
    category: 'lost-and-found',
    isResolved: false,
    createdAt: new Date('2024-12-09T14:15:00'),
    updatedAt: new Date('2024-12-09T14:15:00'),
  },
  {
    id: 'post-3',
    authorId: 'user-1',
    title: 'Annual Holiday Block Party - December 21st',
    content: 'Join us for our annual holiday celebration! We\'ll have hot cocoa, carol singing, and a visit from Santa for the kids. Location: Community Center parking lot. Time: 4 PM - 8 PM. Please bring a dish to share if you can. All neighbors welcome!',
    category: 'community-event',
    isResolved: false,
    createdAt: new Date('2024-12-08T10:00:00'),
    updatedAt: new Date('2024-12-08T10:00:00'),
  },
  {
    id: 'post-4',
    authorId: 'user-4',
    title: 'Package thefts reported on Birch Lane',
    content: 'Three neighbors on Birch Lane have had packages stolen from their porches this week. The incidents seem to happen between 2-4 PM when most people are at work. Consider using package lockers or asking neighbors to grab deliveries. I\'m sharing my Ring camera footage with police.',
    category: 'safety-alert',
    isResolved: true,
    createdAt: new Date('2024-12-07T09:45:00'),
    updatedAt: new Date('2024-12-09T11:00:00'),
  },
  {
    id: 'post-5',
    authorId: 'user-2',
    title: 'Found: Set of car keys near dog park',
    content: 'Found a set of Toyota keys with a small flashlight keychain near the entrance to the dog park this morning. They\'re with me - DM if they\'re yours and you can describe the keychain.',
    category: 'lost-and-found',
    isResolved: true,
    createdAt: new Date('2024-12-06T08:20:00'),
    updatedAt: new Date('2024-12-06T16:30:00'),
  },
  {
    id: 'post-6',
    authorId: 'user-3',
    title: 'Neighborhood cleanup day - volunteers needed',
    content: 'Let\'s make our streets shine! We\'re organizing a neighborhood cleanup on Saturday, December 14th from 9 AM to 12 PM. Meet at the community garden. Gloves and bags provided. Coffee and donuts for volunteers!',
    category: 'community-event',
    isResolved: false,
    createdAt: new Date('2024-12-05T15:30:00'),
    updatedAt: new Date('2024-12-05T15:30:00'),
  },
];

export const initialComments: Comment[] = [
  {
    id: 'comment-1',
    postId: 'post-1',
    authorId: 'user-1',
    content: 'I\'ve seen it too! I called the non-emergency police line and they said they\'d send someone to check it out.',
    createdAt: new Date('2024-12-09T19:15:00'),
  },
  {
    id: 'comment-2',
    postId: 'post-1',
    authorId: 'user-4',
    content: 'Thanks for the heads up. I\'ll keep my eyes open during my evening walks.',
    createdAt: new Date('2024-12-09T20:00:00'),
  },
  {
    id: 'comment-3',
    postId: 'post-2',
    authorId: 'user-1',
    content: 'I\'ll keep an eye out for Mango! Hope he comes home soon.',
    createdAt: new Date('2024-12-09T15:00:00'),
  },
  {
    id: 'comment-4',
    postId: 'post-3',
    authorId: 'user-4',
    content: 'Can\'t wait! I\'ll bring my famous apple pie.',
    createdAt: new Date('2024-12-08T12:30:00'),
  },
  {
    id: 'comment-5',
    postId: 'post-4',
    authorId: 'user-3',
    content: 'Update: Police arrested someone matching the description yesterday. Great work everyone for staying vigilant!',
    createdAt: new Date('2024-12-09T11:00:00'),
  },
  {
    id: 'comment-6',
    postId: 'post-5',
    authorId: 'user-4',
    content: 'Those are mine! Thank you so much - I\'ll message you now.',
    createdAt: new Date('2024-12-06T16:30:00'),
  },
];
