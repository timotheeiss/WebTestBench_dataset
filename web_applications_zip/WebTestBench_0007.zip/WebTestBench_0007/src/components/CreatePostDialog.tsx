import { useState } from 'react';
import { AlertTriangle, Search, Calendar, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { PostCategory, CATEGORY_CONFIG } from '@/types';
import { cn } from '@/lib/utils';

interface CreatePostDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (title: string, content: string, category: PostCategory) => void;
}

const categoryOptions: { value: PostCategory; icon: React.ReactNode; description: string }[] = [
  {
    value: 'safety-alert',
    icon: <AlertTriangle className="h-5 w-5" />,
    description: 'Report suspicious activity or safety concerns',
  },
  {
    value: 'lost-and-found',
    icon: <Search className="h-5 w-5" />,
    description: 'Lost pet, item, or found something?',
  },
  {
    value: 'community-event',
    icon: <Calendar className="h-5 w-5" />,
    description: 'Share upcoming events or gatherings',
  },
];

export function CreatePostDialog({ open, onOpenChange, onSubmit }: CreatePostDialogProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<PostCategory>('community-event');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && content.trim()) {
      onSubmit(title.trim(), content.trim(), category);
      setTitle('');
      setContent('');
      setCategory('community-event');
      onOpenChange(false);
    }
  };

  const getCategoryStyles = (cat: PostCategory, isSelected: boolean) => {
    const base = 'flex flex-col gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200';
    
    if (isSelected) {
      if (cat === 'safety-alert') return cn(base, 'border-destructive bg-destructive/5');
      if (cat === 'lost-and-found') return cn(base, 'border-warning bg-warning/5');
      return cn(base, 'border-primary bg-primary/5');
    }
    
    return cn(base, 'border-border hover:border-muted-foreground/50 bg-card');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-background">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Create New Post</DialogTitle>
          <DialogDescription>
            Share something with your neighbors
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-3">
            <Label className="text-sm font-medium">Category</Label>
            <div className="grid gap-3">
              {categoryOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setCategory(option.value)}
                  className={getCategoryStyles(option.value, category === option.value)}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        'p-2 rounded-lg',
                        category === option.value
                          ? option.value === 'safety-alert'
                            ? 'bg-destructive text-destructive-foreground'
                            : option.value === 'lost-and-found'
                            ? 'bg-warning text-warning-foreground'
                            : 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground'
                      )}
                    >
                      {option.icon}
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-sm text-foreground">
                        {CATEGORY_CONFIG[option.value].label}
                      </p>
                      <p className="text-xs text-muted-foreground">{option.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-medium">
              Title
            </Label>
            <Input
              id="title"
              placeholder="Brief summary of your post"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-card"
              maxLength={100}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content" className="text-sm font-medium">
              Details
            </Label>
            <Textarea
              id="content"
              placeholder="Share all the relevant details with your neighbors..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[120px] bg-card"
              maxLength={1000}
            />
          </div>

          <div className="flex gap-3 justify-end pt-2">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="hero" disabled={!title.trim() || !content.trim()}>
              Post to Neighborhood
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
