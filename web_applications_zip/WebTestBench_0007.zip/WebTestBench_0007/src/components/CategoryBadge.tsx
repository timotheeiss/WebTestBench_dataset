import { AlertTriangle, Search, Calendar } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { PostCategory, CATEGORY_CONFIG } from '@/types';

interface CategoryBadgeProps {
  category: PostCategory;
}

const categoryIcons: Record<PostCategory, React.ReactNode> = {
  'safety-alert': <AlertTriangle className="h-3 w-3" />,
  'lost-and-found': <Search className="h-3 w-3" />,
  'community-event': <Calendar className="h-3 w-3" />,
};

const categoryVariants: Record<PostCategory, 'destructive' | 'warning' | 'default'> = {
  'safety-alert': 'destructive',
  'lost-and-found': 'warning',
  'community-event': 'default',
};

export function CategoryBadge({ category }: CategoryBadgeProps) {
  const config = CATEGORY_CONFIG[category];

  return (
    <Badge variant={categoryVariants[category]} className="gap-1">
      {categoryIcons[category]}
      {config.label}
    </Badge>
  );
}
