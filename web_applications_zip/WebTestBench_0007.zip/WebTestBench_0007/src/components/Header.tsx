import { Shield, Bell, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { currentUser } from '@/data/mockData';

interface HeaderProps {
  onCreatePost: () => void;
}

export function Header({ onCreatePost }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow-glow-primary">
            <Shield className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <h1 className="font-display text-lg font-bold text-foreground leading-tight">
              NeighborWatch
            </h1>
            <p className="text-xs text-muted-foreground">Maple Heights</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="hero" size="sm" onClick={onCreatePost} className="gap-2">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">New Post</span>
          </Button>

          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-accent-foreground">
              3
            </span>
          </Button>

          <div className="flex items-center gap-2 rounded-full border border-border bg-card p-1 pr-3 shadow-soft">
            <Avatar className="h-8 w-8">
              <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                {currentUser.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <span className="hidden text-sm font-medium text-foreground sm:inline">
              {currentUser.name.split(' ')[0]}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
