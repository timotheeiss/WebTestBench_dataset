import { Search, Filter, AlertTriangle, Calendar, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PostCategory, CATEGORY_CONFIG } from '@/types';

interface FilterBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: PostCategory | null;
  onCategoryChange: (category: PostCategory | null) => void;
  showResolved: boolean;
  onShowResolvedChange: (show: boolean) => void;
}

const categoryIcons: Record<PostCategory, React.ReactNode> = {
  'safety-alert': <AlertTriangle className="h-3.5 w-3.5" />,
  'lost-and-found': <Search className="h-3.5 w-3.5" />,
  'community-event': <Calendar className="h-3.5 w-3.5" />,
};

export function FilterBar({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  showResolved,
  onShowResolvedChange,
}: FilterBarProps) {
  const categories: PostCategory[] = ['safety-alert', 'lost-and-found', 'community-event'];

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search posts..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10 bg-card border-border shadow-soft focus:shadow-card"
        />
        {searchQuery && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2"
            onClick={() => onSearchChange('')}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Filter:</span>
        </div>

        <Button
          variant={selectedCategory === null ? 'secondary' : 'ghost'}
          size="sm"
          onClick={() => onCategoryChange(null)}
          className="h-8"
        >
          All
        </Button>

        {categories.map((category) => {
          const config = CATEGORY_CONFIG[category];
          const isSelected = selectedCategory === category;

          return (
            <Button
              key={category}
              variant={isSelected ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => onCategoryChange(isSelected ? null : category)}
              className="h-8 gap-1.5"
            >
              {categoryIcons[category]}
              <span className="hidden sm:inline">{config.label}</span>
            </Button>
          );
        })}

        <div className="ml-auto flex items-center gap-2">
          <Button
            variant={showResolved ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => onShowResolvedChange(!showResolved)}
            className="h-8"
          >
            {showResolved ? 'Showing resolved' : 'Hide resolved'}
          </Button>
        </div>
      </div>

      {(searchQuery || selectedCategory) && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {searchQuery && (
            <Badge variant="secondary" className="gap-1">
              "{searchQuery}"
              <button onClick={() => onSearchChange('')} className="ml-1 hover:text-foreground">
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          {selectedCategory && (
            <Badge variant="secondary" className="gap-1">
              {CATEGORY_CONFIG[selectedCategory].label}
              <button onClick={() => onCategoryChange(null)} className="ml-1 hover:text-foreground">
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}
