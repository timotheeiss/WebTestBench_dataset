import { useState } from 'react';
import { MessageCircle, CheckCircle, Clock, ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { CategoryBadge } from '@/components/CategoryBadge';
import { CommentSection } from '@/components/CommentSection';
import { Post, Comment, User } from '@/types';
import { users, currentUser } from '@/data/mockData';
import { formatDistanceToNow } from 'date-fns';

interface PostCardProps {
  post: Post;
  comments: Comment[];
  onToggleResolved: (postId: string) => void;
  onAddComment: (postId: string, content: string) => void;
}

export function PostCard({ post, comments, onToggleResolved, onAddComment }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const author = users.find((u) => u.id === post.authorId);
  const postComments = comments.filter((c) => c.postId === post.id);
  const isOwner = post.authorId === currentUser.id;

  if (!author) return null;

  return (
    <Card
      className={`overflow-hidden transition-all duration-300 animate-fade-in hover:shadow-card ${
        post.isResolved ? 'opacity-75' : ''
      }`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10 ring-2 ring-background shadow-soft">
              <AvatarImage src={author.avatar} alt={author.name} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {author.name.split(' ').map((n) => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="text-sm font-semibold text-foreground">{author.name}</h4>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDistanceToNow(post.createdAt, { addSuffix: true })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <CategoryBadge category={post.category} />
            {post.isResolved && (
              <Badge variant="success" className="gap-1">
                <CheckCircle className="h-3 w-3" />
                Resolved
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        <h3
          className={`font-display text-lg font-semibold mb-2 ${
            post.isResolved ? 'text-muted-foreground line-through' : 'text-foreground'
          }`}
        >
          {post.title}
        </h3>
        <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
          {post.content}
        </p>
      </CardContent>

      <CardFooter className="flex-col gap-3 pt-3 border-t border-border">
        <div className="flex items-center justify-between w-full">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowComments(!showComments)}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <MessageCircle className="h-4 w-4" />
            {postComments.length} {postComments.length === 1 ? 'comment' : 'comments'}
            {showComments ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </Button>

          {(isOwner || post.category === 'safety-alert' || post.category === 'lost-and-found') && (
            <Button
              variant={post.isResolved ? 'ghost' : 'success'}
              size="sm"
              onClick={() => onToggleResolved(post.id)}
              className="gap-2"
            >
              {post.isResolved ? (
                <>
                  <RotateCcw className="h-4 w-4" />
                  Reopen
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Mark Resolved
                </>
              )}
            </Button>
          )}
        </div>

        {showComments && (
          <div className="w-full pt-3 border-t border-border">
            <CommentSection
              postId={post.id}
              comments={postComments}
              onAddComment={onAddComment}
            />
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
