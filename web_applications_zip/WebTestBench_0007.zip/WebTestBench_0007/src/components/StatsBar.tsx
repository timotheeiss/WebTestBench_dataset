import { Users, AlertTriangle, CheckCircle, MessageCircle } from 'lucide-react';
import { Post, Comment } from '@/types';
import { users } from '@/data/mockData';

interface StatsBarProps {
  posts: Post[];
  comments: Comment[];
}

export function StatsBar({ posts, comments }: StatsBarProps) {
  const activeAlerts = posts.filter((p) => p.category === 'safety-alert' && !p.isResolved).length;
  const resolvedPosts = posts.filter((p) => p.isResolved).length;

  const stats = [
    {
      icon: Users,
      label: 'Neighbors',
      value: users.length,
      color: 'text-primary',
    },
    {
      icon: AlertTriangle,
      label: 'Active Alerts',
      value: activeAlerts,
      color: 'text-destructive',
    },
    {
      icon: CheckCircle,
      label: 'Resolved',
      value: resolvedPosts,
      color: 'text-success',
    },
    {
      icon: MessageCircle,
      label: 'Comments',
      value: comments.length,
      color: 'text-muted-foreground',
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex items-center gap-3 rounded-xl bg-card p-4 shadow-soft border border-border"
        >
          <div className={`${stat.color}`}>
            <stat.icon className="h-5 w-5" />
          </div>
          <div>
            <p className="font-display text-xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
