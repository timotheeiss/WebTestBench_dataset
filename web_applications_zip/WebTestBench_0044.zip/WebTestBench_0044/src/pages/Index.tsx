import { useState } from 'react';
import { Header } from '@/components/Header';
import { ApplicationList } from '@/components/ApplicationList';
import { ApplicationForm } from '@/components/ApplicationForm';
import { useApplications } from '@/hooks/useApplications';
import { JobApplication } from '@/types/application';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const { applications, addApplication, updateApplication, deleteApplication } = useApplications();
  const [formOpen, setFormOpen] = useState(false);
  const [editingApplication, setEditingApplication] = useState<JobApplication | null>(null);
  const { toast } = useToast();

  const handleAddClick = () => {
    setEditingApplication(null);
    setFormOpen(true);
  };

  const handleEdit = (application: JobApplication) => {
    setEditingApplication(application);
    setFormOpen(true);
  };

  const handleDelete = (id: string) => {
    deleteApplication(id);
    toast({
      title: 'Application deleted',
      description: 'The application has been removed from your list.',
    });
  };

  const handleSubmit = (data: Omit<JobApplication, 'id'> & { id?: string }) => {
    if (data.id) {
      updateApplication(data.id, data);
      toast({
        title: 'Application updated',
        description: 'Your changes have been saved.',
      });
    } else {
      addApplication(data);
      toast({
        title: 'Application added',
        description: `${data.company} has been added to your list.`,
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header applicationCount={applications.length} onAddClick={handleAddClick} />
      
      <main className="container mx-auto px-4 py-8">
        <ApplicationList
          applications={applications}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onAddClick={handleAddClick}
        />
      </main>

      <ApplicationForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleSubmit}
        editingApplication={editingApplication}
      />
    </div>
  );
};

export default Index;
