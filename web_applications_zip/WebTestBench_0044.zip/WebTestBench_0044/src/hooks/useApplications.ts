import { useState, useCallback } from 'react';
import { JobApplication } from '@/types/application';
import { defaultApplications } from '@/data/defaultApplications';

export function useApplications() {
  const [applications, setApplications] = useState<JobApplication[]>(defaultApplications);

  const addApplication = useCallback((application: Omit<JobApplication, 'id'>) => {
    const newApplication: JobApplication = {
      ...application,
      id: crypto.randomUUID(),
    };
    setApplications((prev) => [newApplication, ...prev]);
  }, []);

  const updateApplication = useCallback((id: string, updates: Partial<JobApplication>) => {
    setApplications((prev) =>
      prev.map((app) => (app.id === id ? { ...app, ...updates } : app))
    );
  }, []);

  const deleteApplication = useCallback((id: string) => {
    setApplications((prev) => prev.filter((app) => app.id !== id));
  }, []);

  return {
    applications,
    addApplication,
    updateApplication,
    deleteApplication,
  };
}
