import { JobApplication } from '@/types/application';

export const defaultApplications: JobApplication[] = [
  {
    id: '1',
    company: 'Stripe',
    role: 'Senior Frontend Engineer',
    dateApplied: '2024-01-15',
    status: 'interviewed',
    notes: 'Had a great call with the hiring manager. Technical interview scheduled for next week.',
  },
  {
    id: '2',
    company: 'Notion',
    role: 'Product Designer',
    dateApplied: '2024-01-10',
    status: 'applied',
    notes: 'Applied through their careers page. Waiting to hear back.',
  },
  {
    id: '3',
    company: 'Linear',
    role: 'Full Stack Developer',
    dateApplied: '2024-01-08',
    status: 'offered',
    notes: 'Received offer! Need to respond by end of week. Great team culture.',
  },
  {
    id: '4',
    company: 'Figma',
    role: 'Software Engineer',
    dateApplied: '2024-01-05',
    status: 'rejected',
    notes: 'Position was filled internally. Recruiter suggested applying again in 6 months.',
  },
];
