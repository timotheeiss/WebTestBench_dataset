export type ApplicationStatus = 'applied' | 'interviewed' | 'offered' | 'rejected';

export interface JobApplication {
  id: string;
  company: string;
  role: string;
  dateApplied: string;
  status: ApplicationStatus;
  notes: string;
}
