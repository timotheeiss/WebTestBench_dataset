import { JobApplication } from '@/types/application';
import { ApplicationCard } from './ApplicationCard';
import { EmptyState } from './EmptyState';

interface ApplicationListProps {
  applications: JobApplication[];
  onEdit: (application: JobApplication) => void;
  onDelete: (id: string) => void;
  onAddClick: () => void;
}

export function ApplicationList({
  applications,
  onEdit,
  onDelete,
  onAddClick,
}: ApplicationListProps) {
  if (applications.length === 0) {
    return <EmptyState onAddClick={onAddClick} />;
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {applications.map((application, index) => (
        <div
          key={application.id}
          style={{ animationDelay: `${index * 50}ms` }}
        >
          <ApplicationCard
            application={application}
            onEdit={onEdit}
            onDelete={onDelete}
          />
        </div>
      ))}
    </div>
  );
}
