import { Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  onAddClick: () => void;
}

export function EmptyState({ onAddClick }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Briefcase className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">
        No applications yet
      </h3>
      <p className="text-muted-foreground mb-6 max-w-sm">
        Start tracking your job search by adding your first application.
      </p>
      <Button onClick={onAddClick}>Add Your First Application</Button>
    </div>
  );
}
