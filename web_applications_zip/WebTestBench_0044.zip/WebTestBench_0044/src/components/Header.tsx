import { Briefcase, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  applicationCount: number;
  onAddClick: () => void;
}

export function Header({ applicationCount, onAddClick }: HeaderProps) {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Briefcase className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-semibold text-lg text-foreground">Job Tracker</h1>
            <p className="text-sm text-muted-foreground">
              {applicationCount} application{applicationCount !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
        <Button onClick={onAddClick} className="gap-2">
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add Application</span>
          <span className="sm:hidden">Add</span>
        </Button>
      </div>
    </header>
  );
}
