import { ApplicationStatus } from '@/types/application';
import { cn } from '@/lib/utils';

interface StatusBadgeProps {
  status: ApplicationStatus;
  className?: string;
}

const statusConfig: Record<ApplicationStatus, { label: string; className: string }> = {
  applied: {
    label: 'Applied',
    className: 'status-applied',
  },
  interviewed: {
    label: 'Interviewed',
    className: 'status-interviewed',
  },
  offered: {
    label: 'Offered',
    className: 'status-offered',
  },
  rejected: {
    label: 'Rejected',
    className: 'status-rejected',
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border',
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
}
