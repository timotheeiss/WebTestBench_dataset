export type FieldType = 'text' | 'number' | 'date' | 'select' | 'textarea';

export interface FieldDefinition {
  id: string;
  name: string;
  type: FieldType;
  required: boolean;
  options?: string[]; // For select type
  placeholder?: string;
}

export interface Template {
  id: string;
  name: string;
  description: string;
  fields: FieldDefinition[];
  createdAt: string;
  updatedAt: string;
}

export interface Record {
  id: string;
  templateId: string;
  data: { [fieldId: string]: string | number | null };
  createdAt: string;
  updatedAt: string;
}

export type ViewMode = 'table' | 'form';
