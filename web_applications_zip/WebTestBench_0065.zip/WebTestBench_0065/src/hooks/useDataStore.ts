import { useState, useCallback } from 'react';
import { Template, Record } from '@/types';
import { defaultTemplates, defaultRecords } from '@/data/defaultData';

export function useDataStore() {
  const [templates, setTemplates] = useState<Template[]>(defaultTemplates);
  const [records, setRecords] = useState<Record[]>(defaultRecords);

  // Template operations
  const addTemplate = useCallback((template: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newTemplate: Template = {
      ...template,
      id: `tpl-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    setTemplates(prev => [...prev, newTemplate]);
    return newTemplate;
  }, []);

  const updateTemplate = useCallback((id: string, updates: Partial<Omit<Template, 'id' | 'createdAt'>>) => {
    setTemplates(prev => prev.map(t => 
      t.id === id 
        ? { ...t, ...updates, updatedAt: new Date().toISOString() }
        : t
    ));
  }, []);

  const deleteTemplate = useCallback((id: string) => {
    setTemplates(prev => prev.filter(t => t.id !== id));
    setRecords(prev => prev.filter(r => r.templateId !== id));
  }, []);

  const getTemplate = useCallback((id: string) => {
    return templates.find(t => t.id === id);
  }, [templates]);

  // Record operations
  const addRecord = useCallback((record: Omit<Record, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newRecord: Record = {
      ...record,
      id: `rec-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    setRecords(prev => [...prev, newRecord]);
    return newRecord;
  }, []);

  const updateRecord = useCallback((id: string, updates: Partial<Omit<Record, 'id' | 'createdAt'>>) => {
    setRecords(prev => prev.map(r => 
      r.id === id 
        ? { ...r, ...updates, updatedAt: new Date().toISOString() }
        : r
    ));
  }, []);

  const deleteRecord = useCallback((id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
  }, []);

  const getRecordsByTemplate = useCallback((templateId: string) => {
    return records.filter(r => r.templateId === templateId);
  }, [records]);

  const getRecord = useCallback((id: string) => {
    return records.find(r => r.id === id);
  }, [records]);

  return {
    templates,
    records,
    addTemplate,
    updateTemplate,
    deleteTemplate,
    getTemplate,
    addRecord,
    updateRecord,
    deleteRecord,
    getRecordsByTemplate,
    getRecord,
  };
}
