import { useState, useCallback } from 'react';
import { Toaster, toast } from 'sonner';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';
import { TemplateBuilder } from '@/components/templates/TemplateBuilder';
import { RecordsTable } from '@/components/records/RecordsTable';
import { RecordForm } from '@/components/records/RecordForm';
import { RecordDetail } from '@/components/records/RecordDetail';
import { EmptyState } from '@/components/EmptyState';
import { useDataStore } from '@/hooks/useDataStore';
import { Template, Record as DataRecord } from '@/types';

type View = 
  | { type: 'empty' }
  | { type: 'template-builder'; template?: Template }
  | { type: 'records'; templateId: string }
  | { type: 'record-form'; templateId: string; record?: DataRecord }
  | { type: 'record-detail'; templateId: string; recordId: string };

export default function Index() {
  const {
    templates,
    addTemplate,
    updateTemplate,
    deleteTemplate,
    getTemplate,
    addRecord,
    updateRecord,
    deleteRecord,
    getRecordsByTemplate,
    getRecord,
  } = useDataStore();

  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(
    templates.length > 0 ? templates[0].id : null
  );
  const [view, setView] = useState<View>(
    templates.length > 0 
      ? { type: 'records', templateId: templates[0].id }
      : { type: 'empty' }
  );

  // Template handlers
  const handleCreateTemplate = useCallback(() => {
    setView({ type: 'template-builder' });
  }, []);

  const handleEditTemplate = useCallback((template: Template) => {
    setView({ type: 'template-builder', template });
  }, []);

  const handleSaveTemplate = useCallback((data: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (view.type === 'template-builder' && view.template) {
      updateTemplate(view.template.id, data);
      toast.success('Template updated');
      setView({ type: 'records', templateId: view.template.id });
    } else {
      const newTemplate = addTemplate(data);
      toast.success('Template created');
      setSelectedTemplateId(newTemplate.id);
      setView({ type: 'records', templateId: newTemplate.id });
    }
  }, [view, addTemplate, updateTemplate]);

  const handleDeleteTemplate = useCallback((id: string) => {
    deleteTemplate(id);
    toast.success('Template deleted');
    const remaining = templates.filter(t => t.id !== id);
    if (remaining.length > 0) {
      setSelectedTemplateId(remaining[0].id);
      setView({ type: 'records', templateId: remaining[0].id });
    } else {
      setSelectedTemplateId(null);
      setView({ type: 'empty' });
    }
  }, [templates, deleteTemplate]);

  const handleSelectTemplate = useCallback((id: string) => {
    setSelectedTemplateId(id);
    setView({ type: 'records', templateId: id });
  }, []);

  // Record handlers
  const handleAddRecord = useCallback((templateId: string) => {
    setView({ type: 'record-form', templateId });
  }, []);

  const handleEditRecord = useCallback((templateId: string, record: DataRecord) => {
    setView({ type: 'record-form', templateId, record });
  }, []);

  const handleViewRecord = useCallback((templateId: string, record: DataRecord) => {
    setView({ type: 'record-detail', templateId, recordId: record.id });
  }, []);

  const handleSaveRecord = useCallback((templateId: string, data: { [fieldId: string]: string | number | null }, record?: DataRecord) => {
    if (record) {
      updateRecord(record.id, { data });
      toast.success('Record updated');
    } else {
      addRecord({ templateId, data });
      toast.success('Record created');
    }
    setView({ type: 'records', templateId });
  }, [addRecord, updateRecord]);

  const handleDeleteRecord = useCallback((templateId: string, recordId: string) => {
    deleteRecord(recordId);
    toast.success('Record deleted');
    setView({ type: 'records', templateId });
  }, [deleteRecord]);

  const handleNavigateRecord = useCallback((templateId: string, recordId: string) => {
    if (view.type === 'record-detail') {
      setView({ type: 'record-detail', templateId, recordId });
    } else if (view.type === 'record-form') {
      const record = getRecord(recordId);
      if (record) {
        setView({ type: 'record-form', templateId, record });
      }
    }
  }, [view, getRecord]);

  // Render main content
  const renderContent = () => {
    if (view.type === 'empty') {
      return <EmptyState onCreateTemplate={handleCreateTemplate} />;
    }

    if (view.type === 'template-builder') {
      return (
        <TemplateBuilder
          template={view.template}
          onSave={handleSaveTemplate}
          onCancel={() => {
            if (selectedTemplateId) {
              setView({ type: 'records', templateId: selectedTemplateId });
            } else {
              setView({ type: 'empty' });
            }
          }}
        />
      );
    }

    if (view.type === 'records') {
      const template = getTemplate(view.templateId);
      if (!template) return null;
      const records = getRecordsByTemplate(view.templateId);

      return (
        <RecordsTable
          template={template}
          records={records}
          onAddRecord={() => handleAddRecord(view.templateId)}
          onEditRecord={(record) => handleEditRecord(view.templateId, record)}
          onDeleteRecord={(id) => handleDeleteRecord(view.templateId, id)}
          onViewRecord={(record) => handleViewRecord(view.templateId, record)}
          onEditTemplate={() => handleEditTemplate(template)}
          onDeleteTemplate={() => handleDeleteTemplate(view.templateId)}
        />
      );
    }

    if (view.type === 'record-form') {
      const template = getTemplate(view.templateId);
      if (!template) return null;
      const allRecords = getRecordsByTemplate(view.templateId);

      return (
        <RecordForm
          template={template}
          record={view.record}
          allRecords={allRecords}
          onSave={(data) => handleSaveRecord(view.templateId, data, view.record)}
          onClose={() => setView({ type: 'records', templateId: view.templateId })}
          onNavigate={(recordId) => handleNavigateRecord(view.templateId, recordId)}
        />
      );
    }

    if (view.type === 'record-detail') {
      const template = getTemplate(view.templateId);
      const record = getRecord(view.recordId);
      if (!template || !record) return null;
      const allRecords = getRecordsByTemplate(view.templateId);

      return (
        <RecordDetail
          template={template}
          record={record}
          allRecords={allRecords}
          onClose={() => setView({ type: 'records', templateId: view.templateId })}
          onEdit={() => handleEditRecord(view.templateId, record)}
          onDelete={() => handleDeleteRecord(view.templateId, view.recordId)}
          onNavigate={(recordId) => handleNavigateRecord(view.templateId, recordId)}
        />
      );
    }

    return null;
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          templates={templates}
          selectedTemplateId={selectedTemplateId}
          onSelectTemplate={handleSelectTemplate}
          onCreateTemplate={handleCreateTemplate}
        />
        <main className="flex-1 overflow-hidden">
          {renderContent()}
        </main>
      </div>
      <Toaster position="bottom-right" />
    </div>
  );
}
