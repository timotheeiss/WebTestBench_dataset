import { FileText, Plus, LayoutGrid } from 'lucide-react';
import { Template } from '@/types';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SidebarProps {
  templates: Template[];
  selectedTemplateId: string | null;
  onSelectTemplate: (id: string) => void;
  onCreateTemplate: () => void;
}

export function Sidebar({ 
  templates, 
  selectedTemplateId, 
  onSelectTemplate,
  onCreateTemplate 
}: SidebarProps) {
  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <Button 
          onClick={onCreateTemplate} 
          className="w-full justify-start gap-2"
          size="sm"
        >
          <Plus className="w-4 h-4" />
          New Template
        </Button>
      </div>
      
      <div className="flex-1 overflow-auto p-3">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-2 mb-2">
          Templates
        </div>
        
        {templates.length === 0 ? (
          <div className="px-2 py-8 text-center">
            <LayoutGrid className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No templates yet</p>
            <p className="text-xs text-muted-foreground/70">Create one to get started</p>
          </div>
        ) : (
          <nav className="space-y-1">
            {templates.map(template => (
              <button
                key={template.id}
                onClick={() => onSelectTemplate(template.id)}
                className={cn(
                  "w-full text-left px-3 py-2.5 rounded-md transition-colors duration-150",
                  "flex items-start gap-3 group",
                  selectedTemplateId === template.id
                    ? "bg-primary/10 text-primary"
                    : "text-foreground hover:bg-muted"
                )}
              >
                <FileText className={cn(
                  "w-4 h-4 mt-0.5 shrink-0",
                  selectedTemplateId === template.id 
                    ? "text-primary" 
                    : "text-muted-foreground group-hover:text-foreground"
                )} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{template.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {template.fields.length} field{template.fields.length !== 1 ? 's' : ''}
                  </div>
                </div>
              </button>
            ))}
          </nav>
        )}
      </div>
    </aside>
  );
}
