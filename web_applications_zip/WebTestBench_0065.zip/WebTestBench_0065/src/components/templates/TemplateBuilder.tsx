import { useState } from 'react';
import { Plus, Trash2, GripVertical, X } from 'lucide-react';
import { Template, FieldDefinition, FieldType } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';

interface TemplateBuilderProps {
  template?: Template;
  onSave: (template: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
}

const fieldTypes: { value: FieldType; label: string }[] = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'date', label: 'Date' },
  { value: 'select', label: 'Dropdown' },
  { value: 'textarea', label: 'Long Text' },
];

export function TemplateBuilder({ template, onSave, onCancel }: TemplateBuilderProps) {
  const [name, setName] = useState(template?.name || '');
  const [description, setDescription] = useState(template?.description || '');
  const [fields, setFields] = useState<FieldDefinition[]>(
    template?.fields || []
  );

  const addField = () => {
    const newField: FieldDefinition = {
      id: `field-${Date.now()}`,
      name: '',
      type: 'text',
      required: false,
    };
    setFields([...fields, newField]);
  };

  const updateField = (id: string, updates: Partial<FieldDefinition>) => {
    setFields(fields.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const removeField = (id: string) => {
    setFields(fields.filter(f => f.id !== id));
  };

  const handleSave = () => {
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      description: description.trim(),
      fields: fields.filter(f => f.name.trim()),
    });
  };

  const isValid = name.trim() && fields.some(f => f.name.trim());

  return (
    <div className="h-full flex flex-col bg-background animate-fade-in">
      <div className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">
            {template ? 'Edit Template' : 'Create New Template'}
          </h2>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-2xl space-y-6">
          {/* Basic Info */}
          <section className="space-y-4">
            <div>
              <Label htmlFor="template-name">Template Name</Label>
              <Input
                id="template-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Cell Culture Experiment"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="template-desc">Description (optional)</Label>
              <Textarea
                id="template-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Briefly describe what this template is for..."
                className="mt-1.5 resize-none"
                rows={2}
              />
            </div>
          </section>

          {/* Fields */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <Label>Fields</Label>
              <Button variant="outline" size="sm" onClick={addField}>
                <Plus className="w-4 h-4 mr-1" />
                Add Field
              </Button>
            </div>

            {fields.length === 0 ? (
              <div className="border border-dashed border-border rounded-lg p-8 text-center">
                <p className="text-sm text-muted-foreground">
                  No fields yet. Add fields to define your template structure.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {fields.map((field, index) => (
                  <div
                    key={field.id}
                    className="bg-card border border-border rounded-lg p-4 animate-slide-up"
                  >
                    <div className="flex items-start gap-3">
                      <div className="pt-2 text-muted-foreground cursor-grab">
                        <GripVertical className="w-4 h-4" />
                      </div>
                      
                      <div className="flex-1 grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-xs text-muted-foreground">Field Name</Label>
                          <Input
                            value={field.name}
                            onChange={(e) => updateField(field.id, { name: e.target.value })}
                            placeholder="e.g., Sample ID"
                            className="mt-1"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-xs text-muted-foreground">Type</Label>
                          <Select
                            value={field.type}
                            onValueChange={(value: FieldType) => updateField(field.id, { type: value })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {fieldTypes.map(type => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {field.type === 'select' && (
                          <div className="col-span-2">
                            <Label className="text-xs text-muted-foreground">
                              Options (comma-separated)
                            </Label>
                            <Input
                              value={field.options?.join(', ') || ''}
                              onChange={(e) => updateField(field.id, { 
                                options: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                              })}
                              placeholder="Option 1, Option 2, Option 3"
                              className="mt-1"
                            />
                          </div>
                        )}

                        <div className="col-span-2">
                          <Label className="text-xs text-muted-foreground">Placeholder (optional)</Label>
                          <Input
                            value={field.placeholder || ''}
                            onChange={(e) => updateField(field.id, { placeholder: e.target.value })}
                            placeholder="Hint text for this field..."
                            className="mt-1"
                          />
                        </div>

                        <div className="col-span-2 flex items-center gap-2">
                          <Checkbox
                            id={`required-${field.id}`}
                            checked={field.required}
                            onCheckedChange={(checked) => updateField(field.id, { required: !!checked })}
                          />
                          <Label htmlFor={`required-${field.id}`} className="text-sm cursor-pointer">
                            Required field
                          </Label>
                        </div>
                      </div>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-muted-foreground hover:text-destructive"
                        onClick={() => removeField(field.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-border bg-card px-6 py-4">
        <div className="flex items-center justify-end gap-3">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!isValid}>
            {template ? 'Save Changes' : 'Create Template'}
          </Button>
        </div>
      </div>
    </div>
  );
}
