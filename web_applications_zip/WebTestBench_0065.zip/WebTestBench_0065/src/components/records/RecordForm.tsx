import { useState, useEffect } from 'react';
import { X, Save, ChevronLeft, ChevronRight } from 'lucide-react';
import { Template, Record as DataRecord } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface RecordFormProps {
  template: Template;
  record?: DataRecord;
  allRecords?: DataRecord[];
  onSave: (data: { [fieldId: string]: string | number | null }) => void;
  onClose: () => void;
  onNavigate?: (recordId: string) => void;
}

export function RecordForm({ 
  template, 
  record, 
  allRecords = [],
  onSave, 
  onClose,
  onNavigate 
}: RecordFormProps) {
  const [formData, setFormData] = useState<{ [fieldId: string]: string | number | null }>({});

  useEffect(() => {
    if (record) {
      setFormData(record.data);
    } else {
      // Initialize empty form
      const initial: { [fieldId: string]: string | number | null } = {};
      template.fields.forEach(field => {
        initial[field.id] = field.type === 'number' ? null : '';
      });
      setFormData(initial);
    }
  }, [record, template]);

  const updateField = (fieldId: string, value: string | number | null) => {
    setFormData(prev => ({ ...prev, [fieldId]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const isValid = template.fields
    .filter(f => f.required)
    .every(f => {
      const value = formData[f.id];
      return value !== null && value !== undefined && value !== '';
    });

  // Navigation
  const currentIndex = record ? allRecords.findIndex(r => r.id === record.id) : -1;
  const canGoPrev = currentIndex > 0;
  const canGoNext = currentIndex >= 0 && currentIndex < allRecords.length - 1;

  const goToPrev = () => {
    if (canGoPrev && onNavigate) {
      onNavigate(allRecords[currentIndex - 1].id);
    }
  };

  const goToNext = () => {
    if (canGoNext && onNavigate) {
      onNavigate(allRecords[currentIndex + 1].id);
    }
  };

  return (
    <div className="h-full flex flex-col bg-background animate-fade-in">
      <div className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">
              {record ? 'Edit Record' : 'New Record'}
            </h2>
            <p className="text-sm text-muted-foreground">{template.name}</p>
          </div>
          <div className="flex items-center gap-2">
            {record && allRecords.length > 1 && (
              <div className="flex items-center gap-1 mr-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={goToPrev}
                  disabled={!canGoPrev}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-muted-foreground min-w-[60px] text-center">
                  {currentIndex + 1} of {allRecords.length}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={goToNext}
                  disabled={!canGoNext}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-xl space-y-5">
            {template.fields.map(field => (
              <div key={field.id}>
                <Label htmlFor={field.id} className="flex items-center gap-1">
                  {field.name}
                  {field.required && <span className="text-destructive">*</span>}
                </Label>
                
                {field.type === 'text' && (
                  <Input
                    id={field.id}
                    value={(formData[field.id] as string) || ''}
                    onChange={(e) => updateField(field.id, e.target.value)}
                    placeholder={field.placeholder}
                    className="mt-1.5"
                  />
                )}

                {field.type === 'number' && (
                  <Input
                    id={field.id}
                    type="number"
                    value={formData[field.id] !== null ? formData[field.id] : ''}
                    onChange={(e) => updateField(
                      field.id, 
                      e.target.value ? parseFloat(e.target.value) : null
                    )}
                    placeholder={field.placeholder}
                    className="mt-1.5"
                  />
                )}

                {field.type === 'date' && (
                  <Input
                    id={field.id}
                    type="date"
                    value={(formData[field.id] as string) || ''}
                    onChange={(e) => updateField(field.id, e.target.value)}
                    className="mt-1.5"
                  />
                )}

                {field.type === 'textarea' && (
                  <Textarea
                    id={field.id}
                    value={(formData[field.id] as string) || ''}
                    onChange={(e) => updateField(field.id, e.target.value)}
                    placeholder={field.placeholder}
                    className="mt-1.5 resize-none"
                    rows={3}
                  />
                )}

                {field.type === 'select' && (
                  <Select
                    value={(formData[field.id] as string) || ''}
                    onValueChange={(value) => updateField(field.id, value)}
                  >
                    <SelectTrigger className="mt-1.5">
                      <SelectValue placeholder="Select an option..." />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options?.map(option => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-border bg-card px-6 py-4">
          <div className="flex items-center justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!isValid}>
              <Save className="w-4 h-4 mr-1" />
              {record ? 'Save Changes' : 'Create Record'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
