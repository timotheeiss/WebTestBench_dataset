import { X, Edit2, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Template, Record as DataRecord } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface RecordDetailProps {
  template: Template;
  record: DataRecord;
  allRecords: DataRecord[];
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onNavigate: (recordId: string) => void;
}

export function RecordDetail({
  template,
  record,
  allRecords,
  onClose,
  onEdit,
  onDelete,
  onNavigate,
}: RecordDetailProps) {
  const formatValue = (value: string | number | null, type: string): string => {
    if (value === null || value === undefined || value === '') return '—';
    if (type === 'date' && typeof value === 'string') {
      return new Date(value).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    }
    return String(value);
  };

  const formatDateTime = (dateString: string): string => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  const currentIndex = allRecords.findIndex(r => r.id === record.id);
  const canGoPrev = currentIndex > 0;
  const canGoNext = currentIndex < allRecords.length - 1;

  return (
    <div className="h-full flex flex-col bg-background animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Record Details</h2>
            <p className="text-sm text-muted-foreground">{template.name}</p>
          </div>
          <div className="flex items-center gap-2">
            {allRecords.length > 1 && (
              <div className="flex items-center gap-1 mr-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => canGoPrev && onNavigate(allRecords[currentIndex - 1].id)}
                  disabled={!canGoPrev}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-muted-foreground min-w-[60px] text-center">
                  {currentIndex + 1} of {allRecords.length}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => canGoNext && onNavigate(allRecords[currentIndex + 1].id)}
                  disabled={!canGoNext}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-xl space-y-6">
          {template.fields.map(field => (
            <div key={field.id} className="animate-slide-up">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-sm font-medium text-muted-foreground">
                  {field.name}
                </span>
                {field.required && (
                  <Badge variant="secondary" className="text-xs px-1.5 py-0">
                    Required
                  </Badge>
                )}
              </div>
              <div className={`text-base ${
                field.type === 'textarea' ? 'whitespace-pre-wrap' : ''
              }`}>
                {formatValue(record.data[field.id], field.type)}
              </div>
            </div>
          ))}

          {/* Metadata */}
          <div className="pt-6 border-t border-border space-y-3">
            <div>
              <span className="text-sm font-medium text-muted-foreground">Created</span>
              <p className="text-sm">{formatDateTime(record.createdAt)}</p>
            </div>
            <div>
              <span className="text-sm font-medium text-muted-foreground">Last Updated</span>
              <p className="text-sm">{formatDateTime(record.updatedAt)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={onDelete} className="text-destructive hover:text-destructive">
              <Trash2 className="w-4 h-4 mr-1" />
              Delete
            </Button>
            <Button onClick={onEdit}>
              <Edit2 className="w-4 h-4 mr-1" />
              Edit Record
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
