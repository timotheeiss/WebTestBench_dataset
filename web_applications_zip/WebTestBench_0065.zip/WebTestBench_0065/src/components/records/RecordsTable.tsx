import { useState } from 'react';
import { Edit2, Trash2, Plus, Eye, Table2, FileText, MoreHorizontal, Settings } from 'lucide-react';
import { Template, Record as DataRecord, ViewMode } from '@/types';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface RecordsTableProps {
  template: Template;
  records: DataRecord[];
  onAddRecord: () => void;
  onEditRecord: (record: DataRecord) => void;
  onDeleteRecord: (id: string) => void;
  onViewRecord: (record: DataRecord) => void;
  onEditTemplate: () => void;
  onDeleteTemplate: () => void;
}

export function RecordsTable({
  template,
  records,
  onAddRecord,
  onEditRecord,
  onDeleteRecord,
  onViewRecord,
  onEditTemplate,
  onDeleteTemplate,
}: RecordsTableProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('table');

  const formatValue = (value: string | number | null, type: string): string => {
    if (value === null || value === undefined || value === '') return '—';
    if (type === 'date' && typeof value === 'string') {
      return new Date(value).toLocaleDateString();
    }
    return String(value);
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="h-full flex flex-col animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-semibold">{template.name}</h2>
            {template.description && (
              <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            {/* View Toggle */}
            <div className="flex items-center bg-muted rounded-md p-1">
              <button
                onClick={() => setViewMode('table')}
                className={cn(
                  "px-3 py-1.5 rounded text-sm font-medium transition-colors",
                  viewMode === 'table' 
                    ? "bg-card text-foreground shadow-sm" 
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Table2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('form')}
                className={cn(
                  "px-3 py-1.5 rounded text-sm font-medium transition-colors",
                  viewMode === 'form' 
                    ? "bg-card text-foreground shadow-sm" 
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <FileText className="w-4 h-4" />
              </button>
            </div>

            <Button onClick={onAddRecord} size="sm">
              <Plus className="w-4 h-4 mr-1" />
              Add Record
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={onEditTemplate}>
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit Template
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={onDeleteTemplate}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Template
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {records.length === 0 ? (
          <div className="h-full flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium mb-1">No records yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Create your first record using this template
              </p>
              <Button onClick={onAddRecord}>
                <Plus className="w-4 h-4 mr-1" />
                Add Record
              </Button>
            </div>
          </div>
        ) : viewMode === 'table' ? (
          /* Table View */
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    {template.fields.slice(0, 5).map(field => (
                      <th key={field.id} className="table-header-cell">
                        {field.name}
                      </th>
                    ))}
                    <th className="table-header-cell">Created</th>
                    <th className="table-header-cell w-12"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {records.map(record => (
                    <tr 
                      key={record.id} 
                      className="hover:bg-muted/30 transition-colors cursor-pointer"
                      onClick={() => onViewRecord(record)}
                    >
                      {template.fields.slice(0, 5).map(field => (
                        <td key={field.id} className="table-body-cell max-w-[200px] truncate">
                          {formatValue(record.data[field.id], field.type)}
                        </td>
                      ))}
                      <td className="table-body-cell text-muted-foreground">
                        {formatDate(record.createdAt)}
                      </td>
                      <td className="table-body-cell" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onViewRecord(record)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onEditRecord(record)}>
                              <Edit2 className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              onClick={() => onDeleteRecord(record.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          /* Card/Form View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {records.map(record => (
              <div
                key={record.id}
                className="bg-card border border-border rounded-lg p-4 hover:shadow-elevated transition-shadow cursor-pointer animate-slide-up"
                onClick={() => onViewRecord(record)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">
                      {formatValue(record.data[template.fields[0]?.id], template.fields[0]?.type)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(record.createdAt)}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEditRecord(record); }}>
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={(e) => { e.stopPropagation(); onDeleteRecord(record.id); }}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="space-y-2">
                  {template.fields.slice(1, 4).map(field => (
                    <div key={field.id} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground truncate mr-2">{field.name}</span>
                      <span className="font-medium truncate text-right max-w-[50%]">
                        {formatValue(record.data[field.id], field.type)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Stats */}
      {records.length > 0 && (
        <div className="border-t border-border bg-card px-6 py-3">
          <p className="text-sm text-muted-foreground">
            {records.length} record{records.length !== 1 ? 's' : ''}
          </p>
        </div>
      )}
    </div>
  );
}
