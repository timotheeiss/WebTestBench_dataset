import { FlaskConical, Plus, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  onCreateTemplate: () => void;
}

export function EmptyState({ onCreateTemplate }: EmptyStateProps) {
  return (
    <div className="h-full flex items-center justify-center p-8">
      <div className="max-w-md text-center animate-fade-in">
        <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
          <FlaskConical className="w-10 h-10 text-primary" />
        </div>
        
        <h2 className="text-2xl font-semibold mb-2">Welcome to LabData</h2>
        <p className="text-muted-foreground mb-8">
          Create custom templates to organize your experimental data. Define fields, 
          add records, and view them as tables or individual forms.
        </p>

        <div className="space-y-4">
          <Button onClick={onCreateTemplate} size="lg" className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Template
          </Button>

          <div className="text-sm text-muted-foreground">
            <p className="mb-3">Or select a template from the sidebar to:</p>
            <div className="flex flex-col gap-2 text-left max-w-[200px] mx-auto">
              <div className="flex items-center gap-2">
                <ArrowRight className="w-3 h-3 text-primary shrink-0" />
                <span>Add new data records</span>
              </div>
              <div className="flex items-center gap-2">
                <ArrowRight className="w-3 h-3 text-primary shrink-0" />
                <span>View in table format</span>
              </div>
              <div className="flex items-center gap-2">
                <ArrowRight className="w-3 h-3 text-primary shrink-0" />
                <span>Browse individual forms</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
