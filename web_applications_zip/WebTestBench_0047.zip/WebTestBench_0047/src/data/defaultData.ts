import { DecisionMatrix } from "@/types/decision";

export const defaultDecisionMatrix: DecisionMatrix = {
  topic: "Choosing a New Laptop",
  criteria: [
    { id: "c1", name: "Performance", weight: 30 },
    { id: "c2", name: "Battery Life", weight: 25 },
    { id: "c3", name: "Price", weight: 25 },
    { id: "c4", name: "Build Quality", weight: 20 },
  ],
  options: [
    {
      id: "o1",
      name: "MacBook Pro 14\"",
      scores: { c1: 9, c2: 8, c3: 5, c4: 10 },
    },
    {
      id: "o2",
      name: "Dell XPS 15",
      scores: { c1: 8, c2: 7, c3: 7, c4: 8 },
    },
    {
      id: "o3",
      name: "ThinkPad X1 Carbon",
      scores: { c1: 7, c2: 9, c3: 6, c4: 9 },
    },
  ],
};

export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};
