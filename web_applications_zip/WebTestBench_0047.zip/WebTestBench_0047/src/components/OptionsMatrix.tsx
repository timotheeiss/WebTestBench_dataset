import { useState } from "react";
import { Option, Criterion } from "@/types/decision";
import { generateId } from "@/data/defaultData";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, ChevronUp, ChevronDown, GripVertical } from "lucide-react";

interface OptionsMatrixProps {
  options: Option[];
  criteria: Criterion[];
  onOptionsChange: (options: Option[]) => void;
}

export function OptionsMatrix({ options, criteria, onOptionsChange }: OptionsMatrixProps) {
  const [newOptionName, setNewOptionName] = useState("");

  const calculateWeightedScore = (option: Option): number => {
    const totalWeight = criteria.reduce((sum, c) => sum + c.weight, 0);
    if (totalWeight === 0) return 0;

    const weightedSum = criteria.reduce((sum, criterion) => {
      const score = option.scores[criterion.id] || 0;
      return sum + (score * criterion.weight);
    }, 0);

    return weightedSum / totalWeight;
  };

  const addOption = () => {
    if (!newOptionName.trim()) return;
    const newOption: Option = {
      id: generateId(),
      name: newOptionName.trim(),
      scores: {},
    };
    onOptionsChange([...options, newOption]);
    setNewOptionName("");
  };

  const removeOption = (id: string) => {
    onOptionsChange(options.filter((o) => o.id !== id));
  };

  const updateOptionName = (id: string, name: string) => {
    onOptionsChange(
      options.map((o) => (o.id === id ? { ...o, name } : o))
    );
  };

  const updateScore = (optionId: string, criterionId: string, score: number) => {
    const clampedScore = Math.max(0, Math.min(10, score));
    onOptionsChange(
      options.map((o) =>
        o.id === optionId
          ? { ...o, scores: { ...o.scores, [criterionId]: clampedScore } }
          : o
      )
    );
  };

  const moveOption = (index: number, direction: "up" | "down") => {
    const newIndex = direction === "up" ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= options.length) return;
    const newOptions = [...options];
    [newOptions[index], newOptions[newIndex]] = [newOptions[newIndex], newOptions[index]];
    onOptionsChange(newOptions);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      addOption();
    }
  };

  return (
    <Card className="shadow-sm border-border/50">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold">Options & Scores</CardTitle>
      </CardHeader>
      <CardContent>
        {criteria.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Add criteria first to start scoring options.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground w-8"></th>
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground min-w-[180px]">
                    Option
                  </th>
                  {criteria.map((criterion) => (
                    <th
                      key={criterion.id}
                      className="text-center py-3 px-2 font-medium text-muted-foreground min-w-[100px]"
                    >
                      <div className="flex flex-col items-center">
                        <span className="truncate max-w-[100px]">{criterion.name}</span>
                        <span className="text-xs text-muted-foreground/70">({criterion.weight}%)</span>
                      </div>
                    </th>
                  ))}
                  <th className="text-center py-3 px-2 font-semibold text-primary min-w-[80px]">
                    Score
                  </th>
                  <th className="w-10"></th>
                </tr>
              </thead>
              <tbody>
                {options.map((option, index) => {
                  const weightedScore = calculateWeightedScore(option);
                  return (
                    <tr key={option.id} className="border-b border-border/50 group hover:bg-secondary/30">
                      <td className="py-2 px-2">
                        <div className="flex items-center gap-0.5">
                          <GripVertical className="h-4 w-4 text-muted-foreground/30" />
                          <div className="flex flex-col opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-5 w-5"
                              onClick={() => moveOption(index, "up")}
                              disabled={index === 0}
                            >
                              <ChevronUp className="h-3 w-3" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-5 w-5"
                              onClick={() => moveOption(index, "down")}
                              disabled={index === options.length - 1}
                            >
                              <ChevronDown className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </td>
                      <td className="py-2 px-2">
                        <Input
                          value={option.name}
                          onChange={(e) => updateOptionName(option.id, e.target.value)}
                          className="h-9 bg-background"
                        />
                      </td>
                      {criteria.map((criterion) => (
                        <td key={criterion.id} className="py-2 px-2 text-center">
                          <Input
                            type="number"
                            min={0}
                            max={10}
                            value={option.scores[criterion.id] ?? ""}
                            onChange={(e) =>
                              updateScore(option.id, criterion.id, parseFloat(e.target.value) || 0)
                            }
                            placeholder="0-10"
                            className="h-9 w-20 text-center mx-auto bg-background"
                          />
                        </td>
                      ))}
                      <td className="py-2 px-2 text-center">
                        <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary font-semibold">
                          {weightedScore.toFixed(1)}
                        </span>
                      </td>
                      <td className="py-2 px-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeOption(option.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="flex gap-2 pt-4 mt-4 border-t border-border/50">
          <Input
            placeholder="Add new option..."
            value={newOptionName}
            onChange={(e) => setNewOptionName(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1"
          />
          <Button onClick={addOption} disabled={!newOptionName.trim()} size="sm">
            <Plus className="h-4 w-4 mr-1" /> Add Option
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
