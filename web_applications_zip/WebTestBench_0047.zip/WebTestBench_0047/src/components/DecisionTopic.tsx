import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Pencil, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DecisionTopicProps {
  topic: string;
  onTopicChange: (topic: string) => void;
}

export function DecisionTopic({ topic, onTopicChange }: DecisionTopicProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(topic);

  const handleSave = () => {
    if (editValue.trim()) {
      onTopicChange(editValue.trim());
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSave();
    } else if (e.key === "Escape") {
      setEditValue(topic);
      setIsEditing(false);
    }
  };

  return (
    <div className="flex items-center gap-3 mb-8">
      {isEditing ? (
        <div className="flex items-center gap-2 flex-1">
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={handleSave}
            autoFocus
            className="text-2xl font-semibold h-12 border-primary"
          />
          <Button size="icon" variant="ghost" onClick={handleSave}>
            <Check className="h-5 w-5 text-primary" />
          </Button>
        </div>
      ) : (
        <div className="flex items-center gap-3 group cursor-pointer" onClick={() => setIsEditing(true)}>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">{topic}</h1>
          <Button size="icon" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity">
            <Pencil className="h-4 w-4 text-muted-foreground" />
          </Button>
        </div>
      )}
    </div>
  );
}
