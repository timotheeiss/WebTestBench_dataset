import { Option, Criterion } from "@/types/decision";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Medal, Award } from "lucide-react";

interface RankingDisplayProps {
  options: Option[];
  criteria: Criterion[];
}

export function RankingDisplay({ options, criteria }: RankingDisplayProps) {
  const calculateWeightedScore = (option: Option): number => {
    const totalWeight = criteria.reduce((sum, c) => sum + c.weight, 0);
    if (totalWeight === 0) return 0;

    const weightedSum = criteria.reduce((sum, criterion) => {
      const score = option.scores[criterion.id] || 0;
      return sum + score * criterion.weight;
    }, 0);

    return weightedSum / totalWeight;
  };

  const rankedOptions = [...options]
    .map((option) => ({
      ...option,
      weightedScore: calculateWeightedScore(option),
    }))
    .sort((a, b) => b.weightedScore - a.weightedScore);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-5 w-5" />;
      case 2:
        return <Medal className="h-5 w-5" />;
      case 3:
        return <Award className="h-5 w-5" />;
      default:
        return <span className="text-sm font-bold">#{rank}</span>;
    }
  };

  const getRankStyles = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-amber-400 to-yellow-500 text-white shadow-lg shadow-amber-200/50";
      case 2:
        return "bg-gradient-to-r from-slate-300 to-slate-400 text-white shadow-md";
      case 3:
        return "bg-gradient-to-r from-amber-600 to-orange-700 text-white shadow-md";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  if (options.length === 0 || criteria.length === 0) {
    return null;
  }

  const maxScore = Math.max(...rankedOptions.map((o) => o.weightedScore), 1);

  return (
    <Card className="shadow-sm border-border/50">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Trophy className="h-5 w-5 text-amber-500" />
          Ranking
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {rankedOptions.map((option, index) => {
          const rank = index + 1;
          const progressWidth = (option.weightedScore / maxScore) * 100;

          return (
            <div
              key={option.id}
              className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-300 ${getRankStyles(rank)}`}
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                {getRankIcon(rank)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold truncate">{option.name}</h3>
                <div className="mt-2 h-2 rounded-full bg-white/20 overflow-hidden">
                  <div
                    className="h-full bg-white/60 rounded-full transition-all duration-500"
                    style={{ width: `${progressWidth}%` }}
                  />
                </div>
              </div>
              <div className="flex-shrink-0 text-right">
                <span className="text-2xl font-bold">{option.weightedScore.toFixed(1)}</span>
                <span className="text-sm opacity-80">/10</span>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
