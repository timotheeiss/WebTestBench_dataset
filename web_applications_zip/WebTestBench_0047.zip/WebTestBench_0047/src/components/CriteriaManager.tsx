import { useState } from "react";
import { Criterion } from "@/types/decision";
import { generateId } from "@/data/defaultData";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, GripVertical, ChevronUp, ChevronDown } from "lucide-react";
import { Slider } from "@/components/ui/slider";

interface CriteriaManagerProps {
  criteria: Criterion[];
  onCriteriaChange: (criteria: Criterion[]) => void;
}

export function CriteriaManager({ criteria, onCriteriaChange }: CriteriaManagerProps) {
  const [newCriterionName, setNewCriterionName] = useState("");

  const totalWeight = criteria.reduce((sum, c) => sum + c.weight, 0);

  const addCriterion = () => {
    if (!newCriterionName.trim()) return;
    const newCriterion: Criterion = {
      id: generateId(),
      name: newCriterionName.trim(),
      weight: 10,
    };
    onCriteriaChange([...criteria, newCriterion]);
    setNewCriterionName("");
  };

  const removeCriterion = (id: string) => {
    onCriteriaChange(criteria.filter((c) => c.id !== id));
  };

  const updateCriterion = (id: string, updates: Partial<Criterion>) => {
    onCriteriaChange(
      criteria.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const moveCriterion = (index: number, direction: "up" | "down") => {
    const newIndex = direction === "up" ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= criteria.length) return;
    const newCriteria = [...criteria];
    [newCriteria[index], newCriteria[newIndex]] = [newCriteria[newIndex], newCriteria[index]];
    onCriteriaChange(newCriteria);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      addCriterion();
    }
  };

  return (
    <Card className="shadow-sm border-border/50">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold flex items-center justify-between">
          <span>Criteria</span>
          <span className={`text-sm font-normal ${totalWeight === 100 ? "text-primary" : "text-warning"}`}>
            Total Weight: {totalWeight}%
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {criteria.map((criterion, index) => (
          <div
            key={criterion.id}
            className="flex items-center gap-2 p-3 bg-secondary/50 rounded-lg group"
          >
            <GripVertical className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
            <div className="flex items-center gap-1 flex-shrink-0">
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => moveCriterion(index, "up")}
                disabled={index === 0}
              >
                <ChevronUp className="h-3 w-3" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => moveCriterion(index, "down")}
                disabled={index === criteria.length - 1}
              >
                <ChevronDown className="h-3 w-3" />
              </Button>
            </div>
            <Input
              value={criterion.name}
              onChange={(e) => updateCriterion(criterion.id, { name: e.target.value })}
              className="flex-1 h-8 bg-background"
            />
            <div className="flex items-center gap-2 w-40">
              <Slider
                value={[criterion.weight]}
                onValueChange={(value) => updateCriterion(criterion.id, { weight: value[0] })}
                max={100}
                min={1}
                step={1}
                className="w-24"
              />
              <span className="text-sm font-medium w-10 text-right">{criterion.weight}%</span>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={() => removeCriterion(criterion.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}

        <div className="flex gap-2 pt-2">
          <Input
            placeholder="Add new criterion..."
            value={newCriterionName}
            onChange={(e) => setNewCriterionName(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1"
          />
          <Button onClick={addCriterion} disabled={!newCriterionName.trim()} size="sm">
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
