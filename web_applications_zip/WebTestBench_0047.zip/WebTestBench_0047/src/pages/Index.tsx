import { useState } from "react";
import { DecisionMatrix } from "@/types/decision";
import { defaultDecisionMatrix } from "@/data/defaultData";
import { DecisionTopic } from "@/components/DecisionTopic";
import { CriteriaManager } from "@/components/CriteriaManager";
import { OptionsMatrix } from "@/components/OptionsMatrix";
import { RankingDisplay } from "@/components/RankingDisplay";
import { Scale, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

const Index = () => {
  const [matrix, setMatrix] = useState<DecisionMatrix>(defaultDecisionMatrix);

  const handleReset = () => {
    setMatrix({
      topic: "New Decision",
      criteria: [],
      options: [],
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10">
              <Scale className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-medium text-muted-foreground">Decision Matrix</h2>
              <p className="text-xs text-muted-foreground/70">Compare options systematically</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
            <RotateCcw className="h-4 w-4" />
            New Decision
          </Button>
        </header>

        {/* Topic */}
        <DecisionTopic
          topic={matrix.topic}
          onTopicChange={(topic) => setMatrix({ ...matrix, topic })}
        />

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Criteria */}
          <div className="lg:col-span-1">
            <CriteriaManager
              criteria={matrix.criteria}
              onCriteriaChange={(criteria) => setMatrix({ ...matrix, criteria })}
            />
          </div>

          {/* Right Column - Options & Ranking */}
          <div className="lg:col-span-2 space-y-6">
            <OptionsMatrix
              options={matrix.options}
              criteria={matrix.criteria}
              onOptionsChange={(options) => setMatrix({ ...matrix, options })}
            />
            <RankingDisplay options={matrix.options} criteria={matrix.criteria} />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 pt-6 border-t border-border/50 text-center">
          <p className="text-sm text-muted-foreground">
            Score each option from 0-10 per criterion. Higher scores = better fit.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
