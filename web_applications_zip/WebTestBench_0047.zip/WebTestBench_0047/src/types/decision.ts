export interface Criterion {
  id: string;
  name: string;
  weight: number;
}

export interface Option {
  id: string;
  name: string;
  scores: Record<string, number>; // criterionId -> score
}

export interface DecisionMatrix {
  topic: string;
  criteria: Criterion[];
  options: Option[];
}
