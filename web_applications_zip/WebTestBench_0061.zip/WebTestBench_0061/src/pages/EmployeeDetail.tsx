import { useParams, Link, useNavigate } from 'react-router-dom';
import { useData } from '@/context/DataContext';
import { StatusBadge } from '@/components/StatusBadge';
import { TrainingRecordForm } from '@/components/TrainingRecordForm';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  ArrowLeft,
  Mail,
  Building2,
  Briefcase,
  Calendar,
  Plus,
  Trash2,
  CheckCircle,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { useState } from 'react';
import { ComplianceStatus } from '@/data/mockData';

const EmployeeDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    employees,
    courses,
    getEmployeeComplianceStatus,
    getEmployeeTrainingRecords,
    getMandatoryCourses,
    deleteTrainingRecord,
  } = useData();
  const [trainingFormOpen, setTrainingFormOpen] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState<string | null>(null);

  const employee = employees.find(e => e.id === id);
  const trainingRecords = id ? getEmployeeTrainingRecords(id) : [];
  const mandatoryCourses = getMandatoryCourses();

  if (!employee) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <h2 className="text-xl font-semibold text-foreground mb-2">Employee not found</h2>
        <p className="text-muted-foreground mb-4">The employee you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/employees">Back to Employees</Link>
        </Button>
      </div>
    );
  }

  const status = getEmployeeComplianceStatus(employee.id);

  const getCourseStatus = (courseId: string): { status: ComplianceStatus; record?: typeof trainingRecords[0] } => {
    const records = trainingRecords.filter(r => r.courseId === courseId);
    const latestRecord = records.sort(
      (a, b) => new Date(b.completedDate).getTime() - new Date(a.completedDate).getTime()
    )[0];

    if (!latestRecord) return { status: 'overdue' };

    const today = new Date();
    const expiryDate = new Date(latestRecord.expiryDate);
    const thirtyDaysFromNow = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    if (expiryDate < today) return { status: 'overdue', record: latestRecord };
    if (expiryDate < thirtyDaysFromNow) return { status: 'due-soon', record: latestRecord };
    return { status: 'compliant', record: latestRecord };
  };

  const handleDeleteRecord = () => {
    if (recordToDelete) {
      deleteTrainingRecord(recordToDelete);
      setRecordToDelete(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back Button */}
      <Button variant="ghost" className="gap-2 -ml-2" onClick={() => navigate('/employees')}>
        <ArrowLeft className="h-4 w-4" />
        Back to Employees
      </Button>

      {/* Header */}
      <div className="bg-card rounded-xl border border-border shadow-sm p-6">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl font-semibold text-primary">
                {employee.name.split(' ').map(n => n[0]).join('')}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{employee.name}</h1>
              <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Mail className="h-4 w-4" />
                  {employee.email}
                </span>
                <span className="flex items-center gap-1.5">
                  <Building2 className="h-4 w-4" />
                  {employee.department}
                </span>
                <span className="flex items-center gap-1.5">
                  <Briefcase className="h-4 w-4" />
                  {employee.position}
                </span>
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  Hired {new Date(employee.hireDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <StatusBadge status={status} />
            <Button onClick={() => setTrainingFormOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Record Training
            </Button>
          </div>
        </div>
      </div>

      {/* Mandatory Courses Status */}
      <div className="bg-card rounded-xl border border-border shadow-sm">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Mandatory Training Status</h2>
          <p className="text-sm text-muted-foreground">
            Required courses and their completion status
          </p>
        </div>
        <div className="divide-y divide-border">
          {mandatoryCourses.map(course => {
            const { status: courseStatus, record } = getCourseStatus(course.id);
            return (
              <div
                key={course.id}
                className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-lg ${
                      courseStatus === 'compliant'
                        ? 'bg-success/10'
                        : courseStatus === 'due-soon'
                        ? 'bg-warning/10'
                        : 'bg-danger/10'
                    }`}
                  >
                    {courseStatus === 'compliant' ? (
                      <CheckCircle className="h-4 w-4 text-success" />
                    ) : courseStatus === 'due-soon' ? (
                      <AlertTriangle className="h-4 w-4 text-warning" />
                    ) : (
                      <XCircle className="h-4 w-4 text-danger" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{course.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {course.durationHours} hours · {course.validityMonths} months validity
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  {record ? (
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        Completed {new Date(record.completedDate).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Expires {new Date(record.expiryDate).toLocaleDateString()}
                      </p>
                    </div>
                  ) : (
                    <Badge variant="outline" className="text-danger border-danger/20">
                      Not completed
                    </Badge>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* All Training Records */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Training History</h2>
          <p className="text-sm text-muted-foreground">
            All completed training courses
          </p>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="table-header">Course</TableHead>
              <TableHead className="table-header">Completed</TableHead>
              <TableHead className="table-header">Expires</TableHead>
              <TableHead className="table-header">Certificate</TableHead>
              <TableHead className="table-header text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {trainingRecords.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">
                  No training records yet
                </TableCell>
              </TableRow>
            ) : (
              trainingRecords
                .sort((a, b) => new Date(b.completedDate).getTime() - new Date(a.completedDate).getTime())
                .map(record => {
                  const course = courses.find(c => c.id === record.courseId);
                  const isExpired = new Date(record.expiryDate) < new Date();
                  return (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-foreground">{course?.name || 'Unknown'}</p>
                          <p className="text-sm text-muted-foreground">{course?.category}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(record.completedDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <span className={isExpired ? 'text-danger' : 'text-muted-foreground'}>
                          {new Date(record.expiryDate).toLocaleDateString()}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {record.certificateNumber || '—'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-muted-foreground hover:text-destructive"
                          onClick={() => setRecordToDelete(record.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Training Record Form */}
      <TrainingRecordForm
        open={trainingFormOpen}
        onClose={() => setTrainingFormOpen(false)}
        employeeId={employee.id}
        employeeName={employee.name}
      />

      {/* Delete Record Confirmation */}
      <AlertDialog open={!!recordToDelete} onOpenChange={() => setRecordToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Training Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this training record? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteRecord}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default EmployeeDetail;
