import { useData } from '@/context/DataContext';
import { MetricCard } from '@/components/MetricCard';
import { StatusBadge } from '@/components/StatusBadge';
import { Users, CheckCircle, AlertTriangle, XCircle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { employees, courses, getComplianceStats, getEmployeeComplianceStatus, getMandatoryCourses } = useData();
  const stats = getComplianceStats();
  const mandatoryCourses = getMandatoryCourses();

  const complianceRate = stats.total > 0 
    ? Math.round((stats.compliant / stats.total) * 100) 
    : 0;

  const overdueEmployees = employees.filter(e => getEmployeeComplianceStatus(e.id) === 'overdue');

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Compliance Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Overview of employee training compliance status
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Employees"
          value={stats.total}
          subtitle={`${mandatoryCourses.length} mandatory courses`}
          icon={Users}
          variant="default"
        />
        <MetricCard
          title="Compliant"
          value={stats.compliant}
          subtitle={`${complianceRate}% compliance rate`}
          icon={CheckCircle}
          variant="success"
        />
        <MetricCard
          title="Due Soon"
          value={stats.dueSoon}
          subtitle="Within 30 days"
          icon={AlertTriangle}
          variant="warning"
        />
        <MetricCard
          title="Overdue"
          value={stats.overdue}
          subtitle="Requires immediate action"
          icon={XCircle}
          variant="danger"
        />
      </div>

      {/* Overdue Employees Section */}
      {overdueEmployees.length > 0 && (
        <div className="bg-card rounded-xl border border-border shadow-sm">
          <div className="flex items-center justify-between p-6 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-danger/10">
                <XCircle className="h-5 w-5 text-danger" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Employees Overdue</h2>
                <p className="text-sm text-muted-foreground">
                  {overdueEmployees.length} employee{overdueEmployees.length > 1 ? 's' : ''} need attention
                </p>
              </div>
            </div>
            <Link
              to="/employees"
              className="text-sm font-medium text-primary hover:underline"
            >
              View all →
            </Link>
          </div>
          <div className="divide-y divide-border">
            {overdueEmployees.slice(0, 5).map(employee => (
              <div
                key={employee.id}
                className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-medium text-primary">
                      {employee.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{employee.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {employee.department} · {employee.position}
                    </p>
                  </div>
                </div>
                <StatusBadge status="overdue" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Mandatory Courses */}
        <div className="bg-card rounded-xl border border-border shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-primary/10">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Mandatory Courses</h2>
          </div>
          <div className="space-y-3">
            {mandatoryCourses.map(course => (
              <div
                key={course.id}
                className="flex items-center justify-between py-2 border-b border-border last:border-0"
              >
                <div>
                  <p className="font-medium text-foreground text-sm">{course.name}</p>
                  <p className="text-xs text-muted-foreground">{course.category}</p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {course.validityMonths} months validity
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance by Department */}
        <div className="bg-card rounded-xl border border-border shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-success/10">
              <CheckCircle className="h-5 w-5 text-success" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">By Department</h2>
          </div>
          <div className="space-y-3">
            {Array.from(new Set(employees.map(e => e.department))).map(dept => {
              const deptEmployees = employees.filter(e => e.department === dept);
              const deptCompliant = deptEmployees.filter(
                e => getEmployeeComplianceStatus(e.id) === 'compliant'
              ).length;
              const rate = Math.round((deptCompliant / deptEmployees.length) * 100);
              return (
                <div key={dept} className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-foreground">{dept}</span>
                    <span className="text-muted-foreground">
                      {deptCompliant}/{deptEmployees.length} ({rate}%)
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full bg-success rounded-full transition-all"
                      style={{ width: `${rate}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
