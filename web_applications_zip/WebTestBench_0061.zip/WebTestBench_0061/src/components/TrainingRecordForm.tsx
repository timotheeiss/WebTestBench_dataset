import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useData } from '@/context/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useEffect } from 'react';

const trainingRecordSchema = z.object({
  courseId: z.string().min(1, 'Please select a course'),
  completedDate: z.string().min(1, 'Completion date is required'),
  certificateNumber: z.string().optional(),
});

type TrainingRecordFormData = z.infer<typeof trainingRecordSchema>;

interface TrainingRecordFormProps {
  open: boolean;
  onClose: () => void;
  employeeId: string;
  employeeName: string;
}

export const TrainingRecordForm = ({
  open,
  onClose,
  employeeId,
  employeeName,
}: TrainingRecordFormProps) => {
  const { courses, addTrainingRecord } = useData();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<TrainingRecordFormData>({
    resolver: zodResolver(trainingRecordSchema),
    defaultValues: {
      courseId: '',
      completedDate: new Date().toISOString().split('T')[0],
      certificateNumber: '',
    },
  });

  const selectedCourseId = watch('courseId');
  const completedDate = watch('completedDate');

  useEffect(() => {
    if (!open) {
      reset();
    }
  }, [open, reset]);

  const getExpiryDate = (courseId: string, completedDate: string) => {
    const course = courses.find(c => c.id === courseId);
    if (!course || !completedDate) return '';
    const date = new Date(completedDate);
    date.setMonth(date.getMonth() + course.validityMonths);
    return date.toISOString().split('T')[0];
  };

  const handleFormSubmit = (data: TrainingRecordFormData) => {
    const expiryDate = getExpiryDate(data.courseId, data.completedDate);
    addTrainingRecord({
      employeeId,
      courseId: data.courseId,
      completedDate: data.completedDate,
      expiryDate,
      certificateNumber: data.certificateNumber || undefined,
    });
    reset();
    onClose();
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Record Training Completion</DialogTitle>
          <p className="text-sm text-muted-foreground">
            For: <span className="font-medium text-foreground">{employeeName}</span>
          </p>
        </DialogHeader>
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="courseId">Course</Label>
            <Select
              value={selectedCourseId}
              onValueChange={(value) => setValue('courseId', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a course" />
              </SelectTrigger>
              <SelectContent className="bg-popover">
                {courses.map(course => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                    {course.mandatory && (
                      <span className="ml-2 text-xs text-muted-foreground">(Mandatory)</span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.courseId && (
              <p className="text-sm text-destructive">{errors.courseId.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="completedDate">Completion Date</Label>
            <Input id="completedDate" type="date" {...register('completedDate')} />
            {errors.completedDate && (
              <p className="text-sm text-destructive">{errors.completedDate.message}</p>
            )}
          </div>

          {selectedCourseId && completedDate && (
            <div className="rounded-lg bg-muted p-3">
              <p className="text-sm text-muted-foreground">
                Certificate expires:{' '}
                <span className="font-medium text-foreground">
                  {new Date(getExpiryDate(selectedCourseId, completedDate)).toLocaleDateString()}
                </span>
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="certificateNumber">Certificate Number (optional)</Label>
            <Input
              id="certificateNumber"
              {...register('certificateNumber')}
              placeholder="e.g., CERT-2024-001"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit">Record Completion</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
