import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Course } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { useEffect } from 'react';

const courseSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  durationHours: z.coerce.number().min(0.5, 'Duration must be at least 0.5 hours'),
  validityMonths: z.coerce.number().min(1, 'Validity must be at least 1 month'),
  mandatory: z.boolean(),
  category: z.string().min(1, 'Category is required'),
});

type CourseFormData = z.infer<typeof courseSchema>;

interface CourseFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: CourseFormData) => void;
  course?: Course | null;
}

export const CourseForm = ({ open, onClose, onSubmit, course }: CourseFormProps) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<CourseFormData>({
    resolver: zodResolver(courseSchema),
    defaultValues: {
      name: '',
      description: '',
      durationHours: 1,
      validityMonths: 12,
      mandatory: false,
      category: '',
    },
  });

  useEffect(() => {
    if (course) {
      reset(course);
    } else {
      reset({
        name: '',
        description: '',
        durationHours: 1,
        validityMonths: 12,
        mandatory: false,
        category: '',
      });
    }
  }, [course, reset]);

  const mandatory = watch('mandatory');

  const handleFormSubmit = (data: CourseFormData) => {
    onSubmit(data);
    reset();
    onClose();
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{course ? 'Edit Course' : 'Add New Course'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Course Name</Label>
            <Input id="name" {...register('name')} placeholder="Workplace Safety" />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...register('description')}
              placeholder="Course description..."
              rows={3}
            />
            {errors.description && (
              <p className="text-sm text-destructive">{errors.description.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Input id="category" {...register('category')} placeholder="Safety, HR, IT..." />
            {errors.category && (
              <p className="text-sm text-destructive">{errors.category.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="durationHours">Duration (hours)</Label>
              <Input
                id="durationHours"
                type="number"
                step="0.5"
                {...register('durationHours')}
              />
              {errors.durationHours && (
                <p className="text-sm text-destructive">{errors.durationHours.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="validityMonths">Validity (months)</Label>
              <Input
                id="validityMonths"
                type="number"
                {...register('validityMonths')}
              />
              {errors.validityMonths && (
                <p className="text-sm text-destructive">{errors.validityMonths.message}</p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="mandatory">Mandatory Training</Label>
              <p className="text-sm text-muted-foreground">
                All employees must complete this course
              </p>
            </div>
            <Switch
              id="mandatory"
              checked={mandatory}
              onCheckedChange={(checked) => setValue('mandatory', checked)}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit">{course ? 'Save Changes' : 'Add Course'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
