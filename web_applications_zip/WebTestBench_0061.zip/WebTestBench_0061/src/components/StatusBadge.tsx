import { cn } from '@/lib/utils';
import { ComplianceStatus } from '@/data/mockData';
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface StatusBadgeProps {
  status: ComplianceStatus;
  showIcon?: boolean;
  className?: string;
}

const statusConfig: Record<ComplianceStatus, { label: string; className: string; icon: typeof CheckCircle }> = {
  compliant: {
    label: 'Compliant',
    className: 'status-compliant',
    icon: CheckCircle,
  },
  'due-soon': {
    label: 'Due Soon',
    className: 'status-warning',
    icon: AlertTriangle,
  },
  overdue: {
    label: 'Overdue',
    className: 'status-overdue',
    icon: XCircle,
  },
};

export const StatusBadge = ({ status, showIcon = true, className }: StatusBadgeProps) => {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border',
        config.className,
        className
      )}
    >
      {showIcon && <Icon className="h-3 w-3" />}
      {config.label}
    </span>
  );
};
