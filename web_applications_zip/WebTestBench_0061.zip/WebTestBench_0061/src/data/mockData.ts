export interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  position: string;
  hireDate: string;
  avatar?: string;
}

export interface Course {
  id: string;
  name: string;
  description: string;
  durationHours: number;
  validityMonths: number;
  mandatory: boolean;
  category: string;
}

export interface TrainingRecord {
  id: string;
  employeeId: string;
  courseId: string;
  completedDate: string;
  expiryDate: string;
  certificateNumber?: string;
}

export type ComplianceStatus = 'compliant' | 'due-soon' | 'overdue';

// Initial mock data
export const initialEmployees: Employee[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    email: 'sarah.chen@company.com',
    department: 'Engineering',
    position: 'Senior Developer',
    hireDate: '2022-03-15',
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    email: 'marcus.johnson@company.com',
    department: 'Operations',
    position: 'Operations Manager',
    hireDate: '2021-08-01',
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.rodriguez@company.com',
    department: 'Human Resources',
    position: 'HR Specialist',
    hireDate: '2023-01-10',
  },
  {
    id: '4',
    name: 'David Kim',
    email: 'david.kim@company.com',
    department: 'Engineering',
    position: 'Junior Developer',
    hireDate: '2024-02-20',
  },
  {
    id: '5',
    name: 'Lisa Thompson',
    email: 'lisa.thompson@company.com',
    department: 'Finance',
    position: 'Financial Analyst',
    hireDate: '2022-11-05',
  },
];

export const initialCourses: Course[] = [
  {
    id: '1',
    name: 'Workplace Safety Fundamentals',
    description: 'Essential safety protocols and emergency procedures for all employees',
    durationHours: 4,
    validityMonths: 12,
    mandatory: true,
    category: 'Safety',
  },
  {
    id: '2',
    name: 'Data Privacy & GDPR Compliance',
    description: 'Understanding data protection regulations and best practices',
    durationHours: 3,
    validityMonths: 12,
    mandatory: true,
    category: 'Compliance',
  },
  {
    id: '3',
    name: 'Anti-Harassment Training',
    description: 'Creating a respectful and inclusive workplace environment',
    durationHours: 2,
    validityMonths: 24,
    mandatory: true,
    category: 'HR',
  },
  {
    id: '4',
    name: 'Cybersecurity Awareness',
    description: 'Protecting company assets from digital threats',
    durationHours: 2,
    validityMonths: 12,
    mandatory: true,
    category: 'IT',
  },
  {
    id: '5',
    name: 'First Aid & CPR',
    description: 'Basic emergency medical response training',
    durationHours: 8,
    validityMonths: 24,
    mandatory: false,
    category: 'Safety',
  },
  {
    id: '6',
    name: 'Leadership Development',
    description: 'Building effective management and leadership skills',
    durationHours: 16,
    validityMonths: 36,
    mandatory: false,
    category: 'Professional Development',
  },
];

// Training records with various compliance states
const today = new Date();
const formatDate = (date: Date) => date.toISOString().split('T')[0];

export const initialTrainingRecords: TrainingRecord[] = [
  // Sarah Chen - mostly compliant, one overdue
  {
    id: '1',
    employeeId: '1',
    courseId: '1',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 6, 15)),
    expiryDate: formatDate(new Date(today.getFullYear(), today.getMonth() + 6, 15)),
  },
  {
    id: '2',
    employeeId: '1',
    courseId: '2',
    completedDate: formatDate(new Date(today.getFullYear() - 1, today.getMonth() - 2, 10)),
    expiryDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 2, 10)), // Overdue
  },
  {
    id: '3',
    employeeId: '1',
    courseId: '3',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 3, 20)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() + 9, 20)),
  },
  {
    id: '4',
    employeeId: '1',
    courseId: '4',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 5)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 1, 5)),
  },
  
  // Marcus Johnson - all compliant
  {
    id: '5',
    employeeId: '2',
    courseId: '1',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 2, 1)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 2, 1)),
  },
  {
    id: '6',
    employeeId: '2',
    courseId: '2',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 4, 15)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 4, 15)),
  },
  {
    id: '7',
    employeeId: '2',
    courseId: '3',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 10)),
    expiryDate: formatDate(new Date(today.getFullYear() + 2, today.getMonth() - 1, 10)),
  },
  {
    id: '8',
    employeeId: '2',
    courseId: '4',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 3, 20)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 3, 20)),
  },
  
  // Emily Rodriguez - some due soon
  {
    id: '9',
    employeeId: '3',
    courseId: '1',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 11, 10)),
    expiryDate: formatDate(new Date(today.getFullYear(), today.getMonth() + 1, 10)), // Due soon
  },
  {
    id: '10',
    employeeId: '3',
    courseId: '2',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 5, 25)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 5, 25)),
  },
  {
    id: '11',
    employeeId: '3',
    courseId: '3',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 15)),
    expiryDate: formatDate(new Date(today.getFullYear() + 2, today.getMonth() - 1, 15)),
  },
  
  // David Kim - new employee, missing trainings (no records for mandatory courses)
  {
    id: '12',
    employeeId: '4',
    courseId: '1',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 20)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() - 1, 20)),
  },
  
  // Lisa Thompson - multiple overdue
  {
    id: '13',
    employeeId: '5',
    courseId: '1',
    completedDate: formatDate(new Date(today.getFullYear() - 1, today.getMonth() - 3, 5)),
    expiryDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 3, 5)), // Overdue
  },
  {
    id: '14',
    employeeId: '5',
    courseId: '2',
    completedDate: formatDate(new Date(today.getFullYear() - 1, today.getMonth() - 1, 10)),
    expiryDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 10)), // Overdue
  },
  {
    id: '15',
    employeeId: '5',
    courseId: '3',
    completedDate: formatDate(new Date(today.getFullYear(), today.getMonth() - 6, 20)),
    expiryDate: formatDate(new Date(today.getFullYear() + 1, today.getMonth() + 6, 20)),
  },
];
