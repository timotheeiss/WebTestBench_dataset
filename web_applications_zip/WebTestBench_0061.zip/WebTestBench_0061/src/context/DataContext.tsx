import React, { createContext, useContext, useState, useCallback } from 'react';
import {
  Employee,
  Course,
  TrainingRecord,
  ComplianceStatus,
  initialEmployees,
  initialCourses,
  initialTrainingRecords,
} from '@/data/mockData';

interface DataContextType {
  employees: Employee[];
  courses: Course[];
  trainingRecords: TrainingRecord[];
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  updateEmployee: (id: string, employee: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  addCourse: (course: Omit<Course, 'id'>) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;
  addTrainingRecord: (record: Omit<TrainingRecord, 'id'>) => void;
  deleteTrainingRecord: (id: string) => void;
  getEmployeeComplianceStatus: (employeeId: string) => ComplianceStatus;
  getEmployeeTrainingRecords: (employeeId: string) => TrainingRecord[];
  getMandatoryCourses: () => Course[];
  getOverdueEmployeesCount: () => number;
  getComplianceStats: () => {
    total: number;
    compliant: number;
    dueSoon: number;
    overdue: number;
  };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [courses, setCourses] = useState<Course[]>(initialCourses);
  const [trainingRecords, setTrainingRecords] = useState<TrainingRecord[]>(initialTrainingRecords);

  const generateId = () => Math.random().toString(36).substring(2, 11);

  const addEmployee = useCallback((employee: Omit<Employee, 'id'>) => {
    setEmployees(prev => [...prev, { ...employee, id: generateId() }]);
  }, []);

  const updateEmployee = useCallback((id: string, employee: Partial<Employee>) => {
    setEmployees(prev => prev.map(e => (e.id === id ? { ...e, ...employee } : e)));
  }, []);

  const deleteEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.filter(e => e.id !== id));
    setTrainingRecords(prev => prev.filter(r => r.employeeId !== id));
  }, []);

  const addCourse = useCallback((course: Omit<Course, 'id'>) => {
    setCourses(prev => [...prev, { ...course, id: generateId() }]);
  }, []);

  const updateCourse = useCallback((id: string, course: Partial<Course>) => {
    setCourses(prev => prev.map(c => (c.id === id ? { ...c, ...course } : c)));
  }, []);

  const deleteCourse = useCallback((id: string) => {
    setCourses(prev => prev.filter(c => c.id !== id));
    setTrainingRecords(prev => prev.filter(r => r.courseId !== id));
  }, []);

  const addTrainingRecord = useCallback((record: Omit<TrainingRecord, 'id'>) => {
    setTrainingRecords(prev => [...prev, { ...record, id: generateId() }]);
  }, []);

  const deleteTrainingRecord = useCallback((id: string) => {
    setTrainingRecords(prev => prev.filter(r => r.id !== id));
  }, []);

  const getMandatoryCourses = useCallback(() => {
    return courses.filter(c => c.mandatory);
  }, [courses]);

  const getEmployeeTrainingRecords = useCallback((employeeId: string) => {
    return trainingRecords.filter(r => r.employeeId === employeeId);
  }, [trainingRecords]);

  const getEmployeeComplianceStatus = useCallback((employeeId: string): ComplianceStatus => {
    const mandatoryCourses = getMandatoryCourses();
    const employeeRecords = getEmployeeTrainingRecords(employeeId);
    const today = new Date();
    const thirtyDaysFromNow = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    let hasOverdue = false;
    let hasDueSoon = false;

    for (const course of mandatoryCourses) {
      const latestRecord = employeeRecords
        .filter(r => r.courseId === course.id)
        .sort((a, b) => new Date(b.completedDate).getTime() - new Date(a.completedDate).getTime())[0];

      if (!latestRecord) {
        hasOverdue = true;
        continue;
      }

      const expiryDate = new Date(latestRecord.expiryDate);
      if (expiryDate < today) {
        hasOverdue = true;
      } else if (expiryDate < thirtyDaysFromNow) {
        hasDueSoon = true;
      }
    }

    if (hasOverdue) return 'overdue';
    if (hasDueSoon) return 'due-soon';
    return 'compliant';
  }, [getMandatoryCourses, getEmployeeTrainingRecords]);

  const getOverdueEmployeesCount = useCallback(() => {
    return employees.filter(e => getEmployeeComplianceStatus(e.id) === 'overdue').length;
  }, [employees, getEmployeeComplianceStatus]);

  const getComplianceStats = useCallback(() => {
    const stats = { total: employees.length, compliant: 0, dueSoon: 0, overdue: 0 };
    employees.forEach(e => {
      const status = getEmployeeComplianceStatus(e.id);
      if (status === 'compliant') stats.compliant++;
      else if (status === 'due-soon') stats.dueSoon++;
      else stats.overdue++;
    });
    return stats;
  }, [employees, getEmployeeComplianceStatus]);

  return (
    <DataContext.Provider
      value={{
        employees,
        courses,
        trainingRecords,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        addCourse,
        updateCourse,
        deleteCourse,
        addTrainingRecord,
        deleteTrainingRecord,
        getEmployeeComplianceStatus,
        getEmployeeTrainingRecords,
        getMandatoryCourses,
        getOverdueEmployeesCount,
        getComplianceStats,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
