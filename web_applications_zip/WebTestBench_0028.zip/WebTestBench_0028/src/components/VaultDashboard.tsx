import React, { useState, useMemo } from 'react';
import { useVault } from '@/contexts/VaultContext';
import { Document, Folder } from '@/types/vault';
import { VaultHeader } from './VaultHeader';
import { FolderCard } from './FolderCard';
import { DocumentCard } from './DocumentCard';
import { UploadModal } from './UploadModal';
import { NewFolderModal } from './NewFolderModal';
import { RenameModal } from './RenameModal';
import { EditTagsModal } from './EditTagsModal';
import { MoveModal } from './MoveModal';
import { FileText, FolderOpen, Search, Lock } from 'lucide-react';
import { toast } from 'sonner';

export function VaultDashboard() {
  const { 
    currentFolderId, 
    getFoldersByParent, 
    getDocumentsByFolder,
    searchDocuments,
    addFolder,
    renameFolder,
    renameDocument,
    getFolderPath
  } = useVault();

  const [searchQuery, setSearchQuery] = useState('');
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [newFolderModalOpen, setNewFolderModalOpen] = useState(false);
  const [renameModalOpen, setRenameModalOpen] = useState(false);
  const [editTagsModalOpen, setEditTagsModalOpen] = useState(false);
  const [moveModalOpen, setMoveModalOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [selectedFolder, setSelectedFolder] = useState<Folder | null>(null);

  const isSearching = searchQuery.trim().length > 0;

  const folders = useMemo(() => {
    if (isSearching) return [];
    return getFoldersByParent(currentFolderId);
  }, [currentFolderId, getFoldersByParent, isSearching]);

  const documents = useMemo(() => {
    if (isSearching) {
      return searchDocuments(searchQuery);
    }
    return getDocumentsByFolder(currentFolderId);
  }, [currentFolderId, getDocumentsByFolder, searchQuery, searchDocuments, isSearching]);

  const currentFolderName = useMemo(() => {
    const path = getFolderPath(currentFolderId);
    return path.length > 0 ? path[path.length - 1].name : undefined;
  }, [currentFolderId, getFolderPath]);

  const handleNewFolder = (name: string) => {
    addFolder(name, currentFolderId);
    toast.success(`Folder "${name}" created`);
  };

  const handleRenameFolder = (folder: Folder) => {
    setSelectedFolder(folder);
    setSelectedDocument(null);
    setRenameModalOpen(true);
  };

  const handleRenameDocument = (doc: Document) => {
    setSelectedDocument(doc);
    setSelectedFolder(null);
    setRenameModalOpen(true);
  };

  const handleEditTags = (doc: Document) => {
    setSelectedDocument(doc);
    setEditTagsModalOpen(true);
  };

  const handleMoveDocument = (doc: Document) => {
    setSelectedDocument(doc);
    setMoveModalOpen(true);
  };

  const handleRenameSubmit = (newName: string) => {
    if (selectedFolder) {
      renameFolder(selectedFolder.id, newName);
      toast.success('Folder renamed');
    } else if (selectedDocument) {
      renameDocument(selectedDocument.id, newName);
      toast.success('Document renamed');
    }
  };

  const isEmpty = folders.length === 0 && documents.length === 0;

  return (
    <div className="min-h-screen vault-gradient">
      <VaultHeader
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNewFolder={() => setNewFolderModalOpen(true)}
        onUpload={() => setUploadModalOpen(true)}
      />

      <main className="p-6">
        {isEmpty ? (
          <EmptyState 
            isSearching={isSearching} 
            searchQuery={searchQuery}
            onUpload={() => setUploadModalOpen(true)}
            onNewFolder={() => setNewFolderModalOpen(true)}
          />
        ) : (
          <div className="space-y-8">
            {/* Folders */}
            {folders.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
                  <FolderOpen className="w-4 h-4" />
                  Folders ({folders.length})
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {folders.map((folder) => (
                    <FolderCard
                      key={folder.id}
                      folder={folder}
                      onRename={handleRenameFolder}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Documents */}
            {documents.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  {isSearching ? 'Search Results' : 'Documents'} ({documents.length})
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {documents.map((doc) => (
                    <DocumentCard
                      key={doc.id}
                      document={doc}
                      onRename={handleRenameDocument}
                      onEditTags={handleEditTags}
                      onMove={handleMoveDocument}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {/* Modals */}
      <UploadModal 
        open={uploadModalOpen} 
        onOpenChange={setUploadModalOpen} 
      />
      <NewFolderModal
        open={newFolderModalOpen}
        onOpenChange={setNewFolderModalOpen}
        onSubmit={handleNewFolder}
        parentFolderName={currentFolderName}
      />
      <RenameModal
        open={renameModalOpen}
        onOpenChange={setRenameModalOpen}
        currentName={selectedFolder?.name ?? selectedDocument?.name ?? ''}
        itemType={selectedFolder ? 'folder' : 'document'}
        onSubmit={handleRenameSubmit}
      />
      <EditTagsModal
        open={editTagsModalOpen}
        onOpenChange={setEditTagsModalOpen}
        document={selectedDocument}
      />
      <MoveModal
        open={moveModalOpen}
        onOpenChange={setMoveModalOpen}
        document={selectedDocument}
      />
    </div>
  );
}

interface EmptyStateProps {
  isSearching: boolean;
  searchQuery: string;
  onUpload: () => void;
  onNewFolder: () => void;
}

function EmptyState({ isSearching, searchQuery, onUpload, onNewFolder }: EmptyStateProps) {
  if (isSearching) {
    return (
      <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
        <div className="p-4 rounded-2xl bg-secondary mb-6">
          <Search className="w-12 h-12 text-muted-foreground" />
        </div>
        <h3 className="text-xl font-semibold mb-2">No results found</h3>
        <p className="text-muted-foreground text-center max-w-md">
          No documents match "{searchQuery}". Try a different search term or check your spelling.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
      <div className="p-4 rounded-2xl bg-primary/10 vault-glow mb-6">
        <Lock className="w-12 h-12 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-2">Your vault is empty</h3>
      <p className="text-muted-foreground text-center max-w-md mb-6">
        Start by uploading documents or creating folders to organize your secure files.
      </p>
      <div className="flex gap-3">
        <button
          onClick={onNewFolder}
          className="px-4 py-2 rounded-lg border border-border bg-secondary hover:bg-secondary/80 text-sm font-medium transition-colors"
        >
          Create Folder
        </button>
        <button
          onClick={onUpload}
          className="px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 text-sm font-medium transition-colors vault-glow-sm"
        >
          Upload Documents
        </button>
      </div>
    </div>
  );
}
