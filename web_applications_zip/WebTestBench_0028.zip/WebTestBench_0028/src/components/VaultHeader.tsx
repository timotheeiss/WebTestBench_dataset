import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useVault } from '@/contexts/VaultContext';
import { Button } from '@/components/ui/button';
import { 
  Shield, 
  LogOut, 
  FolderPlus, 
  Upload, 
  Search,
  ChevronRight,
  Home
} from 'lucide-react';

interface VaultHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onNewFolder: () => void;
  onUpload: () => void;
}

export function VaultHeader({ 
  searchQuery, 
  onSearchChange, 
  onNewFolder, 
  onUpload 
}: VaultHeaderProps) {
  const { user, logout } = useAuth();
  const { currentFolderId, setCurrentFolderId, getFolderPath } = useVault();
  
  const folderPath = getFolderPath(currentFolderId);

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10 vault-glow-sm">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gradient">SecureVault</h1>
            <p className="text-xs text-muted-foreground">{user?.email}</p>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-md mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search documents by name or tag..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full h-10 pl-10 pr-4 rounded-lg bg-secondary border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onNewFolder}>
            <FolderPlus className="w-4 h-4" />
            New Folder
          </Button>
          <Button variant="default" size="sm" onClick={onUpload}>
            <Upload className="w-4 h-4" />
            Upload
          </Button>
          <Button variant="ghost" size="icon" onClick={logout} title="Sign out">
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="px-6 pb-3">
        <nav className="flex items-center gap-1 text-sm">
          <button
            onClick={() => setCurrentFolderId(null)}
            className={`flex items-center gap-1 px-2 py-1 rounded-md transition-colors ${
              currentFolderId === null 
                ? 'text-primary font-medium' 
                : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Vault</span>
          </button>
          
          {folderPath.map((folder, index) => (
            <React.Fragment key={folder.id}>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
              <button
                onClick={() => setCurrentFolderId(folder.id)}
                className={`px-2 py-1 rounded-md transition-colors ${
                  index === folderPath.length - 1
                    ? 'text-primary font-medium'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                {folder.name}
              </button>
            </React.Fragment>
          ))}
        </nav>
      </div>
    </header>
  );
}
