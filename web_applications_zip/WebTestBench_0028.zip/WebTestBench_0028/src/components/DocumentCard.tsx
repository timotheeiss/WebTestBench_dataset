import React, { useState } from 'react';
import { Document } from '@/types/vault';
import { useVault } from '@/contexts/VaultContext';
import { 
  FileText, 
  Image, 
  File, 
  MoreVertical, 
  Pencil, 
  Trash2,
  Tag,
  Download,
  Lock,
  FolderInput
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface DocumentCardProps {
  document: Document;
  onRename: (doc: Document) => void;
  onEditTags: (doc: Document) => void;
  onMove: (doc: Document) => void;
}

function getFileIcon(mimeType: string) {
  if (mimeType.startsWith('image/')) {
    return <Image className="w-6 h-6" />;
  }
  if (mimeType === 'application/pdf' || mimeType.includes('document')) {
    return <FileText className="w-6 h-6" />;
  }
  return <File className="w-6 h-6" />;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function DocumentCard({ document, onRename, onEditTags, onMove }: DocumentCardProps) {
  const { deleteDocument } = useVault();
  const [isHovered, setIsHovered] = useState(false);

  const handleDelete = () => {
    if (confirm(`Delete "${document.name}"? This cannot be undone.`)) {
      deleteDocument(document.id);
    }
  };

  const handleDownload = () => {
    const link = window.document.createElement('a');
    link.href = document.content;
    link.download = document.name;
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
  };

  const isImage = document.mimeType.startsWith('image/');

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative overflow-hidden rounded-xl bg-card border border-border hover:border-primary/50 transition-all duration-200 animate-fade-in"
    >
      {/* Preview area */}
      <div className="relative h-32 bg-secondary/50 flex items-center justify-center overflow-hidden">
        {isImage ? (
          <img
            src={document.content}
            alt={document.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className={`p-4 rounded-xl transition-colors ${isHovered ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'}`}>
            {getFileIcon(document.mimeType)}
          </div>
        )}
        
        {/* Encryption indicator */}
        <div className="absolute top-2 right-2 p-1.5 rounded-md bg-background/80 backdrop-blur-sm">
          <Lock className="w-3 h-3 text-primary" />
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <h3 className="font-medium text-foreground truncate" title={document.name}>
              {document.name}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">
              {formatFileSize(document.size)} • {formatDate(document.updatedAt)}
            </p>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 shrink-0"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />
                Download
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onRename(document)}>
                <Pencil className="w-4 h-4 mr-2" />
                Rename
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEditTags(document)}>
                <Tag className="w-4 h-4 mr-2" />
                Edit Tags
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onMove(document)}>
                <FolderInput className="w-4 h-4 mr-2" />
                Move
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleDelete} className="text-destructive">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Tags */}
        {document.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {document.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
            {document.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{document.tags.length - 3}
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
