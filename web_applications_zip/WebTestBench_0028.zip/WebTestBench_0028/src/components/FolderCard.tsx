import React, { useState } from 'react';
import { useVault } from '@/contexts/VaultContext';
import { Folder as FolderType } from '@/types/vault';
import { 
  Folder, 
  ChevronRight, 
  MoreVertical, 
  Pencil, 
  Trash2,
  FolderOpen
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

interface FolderCardProps {
  folder: FolderType;
  onRename: (folder: FolderType) => void;
}

export function FolderCard({ folder, onRename }: FolderCardProps) {
  const { setCurrentFolderId, deleteFolder, getDocumentsByFolder, getFoldersByParent } = useVault();
  const [isHovered, setIsHovered] = useState(false);

  const documentCount = getDocumentsByFolder(folder.id).length;
  const subFolderCount = getFoldersByParent(folder.id).length;

  const handleClick = () => {
    setCurrentFolderId(folder.id);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`Delete folder "${folder.name}" and move all contents to root?`)) {
      deleteFolder(folder.id);
    }
  };

  return (
    <div
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative p-4 rounded-xl bg-card border border-border hover:border-primary/50 hover:bg-card/80 cursor-pointer transition-all duration-200 animate-fade-in"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg transition-colors ${isHovered ? 'bg-primary/20' : 'bg-secondary'}`}>
            {isHovered ? (
              <FolderOpen className="w-6 h-6 text-primary" />
            ) : (
              <Folder className="w-6 h-6 text-primary" />
            )}
          </div>
          <div>
            <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
              {folder.name}
            </h3>
            <p className="text-xs text-muted-foreground">
              {documentCount} document{documentCount !== 1 ? 's' : ''}
              {subFolderCount > 0 && `, ${subFolderCount} folder${subFolderCount !== 1 ? 's' : ''}`}
            </p>
          </div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
            >
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onRename(folder); }}>
              <Pencil className="w-4 h-4 mr-2" />
              Rename
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleDelete} className="text-destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
    </div>
  );
}
