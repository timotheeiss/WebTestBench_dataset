import React from 'react';
import { useVault } from '@/contexts/VaultContext';
import { Document } from '@/types/vault';
import { Button } from '@/components/ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from '@/components/ui/dialog';
import { FolderInput, Folder, Home } from 'lucide-react';

interface MoveModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  document: Document | null;
}

export function MoveModal({ open, onOpenChange, document }: MoveModalProps) {
  const { folders, moveDocument } = useVault();
  const [selectedFolder, setSelectedFolder] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (document) {
      setSelectedFolder(document.folderId);
    }
  }, [document]);

  const handleMove = () => {
    if (document) {
      moveDocument(document.id, selectedFolder);
      onOpenChange(false);
    }
  };

  if (!document) return null;

  // Get root folders
  const rootFolders = folders.filter(f => f.parentId === null);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderInput className="w-5 h-5 text-primary" />
            Move Document
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Select a destination for "{document.name}"
          </p>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {/* Root option */}
            <button
              onClick={() => setSelectedFolder(null)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                selectedFolder === null
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50 hover:bg-secondary'
              }`}
            >
              <Home className="w-5 h-5 text-primary" />
              <span className="font-medium">Root (Vault)</span>
            </button>

            {/* Folders */}
            {rootFolders.map((folder) => (
              <FolderOption
                key={folder.id}
                folder={folder}
                selectedFolder={selectedFolder}
                onSelect={setSelectedFolder}
                allFolders={folders}
                level={0}
              />
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleMove} disabled={selectedFolder === document.folderId}>
            Move Here
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface FolderOptionProps {
  folder: { id: string; name: string; parentId: string | null };
  selectedFolder: string | null;
  onSelect: (id: string) => void;
  allFolders: { id: string; name: string; parentId: string | null }[];
  level: number;
}

function FolderOption({ folder, selectedFolder, onSelect, allFolders, level }: FolderOptionProps) {
  const children = allFolders.filter(f => f.parentId === folder.id);

  return (
    <>
      <button
        onClick={() => onSelect(folder.id)}
        style={{ paddingLeft: `${12 + level * 20}px` }}
        className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
          selectedFolder === folder.id
            ? 'border-primary bg-primary/10'
            : 'border-border hover:border-primary/50 hover:bg-secondary'
        }`}
      >
        <Folder className="w-5 h-5 text-primary" />
        <span className="font-medium">{folder.name}</span>
      </button>
      {children.map((child) => (
        <FolderOption
          key={child.id}
          folder={child}
          selectedFolder={selectedFolder}
          onSelect={onSelect}
          allFolders={allFolders}
          level={level + 1}
        />
      ))}
    </>
  );
}
