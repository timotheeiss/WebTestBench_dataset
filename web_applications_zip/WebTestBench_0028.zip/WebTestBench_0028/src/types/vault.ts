export interface User {
  id: string;
  email: string;
  passwordHash: string;
  createdAt: string;
}

export interface Document {
  id: string;
  name: string;
  folderId: string | null;
  tags: string[];
  content: string; // base64 encoded
  mimeType: string;
  size: number;
  encryptedKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface Folder {
  id: string;
  name: string;
  parentId: string | null;
  createdAt: string;
}

export interface VaultState {
  documents: Document[];
  folders: Folder[];
  tags: string[];
}
