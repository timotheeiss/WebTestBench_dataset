// Simulated encryption utilities using Web Crypto API
// In a real app, this would use proper key derivation and encryption

export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function generateEncryptionKey(): Promise<string> {
  const key = await crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  const exported = await crypto.subtle.exportKey('raw', key);
  const keyArray = Array.from(new Uint8Array(exported));
  return keyArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function generateId(): string {
  return crypto.randomUUID();
}

// Simulated encryption - in production, use proper AES-GCM encryption
export async function encryptContent(content: string, key: string): Promise<string> {
  // For demo purposes, we just base64 encode with a simple XOR
  const encoder = new TextEncoder();
  const contentBytes = encoder.encode(content);
  const keyBytes = encoder.encode(key);
  
  const encrypted = new Uint8Array(contentBytes.length);
  for (let i = 0; i < contentBytes.length; i++) {
    encrypted[i] = contentBytes[i] ^ keyBytes[i % keyBytes.length];
  }
  
  return btoa(String.fromCharCode(...encrypted));
}

export async function decryptContent(encrypted: string, key: string): Promise<string> {
  const decoder = new TextDecoder();
  const encryptedBytes = new Uint8Array(
    atob(encrypted).split('').map(c => c.charCodeAt(0))
  );
  const keyBytes = new TextEncoder().encode(key);
  
  const decrypted = new Uint8Array(encryptedBytes.length);
  for (let i = 0; i < encryptedBytes.length; i++) {
    decrypted[i] = encryptedBytes[i] ^ keyBytes[i % keyBytes.length];
  }
  
  return decoder.decode(decrypted);
}
