import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Document, Folder, VaultState } from '@/types/vault';
import { generateId, generateEncryptionKey } from '@/lib/crypto';
import { useAuth } from './AuthContext';

interface VaultContextType {
  documents: Document[];
  folders: Folder[];
  tags: string[];
  currentFolderId: string | null;
  setCurrentFolderId: (id: string | null) => void;
  addDocument: (file: File, folderId: string | null, tags: string[]) => Promise<void>;
  deleteDocument: (id: string) => void;
  renameDocument: (id: string, newName: string) => void;
  updateDocumentTags: (id: string, tags: string[]) => void;
  moveDocument: (id: string, folderId: string | null) => void;
  addFolder: (name: string, parentId: string | null) => void;
  deleteFolder: (id: string) => void;
  renameFolder: (id: string, newName: string) => void;
  searchDocuments: (query: string) => Document[];
  getDocumentsByFolder: (folderId: string | null) => Document[];
  getFoldersByParent: (parentId: string | null) => Folder[];
  getFolderPath: (folderId: string | null) => Folder[];
}

const VaultContext = createContext<VaultContextType | null>(null);

const getStorageKey = (userId: string) => `vault_data_${userId}`;

// Default sample data
const createDefaultData = (): VaultState => ({
  documents: [],
  folders: [
    { id: 'folder-1', name: 'Personal', parentId: null, createdAt: new Date().toISOString() },
    { id: 'folder-2', name: 'Work', parentId: null, createdAt: new Date().toISOString() },
    { id: 'folder-3', name: 'Taxes', parentId: 'folder-1', createdAt: new Date().toISOString() },
  ],
  tags: ['important', 'archive', 'pending', 'confidential'],
});

export function VaultProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);

  // Load data when user changes
  useEffect(() => {
    if (user) {
      const storageKey = getStorageKey(user.id);
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        try {
          const data: VaultState = JSON.parse(stored);
          setDocuments(data.documents);
          setFolders(data.folders);
          setTags(data.tags);
        } catch {
          const defaultData = createDefaultData();
          setDocuments(defaultData.documents);
          setFolders(defaultData.folders);
          setTags(defaultData.tags);
        }
      } else {
        const defaultData = createDefaultData();
        setDocuments(defaultData.documents);
        setFolders(defaultData.folders);
        setTags(defaultData.tags);
        localStorage.setItem(storageKey, JSON.stringify(defaultData));
      }
    } else {
      setDocuments([]);
      setFolders([]);
      setTags([]);
      setCurrentFolderId(null);
    }
  }, [user]);

  // Save data when it changes
  const saveData = useCallback(() => {
    if (user) {
      const data: VaultState = { documents, folders, tags };
      localStorage.setItem(getStorageKey(user.id), JSON.stringify(data));
    }
  }, [user, documents, folders, tags]);

  useEffect(() => {
    saveData();
  }, [saveData]);

  const addDocument = async (file: File, folderId: string | null, docTags: string[]) => {
    const reader = new FileReader();
    
    return new Promise<void>((resolve) => {
      reader.onload = async () => {
        const content = reader.result as string;
        const encryptionKey = await generateEncryptionKey();
        
        const newDoc: Document = {
          id: generateId(),
          name: file.name,
          folderId,
          tags: docTags,
          content,
          mimeType: file.type,
          size: file.size,
          encryptedKey: encryptionKey,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        setDocuments(prev => [...prev, newDoc]);
        
        // Add new tags
        const newTags = docTags.filter(t => !tags.includes(t));
        if (newTags.length > 0) {
          setTags(prev => [...prev, ...newTags]);
        }
        
        resolve();
      };
      reader.readAsDataURL(file);
    });
  };

  const deleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
  };

  const renameDocument = (id: string, newName: string) => {
    setDocuments(prev =>
      prev.map(d =>
        d.id === id ? { ...d, name: newName, updatedAt: new Date().toISOString() } : d
      )
    );
  };

  const updateDocumentTags = (id: string, newTags: string[]) => {
    setDocuments(prev =>
      prev.map(d =>
        d.id === id ? { ...d, tags: newTags, updatedAt: new Date().toISOString() } : d
      )
    );
    
    // Add new tags to global tags
    const allNewTags = newTags.filter(t => !tags.includes(t));
    if (allNewTags.length > 0) {
      setTags(prev => [...prev, ...allNewTags]);
    }
  };

  const moveDocument = (id: string, folderId: string | null) => {
    setDocuments(prev =>
      prev.map(d =>
        d.id === id ? { ...d, folderId, updatedAt: new Date().toISOString() } : d
      )
    );
  };

  const addFolder = (name: string, parentId: string | null) => {
    const newFolder: Folder = {
      id: generateId(),
      name,
      parentId,
      createdAt: new Date().toISOString(),
    };
    setFolders(prev => [...prev, newFolder]);
  };

  const deleteFolder = (id: string) => {
    // Get all child folder IDs recursively
    const getAllChildIds = (folderId: string): string[] => {
      const children = folders.filter(f => f.parentId === folderId);
      return [folderId, ...children.flatMap(c => getAllChildIds(c.id))];
    };
    
    const idsToDelete = getAllChildIds(id);
    
    setFolders(prev => prev.filter(f => !idsToDelete.includes(f.id)));
    setDocuments(prev =>
      prev.map(d =>
        idsToDelete.includes(d.folderId ?? '') ? { ...d, folderId: null } : d
      )
    );
    
    if (idsToDelete.includes(currentFolderId ?? '')) {
      setCurrentFolderId(null);
    }
  };

  const renameFolder = (id: string, newName: string) => {
    setFolders(prev =>
      prev.map(f => (f.id === id ? { ...f, name: newName } : f))
    );
  };

  const searchDocuments = (query: string): Document[] => {
    const lowerQuery = query.toLowerCase();
    return documents.filter(
      d =>
        d.name.toLowerCase().includes(lowerQuery) ||
        d.tags.some(t => t.toLowerCase().includes(lowerQuery))
    );
  };

  const getDocumentsByFolder = (folderId: string | null): Document[] => {
    return documents.filter(d => d.folderId === folderId);
  };

  const getFoldersByParent = (parentId: string | null): Folder[] => {
    return folders.filter(f => f.parentId === parentId);
  };

  const getFolderPath = (folderId: string | null): Folder[] => {
    const path: Folder[] = [];
    let currentId = folderId;
    
    while (currentId) {
      const folder = folders.find(f => f.id === currentId);
      if (folder) {
        path.unshift(folder);
        currentId = folder.parentId;
      } else {
        break;
      }
    }
    
    return path;
  };

  return (
    <VaultContext.Provider
      value={{
        documents,
        folders,
        tags,
        currentFolderId,
        setCurrentFolderId,
        addDocument,
        deleteDocument,
        renameDocument,
        updateDocumentTags,
        moveDocument,
        addFolder,
        deleteFolder,
        renameFolder,
        searchDocuments,
        getDocumentsByFolder,
        getFoldersByParent,
        getFolderPath,
      }}
    >
      {children}
    </VaultContext.Provider>
  );
}

export function useVault() {
  const context = useContext(VaultContext);
  if (!context) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
}
