export const organizationInfo = {
  name: "Green Horizons Foundation",
  tagline: "Building sustainable futures for communities worldwide",
  year: 2024,
  foundedYear: 2015,
};

export const heroStats = [
  { value: "2.4M", label: "Lives Impacted", suffix: "+" },
  { value: "47", label: "Countries Reached", suffix: "" },
  { value: "156", label: "Projects Completed", suffix: "" },
  { value: "$18.2M", label: "Funds Raised", suffix: "" },
];

export const chapters = [
  { id: "overview", title: "Year in Review", number: 1 },
  { id: "programs", title: "Our Programs", number: 2 },
  { id: "impact", title: "Global Impact", number: 3 },
  { id: "financials", title: "Financial Stewardship", number: 4 },
  { id: "stories", title: "Stories of Change", number: 5 },
  { id: "future", title: "Looking Ahead", number: 6 },
];

export const yearlyGrowth = [
  { year: "2019", beneficiaries: 320000, projects: 28, volunteers: 1200 },
  { year: "2020", beneficiaries: 580000, projects: 45, volunteers: 2100 },
  { year: "2021", beneficiaries: 890000, projects: 72, volunteers: 3400 },
  { year: "2022", beneficiaries: 1450000, projects: 98, volunteers: 5200 },
  { year: "2023", beneficiaries: 1920000, projects: 128, volunteers: 7100 },
  { year: "2024", beneficiaries: 2400000, projects: 156, volunteers: 8900 },
];

export const programData = [
  {
    name: "Clean Water Initiative",
    description: "Providing access to safe drinking water in underserved communities",
    beneficiaries: 680000,
    icon: "droplets",
    color: "hsl(var(--chart-3))",
    percentage: 28,
  },
  {
    name: "Education for All",
    description: "Building schools and training teachers in rural areas",
    beneficiaries: 520000,
    icon: "graduation-cap",
    color: "hsl(var(--chart-1))",
    percentage: 22,
  },
  {
    name: "Sustainable Agriculture",
    description: "Teaching farming techniques that protect the environment",
    beneficiaries: 450000,
    icon: "sprout",
    color: "hsl(var(--chart-4))",
    percentage: 19,
  },
  {
    name: "Healthcare Access",
    description: "Mobile clinics and health education programs",
    beneficiaries: 380000,
    icon: "heart-pulse",
    color: "hsl(var(--chart-2))",
    percentage: 16,
  },
  {
    name: "Women's Empowerment",
    description: "Microfinance and skills training for women entrepreneurs",
    beneficiaries: 370000,
    icon: "users",
    color: "hsl(var(--chart-5))",
    percentage: 15,
  },
];

export const geographicData = [
  { region: "Sub-Saharan Africa", countries: 18, beneficiaries: 920000 },
  { region: "South Asia", countries: 8, beneficiaries: 650000 },
  { region: "Southeast Asia", countries: 7, beneficiaries: 420000 },
  { region: "Latin America", countries: 9, beneficiaries: 280000 },
  { region: "Middle East", countries: 5, beneficiaries: 130000 },
];

export const financialData = {
  totalRevenue: 18200000,
  breakdown: [
    { category: "Program Services", amount: 14560000, percentage: 80 },
    { category: "Administrative", amount: 1820000, percentage: 10 },
    { category: "Fundraising", amount: 1820000, percentage: 10 },
  ],
  sources: [
    { source: "Individual Donors", amount: 7280000, percentage: 40 },
    { source: "Foundation Grants", amount: 5460000, percentage: 30 },
    { source: "Corporate Partners", amount: 3640000, percentage: 20 },
    { source: "Government Grants", amount: 1820000, percentage: 10 },
  ],
};

export const impactStories = [
  {
    id: 1,
    name: "Maria Santos",
    location: "Guatemala",
    program: "Sustainable Agriculture",
    quote: "The training changed everything. My family now has food security, and I sell the surplus at the local market. For the first time, my children can focus on school instead of worrying about the next meal.",
    impact: "Increased farm yield by 300%",
  },
  {
    id: 2,
    name: "Kwame Asante",
    location: "Ghana",
    program: "Clean Water Initiative",
    quote: "Before the well, my daughter walked 3 hours each day for water. Now she attends school full-time and dreams of becoming a doctor.",
    impact: "Saved 6 hours daily for education",
  },
  {
    id: 3,
    name: "Priya Sharma",
    location: "India",
    program: "Women's Empowerment",
    quote: "The microloan helped me start my tailoring business. Today, I employ four other women from my village. We are not just surviving anymore—we are thriving.",
    impact: "Created 5 local jobs",
  },
];

export const futureGoals = [
  { goal: "Reach 5 million beneficiaries", target: 2026, progress: 48 },
  { goal: "Expand to 60 countries", target: 2025, progress: 78 },
  { goal: "Train 15,000 volunteers", target: 2025, progress: 59 },
  { goal: "Achieve carbon neutrality", target: 2027, progress: 35 },
];
