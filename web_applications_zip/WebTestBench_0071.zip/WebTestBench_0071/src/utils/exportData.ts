import {
  organizationInfo,
  yearlyGrowth,
  programData,
  geographicData,
  financialData,
  impactStories,
  futureGoals,
  chapters,
} from "@/data/reportData";

export type ExportFormat = "json" | "csv";

interface ChapterData {
  id: string;
  title: string;
  data: unknown;
}

const getChapterData = (chapterId: string): ChapterData | null => {
  switch (chapterId) {
    case "overview":
      return {
        id: chapterId,
        title: "Year in Review",
        data: {
          organizationInfo,
          yearlyGrowth,
        },
      };
    case "programs":
      return {
        id: chapterId,
        title: "Our Programs",
        data: programData,
      };
    case "impact":
      return {
        id: chapterId,
        title: "Global Impact",
        data: geographicData,
      };
    case "financials":
      return {
        id: chapterId,
        title: "Financial Stewardship",
        data: financialData,
      };
    case "stories":
      return {
        id: chapterId,
        title: "Stories of Change",
        data: impactStories,
      };
    case "future":
      return {
        id: chapterId,
        title: "Looking Ahead",
        data: futureGoals,
      };
    default:
      return null;
  }
};

const convertToCSV = (data: unknown, chapterId: string): string => {
  if (!data || typeof data !== "object") return "";

  // Handle arrays
  if (Array.isArray(data)) {
    if (data.length === 0) return "";
    const headers = Object.keys(data[0]);
    const rows = data.map((item) =>
      headers.map((h) => JSON.stringify(item[h] ?? "")).join(",")
    );
    return [headers.join(","), ...rows].join("\n");
  }

  // Handle objects with nested arrays (like financialData)
  if (chapterId === "financials") {
    const fd = data as typeof financialData;
    let csv = `Total Revenue,${fd.totalRevenue}\n\n`;
    csv += "Expense Breakdown\n";
    csv += "Category,Amount,Percentage\n";
    fd.breakdown.forEach((b) => {
      csv += `${b.category},${b.amount},${b.percentage}\n`;
    });
    csv += "\nFunding Sources\n";
    csv += "Source,Amount,Percentage\n";
    fd.sources.forEach((s) => {
      csv += `${s.source},${s.amount},${s.percentage}\n`;
    });
    return csv;
  }

  // Handle overview (has organizationInfo and yearlyGrowth)
  if (chapterId === "overview") {
    const od = data as { organizationInfo: typeof organizationInfo; yearlyGrowth: typeof yearlyGrowth };
    let csv = "Organization Info\n";
    csv += `Name,${od.organizationInfo.name}\n`;
    csv += `Year,${od.organizationInfo.year}\n`;
    csv += `Founded,${od.organizationInfo.foundedYear}\n\n`;
    csv += "Yearly Growth\n";
    csv += "Year,Beneficiaries,Projects,Volunteers\n";
    od.yearlyGrowth.forEach((y) => {
      csv += `${y.year},${y.beneficiaries},${y.projects},${y.volunteers}\n`;
    });
    return csv;
  }

  return JSON.stringify(data, null, 2);
};

export const exportChapterData = (chapterId: string, format: ExportFormat = "json"): void => {
  const chapterData = getChapterData(chapterId);
  
  if (!chapterData) {
    console.error(`No data found for chapter: ${chapterId}`);
    return;
  }

  let content: string;
  let mimeType: string;
  let extension: string;

  if (format === "csv") {
    content = convertToCSV(chapterData.data, chapterId);
    mimeType = "text/csv";
    extension = "csv";
  } else {
    content = JSON.stringify(chapterData, null, 2);
    mimeType = "application/json";
    extension = "json";
  }

  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${organizationInfo.name.replace(/\s+/g, "-")}_${chapterData.title.replace(/\s+/g, "-")}_${organizationInfo.year}.${extension}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const exportAllChaptersData = (format: ExportFormat = "json"): void => {
  const allData = chapters.map((chapter) => getChapterData(chapter.id)).filter(Boolean);

  let content: string;
  let mimeType: string;
  let extension: string;

  if (format === "csv") {
    content = allData.map((chapter) => {
      if (!chapter) return "";
      return `# ${chapter.title}\n${convertToCSV(chapter.data, chapter.id)}`;
    }).join("\n\n---\n\n");
    mimeType = "text/csv";
    extension = "csv";
  } else {
    content = JSON.stringify({ organization: organizationInfo, chapters: allData }, null, 2);
    mimeType = "application/json";
    extension = "json";
  }

  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${organizationInfo.name.replace(/\s+/g, "-")}_Annual-Report_${organizationInfo.year}.${extension}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
