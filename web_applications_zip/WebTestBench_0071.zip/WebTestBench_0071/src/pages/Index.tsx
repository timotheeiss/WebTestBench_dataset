import { useState, useEffect, createContext, useContext } from "react";
import { chapters, organizationInfo } from "@/data/reportData";
import { useFavorites } from "@/hooks/useFavorites";
import { useChartActivation, ChartError } from "@/hooks/useChartActivation";
import ChapterNavigation from "@/components/ChapterNavigation";
import HeroSection from "@/components/chapters/HeroSection";
import OverviewChapter from "@/components/chapters/OverviewChapter";
import ProgramsChapter from "@/components/chapters/ProgramsChapter";
import ImpactChapter from "@/components/chapters/ImpactChapter";
import FinancialsChapter from "@/components/chapters/FinancialsChapter";
import StoriesChapter from "@/components/chapters/StoriesChapter";
import FutureChapter from "@/components/chapters/FutureChapter";

// Context for sharing chapter state
interface ChapterContextType {
  activeChapter: string;
  favorites: {
    isFavorite: (id: string) => boolean;
    toggleFavorite: (id: string) => void;
  };
  chartActivation: {
    isChapterActive: (id: string) => boolean;
    activateChapter: (id: string) => void;
    handleChartInteraction: (id: string, action: "forward" | "reverse") => { success: boolean; error: ChartError | null };
    getChapterError: (id: string) => ChartError | undefined;
    clearError: (id: string) => void;
    isChapterLoading: (id: string) => boolean;
  };
}

export const ChapterContext = createContext<ChapterContextType | null>(null);

export const useChapterContext = () => {
  const context = useContext(ChapterContext);
  if (!context) {
    throw new Error("useChapterContext must be used within ChapterContext.Provider");
  }
  return context;
};

const Index = () => {
  const [activeChapter, setActiveChapter] = useState("overview");
  const { isFavorite, toggleFavorite } = useFavorites();
  const {
    activateChapter,
    isChapterActive,
    handleChartInteraction,
    getChapterError,
    clearError,
    isChapterLoading,
  } = useChartActivation(activeChapter);

  useEffect(() => {
    const handleScroll = () => {
      const sections = chapters.map((c) => ({
        id: c.id,
        element: document.getElementById(c.id),
      }));

      const scrollPosition = window.scrollY + window.innerHeight / 3;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section.element) {
          const top = section.element.offsetTop;
          if (scrollPosition >= top) {
            setActiveChapter(section.id);
            // Auto-activate chapter when scrolled to
            activateChapter(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [activateChapter]);

  const scrollToChapter = (chapterId: string) => {
    const element = document.getElementById(chapterId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToFirstChapter = () => {
    scrollToChapter("overview");
  };

  const contextValue: ChapterContextType = {
    activeChapter,
    favorites: { isFavorite, toggleFavorite },
    chartActivation: {
      isChapterActive,
      activateChapter,
      handleChartInteraction,
      getChapterError,
      clearError,
      isChapterLoading,
    },
  };

  return (
    <ChapterContext.Provider value={contextValue}>
      {/* SEO Meta Tags */}
      <title>{organizationInfo.name} - {organizationInfo.year} Annual Impact Report</title>
      <meta 
        name="description" 
        content={`Discover how ${organizationInfo.name} made a difference in ${organizationInfo.year}. Read our annual impact report showcasing 2.4M+ lives impacted across 47 countries.`} 
      />

      <main className="bg-background min-h-screen">
        <ChapterNavigation
          activeChapter={activeChapter}
          onChapterClick={scrollToChapter}
        />

        <HeroSection onScrollDown={scrollToFirstChapter} />
        <OverviewChapter />
        <ProgramsChapter />
        <ImpactChapter />
        <FinancialsChapter />
        <StoriesChapter />
        <FutureChapter />
      </main>
    </ChapterContext.Provider>
  );
};

export default Index;
