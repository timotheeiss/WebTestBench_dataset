import { Download, Heart, FileJson, FileSpreadsheet, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { exportChapterData, ExportFormat } from "@/utils/exportData";
import { cn } from "@/lib/utils";

interface ChapterToolbarProps {
  chapterId: string;
  chapterTitle: string;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  isLoading?: boolean;
  error?: string | null;
  onClearError?: () => void;
}

const ChapterToolbar = ({
  chapterId,
  chapterTitle,
  isFavorite,
  onToggleFavorite,
  isLoading = false,
  error = null,
  onClearError,
}: ChapterToolbarProps) => {
  const handleExport = (format: ExportFormat) => {
    exportChapterData(chapterId, format);
  };

  return (
    <div className="flex items-center gap-2 mb-6">
      <Button
        variant="outline"
        size="sm"
        onClick={onToggleFavorite}
        className={cn(
          "gap-2 transition-colors",
          isFavorite && "bg-accent/20 border-accent text-accent hover:bg-accent/30"
        )}
      >
        <Heart
          className={cn("w-4 h-4", isFavorite && "fill-accent")}
        />
        {isFavorite ? "Saved" : "Save"}
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="w-4 h-4" />
            Export
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <DropdownMenuItem onClick={() => handleExport("json")} className="gap-2">
            <FileJson className="w-4 h-4" />
            Export as JSON
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleExport("csv")} className="gap-2">
            <FileSpreadsheet className="w-4 h-4" />
            Export as CSV
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {isLoading && (
        <div className="flex items-center gap-2 text-muted-foreground text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Loading...
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 px-3 py-1.5 rounded-md">
          <span>{error}</span>
          {onClearError && (
            <button
              onClick={onClearError}
              className="text-xs underline hover:no-underline"
            >
              Dismiss
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ChapterToolbar;
