import { programData } from "@/data/reportData";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Droplets, GraduationCap, Sprout, HeartPulse, Users, LucideIcon } from "lucide-react";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";
import ChartWrapper from "@/components/ChartWrapper";

const CHAPTER_ID = "programs";

const iconMap: { [key: string]: LucideIcon } = {
  droplets: Droplets,
  "graduation-cap": GraduationCap,
  sprout: Sprout,
  "heart-pulse": HeartPulse,
  users: Users,
};

const ProgramsChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isActive = chartActivation.isChapterActive(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  const handleInteraction = (action: "forward" | "reverse") => {
    chartActivation.handleChartInteraction(CHAPTER_ID, action);
  };

  return (
    <section id={CHAPTER_ID} className="py-24 px-6 bg-secondary/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 02
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Our Programs
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            Five core initiatives working together to create lasting change in communities worldwide.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Our Programs"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Program Cards */}
          <div className="space-y-4">
            {programData.map((program, index) => {
              const Icon = iconMap[program.icon];
              return (
                <div
                  key={program.name}
                  className="bg-card rounded-xl p-6 shadow-soft hover:shadow-card transition-shadow duration-300"
                >
                  <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${program.color}20` }}
                  >
                    {Icon && <Icon className="w-6 h-6" color={program.color} />}
                  </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-display text-lg font-semibold text-foreground">
                          {program.name}
                        </h3>
                        <span className="font-body text-sm font-medium" style={{ color: program.color }}>
                          {program.percentage}%
                        </span>
                      </div>
                      <p className="font-body text-sm text-muted-foreground mb-3">
                        {program.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <div className="h-2 flex-1 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-1000"
                            style={{
                              width: `${program.percentage}%`,
                              backgroundColor: program.color,
                            }}
                          />
                        </div>
                        <span className="font-body text-xs text-muted-foreground whitespace-nowrap">
                          {program.beneficiaries.toLocaleString()} reached
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pie Chart */}
          <div className="bg-card rounded-2xl p-8 shadow-card sticky top-24">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6 text-center">
              Impact Distribution by Program
            </h3>
            <ChartWrapper
              chapterId={CHAPTER_ID}
              isActive={isActive}
              isLoading={isLoading}
              error={error?.message}
              onActivate={() => chartActivation.activateChapter(CHAPTER_ID)}
              onClearError={() => chartActivation.clearError(CHAPTER_ID)}
              onInteraction={handleInteraction}
            >
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={programData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={3}
                      dataKey="percentage"
                      nameKey="name"
                    >
                      {programData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '0.75rem',
                        fontFamily: 'var(--font-body)',
                      }}
                      formatter={(value: number, name: string) => [`${value}%`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </ChartWrapper>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {programData.map((program) => (
                <div key={program.name} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: program.color }}
                  />
                  <span className="font-body text-xs text-muted-foreground">
                    {program.name.split(' ')[0]}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProgramsChapter;
