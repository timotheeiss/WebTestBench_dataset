import { futureGoals, organizationInfo } from "@/data/reportData";
import { Target, ArrowRight, Download } from "lucide-react";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";
import { Button } from "@/components/ui/button";
import { exportAllChaptersData } from "@/utils/exportData";

const CHAPTER_ID = "future";

const FutureChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  return (
    <section id={CHAPTER_ID} className="py-24 px-6 bg-secondary/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 06
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Looking Ahead
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            Our vision for the future is ambitious, but with your continued support, 
            we know it's achievable.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Looking Ahead"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {futureGoals.map((goal, index) => (
            <div
              key={goal.goal}
              className="bg-card rounded-2xl p-8 shadow-card"
            >
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <Target className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-display text-xl font-semibold text-foreground mb-1">
                    {goal.goal}
                  </h3>
                  <p className="font-body text-sm text-muted-foreground">
                    Target Year: {goal.target}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-body text-sm text-muted-foreground">
                    Progress
                  </span>
                  <span className="font-display text-lg font-bold text-primary">
                    {goal.progress}%
                  </span>
                </div>
                <div className="h-3 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-hero rounded-full transition-all duration-1000"
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-hero rounded-3xl p-12 text-center">
          <h3 className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Join Us in Making a Difference
          </h3>
          <p className="font-body text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-8">
            Every contribution, no matter the size, helps us move closer to our goals. 
            Together, we can build a more sustainable and equitable world.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary-foreground text-primary font-body font-semibold rounded-xl hover:bg-primary-foreground/90 transition-colors">
              Donate Now
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-transparent border-2 border-primary-foreground/30 text-primary-foreground font-body font-semibold rounded-xl hover:bg-primary-foreground/10 transition-colors">
              Become a Volunteer
            </button>
          </div>
        </div>

        {/* Export Full Report */}
        <div className="mt-12 text-center">
          <p className="font-body text-muted-foreground mb-4">
            Download the complete annual report data
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              variant="outline"
              size="lg"
              onClick={() => exportAllChaptersData("json")}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Export Full Report (JSON)
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => exportAllChaptersData("csv")}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Export Full Report (CSV)
            </Button>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-24 pt-12 border-t border-border text-center">
          <p className="font-display text-2xl font-semibold text-foreground mb-2">
            {organizationInfo.name}
          </p>
          <p className="font-body text-muted-foreground mb-4">
            {organizationInfo.tagline}
          </p>
          <p className="font-body text-sm text-muted-foreground">
            © {organizationInfo.year} {organizationInfo.name}. All rights reserved.
          </p>
        </footer>
      </div>
    </section>
  );
};

export default FutureChapter;
