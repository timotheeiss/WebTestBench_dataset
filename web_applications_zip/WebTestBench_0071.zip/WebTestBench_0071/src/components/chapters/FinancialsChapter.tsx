import { financialData } from "@/data/reportData";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";
import ChartWrapper from "@/components/ChartWrapper";

const CHAPTER_ID = "financials";

const FinancialsChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isActive = chartActivation.isChapterActive(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  const handleInteraction = (action: "forward" | "reverse") => {
    chartActivation.handleChartInteraction(CHAPTER_ID, action);
  };

  const expenseColors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
  ];

  const sourceColors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
  ];

  return (
    <section id={CHAPTER_ID} className="py-24 px-6 bg-secondary/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 04
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Financial Stewardship
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            Transparency in how we manage donor contributions, with 80% going directly to programs.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Financial Stewardship"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        {/* Total Revenue */}
        <div className="bg-gradient-hero rounded-2xl p-10 text-center mb-12">
          <p className="font-body text-primary-foreground/70 uppercase tracking-widest text-sm mb-2">
            Total Revenue 2024
          </p>
          <div className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-primary-foreground">
            ${(financialData.totalRevenue / 1000000).toFixed(1)}M
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Expense Breakdown */}
          <div className="bg-card rounded-2xl p-8 shadow-card">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">
              How We Spend
            </h3>
            <div className="flex items-center gap-8">
              <ChartWrapper
                chapterId={CHAPTER_ID}
                isActive={isActive}
                isLoading={isLoading}
                error={error?.message}
                onActivate={() => chartActivation.activateChapter(CHAPTER_ID)}
                onClearError={() => chartActivation.clearError(CHAPTER_ID)}
                onInteraction={handleInteraction}
              >
                <div className="w-48 h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={financialData.breakdown}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="percentage"
                      >
                        {financialData.breakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={expenseColors[index]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '0.75rem',
                          fontFamily: 'var(--font-body)',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </ChartWrapper>
              <div className="flex-1 space-y-4">
                {financialData.breakdown.map((item, index) => (
                  <div key={item.category} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: expenseColors[index] }}
                      />
                      <span className="font-body text-sm text-foreground">
                        {item.category}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-display font-semibold text-foreground">
                        {item.percentage}%
                      </span>
                      <span className="font-body text-xs text-muted-foreground ml-2">
                        ${(item.amount / 1000000).toFixed(1)}M
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-6 p-4 bg-primary/10 rounded-xl">
              <p className="font-body text-sm text-foreground">
                <span className="font-semibold text-primary">80¢ of every dollar</span> goes directly 
                to our programs and the communities we serve.
              </p>
            </div>
          </div>

          {/* Funding Sources */}
          <div className="bg-card rounded-2xl p-8 shadow-card">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">
              Where Our Funding Comes From
            </h3>
            <div className="space-y-4">
              {financialData.sources.map((source, index) => (
                <div key={source.source}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-body text-sm text-foreground">
                      {source.source}
                    </span>
                    <span className="font-display font-semibold text-foreground">
                      ${(source.amount / 1000000).toFixed(1)}M
                    </span>
                  </div>
                  <div className="h-3 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{
                        width: `${source.percentage}%`,
                        backgroundColor: sourceColors[index],
                      }}
                    />
                  </div>
                  <p className="font-body text-xs text-muted-foreground mt-1 text-right">
                    {source.percentage}% of total
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinancialsChapter;
