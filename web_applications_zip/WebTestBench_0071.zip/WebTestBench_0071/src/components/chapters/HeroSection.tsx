import { organizationInfo, heroStats } from "@/data/reportData";
import StatCard from "@/components/StatCard";
import { ChevronDown } from "lucide-react";

interface HeroSectionProps {
  onScrollDown: () => void;
}

const HeroSection = ({ onScrollDown }: HeroSectionProps) => {
  return (
    <section className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-hero" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent_50%)]" />
      
      {/* Content */}
      <div className="relative z-10 flex-1 flex flex-col justify-center items-center px-6 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <p className="font-body text-primary-foreground/70 uppercase tracking-[0.3em] text-sm mb-6 opacity-0 animate-fade-in animation-delay-100">
            Annual Impact Report
          </p>
          
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-primary-foreground mb-4 opacity-0 animate-fade-in-up animation-delay-200">
            {organizationInfo.year}
          </h1>
          
          <h2 className="font-display text-2xl md:text-3xl lg:text-4xl text-primary-foreground/90 mb-6 opacity-0 animate-fade-in-up animation-delay-300">
            {organizationInfo.name}
          </h2>
          
          <p className="font-body text-lg md:text-xl text-primary-foreground/70 max-w-2xl mx-auto opacity-0 animate-fade-in animation-delay-400">
            {organizationInfo.tagline}
          </p>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="relative z-10 bg-primary/20 backdrop-blur-sm border-t border-primary-foreground/10">
        <div className="container mx-auto px-6 py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {heroStats.map((stat, index) => (
              <StatCard
                key={stat.label}
                value={stat.value}
                label={stat.label}
                suffix={stat.suffix}
                delay={600 + index * 150}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={onScrollDown}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary-foreground/60 hover:text-primary-foreground transition-colors animate-bounce"
        aria-label="Scroll to content"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
};

export default HeroSection;
