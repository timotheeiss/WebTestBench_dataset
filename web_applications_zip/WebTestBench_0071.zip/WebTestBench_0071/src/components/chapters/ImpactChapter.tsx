import { geographicData } from "@/data/reportData";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Globe, MapPin } from "lucide-react";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";
import ChartWrapper from "@/components/ChartWrapper";

const CHAPTER_ID = "impact";

const ImpactChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isActive = chartActivation.isChapterActive(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  const handleInteraction = (action: "forward" | "reverse") => {
    chartActivation.handleChartInteraction(CHAPTER_ID, action);
  };

  return (
    <section id={CHAPTER_ID} className="py-24 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 03
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Global Impact
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            From villages in sub-Saharan Africa to urban communities in South Asia, 
            our work spans continents and transforms lives.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Global Impact"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        {/* Global Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="bg-gradient-hero rounded-2xl p-8 text-center">
            <Globe className="w-10 h-10 text-primary-foreground/80 mx-auto mb-4" />
            <div className="font-display text-4xl font-bold text-primary-foreground mb-2">
              47
            </div>
            <div className="font-body text-primary-foreground/70 text-sm uppercase tracking-wider">
              Countries Reached
            </div>
          </div>
          <div className="bg-gradient-warm rounded-2xl p-8 text-center">
            <MapPin className="w-10 h-10 text-accent-foreground/80 mx-auto mb-4" />
            <div className="font-display text-4xl font-bold text-accent-foreground mb-2">
              312
            </div>
            <div className="font-body text-accent-foreground/70 text-sm uppercase tracking-wider">
              Active Communities
            </div>
          </div>
          <div className="bg-card rounded-2xl p-8 text-center shadow-card border border-border">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <span className="font-display text-lg font-bold text-primary">5</span>
            </div>
            <div className="font-display text-4xl font-bold text-foreground mb-2">
              Regions
            </div>
            <div className="font-body text-muted-foreground text-sm uppercase tracking-wider">
              Global Coverage
            </div>
          </div>
        </div>

        {/* Regional Breakdown */}
        <div className="bg-card rounded-2xl p-8 shadow-card">
          <h3 className="font-display text-2xl font-semibold text-foreground mb-8">
            Regional Impact Breakdown
          </h3>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Chart */}
            <ChartWrapper
              chapterId={CHAPTER_ID}
              isActive={isActive}
              isLoading={isLoading}
              error={error?.message}
              onActivate={() => chartActivation.activateChapter(CHAPTER_ID)}
              onClearError={() => chartActivation.clearError(CHAPTER_ID)}
              onInteraction={handleInteraction}
            >
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={geographicData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      type="number"
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
                    />
                    <YAxis
                      type="category"
                      dataKey="region"
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                      width={120}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '0.75rem',
                        fontFamily: 'var(--font-body)',
                      }}
                      formatter={(value: number) => [value.toLocaleString(), 'Beneficiaries']}
                    />
                    <Bar
                      dataKey="beneficiaries"
                      fill="hsl(var(--primary))"
                      radius={[0, 8, 8, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </ChartWrapper>

            {/* Region Details */}
            <div className="space-y-4">
              {geographicData.map((region, index) => (
                <div
                  key={region.region}
                  className="flex items-center justify-between p-4 bg-secondary/50 rounded-xl"
                >
                  <div>
                    <h4 className="font-display text-lg font-medium text-foreground">
                      {region.region}
                    </h4>
                    <p className="font-body text-sm text-muted-foreground">
                      {region.countries} countries • {region.beneficiaries.toLocaleString()} people reached
                    </p>
                  </div>
                  <div className="font-display text-2xl font-bold text-primary">
                    {Math.round((region.beneficiaries / 2400000) * 100)}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactChapter;
