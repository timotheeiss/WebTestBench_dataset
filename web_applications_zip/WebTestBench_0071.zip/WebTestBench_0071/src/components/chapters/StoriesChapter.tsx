import { impactStories } from "@/data/reportData";
import { Quote } from "lucide-react";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";

const CHAPTER_ID = "stories";

const StoriesChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  return (
    <section id={CHAPTER_ID} className="py-24 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 05
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Stories of Change
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            Behind every number is a person whose life has been transformed. 
            Here are some of their stories.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Stories of Change"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {impactStories.map((story, index) => (
            <div
              key={story.id}
              className="bg-card rounded-2xl p-8 shadow-card hover:shadow-glow transition-shadow duration-500 group"
            >
              <div className="flex items-center justify-between mb-6">
                <Quote className="w-10 h-10 text-accent/40 group-hover:text-accent transition-colors" />
                <span className="px-3 py-1 bg-primary/10 rounded-full font-body text-xs text-primary font-medium">
                  {story.program}
                </span>
              </div>
              
              <blockquote className="font-display text-lg text-foreground italic leading-relaxed mb-6">
                "{story.quote}"
              </blockquote>
              
              <div className="border-t border-border pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-display font-semibold text-foreground">
                      {story.name}
                    </h4>
                    <p className="font-body text-sm text-muted-foreground">
                      {story.location}
                    </p>
                  </div>
                </div>
                <div className="mt-4 px-3 py-2 bg-accent/10 rounded-lg">
                  <p className="font-body text-sm text-accent font-medium">
                    Impact: {story.impact}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StoriesChapter;
