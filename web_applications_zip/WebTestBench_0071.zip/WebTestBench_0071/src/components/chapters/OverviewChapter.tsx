import { yearlyGrowth, organizationInfo } from "@/data/reportData";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useChapterContext } from "@/pages/Index";
import ChapterToolbar from "@/components/ChapterToolbar";
import ChartWrapper from "@/components/ChartWrapper";

const CHAPTER_ID = "overview";

const OverviewChapter = () => {
  const { favorites, chartActivation } = useChapterContext();
  const isFavorite = favorites.isFavorite(CHAPTER_ID);
  const isActive = chartActivation.isChapterActive(CHAPTER_ID);
  const isLoading = chartActivation.isChapterLoading(CHAPTER_ID);
  const error = chartActivation.getChapterError(CHAPTER_ID);

  const handleInteraction = (action: "forward" | "reverse") => {
    chartActivation.handleChartInteraction(CHAPTER_ID, action);
  };

  return (
    <section id={CHAPTER_ID} className="py-24 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <span className="font-body text-accent uppercase tracking-widest text-sm font-medium">
            Chapter 01
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mt-4 mb-6">
            Year in Review
          </h2>
          <p className="font-body text-lg text-muted-foreground max-w-2xl mx-auto">
            {organizationInfo.year} marked our most impactful year yet, with unprecedented growth 
            across all programs and regions.
          </p>
        </div>

        <ChapterToolbar
          chapterId={CHAPTER_ID}
          chapterTitle="Year in Review"
          isFavorite={isFavorite}
          onToggleFavorite={() => favorites.toggleFavorite(CHAPTER_ID)}
          isLoading={isLoading}
          error={error?.message}
          onClearError={() => chartActivation.clearError(CHAPTER_ID)}
        />

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="bg-card rounded-2xl p-8 shadow-card">
              <h3 className="font-display text-2xl font-semibold text-foreground mb-4">
                A Decade of Growth
              </h3>
              <p className="font-body text-muted-foreground leading-relaxed mb-6">
                Since our founding in {organizationInfo.foundedYear}, we've grown from a small 
                team of 12 volunteers to a global network of nearly 9,000 dedicated individuals. 
                This year alone, we welcomed 1,800 new volunteers and expanded our reach to 
                8 additional countries.
              </p>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-secondary rounded-xl">
                  <div className="font-display text-2xl font-bold text-primary">650%</div>
                  <div className="font-body text-xs text-muted-foreground mt-1">5-Year Growth</div>
                </div>
                <div className="text-center p-4 bg-secondary rounded-xl">
                  <div className="font-display text-2xl font-bold text-primary">8,900</div>
                  <div className="font-body text-xs text-muted-foreground mt-1">Active Volunteers</div>
                </div>
                <div className="text-center p-4 bg-secondary rounded-xl">
                  <div className="font-display text-2xl font-bold text-primary">156</div>
                  <div className="font-body text-xs text-muted-foreground mt-1">Projects This Year</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-8 shadow-card">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">
              Beneficiaries Reached Over Time
            </h3>
            <ChartWrapper
              chapterId={CHAPTER_ID}
              isActive={isActive}
              isLoading={isLoading}
              error={error?.message}
              onActivate={() => chartActivation.activateChapter(CHAPTER_ID)}
              onClearError={() => chartActivation.clearError(CHAPTER_ID)}
              onInteraction={handleInteraction}
            >
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={yearlyGrowth}>
                    <defs>
                      <linearGradient id="beneficiariesGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="year" 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                    />
                    <YAxis 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                      tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '0.75rem',
                        fontFamily: 'var(--font-body)',
                      }}
                      formatter={(value: number) => [value.toLocaleString(), 'Beneficiaries']}
                    />
                    <Area
                      type="monotone"
                      dataKey="beneficiaries"
                      stroke="hsl(var(--primary))"
                      strokeWidth={3}
                      fill="url(#beneficiariesGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </ChartWrapper>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OverviewChapter;
