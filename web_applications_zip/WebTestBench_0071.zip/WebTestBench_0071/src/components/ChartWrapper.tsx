import { ReactNode, useState, useCallback } from "react";
import { AlertTriangle, RefreshCw, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ChartWrapperProps {
  children: ReactNode;
  chapterId: string;
  isActive: boolean;
  isLoading: boolean;
  error?: string | null;
  onActivate: () => void;
  onClearError: () => void;
  onInteraction?: (action: "forward" | "reverse") => void;
}

const ChartWrapper = ({
  children,
  chapterId,
  isActive,
  isLoading,
  error,
  onActivate,
  onClearError,
  onInteraction,
}: ChartWrapperProps) => {
  const [lastScrollY, setLastScrollY] = useState(0);

  const handleMouseEnter = useCallback(() => {
    setLastScrollY(window.scrollY);
  }, []);

  const handleScroll = useCallback(() => {
    if (!isActive || !onInteraction) return;
    
    const currentScrollY = window.scrollY;
    if (currentScrollY < lastScrollY - 50) {
      // Reverse scroll detected (scrolling up significantly)
      onInteraction("reverse");
    } else if (currentScrollY > lastScrollY + 10) {
      onInteraction("forward");
    }
    setLastScrollY(currentScrollY);
  }, [isActive, lastScrollY, onInteraction]);

  // Add scroll listener when chart is active
  if (typeof window !== "undefined" && isActive && onInteraction) {
    window.addEventListener("scroll", handleScroll, { passive: true });
  }

  if (!isActive) {
    return (
      <div
        className="relative h-full min-h-[200px] flex items-center justify-center bg-muted/50 rounded-xl border border-dashed border-border"
        onMouseEnter={handleMouseEnter}
      >
        <div className="absolute inset-0 backdrop-blur-sm bg-background/50 rounded-xl flex flex-col items-center justify-center gap-4 z-10">
          <Lock className="w-8 h-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground text-center max-w-xs">
            Scroll to this chapter to activate chart interactions
          </p>
          <Button variant="outline" size="sm" onClick={onActivate} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Activate Now
          </Button>
        </div>
        <div className="opacity-30 pointer-events-none">{children}</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="relative h-full min-h-[200px]">
        <div className="absolute inset-0 bg-background/80 rounded-xl flex items-center justify-center z-10">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-muted-foreground">Loading chart data...</p>
          </div>
        </div>
        <div className="opacity-30 pointer-events-none">{children}</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="relative h-full min-h-[200px]">
        <div className="absolute inset-0 bg-destructive/5 border border-destructive/20 rounded-xl flex flex-col items-center justify-center gap-4 z-10">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm text-destructive text-center max-w-xs">{error}</p>
          <Button
            variant="outline"
            size="sm"
            onClick={onClearError}
            className="gap-2 border-destructive/30 text-destructive hover:bg-destructive/10"
          >
            <RefreshCw className="w-4 h-4" />
            Retry
          </Button>
        </div>
        <div className="opacity-20 pointer-events-none">{children}</div>
      </div>
    );
  }

  return (
    <div className={cn("relative h-full transition-opacity duration-300")} onMouseEnter={handleMouseEnter}>
      {children}
    </div>
  );
};

export default ChartWrapper;
