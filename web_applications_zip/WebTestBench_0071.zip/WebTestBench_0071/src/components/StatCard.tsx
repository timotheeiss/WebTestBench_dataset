interface StatCardProps {
  value: string;
  label: string;
  suffix?: string;
  delay?: number;
}

const StatCard = ({ value, label, suffix = "", delay = 0 }: StatCardProps) => {
  return (
    <div
      className="text-center opacity-0 animate-count-up"
      style={{ animationDelay: `${delay}ms`, animationFillMode: "forwards" }}
    >
      <div className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-2">
        {value}
        {suffix && <span className="text-primary-foreground/70">{suffix}</span>}
      </div>
      <div className="font-body text-sm md:text-base text-primary-foreground/80 uppercase tracking-wider">
        {label}
      </div>
    </div>
  );
};

export default StatCard;
