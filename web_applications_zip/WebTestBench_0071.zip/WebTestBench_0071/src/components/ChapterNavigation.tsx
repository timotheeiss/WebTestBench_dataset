import { chapters } from "@/data/reportData";

interface ChapterNavigationProps {
  activeChapter: string;
  onChapterClick: (chapterId: string) => void;
}

const ChapterNavigation = ({ activeChapter, onChapterClick }: ChapterNavigationProps) => {
  return (
    <nav className="fixed right-6 top-1/2 -translate-y-1/2 z-50 hidden lg:block">
      <ul className="flex flex-col gap-3">
        {chapters.map((chapter) => (
          <li key={chapter.id}>
            <button
              onClick={() => onChapterClick(chapter.id)}
              className="group flex items-center gap-3"
              aria-label={`Go to ${chapter.title}`}
            >
              <span
                className={`hidden group-hover:block text-right text-sm font-body transition-all duration-300 ${
                  activeChapter === chapter.id
                    ? "text-primary font-medium"
                    : "text-muted-foreground"
                }`}
              >
                {chapter.title}
              </span>
              <span
                className={`w-3 h-3 rounded-full border-2 transition-all duration-300 ${
                  activeChapter === chapter.id
                    ? "bg-primary border-primary scale-125"
                    : "border-muted-foreground/40 group-hover:border-primary group-hover:scale-110"
                }`}
              />
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default ChapterNavigation;
