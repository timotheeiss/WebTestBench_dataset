import { useState, useEffect, useCallback } from "react";

const FAVORITES_STORAGE_KEY = "nonprofit-report-favorites";

export const useFavorites = () => {
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  useEffect(() => {
    try {
      const stored = localStorage.getItem(FAVORITES_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setFavorites(new Set(parsed));
      }
    } catch (error) {
      console.warn("Failed to load favorites from localStorage:", error);
    }
  }, []);

  const saveFavorites = useCallback((newFavorites: Set<string>) => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify([...newFavorites]));
    } catch (error) {
      console.warn("Failed to save favorites to localStorage:", error);
    }
  }, []);

  const toggleFavorite = useCallback((chapterId: string) => {
    setFavorites((prev) => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(chapterId)) {
        newFavorites.delete(chapterId);
      } else {
        newFavorites.add(chapterId);
      }
      saveFavorites(newFavorites);
      return newFavorites;
    });
  }, [saveFavorites]);

  const isFavorite = useCallback((chapterId: string) => {
    return favorites.has(chapterId);
  }, [favorites]);

  return { favorites, toggleFavorite, isFavorite };
};
