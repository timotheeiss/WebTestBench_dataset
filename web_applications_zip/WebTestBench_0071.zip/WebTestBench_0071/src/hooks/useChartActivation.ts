import { useState, useCallback } from "react";

export interface ChartError {
  chapterId: string;
  message: string;
  timestamp: Date;
}

export const useChartActivation = (activeChapter: string) => {
  const [activatedChapters, setActivatedChapters] = useState<Set<string>>(new Set());
  const [chartErrors, setChartErrors] = useState<ChartError[]>([]);
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});

  const activateChapter = useCallback((chapterId: string) => {
    if (activatedChapters.has(chapterId)) return;
    
    setIsLoading((prev) => ({ ...prev, [chapterId]: true }));
    
    // Simulate data loading
    setTimeout(() => {
      setActivatedChapters((prev) => new Set(prev).add(chapterId));
      setIsLoading((prev) => ({ ...prev, [chapterId]: false }));
    }, 500);
  }, [activatedChapters]);

  const isChapterActive = useCallback((chapterId: string) => {
    return activatedChapters.has(chapterId);
  }, [activatedChapters]);

  const handleChartInteraction = useCallback((chapterId: string, action: "forward" | "reverse") => {
    // Clear previous errors for this chapter
    setChartErrors((prev) => prev.filter((e) => e.chapterId !== chapterId));

    if (!activatedChapters.has(chapterId)) {
      const error: ChartError = {
        chapterId,
        message: "Please activate this chapter first by scrolling to it",
        timestamp: new Date(),
      };
      setChartErrors((prev) => [...prev, error]);
      return { success: false, error };
    }

    if (action === "reverse") {
      // Trigger data loading error for reverse operations
      setIsLoading((prev) => ({ ...prev, [chapterId]: true }));
      
      setTimeout(() => {
        const error: ChartError = {
          chapterId,
          message: "Data loading error: Reverse operation not permitted. Please reload the chapter.",
          timestamp: new Date(),
        };
        setChartErrors((prev) => [...prev, error]);
        setIsLoading((prev) => ({ ...prev, [chapterId]: false }));
      }, 300);
      
      return { success: false, error: null };
    }

    return { success: true, error: null };
  }, [activatedChapters]);

  const getChapterError = useCallback((chapterId: string) => {
    return chartErrors.find((e) => e.chapterId === chapterId);
  }, [chartErrors]);

  const clearError = useCallback((chapterId: string) => {
    setChartErrors((prev) => prev.filter((e) => e.chapterId !== chapterId));
  }, []);

  const isChapterLoading = useCallback((chapterId: string) => {
    return isLoading[chapterId] || false;
  }, [isLoading]);

  return {
    activateChapter,
    isChapterActive,
    handleChartInteraction,
    getChapterError,
    clearError,
    isChapterLoading,
  };
};
