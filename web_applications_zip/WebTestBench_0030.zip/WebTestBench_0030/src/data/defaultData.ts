import { Note, Folder, Tag } from '@/types/notes';

export const defaultFolders: Folder[] = [
  { id: 'folder-1', name: 'Personal', createdAt: '2024-01-15T10:00:00Z' },
  { id: 'folder-2', name: 'Work', createdAt: '2024-01-15T10:01:00Z' },
  { id: 'folder-3', name: 'Ideas', createdAt: '2024-01-15T10:02:00Z' },
];

export const defaultTags: Tag[] = [
  { id: 'tag-1', name: 'Important', color: 'red' },
  { id: 'tag-2', name: 'To-Do', color: 'orange' },
  { id: 'tag-3', name: 'Reference', color: 'blue' },
  { id: 'tag-4', name: 'Idea', color: 'green' },
  { id: 'tag-5', name: 'Meeting', color: 'purple' },
];

export const defaultNotes: Note[] = [
  {
    id: 'note-1',
    title: 'Welcome to Notes',
    content: `<h1>Welcome to Your Notes App</h1>
<p>This is your personal space for capturing thoughts, ideas, and important information. Here's what you can do:</p>
<h2>Rich Text Editing</h2>
<ul>
<li>Format text with <strong>bold</strong>, <em>italic</em>, and more</li>
<li>Create headings and lists</li>
<li>Add blockquotes for emphasis</li>
</ul>
<h2>Organization</h2>
<p>Use <strong>folders</strong> to group related notes and <strong>tags</strong> to categorize them by topic or priority.</p>
<blockquote>Pro tip: Use the search bar to quickly find any note by title, content, or tags!</blockquote>`,
    folderId: null,
    tagIds: ['tag-3'],
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'note-2',
    title: 'Project Planning',
    content: `<h1>Q1 Project Roadmap</h1>
<p>Key initiatives for this quarter:</p>
<h2>Phase 1: Research</h2>
<ul>
<li>User interviews and surveys</li>
<li>Competitive analysis</li>
<li>Technical feasibility study</li>
</ul>
<h2>Phase 2: Design</h2>
<ul>
<li>Wireframes and prototypes</li>
<li>Design system updates</li>
<li>Stakeholder review</li>
</ul>
<h2>Phase 3: Development</h2>
<p>Begin implementation with the core features identified during research.</p>`,
    folderId: 'folder-2',
    tagIds: ['tag-1', 'tag-2'],
    createdAt: '2024-01-16T09:00:00Z',
    updatedAt: '2024-01-18T14:30:00Z',
  },
  {
    id: 'note-3',
    title: 'Book Recommendations',
    content: `<h1>Books to Read</h1>
<h2>Currently Reading</h2>
<p><strong>Atomic Habits</strong> by James Clear - Excellent insights on building good habits and breaking bad ones.</p>
<h2>Up Next</h2>
<ul>
<li>Deep Work by Cal Newport</li>
<li>The Design of Everyday Things by Don Norman</li>
<li>Thinking, Fast and Slow by Daniel Kahneman</li>
</ul>
<h2>Finished</h2>
<ul>
<li>✓ The Pragmatic Programmer</li>
<li>✓ Clean Code</li>
</ul>`,
    folderId: 'folder-1',
    tagIds: ['tag-3'],
    createdAt: '2024-01-17T15:00:00Z',
    updatedAt: '2024-01-20T11:00:00Z',
  },
  {
    id: 'note-4',
    title: 'App Feature Ideas',
    content: `<h1>Feature Ideas for Notes App</h1>
<p>Some ideas to explore for future versions:</p>
<h2>Collaboration</h2>
<ul>
<li>Share notes with others</li>
<li>Real-time collaborative editing</li>
<li>Comments and annotations</li>
</ul>
<h2>Productivity</h2>
<ul>
<li>Task lists with due dates</li>
<li>Reminders and notifications</li>
<li>Calendar integration</li>
</ul>
<blockquote>Remember: Start simple, iterate based on feedback!</blockquote>`,
    folderId: 'folder-3',
    tagIds: ['tag-4'],
    createdAt: '2024-01-18T16:00:00Z',
    updatedAt: '2024-01-18T16:00:00Z',
  },
  {
    id: 'note-5',
    title: 'Weekly Team Standup',
    content: `<h1>Team Standup Notes - Week 3</h1>
<h2>Updates</h2>
<p><strong>Design Team:</strong> Completed new dashboard mockups, ready for review.</p>
<p><strong>Engineering:</strong> API refactor is 80% complete, on track for Friday.</p>
<p><strong>Product:</strong> Customer feedback sessions scheduled for next week.</p>
<h2>Blockers</h2>
<ul>
<li>Waiting on third-party API documentation</li>
<li>Need additional QA resources</li>
</ul>
<h2>Action Items</h2>
<ul>
<li>Schedule design review meeting</li>
<li>Follow up with vendor on API docs</li>
</ul>`,
    folderId: 'folder-2',
    tagIds: ['tag-5', 'tag-2'],
    createdAt: '2024-01-19T10:00:00Z',
    updatedAt: '2024-01-19T10:30:00Z',
  },
];

export const STORAGE_KEY = 'notes-app-data';
