import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Note, Folder, Tag, NotesState, TagColor } from '@/types/notes';
import { defaultNotes, defaultFolders, defaultTags, STORAGE_KEY } from '@/data/defaultData';

type Action =
  | { type: 'SET_STATE'; payload: NotesState }
  | { type: 'CREATE_NOTE'; payload: { title?: string; folderId?: string | null } }
  | { type: 'UPDATE_NOTE'; payload: { id: string; updates: Partial<Note> } }
  | { type: 'DELETE_NOTE'; payload: string }
  | { type: 'SELECT_NOTE'; payload: string | null }
  | { type: 'CREATE_FOLDER'; payload: string }
  | { type: 'RENAME_FOLDER'; payload: { id: string; name: string } }
  | { type: 'DELETE_FOLDER'; payload: string }
  | { type: 'SELECT_FOLDER'; payload: string | null }
  | { type: 'MOVE_NOTE_TO_FOLDER'; payload: { noteId: string; folderId: string | null } }
  | { type: 'CREATE_TAG'; payload: { name: string; color: TagColor } }
  | { type: 'DELETE_TAG'; payload: string }
  | { type: 'SELECT_TAG'; payload: string | null }
  | { type: 'ADD_TAG_TO_NOTE'; payload: { noteId: string; tagId: string } }
  | { type: 'REMOVE_TAG_FROM_NOTE'; payload: { noteId: string; tagId: string } }
  | { type: 'SET_SEARCH_QUERY'; payload: string };

const initialState: NotesState = {
  notes: defaultNotes,
  folders: defaultFolders,
  tags: defaultTags,
  selectedNoteId: null,
  selectedFolderId: null,
  selectedTagId: null,
  searchQuery: '',
};

function notesReducer(state: NotesState, action: Action): NotesState {
  switch (action.type) {
    case 'SET_STATE':
      return action.payload;

    case 'CREATE_NOTE': {
      const now = new Date().toISOString();
      const newNote: Note = {
        id: uuidv4(),
        title: action.payload.title || 'Untitled Note',
        content: '',
        folderId: action.payload.folderId ?? state.selectedFolderId,
        tagIds: state.selectedTagId ? [state.selectedTagId] : [],
        createdAt: now,
        updatedAt: now,
      };
      return {
        ...state,
        notes: [newNote, ...state.notes],
        selectedNoteId: newNote.id,
      };
    }

    case 'UPDATE_NOTE': {
      const now = new Date().toISOString();
      return {
        ...state,
        notes: state.notes.map((note) =>
          note.id === action.payload.id
            ? { ...note, ...action.payload.updates, updatedAt: now }
            : note
        ),
      };
    }

    case 'DELETE_NOTE': {
      const newNotes = state.notes.filter((note) => note.id !== action.payload);
      return {
        ...state,
        notes: newNotes,
        selectedNoteId: state.selectedNoteId === action.payload ? null : state.selectedNoteId,
      };
    }

    case 'SELECT_NOTE':
      return { ...state, selectedNoteId: action.payload };

    case 'CREATE_FOLDER': {
      const newFolder: Folder = {
        id: uuidv4(),
        name: action.payload,
        createdAt: new Date().toISOString(),
      };
      return { ...state, folders: [...state.folders, newFolder] };
    }

    case 'RENAME_FOLDER':
      return {
        ...state,
        folders: state.folders.map((folder) =>
          folder.id === action.payload.id
            ? { ...folder, name: action.payload.name }
            : folder
        ),
      };

    case 'DELETE_FOLDER': {
      // Move notes from deleted folder to no folder
      const updatedNotes = state.notes.map((note) =>
        note.folderId === action.payload ? { ...note, folderId: null } : note
      );
      return {
        ...state,
        folders: state.folders.filter((folder) => folder.id !== action.payload),
        notes: updatedNotes,
        selectedFolderId: state.selectedFolderId === action.payload ? null : state.selectedFolderId,
      };
    }

    case 'SELECT_FOLDER':
      return { ...state, selectedFolderId: action.payload, selectedNoteId: null };

    case 'MOVE_NOTE_TO_FOLDER':
      return {
        ...state,
        notes: state.notes.map((note) =>
          note.id === action.payload.noteId
            ? { ...note, folderId: action.payload.folderId, updatedAt: new Date().toISOString() }
            : note
        ),
      };

    case 'CREATE_TAG': {
      const newTag: Tag = {
        id: uuidv4(),
        name: action.payload.name,
        color: action.payload.color,
      };
      return { ...state, tags: [...state.tags, newTag] };
    }

    case 'DELETE_TAG': {
      // Remove tag from all notes
      const updatedNotes = state.notes.map((note) => ({
        ...note,
        tagIds: note.tagIds.filter((tagId) => tagId !== action.payload),
      }));
      return {
        ...state,
        tags: state.tags.filter((tag) => tag.id !== action.payload),
        notes: updatedNotes,
        selectedTagId: state.selectedTagId === action.payload ? null : state.selectedTagId,
      };
    }

    case 'SELECT_TAG':
      return { ...state, selectedTagId: action.payload, selectedNoteId: null };

    case 'ADD_TAG_TO_NOTE':
      return {
        ...state,
        notes: state.notes.map((note) =>
          note.id === action.payload.noteId && !note.tagIds.includes(action.payload.tagId)
            ? { ...note, tagIds: [...note.tagIds, action.payload.tagId], updatedAt: new Date().toISOString() }
            : note
        ),
      };

    case 'REMOVE_TAG_FROM_NOTE':
      return {
        ...state,
        notes: state.notes.map((note) =>
          note.id === action.payload.noteId
            ? { ...note, tagIds: note.tagIds.filter((id) => id !== action.payload.tagId), updatedAt: new Date().toISOString() }
            : note
        ),
      };

    case 'SET_SEARCH_QUERY':
      return { ...state, searchQuery: action.payload, selectedNoteId: null };

    default:
      return state;
  }
}

interface NotesContextType {
  state: NotesState;
  dispatch: React.Dispatch<Action>;
  filteredNotes: Note[];
  selectedNote: Note | null;
}

const NotesContext = createContext<NotesContextType | null>(null);

export function NotesProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(notesReducer, initialState);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        dispatch({ type: 'SET_STATE', payload: { ...initialState, ...parsed, selectedNoteId: null } });
      }
    } catch (error) {
      console.error('Failed to load notes from localStorage:', error);
    }
  }, []);

  // Save to localStorage on state changes
  useEffect(() => {
    try {
      const toSave = {
        notes: state.notes,
        folders: state.folders,
        tags: state.tags,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch (error) {
      console.error('Failed to save notes to localStorage:', error);
    }
  }, [state.notes, state.folders, state.tags]);

  // Filter notes based on selection and search
  const filteredNotes = React.useMemo(() => {
    let notes = [...state.notes];

    // Filter by folder
    if (state.selectedFolderId !== null) {
      notes = notes.filter((note) => note.folderId === state.selectedFolderId);
    }

    // Filter by tag
    if (state.selectedTagId !== null) {
      notes = notes.filter((note) => note.tagIds.includes(state.selectedTagId!));
    }

    // Filter by search query
    if (state.searchQuery) {
      const query = state.searchQuery.toLowerCase();
      notes = notes.filter((note) => {
        const titleMatch = note.title.toLowerCase().includes(query);
        const contentMatch = note.content.toLowerCase().includes(query);
        const tagMatch = note.tagIds.some((tagId) => {
          const tag = state.tags.find((t) => t.id === tagId);
          return tag?.name.toLowerCase().includes(query);
        });
        const folderMatch = state.folders.find((f) => f.id === note.folderId)?.name.toLowerCase().includes(query);
        return titleMatch || contentMatch || tagMatch || folderMatch;
      });
    }

    // Sort by updated date (newest first)
    return notes.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }, [state.notes, state.folders, state.tags, state.selectedFolderId, state.selectedTagId, state.searchQuery]);

  const selectedNote = state.selectedNoteId
    ? state.notes.find((note) => note.id === state.selectedNoteId) || null
    : null;

  return (
    <NotesContext.Provider value={{ state, dispatch, filteredNotes, selectedNote }}>
      {children}
    </NotesContext.Provider>
  );
}

export function useNotes() {
  const context = useContext(NotesContext);
  if (!context) {
    throw new Error('useNotes must be used within a NotesProvider');
  }
  return context;
}
