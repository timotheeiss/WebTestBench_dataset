import { cn } from '@/lib/utils';
import { Tag, TagColor } from '@/types/notes';
import { X } from 'lucide-react';

interface TagBadgeProps {
  tag: Tag;
  onClick?: () => void;
  onRemove?: () => void;
  selected?: boolean;
  size?: 'sm' | 'md';
}

const colorClasses: Record<TagColor, string> = {
  red: 'bg-tag-red/15 text-tag-red hover:bg-tag-red/25',
  orange: 'bg-tag-orange/15 text-tag-orange hover:bg-tag-orange/25',
  yellow: 'bg-tag-yellow/15 text-tag-yellow hover:bg-tag-yellow/25',
  green: 'bg-tag-green/15 text-tag-green hover:bg-tag-green/25',
  teal: 'bg-tag-teal/15 text-tag-teal hover:bg-tag-teal/25',
  blue: 'bg-tag-blue/15 text-tag-blue hover:bg-tag-blue/25',
  purple: 'bg-tag-purple/15 text-tag-purple hover:bg-tag-purple/25',
  pink: 'bg-tag-pink/15 text-tag-pink hover:bg-tag-pink/25',
};

const selectedColorClasses: Record<TagColor, string> = {
  red: 'bg-tag-red text-white',
  orange: 'bg-tag-orange text-white',
  yellow: 'bg-tag-yellow text-white',
  green: 'bg-tag-green text-white',
  teal: 'bg-tag-teal text-white',
  blue: 'bg-tag-blue text-white',
  purple: 'bg-tag-purple text-white',
  pink: 'bg-tag-pink text-white',
};

export function TagBadge({ tag, onClick, onRemove, selected, size = 'md' }: TagBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full font-body font-medium transition-colors cursor-pointer',
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm',
        selected ? selectedColorClasses[tag.color] : colorClasses[tag.color]
      )}
      onClick={onClick}
    >
      {tag.name}
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-0.5 hover:opacity-70"
        >
          <X className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
        </button>
      )}
    </span>
  );
}
