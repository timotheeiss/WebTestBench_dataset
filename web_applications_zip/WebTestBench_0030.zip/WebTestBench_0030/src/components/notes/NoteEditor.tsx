import { useCallback, useEffect, useState } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { useNotes } from '@/contexts/NotesContext';
import { TagBadge } from './TagBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  MoreVertical,
  Folder,
  Tags,
  Trash2,
  Check,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function NoteEditor() {
  const { state, dispatch, selectedNote } = useNotes();
  const [title, setTitle] = useState('');
  const [showTagMenu, setShowTagMenu] = useState(false);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
      }),
      Placeholder.configure({
        placeholder: 'Start writing...',
      }),
    ],
    content: '',
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose focus:outline-none max-w-none',
      },
    },
    onUpdate: ({ editor }) => {
      if (selectedNote) {
        dispatch({
          type: 'UPDATE_NOTE',
          payload: { id: selectedNote.id, updates: { content: editor.getHTML() } },
        });
      }
    },
  });

  // Sync editor with selected note
  useEffect(() => {
    if (selectedNote) {
      setTitle(selectedNote.title);
      if (editor && editor.getHTML() !== selectedNote.content) {
        editor.commands.setContent(selectedNote.content);
      }
    } else {
      setTitle('');
      editor?.commands.setContent('');
    }
  }, [selectedNote?.id, editor]);

  const handleTitleChange = useCallback(
    (newTitle: string) => {
      setTitle(newTitle);
      if (selectedNote) {
        dispatch({
          type: 'UPDATE_NOTE',
          payload: { id: selectedNote.id, updates: { title: newTitle } },
        });
      }
    },
    [selectedNote, dispatch]
  );

  const handleMoveToFolder = (folderId: string | null) => {
    if (selectedNote) {
      dispatch({
        type: 'MOVE_NOTE_TO_FOLDER',
        payload: { noteId: selectedNote.id, folderId },
      });
    }
  };

  const handleToggleTag = (tagId: string) => {
    if (!selectedNote) return;
    if (selectedNote.tagIds.includes(tagId)) {
      dispatch({
        type: 'REMOVE_TAG_FROM_NOTE',
        payload: { noteId: selectedNote.id, tagId },
      });
    } else {
      dispatch({
        type: 'ADD_TAG_TO_NOTE',
        payload: { noteId: selectedNote.id, tagId },
      });
    }
  };

  const handleDelete = () => {
    if (selectedNote) {
      dispatch({ type: 'DELETE_NOTE', payload: selectedNote.id });
    }
  };

  if (!selectedNote) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center text-muted-foreground">
          <p className="text-lg font-heading">Select a note to edit</p>
          <p className="text-sm mt-1">or create a new one</p>
        </div>
      </div>
    );
  }

  const noteTags = selectedNote.tagIds
    .map((id) => state.tags.find((t) => t.id === id))
    .filter(Boolean);

  const currentFolder = state.folders.find((f) => f.id === selectedNote.folderId);

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden animate-fade-in">
      {/* Toolbar */}
      <div className="border-b border-border px-4 py-2 flex items-center gap-2 bg-card/50">
        <div className="flex items-center gap-1 border-r border-border pr-2">
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleBold().run()}
            active={editor?.isActive('bold')}
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleItalic().run()}
            active={editor?.isActive('italic')}
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </ToolbarButton>
        </div>

        <div className="flex items-center gap-1 border-r border-border pr-2">
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()}
            active={editor?.isActive('heading', { level: 1 })}
            title="Heading 1"
          >
            <Heading1 className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}
            active={editor?.isActive('heading', { level: 2 })}
            title="Heading 2"
          >
            <Heading2 className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleHeading({ level: 3 }).run()}
            active={editor?.isActive('heading', { level: 3 })}
            title="Heading 3"
          >
            <Heading3 className="h-4 w-4" />
          </ToolbarButton>
        </div>

        <div className="flex items-center gap-1 border-r border-border pr-2">
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleBulletList().run()}
            active={editor?.isActive('bulletList')}
            title="Bullet List"
          >
            <List className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleOrderedList().run()}
            active={editor?.isActive('orderedList')}
            title="Numbered List"
          >
            <ListOrdered className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            onClick={() => editor?.chain().focus().toggleBlockquote().run()}
            active={editor?.isActive('blockquote')}
            title="Quote"
          >
            <Quote className="h-4 w-4" />
          </ToolbarButton>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {/* Folder Selector */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2 h-8">
                <Folder className="h-4 w-4" />
                <span className="text-sm">{currentFolder?.name || 'No Folder'}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => handleMoveToFolder(null)}>
                {!selectedNote.folderId && <Check className="h-4 w-4 mr-2" />}
                <span className={!selectedNote.folderId ? '' : 'ml-6'}>No Folder</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {state.folders.map((folder) => (
                <DropdownMenuItem
                  key={folder.id}
                  onClick={() => handleMoveToFolder(folder.id)}
                >
                  {selectedNote.folderId === folder.id && <Check className="h-4 w-4 mr-2" />}
                  <span className={selectedNote.folderId === folder.id ? '' : 'ml-6'}>
                    {folder.name}
                  </span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Tags Selector */}
          <DropdownMenu open={showTagMenu} onOpenChange={setShowTagMenu}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2 h-8">
                <Tags className="h-4 w-4" />
                <span className="text-sm">Tags</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {state.tags.map((tag) => (
                <DropdownMenuItem
                  key={tag.id}
                  onClick={() => handleToggleTag(tag.id)}
                >
                  {selectedNote.tagIds.includes(tag.id) && <Check className="h-4 w-4 mr-2" />}
                  <span className={selectedNote.tagIds.includes(tag.id) ? '' : 'ml-6'}>
                    <TagBadge tag={tag} size="sm" />
                  </span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* More Actions */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleDelete} className="text-destructive focus:text-destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Note
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto p-8">
          {/* Title */}
          <Input
            value={title}
            onChange={(e) => handleTitleChange(e.target.value)}
            placeholder="Note title..."
            className="border-none text-3xl font-heading font-semibold h-auto py-2 px-0 focus-visible:ring-0 bg-transparent placeholder:text-muted-foreground/50"
          />

          {/* Tags */}
          {noteTags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3 mb-4">
              {noteTags.map(
                (tag) =>
                  tag && (
                    <TagBadge
                      key={tag.id}
                      tag={tag}
                      onRemove={() => handleToggleTag(tag.id)}
                    />
                  )
              )}
            </div>
          )}

          {/* Meta */}
          <p className="text-xs text-muted-foreground mb-6">
            Last edited {formatDistanceToNow(new Date(selectedNote.updatedAt), { addSuffix: true })}
          </p>

          {/* Content */}
          <EditorContent editor={editor} className="min-h-[300px]" />
        </div>
      </div>
    </div>
  );
}

function ToolbarButton({
  children,
  onClick,
  active,
  title,
}: {
  children: React.ReactNode;
  onClick: () => void;
  active?: boolean;
  title: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={cn(
        'p-2 rounded-md transition-colors',
        active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
      )}
    >
      {children}
    </button>
  );
}
