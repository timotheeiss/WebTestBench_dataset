import { useState } from 'react';
import { useNotes } from '@/contexts/NotesContext';
import { TagBadge } from './TagBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  FileText,
  Folder,
  FolderPlus,
  Hash,
  MoreHorizontal,
  Pencil,
  Plus,
  Trash2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TagColor } from '@/types/notes';

const tagColors: TagColor[] = ['red', 'orange', 'yellow', 'green', 'teal', 'blue', 'purple', 'pink'];

export function Sidebar() {
  const { state, dispatch } = useNotes();
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [editingFolderName, setEditingFolderName] = useState('');
  const [showNewTag, setShowNewTag] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState<TagColor>('blue');

  const handleCreateFolder = () => {
    if (newFolderName.trim()) {
      dispatch({ type: 'CREATE_FOLDER', payload: newFolderName.trim() });
      setNewFolderName('');
      setShowNewFolder(false);
    }
  };

  const handleRenameFolder = () => {
    if (editingFolderId && editingFolderName.trim()) {
      dispatch({ type: 'RENAME_FOLDER', payload: { id: editingFolderId, name: editingFolderName.trim() } });
      setEditingFolderId(null);
      setEditingFolderName('');
    }
  };

  const handleCreateTag = () => {
    if (newTagName.trim()) {
      dispatch({ type: 'CREATE_TAG', payload: { name: newTagName.trim(), color: newTagColor } });
      setNewTagName('');
      setNewTagColor('blue');
      setShowNewTag(false);
    }
  };

  const notesCount = (folderId: string | null) =>
    state.notes.filter((n) => n.folderId === folderId).length;

  const tagNotesCount = (tagId: string) =>
    state.notes.filter((n) => n.tagIds.includes(tagId)).length;

  return (
    <aside className="w-64 h-full bg-sidebar border-r border-sidebar-border flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <h1 className="text-xl font-heading font-semibold text-sidebar-foreground">Notes</h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-6">
        {/* All Notes */}
        <div>
          <button
            onClick={() => {
              dispatch({ type: 'SELECT_FOLDER', payload: null });
              dispatch({ type: 'SELECT_TAG', payload: null });
            }}
            className={cn(
              'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
              state.selectedFolderId === null && state.selectedTagId === null
                ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
            )}
          >
            <FileText className="h-4 w-4" />
            <span>All Notes</span>
            <span className="ml-auto text-xs text-muted-foreground">{state.notes.length}</span>
          </button>
        </div>

        {/* Folders */}
        <div>
          <div className="flex items-center justify-between px-3 mb-2">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Folders</h2>
            <button
              onClick={() => setShowNewFolder(true)}
              className="p-1 hover:bg-sidebar-accent rounded transition-colors"
            >
              <FolderPlus className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          </div>

          {showNewFolder && (
            <div className="px-2 mb-2 animate-fade-in">
              <Input
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Folder name..."
                className="h-8 text-sm"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreateFolder();
                  if (e.key === 'Escape') setShowNewFolder(false);
                }}
                onBlur={() => {
                  if (!newFolderName.trim()) setShowNewFolder(false);
                }}
              />
            </div>
          )}

          <div className="space-y-0.5">
            {state.folders.map((folder) => (
              <div key={folder.id} className="group relative">
                {editingFolderId === folder.id ? (
                  <Input
                    value={editingFolderName}
                    onChange={(e) => setEditingFolderName(e.target.value)}
                    className="h-8 text-sm mx-2"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleRenameFolder();
                      if (e.key === 'Escape') setEditingFolderId(null);
                    }}
                    onBlur={handleRenameFolder}
                  />
                ) : (
                  <button
                    onClick={() => dispatch({ type: 'SELECT_FOLDER', payload: folder.id })}
                    className={cn(
                      'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors',
                      state.selectedFolderId === folder.id
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                        : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                    )}
                  >
                    <Folder className="h-4 w-4" />
                    <span className="truncate">{folder.name}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {notesCount(folder.id)}
                    </span>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <button className="p-1 opacity-0 group-hover:opacity-100 hover:bg-sidebar-accent rounded transition-all">
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-36">
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingFolderId(folder.id);
                            setEditingFolderName(folder.name);
                          }}
                        >
                          <Pencil className="h-4 w-4 mr-2" />
                          Rename
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            dispatch({ type: 'DELETE_FOLDER', payload: folder.id });
                          }}
                          className="text-destructive focus:text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Tags */}
        <div>
          <div className="flex items-center justify-between px-3 mb-2">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Tags</h2>
            <button
              onClick={() => setShowNewTag(true)}
              className="p-1 hover:bg-sidebar-accent rounded transition-colors"
            >
              <Plus className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          </div>

          <div className="space-y-1 px-2">
            {state.tags.map((tag) => (
              <div key={tag.id} className="group flex items-center gap-1">
                <button
                  onClick={() => dispatch({ type: 'SELECT_TAG', payload: tag.id })}
                  className="flex-1 flex items-center"
                >
                  <TagBadge
                    tag={tag}
                    selected={state.selectedTagId === tag.id}
                    size="sm"
                  />
                </button>
                <span className="text-xs text-muted-foreground mr-1">{tagNotesCount(tag.id)}</span>
                <button
                  onClick={() => dispatch({ type: 'DELETE_TAG', payload: tag.id })}
                  className="p-1 opacity-0 group-hover:opacity-100 hover:bg-sidebar-accent rounded transition-all"
                >
                  <Trash2 className="h-3 w-3 text-muted-foreground hover:text-destructive" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </nav>

      {/* New Tag Dialog */}
      <Dialog open={showNewTag} onOpenChange={setShowNewTag}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Tag</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input
              value={newTagName}
              onChange={(e) => setNewTagName(e.target.value)}
              placeholder="Tag name..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCreateTag();
              }}
            />
            <div>
              <label className="text-sm font-medium mb-2 block">Color</label>
              <div className="flex gap-2 flex-wrap">
                {tagColors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setNewTagColor(color)}
                    className={cn(
                      'w-8 h-8 rounded-full transition-transform',
                      newTagColor === color && 'ring-2 ring-offset-2 ring-foreground scale-110'
                    )}
                    style={{ backgroundColor: `hsl(var(--tag-${color}))` }}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewTag(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateTag}>Create Tag</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </aside>
  );
}
