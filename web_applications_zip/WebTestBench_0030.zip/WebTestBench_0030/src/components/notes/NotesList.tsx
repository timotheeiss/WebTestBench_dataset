import { useNotes } from '@/contexts/NotesContext';
import { TagBadge } from './TagBadge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function NotesList() {
  const { state, dispatch, filteredNotes } = useNotes();

  const getPreviewText = (html: string) => {
    const div = document.createElement('div');
    div.innerHTML = html;
    const text = div.textContent || div.innerText || '';
    return text.slice(0, 100) + (text.length > 100 ? '...' : '');
  };

  const getTitle = () => {
    if (state.searchQuery) return `Search: "${state.searchQuery}"`;
    if (state.selectedTagId) {
      const tag = state.tags.find((t) => t.id === state.selectedTagId);
      return tag ? `#${tag.name}` : 'All Notes';
    }
    if (state.selectedFolderId) {
      const folder = state.folders.find((f) => f.id === state.selectedFolderId);
      return folder?.name || 'All Notes';
    }
    return 'All Notes';
  };

  return (
    <div className="w-80 h-full bg-card border-r border-border flex flex-col overflow-hidden">
      {/* Search */}
      <div className="p-3 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={state.searchQuery}
            onChange={(e) => dispatch({ type: 'SET_SEARCH_QUERY', payload: e.target.value })}
            placeholder="Search notes..."
            className="pl-9 h-9"
          />
        </div>
      </div>

      {/* Header */}
      <div className="p-3 flex items-center justify-between border-b border-border">
        <h2 className="font-heading font-medium text-lg truncate">{getTitle()}</h2>
        <Button
          size="sm"
          onClick={() => dispatch({ type: 'CREATE_NOTE', payload: {} })}
          className="h-8 gap-1"
        >
          <Plus className="h-4 w-4" />
          New
        </Button>
      </div>

      {/* Notes List */}
      <div className="flex-1 overflow-y-auto">
        {filteredNotes.length === 0 ? (
          <div className="p-6 text-center text-muted-foreground">
            <p className="text-sm">No notes found</p>
            <Button
              variant="link"
              onClick={() => dispatch({ type: 'CREATE_NOTE', payload: {} })}
              className="mt-2"
            >
              Create your first note
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredNotes.map((note) => {
              const noteTags = note.tagIds
                .map((id) => state.tags.find((t) => t.id === id))
                .filter(Boolean);

              return (
                <button
                  key={note.id}
                  onClick={() => dispatch({ type: 'SELECT_NOTE', payload: note.id })}
                  className={cn(
                    'w-full text-left p-4 transition-colors animate-fade-in',
                    state.selectedNoteId === note.id
                      ? 'bg-primary/5 border-l-2 border-l-primary'
                      : 'hover:bg-muted/50 border-l-2 border-l-transparent'
                  )}
                >
                  <h3 className="font-medium text-sm truncate mb-1">{note.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                    {getPreviewText(note.content) || 'Empty note'}
                  </p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {noteTags.slice(0, 3).map(
                      (tag) =>
                        tag && <TagBadge key={tag.id} tag={tag} size="sm" />
                    )}
                    {noteTags.length > 3 && (
                      <span className="text-xs text-muted-foreground">+{noteTags.length - 3}</span>
                    )}
                    <span className="text-xs text-muted-foreground ml-auto">
                      {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
