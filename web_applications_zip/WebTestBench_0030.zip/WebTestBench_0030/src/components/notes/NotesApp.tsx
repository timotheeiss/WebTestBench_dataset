import { NotesProvider } from '@/contexts/NotesContext';
import { Sidebar } from './Sidebar';
import { NotesList } from './NotesList';
import { NoteEditor } from './NoteEditor';

export function NotesApp() {
  return (
    <NotesProvider>
      <div className="h-screen w-screen flex overflow-hidden">
        <Sidebar />
        <NotesList />
        <NoteEditor />
      </div>
    </NotesProvider>
  );
}
