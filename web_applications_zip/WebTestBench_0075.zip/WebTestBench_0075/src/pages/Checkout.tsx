import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import CheckoutForm from '@/components/CheckoutForm';
import { Button } from '@/components/ui/button';

const Checkout = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-theater">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/cart')}
          className="mb-6 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Cart
        </Button>

        <h1 className="font-display text-3xl font-bold text-foreground mb-8">
          Checkout
        </h1>

        <CheckoutForm />
      </div>
    </div>
  );
};

export default Checkout;
