import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Receipt } from 'lucide-react';
import { useOrders } from '@/contexts/OrderContext';
import OrderCard from '@/components/OrderCard';
import { Button } from '@/components/ui/button';

const Orders = () => {
  const navigate = useNavigate();
  const { orders } = useOrders();

  return (
    <div className="min-h-screen bg-gradient-theater">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shows
        </Button>

        <div className="mb-8 flex items-center gap-3">
          <Receipt className="h-8 w-8 text-primary" />
          <h1 className="font-display text-3xl font-bold text-foreground">
            My Orders
          </h1>
        </div>

        {orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Receipt className="mb-4 h-16 w-16 text-muted-foreground/50" />
            <h2 className="font-display text-2xl font-semibold text-foreground">
              No orders yet
            </h2>
            <p className="mt-2 text-muted-foreground">
              Your order history will appear here after you make a purchase.
            </p>
            <Button
              onClick={() => navigate('/')}
              className="mt-6 bg-primary text-primary-foreground"
            >
              Browse Shows
            </Button>
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-2">
            {orders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;
