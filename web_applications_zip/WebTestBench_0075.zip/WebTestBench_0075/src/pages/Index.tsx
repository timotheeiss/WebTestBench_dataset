import { Sparkles, Theater } from 'lucide-react';
import { plays } from '@/data/plays';
import PlayCard from '@/components/PlayCard';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-theater">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-burgundy/20 via-transparent to-transparent" />
        <div className="container relative mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-sm text-primary">
              <Sparkles className="h-4 w-4" />
              Now showing the finest productions
            </div>
            <h1 className="font-display text-4xl font-bold leading-tight md:text-6xl lg:text-7xl">
              <span className="text-gradient-gold">Experience</span>
              <br />
              <span className="text-foreground">The Magic of</span>
              <br />
              <span className="text-gradient-gold">Live Theater</span>
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
              Book your seats for the most captivating performances. From timeless classics 
              to groundbreaking new productions.
            </p>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -left-20 top-1/2 h-40 w-40 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -right-20 top-1/3 h-60 w-60 rounded-full bg-burgundy/10 blur-3xl" />
      </section>

      {/* Shows Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="mb-12 flex items-center gap-3">
            <Theater className="h-8 w-8 text-primary" />
            <h2 className="font-display text-3xl font-semibold text-foreground">
              Now Showing
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {plays.map((play, index) => (
              <PlayCard key={play.id} play={play} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 Curtain Call Theater. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
