import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Trash2, ShoppingBag } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Cart = () => {
  const navigate = useNavigate();
  const { items, removeItem, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-theater">
        <div className="container mx-auto px-4 py-16">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-6 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Shows
          </Button>

          <div className="flex flex-col items-center justify-center py-20 text-center">
            <ShoppingBag className="mb-4 h-16 w-16 text-muted-foreground/50" />
            <h2 className="font-display text-2xl font-semibold text-foreground">
              Your cart is empty
            </h2>
            <p className="mt-2 text-muted-foreground">
              Browse our shows and add some tickets to get started.
            </p>
            <Button
              onClick={() => navigate('/')}
              className="mt-6 bg-primary text-primary-foreground"
            >
              Browse Shows
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Group items by play and showtime
  const groupedItems = items.reduce((acc, item) => {
    const key = `${item.playId}-${item.showtimeId}`;
    if (!acc[key]) {
      acc[key] = {
        playTitle: item.playTitle,
        showtime: item.showtime,
        items: [],
      };
    }
    acc[key].items.push(item);
    return acc;
  }, {} as Record<string, { playTitle: string; showtime: string; items: typeof items }>);

  return (
    <div className="min-h-screen bg-gradient-theater">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shows
        </Button>

        <h1 className="font-display text-3xl font-bold text-foreground mb-8">
          Your Cart
        </h1>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Cart Items */}
          <div className="space-y-4 lg:col-span-2">
            {Object.entries(groupedItems).map(([key, group]) => (
              <Card key={key} className="border-border/30 bg-card animate-fade-in">
                <CardHeader>
                  <CardTitle className="font-display text-lg">{group.playTitle}</CardTitle>
                  <p className="text-sm text-muted-foreground">{group.showtime}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  {group.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between rounded-lg border border-border/30 bg-background/50 p-3"
                    >
                      <div>
                        <p className="font-medium">
                          Seat {item.seat.row}{item.seat.number}
                        </p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {item.seat.category}
                        </p>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-primary">
                          ${item.seat.price}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="h-8 w-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24 border-border/30 bg-card">
              <CardHeader>
                <CardTitle className="font-display text-xl">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Tickets ({items.length})</span>
                    <span>${total}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Service Fee</span>
                    <span>$0</span>
                  </div>
                </div>
                <div className="border-t border-border/30 pt-4">
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total</span>
                    <span className="text-primary">${total}</span>
                  </div>
                </div>
                <Button
                  onClick={() => navigate('/checkout')}
                  size="lg"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  Proceed to Checkout
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
