import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, Star, MapPin, Calendar, Plus } from 'lucide-react';
import { plays } from '@/data/plays';
import { Seat, Showtime } from '@/types';
import { useCart } from '@/contexts/CartContext';
import SeatingChart from '@/components/SeatingChart';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const PlayDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addItem, items } = useCart();
  const { toast } = useToast();

  const play = plays.find(p => p.id === id);
  const [selectedShowtime, setSelectedShowtime] = useState<Showtime | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);

  if (!play) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-muted-foreground">Show not found</p>
        <Button onClick={() => navigate('/')} className="mt-4">
          Back to Shows
        </Button>
      </div>
    );
  }

  const formatShowtime = (showtime: Showtime): string => {
    const date = new Date(showtime.date + 'T' + showtime.time);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    }) + ' at ' + date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  const handleSeatSelect = (seat: Seat) => {
    // Check if seat already in cart for this showtime
    const isInCart = items.some(
      item => item.showtimeId === selectedShowtime?.id && item.seat.id === seat.id
    );
    if (isInCart) {
      toast({
        title: 'Seat already in cart',
        description: 'This seat is already in your cart.',
        variant: 'destructive',
      });
      return;
    }
    setSelectedSeats(prev => [...prev, seat]);
  };

  const handleSeatDeselect = (seatId: string) => {
    setSelectedSeats(prev => prev.filter(s => s.id !== seatId));
  };

  const handleAddToCart = () => {
    if (!selectedShowtime) return;

    selectedSeats.forEach(seat => {
      addItem({
        id: `${selectedShowtime.id}-${seat.id}`,
        playId: play.id,
        playTitle: play.title,
        showtimeId: selectedShowtime.id,
        showtime: formatShowtime(selectedShowtime),
        seat,
      });
    });

    toast({
      title: 'Added to cart!',
      description: `${selectedSeats.length} ticket(s) added to your cart.`,
    });

    setSelectedSeats([]);
  };

  const totalPrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);

  return (
    <div className="min-h-screen bg-gradient-theater">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shows
        </Button>

        {/* Play Header */}
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-1">
            <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
              <img
                src={play.image}
                alt={play.title}
                className="h-full w-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = `https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=400&h=600&fit=crop`;
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            </div>
          </div>

          <div className="space-y-6 lg:col-span-2">
            <div>
              <Badge className="mb-3 bg-secondary text-secondary-foreground">
                {play.genre}
              </Badge>
              <h1 className="font-display text-4xl font-bold text-foreground lg:text-5xl">
                {play.title}
              </h1>
              <div className="mt-4 flex flex-wrap items-center gap-4 text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="h-5 w-5" />
                  {play.duration}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="h-5 w-5 fill-primary text-primary" />
                  {play.rating}
                </span>
              </div>
              <p className="mt-4 text-lg text-muted-foreground">
                {play.description}
              </p>
            </div>

            {/* Showtimes */}
            <div>
              <h3 className="mb-4 font-display text-xl font-semibold text-foreground">
                Select a Showtime
              </h3>
              <div className="flex flex-wrap gap-3">
                {play.showtimes.map((showtime) => (
                  <Button
                    key={showtime.id}
                    variant={selectedShowtime?.id === showtime.id ? 'default' : 'outline'}
                    onClick={() => {
                      setSelectedShowtime(showtime);
                      setSelectedSeats([]);
                    }}
                    className={
                      selectedShowtime?.id === showtime.id
                        ? 'bg-primary text-primary-foreground'
                        : 'border-border hover:border-primary hover:text-primary'
                    }
                  >
                    <div className="text-left">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatShowtime(showtime)}
                      </div>
                      <div className="flex items-center gap-1 text-xs opacity-70">
                        <MapPin className="h-3 w-3" />
                        {showtime.venue}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Seating Section */}
        {selectedShowtime && (
          <div className="mt-12 animate-fade-in">
            <Card className="border-border/30 bg-card">
              <CardContent className="p-6 lg:p-8">
                <div className="mb-6 flex items-center justify-between">
                  <h3 className="font-display text-xl font-semibold text-foreground">
                    Select Your Seats
                  </h3>
                  <div className="text-sm text-muted-foreground">
                    {formatShowtime(selectedShowtime)} • {selectedShowtime.venue}
                  </div>
                </div>

                <SeatingChart
                  showtimeId={selectedShowtime.id}
                  selectedSeats={selectedSeats}
                  onSeatSelect={handleSeatSelect}
                  onSeatDeselect={handleSeatDeselect}
                />

                {/* Selected Seats Summary */}
                {selectedSeats.length > 0 && (
                  <div className="mt-8 flex flex-col items-center justify-between gap-4 rounded-lg border border-primary/30 bg-primary/5 p-4 sm:flex-row">
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Selected: {selectedSeats.map(s => `${s.row}${s.number}`).join(', ')}
                      </p>
                      <p className="text-lg font-semibold text-foreground">
                        Total: <span className="text-primary">${totalPrice}</span>
                      </p>
                    </div>
                    <Button
                      onClick={handleAddToCart}
                      size="lg"
                      className="bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      <Plus className="mr-2 h-5 w-5" />
                      Add {selectedSeats.length} to Cart
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlayDetail;
