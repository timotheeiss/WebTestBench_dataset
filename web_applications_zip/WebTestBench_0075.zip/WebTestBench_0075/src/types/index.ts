export interface Play {
  id: string;
  title: string;
  description: string;
  image: string;
  duration: string;
  genre: string;
  rating: string;
  showtimes: Showtime[];
}

export interface Showtime {
  id: string;
  date: string;
  time: string;
  venue: string;
}

export interface Seat {
  id: string;
  row: string;
  number: number;
  price: number;
  status: 'available' | 'taken' | 'selected';
  category: 'orchestra' | 'mezzanine' | 'balcony';
}

export interface CartItem {
  id: string;
  playId: string;
  playTitle: string;
  showtimeId: string;
  showtime: string;
  seat: Seat;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  customerInfo: CustomerInfo;
  purchaseDate: string;
  status: 'confirmed' | 'refunded' | 'pending-refund';
}

export interface CustomerInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
}
