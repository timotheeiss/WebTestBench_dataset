import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Order, CartItem, CustomerInfo } from '@/types';

interface OrderContextType {
  orders: Order[];
  addOrder: (items: CartItem[], customerInfo: CustomerInfo, total: number) => Order;
  requestRefund: (orderId: string) => void;
  getEligibleForRefund: (order: Order) => boolean;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

// Sample existing orders for demo
const initialOrders: Order[] = [
  {
    id: 'ORD-001',
    items: [
      {
        id: 'item-1',
        playId: 'phantom',
        playTitle: 'The Phantom of the Opera',
        showtimeId: 'ph-1',
        showtime: 'Jan 2, 2025 at 7:30 PM',
        seat: { id: 'C7', row: 'C', number: 7, price: 150, status: 'taken', category: 'orchestra' }
      },
      {
        id: 'item-2',
        playId: 'phantom',
        playTitle: 'The Phantom of the Opera',
        showtimeId: 'ph-1',
        showtime: 'Jan 2, 2025 at 7:30 PM',
        seat: { id: 'C8', row: 'C', number: 8, price: 150, status: 'taken', category: 'orchestra' }
      }
    ],
    total: 300,
    customerInfo: {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@email.com',
      phone: '555-0123'
    },
    purchaseDate: '2024-12-20T10:30:00',
    status: 'confirmed'
  }
];

export const OrderProvider = ({ children }: { children: ReactNode }) => {
  const [orders, setOrders] = useState<Order[]>(initialOrders);

  const addOrder = (items: CartItem[], customerInfo: CustomerInfo, total: number): Order => {
    const newOrder: Order = {
      id: `ORD-${String(orders.length + 1).padStart(3, '0')}`,
      items,
      total,
      customerInfo,
      purchaseDate: new Date().toISOString(),
      status: 'confirmed'
    };
    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  };

  const requestRefund = (orderId: string) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: 'pending-refund' as const }
        : order
    ));
  };

  const getEligibleForRefund = (order: Order): boolean => {
    if (order.status !== 'confirmed') return false;
    // Orders are eligible for refund if show is at least 24 hours away
    const showDate = new Date(order.items[0]?.showtime || '');
    const now = new Date();
    const hoursUntilShow = (showDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilShow > 24;
  };

  return (
    <OrderContext.Provider value={{ orders, addOrder, requestRefund, getEligibleForRefund }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
};
