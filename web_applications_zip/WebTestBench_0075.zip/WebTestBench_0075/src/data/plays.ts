import { Play } from '@/types';

export const plays: Play[] = [
  {
    id: 'phantom',
    title: 'The Phantom of the Opera',
    description: 'Andrew Lloyd Webber\'s legendary musical about a mysterious masked figure who haunts the Paris Opera House. A tale of obsession, love, and music that has captivated audiences worldwide for decades.',
    image: '/plays/phantom.jpg',
    duration: '2h 30m',
    genre: 'Musical Drama',
    rating: '4.9',
    showtimes: [
      { id: 'ph-1', date: '2025-01-02', time: '19:30', venue: 'Grand Theater' },
      { id: 'ph-2', date: '2025-01-03', time: '14:00', venue: 'Grand Theater' },
      { id: 'ph-3', date: '2025-01-03', time: '19:30', venue: 'Grand Theater' },
      { id: 'ph-4', date: '2025-01-04', time: '19:30', venue: 'Grand Theater' },
    ]
  },
  {
    id: 'hamilton',
    title: 'Hamilton',
    description: 'The revolutionary musical telling the story of American Founding Father Alexander Hamilton. With its blend of hip-hop, jazz, and Broadway, this groundbreaking show redefined what musical theater could be.',
    image: '/plays/hamilton.jpg',
    duration: '2h 45m',
    genre: 'Musical Biography',
    rating: '4.8',
    showtimes: [
      { id: 'hm-1', date: '2025-01-02', time: '20:00', venue: 'Royal Stage' },
      { id: 'hm-2', date: '2025-01-05', time: '14:00', venue: 'Royal Stage' },
      { id: 'hm-3', date: '2025-01-05', time: '20:00', venue: 'Royal Stage' },
    ]
  },
  {
    id: 'les-mis',
    title: 'Les Misérables',
    description: 'The timeless tale of broken dreams, passion, sacrifice, and redemption. Set against the backdrop of 19th-century France, this epic musical follows the journey of Jean Valjean.',
    image: '/plays/les-mis.jpg',
    duration: '3h 00m',
    genre: 'Musical Drama',
    rating: '4.9',
    showtimes: [
      { id: 'lm-1', date: '2025-01-03', time: '19:00', venue: 'Empire Hall' },
      { id: 'lm-2', date: '2025-01-06', time: '14:00', venue: 'Empire Hall' },
      { id: 'lm-3', date: '2025-01-06', time: '19:00', venue: 'Empire Hall' },
    ]
  },
  {
    id: 'wicked',
    title: 'Wicked',
    description: 'Long before Dorothy arrives, two young women meet in the land of Oz. One, born with emerald-green skin, is smart and fiery. The other is beautiful, ambitious, and very popular.',
    image: '/plays/wicked.jpg',
    duration: '2h 45m',
    genre: 'Musical Fantasy',
    rating: '4.7',
    showtimes: [
      { id: 'wk-1', date: '2025-01-04', time: '19:30', venue: 'Grand Theater' },
      { id: 'wk-2', date: '2025-01-07', time: '14:00', venue: 'Grand Theater' },
      { id: 'wk-3', date: '2025-01-07', time: '19:30', venue: 'Grand Theater' },
    ]
  },
  {
    id: 'chicago',
    title: 'Chicago',
    description: 'Set in the legendary city during the roaring twenties, Chicago tells the story of Roxie Hart, a housewife who murders her lover and convinces her hapless husband to take the rap.',
    image: '/plays/chicago.jpg',
    duration: '2h 15m',
    genre: 'Musical Comedy',
    rating: '4.6',
    showtimes: [
      { id: 'ch-1', date: '2025-01-05', time: '20:00', venue: 'Royal Stage' },
      { id: 'ch-2', date: '2025-01-08', time: '19:30', venue: 'Royal Stage' },
    ]
  },
  {
    id: 'macbeth',
    title: 'Macbeth',
    description: 'Shakespeare\'s darkest tragedy about ambition, power, and guilt. A Scottish general receives a prophecy from witches that he will become king, leading him down a bloody path.',
    image: '/plays/macbeth.jpg',
    duration: '2h 30m',
    genre: 'Tragedy',
    rating: '4.5',
    showtimes: [
      { id: 'mb-1', date: '2025-01-06', time: '19:00', venue: 'Empire Hall' },
      { id: 'mb-2', date: '2025-01-09', time: '19:00', venue: 'Empire Hall' },
    ]
  }
];
