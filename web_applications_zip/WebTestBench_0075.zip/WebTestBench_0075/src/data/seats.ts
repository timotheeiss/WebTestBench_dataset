import { Seat } from '@/types';

const generateSeats = (): Seat[] => {
  const seats: Seat[] = [];
  
  // Orchestra section (rows A-G, seats 1-14)
  const orchestraRows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  orchestraRows.forEach(row => {
    for (let num = 1; num <= 14; num++) {
      seats.push({
        id: `${row}${num}`,
        row,
        number: num,
        price: 150,
        status: Math.random() > 0.7 ? 'taken' : 'available',
        category: 'orchestra'
      });
    }
  });
  
  // Mezzanine section (rows H-K, seats 1-16)
  const mezzanineRows = ['H', 'I', 'J', 'K'];
  mezzanineRows.forEach(row => {
    for (let num = 1; num <= 16; num++) {
      seats.push({
        id: `${row}${num}`,
        row,
        number: num,
        price: 100,
        status: Math.random() > 0.6 ? 'taken' : 'available',
        category: 'mezzanine'
      });
    }
  });
  
  // Balcony section (rows L-N, seats 1-18)
  const balconyRows = ['L', 'M', 'N'];
  balconyRows.forEach(row => {
    for (let num = 1; num <= 18; num++) {
      seats.push({
        id: `${row}${num}`,
        row,
        number: num,
        price: 65,
        status: Math.random() > 0.5 ? 'taken' : 'available',
        category: 'balcony'
      });
    }
  });
  
  return seats;
};

// Cache seats per showtime
const seatCache: Record<string, Seat[]> = {};

export const getSeatsForShowtime = (showtimeId: string): Seat[] => {
  if (!seatCache[showtimeId]) {
    seatCache[showtimeId] = generateSeats();
  }
  return seatCache[showtimeId].map(seat => ({ ...seat }));
};

export const updateSeatStatus = (showtimeId: string, seatId: string, status: Seat['status']) => {
  if (seatCache[showtimeId]) {
    const seat = seatCache[showtimeId].find(s => s.id === seatId);
    if (seat) {
      seat.status = status;
    }
  }
};
