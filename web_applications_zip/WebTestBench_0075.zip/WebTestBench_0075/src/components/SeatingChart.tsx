import { useState, useEffect } from 'react';
import { Seat } from '@/types';
import { getSeatsForShowtime } from '@/data/seats';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface SeatingChartProps {
  showtimeId: string;
  selectedSeats: Seat[];
  onSeatSelect: (seat: Seat) => void;
  onSeatDeselect: (seatId: string) => void;
}

const SeatingChart = ({
  showtimeId,
  selectedSeats,
  onSeatSelect,
  onSeatDeselect,
}: SeatingChartProps) => {
  const [seats, setSeats] = useState<Seat[]>([]);

  useEffect(() => {
    const loadedSeats = getSeatsForShowtime(showtimeId);
    setSeats(loadedSeats);
  }, [showtimeId]);

  const groupedSeats = seats.reduce((acc, seat) => {
    if (!acc[seat.row]) acc[seat.row] = [];
    acc[seat.row].push(seat);
    return acc;
  }, {} as Record<string, Seat[]>);

  const isSelected = (seatId: string) => 
    selectedSeats.some(s => s.id === seatId);

  const handleSeatClick = (seat: Seat) => {
    if (seat.status === 'taken') return;
    
    if (isSelected(seat.id)) {
      onSeatDeselect(seat.id);
    } else {
      onSeatSelect(seat);
    }
  };

  const getCategoryLabel = (row: string): string | null => {
    if (row === 'A') return 'Orchestra';
    if (row === 'H') return 'Mezzanine';
    if (row === 'L') return 'Balcony';
    return null;
  };

  const getCategoryColor = (category: Seat['category']) => {
    switch (category) {
      case 'orchestra': return 'bg-seat-orchestra';
      case 'mezzanine': return 'bg-seat-mezzanine';
      case 'balcony': return 'bg-seat-balcony';
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Stage */}
      <div className="relative mx-auto w-3/4">
        <div className="h-8 rounded-t-full bg-gradient-to-b from-primary/40 to-primary/10 flex items-center justify-center">
          <span className="text-xs font-medium text-primary uppercase tracking-widest">Stage</span>
        </div>
        <div className="h-1 bg-primary/60 shadow-gold" />
      </div>

      {/* Seating Grid */}
      <div className="overflow-x-auto pb-4">
        <div className="min-w-[600px] space-y-1">
          {Object.entries(groupedSeats).map(([row, rowSeats]) => (
            <div key={row}>
              {getCategoryLabel(row) && (
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 mt-4">
                  {getCategoryLabel(row)} — ${rowSeats[0]?.price}
                </div>
              )}
              <div className="flex items-center gap-1 justify-center">
                <span className="w-6 text-center text-xs font-medium text-muted-foreground">
                  {row}
                </span>
                <div className="flex gap-1">
                  {rowSeats.sort((a, b) => a.number - b.number).map((seat) => (
                    <Tooltip key={seat.id}>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => handleSeatClick(seat)}
                          disabled={seat.status === 'taken'}
                          className={cn(
                            'h-6 w-6 rounded-t-md text-[10px] font-medium transition-all duration-200',
                            seat.status === 'taken' && 'bg-seat-taken cursor-not-allowed opacity-50',
                            seat.status === 'available' && !isSelected(seat.id) && cn(
                              getCategoryColor(seat.category),
                              'hover:scale-110 hover:brightness-110 cursor-pointer'
                            ),
                            isSelected(seat.id) && 'bg-seat-selected text-primary-foreground scale-110 animate-pulse-gold'
                          )}
                        >
                          {seat.number}
                        </button>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="bg-popover text-popover-foreground">
                        <p className="font-medium">Seat {seat.row}{seat.number}</p>
                        <p className="text-sm text-muted-foreground">
                          {seat.status === 'taken' ? 'Unavailable' : `$${seat.price}`}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
                <span className="w-6 text-center text-xs font-medium text-muted-foreground">
                  {row}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap justify-center gap-6 text-sm">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-t-sm bg-seat-orchestra" />
          <span className="text-muted-foreground">Orchestra ($150)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-t-sm bg-seat-mezzanine" />
          <span className="text-muted-foreground">Mezzanine ($100)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-t-sm bg-seat-balcony" />
          <span className="text-muted-foreground">Balcony ($65)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-t-sm bg-seat-taken opacity-50" />
          <span className="text-muted-foreground">Taken</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-t-sm bg-seat-selected" />
          <span className="text-muted-foreground">Selected</span>
        </div>
      </div>
    </div>
  );
};

export default SeatingChart;
