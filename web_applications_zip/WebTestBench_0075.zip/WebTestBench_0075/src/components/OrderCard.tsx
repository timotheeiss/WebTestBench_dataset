import { useState } from 'react';
import { Calendar, MapPin, Armchair, RefreshCw, CheckCircle, Clock } from 'lucide-react';
import { Order } from '@/types';
import { useOrders } from '@/contexts/OrderContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface OrderCardProps {
  order: Order;
}

const OrderCard = ({ order }: OrderCardProps) => {
  const { requestRefund, getEligibleForRefund } = useOrders();
  const { toast } = useToast();
  const [showRefundDialog, setShowRefundDialog] = useState(false);

  const isEligible = getEligibleForRefund(order);

  const handleRefundRequest = () => {
    requestRefund(order.id);
    setShowRefundDialog(false);
    toast({
      title: 'Refund Requested',
      description: 'Your refund request has been submitted and is being processed.',
    });
  };

  const getStatusBadge = () => {
    switch (order.status) {
      case 'confirmed':
        return (
          <Badge className="bg-seat-available/20 text-seat-available border-seat-available/30">
            <CheckCircle className="mr-1 h-3 w-3" />
            Confirmed
          </Badge>
        );
      case 'pending-refund':
        return (
          <Badge className="bg-primary/20 text-primary border-primary/30">
            <Clock className="mr-1 h-3 w-3" />
            Refund Pending
          </Badge>
        );
      case 'refunded':
        return (
          <Badge variant="secondary">
            <RefreshCw className="mr-1 h-3 w-3" />
            Refunded
          </Badge>
        );
    }
  };

  const purchaseDate = new Date(order.purchaseDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <>
      <Card className="border-border/30 bg-card animate-fade-in">
        <CardHeader className="flex flex-row items-start justify-between">
          <div>
            <CardTitle className="font-display text-lg">{order.id}</CardTitle>
            <p className="text-sm text-muted-foreground">Purchased on {purchaseDate}</p>
          </div>
          {getStatusBadge()}
        </CardHeader>
        <CardContent className="space-y-4">
          {order.items.map((item, idx) => (
            <div 
              key={item.id} 
              className={`space-y-2 ${idx > 0 ? 'border-t border-border/30 pt-4' : ''}`}
            >
              <h4 className="font-semibold text-foreground">{item.playTitle}</h4>
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {item.showtime}
                </span>
                <span className="flex items-center gap-1">
                  <Armchair className="h-4 w-4" />
                  Seat {item.seat.row}{item.seat.number}
                </span>
                <span className="capitalize">
                  {item.seat.category} — ${item.seat.price}
                </span>
              </div>
            </div>
          ))}

          <div className="flex items-center justify-between border-t border-border/30 pt-4">
            <div>
              <span className="text-sm text-muted-foreground">Total: </span>
              <span className="text-lg font-semibold text-primary">${order.total}</span>
            </div>
            {order.status === 'confirmed' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowRefundDialog(true)}
                disabled={!isEligible}
                className={!isEligible ? 'opacity-50' : ''}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Request Refund
              </Button>
            )}
          </div>
          {order.status === 'confirmed' && !isEligible && (
            <p className="text-xs text-muted-foreground">
              Refunds are only available for shows more than 24 hours away.
            </p>
          )}
        </CardContent>
      </Card>

      <Dialog open={showRefundDialog} onOpenChange={setShowRefundDialog}>
        <DialogContent className="bg-popover border-border">
          <DialogHeader>
            <DialogTitle className="font-display">Request Refund</DialogTitle>
            <DialogDescription>
              Are you sure you want to request a refund for order {order.id}? 
              This will cancel your tickets for all {order.items.length} seat(s).
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm">
              Refund amount: <span className="font-semibold text-primary">${order.total}</span>
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Refunds typically process within 5-7 business days.
            </p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowRefundDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleRefundRequest} className="bg-primary text-primary-foreground">
              Confirm Refund
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default OrderCard;
