import { Link } from 'react-router-dom';
import { Clock, Star } from 'lucide-react';
import { Play } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface PlayCardProps {
  play: Play;
  index: number;
}

const PlayCard = ({ play, index }: PlayCardProps) => {
  return (
    <Link to={`/play/${play.id}`}>
      <Card 
        className="group overflow-hidden border-border/30 bg-gradient-card transition-all duration-500 hover:border-primary/50 hover:shadow-card-hover animate-fade-in"
        style={{ animationDelay: `${index * 100}ms` }}
      >
        <div className="relative aspect-[3/4] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent z-10" />
          <img
            src={play.image}
            alt={play.title}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            onError={(e) => {
              e.currentTarget.src = `https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=400&h=600&fit=crop`;
            }}
          />
          <Badge className="absolute left-3 top-3 z-20 bg-secondary text-secondary-foreground">
            {play.genre}
          </Badge>
          <div className="absolute bottom-0 left-0 right-0 z-20 p-4">
            <h3 className="font-display text-xl font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
              {play.title}
            </h3>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {play.duration}
              </span>
              <span className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-primary text-primary" />
                {play.rating}
              </span>
            </div>
          </div>
        </div>
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {play.description}
          </p>
          <p className="mt-3 text-sm font-medium text-primary">
            {play.showtimes.length} upcoming shows →
          </p>
        </CardContent>
      </Card>
    </Link>
  );
};

export default PlayCard;
