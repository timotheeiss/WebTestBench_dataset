import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { customers } from "@/data/mockData";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Mail, Phone, Eye, Ticket, ShoppingBag } from "lucide-react";

const interactionIcons = {
  email: Mail,
  call: Phone,
  visit: Eye,
  exhibition: Ticket,
  purchase: ShoppingBag,
};

export function RecentActivity() {
  // Get all interactions from all customers, sorted by date
  const allInteractions = customers
    .flatMap(customer => 
      customer.interactions.map(interaction => ({
        ...interaction,
        customerName: `${customer.firstName} ${customer.lastName}`,
        customerId: customer.id,
        customerStatus: customer.status,
      }))
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {allInteractions.map((interaction) => {
            const Icon = interactionIcons[interaction.type];
            return (
              <div 
                key={interaction.id}
                className="flex items-start gap-4 py-3 border-b border-border last:border-0 animate-fade-in"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary">
                  <Icon className="h-5 w-5 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium truncate">{interaction.customerName}</p>
                    <StatusBadge status={interaction.customerStatus} />
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-1">{interaction.notes}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(interaction.date).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
