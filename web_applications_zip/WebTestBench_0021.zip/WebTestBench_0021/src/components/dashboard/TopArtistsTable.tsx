import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { dashboardMetrics } from "@/data/mockData";

export function TopArtistsTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Top Artists</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {dashboardMetrics.topArtists.map((artist, index) => (
            <div 
              key={artist.artist}
              className="flex items-center justify-between py-2 border-b border-border last:border-0"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-sm font-medium text-muted-foreground">
                  {index + 1}
                </span>
                <div>
                  <p className="font-medium">{artist.artist}</p>
                  <p className="text-sm text-muted-foreground">{artist.sales} sales</p>
                </div>
              </div>
              <span className="font-semibold">${artist.revenue.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
