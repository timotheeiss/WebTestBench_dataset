import { CustomerStatus, STATUS_CONFIG } from "@/data/mockData";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: CustomerStatus;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status];
  
  return (
    <span 
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors",
        config.color,
        className
      )}
    >
      {config.label}
    </span>
  );
}
