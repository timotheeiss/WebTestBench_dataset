// Mock data for Art Gallery CRM

export type CustomerStatus = 
  | "new_lead" 
  | "contacted" 
  | "interested" 
  | "negotiating" 
  | "purchased" 
  | "vip_collector" 
  | "inactive";

export type ArtworkMedium = 
  | "oil" 
  | "acrylic" 
  | "watercolor" 
  | "sculpture" 
  | "photography" 
  | "mixed_media" 
  | "digital";

export interface Artwork {
  id: string;
  title: string;
  artist: string;
  year: number;
  medium: ArtworkMedium;
  price: number;
  imageUrl?: string;
  sold: boolean;
}

export interface Purchase {
  id: string;
  artworkId: string;
  date: string;
  amount: number;
}

export interface Interaction {
  id: string;
  type: "email" | "call" | "visit" | "exhibition" | "purchase";
  date: string;
  notes: string;
}

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  status: CustomerStatus;
  interests: string[];
  totalSpent: number;
  purchaseCount: number;
  lastContact: string;
  createdAt: string;
  notes: string;
  artworksInterested: string[];
  purchases: Purchase[];
  interactions: Interaction[];
  tags: string[];
}

export const STATUS_CONFIG: Record<CustomerStatus, { label: string; color: string }> = {
  new_lead: { label: "New Lead", color: "bg-info/10 text-info border-info/20" },
  contacted: { label: "Contacted", color: "bg-muted text-muted-foreground border-muted" },
  interested: { label: "Interested", color: "bg-warning/10 text-warning border-warning/20" },
  negotiating: { label: "Negotiating", color: "bg-accent/10 text-accent border-accent/20" },
  purchased: { label: "Purchased", color: "bg-success/10 text-success border-success/20" },
  vip_collector: { label: "VIP Collector", color: "bg-primary/10 text-primary border-primary/20" },
  inactive: { label: "Inactive", color: "bg-muted text-muted-foreground/60 border-muted" },
};

export const MEDIUM_LABELS: Record<ArtworkMedium, string> = {
  oil: "Oil Painting",
  acrylic: "Acrylic",
  watercolor: "Watercolor",
  sculpture: "Sculpture",
  photography: "Photography",
  mixed_media: "Mixed Media",
  digital: "Digital Art",
};

export const artworks: Artwork[] = [
  {
    id: "art-1",
    title: "Sunset Over Manhattan",
    artist: "Elena Voss",
    year: 2023,
    medium: "oil",
    price: 12500,
    sold: true,
  },
  {
    id: "art-2",
    title: "Abstract Emotions III",
    artist: "Marcus Chen",
    year: 2024,
    medium: "acrylic",
    price: 8900,
    sold: false,
  },
  {
    id: "art-3",
    title: "The Garden Path",
    artist: "Sarah Mitchell",
    year: 2023,
    medium: "watercolor",
    price: 4500,
    sold: true,
  },
  {
    id: "art-4",
    title: "Urban Fragments",
    artist: "David Park",
    year: 2024,
    medium: "photography",
    price: 3200,
    sold: false,
  },
  {
    id: "art-5",
    title: "Bronze Horizon",
    artist: "Anna Kowalski",
    year: 2022,
    medium: "sculpture",
    price: 28000,
    sold: true,
  },
  {
    id: "art-6",
    title: "Digital Dreams",
    artist: "Tech Collective",
    year: 2024,
    medium: "digital",
    price: 5500,
    sold: false,
  },
  {
    id: "art-7",
    title: "Memories of Blue",
    artist: "Elena Voss",
    year: 2024,
    medium: "oil",
    price: 15800,
    sold: false,
  },
  {
    id: "art-8",
    title: "Convergence",
    artist: "Marcus Chen",
    year: 2023,
    medium: "mixed_media",
    price: 11200,
    sold: true,
  },
];

export const customers: Customer[] = [
  {
    id: "cust-1",
    firstName: "Victoria",
    lastName: "Ashworth",
    email: "v.ashworth@email.com",
    phone: "+1 (555) 234-5678",
    status: "vip_collector",
    interests: ["Contemporary", "Abstract", "Sculpture"],
    totalSpent: 156000,
    purchaseCount: 8,
    lastContact: "2024-01-10",
    createdAt: "2021-03-15",
    notes: "Prefers private viewings. Interested in large-scale installations.",
    artworksInterested: ["art-2", "art-7"],
    purchases: [
      { id: "pur-1", artworkId: "art-1", date: "2023-11-20", amount: 12500 },
      { id: "pur-2", artworkId: "art-5", date: "2023-06-15", amount: 28000 },
    ],
    interactions: [
      { id: "int-1", type: "visit", date: "2024-01-10", notes: "Private viewing of new Elena Voss collection" },
      { id: "int-2", type: "exhibition", date: "2023-12-01", notes: "Attended winter gala" },
    ],
    tags: ["high-value", "contemporary-collector", "private-client"],
  },
  {
    id: "cust-2",
    firstName: "James",
    lastName: "Morrison",
    email: "j.morrison@company.com",
    phone: "+1 (555) 345-6789",
    status: "negotiating",
    interests: ["Photography", "Modern", "Minimalist"],
    totalSpent: 24500,
    purchaseCount: 3,
    lastContact: "2024-01-08",
    createdAt: "2022-08-22",
    notes: "Corporate buyer for office spaces. Budget around $50k per quarter.",
    artworksInterested: ["art-4", "art-6"],
    purchases: [
      { id: "pur-3", artworkId: "art-3", date: "2023-09-10", amount: 4500 },
    ],
    interactions: [
      { id: "int-3", type: "call", date: "2024-01-08", notes: "Discussed bulk purchase for new office" },
      { id: "int-4", type: "email", date: "2024-01-05", notes: "Sent portfolio of available photography" },
    ],
    tags: ["corporate", "bulk-buyer"],
  },
  {
    id: "cust-3",
    firstName: "Sophia",
    lastName: "Chen",
    email: "sophia.chen@gallery.net",
    phone: "+1 (555) 456-7890",
    status: "interested",
    interests: ["Asian Contemporary", "Ink Painting", "Ceramics"],
    totalSpent: 0,
    purchaseCount: 0,
    lastContact: "2024-01-05",
    createdAt: "2024-01-02",
    notes: "New collector, very enthusiastic. Attending upcoming exhibition.",
    artworksInterested: ["art-2", "art-8"],
    purchases: [],
    interactions: [
      { id: "int-5", type: "email", date: "2024-01-05", notes: "Welcome email and exhibition invite sent" },
      { id: "int-6", type: "visit", date: "2024-01-02", notes: "First gallery visit, showed interest in Marcus Chen" },
    ],
    tags: ["new-collector", "asian-art-interest"],
  },
  {
    id: "cust-4",
    firstName: "Robert",
    lastName: "Williams",
    email: "rwilliams@invest.com",
    phone: "+1 (555) 567-8901",
    status: "purchased",
    interests: ["Investment Art", "Blue Chip", "Emerging Artists"],
    totalSpent: 89000,
    purchaseCount: 5,
    lastContact: "2023-12-20",
    createdAt: "2020-11-10",
    notes: "Investment-focused collector. Tracks market trends closely.",
    artworksInterested: ["art-7"],
    purchases: [
      { id: "pur-4", artworkId: "art-8", date: "2023-12-15", amount: 11200 },
    ],
    interactions: [
      { id: "int-7", type: "call", date: "2023-12-20", notes: "Quarterly portfolio review call" },
    ],
    tags: ["investor", "returning-client"],
  },
  {
    id: "cust-5",
    firstName: "Emma",
    lastName: "Thompson",
    email: "emma.t@design.studio",
    phone: "+1 (555) 678-9012",
    status: "contacted",
    interests: ["Digital Art", "NFTs", "New Media"],
    totalSpent: 5500,
    purchaseCount: 1,
    lastContact: "2024-01-03",
    createdAt: "2023-10-15",
    notes: "Interior designer, sources for clients. Potential partnership.",
    artworksInterested: ["art-6"],
    purchases: [],
    interactions: [
      { id: "int-8", type: "email", date: "2024-01-03", notes: "Follow-up on partnership proposal" },
    ],
    tags: ["designer", "partnership-potential"],
  },
  {
    id: "cust-6",
    firstName: "Michael",
    lastName: "Foster",
    email: "mfoster@email.com",
    phone: "+1 (555) 789-0123",
    status: "new_lead",
    interests: ["Impressionism", "Landscapes"],
    totalSpent: 0,
    purchaseCount: 0,
    lastContact: "2024-01-12",
    createdAt: "2024-01-12",
    notes: "Referred by Victoria Ashworth. First-time collector.",
    artworksInterested: [],
    purchases: [],
    interactions: [
      { id: "int-9", type: "email", date: "2024-01-12", notes: "Initial inquiry via website" },
    ],
    tags: ["referral", "first-time-buyer"],
  },
  {
    id: "cust-7",
    firstName: "Isabella",
    lastName: "Romano",
    email: "isabella.romano@art.eu",
    phone: "+39 06 1234 5678",
    status: "inactive",
    interests: ["Renaissance", "Old Masters"],
    totalSpent: 45000,
    purchaseCount: 2,
    lastContact: "2023-06-15",
    createdAt: "2019-04-20",
    notes: "Based in Rome. Last active during European collection tour.",
    artworksInterested: [],
    purchases: [],
    interactions: [
      { id: "int-10", type: "exhibition", date: "2023-06-15", notes: "Met at Venice Biennale" },
    ],
    tags: ["international", "european-client"],
  },
  {
    id: "cust-8",
    firstName: "Alexander",
    lastName: "Petrov",
    email: "a.petrov@finance.ru",
    phone: "+7 495 123 4567",
    status: "vip_collector",
    interests: ["Russian Avant-Garde", "Contemporary", "Large Scale"],
    totalSpent: 420000,
    purchaseCount: 12,
    lastContact: "2024-01-11",
    createdAt: "2018-09-05",
    notes: "Major collector. Private jet for art transport. Annual budget $500k+.",
    artworksInterested: ["art-5", "art-7"],
    purchases: [],
    interactions: [
      { id: "int-11", type: "call", date: "2024-01-11", notes: "Discussed upcoming auction participation" },
    ],
    tags: ["high-value", "international", "vip"],
  },
];

export const dashboardMetrics = {
  totalCustomers: customers.length,
  totalRevenue: customers.reduce((acc, c) => acc + c.totalSpent, 0),
  activeDeals: customers.filter(c => c.status === "negotiating" || c.status === "interested").length,
  vipClients: customers.filter(c => c.status === "vip_collector").length,
  monthlyRevenue: [
    { month: "Aug", revenue: 28000 },
    { month: "Sep", revenue: 45000 },
    { month: "Oct", revenue: 32000 },
    { month: "Nov", revenue: 58000 },
    { month: "Dec", revenue: 72000 },
    { month: "Jan", revenue: 41000 },
  ],
  statusDistribution: [
    { status: "VIP Collector", count: 2, color: "#2d3748" },
    { status: "Purchased", count: 1, color: "#38a169" },
    { status: "Negotiating", count: 1, color: "#c9783a" },
    { status: "Interested", count: 1, color: "#d69e2e" },
    { status: "Contacted", count: 1, color: "#718096" },
    { status: "New Lead", count: 1, color: "#4299e1" },
    { status: "Inactive", count: 1, color: "#a0aec0" },
  ],
  topArtists: [
    { artist: "Elena Voss", sales: 3, revenue: 78000 },
    { artist: "Marcus Chen", sales: 5, revenue: 52000 },
    { artist: "Anna Kowalski", sales: 2, revenue: 56000 },
    { artist: "David Park", sales: 4, revenue: 28000 },
  ],
};
