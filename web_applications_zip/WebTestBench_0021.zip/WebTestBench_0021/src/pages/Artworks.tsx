import { useState, useMemo } from "react";
import { Search, Filter } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { artworks, ArtworkMedium, MEDIUM_LABELS } from "@/data/mockData";

const Artworks = () => {
  const [search, setSearch] = useState("");
  const [mediumFilter, setMediumFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredArtworks = useMemo(() => {
    return artworks.filter((artwork) => {
      const matchesSearch =
        artwork.title.toLowerCase().includes(search.toLowerCase()) ||
        artwork.artist.toLowerCase().includes(search.toLowerCase());

      const matchesMedium = mediumFilter === "all" || artwork.medium === mediumFilter;
      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "available" && !artwork.sold) ||
        (statusFilter === "sold" && artwork.sold);

      return matchesSearch && matchesMedium && matchesStatus;
    });
  }, [search, mediumFilter, statusFilter]);

  const totalValue = filteredArtworks.reduce((acc, a) => acc + a.price, 0);

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Artworks</h1>
          <p className="text-muted-foreground mt-1">
            Browse and manage your gallery collection
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by title or artist..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={mediumFilter} onValueChange={setMediumFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Medium" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Mediums</SelectItem>
              {Object.entries(MEDIUM_LABELS).map(([key, label]) => (
                <SelectItem key={key} value={key}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-36">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="sold">Sold</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>{filteredArtworks.length} artworks</span>
          <span>·</span>
          <span>Total value: ${totalValue.toLocaleString()}</span>
        </div>

        {/* Artwork Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredArtworks.map((artwork, index) => (
            <Card
              key={artwork.id}
              className="overflow-hidden transition-all duration-200 hover:shadow-lg group animate-scale-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Placeholder Image */}
              <div className="aspect-[4/3] bg-gradient-to-br from-secondary to-muted relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-light text-muted-foreground/30">
                    {artwork.title[0]}
                  </span>
                </div>
                {artwork.sold && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-foreground text-background">Sold</Badge>
                  </div>
                )}
              </div>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div>
                    <h3 className="font-semibold line-clamp-1 group-hover:text-accent transition-colors">
                      {artwork.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">{artwork.artist}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {MEDIUM_LABELS[artwork.medium]}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{artwork.year}</span>
                    </div>
                    <span className="font-semibold">${artwork.price.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredArtworks.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground">No artworks found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
};

export default Artworks;
