import { Users, DollarSign, Target, Crown } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { StatusDistributionChart } from "@/components/dashboard/StatusDistributionChart";
import { TopArtistsTable } from "@/components/dashboard/TopArtistsTable";
import { RecentActivity } from "@/components/dashboard/RecentActivity";
import { dashboardMetrics } from "@/data/mockData";

const Dashboard = () => {
  return (
    <MainLayout>
      <div className="space-y-8 animate-fade-in">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back. Here's your gallery overview.</p>
        </div>

        {/* Metrics Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Total Customers"
            value={dashboardMetrics.totalCustomers}
            subtitle="Active collectors"
            icon={Users}
            trend={{ value: 12, positive: true }}
          />
          <MetricCard
            title="Total Revenue"
            value={`$${(dashboardMetrics.totalRevenue / 1000).toFixed(0)}k`}
            subtitle="All time sales"
            icon={DollarSign}
            trend={{ value: 8, positive: true }}
          />
          <MetricCard
            title="Active Deals"
            value={dashboardMetrics.activeDeals}
            subtitle="In negotiation"
            icon={Target}
          />
          <MetricCard
            title="VIP Clients"
            value={dashboardMetrics.vipClients}
            subtitle="Top collectors"
            icon={Crown}
          />
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-3">
          <RevenueChart />
          <StatusDistributionChart />
        </div>

        {/* Bottom Row */}
        <div className="grid gap-6 lg:grid-cols-3">
          <RecentActivity />
          <TopArtistsTable />
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
