import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { 
  ArrowLeft, 
  Mail, 
  Phone, 
  Calendar,
  Edit2,
  Trash2,
  Plus,
  Eye,
  Ticket,
  ShoppingBag,
  PhoneCall,
  DollarSign
} from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { customers as initialCustomers, artworks, Customer, CustomerStatus, STATUS_CONFIG, MEDIUM_LABELS } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

const interactionIcons = {
  email: Mail,
  call: PhoneCall,
  visit: Eye,
  exhibition: Ticket,
  purchase: ShoppingBag,
};

const CustomerDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [customer, setCustomer] = useState<Customer | undefined>(
    initialCustomers.find((c) => c.id === id)
  );
  const [isEditing, setIsEditing] = useState(false);
  const [isAddingArtwork, setIsAddingArtwork] = useState(false);
  const [editData, setEditData] = useState<Partial<Customer>>({});

  if (!customer) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center py-24">
          <p className="text-muted-foreground mb-4">Customer not found</p>
          <Button asChild>
            <Link to="/customers">Back to Customers</Link>
          </Button>
        </div>
      </MainLayout>
    );
  }

  const interestedArtworks = artworks.filter((a) =>
    customer.artworksInterested.includes(a.id)
  );
  const purchasedArtworks = customer.purchases.map((p) => ({
    ...artworks.find((a) => a.id === p.artworkId),
    purchaseDate: p.date,
    purchaseAmount: p.amount,
  }));

  const handleSaveEdit = () => {
    setCustomer({ ...customer, ...editData });
    setIsEditing(false);
    toast({
      title: "Customer updated",
      description: "Changes have been saved successfully.",
    });
  };

  const handleStatusChange = (newStatus: CustomerStatus) => {
    setCustomer({ ...customer, status: newStatus });
    toast({
      title: "Status updated",
      description: `Customer status changed to ${STATUS_CONFIG[newStatus].label}`,
    });
  };

  const handleAddArtwork = (artworkId: string) => {
    if (!customer.artworksInterested.includes(artworkId)) {
      setCustomer({
        ...customer,
        artworksInterested: [...customer.artworksInterested, artworkId],
      });
      toast({
        title: "Artwork added",
        description: "The artwork has been added to interested list.",
      });
    }
    setIsAddingArtwork(false);
  };

  const availableArtworks = artworks.filter(
    (a) => !customer.artworksInterested.includes(a.id) && !a.sold
  );

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Back Button */}
        <Button variant="ghost" asChild className="gap-2 -ml-2">
          <Link to="/customers">
            <ArrowLeft className="h-4 w-4" />
            Back to Customers
          </Link>
        </Button>

        {/* Header */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-secondary text-xl font-semibold">
              {customer.firstName[0]}
              {customer.lastName[0]}
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-semibold tracking-tight">
                  {customer.firstName} {customer.lastName}
                </h1>
                <StatusBadge status={customer.status} />
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Mail className="h-4 w-4" />
                  {customer.email}
                </span>
                {customer.phone && (
                  <span className="flex items-center gap-1.5">
                    <Phone className="h-4 w-4" />
                    {customer.phone}
                  </span>
                )}
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  Customer since{" "}
                  {new Date(customer.createdAt).toLocaleDateString("en-US", {
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Select value={customer.status} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(STATUS_CONFIG).map(([key, config]) => (
                  <SelectItem key={key} value={key}>
                    {config.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isEditing} onOpenChange={setIsEditing}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2" onClick={() => setEditData(customer)}>
                  <Edit2 className="h-4 w-4" />
                  Edit
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Customer</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label>First Name</Label>
                      <Input
                        value={editData.firstName || ""}
                        onChange={(e) => setEditData({ ...editData, firstName: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Last Name</Label>
                      <Input
                        value={editData.lastName || ""}
                        onChange={(e) => setEditData({ ...editData, lastName: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      value={editData.email || ""}
                      onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      value={editData.phone || ""}
                      onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Notes</Label>
                    <Textarea
                      value={editData.notes || ""}
                      onChange={(e) => setEditData({ ...editData, notes: e.target.value })}
                      rows={4}
                    />
                  </div>
                  <Button onClick={handleSaveEdit} className="w-full">
                    Save Changes
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                  <DollarSign className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Spent</p>
                  <p className="text-xl font-semibold">${customer.totalSpent.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                  <ShoppingBag className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Purchases</p>
                  <p className="text-xl font-semibold">{customer.purchaseCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
                  <Eye className="h-5 w-5 text-info" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Interested In</p>
                  <p className="text-xl font-semibold">{customer.artworksInterested.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last Contact</p>
                  <p className="text-xl font-semibold">
                    {new Date(customer.lastContact).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Content */}
        <Tabs defaultValue="artworks" className="space-y-4">
          <TabsList>
            <TabsTrigger value="artworks">Artworks</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="notes">Notes & Tags</TabsTrigger>
          </TabsList>

          <TabsContent value="artworks" className="space-y-4">
            {/* Interested Artworks */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle className="text-lg">Interested Artworks</CardTitle>
                <Dialog open={isAddingArtwork} onOpenChange={setIsAddingArtwork}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add Artwork
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Interested Artwork</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-3 pt-4 max-h-96 overflow-y-auto">
                      {availableArtworks.length === 0 ? (
                        <p className="text-muted-foreground text-center py-8">
                          No available artworks to add
                        </p>
                      ) : (
                        availableArtworks.map((artwork) => (
                          <div
                            key={artwork.id}
                            onClick={() => handleAddArtwork(artwork.id)}
                            className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-muted transition-colors"
                          >
                            <div>
                              <p className="font-medium">{artwork.title}</p>
                              <p className="text-sm text-muted-foreground">
                                {artwork.artist} · {MEDIUM_LABELS[artwork.medium]}
                              </p>
                            </div>
                            <span className="font-semibold">${artwork.price.toLocaleString()}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {interestedArtworks.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No artworks of interest yet
                  </p>
                ) : (
                  <div className="space-y-3">
                    {interestedArtworks.map((artwork) => (
                      <div
                        key={artwork.id}
                        className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                      >
                        <div>
                          <p className="font-medium">{artwork.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {artwork.artist} · {artwork.year} · {MEDIUM_LABELS[artwork.medium]}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">${artwork.price.toLocaleString()}</p>
                          <Badge variant={artwork.sold ? "secondary" : "outline"}>
                            {artwork.sold ? "Sold" : "Available"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Purchase History */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Purchase History</CardTitle>
              </CardHeader>
              <CardContent>
                {purchasedArtworks.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No purchases yet
                  </p>
                ) : (
                  <div className="space-y-3">
                    {purchasedArtworks.map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 rounded-lg bg-success/5 border border-success/10"
                      >
                        <div>
                          <p className="font-medium">{item?.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {item?.artist} · Purchased{" "}
                            {new Date(item.purchaseDate).toLocaleDateString("en-US", {
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </p>
                        </div>
                        <p className="font-semibold text-success">
                          ${item.purchaseAmount.toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Interaction History</CardTitle>
              </CardHeader>
              <CardContent>
                {customer.interactions.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No interactions recorded
                  </p>
                ) : (
                  <div className="space-y-4">
                    {customer.interactions
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((interaction) => {
                        const Icon = interactionIcons[interaction.type];
                        return (
                          <div
                            key={interaction.id}
                            className="flex items-start gap-4 p-4 rounded-lg border"
                          >
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary">
                              <Icon className="h-5 w-5 text-muted-foreground" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <p className="font-medium capitalize">{interaction.type}</p>
                                <p className="text-sm text-muted-foreground">
                                  {new Date(interaction.date).toLocaleDateString("en-US", {
                                    month: "long",
                                    day: "numeric",
                                    year: "numeric",
                                  })}
                                </p>
                              </div>
                              <p className="text-muted-foreground">{interaction.notes}</p>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes">
            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {customer.notes || "No notes added yet."}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tags</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {customer.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Interests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {customer.interests.map((interest) => (
                      <Badge key={interest} variant="outline">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default CustomerDetail;
