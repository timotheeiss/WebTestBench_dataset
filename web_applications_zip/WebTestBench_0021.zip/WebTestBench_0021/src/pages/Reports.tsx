import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { customers, dashboardMetrics, STATUS_CONFIG } from "@/data/mockData";

const Reports = () => {
  // Customer acquisition by month (simulated)
  const acquisitionData = [
    { month: "Jul", newCustomers: 2 },
    { month: "Aug", newCustomers: 3 },
    { month: "Sep", newCustomers: 1 },
    { month: "Oct", newCustomers: 4 },
    { month: "Nov", newCustomers: 2 },
    { month: "Dec", newCustomers: 3 },
    { month: "Jan", newCustomers: 2 },
  ];

  // Revenue by customer type
  const revenueByType = [
    { type: "VIP Collectors", revenue: 576000, color: "#2d3748" },
    { type: "Regular Buyers", revenue: 168500, color: "#c9783a" },
    { type: "New Collectors", revenue: 0, color: "#4299e1" },
  ];

  // Engagement metrics
  const engagementData = [
    { month: "Aug", emails: 45, calls: 12, visits: 8 },
    { month: "Sep", emails: 52, calls: 15, visits: 10 },
    { month: "Oct", emails: 38, calls: 18, visits: 6 },
    { month: "Nov", emails: 65, calls: 22, visits: 14 },
    { month: "Dec", emails: 72, calls: 28, visits: 18 },
    { month: "Jan", emails: 48, calls: 16, visits: 12 },
  ];

  // Status conversion funnel
  const funnelData = [
    { stage: "New Leads", count: customers.filter(c => c.status === "new_lead").length },
    { stage: "Contacted", count: customers.filter(c => c.status === "contacted").length },
    { stage: "Interested", count: customers.filter(c => c.status === "interested").length },
    { stage: "Negotiating", count: customers.filter(c => c.status === "negotiating").length },
    { stage: "Purchased", count: customers.filter(c => c.status === "purchased").length + customers.filter(c => c.status === "vip_collector").length },
  ];

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Reports</h1>
          <p className="text-muted-foreground mt-1">
            Analytics and performance summaries
          </p>
        </div>

        {/* Summary Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total Revenue (All Time)</p>
              <p className="text-2xl font-semibold mt-1">${dashboardMetrics.totalRevenue.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Avg. Purchase Value</p>
              <p className="text-2xl font-semibold mt-1">
                ${Math.round(dashboardMetrics.totalRevenue / customers.filter(c => c.purchaseCount > 0).length).toLocaleString()}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Conversion Rate</p>
              <p className="text-2xl font-semibold mt-1">
                {Math.round((customers.filter(c => c.status === "purchased" || c.status === "vip_collector").length / customers.length) * 100)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Active Relationships</p>
              <p className="text-2xl font-semibold mt-1">
                {customers.filter(c => c.status !== "inactive").length}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Reports Tabs */}
        <Tabs defaultValue="revenue" className="space-y-4">
          <TabsList>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="funnel">Sales Funnel</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Monthly Revenue Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={dashboardMetrics.monthlyRevenue}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 15%, 88%)" />
                        <XAxis dataKey="month" stroke="hsl(220, 10%, 45%)" fontSize={12} />
                        <YAxis stroke="hsl(220, 10%, 45%)" fontSize={12} tickFormatter={(v) => `$${v/1000}k`} />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "hsl(0, 0%, 100%)",
                            border: "1px solid hsl(40, 15%, 88%)",
                            borderRadius: "8px",
                          }}
                          formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                        />
                        <Bar dataKey="revenue" fill="hsl(25, 60%, 55%)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Revenue by Customer Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={revenueByType}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          dataKey="revenue"
                          nameKey="type"
                          paddingAngle={2}
                        >
                          {revenueByType.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "hsl(0, 0%, 100%)",
                            border: "1px solid hsl(40, 15%, 88%)",
                            borderRadius: "8px",
                          }}
                          formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    {revenueByType.map((item) => (
                      <div key={item.type} className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-sm text-muted-foreground">{item.type}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Artists Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Artist Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dashboardMetrics.topArtists} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 15%, 88%)" />
                      <XAxis type="number" stroke="hsl(220, 10%, 45%)" fontSize={12} tickFormatter={(v) => `$${v/1000}k`} />
                      <YAxis dataKey="artist" type="category" stroke="hsl(220, 10%, 45%)" fontSize={12} width={100} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(0, 0%, 100%)",
                          border: "1px solid hsl(40, 15%, 88%)",
                          borderRadius: "8px",
                        }}
                        formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                      />
                      <Bar dataKey="revenue" fill="hsl(220, 15%, 20%)" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Customer Engagement Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={engagementData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 15%, 88%)" />
                      <XAxis dataKey="month" stroke="hsl(220, 10%, 45%)" fontSize={12} />
                      <YAxis stroke="hsl(220, 10%, 45%)" fontSize={12} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(0, 0%, 100%)",
                          border: "1px solid hsl(40, 15%, 88%)",
                          borderRadius: "8px",
                        }}
                      />
                      <Line type="monotone" dataKey="emails" stroke="hsl(25, 60%, 55%)" strokeWidth={2} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="calls" stroke="hsl(220, 15%, 20%)" strokeWidth={2} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="visits" stroke="hsl(145, 60%, 40%)" strokeWidth={2} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-accent" />
                    <span className="text-sm text-muted-foreground">Emails</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-primary" />
                    <span className="text-sm text-muted-foreground">Calls</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-success" />
                    <span className="text-sm text-muted-foreground">Gallery Visits</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Customer Acquisition</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={acquisitionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 15%, 88%)" />
                      <XAxis dataKey="month" stroke="hsl(220, 10%, 45%)" fontSize={12} />
                      <YAxis stroke="hsl(220, 10%, 45%)" fontSize={12} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(0, 0%, 100%)",
                          border: "1px solid hsl(40, 15%, 88%)",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="newCustomers" fill="hsl(200, 80%, 50%)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="funnel" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sales Conversion Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={funnelData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(40, 15%, 88%)" />
                      <XAxis type="number" stroke="hsl(220, 10%, 45%)" fontSize={12} />
                      <YAxis dataKey="stage" type="category" stroke="hsl(220, 10%, 45%)" fontSize={12} width={100} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(0, 0%, 100%)",
                          border: "1px solid hsl(40, 15%, 88%)",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="count" fill="hsl(25, 60%, 55%)" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Status Breakdown Table */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Customer Status Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(STATUS_CONFIG).map(([status, config]) => {
                    const count = customers.filter(c => c.status === status).length;
                    const percentage = Math.round((count / customers.length) * 100);
                    return (
                      <div key={status} className="flex items-center gap-4">
                        <div className="w-32">
                          <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${config.color}`}>
                            {config.label}
                          </span>
                        </div>
                        <div className="flex-1">
                          <div className="h-2 rounded-full bg-muted overflow-hidden">
                            <div 
                              className="h-full bg-accent transition-all duration-500"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                        <div className="w-20 text-right">
                          <span className="font-medium">{count}</span>
                          <span className="text-muted-foreground text-sm ml-1">({percentage}%)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Reports;
