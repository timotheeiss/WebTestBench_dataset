import React, { createContext, useContext, useState, useCallback } from 'react';
import { Poll, PollOption, PollStatus, VotingMode, Vote } from '@/types/poll';
import { defaultPolls } from '@/data/defaultData';

interface CreatePollData {
  title: string;
  description: string;
  options: string[];
  deadline: Date | null;
  votingMode: VotingMode;
}

interface PollContextType {
  polls: Poll[];
  getPoll: (id: string) => Poll | undefined;
  getUserPolls: (userId: string) => Poll[];
  createPoll: (data: CreatePollData, creatorId: string) => Poll;
  updatePollStatus: (pollId: string, status: PollStatus) => void;
  vote: (pollId: string, optionId: string, odterId: string | null) => boolean;
  hasVoted: (pollId: string, odterId: string | null) => boolean;
  getShareUrl: (pollId: string) => string;
}

const PollContext = createContext<PollContextType | undefined>(undefined);

export function PollProvider({ children }: { children: React.ReactNode }) {
  const [polls, setPolls] = useState<Poll[]>(defaultPolls);

  const getPoll = useCallback((id: string) => {
    return polls.find(p => p.id === id);
  }, [polls]);

  const getUserPolls = useCallback((userId: string) => {
    return polls.filter(p => p.creatorId === userId);
  }, [polls]);

  const createPoll = useCallback((data: CreatePollData, creatorId: string): Poll => {
    const newPoll: Poll = {
      id: `poll-${Date.now()}`,
      title: data.title,
      description: data.description,
      options: data.options.map((text, i) => ({
        id: `opt-${Date.now()}-${i}`,
        text,
        votes: 0,
      })),
      creatorId,
      createdAt: new Date(),
      deadline: data.deadline,
      votingMode: data.votingMode,
      status: 'active',
      votes: [],
    };
    setPolls(prev => [newPoll, ...prev]);
    return newPoll;
  }, []);

  const updatePollStatus = useCallback((pollId: string, status: PollStatus) => {
    setPolls(prev => prev.map(p => 
      p.id === pollId ? { ...p, status } : p
    ));
  }, []);

  const vote = useCallback((pollId: string, optionId: string, odterId: string | null): boolean => {
    const poll = polls.find(p => p.id === pollId);
    if (!poll || poll.status !== 'active') return false;
    
    // Check if already voted
    if (odterId && poll.votes.some(v => v.odterId === odterId)) return false;
    
    setPolls(prev => prev.map(p => {
      if (p.id !== pollId) return p;
      
      const newVote: Vote = {
        optionId,
        odterId,
        votedAt: new Date(),
      };
      
      return {
        ...p,
        options: p.options.map(opt => 
          opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
        ),
        votes: [...p.votes, newVote],
      };
    }));
    
    return true;
  }, [polls]);

  const hasVoted = useCallback((pollId: string, odterId: string | null): boolean => {
    if (!odterId) return false;
    const poll = polls.find(p => p.id === pollId);
    return poll?.votes.some(v => v.odterId === odterId) ?? false;
  }, [polls]);

  const getShareUrl = useCallback((pollId: string): string => {
    return `${window.location.origin}/poll/${pollId}`;
  }, []);

  return (
    <PollContext.Provider value={{
      polls,
      getPoll,
      getUserPolls,
      createPoll,
      updatePollStatus,
      vote,
      hasVoted,
      getShareUrl,
    }}>
      {children}
    </PollContext.Provider>
  );
}

export function usePolls() {
  const context = useContext(PollContext);
  if (!context) {
    throw new Error('usePolls must be used within PollProvider');
  }
  return context;
}
