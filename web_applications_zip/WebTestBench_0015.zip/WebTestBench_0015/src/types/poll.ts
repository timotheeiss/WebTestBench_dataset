export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Vote {
  optionId: string;
  odterId: string | null; // null for anonymous
  votedAt: Date;
}

export type PollStatus = 'active' | 'closed' | 'readonly';
export type VotingMode = 'anonymous' | 'authenticated';

export interface Poll {
  id: string;
  title: string;
  description: string;
  options: PollOption[];
  creatorId: string;
  createdAt: Date;
  deadline: Date | null;
  votingMode: VotingMode;
  status: PollStatus;
  votes: Vote[];
}

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}
