import { Poll } from '@/types/poll';
import { cn } from '@/lib/utils';

interface PollResultsProps {
  poll: Poll;
  selectedOption?: string;
  animate?: boolean;
}

const barColors = [
  'bg-chart-1',
  'bg-chart-2',
  'bg-chart-3',
  'bg-chart-4',
  'bg-chart-5',
];

export function PollResults({ poll, selectedOption, animate = true }: PollResultsProps) {
  const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);

  return (
    <div className="space-y-4">
      {poll.options.map((option, index) => {
        const percentage = totalVotes > 0 ? (option.votes / totalVotes) * 100 : 0;
        const isSelected = option.id === selectedOption;
        const colorClass = barColors[index % barColors.length];

        return (
          <div 
            key={option.id} 
            className={cn(
              "relative p-4 rounded-xl border-2 transition-all duration-300",
              isSelected 
                ? "border-primary bg-accent" 
                : "border-border bg-card hover:border-primary/30"
            )}
          >
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isSelected && (
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary">
                    <svg className="h-3 w-3 text-primary-foreground" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
                <span className="font-medium text-foreground">{option.text}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm text-muted-foreground">
                  {option.votes} {option.votes === 1 ? 'vote' : 'votes'}
                </span>
                <span className="font-display font-semibold text-foreground min-w-[3rem] text-right">
                  {Math.round(percentage)}%
                </span>
              </div>
            </div>
            
            <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn(
                  "h-full rounded-full transition-all",
                  colorClass,
                  animate ? "animate-bar-grow" : ""
                )}
                style={{ 
                  width: animate ? undefined : `${percentage}%`,
                  ['--target-width' as string]: `${percentage}%`,
                  animationDelay: `${index * 0.1}s`,
                }}
              />
            </div>
          </div>
        );
      })}
      
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-muted-foreground">
          Total votes: <span className="font-semibold text-foreground">{totalVotes}</span>
        </p>
      </div>
    </div>
  );
}
