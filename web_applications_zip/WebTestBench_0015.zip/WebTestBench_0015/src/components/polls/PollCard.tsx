import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Poll } from '@/types/poll';
import { Calendar, Users, Lock, Globe, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface PollCardProps {
  poll: Poll;
  showManage?: boolean;
}

export function PollCard({ poll, showManage = false }: PollCardProps) {
  const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
  
  const statusColors = {
    active: 'bg-success/10 text-success border-success/20',
    closed: 'bg-destructive/10 text-destructive border-destructive/20',
    readonly: 'bg-warning/10 text-warning border-warning/20',
  };

  const isExpired = poll.deadline && new Date(poll.deadline) < new Date();

  return (
    <Link to={showManage ? `/manage/${poll.id}` : `/poll/${poll.id}`}>
      <Card className="h-full hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <CardTitle className="text-lg line-clamp-2 group-hover:text-primary transition-colors">
              {poll.title}
            </CardTitle>
            <Badge variant="outline" className={statusColors[poll.status]}>
              {poll.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {poll.description}
          </p>
          
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              <span>{totalVotes} votes</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>{format(new Date(poll.createdAt), 'MMM d, yyyy')}</span>
            </div>
            <div className="flex items-center gap-1.5">
              {poll.votingMode === 'anonymous' ? (
                <>
                  <Globe className="h-3.5 w-3.5" />
                  <span>Anonymous</span>
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" />
                  <span>Sign-in required</span>
                </>
              )}
            </div>
            {poll.deadline && (
              <div className={`flex items-center gap-1.5 ${isExpired ? 'text-destructive' : ''}`}>
                <Clock className="h-3.5 w-3.5" />
                <span>{isExpired ? 'Expired' : `Due ${format(new Date(poll.deadline), 'MMM d')}`}</span>
              </div>
            )}
          </div>

          <div className="space-y-2">
            {poll.options.slice(0, 3).map((option) => {
              const percentage = totalVotes > 0 ? (option.votes / totalVotes) * 100 : 0;
              return (
                <div key={option.id} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="truncate flex-1 text-foreground">{option.text}</span>
                    <span className="text-muted-foreground ml-2">{Math.round(percentage)}%</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
            {poll.options.length > 3 && (
              <p className="text-xs text-muted-foreground">
                +{poll.options.length - 3} more options
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
