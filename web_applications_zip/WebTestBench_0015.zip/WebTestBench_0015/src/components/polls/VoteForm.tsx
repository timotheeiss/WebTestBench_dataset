import { useState } from 'react';
import { Poll } from '@/types/poll';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

interface VoteFormProps {
  poll: Poll;
  onVote: (optionId: string) => void;
  disabled?: boolean;
}

export function VoteForm({ poll, onVote, disabled }: VoteFormProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedOption) {
      onVote(selectedOption);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-3">
        {poll.options.map((option, index) => (
          <button
            key={option.id}
            type="button"
            onClick={() => !disabled && setSelectedOption(option.id)}
            disabled={disabled}
            className={cn(
              "w-full p-4 rounded-xl border-2 text-left transition-all duration-200 group",
              "opacity-0 animate-slide-up",
              selectedOption === option.id
                ? "border-primary bg-accent shadow-md"
                : "border-border bg-card hover:border-primary/50 hover:shadow-sm",
              disabled && "opacity-50 cursor-not-allowed"
            )}
            style={{ animationDelay: `${index * 0.1}s`, animationFillMode: 'forwards' }}
          >
            <div className="flex items-center justify-between">
              <span className={cn(
                "font-medium transition-colors",
                selectedOption === option.id ? "text-primary" : "text-foreground group-hover:text-primary"
              )}>
                {option.text}
              </span>
              <div className={cn(
                "flex h-6 w-6 items-center justify-center rounded-full border-2 transition-all",
                selectedOption === option.id
                  ? "border-primary bg-primary"
                  : "border-muted-foreground/30 group-hover:border-primary/50"
              )}>
                {selectedOption === option.id && (
                  <Check className="h-4 w-4 text-primary-foreground animate-scale-in" />
                )}
              </div>
            </div>
          </button>
        ))}
      </div>

      <Button 
        type="submit" 
        variant="hero"
        size="lg"
        className="w-full"
        disabled={!selectedOption || disabled}
      >
        Submit Vote
      </Button>
    </form>
  );
}
