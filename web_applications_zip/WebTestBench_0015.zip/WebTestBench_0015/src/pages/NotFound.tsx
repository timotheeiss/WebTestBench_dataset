import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container flex flex-col items-center justify-center py-20 text-center">
        <span className="font-display text-[120px] font-bold text-muted/50 leading-none mb-4">404</span>
        <h1 className="font-display text-2xl font-bold text-foreground mb-3">Page Not Found</h1>
        <p className="text-muted-foreground mb-8">The page you're looking for doesn't exist.</p>
        <Link to="/"><Button variant="hero" className="gap-2"><Home className="h-4 w-4" />Back to Home</Button></Link>
      </div>
    </div>
  );
}
