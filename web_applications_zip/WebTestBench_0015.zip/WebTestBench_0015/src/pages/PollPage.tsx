import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/layout/Header';
import { VoteForm } from '@/components/polls/VoteForm';
import { PollResults } from '@/components/polls/PollResults';
import { usePolls } from '@/context/PollContext';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Calendar, Users, Lock, Globe, Clock, AlertCircle, ArrowLeft } from 'lucide-react';

export default function PollPage() {
  const { id } = useParams<{ id: string }>();
  const { getPoll, vote, hasVoted } = usePolls();
  const { user, isAuthenticated } = useAuth();
  const [hasVotedLocal, setHasVotedLocal] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const poll = id ? getPoll(id) : undefined;

  useEffect(() => {
    if (poll && user) {
      setHasVotedLocal(hasVoted(poll.id, user.id));
    }
  }, [poll, user, hasVoted]);

  if (!poll) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="font-display text-2xl font-bold text-foreground mb-2">
            Poll Not Found
          </h1>
          <p className="text-muted-foreground mb-6">
            This poll may have been deleted or the link is incorrect.
          </p>
          <Link to="/">
            <Button variant="default">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
  const isExpired = poll.deadline && new Date(poll.deadline) < new Date();
  const canVote = poll.status === 'active' && !isExpired && !hasVotedLocal;
  const requiresAuth = poll.votingMode === 'authenticated' && !isAuthenticated;
  const showResults = hasVotedLocal || poll.status !== 'active' || isExpired;

  const handleVote = (optionId: string) => {
    if (requiresAuth) {
      toast.error('Please sign in to vote on this poll');
      return;
    }

    const success = vote(poll.id, optionId, user?.id ?? null);
    if (success) {
      setSelectedOption(optionId);
      setHasVotedLocal(true);
      toast.success('Your vote has been recorded!');
    } else {
      toast.error('Unable to submit vote. Please try again.');
    }
  };

  const statusColors = {
    active: 'bg-success/10 text-success border-success/20',
    closed: 'bg-destructive/10 text-destructive border-destructive/20',
    readonly: 'bg-warning/10 text-warning border-warning/20',
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container max-w-2xl py-8">
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>

        <Card className="animate-scale-in">
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <CardTitle className="text-2xl">{poll.title}</CardTitle>
                {poll.description && (
                  <CardDescription className="text-base">
                    {poll.description}
                  </CardDescription>
                )}
              </div>
              <Badge variant="outline" className={statusColors[poll.status]}>
                {poll.status}
              </Badge>
            </div>

            <div className="flex flex-wrap gap-4 pt-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Users className="h-4 w-4" />
                <span>{totalVotes} votes</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                <span>{format(new Date(poll.createdAt), 'MMM d, yyyy')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {poll.votingMode === 'anonymous' ? (
                  <>
                    <Globe className="h-4 w-4" />
                    <span>Anonymous voting</span>
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4" />
                    <span>Sign-in required</span>
                  </>
                )}
              </div>
              {poll.deadline && (
                <div className={`flex items-center gap-1.5 ${isExpired ? 'text-destructive' : ''}`}>
                  <Clock className="h-4 w-4" />
                  <span>
                    {isExpired 
                      ? `Expired ${format(new Date(poll.deadline), 'MMM d')}`
                      : `Ends ${format(new Date(poll.deadline), 'MMM d, h:mm a')}`
                    }
                  </span>
                </div>
              )}
            </div>
          </CardHeader>
          
          <CardContent>
            {/* Auth Required Message */}
            {requiresAuth && canVote && (
              <div className="mb-6 p-4 rounded-lg bg-accent border border-primary/20">
                <div className="flex items-center gap-3">
                  <Lock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium text-foreground">Sign in to vote</p>
                    <p className="text-sm text-muted-foreground">
                      This poll requires authentication to prevent duplicate votes.
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <Link to="/login">
                    <Button variant="default" size="sm">Log in</Button>
                  </Link>
                  <Link to="/signup">
                    <Button variant="outline" size="sm">Sign up</Button>
                  </Link>
                </div>
              </div>
            )}

            {/* Poll Closed/Expired Message */}
            {(poll.status === 'closed' || isExpired) && !hasVotedLocal && (
              <div className="mb-6 p-4 rounded-lg bg-muted">
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-5 w-5 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    {poll.status === 'closed' 
                      ? 'This poll is closed and no longer accepting votes.'
                      : 'This poll has expired and is no longer accepting votes.'
                    }
                  </p>
                </div>
              </div>
            )}

            {/* Vote Form or Results */}
            {showResults ? (
              <div className="space-y-4">
                {hasVotedLocal && (
                  <div className="p-3 rounded-lg bg-success/10 border border-success/20 text-success text-sm text-center">
                    ✓ Thank you for voting!
                  </div>
                )}
                <PollResults poll={poll} selectedOption={selectedOption ?? undefined} />
              </div>
            ) : (
              <VoteForm 
                poll={poll} 
                onVote={handleVote}
                disabled={requiresAuth}
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
