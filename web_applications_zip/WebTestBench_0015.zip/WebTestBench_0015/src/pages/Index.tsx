import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/layout/Header';
import { PollCard } from '@/components/polls/PollCard';
import { usePolls } from '@/context/PollContext';
import { useAuth } from '@/context/AuthContext';
import { ArrowRight, BarChart3, Share2, Shield, Sparkles } from 'lucide-react';

export default function Index() {
  const { polls } = usePolls();
  const { isAuthenticated } = useAuth();
  
  const activePolls = polls.filter(p => p.status === 'active').slice(0, 3);

  const features = [
    { icon: BarChart3, title: 'Live Results', description: 'Watch votes come in with beautiful, animated bar charts that update instantly.' },
    { icon: Share2, title: 'Easy Sharing', description: 'Share your polls with a simple link. Voters can participate in seconds.' },
    { icon: Shield, title: 'Flexible Privacy', description: 'Choose between anonymous voting or require sign-in for verified responses.' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 gradient-subtle opacity-50" />
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl" />
        
        <div className="container relative">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent border border-primary/20 text-sm text-accent-foreground mb-6 animate-fade-in">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>Create beautiful polls in seconds</span>
            </div>
            
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6 animate-slide-up">
              Decisions made <span className="text-primary">simple</span> and beautiful
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Create engaging polls, share them instantly, and watch results update in real-time.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to={isAuthenticated ? '/create' : '/signup'}>
                <Button variant="hero" size="xl" className="gap-2 group">
                  {isAuthenticated ? 'Create a Poll' : 'Get Started Free'}
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/poll/poll-1">
                <Button variant="outline" size="xl">See Example Poll</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-border">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl font-bold text-foreground mb-4">Everything you need for great polls</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Simple, powerful features designed to help you gather feedback efficiently.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div key={feature.title} className="relative p-6 rounded-2xl bg-card border border-border hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl gradient-hero shadow-md mb-4 group-hover:shadow-glow transition-shadow">
                  <feature.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {activePolls.length > 0 && (
        <section className="py-20 bg-muted/30">
          <div className="container">
            <h2 className="font-display text-2xl font-bold text-foreground mb-8">Active Polls</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activePolls.map((poll) => <PollCard key={poll.id} poll={poll} />)}
            </div>
          </div>
        </section>
      )}

      <footer className="py-8 border-t border-border">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-hero">
              <BarChart3 className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-display font-semibold text-foreground">PollWise</span>
          </div>
          <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} PollWise. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
