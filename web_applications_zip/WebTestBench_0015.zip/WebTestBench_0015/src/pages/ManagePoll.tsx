import { useState } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/layout/Header';
import { PollResults } from '@/components/polls/PollResults';
import { usePolls } from '@/context/PollContext';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { PollStatus } from '@/types/poll';
import { 
  ArrowLeft, 
  Calendar, 
  Users, 
  Lock, 
  Globe, 
  Clock, 
  AlertCircle,
  Share2,
  Copy,
  Play,
  Pause,
  Eye,
  ExternalLink
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ManagePoll() {
  const { id } = useParams<{ id: string }>();
  const { getPoll, updatePollStatus, getShareUrl } = usePolls();
  const { user, isAuthenticated } = useAuth();
  const [copied, setCopied] = useState(false);

  const poll = id ? getPoll(id) : undefined;

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  if (!poll) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="font-display text-2xl font-bold text-foreground mb-2">
            Poll Not Found
          </h1>
          <p className="text-muted-foreground mb-6">
            This poll may have been deleted or you don't have permission to manage it.
          </p>
          <Link to="/dashboard">
            <Button variant="default">Go to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (poll.creatorId !== user.id) {
    return <Navigate to={`/poll/${poll.id}`} replace />;
  }

  const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
  const isExpired = poll.deadline && new Date(poll.deadline) < new Date();
  const shareUrl = getShareUrl(poll.id);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success('Link copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy link');
    }
  };

  const handleStatusChange = (newStatus: PollStatus) => {
    updatePollStatus(poll.id, newStatus);
    const messages = {
      active: 'Poll is now active and accepting votes',
      closed: 'Poll has been closed',
      readonly: 'Poll is now in read-only mode',
    };
    toast.success(messages[newStatus]);
  };

  const statusColors = {
    active: 'bg-success/10 text-success border-success/20',
    closed: 'bg-destructive/10 text-destructive border-destructive/20',
    readonly: 'bg-warning/10 text-warning border-warning/20',
  };

  const statusActions: { status: PollStatus; icon: typeof Play; label: string }[] = [
    { status: 'active', icon: Play, label: 'Open' },
    { status: 'closed', icon: Pause, label: 'Close' },
    { status: 'readonly', icon: Eye, label: 'Read-only' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container max-w-3xl py-8">
        <Link 
          to="/dashboard" 
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to dashboard
        </Link>

        <div className="space-y-6">
          {/* Poll Header */}
          <Card className="animate-scale-in">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <CardTitle className="text-2xl">{poll.title}</CardTitle>
                  {poll.description && (
                    <CardDescription className="text-base">
                      {poll.description}
                    </CardDescription>
                  )}
                </div>
                <Badge variant="outline" className={statusColors[poll.status]}>
                  {poll.status}
                </Badge>
              </div>

              <div className="flex flex-wrap gap-4 pt-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Users className="h-4 w-4" />
                  <span>{totalVotes} votes</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  <span>{format(new Date(poll.createdAt), 'MMM d, yyyy')}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {poll.votingMode === 'anonymous' ? (
                    <>
                      <Globe className="h-4 w-4" />
                      <span>Anonymous</span>
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4" />
                      <span>Sign-in required</span>
                    </>
                  )}
                </div>
                {poll.deadline && (
                  <div className={`flex items-center gap-1.5 ${isExpired ? 'text-destructive' : ''}`}>
                    <Clock className="h-4 w-4" />
                    <span>
                      {isExpired 
                        ? `Expired ${format(new Date(poll.deadline), 'MMM d')}`
                        : `Ends ${format(new Date(poll.deadline), 'MMM d, h:mm a')}`
                      }
                    </span>
                  </div>
                )}
              </div>
            </CardHeader>
          </Card>

          {/* Share Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Share2 className="h-5 w-5" />
                Share Your Poll
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <div className="flex-1 p-3 rounded-lg bg-muted font-mono text-sm truncate">
                  {shareUrl}
                </div>
                <Button 
                  variant="outline" 
                  onClick={handleCopyLink}
                  className="gap-2"
                >
                  <Copy className="h-4 w-4" />
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
                <Link to={`/poll/${poll.id}`} target="_blank">
                  <Button variant="ghost" size="icon">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Poll Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Poll Status</CardTitle>
              <CardDescription>
                Control whether your poll is accepting votes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3">
                {statusActions.map(({ status, icon: Icon, label }) => (
                  <button
                    key={status}
                    onClick={() => handleStatusChange(status)}
                    className={cn(
                      "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all",
                      poll.status === status
                        ? "border-primary bg-accent"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    <Icon className={cn(
                      "h-6 w-6",
                      poll.status === status ? "text-primary" : "text-muted-foreground"
                    )} />
                    <span className="font-medium text-sm">{label}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-3 text-center">
                {poll.status === 'active' && 'Poll is accepting votes'}
                {poll.status === 'closed' && 'Poll is closed, no new votes allowed'}
                {poll.status === 'readonly' && 'Results are visible but voting is disabled'}
              </p>
            </CardContent>
          </Card>

          {/* Results */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Results</CardTitle>
              <CardDescription>
                Live breakdown of all votes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PollResults poll={poll} animate={false} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
