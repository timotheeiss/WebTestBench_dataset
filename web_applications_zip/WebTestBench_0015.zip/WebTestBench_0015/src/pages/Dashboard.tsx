import { useState, useMemo } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Header } from '@/components/layout/Header';
import { PollCard } from '@/components/polls/PollCard';
import { usePolls } from '@/context/PollContext';
import { useAuth } from '@/context/AuthContext';
import { Plus, Search, SortAsc, LayoutGrid } from 'lucide-react';
import { PollStatus } from '@/types/poll';

type SortOption = 'newest' | 'oldest' | 'title' | 'votes';

export default function Dashboard() {
  const { getUserPolls } = usePolls();
  const { user, isAuthenticated } = useAuth();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<PollStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  const userPolls = getUserPolls(user.id);

  const filteredAndSortedPolls = useMemo(() => {
    let result = userPolls;

    // Filter by search
    if (search) {
      const searchLower = search.toLowerCase();
      result = result.filter(p => 
        p.title.toLowerCase().includes(searchLower) ||
        p.description.toLowerCase().includes(searchLower)
      );
    }

    // Filter by status
    if (statusFilter !== 'all') {
      result = result.filter(p => p.status === statusFilter);
    }

    // Sort
    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'oldest':
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        case 'title':
          return a.title.localeCompare(b.title);
        case 'votes':
          const aVotes = a.options.reduce((sum, opt) => sum + opt.votes, 0);
          const bVotes = b.options.reduce((sum, opt) => sum + opt.votes, 0);
          return bVotes - aVotes;
        default:
          return 0;
      }
    });

    return result;
  }, [userPolls, search, statusFilter, sortBy]);

  const statusCounts = useMemo(() => ({
    all: userPolls.length,
    active: userPolls.filter(p => p.status === 'active').length,
    closed: userPolls.filter(p => p.status === 'closed').length,
    readonly: userPolls.filter(p => p.status === 'readonly').length,
  }), [userPolls]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">
              My Polls
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage and track all your polls in one place
            </p>
          </div>
          <Link to="/create">
            <Button variant="hero" className="gap-2">
              <Plus className="h-4 w-4" />
              Create Poll
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search polls..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Status Filter */}
          <div className="flex gap-2 flex-wrap">
            {(['all', 'active', 'closed', 'readonly'] as const).map((status) => (
              <Button
                key={status}
                variant={statusFilter === status ? 'default' : 'outline'}
                size="sm"
                onClick={() => setStatusFilter(status)}
                className="capitalize"
              >
                {status} ({statusCounts[status]})
              </Button>
            ))}
          </div>

          {/* Sort */}
          <div className="flex items-center gap-2">
            <SortAsc className="h-4 w-4 text-muted-foreground" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="h-10 rounded-lg border-2 border-input bg-background px-3 text-sm focus:border-primary focus:outline-none"
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="title">Title A-Z</option>
              <option value="votes">Most votes</option>
            </select>
          </div>
        </div>

        {/* Poll Grid */}
        {filteredAndSortedPolls.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedPolls.map((poll, index) => (
              <div 
                key={poll.id}
                className="opacity-0 animate-slide-up"
                style={{ animationDelay: `${index * 0.05}s`, animationFillMode: 'forwards' }}
              >
                <PollCard poll={poll} showManage />
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-muted mb-4">
              <LayoutGrid className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-display text-xl font-semibold text-foreground mb-2">
              {search || statusFilter !== 'all' ? 'No polls found' : 'No polls yet'}
            </h3>
            <p className="text-muted-foreground mb-6 max-w-sm">
              {search || statusFilter !== 'all' 
                ? 'Try adjusting your filters or search terms'
                : 'Create your first poll to start gathering feedback from your audience.'
              }
            </p>
            {!search && statusFilter === 'all' && (
              <Link to="/create">
                <Button variant="default" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Create your first poll
                </Button>
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
