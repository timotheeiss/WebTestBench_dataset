import { Poll, User } from '@/types/poll';

export const defaultUsers: User[] = [
  {
    id: 'user-1',
    email: 'demo@pollwise.com',
    name: 'Demo User',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: 'user-2',
    email: 'alex@example.com',
    name: 'Alex Johnson',
    createdAt: new Date('2024-02-20'),
  },
];

export const defaultPolls: Poll[] = [
  {
    id: 'poll-1',
    title: 'Best Programming Language for Beginners?',
    description: 'Help us decide which programming language should be recommended for complete beginners starting their coding journey in 2024.',
    options: [
      { id: 'opt-1a', text: 'Python', votes: 45 },
      { id: 'opt-1b', text: 'JavaScript', votes: 32 },
      { id: 'opt-1c', text: 'Scratch', votes: 18 },
      { id: 'opt-1d', text: 'Java', votes: 12 },
    ],
    creatorId: 'user-1',
    createdAt: new Date('2024-11-01'),
    deadline: new Date('2024-12-31'),
    votingMode: 'anonymous',
    status: 'active',
    votes: [],
  },
  {
    id: 'poll-2',
    title: 'Team Lunch Preference',
    description: 'Vote for where we should go for our monthly team lunch this Friday!',
    options: [
      { id: 'opt-2a', text: 'Italian Restaurant', votes: 8 },
      { id: 'opt-2b', text: 'Sushi Bar', votes: 12 },
      { id: 'opt-2c', text: 'Mexican Grill', votes: 6 },
      { id: 'opt-2d', text: 'Burger Joint', votes: 4 },
    ],
    creatorId: 'user-1',
    createdAt: new Date('2024-12-08'),
    deadline: new Date('2024-12-13'),
    votingMode: 'authenticated',
    status: 'active',
    votes: [],
  },
  {
    id: 'poll-3',
    title: 'Favorite Remote Work Tool',
    description: 'What tool has been most essential for your remote work setup?',
    options: [
      { id: 'opt-3a', text: 'Slack', votes: 28 },
      { id: 'opt-3b', text: 'Zoom', votes: 22 },
      { id: 'opt-3c', text: 'Notion', votes: 35 },
      { id: 'opt-3d', text: 'Figma', votes: 15 },
    ],
    creatorId: 'user-2',
    createdAt: new Date('2024-10-15'),
    deadline: null,
    votingMode: 'anonymous',
    status: 'closed',
    votes: [],
  },
  {
    id: 'poll-4',
    title: 'Office Pet Policy',
    description: 'Should we allow pets in the office on Fridays?',
    options: [
      { id: 'opt-4a', text: 'Yes, all pets welcome!', votes: 42 },
      { id: 'opt-4b', text: 'Only dogs and cats', votes: 28 },
      { id: 'opt-4c', text: 'No pets please', votes: 15 },
    ],
    creatorId: 'user-1',
    createdAt: new Date('2024-11-20'),
    deadline: new Date('2024-11-30'),
    votingMode: 'authenticated',
    status: 'readonly',
    votes: [],
  },
];
