export type Difficulty = 'easy' | 'medium' | 'hard';
export type CardStatus = 'know' | 'dontKnow' | 'uncertain' | 'unseen';

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  tags: string[];
  difficulty: Difficulty;
  status: CardStatus;
  lastReviewed?: Date;
  reviewCount: number;
}

export interface CardSet {
  id: string;
  title: string;
  description: string;
  cards: Flashcard[];
  authorId: string;
  authorName: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
  ratings: Rating[];
  saves: number;
}

export interface Rating {
  id: string;
  userId: string;
  userName: string;
  clarity: number;
  accuracy: number;
  difficultyMatch: number;
  comment?: string;
  createdAt: Date;
}

export interface StudySession {
  setId: string;
  cardsReviewed: number;
  cardsKnown: number;
  cardsDontKnow: number;
  cardsUncertain: number;
  startedAt: Date;
  completedAt?: Date;
}

export interface UserProgress {
  totalCardsStudied: number;
  totalSetsCompleted: number;
  currentStreak: number;
  longestStreak: number;
  lastStudyDate?: Date;
}
