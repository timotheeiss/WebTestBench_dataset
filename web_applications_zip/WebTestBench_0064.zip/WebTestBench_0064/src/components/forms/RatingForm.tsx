import { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface RatingFormProps {
  onSubmit: (data: { clarity: number; accuracy: number; difficultyMatch: number; comment?: string }) => void;
  onCancel: () => void;
}

function StarRating({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  const [hover, setHover] = useState(0);

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            onMouseEnter={() => setHover(star)}
            onMouseLeave={() => setHover(0)}
            className="transition-transform hover:scale-110"
          >
            <Star
              className={cn(
                'h-7 w-7 transition-colors',
                (hover || value) >= star
                  ? 'fill-primary text-primary'
                  : 'text-muted-foreground/30'
              )}
            />
          </button>
        ))}
      </div>
    </div>
  );
}

export function RatingForm({ onSubmit, onCancel }: RatingFormProps) {
  const [clarity, setClarity] = useState(0);
  const [accuracy, setAccuracy] = useState(0);
  const [difficultyMatch, setDifficultyMatch] = useState(0);
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (clarity && accuracy && difficultyMatch) {
      onSubmit({ clarity, accuracy, difficultyMatch, comment: comment.trim() || undefined });
    }
  };

  const isValid = clarity > 0 && accuracy > 0 && difficultyMatch > 0;

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
      <StarRating value={clarity} onChange={setClarity} label="Clarity of questions and answers" />
      <StarRating value={accuracy} onChange={setAccuracy} label="Accuracy of information" />
      <StarRating value={difficultyMatch} onChange={setDifficultyMatch} label="Difficulty level matches content" />

      <div className="space-y-2">
        <Label htmlFor="comment">Comment (optional)</Label>
        <Textarea
          id="comment"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share your thoughts about this card set..."
          className="min-h-[80px] resize-none"
        />
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1" disabled={!isValid}>
          Submit Rating
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
