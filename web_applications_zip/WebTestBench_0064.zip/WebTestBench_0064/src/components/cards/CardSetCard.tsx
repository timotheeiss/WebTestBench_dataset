import { Link } from 'react-router-dom';
import { BookOpen, Star, Users, Clock, Play } from 'lucide-react';
import { CardSet } from '@/types/flashcard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface CardSetCardProps {
  cardSet: CardSet;
  showActions?: boolean;
}

export function CardSetCard({ cardSet, showActions = true }: CardSetCardProps) {
  const averageRating = cardSet.ratings.length > 0
    ? cardSet.ratings.reduce((sum, r) => sum + (r.clarity + r.accuracy + r.difficultyMatch) / 3, 0) / cardSet.ratings.length
    : 0;

  const getProgressStats = () => {
    const known = cardSet.cards.filter(c => c.status === 'know').length;
    const total = cardSet.cards.length;
    return { known, total, percentage: total > 0 ? Math.round((known / total) * 100) : 0 };
  };

  const progress = getProgressStats();

  return (
    <div className="group relative overflow-hidden rounded-xl border border-border bg-card p-6 shadow-soft transition-all duration-300 hover:shadow-card hover:-translate-y-1">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            {cardSet.isPublished ? (
              <Badge variant="secondary" className="text-xs">Published</Badge>
            ) : (
              <Badge variant="outline" className="text-xs">Draft</Badge>
            )}
            {averageRating > 0 && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Star className="h-3.5 w-3.5 fill-primary text-primary" />
                <span>{averageRating.toFixed(1)}</span>
              </div>
            )}
          </div>

          <Link to={`/set/${cardSet.id}`}>
            <h3 className="font-display text-xl font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">
              {cardSet.title}
            </h3>
          </Link>

          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
            {cardSet.description}
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <BookOpen className="h-4 w-4" />
              <span>{cardSet.cards.length} cards</span>
            </div>
            {cardSet.saves > 0 && (
              <div className="flex items-center gap-1.5">
                <Users className="h-4 w-4" />
                <span>{cardSet.saves} saves</span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>by {cardSet.authorName}</span>
            </div>
          </div>

          {cardSet.authorId === 'current-user' && progress.total > 0 && (
            <div className="mt-4">
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium text-foreground">{progress.percentage}%</span>
              </div>
              <div className="h-2 w-full rounded-full bg-secondary overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${progress.percentage}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {showActions && (
        <div className="mt-6 flex items-center gap-2">
          <Link to={`/study/${cardSet.id}`} className="flex-1">
            <Button className="w-full gap-2">
              <Play className="h-4 w-4" />
              Study
            </Button>
          </Link>
          <Link to={`/set/${cardSet.id}`}>
            <Button variant="outline">View</Button>
          </Link>
        </div>
      )}
    </div>
  );
}
