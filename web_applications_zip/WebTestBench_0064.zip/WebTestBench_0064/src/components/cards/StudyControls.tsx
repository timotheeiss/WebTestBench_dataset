import { Check, X, HelpCircle, ArrowRight, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CardStatus } from '@/types/flashcard';

interface StudyControlsProps {
  onStatusChange: (status: CardStatus) => void;
  onNext: () => void;
  onReset: () => void;
  currentIndex: number;
  totalCards: number;
  isComplete: boolean;
}

export function StudyControls({
  onStatusChange,
  onNext,
  onReset,
  currentIndex,
  totalCards,
  isComplete,
}: StudyControlsProps) {
  if (isComplete) {
    return (
      <div className="flex flex-col items-center gap-4 mt-8 animate-fade-in">
        <p className="text-xl font-display text-foreground">Study session complete!</p>
        <Button onClick={onReset} size="lg" className="gap-2">
          <RotateCcw className="h-4 w-4" />
          Study Again
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 mt-8">
      {/* Progress indicator */}
      <div className="flex items-center justify-center gap-2">
        <span className="text-sm text-muted-foreground">
          Card {currentIndex + 1} of {totalCards}
        </span>
      </div>

      {/* Status buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <Button
          variant="destructive"
          size="lg"
          className="w-full sm:w-auto gap-2"
          onClick={() => {
            onStatusChange('dontKnow');
            onNext();
          }}
        >
          <X className="h-5 w-5" />
          Don't Know
        </Button>

        <Button
          variant="uncertain"
          size="lg"
          className="w-full sm:w-auto gap-2"
          onClick={() => {
            onStatusChange('uncertain');
            onNext();
          }}
        >
          <HelpCircle className="h-5 w-5" />
          Uncertain
        </Button>

        <Button
          variant="success"
          size="lg"
          className="w-full sm:w-auto gap-2"
          onClick={() => {
            onStatusChange('know');
            onNext();
          }}
        >
          <Check className="h-5 w-5" />
          I Know It
        </Button>
      </div>

      {/* Skip button */}
      <div className="flex justify-center">
        <Button variant="ghost" onClick={onNext} className="gap-2">
          Skip for now
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
