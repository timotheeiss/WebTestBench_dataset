import { Flame, BookOpen, Award, TrendingUp } from 'lucide-react';
import { UserProgress } from '@/types/flashcard';

interface ProgressStatsProps {
  progress: UserProgress;
}

export function ProgressStats({ progress }: ProgressStatsProps) {
  const stats = [
    {
      label: 'Current Streak',
      value: `${progress.currentStreak} days`,
      icon: Flame,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      label: 'Cards Studied',
      value: progress.totalCardsStudied.toString(),
      icon: BookOpen,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
    {
      label: 'Sets Completed',
      value: progress.totalSetsCompleted.toString(),
      icon: Award,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
    {
      label: 'Best Streak',
      value: `${progress.longestStreak} days`,
      icon: TrendingUp,
      color: 'text-uncertain',
      bgColor: 'bg-uncertain/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map(({ label, value, icon: Icon, color, bgColor }) => (
        <div
          key={label}
          className="relative overflow-hidden rounded-xl border border-border bg-card p-5 shadow-soft"
        >
          <div className={`absolute top-4 right-4 h-10 w-10 rounded-lg ${bgColor} flex items-center justify-center`}>
            <Icon className={`h-5 w-5 ${color}`} />
          </div>
          <div className="pr-12">
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="font-display text-2xl font-bold text-foreground mt-1">{value}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
