import { useState } from 'react';
import { Flashcard } from '@/types/flashcard';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface FlashcardDisplayProps {
  card: Flashcard;
  isFlipped: boolean;
  onFlip: () => void;
}

const difficultyColors = {
  easy: 'bg-success/10 text-success border-success/20',
  medium: 'bg-warning/10 text-warning border-warning/20',
  hard: 'bg-destructive/10 text-destructive border-destructive/20',
};

export function FlashcardDisplay({ card, isFlipped, onFlip }: FlashcardDisplayProps) {
  return (
    <div
      className="card-flip w-full max-w-2xl mx-auto cursor-pointer"
      style={{ height: '400px' }}
      onClick={onFlip}
    >
      <div className={cn('card-flip-inner w-full h-full relative', isFlipped && 'flipped')}>
        {/* Front - Question */}
        <div className="card-face absolute inset-0 w-full h-full rounded-2xl border border-border bg-card shadow-card p-8 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <Badge variant="outline" className={cn('capitalize', difficultyColors[card.difficulty])}>
              {card.difficulty}
            </Badge>
            <span className="text-sm text-muted-foreground">Click to flip</span>
          </div>
          
          <div className="flex-1 flex items-center justify-center">
            <p className="font-display text-2xl md:text-3xl text-center text-foreground leading-relaxed">
              {card.question}
            </p>
          </div>

          <div className="flex flex-wrap gap-2 mt-6">
            {card.tags.map(tag => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        </div>

        {/* Back - Answer */}
        <div className="card-face card-back absolute inset-0 w-full h-full rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10 shadow-card p-8 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <span className="text-sm font-medium text-primary">Answer</span>
            <span className="text-sm text-muted-foreground">Click to flip back</span>
          </div>

          <div className="flex-1 flex items-center justify-center">
            <p className="text-xl md:text-2xl text-center text-foreground leading-relaxed">
              {card.answer}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
