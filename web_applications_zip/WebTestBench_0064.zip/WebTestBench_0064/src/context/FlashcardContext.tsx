import React, { createContext, useContext, useState, useCallback } from 'react';
import { CardSet, Flashcard, CardStatus, UserProgress, Rating, Difficulty } from '@/types/flashcard';
import { mockCardSets, mockUserProgress } from '@/data/mockData';

interface FlashcardContextType {
  cardSets: CardSet[];
  userProgress: UserProgress;
  createCardSet: (title: string, description: string) => CardSet;
  updateCardSet: (setId: string, updates: Partial<CardSet>) => void;
  deleteCardSet: (setId: string) => void;
  addCard: (setId: string, card: Omit<Flashcard, 'id' | 'status' | 'reviewCount'>) => void;
  updateCard: (setId: string, cardId: string, updates: Partial<Flashcard>) => void;
  deleteCard: (setId: string, cardId: string) => void;
  updateCardStatus: (setId: string, cardId: string, status: CardStatus) => void;
  publishSet: (setId: string) => void;
  unpublishSet: (setId: string) => void;
  saveSet: (setId: string) => void;
  addRating: (setId: string, rating: Omit<Rating, 'id' | 'createdAt'>) => void;
  getPublishedSets: () => CardSet[];
  getMySets: () => CardSet[];
  getSavedSets: () => CardSet[];
  getSetById: (id: string) => CardSet | undefined;
  getCardsToReview: (setId: string) => Flashcard[];
}

const FlashcardContext = createContext<FlashcardContextType | undefined>(undefined);

export function FlashcardProvider({ children }: { children: React.ReactNode }) {
  const [cardSets, setCardSets] = useState<CardSet[]>(mockCardSets);
  const [userProgress, setUserProgress] = useState<UserProgress>(mockUserProgress);
  const [savedSetIds, setSavedSetIds] = useState<string[]>([]);

  const createCardSet = useCallback((title: string, description: string): CardSet => {
    const newSet: CardSet = {
      id: `set-${Date.now()}`,
      title,
      description,
      cards: [],
      authorId: 'current-user',
      authorName: 'You',
      isPublished: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      ratings: [],
      saves: 0,
    };
    setCardSets(prev => [...prev, newSet]);
    return newSet;
  }, []);

  const updateCardSet = useCallback((setId: string, updates: Partial<CardSet>) => {
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId ? { ...set, ...updates, updatedAt: new Date() } : set
      )
    );
  }, []);

  const deleteCardSet = useCallback((setId: string) => {
    setCardSets(prev => prev.filter(set => set.id !== setId));
  }, []);

  const addCard = useCallback((setId: string, card: Omit<Flashcard, 'id' | 'status' | 'reviewCount'>) => {
    const newCard: Flashcard = {
      ...card,
      id: `card-${Date.now()}`,
      status: 'unseen',
      reviewCount: 0,
    };
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId
          ? { ...set, cards: [...set.cards, newCard], updatedAt: new Date() }
          : set
      )
    );
  }, []);

  const updateCard = useCallback((setId: string, cardId: string, updates: Partial<Flashcard>) => {
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId
          ? {
              ...set,
              cards: set.cards.map(card =>
                card.id === cardId ? { ...card, ...updates } : card
              ),
              updatedAt: new Date(),
            }
          : set
      )
    );
  }, []);

  const deleteCard = useCallback((setId: string, cardId: string) => {
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId
          ? { ...set, cards: set.cards.filter(c => c.id !== cardId), updatedAt: new Date() }
          : set
      )
    );
  }, []);

  const updateCardStatus = useCallback((setId: string, cardId: string, status: CardStatus) => {
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId
          ? {
              ...set,
              cards: set.cards.map(card =>
                card.id === cardId
                  ? { ...card, status, lastReviewed: new Date(), reviewCount: card.reviewCount + 1 }
                  : card
              ),
            }
          : set
      )
    );
    setUserProgress(prev => ({
      ...prev,
      totalCardsStudied: prev.totalCardsStudied + 1,
      lastStudyDate: new Date(),
    }));
  }, []);

  const publishSet = useCallback((setId: string) => {
    updateCardSet(setId, { isPublished: true });
  }, [updateCardSet]);

  const unpublishSet = useCallback((setId: string) => {
    updateCardSet(setId, { isPublished: false });
  }, [updateCardSet]);

  const saveSet = useCallback((setId: string) => {
    if (!savedSetIds.includes(setId)) {
      setSavedSetIds(prev => [...prev, setId]);
      setCardSets(prev =>
        prev.map(set =>
          set.id === setId ? { ...set, saves: set.saves + 1 } : set
        )
      );
    }
  }, [savedSetIds]);

  const addRating = useCallback((setId: string, rating: Omit<Rating, 'id' | 'createdAt'>) => {
    const newRating: Rating = {
      ...rating,
      id: `rating-${Date.now()}`,
      createdAt: new Date(),
    };
    setCardSets(prev =>
      prev.map(set =>
        set.id === setId
          ? { ...set, ratings: [...set.ratings, newRating] }
          : set
      )
    );
  }, []);

  const getPublishedSets = useCallback(() => {
    return cardSets.filter(set => set.isPublished && set.authorId !== 'current-user');
  }, [cardSets]);

  const getMySets = useCallback(() => {
    return cardSets.filter(set => set.authorId === 'current-user');
  }, [cardSets]);

  const getSavedSets = useCallback(() => {
    return cardSets.filter(set => savedSetIds.includes(set.id));
  }, [cardSets, savedSetIds]);

  const getSetById = useCallback((id: string) => {
    return cardSets.find(set => set.id === id);
  }, [cardSets]);

  const getCardsToReview = useCallback((setId: string): Flashcard[] => {
    const set = cardSets.find(s => s.id === setId);
    if (!set) return [];
    
    // Prioritize: don't know > uncertain > unseen > know
    const priorityOrder: CardStatus[] = ['dontKnow', 'uncertain', 'unseen', 'know'];
    return [...set.cards].sort((a, b) => {
      return priorityOrder.indexOf(a.status) - priorityOrder.indexOf(b.status);
    });
  }, [cardSets]);

  return (
    <FlashcardContext.Provider
      value={{
        cardSets,
        userProgress,
        createCardSet,
        updateCardSet,
        deleteCardSet,
        addCard,
        updateCard,
        deleteCard,
        updateCardStatus,
        publishSet,
        unpublishSet,
        saveSet,
        addRating,
        getPublishedSets,
        getMySets,
        getSavedSets,
        getSetById,
        getCardsToReview,
      }}
    >
      {children}
    </FlashcardContext.Provider>
  );
}

export function useFlashcards() {
  const context = useContext(FlashcardContext);
  if (context === undefined) {
    throw new Error('useFlashcards must be used within a FlashcardProvider');
  }
  return context;
}
