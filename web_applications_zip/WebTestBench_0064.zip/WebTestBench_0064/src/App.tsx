import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FlashcardProvider } from "@/context/FlashcardContext";
import Index from "./pages/Index";
import MySets from "./pages/MySets";
import Browse from "./pages/Browse";
import CreateSet from "./pages/CreateSet";
import SetDetail from "./pages/SetDetail";
import Study from "./pages/Study";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <FlashcardProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/my-sets" element={<MySets />} />
            <Route path="/browse" element={<Browse />} />
            <Route path="/create" element={<CreateSet />} />
            <Route path="/set/:id" element={<SetDetail />} />
            <Route path="/study/:id" element={<Study />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </FlashcardProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
