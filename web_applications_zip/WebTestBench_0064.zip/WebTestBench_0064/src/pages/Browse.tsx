import { useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CardSetCard } from '@/components/cards/CardSetCard';
import { Badge } from '@/components/ui/badge';
import { useFlashcards } from '@/context/FlashcardContext';

const categories = ['All', 'Programming', 'Languages', 'Science', 'History', 'Math'];

export default function Browse() {
  const { getPublishedSets } = useFlashcards();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const publishedSets = getPublishedSets();

  const filteredSets = publishedSets.filter(set => {
    const matchesSearch = set.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      set.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  return (
    <Layout>
      <div className="mb-8 animate-fade-in">
        <h1 className="font-display text-3xl font-bold text-foreground">Browse Card Sets</h1>
        <p className="text-muted-foreground mt-1">Discover and save flashcard sets created by the community</p>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search card sets..."
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </Button>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2 mb-8 animate-fade-in" style={{ animationDelay: '0.15s' }}>
        {categories.map(category => (
          <Badge
            key={category}
            variant={selectedCategory === category ? 'default' : 'secondary'}
            className="cursor-pointer px-4 py-1.5 text-sm transition-colors hover:bg-primary/80"
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </Badge>
        ))}
      </div>

      {/* Results */}
      {filteredSets.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          {filteredSets.map(set => (
            <CardSetCard key={set.id} cardSet={set} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 animate-fade-in">
          <p className="text-muted-foreground">No card sets found matching your search.</p>
        </div>
      )}
    </Layout>
  );
}
