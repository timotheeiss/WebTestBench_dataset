import { useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FlashcardDisplay } from '@/components/cards/FlashcardDisplay';
import { StudyControls } from '@/components/cards/StudyControls';
import { useFlashcards } from '@/context/FlashcardContext';
import { CardStatus } from '@/types/flashcard';
import { Progress } from '@/components/ui/progress';

export default function Study() {
  const { id } = useParams<{ id: string }>();
  const { getSetById, getCardsToReview, updateCardStatus } = useFlashcards();
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [sessionStats, setSessionStats] = useState({ know: 0, dontKnow: 0, uncertain: 0 });

  const cardSet = getSetById(id!);
  const cards = cardSet ? getCardsToReview(id!) : [];

  const handleStatusChange = useCallback((status: CardStatus) => {
    if (cards[currentIndex]) {
      updateCardStatus(id!, cards[currentIndex].id, status);
      setSessionStats(prev => ({
        ...prev,
        [status === 'know' ? 'know' : status === 'dontKnow' ? 'dontKnow' : 'uncertain']: 
          prev[status === 'know' ? 'know' : status === 'dontKnow' ? 'dontKnow' : 'uncertain'] + 1,
      }));
    }
  }, [cards, currentIndex, id, updateCardStatus]);

  const handleNext = useCallback(() => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex(prev => prev + 1);
    }, 100);
  }, []);

  const handleReset = useCallback(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setSessionStats({ know: 0, dontKnow: 0, uncertain: 0 });
  }, []);

  const handleFlip = useCallback(() => {
    setIsFlipped(prev => !prev);
  }, []);

  if (!cardSet) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Card set not found.</p>
          <Link to="/">
            <Button>Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">No cards to study in this set.</p>
          <Link to={`/set/${id}`}>
            <Button>Go Back</Button>
          </Link>
        </div>
      </div>
    );
  }

  const isComplete = currentIndex >= cards.length;
  const progress = (currentIndex / cards.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={`/set/${id}`}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-display font-semibold text-foreground line-clamp-1">{cardSet.title}</h1>
              <p className="text-sm text-muted-foreground">Study Session</p>
            </div>
          </div>
          <Link to={`/set/${id}`}>
            <Button variant="ghost" size="icon">
              <X className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="sticky top-16 z-40 bg-background/80 backdrop-blur-md py-3 border-b border-border">
        <div className="container">
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      {/* Main Content */}
      <main className="container py-8 flex flex-col items-center">
        {isComplete ? (
          <div className="text-center py-16 animate-fade-in">
            <div className="w-24 h-24 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">🎉</span>
            </div>
            <h2 className="font-display text-3xl font-bold text-foreground mb-4">Session Complete!</h2>
            <p className="text-muted-foreground mb-8">Great job reviewing {cards.length} cards!</p>

            {/* Session Stats */}
            <div className="flex justify-center gap-8 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-success">{sessionStats.know}</div>
                <div className="text-sm text-muted-foreground">Knew</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-uncertain">{sessionStats.uncertain}</div>
                <div className="text-sm text-muted-foreground">Uncertain</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-destructive">{sessionStats.dontKnow}</div>
                <div className="text-sm text-muted-foreground">Need Review</div>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button size="lg" onClick={handleReset}>
                Study Again
              </Button>
              <Link to={`/set/${id}`}>
                <Button size="lg" variant="outline">
                  Back to Set
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-2xl animate-fade-in">
            <FlashcardDisplay
              card={cards[currentIndex]}
              isFlipped={isFlipped}
              onFlip={handleFlip}
            />
            <StudyControls
              onStatusChange={handleStatusChange}
              onNext={handleNext}
              onReset={handleReset}
              currentIndex={currentIndex}
              totalCards={cards.length}
              isComplete={isComplete}
            />
          </div>
        )}
      </main>
    </div>
  );
}
