import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { CardForm } from '@/components/forms/CardForm';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useFlashcards } from '@/context/FlashcardContext';
import { Difficulty, Flashcard } from '@/types/flashcard';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const difficultyColors = {
  easy: 'bg-success/10 text-success border-success/20',
  medium: 'bg-warning/10 text-warning border-warning/20',
  hard: 'bg-destructive/10 text-destructive border-destructive/20',
};

export default function CreateSet() {
  const navigate = useNavigate();
  const { createCardSet, addCard } = useFlashcards();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [cards, setCards] = useState<Omit<Flashcard, 'id' | 'status' | 'reviewCount' | 'lastReviewed'>[]>([]);
  const [showCardForm, setShowCardForm] = useState(false);

  const handleAddCard = (cardData: { question: string; answer: string; tags: string[]; difficulty: Difficulty }) => {
    setCards([...cards, cardData]);
    setShowCardForm(false);
    toast({ title: 'Card added', description: 'Your flashcard has been added to the set.' });
  };

  const handleRemoveCard = (index: number) => {
    setCards(cards.filter((_, i) => i !== index));
  };

  const handleCreateSet = () => {
    if (!title.trim()) {
      toast({ title: 'Title required', description: 'Please enter a title for your card set.', variant: 'destructive' });
      return;
    }

    if (cards.length === 0) {
      toast({ title: 'Cards required', description: 'Add at least one card to your set.', variant: 'destructive' });
      return;
    }

    const newSet = createCardSet(title, description);
    cards.forEach(card => addCard(newSet.id, card));
    
    toast({ title: 'Set created!', description: 'Your flashcard set has been created successfully.' });
    navigate(`/set/${newSet.id}`);
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <div className="mb-8 animate-fade-in">
          <h1 className="font-display text-3xl font-bold text-foreground">Create New Card Set</h1>
          <p className="text-muted-foreground mt-1">Build your flashcard collection for effective learning</p>
        </div>

        <div className="space-y-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          {/* Set Details */}
          <div className="rounded-xl border border-border bg-card p-6 shadow-soft space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Set Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., JavaScript Fundamentals"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What will learners master with this set?"
                className="resize-none"
              />
            </div>
          </div>

          {/* Cards List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold text-foreground">
                Cards ({cards.length})
              </h2>
              <Dialog open={showCardForm} onOpenChange={setShowCardForm}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Card
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add New Card</DialogTitle>
                  </DialogHeader>
                  <CardForm onSubmit={handleAddCard} onCancel={() => setShowCardForm(false)} />
                </DialogContent>
              </Dialog>
            </div>

            {cards.length > 0 ? (
              <div className="space-y-3">
                {cards.map((card, index) => (
                  <div
                    key={index}
                    className="group rounded-xl border border-border bg-card p-4 shadow-soft hover:shadow-card transition-shadow"
                  >
                    <div className="flex items-start gap-3">
                      <div className="text-muted-foreground/50 cursor-grab">
                        <GripVertical className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className={cn('text-xs capitalize', difficultyColors[card.difficulty])}>
                            {card.difficulty}
                          </Badge>
                          {card.tags.slice(0, 2).map(tag => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <p className="font-medium text-foreground line-clamp-1">{card.question}</p>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{card.answer}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                        onClick={() => handleRemoveCard(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 rounded-xl border border-dashed border-border">
                <p className="text-muted-foreground">No cards yet. Add your first flashcard above.</p>
              </div>
            )}
          </div>

          {/* Create Button */}
          <div className="flex gap-4 pt-4">
            <Button size="lg" className="flex-1" onClick={handleCreateSet}>
              Create Card Set
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
