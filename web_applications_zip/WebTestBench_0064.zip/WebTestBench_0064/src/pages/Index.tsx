import { Link } from 'react-router-dom';
import { Plus, ArrowRight, Sparkles, BookOpen, Users } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { CardSetCard } from '@/components/cards/CardSetCard';
import { ProgressStats } from '@/components/cards/ProgressStats';
import { useFlashcards } from '@/context/FlashcardContext';

const Index = () => {
  const { getMySets, getPublishedSets, userProgress } = useFlashcards();
  const mySets = getMySets();
  const publishedSets = getPublishedSets().slice(0, 3);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/10 via-primary/5 to-accent/10 p-8 md:p-12 mb-12 animate-fade-in">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        
        <div className="relative">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-primary">Welcome back!</span>
          </div>
          
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
            Master anything with<br />
            <span className="text-primary">smart flashcards</span>
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-xl mb-8">
            Create, study, and share flashcards. Track your progress and learn efficiently with spaced repetition.
          </p>

          <div className="flex flex-wrap gap-4">
            <Link to="/create">
              <Button size="xl" className="gap-2 shadow-elevated">
                <Plus className="h-5 w-5" />
                Create New Set
              </Button>
            </Link>
            <Link to="/browse">
              <Button size="xl" variant="outline" className="gap-2">
                Browse Community
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Progress Stats */}
      <section className="mb-12 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Your Progress</h2>
        <ProgressStats progress={userProgress} />
      </section>

      {/* My Sets */}
      <section className="mb-12 animate-fade-in" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-semibold text-foreground">My Card Sets</h2>
          </div>
          <Link to="/my-sets">
            <Button variant="ghost" className="gap-2">
              View All
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        {mySets.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mySets.slice(0, 3).map(set => (
              <CardSetCard key={set.id} cardSet={set} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 rounded-xl border border-dashed border-border">
            <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">You haven't created any card sets yet.</p>
            <Link to="/create">
              <Button>Create Your First Set</Button>
            </Link>
          </div>
        )}
      </section>

      {/* Community Sets */}
      <section className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <Users className="h-5 w-5 text-accent" />
            </div>
            <h2 className="font-display text-2xl font-semibold text-foreground">From the Community</h2>
          </div>
          <Link to="/browse">
            <Button variant="ghost" className="gap-2">
              Browse All
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {publishedSets.map(set => (
            <CardSetCard key={set.id} cardSet={set} />
          ))}
        </div>
      </section>
    </Layout>
  );
};

export default Index;
