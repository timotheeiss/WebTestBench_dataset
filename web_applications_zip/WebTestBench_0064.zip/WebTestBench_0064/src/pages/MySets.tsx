import { Link } from 'react-router-dom';
import { Plus, BookOpen } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { CardSetCard } from '@/components/cards/CardSetCard';
import { useFlashcards } from '@/context/FlashcardContext';

export default function MySets() {
  const { getMySets } = useFlashcards();
  const mySets = getMySets();

  return (
    <Layout>
      <div className="flex items-center justify-between mb-8 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">My Card Sets</h1>
          <p className="text-muted-foreground mt-1">Manage and study your personal flashcard collections</p>
        </div>
        <Link to="/create">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            New Set
          </Button>
        </Link>
      </div>

      {mySets.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          {mySets.map(set => (
            <CardSetCard key={set.id} cardSet={set} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 rounded-xl border border-dashed border-border animate-fade-in">
          <BookOpen className="h-16 w-16 text-muted-foreground/50 mx-auto mb-6" />
          <h2 className="font-display text-xl font-semibold text-foreground mb-2">No card sets yet</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Create your first flashcard set to start learning. Add questions, answers, and organize by difficulty.
          </p>
          <Link to="/create">
            <Button size="lg" className="gap-2">
              <Plus className="h-5 w-5" />
              Create Your First Set
            </Button>
          </Link>
        </div>
      )}
    </Layout>
  );
}
