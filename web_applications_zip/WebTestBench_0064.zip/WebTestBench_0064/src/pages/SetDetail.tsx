import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Play, Edit, Trash2, Globe, Lock, Star, Plus, Bookmark, BookmarkCheck } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CardForm } from '@/components/forms/CardForm';
import { RatingForm } from '@/components/forms/RatingForm';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useFlashcards } from '@/context/FlashcardContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Difficulty } from '@/types/flashcard';

const difficultyColors = {
  easy: 'bg-success/10 text-success border-success/20',
  medium: 'bg-warning/10 text-warning border-warning/20',
  hard: 'bg-destructive/10 text-destructive border-destructive/20',
};

const statusColors = {
  know: 'bg-success text-success-foreground',
  dontKnow: 'bg-destructive text-destructive-foreground',
  uncertain: 'bg-uncertain text-uncertain-foreground',
  unseen: 'bg-muted text-muted-foreground',
};

export default function SetDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getSetById, addCard, deleteCard, publishSet, unpublishSet, deleteCardSet, saveSet, addRating, getSavedSets } = useFlashcards();
  
  const [showAddCard, setShowAddCard] = useState(false);
  const [showRatingForm, setShowRatingForm] = useState(false);

  const cardSet = getSetById(id!);
  const savedSets = getSavedSets();
  const isSaved = savedSets.some(s => s.id === id);

  if (!cardSet) {
    return (
      <Layout>
        <div className="text-center py-16">
          <p className="text-muted-foreground">Card set not found.</p>
          <Link to="/">
            <Button className="mt-4">Go Home</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const isOwner = cardSet.authorId === 'current-user';
  const averageRating = cardSet.ratings.length > 0
    ? cardSet.ratings.reduce((sum, r) => sum + (r.clarity + r.accuracy + r.difficultyMatch) / 3, 0) / cardSet.ratings.length
    : 0;

  const handleAddCard = (cardData: { question: string; answer: string; tags: string[]; difficulty: Difficulty }) => {
    addCard(cardSet.id, cardData);
    setShowAddCard(false);
    toast({ title: 'Card added!', description: 'Your flashcard has been added to the set.' });
  };

  const handleDeleteCard = (cardId: string) => {
    deleteCard(cardSet.id, cardId);
    toast({ title: 'Card deleted', description: 'The flashcard has been removed.' });
  };

  const handleTogglePublish = () => {
    if (cardSet.isPublished) {
      unpublishSet(cardSet.id);
      toast({ title: 'Set unpublished', description: 'Your card set is now private.' });
    } else {
      publishSet(cardSet.id);
      toast({ title: 'Set published!', description: 'Your card set is now visible to the community.' });
    }
  };

  const handleDeleteSet = () => {
    deleteCardSet(cardSet.id);
    toast({ title: 'Set deleted', description: 'Your card set has been removed.' });
    navigate('/my-sets');
  };

  const handleSave = () => {
    saveSet(cardSet.id);
    toast({ title: 'Set saved!', description: 'This card set has been added to your saved sets.' });
  };

  const handleAddRating = (data: { clarity: number; accuracy: number; difficultyMatch: number; comment?: string }) => {
    addRating(cardSet.id, {
      ...data,
      userId: 'current-user',
      userName: 'You',
    });
    setShowRatingForm(false);
    toast({ title: 'Rating submitted!', description: 'Thank you for your feedback.' });
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            {cardSet.isPublished ? (
              <Badge variant="secondary" className="gap-1">
                <Globe className="h-3 w-3" />
                Published
              </Badge>
            ) : (
              <Badge variant="outline" className="gap-1">
                <Lock className="h-3 w-3" />
                Private
              </Badge>
            )}
            {averageRating > 0 && (
              <div className="flex items-center gap-1 text-sm">
                <Star className="h-4 w-4 fill-primary text-primary" />
                <span className="font-medium">{averageRating.toFixed(1)}</span>
                <span className="text-muted-foreground">({cardSet.ratings.length} ratings)</span>
              </div>
            )}
          </div>

          <h1 className="font-display text-3xl font-bold text-foreground">{cardSet.title}</h1>
          <p className="text-muted-foreground mt-2">{cardSet.description}</p>
          <p className="text-sm text-muted-foreground mt-2">by {cardSet.authorName}</p>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-3 mb-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <Link to={`/study/${cardSet.id}`}>
            <Button size="lg" className="gap-2">
              <Play className="h-5 w-5" />
              Start Studying
            </Button>
          </Link>

          {isOwner ? (
            <>
              <Dialog open={showAddCard} onOpenChange={setShowAddCard}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Card
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add New Card</DialogTitle>
                  </DialogHeader>
                  <CardForm onSubmit={handleAddCard} onCancel={() => setShowAddCard(false)} />
                </DialogContent>
              </Dialog>

              <Button variant="outline" className="gap-2" onClick={handleTogglePublish}>
                {cardSet.isPublished ? <Lock className="h-4 w-4" /> : <Globe className="h-4 w-4" />}
                {cardSet.isPublished ? 'Unpublish' : 'Publish'}
              </Button>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="gap-2 text-destructive hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                    Delete Set
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete this card set?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. All cards in this set will be permanently deleted.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteSet} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          ) : (
            <>
              <Button variant="outline" className="gap-2" onClick={handleSave} disabled={isSaved}>
                {isSaved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                {isSaved ? 'Saved' : 'Save Set'}
              </Button>

              <Dialog open={showRatingForm} onOpenChange={setShowRatingForm}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Star className="h-4 w-4" />
                    Rate This Set
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Rate This Card Set</DialogTitle>
                  </DialogHeader>
                  <RatingForm onSubmit={handleAddRating} onCancel={() => setShowRatingForm(false)} />
                </DialogContent>
              </Dialog>
            </>
          )}
        </div>

        {/* Cards List */}
        <div className="space-y-4 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h2 className="font-display text-xl font-semibold text-foreground">
            Cards ({cardSet.cards.length})
          </h2>

          {cardSet.cards.length > 0 ? (
            <div className="space-y-3">
              {cardSet.cards.map((card, index) => (
                <div
                  key={card.id}
                  className="group rounded-xl border border-border bg-card p-5 shadow-soft hover:shadow-card transition-shadow"
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-secondary flex items-center justify-center text-sm font-medium text-secondary-foreground">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className={cn('text-xs capitalize', difficultyColors[card.difficulty])}>
                          {card.difficulty}
                        </Badge>
                        <Badge variant="secondary" className={cn('text-xs capitalize', statusColors[card.status])}>
                          {card.status === 'dontKnow' ? "Don't Know" : card.status === 'unseen' ? 'New' : card.status}
                        </Badge>
                        {card.tags.slice(0, 2).map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <p className="font-medium text-foreground">{card.question}</p>
                      <p className="text-sm text-muted-foreground mt-2">{card.answer}</p>
                    </div>
                    {isOwner && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                        onClick={() => handleDeleteCard(card.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 rounded-xl border border-dashed border-border">
              <p className="text-muted-foreground">No cards in this set yet.</p>
            </div>
          )}
        </div>

        {/* Ratings Section */}
        {cardSet.ratings.length > 0 && (
          <div className="mt-12 space-y-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <h2 className="font-display text-xl font-semibold text-foreground">
              Reviews ({cardSet.ratings.length})
            </h2>
            <div className="space-y-4">
              {cardSet.ratings.map(rating => (
                <div key={rating.id} className="rounded-xl border border-border bg-card p-5 shadow-soft">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-foreground">{rating.userName}</p>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span>Clarity: {rating.clarity}/5</span>
                        <span>Accuracy: {rating.accuracy}/5</span>
                        <span>Difficulty Match: {rating.difficultyMatch}/5</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-primary text-primary" />
                      <span className="font-medium">
                        {((rating.clarity + rating.accuracy + rating.difficultyMatch) / 3).toFixed(1)}
                      </span>
                    </div>
                  </div>
                  {rating.comment && (
                    <p className="mt-3 text-muted-foreground">{rating.comment}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
