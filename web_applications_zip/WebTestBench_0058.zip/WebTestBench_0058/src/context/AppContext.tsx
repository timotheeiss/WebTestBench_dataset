import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { MatchingRule, SearchInput, SearchHistoryEntry, MatchResult, ValidationError } from '@/types/matching';
import { mockRecords, Record } from '@/data/records';

interface AppState {
  // Search input state
  searchInput: SearchInput;
  setSearchInput: (input: SearchInput) => void;
  
  // Rules state
  rules: MatchingRule[];
  selectedRuleId: string | null;
  setSelectedRuleId: (id: string | null) => void;
  addRule: (rule: Omit<MatchingRule, 'id' | 'createdAt'>) => void;
  updateRule: (id: string, updates: Partial<MatchingRule>) => void;
  deleteRule: (id: string) => void;
  
  // Search results
  matchResults: MatchResult[];
  performSearch: () => { success: boolean; message?: string };
  
  // History
  searchHistory: SearchHistoryEntry[];
  addToHistory: (entry: Omit<SearchHistoryEntry, 'id' | 'timestamp'>) => void;
  clearHistory: () => void;
  
  // Marked records
  markedRecords: Set<string>;
  toggleMark: (recordId: string) => void;
  clearMarks: () => void;
  
  // Validation
  validationErrors: ValidationError[];
  validateInput: () => ValidationError[];
  
  // UI state
  hasUnsavedRule: boolean;
  setHasUnsavedRule: (value: boolean) => void;
  
  // Records
  records: Record[];
}

const defaultSearchInput: SearchInput = {
  name: '',
  address: '',
  email: '',
  phone: ''
};

const defaultRule: MatchingRule = {
  id: 'default',
  name: 'Default Rule',
  strategy: 'partial',
  fields: { name: true, address: true, email: true, phone: true },
  weights: { name: 25, address: 25, email: 25, phone: 25 },
  createdAt: new Date(),
  isActive: true
};

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [searchInput, setSearchInput] = useState<SearchInput>(defaultSearchInput);
  const [rules, setRules] = useState<MatchingRule[]>([defaultRule]);
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);
  const [matchResults, setMatchResults] = useState<MatchResult[]>([]);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryEntry[]>([]);
  const [markedRecords, setMarkedRecords] = useState<Set<string>>(new Set());
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [hasUnsavedRule, setHasUnsavedRule] = useState(false);

  const validateInput = useCallback((): ValidationError[] => {
    const errors: ValidationError[] = [];
    const specialCharsRegex = /[<>{}[\]\\|^~`]/;
    
    Object.entries(searchInput).forEach(([field, value]) => {
      if (specialCharsRegex.test(value)) {
        errors.push({
          field,
          message: `${field.charAt(0).toUpperCase() + field.slice(1)} contains special characters that may affect matching`,
          type: 'special_chars'
        });
      }
    });

    setValidationErrors(errors);
    return errors;
  }, [searchInput]);

  const calculateMatchScore = useCallback((record: Record, input: SearchInput, rule: MatchingRule): MatchResult => {
    let totalScore = 0;
    let totalWeight = 0;
    const fieldMatches = { name: false, address: false, email: false, phone: false };

    const matchField = (recordValue: string, inputValue: string, isExact: boolean): boolean => {
      if (!inputValue.trim()) return false;
      
      const normalizedRecord = recordValue.toLowerCase().trim();
      const normalizedInput = inputValue.toLowerCase().trim();
      
      if (isExact) {
        return normalizedRecord === normalizedInput;
      } else {
        return normalizedRecord.includes(normalizedInput) || normalizedInput.includes(normalizedRecord);
      }
    };

    const isExact = rule.strategy === 'exact';

    if (rule.fields.name && input.name) {
      fieldMatches.name = matchField(record.name, input.name, isExact);
      if (fieldMatches.name) totalScore += rule.weights.name;
      totalWeight += rule.weights.name;
    }

    if (rule.fields.address && input.address) {
      fieldMatches.address = matchField(record.address, input.address, isExact);
      if (fieldMatches.address) totalScore += rule.weights.address;
      totalWeight += rule.weights.address;
    }

    if (rule.fields.email && input.email) {
      fieldMatches.email = matchField(record.email, input.email, isExact);
      if (fieldMatches.email) totalScore += rule.weights.email;
      totalWeight += rule.weights.email;
    }

    if (rule.fields.phone && input.phone) {
      fieldMatches.phone = matchField(record.phone, input.phone, isExact);
      if (fieldMatches.phone) totalScore += rule.weights.phone;
      totalWeight += rule.weights.phone;
    }

    const score = totalWeight > 0 ? Math.round((totalScore / totalWeight) * 100) : 0;

    return {
      recordId: record.id,
      score,
      fieldMatches,
      isMarked: markedRecords.has(record.id)
    };
  }, [markedRecords]);

  const performSearch = useCallback((): { success: boolean; message?: string } => {
    // Check sequence: must have a saved rule selected
    if (!selectedRuleId) {
      return { 
        success: false, 
        message: 'Please select a matching rule before searching. Go to "Matching Rule Settings" to create and save a rule first.' 
      };
    }

    const rule = rules.find(r => r.id === selectedRuleId);
    if (!rule) {
      return { 
        success: false, 
        message: 'Selected rule not found. Please select a valid rule.' 
      };
    }

    if (hasUnsavedRule) {
      return {
        success: false,
        message: 'You have unsaved rule changes. Please save your rule in "Matching Rule Settings" before searching.'
      };
    }

    // Validate input
    const errors = validateInput();
    if (errors.length > 0) {
      // Continue but with warning - don't block the search
    }

    // Check if any search field has input
    const hasInput = Object.values(searchInput).some(v => v.trim() !== '');
    if (!hasInput) {
      return {
        success: false,
        message: 'Please enter at least one search field.'
      };
    }

    // Perform matching
    const results = mockRecords
      .map(record => calculateMatchScore(record, searchInput, rule))
      .filter(result => result.score > 0)
      .sort((a, b) => b.score - a.score);

    setMatchResults(results);

    // Add to history
    addToHistory({
      input: { ...searchInput },
      ruleId: rule.id,
      ruleName: rule.name,
      resultCount: results.length,
      markedRecords: Array.from(markedRecords)
    });

    return { success: true };
  }, [selectedRuleId, rules, hasUnsavedRule, searchInput, validateInput, calculateMatchScore, markedRecords]);

  const addRule = useCallback((rule: Omit<MatchingRule, 'id' | 'createdAt'>) => {
    // Check for conflicts
    const existingWithSameName = rules.find(r => r.name.toLowerCase() === rule.name.toLowerCase());
    if (existingWithSameName) {
      return { success: false, message: 'A rule with this name already exists.' };
    }

    const newRule: MatchingRule = {
      ...rule,
      id: `rule-${Date.now()}`,
      createdAt: new Date()
    };
    setRules(prev => [...prev, newRule]);
    setHasUnsavedRule(false);
    return { success: true, rule: newRule };
  }, [rules]);

  const updateRule = useCallback((id: string, updates: Partial<MatchingRule>) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));
  }, []);

  const deleteRule = useCallback((id: string) => {
    if (id === 'default') return;
    setRules(prev => prev.filter(r => r.id !== id));
    if (selectedRuleId === id) {
      setSelectedRuleId(null);
    }
  }, [selectedRuleId]);

  const addToHistory = useCallback((entry: Omit<SearchHistoryEntry, 'id' | 'timestamp'>) => {
    const newEntry: SearchHistoryEntry = {
      ...entry,
      id: `history-${Date.now()}`,
      timestamp: new Date()
    };
    setSearchHistory(prev => [newEntry, ...prev].slice(0, 50)); // Keep last 50
  }, []);

  const clearHistory = useCallback(() => {
    setSearchHistory([]);
  }, []);

  const toggleMark = useCallback((recordId: string) => {
    setMarkedRecords(prev => {
      const next = new Set(prev);
      if (next.has(recordId)) {
        next.delete(recordId);
      } else {
        next.add(recordId);
      }
      return next;
    });
    
    // Update match results to reflect marking
    setMatchResults(prev => prev.map(r => ({
      ...r,
      isMarked: r.recordId === recordId ? !r.isMarked : r.isMarked
    })));
  }, []);

  const clearMarks = useCallback(() => {
    setMarkedRecords(new Set());
    setMatchResults(prev => prev.map(r => ({ ...r, isMarked: false })));
  }, []);

  const value: AppState = {
    searchInput,
    setSearchInput,
    rules,
    selectedRuleId,
    setSelectedRuleId,
    addRule,
    updateRule,
    deleteRule,
    matchResults,
    performSearch,
    searchHistory,
    addToHistory,
    clearHistory,
    markedRecords,
    toggleMark,
    clearMarks,
    validationErrors,
    validateInput,
    hasUnsavedRule,
    setHasUnsavedRule,
    records: mockRecords
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
