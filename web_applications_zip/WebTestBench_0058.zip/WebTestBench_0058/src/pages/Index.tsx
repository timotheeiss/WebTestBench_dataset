import React, { useState } from 'react';
import { Search, History, Settings } from 'lucide-react';
import { AppProvider } from '@/context/AppContext';
import { SearchTab } from '@/components/SearchTab';
import { HistoryTab } from '@/components/HistoryTab';
import { RulesTab } from '@/components/RulesTab';

type TabId = 'search' | 'history' | 'rules';

interface Tab {
  id: TabId;
  label: string;
  icon: React.ReactNode;
}

const tabs: Tab[] = [
  { id: 'search', label: 'Input & Search', icon: <Search className="h-4 w-4" /> },
  { id: 'history', label: 'History Records', icon: <History className="h-4 w-4" /> },
  { id: 'rules', label: 'Matching Rule Settings', icon: <Settings className="h-4 w-4" /> }
];

function RecordMatcher() {
  const [activeTab, setActiveTab] = useState<TabId>('search');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container max-w-6xl py-6">
          <h1 className="text-2xl font-semibold text-foreground">Record Matcher</h1>
          <p className="text-muted-foreground mt-1">
            Search and match records using configurable matching rules
          </p>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="border-b bg-card sticky top-0 z-10">
        <div className="container max-w-6xl">
          <div className="flex gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id ? 'tab-active' : 'tab-inactive'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="container max-w-6xl py-6">
        {activeTab === 'search' && <SearchTab />}
        {activeTab === 'history' && <HistoryTab />}
        {activeTab === 'rules' && <RulesTab />}
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-auto">
        <div className="container max-w-6xl text-center text-sm text-muted-foreground">
          Records are stored in-memory • {new Date().getFullYear()}
        </div>
      </footer>
    </div>
  );
}

const Index = () => {
  return (
    <AppProvider>
      <RecordMatcher />
    </AppProvider>
  );
};

export default Index;
