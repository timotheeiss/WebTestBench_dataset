export type MatchStrategy = 'exact' | 'partial';

export interface MatchingRule {
  id: string;
  name: string;
  strategy: MatchStrategy;
  fields: {
    name: boolean;
    address: boolean;
    email: boolean;
    phone: boolean;
  };
  weights: {
    name: number;
    address: number;
    email: number;
    phone: number;
  };
  createdAt: Date;
  isActive: boolean;
}

export interface SearchInput {
  name: string;
  address: string;
  email: string;
  phone: string;
}

export interface MatchResult {
  recordId: string;
  score: number;
  fieldMatches: {
    name: boolean;
    address: boolean;
    email: boolean;
    phone: boolean;
  };
  isMarked: boolean;
}

export interface SearchHistoryEntry {
  id: string;
  input: SearchInput;
  ruleId: string;
  ruleName: string;
  resultCount: number;
  timestamp: Date;
  markedRecords: string[];
}

export interface ValidationError {
  field: string;
  message: string;
  type: 'special_chars' | 'empty' | 'format';
}
