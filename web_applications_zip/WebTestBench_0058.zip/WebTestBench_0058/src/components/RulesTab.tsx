import React, { useState, useEffect } from 'react';
import { Settings, Plus, Trash2, Check, AlertTriangle, Info } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useApp } from '@/context/AppContext';
import { MatchingRule, MatchStrategy } from '@/types/matching';

interface RuleFormState {
  name: string;
  strategy: MatchStrategy;
  fields: {
    name: boolean;
    address: boolean;
    email: boolean;
    phone: boolean;
  };
  weights: {
    name: number;
    address: number;
    email: number;
    phone: number;
  };
}

const defaultFormState: RuleFormState = {
  name: '',
  strategy: 'partial',
  fields: { name: true, address: true, email: true, phone: true },
  weights: { name: 25, address: 25, email: 25, phone: 25 }
};

export function RulesTab() {
  const {
    rules,
    selectedRuleId,
    setSelectedRuleId,
    addRule,
    updateRule,
    deleteRule,
    setHasUnsavedRule
  } = useApp();

  const [formState, setFormState] = useState<RuleFormState>(defaultFormState);
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);

  // Track unsaved changes
  useEffect(() => {
    const hasChanges = formState.name.trim() !== '' || 
      isCreating || 
      editingId !== null;
    setHasUnsavedRule(hasChanges);
  }, [formState, isCreating, editingId, setHasUnsavedRule]);

  const handleFieldToggle = (field: keyof RuleFormState['fields']) => {
    setFormState(prev => ({
      ...prev,
      fields: { ...prev.fields, [field]: !prev.fields[field] }
    }));
  };

  const handleWeightChange = (field: keyof RuleFormState['weights'], value: number[]) => {
    setFormState(prev => ({
      ...prev,
      weights: { ...prev.weights, [field]: value[0] }
    }));
  };

  const handleStrategyChange = (strategy: MatchStrategy) => {
    setFormState(prev => ({ ...prev, strategy }));
  };

  const validateForm = (): string | null => {
    if (!formState.name.trim()) {
      return 'Please enter a rule name.';
    }
    
    const activeFields = Object.values(formState.fields).filter(Boolean);
    if (activeFields.length === 0) {
      return 'Please enable at least one field for matching.';
    }

    // Check for duplicate names
    const existingRule = rules.find(r => 
      r.name.toLowerCase() === formState.name.toLowerCase() && r.id !== editingId
    );
    if (existingRule) {
      return 'A rule with this name already exists. Rule names must be unique.';
    }

    return null;
  };

  const handleSaveRule = () => {
    const error = validateForm();
    if (error) {
      setMessage({ type: 'error', text: error });
      return;
    }

    if (editingId) {
      updateRule(editingId, {
        name: formState.name,
        strategy: formState.strategy,
        fields: formState.fields,
        weights: formState.weights
      });
      setMessage({ type: 'success', text: 'Rule updated successfully!' });
      setEditingId(null);
    } else {
      const result = addRule({
        name: formState.name,
        strategy: formState.strategy,
        fields: formState.fields,
        weights: formState.weights,
        isActive: true
      });
      setMessage({ type: 'success', text: 'Rule created successfully! You can now select it for searching.' });
      setIsCreating(false);
    }

    setFormState(defaultFormState);
    setTimeout(() => setMessage(null), 5000);
  };

  const handleEditRule = (rule: MatchingRule) => {
    setFormState({
      name: rule.name,
      strategy: rule.strategy,
      fields: rule.fields,
      weights: rule.weights
    });
    setEditingId(rule.id);
    setIsCreating(false);
  };

  const handleDeleteRule = (id: string) => {
    if (id === 'default') {
      setMessage({ type: 'warning', text: 'Cannot delete the default rule.' });
      return;
    }
    deleteRule(id);
    setMessage({ type: 'success', text: 'Rule deleted.' });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleSelectRule = (id: string) => {
    if (isCreating || editingId) {
      setMessage({ 
        type: 'warning', 
        text: 'Please save or cancel your current changes before selecting a rule.' 
      });
      return;
    }
    setSelectedRuleId(id);
    setMessage({ type: 'success', text: 'Rule selected! You can now search using this rule.' });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleCancel = () => {
    setFormState(defaultFormState);
    setIsCreating(false);
    setEditingId(null);
  };

  const totalWeight = Object.values(formState.weights).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Info Banner */}
      <Alert className="border-info/50 bg-info/5">
        <Info className="h-4 w-4 text-info" />
        <AlertDescription>
          <strong>Workflow:</strong> Create and save a rule → Select the rule → Go to "Input & Search" to search
        </AlertDescription>
      </Alert>

      {/* Messages */}
      {message && (
        <Alert 
          variant={message.type === 'error' ? 'destructive' : 'default'}
          className={
            message.type === 'success' ? 'border-success/50 bg-success/5' : 
            message.type === 'warning' ? 'border-warning/50 bg-warning/5' : ''
          }
        >
          {message.type === 'warning' && <AlertTriangle className="h-4 w-4 text-warning" />}
          {message.type === 'success' && <Check className="h-4 w-4 text-success" />}
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Existing Rules */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Matching Rules
          </CardTitle>
          {!isCreating && !editingId && (
            <Button onClick={() => setIsCreating(true)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              New Rule
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {rules.map((rule) => (
              <div
                key={rule.id}
                className={`p-4 rounded-lg border transition-all ${
                  selectedRuleId === rule.id
                    ? 'bg-primary/5 border-primary/30'
                    : 'bg-card hover:bg-muted/30'
                } ${editingId === rule.id ? 'ring-2 ring-primary' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{rule.name}</span>
                      {selectedRuleId === rule.id && (
                        <Badge className="bg-primary text-primary-foreground">Selected</Badge>
                      )}
                      <Badge variant="outline">
                        {rule.strategy === 'exact' ? 'Exact' : 'Partial'}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground flex gap-3">
                      {Object.entries(rule.fields).map(([field, enabled]) => (
                        <span key={field} className={enabled ? 'text-foreground' : 'line-through opacity-50'}>
                          {field} ({rule.weights[field as keyof typeof rule.weights]}%)
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedRuleId !== rule.id && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSelectRule(rule.id)}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Select
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditRule(rule)}
                      disabled={rule.id === 'default'}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteRule(rule.id)}
                      disabled={rule.id === 'default'}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Form */}
      {(isCreating || editingId) && (
        <Card className="animate-slide-up border-primary/30">
          <CardHeader>
            <CardTitle className="text-lg">
              {editingId ? 'Edit Rule' : 'Create New Rule'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Rule Name */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Rule Name</label>
              <Input
                placeholder="Enter rule name..."
                value={formState.name}
                onChange={(e) => setFormState(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>

            {/* Strategy Selection */}
            <div className="space-y-3">
              <label className="text-sm font-medium">Matching Strategy</label>
              <div className="flex gap-3">
                <Button
                  variant={formState.strategy === 'exact' ? 'default' : 'outline'}
                  onClick={() => handleStrategyChange('exact')}
                  className="flex-1"
                >
                  Exact Match
                </Button>
                <Button
                  variant={formState.strategy === 'partial' ? 'default' : 'outline'}
                  onClick={() => handleStrategyChange('partial')}
                  className="flex-1"
                >
                  Partial Match
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                {formState.strategy === 'exact' 
                  ? 'Fields must match exactly (case-insensitive)'
                  : 'Fields can partially match (contains comparison)'}
              </p>
            </div>

            {/* Field Selection & Weights */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Fields & Weights</label>
                <Badge variant={totalWeight === 100 ? 'default' : 'destructive'}>
                  Total: {totalWeight}%
                </Badge>
              </div>
              
              {totalWeight !== 100 && (
                <Alert variant="destructive" className="py-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    Weights should total 100% for accurate scoring.
                  </AlertDescription>
                </Alert>
              )}

              {(['name', 'address', 'email', 'phone'] as const).map((field) => (
                <div key={field} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={formState.fields[field]}
                        onCheckedChange={() => handleFieldToggle(field)}
                      />
                      <span className="text-sm font-medium capitalize">{field}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {formState.weights[field]}%
                    </span>
                  </div>
                  {formState.fields[field] && (
                    <Slider
                      value={[formState.weights[field]]}
                      onValueChange={(value) => handleWeightChange(field, value)}
                      max={100}
                      step={5}
                      className="w-full"
                    />
                  )}
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
              <Button onClick={handleSaveRule}>
                <Check className="h-4 w-4 mr-2" />
                {editingId ? 'Update Rule' : 'Save Rule'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
