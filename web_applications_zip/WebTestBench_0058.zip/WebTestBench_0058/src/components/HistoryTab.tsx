import React from 'react';
import { History, Trash2, Clock, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/context/AppContext';

export function HistoryTab() {
  const { searchHistory, clearHistory, setSearchInput, setSelectedRuleId } = useApp();

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleReplay = (entry: typeof searchHistory[0]) => {
    setSearchInput(entry.input);
    setSelectedRuleId(entry.ruleId);
  };

  const getFilledFields = (input: typeof searchHistory[0]['input']) => {
    return Object.entries(input)
      .filter(([_, value]) => value.trim() !== '')
      .map(([field]) => field);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <History className="h-5 w-5" />
            Search History
          </CardTitle>
          {searchHistory.length > 0 && (
            <Button variant="outline" size="sm" onClick={clearHistory}>
              <Trash2 className="h-4 w-4 mr-2" />
              Clear All
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {searchHistory.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p>No search history yet</p>
              <p className="text-sm mt-1">Your searches will appear here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {searchHistory.map((entry) => {
                const filledFields = getFilledFields(entry.input);
                
                return (
                  <div
                    key={entry.id}
                    className="p-4 rounded-lg border bg-card hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          {formatDate(entry.timestamp)}
                          <span className="mx-2">•</span>
                          <Badge variant="secondary">{entry.ruleName}</Badge>
                          <span className="mx-2">•</span>
                          <span>{entry.resultCount} results</span>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {entry.input.name && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Name: </span>
                              <span className="font-medium">{entry.input.name}</span>
                            </div>
                          )}
                          {entry.input.email && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Email: </span>
                              <span className="font-medium">{entry.input.email}</span>
                            </div>
                          )}
                          {entry.input.address && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Address: </span>
                              <span className="font-medium truncate">{entry.input.address}</span>
                            </div>
                          )}
                          {entry.input.phone && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Phone: </span>
                              <span className="font-medium">{entry.input.phone}</span>
                            </div>
                          )}
                        </div>

                        {entry.markedRecords.length > 0 && (
                          <div className="flex items-center gap-2 text-sm">
                            <Badge variant="outline" className="bg-primary/5">
                              {entry.markedRecords.length} marked records
                            </Badge>
                          </div>
                        )}
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleReplay(entry)}
                        className="text-primary"
                      >
                        Replay
                        <ArrowRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
