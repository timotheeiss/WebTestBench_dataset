import React, { useMemo, useEffect } from 'react';
import { Search, AlertCircle, CheckCircle2, Star, StarOff, Info } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useApp } from '@/context/AppContext';
import { mockRecords } from '@/data/records';

export function SearchTab() {
  const {
    searchInput,
    setSearchInput,
    selectedRuleId,
    rules,
    matchResults,
    performSearch,
    validationErrors,
    validateInput,
    toggleMark,
    markedRecords,
    hasUnsavedRule
  } = useApp();

  const [searchMessage, setSearchMessage] = React.useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);

  const selectedRule = useMemo(() => rules.find(r => r.id === selectedRuleId), [rules, selectedRuleId]);

  // Real-time validation
  useEffect(() => {
    const timeout = setTimeout(() => {
      validateInput();
    }, 300);
    return () => clearTimeout(timeout);
  }, [searchInput, validateInput]);

  // Calculate real-time score preview
  const scorePreview = useMemo(() => {
    if (!selectedRule) return null;
    
    const activeFields = Object.entries(selectedRule.fields)
      .filter(([_, enabled]) => enabled)
      .map(([field]) => field);
    
    const filledFields = Object.entries(searchInput)
      .filter(([field, value]) => activeFields.includes(field) && value.trim() !== '')
      .length;
    
    const totalWeight = Object.entries(selectedRule.weights)
      .filter(([field]) => activeFields.includes(field))
      .reduce((sum, [_, weight]) => sum + weight, 0);
    
    const filledWeight = Object.entries(selectedRule.weights)
      .filter(([field]) => activeFields.includes(field) && searchInput[field as keyof typeof searchInput]?.trim())
      .reduce((sum, [_, weight]) => sum + weight, 0);
    
    return {
      filledFields,
      totalFields: activeFields.length,
      potentialScore: totalWeight > 0 ? Math.round((filledWeight / totalWeight) * 100) : 0
    };
  }, [selectedRule, searchInput]);

  const handleSearch = () => {
    const result = performSearch();
    if (result.success) {
      setSearchMessage({ type: 'success', text: `Found ${matchResults.length} matching records` });
    } else {
      setSearchMessage({ type: 'error', text: result.message || 'Search failed' });
    }
    
    // Clear message after 5 seconds
    setTimeout(() => setSearchMessage(null), 5000);
  };

  const handleInputChange = (field: keyof typeof searchInput) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput({ ...searchInput, [field]: e.target.value });
    setSearchMessage(null);
  };

  const getScoreBadgeClass = (score: number) => {
    if (score >= 75) return 'score-badge-high';
    if (score >= 50) return 'score-badge-medium';
    return 'score-badge-low';
  };

  const getRecordById = (id: string) => mockRecords.find(r => r.id === id);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Status Banner */}
      <div className="flex items-center justify-between p-4 bg-card rounded-lg border">
        <div className="flex items-center gap-3">
          {selectedRule ? (
            <>
              <CheckCircle2 className="h-5 w-5 text-success" />
              <span className="text-sm font-medium">
                Active Rule: <span className="text-primary">{selectedRule.name}</span>
                <Badge variant="outline" className="ml-2">
                  {selectedRule.strategy === 'exact' ? 'Exact Match' : 'Partial Match'}
                </Badge>
              </span>
            </>
          ) : (
            <>
              <AlertCircle className="h-5 w-5 text-warning" />
              <span className="text-sm text-muted-foreground">
                No rule selected. Please select a rule from "Matching Rule Settings" first.
              </span>
            </>
          )}
        </div>
        {scorePreview && (
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Coverage:</span>
            <Badge variant="secondary">
              {scorePreview.filledFields}/{scorePreview.totalFields} fields
            </Badge>
            <span className="text-muted-foreground">Potential:</span>
            <Badge className={getScoreBadgeClass(scorePreview.potentialScore)}>
              {scorePreview.potentialScore}%
            </Badge>
          </div>
        )}
      </div>

      {/* Validation Warnings */}
      {validationErrors.length > 0 && (
        <Alert variant="default" className="border-warning/50 bg-warning/5">
          <Info className="h-4 w-4 text-warning" />
          <AlertDescription className="text-sm">
            {validationErrors.map((err, i) => (
              <div key={i}>{err.message}</div>
            ))}
          </AlertDescription>
        </Alert>
      )}

      {/* Search Message */}
      {searchMessage && (
        <Alert variant={searchMessage.type === 'error' ? 'destructive' : 'default'} 
               className={searchMessage.type === 'success' ? 'border-success/50 bg-success/5' : ''}>
          {searchMessage.type === 'success' ? (
            <CheckCircle2 className="h-4 w-4 text-success" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          <AlertDescription>{searchMessage.text}</AlertDescription>
        </Alert>
      )}

      {/* Unsaved Rule Warning */}
      {hasUnsavedRule && (
        <Alert className="border-warning/50 bg-warning/5">
          <AlertCircle className="h-4 w-4 text-warning" />
          <AlertDescription>
            You have unsaved rule changes. Save your rule before searching.
          </AlertDescription>
        </Alert>
      )}

      {/* Input Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Search className="h-5 w-5" />
            Search Fields
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Name</label>
              <Input
                placeholder="Enter name..."
                value={searchInput.name}
                onChange={handleInputChange('name')}
                className={validationErrors.some(e => e.field === 'name') ? 'border-warning' : ''}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <Input
                placeholder="Enter email..."
                value={searchInput.email}
                onChange={handleInputChange('email')}
                className={validationErrors.some(e => e.field === 'email') ? 'border-warning' : ''}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Address</label>
              <Input
                placeholder="Enter address..."
                value={searchInput.address}
                onChange={handleInputChange('address')}
                className={validationErrors.some(e => e.field === 'address') ? 'border-warning' : ''}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Phone</label>
              <Input
                placeholder="Enter phone number..."
                value={searchInput.phone}
                onChange={handleInputChange('phone')}
                className={validationErrors.some(e => e.field === 'phone') ? 'border-warning' : ''}
              />
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button onClick={handleSearch} size="lg">
              <Search className="h-4 w-4 mr-2" />
              Search Records
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {matchResults.length > 0 && (
        <Card className="animate-slide-up">
          <CardHeader>
            <CardTitle className="text-lg flex items-center justify-between">
              <span>Results ({matchResults.length} matches)</span>
              <Badge variant="outline">
                {markedRecords.size} marked
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {matchResults.map((result) => {
                const record = getRecordById(result.recordId);
                if (!record) return null;
                
                return (
                  <div
                    key={result.recordId}
                    className={`p-4 rounded-lg border transition-all ${
                      result.isMarked 
                        ? 'bg-primary/5 border-primary/30' 
                        : 'bg-card hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${result.fieldMatches.name ? 'text-success' : ''}`}>
                            {record.name}
                          </span>
                          <Badge className={getScoreBadgeClass(result.score)}>
                            {result.score}% match
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground grid grid-cols-1 md:grid-cols-2 gap-1">
                          <span className={result.fieldMatches.email ? 'text-success' : ''}>
                            📧 {record.email}
                          </span>
                          <span className={result.fieldMatches.phone ? 'text-success' : ''}>
                            📱 {record.phone}
                          </span>
                          <span className={`md:col-span-2 ${result.fieldMatches.address ? 'text-success' : ''}`}>
                            📍 {record.address}
                          </span>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleMark(result.recordId)}
                        className={result.isMarked ? 'text-primary' : 'text-muted-foreground'}
                      >
                        {result.isMarked ? (
                          <Star className="h-5 w-5 fill-current" />
                        ) : (
                          <StarOff className="h-5 w-5" />
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {matchResults.length === 0 && selectedRuleId && (
        <Card className="border-dashed">
          <CardContent className="py-12 text-center text-muted-foreground">
            <Search className="h-12 w-12 mx-auto mb-4 opacity-20" />
            <p>Enter search criteria and click "Search Records" to find matches</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
