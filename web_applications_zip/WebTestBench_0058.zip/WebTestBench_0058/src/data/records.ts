export interface Record {
  id: string;
  name: string;
  address: string;
  email: string;
  phone: string;
}

export const mockRecords: Record[] = [
  {
    id: "1",
    name: "John Smith",
    address: "123 Main Street, New York, NY 10001",
    email: "john.smith@email.com",
    phone: "(555) 123-4567"
  },
  {
    id: "2",
    name: "Jane Doe",
    address: "456 Oak Avenue, Los Angeles, CA 90001",
    email: "jane.doe@company.org",
    phone: "(555) 234-5678"
  },
  {
    id: "3",
    name: "Robert Johnson",
    address: "789 Pine Road, Chicago, IL 60601",
    email: "r.johnson@business.net",
    phone: "(555) 345-6789"
  },
  {
    id: "4",
    name: "Emily Wilson",
    address: "321 Elm Boulevard, Houston, TX 77001",
    email: "emily.wilson@mail.com",
    phone: "(555) 456-7890"
  },
  {
    id: "5",
    name: "Michael Brown",
    address: "654 Maple Lane, Phoenix, AZ 85001",
    email: "m.brown@outlook.com",
    phone: "(555) 567-8901"
  },
  {
    id: "6",
    name: "Sarah Davis",
    address: "987 Cedar Court, Philadelphia, PA 19101",
    email: "sarah.davis@gmail.com",
    phone: "(555) 678-9012"
  },
  {
    id: "7",
    name: "David Martinez",
    address: "147 Birch Way, San Antonio, TX 78201",
    email: "d.martinez@yahoo.com",
    phone: "(555) 789-0123"
  },
  {
    id: "8",
    name: "Jennifer Garcia",
    address: "258 Spruce Drive, San Diego, CA 92101",
    email: "j.garcia@proton.me",
    phone: "(555) 890-1234"
  },
  {
    id: "9",
    name: "James Anderson",
    address: "369 Willow Path, Dallas, TX 75201",
    email: "james.anderson@corp.io",
    phone: "(555) 901-2345"
  },
  {
    id: "10",
    name: "Lisa Thompson",
    address: "741 Ash Street, San Jose, CA 95101",
    email: "l.thompson@tech.co",
    phone: "(555) 012-3456"
  },
  {
    id: "11",
    name: "John Williams",
    address: "852 Oak Street, Austin, TX 73301",
    email: "john.w@example.com",
    phone: "(555) 111-2222"
  },
  {
    id: "12",
    name: "Maria Santos",
    address: "963 Palm Avenue, Miami, FL 33101",
    email: "maria.santos@mail.org",
    phone: "(555) 222-3333"
  }
];
