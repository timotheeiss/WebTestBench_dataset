import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Decision } from '@/data/decisions';

export const exportToCSV = (decisions: Decision[], filename: string = 'decisions') => {
  const headers = ['Name', 'Year', 'Category', 'Outcome', 'Summary', 'Conditions', 'Consequences'];
  
  const rows = decisions.map(d => [
    d.name,
    d.year.toString(),
    d.category,
    d.outcome,
    d.outcomeSummary,
    d.conditions.join('; '),
    d.consequences.join('; ')
  ]);

  const csvContent = [headers, ...rows]
    .map(row => row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, `${filename}.csv`);
};

export const exportToExcel = (decisions: Decision[], filename: string = 'decisions') => {
  const data = decisions.map(d => ({
    'Name': d.name,
    'Year': d.year,
    'Category': d.category,
    'Outcome': d.outcome,
    'Summary': d.outcomeSummary,
    'Full Description': d.fullDescription,
    'Conditions': d.conditions.join('; '),
    'Consequences': d.consequences.join('; '),
    'Key Figures': d.keyFigures.join('; '),
    'Sources': d.sources.join('; ')
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Decisions');
  
  XLSX.writeFile(workbook, `${filename}.xlsx`);
};

export const exportToPDF = (decisions: Decision[], filename: string = 'decisions') => {
  const doc = new jsPDF();
  
  doc.setFontSize(20);
  doc.text('Historical Decisions Archive', 14, 22);
  
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Exported on ${new Date().toLocaleDateString()}`, 14, 30);

  const tableData = decisions.map(d => [
    d.name,
    d.year.toString(),
    d.category.charAt(0).toUpperCase() + d.category.slice(1),
    d.outcome.charAt(0).toUpperCase() + d.outcome.slice(1),
    d.outcomeSummary.substring(0, 100) + (d.outcomeSummary.length > 100 ? '...' : '')
  ]);

  autoTable(doc, {
    head: [['Decision', 'Year', 'Category', 'Outcome', 'Summary']],
    body: tableData,
    startY: 40,
    styles: { fontSize: 8, cellPadding: 3 },
    headStyles: { fillColor: [35, 47, 62] },
    alternateRowStyles: { fillColor: [250, 248, 245] },
    columnStyles: {
      0: { cellWidth: 40 },
      1: { cellWidth: 15 },
      2: { cellWidth: 25 },
      3: { cellWidth: 20 },
      4: { cellWidth: 'auto' }
    }
  });

  doc.save(`${filename}.pdf`);
};

export const parseImportFile = async (file: File): Promise<Partial<Decision>[]> => {
  const extension = file.name.split('.').pop()?.toLowerCase();
  
  if (extension === 'csv') {
    return parseCSV(file);
  } else if (extension === 'xlsx' || extension === 'xls') {
    return parseExcel(file);
  }
  
  throw new Error('Unsupported file format. Please use CSV or Excel files.');
};

const parseCSV = async (file: File): Promise<Partial<Decision>[]> => {
  const text = await file.text();
  const lines = text.split('\n').filter(line => line.trim());
  
  if (lines.length < 2) {
    throw new Error('CSV file must contain headers and at least one data row.');
  }

  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim().toLowerCase());
  
  return lines.slice(1).map((line, index) => {
    const values = line.match(/("([^"]|"")*"|[^,]*)/g)?.map(v => v.replace(/^"|"$/g, '').replace(/""/g, '"').trim()) || [];
    
    const row: Record<string, string> = {};
    headers.forEach((header, i) => {
      row[header] = values[i] || '';
    });

    return {
      id: `imported-${Date.now()}-${index}`,
      name: row['name'] || row['decision'] || 'Unnamed Decision',
      year: parseInt(row['year']) || new Date().getFullYear(),
      category: (row['category'] as Decision['category']) || 'political',
      outcome: (row['outcome'] as Decision['outcome']) || 'mixed',
      outcomeSummary: row['summary'] || row['outcomesummary'] || '',
      fullDescription: row['description'] || row['fulldescription'] || '',
      conditions: row['conditions']?.split(';').map(c => c.trim()).filter(Boolean) || [],
      consequences: row['consequences']?.split(';').map(c => c.trim()).filter(Boolean) || [],
      keyFigures: row['keyfigures']?.split(';').map(k => k.trim()).filter(Boolean) || [],
      sources: row['sources']?.split(';').map(s => s.trim()).filter(Boolean) || []
    };
  });
};

const parseExcel = async (file: File): Promise<Partial<Decision>[]> => {
  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer);
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const data = XLSX.utils.sheet_to_json<Record<string, string>>(worksheet);

  return data.map((row, index) => {
    const normalizedRow: Record<string, string> = {};
    Object.keys(row).forEach(key => {
      normalizedRow[key.toLowerCase().replace(/\s+/g, '')] = String(row[key]);
    });

    return {
      id: `imported-${Date.now()}-${index}`,
      name: normalizedRow['name'] || normalizedRow['decision'] || 'Unnamed Decision',
      year: parseInt(normalizedRow['year']) || new Date().getFullYear(),
      category: (normalizedRow['category'] as Decision['category']) || 'political',
      outcome: (normalizedRow['outcome'] as Decision['outcome']) || 'mixed',
      outcomeSummary: normalizedRow['summary'] || normalizedRow['outcomesummary'] || '',
      fullDescription: normalizedRow['description'] || normalizedRow['fulldescription'] || '',
      conditions: normalizedRow['conditions']?.split(';').map(c => c.trim()).filter(Boolean) || [],
      consequences: normalizedRow['consequences']?.split(';').map(c => c.trim()).filter(Boolean) || [],
      keyFigures: normalizedRow['keyfigures']?.split(';').map(k => k.trim()).filter(Boolean) || [],
      sources: normalizedRow['sources']?.split(';').map(s => s.trim()).filter(Boolean) || []
    };
  });
};

const downloadBlob = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
