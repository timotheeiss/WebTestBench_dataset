import { useState, useMemo } from 'react';
import { decisions as defaultDecisions, Decision } from '@/data/decisions';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Header } from '@/components/Header';
import { SearchBar } from '@/components/SearchBar';
import { FilterPanel } from '@/components/FilterPanel';
import { DecisionCard } from '@/components/DecisionCard';
import { DecisionDetail } from '@/components/DecisionDetail';
import { AnimatePresence, motion } from 'framer-motion';
import { Search, BookOpen } from 'lucide-react';

const Index = () => {
  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSearch, setActiveSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [outcomeFilter, setOutcomeFilter] = useState('all');
  const [timePeriodFilter, setTimePeriodFilter] = useState('all');
  const [selectedDecision, setSelectedDecision] = useState<Decision | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // LocalStorage
  const [searchHistory, setSearchHistory] = useLocalStorage<string[]>('searchHistory', []);
  const [bookmarks, setBookmarks] = useLocalStorage<string[]>('bookmarks', []);
  const [importedDecisions, setImportedDecisions] = useLocalStorage<Decision[]>('importedDecisions', []);

  // Combine default and imported decisions
  const allDecisions = useMemo(() => {
    return [...defaultDecisions, ...importedDecisions];
  }, [importedDecisions]);

  // Filter decisions
  const filteredDecisions = useMemo(() => {
    return allDecisions.filter(decision => {
      // Search filter
      if (activeSearch) {
        const query = activeSearch.toLowerCase();
        const matchesName = decision.name.toLowerCase().includes(query);
        const matchesOutcome = decision.outcomeSummary.toLowerCase().includes(query);
        const matchesConditions = decision.conditions.some(c => c.toLowerCase().includes(query));
        const matchesDescription = decision.fullDescription.toLowerCase().includes(query);
        
        if (!matchesName && !matchesOutcome && !matchesConditions && !matchesDescription) {
          return false;
        }
      }

      // Category filter
      if (categoryFilter !== 'all' && decision.category !== categoryFilter) {
        return false;
      }

      // Outcome filter
      if (outcomeFilter !== 'all' && decision.outcome !== outcomeFilter) {
        return false;
      }

      // Time period filter
      if (timePeriodFilter !== 'all') {
        const [start, end] = timePeriodFilter.split('-').map(Number);
        if (decision.year < start || decision.year > end) {
          return false;
        }
      }

      return true;
    });
  }, [allDecisions, activeSearch, categoryFilter, outcomeFilter, timePeriodFilter]);

  // Bookmarked decisions
  const bookmarkedDecisions = useMemo(() => {
    return allDecisions.filter(d => bookmarks.includes(d.id));
  }, [allDecisions, bookmarks]);

  // Handlers
  const handleSearch = (query: string) => {
    setActiveSearch(query);
    if (query && !searchHistory.includes(query)) {
      setSearchHistory(prev => [query, ...prev.slice(0, 9)]);
    }
  };

  const handleHistoryItemClick = (query: string) => {
    setSearchQuery(query);
    handleSearch(query);
  };

  const handleClearHistory = () => {
    setSearchHistory([]);
  };

  const handleBookmarkToggle = (id: string) => {
    setBookmarks(prev => 
      prev.includes(id) 
        ? prev.filter(b => b !== id)
        : [...prev, id]
    );
  };

  const handleClearBookmarks = () => {
    setBookmarks([]);
  };

  const handleResetFilters = () => {
    setCategoryFilter('all');
    setOutcomeFilter('all');
    setTimePeriodFilter('all');
  };

  const handleImport = (decisions: Partial<Decision>[]) => {
    const validDecisions = decisions.filter(d => d.name && d.year) as Decision[];
    setImportedDecisions(prev => [...prev, ...validDecisions]);
  };

  const handleSelectDecision = (decision: Decision) => {
    setSelectedDecision(decision);
    setIsDetailOpen(true);
  };

  const hasActiveFilters = categoryFilter !== 'all' || outcomeFilter !== 'all' || timePeriodFilter !== 'all';

  return (
    <div className="min-h-screen bg-background">
      <Header
        decisions={filteredDecisions}
        bookmarkedDecisions={bookmarkedDecisions}
        onRemoveBookmark={handleBookmarkToggle}
        onClearBookmarks={handleClearBookmarks}
        onSelectDecision={handleSelectDecision}
        onImport={handleImport}
      />

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center mb-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-3 text-balance">
              Explore Historical Decisions
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto text-balance">
              Search through pivotal moments in history. Analyze the conditions, outcomes, and lasting consequences of major decisions.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              onSearch={handleSearch}
              searchHistory={searchHistory}
              onHistoryItemClick={handleHistoryItemClick}
              onClearHistory={handleClearHistory}
            />
          </motion.div>
        </section>

        {/* Filters */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <FilterPanel
            category={categoryFilter}
            outcome={outcomeFilter}
            timePeriod={timePeriodFilter}
            onCategoryChange={setCategoryFilter}
            onOutcomeChange={setOutcomeFilter}
            onTimePeriodChange={setTimePeriodFilter}
            onReset={handleResetFilters}
            hasActiveFilters={hasActiveFilters}
          />
        </motion.section>

        {/* Results */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {filteredDecisions.length} {filteredDecisions.length === 1 ? 'decision' : 'decisions'} found
              </span>
              {activeSearch && (
                <span className="text-sm text-muted-foreground">
                  for "<span className="font-medium text-foreground">{activeSearch}</span>"
                </span>
              )}
            </div>
          </div>

          {filteredDecisions.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16 text-center"
            >
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-heading font-semibold text-lg mb-1">No decisions found</h3>
              <p className="text-sm text-muted-foreground max-w-[280px]">
                Try adjusting your search terms or filters to find what you're looking for.
              </p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              <AnimatePresence mode="popLayout">
                {filteredDecisions.map((decision) => (
                  <DecisionCard
                    key={decision.id}
                    decision={decision}
                    isBookmarked={bookmarks.includes(decision.id)}
                    onBookmarkToggle={handleBookmarkToggle}
                    onClick={() => handleSelectDecision(decision)}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </section>
      </main>

      {/* Decision Detail Modal */}
      <DecisionDetail
        decision={selectedDecision}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        isBookmarked={selectedDecision ? bookmarks.includes(selectedDecision.id) : false}
        onBookmarkToggle={handleBookmarkToggle}
      />
    </div>
  );
};

export default Index;
