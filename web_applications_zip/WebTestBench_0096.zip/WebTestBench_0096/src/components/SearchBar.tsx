import { useState } from 'react';
import { Search, X, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onSearch: (query: string) => void;
  searchHistory: string[];
  onHistoryItemClick: (query: string) => void;
  onClearHistory: () => void;
}

export function SearchBar({
  value,
  onChange,
  onSearch,
  searchHistory,
  onHistoryItemClick,
  onClearHistory
}: SearchBarProps) {
  const [isFocused, setIsFocused] = useState(false);
  const showHistory = isFocused && searchHistory.length > 0 && !value;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onSearch(value.trim());
      setIsFocused(false);
    }
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search decisions by name, outcome, or conditions..."
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setTimeout(() => setIsFocused(false), 200)}
            className="pl-12 pr-12 py-6 text-base bg-card border-border shadow-card rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
          {value && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
              onClick={() => onChange('')}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </form>

      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-elevated overflow-hidden z-50"
          >
            <div className="flex items-center justify-between px-4 py-2 border-b border-border">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Recent Searches
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearHistory}
                className="text-xs text-muted-foreground hover:text-destructive"
              >
                Clear all
              </Button>
            </div>
            <ul className="py-1">
              {searchHistory.slice(0, 5).map((query, index) => (
                <li key={index}>
                  <button
                    type="button"
                    onClick={() => {
                      onHistoryItemClick(query);
                      setIsFocused(false);
                    }}
                    className="w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center gap-3"
                  >
                    <Search className="h-4 w-4 text-muted-foreground" />
                    {query}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
