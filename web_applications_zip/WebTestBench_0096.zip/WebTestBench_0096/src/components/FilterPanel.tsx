import { categories, outcomes, timePeriods } from '@/data/decisions';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Filter, RotateCcw } from 'lucide-react';

interface FilterPanelProps {
  category: string;
  outcome: string;
  timePeriod: string;
  onCategoryChange: (value: string) => void;
  onOutcomeChange: (value: string) => void;
  onTimePeriodChange: (value: string) => void;
  onReset: () => void;
  hasActiveFilters: boolean;
}

export function FilterPanel({
  category,
  outcome,
  timePeriod,
  onCategoryChange,
  onOutcomeChange,
  onTimePeriodChange,
  onReset,
  hasActiveFilters
}: FilterPanelProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-soft">
      <div className="flex items-center gap-2 mb-4">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <span className="font-medium text-sm">Filters</span>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onReset}
            className="ml-auto text-xs h-7 gap-1"
          >
            <RotateCcw className="h-3 w-3" />
            Reset
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted-foreground">Category</label>
          <Select value={category} onValueChange={onCategoryChange}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted-foreground">Outcome</label>
          <Select value={outcome} onValueChange={onOutcomeChange}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Select outcome" />
            </SelectTrigger>
            <SelectContent>
              {outcomes.map((out) => (
                <SelectItem key={out.value} value={out.value}>
                  {out.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted-foreground">Time Period</label>
          <Select value={timePeriod} onValueChange={onTimePeriodChange}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              {timePeriods.map((period) => (
                <SelectItem key={period.value} value={period.value}>
                  {period.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
