import { Decision } from '@/data/decisions';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Bookmark, BookmarkCheck, X, CheckCircle, XCircle, AlertCircle, Users, BookOpen, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DecisionDetailProps {
  decision: Decision | null;
  isOpen: boolean;
  onClose: () => void;
  isBookmarked: boolean;
  onBookmarkToggle: (id: string) => void;
}

const outcomeConfig = {
  positive: { icon: CheckCircle, color: 'text-success', bgColor: 'bg-success/10', label: 'Positive Outcome' },
  negative: { icon: XCircle, color: 'text-destructive', bgColor: 'bg-destructive/10', label: 'Negative Outcome' },
  mixed: { icon: AlertCircle, color: 'text-warning', bgColor: 'bg-warning/10', label: 'Mixed Outcome' }
};

const categoryLabels = {
  political: 'Political Decision',
  military: 'Military Decision',
  economic: 'Economic Decision',
  scientific: 'Scientific Decision',
  social: 'Social Decision'
};

export function DecisionDetail({ decision, isOpen, onClose, isBookmarked, onBookmarkToggle }: DecisionDetailProps) {
  if (!decision) return null;

  const outcomeInfo = outcomeConfig[decision.outcome];
  const OutcomeIcon = outcomeInfo.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0 gap-0 overflow-hidden">
        <DialogHeader className="p-6 pb-4 border-b border-border">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className="text-xs">
                  {categoryLabels[decision.category]}
                </Badge>
                <span className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Calendar className="h-3.5 w-3.5" />
                  {decision.year}
                </span>
              </div>
              <DialogTitle className="font-heading text-2xl font-bold leading-tight">
                {decision.name}
              </DialogTitle>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className={cn(
                  "h-9 w-9 transition-colors",
                  isBookmarked ? "text-gold border-gold hover:bg-gold/10" : ""
                )}
                onClick={() => onBookmarkToggle(decision.id)}
              >
                {isBookmarked ? <BookmarkCheck className="h-4 w-4 fill-current" /> : <Bookmark className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 max-h-[calc(90vh-120px)]">
          <div className="p-6 space-y-6">
            {/* Outcome Badge */}
            <div className={cn("flex items-center gap-3 p-4 rounded-lg", outcomeInfo.bgColor)}>
              <OutcomeIcon className={cn("h-6 w-6", outcomeInfo.color)} />
              <div>
                <p className={cn("font-semibold", outcomeInfo.color)}>{outcomeInfo.label}</p>
                <p className="text-sm text-foreground/80">{decision.outcomeSummary}</p>
              </div>
            </div>

            {/* Full Description */}
            <section>
              <h4 className="font-heading font-semibold text-lg mb-2">Overview</h4>
              <p className="text-muted-foreground leading-relaxed">{decision.fullDescription}</p>
            </section>

            <Separator />

            {/* Conditions */}
            <section>
              <h4 className="font-heading font-semibold text-lg mb-3">Historical Conditions</h4>
              <ul className="space-y-2">
                {decision.conditions.map((condition, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-semibold flex items-center justify-center">
                      {index + 1}
                    </span>
                    <span className="text-sm text-muted-foreground">{condition}</span>
                  </li>
                ))}
              </ul>
            </section>

            <Separator />

            {/* Consequences */}
            <section>
              <h4 className="font-heading font-semibold text-lg mb-3">Consequences & Results</h4>
              <ul className="space-y-2">
                {decision.consequences.map((consequence, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className={cn(
                      "flex-shrink-0 w-1.5 h-1.5 rounded-full mt-2",
                      outcomeInfo.color.replace('text-', 'bg-')
                    )} />
                    <span className="text-sm text-muted-foreground">{consequence}</span>
                  </li>
                ))}
              </ul>
            </section>

            <Separator />

            {/* Key Figures */}
            <section>
              <h4 className="font-heading font-semibold text-lg mb-3 flex items-center gap-2">
                <Users className="h-4 w-4" />
                Key Figures
              </h4>
              <div className="flex flex-wrap gap-2">
                {decision.keyFigures.map((figure, index) => (
                  <Badge key={index} variant="secondary" className="text-sm">
                    {figure}
                  </Badge>
                ))}
              </div>
            </section>

            {/* Sources */}
            <section>
              <h4 className="font-heading font-semibold text-lg mb-3 flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Sources
              </h4>
              <ul className="space-y-1">
                {decision.sources.map((source, index) => (
                  <li key={index} className="text-sm text-muted-foreground">
                    • {source}
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
