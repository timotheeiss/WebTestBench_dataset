import { Decision } from '@/data/decisions';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bookmark, BookmarkCheck, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface DecisionCardProps {
  decision: Decision;
  isBookmarked: boolean;
  onBookmarkToggle: (id: string) => void;
  onClick: () => void;
}

const outcomeStyles = {
  positive: 'bg-success/10 text-success border-success/20',
  negative: 'bg-destructive/10 text-destructive border-destructive/20',
  mixed: 'bg-warning/10 text-warning border-warning/20'
};

const categoryStyles = {
  political: 'bg-primary/10 text-primary',
  military: 'bg-destructive/10 text-destructive',
  economic: 'bg-success/10 text-success',
  scientific: 'bg-info/10 text-info',
  social: 'bg-accent/20 text-accent-foreground'
};

export function DecisionCard({ decision, isBookmarked, onBookmarkToggle, onClick }: DecisionCardProps) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="group bg-card border border-border rounded-lg shadow-soft hover:shadow-card transition-all duration-300 overflow-hidden"
    >
      <div className="p-5">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className={cn("text-xs", categoryStyles[decision.category])}>
              {decision.category}
            </Badge>
            <span className="text-sm text-muted-foreground font-medium">{decision.year}</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8 shrink-0 transition-colors",
              isBookmarked ? "text-gold hover:text-gold/80" : "text-muted-foreground hover:text-foreground"
            )}
            onClick={(e) => {
              e.stopPropagation();
              onBookmarkToggle(decision.id);
            }}
          >
            {isBookmarked ? <BookmarkCheck className="h-4 w-4 fill-current" /> : <Bookmark className="h-4 w-4" />}
          </Button>
        </div>

        <h3 className="font-heading text-lg font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
          {decision.name}
        </h3>

        <div className="flex items-center gap-2 mb-3">
          <Badge
            variant="outline"
            className={cn("text-xs capitalize", outcomeStyles[decision.outcome])}
          >
            {decision.outcome}
          </Badge>
        </div>

        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
          {decision.outcomeSummary}
        </p>

        <Button
          variant="ghost"
          className="w-full justify-between text-sm font-medium hover:bg-muted group/btn"
          onClick={onClick}
        >
          View Details
          <ChevronRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
        </Button>
      </div>
    </motion.article>
  );
}
