import { Decision } from '@/data/decisions';
import { BookmarksPanel } from './BookmarksPanel';
import { ExportImportPanel } from './ExportImportPanel';
import { Scroll } from 'lucide-react';

interface HeaderProps {
  decisions: Decision[];
  bookmarkedDecisions: Decision[];
  onRemoveBookmark: (id: string) => void;
  onClearBookmarks: () => void;
  onSelectDecision: (decision: Decision) => void;
  onImport: (decisions: Partial<Decision>[]) => void;
}

export function Header({
  decisions,
  bookmarkedDecisions,
  onRemoveBookmark,
  onClearBookmarks,
  onSelectDecision,
  onImport
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Scroll className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-heading font-bold text-lg leading-tight">Historical Decisions</h1>
            <p className="text-xs text-muted-foreground">Archive & Research</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ExportImportPanel decisions={decisions} onImport={onImport} />
          <BookmarksPanel
            bookmarkedDecisions={bookmarkedDecisions}
            onRemoveBookmark={onRemoveBookmark}
            onClearAll={onClearBookmarks}
            onSelectDecision={onSelectDecision}
          />
        </div>
      </div>
    </header>
  );
}
