import { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Download, Upload, FileSpreadsheet, FileText, FileDown } from 'lucide-react';
import { Decision } from '@/data/decisions';
import { exportToCSV, exportToExcel, exportToPDF, parseImportFile } from '@/utils/exportUtils';
import { toast } from 'sonner';

interface ExportImportPanelProps {
  decisions: Decision[];
  onImport: (decisions: Partial<Decision>[]) => void;
}

export function ExportImportPanel({ decisions, onImport }: ExportImportPanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportCSV = () => {
    exportToCSV(decisions);
    toast.success('Exported to CSV successfully');
  };

  const handleExportExcel = () => {
    exportToExcel(decisions);
    toast.success('Exported to Excel successfully');
  };

  const handleExportPDF = () => {
    exportToPDF(decisions);
    toast.success('Exported to PDF successfully');
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const imported = await parseImportFile(file);
      onImport(imported);
      toast.success(`Imported ${imported.length} decisions successfully`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to import file');
    }

    // Reset input
    e.target.value = '';
  };

  return (
    <div className="flex items-center gap-2">
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,.xlsx,.xls"
        onChange={handleFileChange}
        className="hidden"
      />

      <Button
        variant="outline"
        size="sm"
        onClick={handleImportClick}
        className="gap-2"
      >
        <Upload className="h-4 w-4" />
        Import
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem onClick={handleExportCSV} className="gap-2 cursor-pointer">
            <FileText className="h-4 w-4" />
            Export as CSV
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleExportExcel} className="gap-2 cursor-pointer">
            <FileSpreadsheet className="h-4 w-4" />
            Export as Excel
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleExportPDF} className="gap-2 cursor-pointer">
            <FileDown className="h-4 w-4" />
            Export as PDF
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
