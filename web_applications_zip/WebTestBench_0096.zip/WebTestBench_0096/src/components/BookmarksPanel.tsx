import { Decision } from '@/data/decisions';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Bookmark, BookmarkX, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BookmarksPanelProps {
  bookmarkedDecisions: Decision[];
  onRemoveBookmark: (id: string) => void;
  onClearAll: () => void;
  onSelectDecision: (decision: Decision) => void;
}

const outcomeStyles = {
  positive: 'bg-success/10 text-success',
  negative: 'bg-destructive/10 text-destructive',
  mixed: 'bg-warning/10 text-warning'
};

export function BookmarksPanel({ 
  bookmarkedDecisions, 
  onRemoveBookmark, 
  onClearAll, 
  onSelectDecision 
}: BookmarksPanelProps) {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Bookmark className="h-4 w-4" />
          Bookmarks
          {bookmarkedDecisions.length > 0 && (
            <Badge variant="secondary" className="h-5 px-1.5 text-xs">
              {bookmarkedDecisions.length}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader className="mb-4">
          <div className="flex items-center justify-between">
            <SheetTitle className="font-heading">Saved Bookmarks</SheetTitle>
            {bookmarkedDecisions.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearAll}
                className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5"
              >
                <Trash2 className="h-4 w-4" />
                Clear all
              </Button>
            )}
          </div>
        </SheetHeader>

        {bookmarkedDecisions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[60vh] text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <BookmarkX className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-heading font-semibold text-lg mb-1">No bookmarks yet</h3>
            <p className="text-sm text-muted-foreground max-w-[240px]">
              Save decisions you want to revisit by clicking the bookmark icon.
            </p>
          </div>
        ) : (
          <ScrollArea className="h-[calc(100vh-120px)]">
            <div className="space-y-3 pr-4">
              {bookmarkedDecisions.map((decision) => (
                <div
                  key={decision.id}
                  className="group p-4 bg-card border border-border rounded-lg hover:shadow-soft transition-all cursor-pointer"
                  onClick={() => onSelectDecision(decision)}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Badge variant="outline" className="text-xs capitalize">
                          {decision.category}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{decision.year}</span>
                      </div>
                      <h4 className="font-heading font-semibold text-sm mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                        {decision.name}
                      </h4>
                      <Badge
                        variant="outline"
                        className={cn("text-xs capitalize", outcomeStyles[decision.outcome])}
                      >
                        {decision.outcome}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveBookmark(decision.id);
                      }}
                    >
                      <BookmarkX className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </SheetContent>
    </Sheet>
  );
}
