export interface Decision {
  id: string;
  name: string;
  year: number;
  category: 'political' | 'military' | 'economic' | 'scientific' | 'social';
  conditions: string[];
  outcome: 'positive' | 'negative' | 'mixed';
  outcomeSummary: string;
  fullDescription: string;
  consequences: string[];
  keyFigures: string[];
  sources: string[];
}

export const decisions: Decision[] = [
  {
    id: "1",
    name: "The Louisiana Purchase",
    year: 1803,
    category: "political",
    conditions: [
      "France needed funds for European wars",
      "Napoleon abandoned plans for American empire",
      "Jefferson sought to secure Mississippi River access",
      "Constitutional questions about federal land acquisition"
    ],
    outcome: "positive",
    outcomeSummary: "Doubled the size of the United States, securing vital trade routes and setting precedent for westward expansion.",
    fullDescription: "In 1803, President Thomas Jefferson negotiated the purchase of approximately 828,000 square miles of territory from France for $15 million. This decision, while controversial due to constitutional concerns about federal authority, proved transformative for American development.",
    consequences: [
      "United States territory doubled in size",
      "Secured control of Mississippi River and New Orleans port",
      "Set precedent for territorial expansion",
      "Opened vast lands for settlement and agriculture",
      "Established principle of implied constitutional powers"
    ],
    keyFigures: ["Thomas Jefferson", "Napoleon Bonaparte", "James Monroe", "Robert Livingston"],
    sources: ["National Archives", "Library of Congress", "Smithsonian Institution"]
  },
  {
    id: "2",
    name: "The Maginot Line Strategy",
    year: 1929,
    category: "military",
    conditions: [
      "Memory of WWI trench warfare casualties",
      "Need to protect industrial regions",
      "Limited military manpower compared to Germany",
      "Belief in defensive warfare supremacy"
    ],
    outcome: "negative",
    outcomeSummary: "Massive fortification system was bypassed by German forces through Belgium, resulting in France's rapid defeat in 1940.",
    fullDescription: "France invested heavily in the Maginot Line, a series of concrete fortifications along the German border. The strategy assumed a static defensive war and failed to account for mobile warfare tactics and the vulnerability of the Ardennes forest route.",
    consequences: [
      "France fell in just six weeks in 1940",
      "Fortifications proved strategically irrelevant",
      "Massive financial investment yielded no return",
      "False sense of security delayed military modernization",
      "Demonstrated obsolescence of static defensive thinking"
    ],
    keyFigures: ["André Maginot", "Philippe Pétain", "Paul Reynaud"],
    sources: ["Imperial War Museum", "French Military Archives"]
  },
  {
    id: "3",
    name: "Marshall Plan Implementation",
    year: 1948,
    category: "economic",
    conditions: [
      "Post-WWII European economic devastation",
      "Rising Soviet influence in Eastern Europe",
      "Need to stabilize democratic governments",
      "American industrial surplus requiring markets"
    ],
    outcome: "positive",
    outcomeSummary: "Successfully rebuilt Western European economies, established lasting transatlantic partnerships, and contained Soviet expansion.",
    fullDescription: "The European Recovery Program, known as the Marshall Plan, provided over $13 billion in economic assistance to Western European nations. This unprecedented aid program helped rebuild infrastructure, stabilize currencies, and restore industrial production.",
    consequences: [
      "Western European GDP increased by 35% from 1948-1952",
      "Prevented communist takeover of key nations",
      "Created foundation for European economic integration",
      "Established model for future foreign aid programs",
      "Strengthened NATO alliance formation"
    ],
    keyFigures: ["George C. Marshall", "Harry Truman", "Dean Acheson", "Paul Hoffman"],
    sources: ["Truman Library", "State Department Archives", "OECD Historical Records"]
  },
  {
    id: "4",
    name: "Apollo Program Authorization",
    year: 1961,
    category: "scientific",
    conditions: [
      "Soviet space program achievements (Sputnik, Gagarin)",
      "Cold War technological competition",
      "Kennedy administration seeking bold initiatives",
      "Existing NASA infrastructure from Mercury program"
    ],
    outcome: "positive",
    outcomeSummary: "Achieved moon landing in 1969, advancing technology across multiple fields and inspiring generations of scientists.",
    fullDescription: "President Kennedy's decision to commit the nation to landing a man on the Moon before the end of the decade mobilized unprecedented scientific and engineering resources. The $25 billion program became the largest non-military technological undertaking in history.",
    consequences: [
      "First human moon landing achieved July 20, 1969",
      "Thousands of technological innovations developed",
      "Advanced computer, materials, and aerospace sciences",
      "Inspired global interest in science education",
      "Established American technological leadership"
    ],
    keyFigures: ["John F. Kennedy", "Wernher von Braun", "Neil Armstrong", "James Webb"],
    sources: ["NASA History Office", "Kennedy Presidential Library", "Smithsonian Air and Space Museum"]
  },
  {
    id: "5",
    name: "Deng Xiaoping's Economic Reforms",
    year: 1978,
    category: "economic",
    conditions: [
      "Chinese economy stagnant after Cultural Revolution",
      "Millions living in poverty",
      "Ideological shift after Mao's death",
      "Success of East Asian developmental states"
    ],
    outcome: "mixed",
    outcomeSummary: "Transformed China into economic powerhouse while maintaining political authoritarianism and creating significant inequality.",
    fullDescription: "Deng Xiaoping initiated sweeping economic reforms, introducing market mechanisms while maintaining Communist Party control. The 'reform and opening up' policy created Special Economic Zones and gradually liberalized agriculture and industry.",
    consequences: [
      "Hundreds of millions lifted from poverty",
      "China became world's second-largest economy",
      "Significant wealth inequality emerged",
      "Environmental degradation accelerated",
      "Political reform remained limited"
    ],
    keyFigures: ["Deng Xiaoping", "Zhao Ziyang", "Hu Yaobang"],
    sources: ["World Bank Historical Data", "Chinese Statistical Yearbooks"]
  },
  {
    id: "6",
    name: "The Treaty of Versailles",
    year: 1919,
    category: "political",
    conditions: [
      "End of World War I",
      "Allied victory over Central Powers",
      "Wilson's Fourteen Points idealism",
      "French desire for security guarantees"
    ],
    outcome: "negative",
    outcomeSummary: "Punitive terms fostered German resentment, contributing to economic instability and the rise of Nazi Germany.",
    fullDescription: "The Treaty of Versailles imposed harsh terms on Germany, including territorial losses, military restrictions, and massive reparations. While intended to prevent future German aggression, the treaty created conditions that destabilized the Weimar Republic.",
    consequences: [
      "German economy crippled by reparations",
      "Rise of nationalist movements exploiting resentment",
      "Failed to establish lasting peace framework",
      "Hitler used treaty grievances to gain power",
      "Contributed to outbreak of World War II"
    ],
    keyFigures: ["Woodrow Wilson", "Georges Clemenceau", "David Lloyd George", "Vittorio Orlando"],
    sources: ["National Archives UK", "French Diplomatic Archives", "Wilson Center"]
  },
  {
    id: "7",
    name: "Abolition of Slavery in Britain",
    year: 1833,
    category: "social",
    conditions: [
      "Growing abolitionist movement",
      "Economic arguments against slavery gaining traction",
      "Religious opposition intensifying",
      "Slave revolts increasing in Caribbean"
    ],
    outcome: "positive",
    outcomeSummary: "Ended slavery throughout British Empire, setting precedent for global abolition movements.",
    fullDescription: "The Slavery Abolition Act 1833 ended slavery in most of the British Empire. While compensation was controversially paid to slave owners rather than enslaved people, the decision marked a significant moral and political transformation.",
    consequences: [
      "800,000 enslaved people freed",
      "Set precedent for other nations to follow",
      "Transformed British colonial economics",
      "Energized global abolitionist movements",
      "Created template for gradual emancipation"
    ],
    keyFigures: ["William Wilberforce", "Thomas Clarkson", "Olaudah Equiano", "Earl Grey"],
    sources: ["British National Archives", "Anti-Slavery International", "Parliamentary Records"]
  },
  {
    id: "8",
    name: "Japan's Meiji Restoration",
    year: 1868,
    category: "political",
    conditions: [
      "Forced opening by Perry's expedition",
      "Weakness of Tokugawa shogunate",
      "Fear of Western colonization",
      "Desire for modernization among reform factions"
    ],
    outcome: "positive",
    outcomeSummary: "Rapidly modernized Japan, transforming it from feudal society to industrial power within decades.",
    fullDescription: "The Meiji Restoration ended centuries of shogunate rule and initiated comprehensive modernization. Japan adopted Western technologies, institutions, and practices while maintaining cultural identity, achieving remarkable industrial and military advancement.",
    consequences: [
      "Rapid industrialization achieved",
      "Modern educational system established",
      "Constitutional government created",
      "Japan became regional power",
      "Foundation for 20th century imperialism"
    ],
    keyFigures: ["Emperor Meiji", "Ito Hirobumi", "Okubo Toshimichi", "Saigo Takamori"],
    sources: ["National Diet Library Japan", "Meiji Memorial Picture Gallery"]
  },
  {
    id: "9",
    name: "Soviet Invasion of Afghanistan",
    year: 1979,
    category: "military",
    conditions: [
      "Communist government in Kabul facing insurgency",
      "Brezhnev Doctrine commitment to socialist states",
      "Strategic concerns about Islamic fundamentalism",
      "Underestimation of Afghan resistance"
    ],
    outcome: "negative",
    outcomeSummary: "Decade-long quagmire that drained Soviet resources and contributed to USSR's collapse.",
    fullDescription: "The Soviet Union invaded Afghanistan to support the communist government against mujahideen insurgents. The intervention became a costly quagmire, often compared to America's Vietnam experience, draining military and economic resources.",
    consequences: [
      "Over 15,000 Soviet soldiers killed",
      "Massive financial drain on Soviet economy",
      "Strengthened Islamic militant movements",
      "Contributed to Soviet Union's collapse",
      "Destabilized Afghanistan for decades"
    ],
    keyFigures: ["Leonid Brezhnev", "Babrak Karmal", "Ahmad Shah Massoud"],
    sources: ["Cold War International History Project", "Soviet Military Archives"]
  },
  {
    id: "10",
    name: "Creation of the Internet (ARPANET)",
    year: 1969,
    category: "scientific",
    conditions: [
      "Cold War need for resilient communications",
      "DARPA funding for research networks",
      "Academic collaboration requirements",
      "Advances in packet-switching technology"
    ],
    outcome: "positive",
    outcomeSummary: "Created foundation for global internet, revolutionizing communication, commerce, and society.",
    fullDescription: "ARPANET, funded by the Department of Defense, connected research institutions and developed protocols that became the foundation of the modern internet. This decision to create an open, decentralized network proved transformative.",
    consequences: [
      "Created foundation for modern internet",
      "Revolutionized global communication",
      "Enabled e-commerce and digital economy",
      "Transformed education and research",
      "Changed social interaction worldwide"
    ],
    keyFigures: ["Vint Cerf", "Bob Kahn", "Leonard Kleinrock", "J.C.R. Licklider"],
    sources: ["Computer History Museum", "Internet Society", "DARPA Archives"]
  },
  {
    id: "11",
    name: "Indian Partition",
    year: 1947,
    category: "political",
    conditions: [
      "British withdrawal from India inevitable",
      "Hindu-Muslim tensions escalating",
      "Muslim League demanding separate state",
      "Time pressure for rapid transition"
    ],
    outcome: "mixed",
    outcomeSummary: "Created independent India and Pakistan but triggered massive violence and displacement affecting millions.",
    fullDescription: "The partition of British India into independent India and Pakistan was rushed through in 1947. While achieving independence, the hastily drawn borders triggered one of history's largest mass migrations and communal violence claiming hundreds of thousands of lives.",
    consequences: [
      "Independence achieved for both nations",
      "10-20 million people displaced",
      "500,000 to 2 million killed in violence",
      "Kashmir conflict initiated",
      "Lasting Indo-Pakistani tensions"
    ],
    keyFigures: ["Lord Mountbatten", "Jawaharlal Nehru", "Muhammad Ali Jinnah", "Mahatma Gandhi"],
    sources: ["British Library India Office Records", "National Archives of India"]
  },
  {
    id: "12",
    name: "Emancipation Proclamation",
    year: 1863,
    category: "social",
    conditions: [
      "Civil War turning against Union initially",
      "Need to undermine Confederate economy",
      "Growing abolitionist pressure",
      "Strategic value of freeing enslaved people"
    ],
    outcome: "positive",
    outcomeSummary: "Freed enslaved people in Confederate states and transformed Civil War into fight for human freedom.",
    fullDescription: "President Lincoln's Emancipation Proclamation declared all enslaved people in Confederate states to be free. While limited in immediate practical effect, it fundamentally changed the war's character and paved the way for the 13th Amendment.",
    consequences: [
      "3.5 million enslaved people legally freed",
      "Transformed Civil War's moral character",
      "Enabled Black soldiers to join Union Army",
      "Prevented European recognition of Confederacy",
      "Led to 13th Amendment ending all slavery"
    ],
    keyFigures: ["Abraham Lincoln", "Frederick Douglass", "William Seward"],
    sources: ["National Archives", "Lincoln Presidential Library", "Smithsonian"]
  }
];

export const categories = [
  { value: 'all', label: 'All Categories' },
  { value: 'political', label: 'Political' },
  { value: 'military', label: 'Military' },
  { value: 'economic', label: 'Economic' },
  { value: 'scientific', label: 'Scientific' },
  { value: 'social', label: 'Social' },
] as const;

export const outcomes = [
  { value: 'all', label: 'All Outcomes' },
  { value: 'positive', label: 'Positive' },
  { value: 'negative', label: 'Negative' },
  { value: 'mixed', label: 'Mixed' },
] as const;

export const timePeriods = [
  { value: 'all', label: 'All Time Periods' },
  { value: '1800-1850', label: '1800-1850' },
  { value: '1851-1900', label: '1851-1900' },
  { value: '1901-1950', label: '1901-1950' },
  { value: '1951-2000', label: '1951-2000' },
] as const;
