import { Play, RotateCcw, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SimulationNode } from '@/components/SimulationNode';
import { WorkflowNode } from '@/types/workflow';
import { SimulationState } from '@/types/workflow';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface SimulationTabProps {
  savedNodes: WorkflowNode[] | null;
  simulationState: SimulationState;
  canStartSimulation: boolean;
  isSimulationComplete: boolean;
  onStartSimulation: () => void;
  onApproveStep: () => void;
  onResetSimulation: () => void;
}

export function SimulationTab({
  savedNodes,
  simulationState,
  canStartSimulation,
  isSimulationComplete,
  onStartSimulation,
  onApproveStep,
  onResetSimulation,
}: SimulationTabProps) {
  const { isRunning, currentStepIndex, stepStatuses } = simulationState;

  // No saved configuration
  if (!canStartSimulation) {
    return (
      <div className="text-center py-12 bg-muted/50 rounded-lg border-2 border-dashed">
        <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="font-semibold text-lg mb-2">No Configuration Saved</h3>
        <p className="text-muted-foreground max-w-md mx-auto">
          Please save your workflow configuration in the Configuration tab before running a simulation.
        </p>
      </div>
    );
  }

  // Simulation not started
  if (!isRunning && stepStatuses.length === 0) {
    return (
      <div className="space-y-6">
        <Alert className="border-primary/50 bg-primary/5">
          <Play className="h-4 w-4 text-primary" />
          <AlertDescription>
            Your workflow has {savedNodes!.length} step{savedNodes!.length !== 1 ? 's' : ''}. Start the simulation to test the approval flow.
          </AlertDescription>
        </Alert>

        <div className="text-center py-8">
          <Button size="lg" onClick={onStartSimulation}>
            <Play className="w-5 h-5 mr-2" />
            Start Simulation
          </Button>
        </div>

        {/* Preview of steps */}
        <div className="space-y-0 opacity-60">
          {savedNodes!.map((node, index) => (
            <SimulationNode
              key={node.id}
              node={node}
              index={index}
              status="idle"
            />
          ))}
        </div>
      </div>
    );
  }

  // Simulation complete
  if (isSimulationComplete) {
    return (
      <div className="space-y-6">
        <Alert className="border-success/50 bg-success/10">
          <CheckCircle2 className="h-4 w-4 text-success" />
          <AlertDescription className="text-success">
            Workflow completed successfully! All {savedNodes!.length} steps have been approved.
          </AlertDescription>
        </Alert>

        <div className="space-y-0">
          {savedNodes!.map((node, index) => (
            <SimulationNode
              key={node.id}
              node={node}
              index={index}
              status={stepStatuses[index]}
            />
          ))}
        </div>

        <div className="text-center pt-4">
          <Button variant="outline" onClick={onResetSimulation}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset & Run Again
          </Button>
        </div>
      </div>
    );
  }

  // Simulation in progress
  const currentNode = savedNodes![currentStepIndex];

  return (
    <div className="space-y-6">
      {/* Current step info */}
      <Alert className="border-primary/50 bg-primary/5">
        <AlertDescription>
          <span className="font-semibold">Step {currentStepIndex + 1} of {savedNodes!.length}:</span>{' '}
          Awaiting approval from <span className="font-medium">{currentNode.approver}</span> for "{currentNode.name}"
        </AlertDescription>
      </Alert>

      {/* Workflow visualization */}
      <div className="space-y-0">
        {savedNodes!.map((node, index) => (
          <SimulationNode
            key={node.id}
            node={node}
            index={index}
            status={stepStatuses[index]}
          />
        ))}
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-center gap-3 pt-4">
        <Button variant="outline" onClick={onResetSimulation}>
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
        <Button onClick={onApproveStep} size="lg">
          <CheckCircle2 className="w-5 h-5 mr-2" />
          Approve Step {currentStepIndex + 1}
        </Button>
      </div>
    </div>
  );
}
