import { useState, useCallback } from 'react';
import { Plus, Save, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { WorkflowNode } from '@/components/WorkflowNode';
import { WorkflowNode as WorkflowNodeType } from '@/types/workflow';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface ConfigurationTabProps {
  nodes: WorkflowNodeType[];
  hasUnsavedChanges: boolean;
  onAddNode: () => void;
  onUpdateNode: (id: string, updates: Partial<WorkflowNodeType>) => void;
  onDeleteNode: (id: string) => void;
  onReorderNodes: (fromIndex: number, toIndex: number) => void;
  onSave: () => boolean;
}

export function ConfigurationTab({
  nodes,
  hasUnsavedChanges,
  onAddNode,
  onUpdateNode,
  onDeleteNode,
  onReorderNodes,
  onSave,
}: ConfigurationTabProps) {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const handleDragStart = useCallback((e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex !== null && draggedIndex !== index) {
      setDragOverIndex(index);
    }
  }, [draggedIndex]);

  const handleDragEnd = useCallback(() => {
    if (draggedIndex !== null && dragOverIndex !== null && draggedIndex !== dragOverIndex) {
      onReorderNodes(draggedIndex, dragOverIndex);
    }
    setDraggedIndex(null);
    setDragOverIndex(null);
  }, [draggedIndex, dragOverIndex, onReorderNodes]);

  return (
    <div className="space-y-6">
      {/* Unsaved changes alert */}
      {hasUnsavedChanges && nodes.length > 0 && (
        <Alert variant="default" className="border-warning/50 bg-warning/10">
          <AlertCircle className="h-4 w-4 text-warning" />
          <AlertDescription className="text-warning-foreground">
            You have unsaved changes. Save your configuration to enable simulation.
          </AlertDescription>
        </Alert>
      )}

      {/* Workflow nodes */}
      <div className="space-y-0">
        {nodes.length === 0 ? (
          <div className="text-center py-12 bg-muted/50 rounded-lg border-2 border-dashed">
            <p className="text-muted-foreground mb-4">
              No workflow steps yet. Add your first step to get started.
            </p>
            <Button onClick={onAddNode} variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Add First Step
            </Button>
          </div>
        ) : (
          nodes.map((node, index) => (
            <WorkflowNode
              key={node.id}
              node={node}
              index={index}
              onUpdate={onUpdateNode}
              onDelete={onDeleteNode}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDragEnd={handleDragEnd}
              isDragging={draggedIndex === index}
              isDragOver={dragOverIndex === index}
            />
          ))
        )}
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-3 pt-4 border-t">
        <Button onClick={onAddNode} variant="outline" className="flex-1 sm:flex-none">
          <Plus className="w-4 h-4 mr-2" />
          Add Step
        </Button>
        <Button 
          onClick={onSave} 
          disabled={nodes.length === 0}
          className="flex-1 sm:flex-none"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Configuration
        </Button>
      </div>

      {/* Help text */}
      <p className="text-xs text-muted-foreground">
        Drag steps to reorder them. Each step requires a name and approver.
      </p>
    </div>
  );
}
