import { GripVertical, Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { WorkflowNode as WorkflowNodeType } from '@/types/workflow';
import { cn } from '@/lib/utils';

interface WorkflowNodeProps {
  node: WorkflowNodeType;
  index: number;
  onUpdate: (id: string, updates: Partial<WorkflowNodeType>) => void;
  onDelete: (id: string) => void;
  onDragStart: (e: React.DragEvent, index: number) => void;
  onDragOver: (e: React.DragEvent, index: number) => void;
  onDragEnd: () => void;
  isDragging: boolean;
  isDragOver: boolean;
}

export function WorkflowNode({
  node,
  index,
  onUpdate,
  onDelete,
  onDragStart,
  onDragOver,
  onDragEnd,
  isDragging,
  isDragOver,
}: WorkflowNodeProps) {
  return (
    <div className="animate-fade-in">
      {/* Connector line */}
      {index > 0 && <div className="workflow-connector" />}
      
      {/* Node card */}
      <div
        draggable
        onDragStart={(e) => onDragStart(e, index)}
        onDragOver={(e) => onDragOver(e, index)}
        onDragEnd={onDragEnd}
        className={cn(
          'group relative bg-card rounded-lg border p-4 transition-all duration-200',
          'workflow-node-shadow hover:workflow-node-shadow-hover',
          isDragging && 'opacity-50 scale-95',
          isDragOver && 'ring-2 ring-primary ring-offset-2'
        )}
      >
        {/* Step number badge */}
        <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-semibold flex items-center justify-center">
          {index + 1}
        </div>

        <div className="flex items-start gap-3 pl-4">
          {/* Drag handle */}
          <div className="drag-handle p-1 -ml-2 text-muted-foreground hover:text-foreground transition-colors">
            <GripVertical className="w-4 h-4" />
          </div>

          {/* Form fields */}
          <div className="flex-1 space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Step Name
              </label>
              <Input
                placeholder="e.g., Manager Review"
                value={node.name}
                onChange={(e) => onUpdate(node.id, { name: e.target.value })}
                className="h-9"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Approver
              </label>
              <Input
                placeholder="e.g., John Smith"
                value={node.approver}
                onChange={(e) => onUpdate(node.id, { approver: e.target.value })}
                className="h-9"
              />
            </div>
          </div>

          {/* Delete button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(node.id)}
            className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
