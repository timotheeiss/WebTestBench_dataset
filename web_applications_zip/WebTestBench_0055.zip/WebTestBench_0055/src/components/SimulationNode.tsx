import { Check, Clock, CircleDot } from 'lucide-react';
import { WorkflowNode } from '@/types/workflow';
import { SimulationStatus } from '@/types/workflow';
import { cn } from '@/lib/utils';

interface SimulationNodeProps {
  node: WorkflowNode;
  index: number;
  status: SimulationStatus;
}

const statusConfig = {
  pending: {
    icon: Clock,
    bgClass: 'bg-muted',
    iconClass: 'text-muted-foreground',
    borderClass: 'border-muted',
    label: 'Pending',
    labelClass: 'text-muted-foreground',
  },
  current: {
    icon: CircleDot,
    bgClass: 'bg-primary/10',
    iconClass: 'text-primary',
    borderClass: 'border-primary',
    label: 'Awaiting Approval',
    labelClass: 'text-primary',
  },
  approved: {
    icon: Check,
    bgClass: 'bg-success/10',
    iconClass: 'text-success',
    borderClass: 'border-success',
    label: 'Approved',
    labelClass: 'text-success',
  },
  idle: {
    icon: Clock,
    bgClass: 'bg-muted',
    iconClass: 'text-muted-foreground',
    borderClass: 'border-muted',
    label: 'Not Started',
    labelClass: 'text-muted-foreground',
  },
};

export function SimulationNode({ node, index, status }: SimulationNodeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className="animate-slide-in" style={{ animationDelay: `${index * 50}ms` }}>
      {/* Connector line */}
      {index > 0 && (
        <div
          className={cn(
            'w-0.5 h-8 mx-auto transition-colors duration-300',
            status === 'approved' || status === 'current'
              ? 'bg-primary'
              : 'bg-border'
          )}
        />
      )}

      {/* Node card */}
      <div
        className={cn(
          'relative rounded-lg border-2 p-4 transition-all duration-300',
          config.bgClass,
          config.borderClass,
          status === 'current' && 'shadow-lg shadow-primary/20'
        )}
      >
        {/* Step number and status icon */}
        <div className="flex items-center gap-3 mb-3">
          <div
            className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm transition-all duration-300',
              status === 'approved'
                ? 'bg-success text-success-foreground'
                : status === 'current'
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted-foreground/20 text-muted-foreground'
            )}
          >
            {status === 'approved' ? (
              <Check className="w-4 h-4" />
            ) : (
              index + 1
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="font-semibold text-foreground">{node.name}</h3>
            <p className="text-sm text-muted-foreground">
              Approver: {node.approver}
            </p>
          </div>

          {/* Status indicator */}
          <div className="flex items-center gap-2">
            {status === 'current' && (
              <span className="relative flex h-3 w-3">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
              </span>
            )}
            <Icon className={cn('w-5 h-5', config.iconClass)} />
          </div>
        </div>

        {/* Status label */}
        <div
          className={cn(
            'text-xs font-medium uppercase tracking-wide',
            config.labelClass
          )}
        >
          {config.label}
        </div>
      </div>
    </div>
  );
}
