import { useState, useCallback, useMemo } from 'react';
import { WorkflowNode, WorkflowState, SimulationState, SimulationStatus } from '@/types/workflow';
import { toast } from '@/hooks/use-toast';

const generateId = () => Math.random().toString(36).substring(2, 9);

// Default sample data
const defaultNodes: WorkflowNode[] = [
  { id: generateId(), name: 'Manager Review', approver: 'John Smith' },
  { id: generateId(), name: 'Finance Approval', approver: 'Sarah Johnson' },
  { id: generateId(), name: 'Final Sign-off', approver: 'Michael Chen' },
];

export function useWorkflow() {
  const [workflowState, setWorkflowState] = useState<WorkflowState>({
    nodes: defaultNodes,
    savedNodes: null,
    hasUnsavedChanges: true,
  });

  const [simulationState, setSimulationState] = useState<SimulationState>({
    isRunning: false,
    currentStepIndex: -1,
    stepStatuses: [],
  });

  // Configuration actions
  const addNode = useCallback(() => {
    const newNode: WorkflowNode = {
      id: generateId(),
      name: '',
      approver: '',
    };
    setWorkflowState((prev) => ({
      ...prev,
      nodes: [...prev.nodes, newNode],
      hasUnsavedChanges: true,
    }));
  }, []);

  const updateNode = useCallback((id: string, updates: Partial<WorkflowNode>) => {
    setWorkflowState((prev) => ({
      ...prev,
      nodes: prev.nodes.map((node) =>
        node.id === id ? { ...node, ...updates } : node
      ),
      hasUnsavedChanges: true,
    }));
  }, []);

  const deleteNode = useCallback((id: string) => {
    setWorkflowState((prev) => {
      if (prev.nodes.length <= 1) {
        toast({
          title: 'Cannot Delete',
          description: 'Workflow must have at least one step.',
          variant: 'destructive',
        });
        return prev;
      }
      return {
        ...prev,
        nodes: prev.nodes.filter((node) => node.id !== id),
        hasUnsavedChanges: true,
      };
    });
  }, []);

  const reorderNodes = useCallback((fromIndex: number, toIndex: number) => {
    setWorkflowState((prev) => {
      const newNodes = [...prev.nodes];
      const [movedNode] = newNodes.splice(fromIndex, 1);
      newNodes.splice(toIndex, 0, movedNode);
      return {
        ...prev,
        nodes: newNodes,
        hasUnsavedChanges: true,
      };
    });
  }, []);

  const validateWorkflow = useCallback((): boolean => {
    const { nodes } = workflowState;
    
    if (nodes.length === 0) {
      toast({
        title: 'Validation Error',
        description: 'Please add at least one workflow step.',
        variant: 'destructive',
      });
      return false;
    }

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (!node.name.trim()) {
        toast({
          title: 'Validation Error',
          description: `Step ${i + 1} is missing a name.`,
          variant: 'destructive',
        });
        return false;
      }
      if (!node.approver.trim()) {
        toast({
          title: 'Validation Error',
          description: `Step ${i + 1} "${node.name}" is missing an approver.`,
          variant: 'destructive',
        });
        return false;
      }
    }

    return true;
  }, [workflowState.nodes]);

  const saveConfiguration = useCallback(() => {
    if (!validateWorkflow()) return false;

    setWorkflowState((prev) => ({
      ...prev,
      savedNodes: [...prev.nodes],
      hasUnsavedChanges: false,
    }));

    // Reset simulation when config is saved
    setSimulationState({
      isRunning: false,
      currentStepIndex: -1,
      stepStatuses: [],
    });

    toast({
      title: 'Configuration Saved',
      description: 'Your workflow has been saved successfully.',
    });

    return true;
  }, [validateWorkflow]);

  // Simulation actions
  const canStartSimulation = useMemo(() => {
    return workflowState.savedNodes !== null && workflowState.savedNodes.length > 0;
  }, [workflowState.savedNodes]);

  const startSimulation = useCallback(() => {
    if (!canStartSimulation) {
      toast({
        title: 'Cannot Start Simulation',
        description: 'Please save your workflow configuration first.',
        variant: 'destructive',
      });
      return;
    }

    const nodeCount = workflowState.savedNodes!.length;
    setSimulationState({
      isRunning: true,
      currentStepIndex: 0,
      stepStatuses: Array(nodeCount).fill('pending').map((_, i) => 
        i === 0 ? 'current' : 'pending'
      ) as SimulationStatus[],
    });

    toast({
      title: 'Simulation Started',
      description: 'Advance through each step to test your workflow.',
    });
  }, [canStartSimulation, workflowState.savedNodes]);

  const approveCurrentStep = useCallback(() => {
    setSimulationState((prev) => {
      if (!prev.isRunning) return prev;

      const newStatuses = [...prev.stepStatuses];
      newStatuses[prev.currentStepIndex] = 'approved';

      const nextIndex = prev.currentStepIndex + 1;
      const isComplete = nextIndex >= newStatuses.length;

      if (!isComplete) {
        newStatuses[nextIndex] = 'current';
      }

      if (isComplete) {
        toast({
          title: 'Workflow Complete!',
          description: 'All steps have been approved successfully.',
        });
      }

      return {
        ...prev,
        currentStepIndex: isComplete ? prev.currentStepIndex : nextIndex,
        stepStatuses: newStatuses,
        isRunning: !isComplete,
      };
    });
  }, []);

  const resetSimulation = useCallback(() => {
    setSimulationState({
      isRunning: false,
      currentStepIndex: -1,
      stepStatuses: [],
    });
  }, []);

  const isSimulationComplete = useMemo(() => {
    return (
      simulationState.stepStatuses.length > 0 &&
      simulationState.stepStatuses.every((s) => s === 'approved')
    );
  }, [simulationState.stepStatuses]);

  return {
    // Workflow state
    nodes: workflowState.nodes,
    savedNodes: workflowState.savedNodes,
    hasUnsavedChanges: workflowState.hasUnsavedChanges,
    
    // Configuration actions
    addNode,
    updateNode,
    deleteNode,
    reorderNodes,
    saveConfiguration,
    
    // Simulation state
    simulationState,
    canStartSimulation,
    isSimulationComplete,
    
    // Simulation actions
    startSimulation,
    approveCurrentStep,
    resetSimulation,
  };
}
