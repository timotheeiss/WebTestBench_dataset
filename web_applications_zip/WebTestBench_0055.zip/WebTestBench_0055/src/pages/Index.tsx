import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ConfigurationTab } from '@/components/ConfigurationTab';
import { SimulationTab } from '@/components/SimulationTab';
import { useWorkflow } from '@/hooks/useWorkflow';
import { Settings2, PlayCircle, Workflow } from 'lucide-react';
import { cn } from '@/lib/utils';

const Index = () => {
  const [activeTab, setActiveTab] = useState<string>('configuration');
  
  const {
    nodes,
    savedNodes,
    hasUnsavedChanges,
    addNode,
    updateNode,
    deleteNode,
    reorderNodes,
    saveConfiguration,
    simulationState,
    canStartSimulation,
    isSimulationComplete,
    startSimulation,
    approveCurrentStep,
    resetSimulation,
  } = useWorkflow();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container max-w-3xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
              <Workflow className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Workflow Builder</h1>
              <p className="text-sm text-muted-foreground">
                Configure and simulate approval workflows
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container max-w-3xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 h-12">
            <TabsTrigger 
              value="configuration" 
              className={cn(
                "flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              )}
            >
              <Settings2 className="w-4 h-4" />
              Configuration
              {hasUnsavedChanges && nodes.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-warning" />
              )}
            </TabsTrigger>
            <TabsTrigger 
              value="simulation"
              className={cn(
                "flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              )}
            >
              <PlayCircle className="w-4 h-4" />
              Simulation
              {simulationState.isRunning && (
                <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="configuration" className="mt-6 animate-fade-in">
            <ConfigurationTab
              nodes={nodes}
              hasUnsavedChanges={hasUnsavedChanges}
              onAddNode={addNode}
              onUpdateNode={updateNode}
              onDeleteNode={deleteNode}
              onReorderNodes={reorderNodes}
              onSave={saveConfiguration}
            />
          </TabsContent>

          <TabsContent value="simulation" className="mt-6 animate-fade-in">
            <SimulationTab
              savedNodes={savedNodes}
              simulationState={simulationState}
              canStartSimulation={canStartSimulation}
              isSimulationComplete={isSimulationComplete}
              onStartSimulation={startSimulation}
              onApproveStep={approveCurrentStep}
              onResetSimulation={resetSimulation}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t mt-auto">
        <div className="container max-w-3xl mx-auto px-4 py-4">
          <p className="text-xs text-muted-foreground text-center">
            All data is stored locally in your browser. No backend required.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
