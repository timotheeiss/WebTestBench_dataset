export interface WorkflowNode {
  id: string;
  name: string;
  approver: string;
}

export interface WorkflowState {
  nodes: WorkflowNode[];
  savedNodes: WorkflowNode[] | null;
  hasUnsavedChanges: boolean;
}

export type SimulationStatus = 'pending' | 'current' | 'approved' | 'idle';

export interface SimulationState {
  isRunning: boolean;
  currentStepIndex: number;
  stepStatuses: SimulationStatus[];
}
