import { useUserData } from '@/context/UserDataContext';
import { Flame, Clock, Trophy, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export function StatsCard() {
  const { streak, totalMinutes, getSessionCount, getWeeklyData } = useUserData();
  const weeklyData = getWeeklyData();
  const maxMinutes = Math.max(...weeklyData.map((d) => d.minutes), 1);

  const stats = [
    {
      icon: Flame,
      label: 'Day Streak',
      value: streak,
      color: 'text-sunset',
      bg: 'bg-sunset-light',
    },
    {
      icon: Clock,
      label: 'Total Minutes',
      value: totalMinutes,
      color: 'text-sage',
      bg: 'bg-sage-light',
    },
    {
      icon: Trophy,
      label: 'Sessions',
      value: getSessionCount(),
      color: 'text-lavender',
      bg: 'bg-lavender-light',
    },
  ];

  return (
    <div className="bg-card rounded-2xl border border-border/50 shadow-card p-6">
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp className="w-5 h-5 text-sage" />
        <h3 className="font-display text-lg font-semibold text-foreground">Your Progress</h3>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <div className={cn('w-12 h-12 mx-auto mb-2 rounded-xl flex items-center justify-center', stat.bg)}>
              <stat.icon className={cn('w-6 h-6', stat.color)} />
            </div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Weekly Chart */}
      <div>
        <p className="text-sm font-medium text-foreground mb-3">This Week</p>
        <div className="flex items-end justify-between gap-2 h-24">
          {weeklyData.map((day, i) => (
            <div key={day.day} className="flex-1 flex flex-col items-center gap-1">
              <div
                className={cn(
                  'w-full rounded-t-md transition-all duration-300',
                  day.minutes > 0 ? 'bg-sage' : 'bg-muted'
                )}
                style={{
                  height: `${Math.max((day.minutes / maxMinutes) * 100, day.minutes > 0 ? 10 : 4)}%`,
                }}
              />
              <span className="text-xs text-muted-foreground">{day.day}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
