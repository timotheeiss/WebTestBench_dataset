import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, ActivityStep } from '@/data/activities';
import { useUserData } from '@/context/UserDataContext';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { Play, Pause, RotateCcw, X, CheckCircle2 } from 'lucide-react';

interface SessionPlayerProps {
  activity: Activity;
}

type PlayerState = 'ready' | 'playing' | 'paused' | 'completed';

export function SessionPlayer({ activity }: SessionPlayerProps) {
  const navigate = useNavigate();
  const { addCompletedSession } = useUserData();
  
  const [state, setState] = useState<PlayerState>('ready');
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [stepTimeRemaining, setStepTimeRemaining] = useState(0);
  const [totalElapsed, setTotalElapsed] = useState(0);

  const currentStep = activity.steps[currentStepIndex];
  const totalDuration = activity.steps.reduce((sum, step) => sum + step.duration, 0);
  const progress = (totalElapsed / totalDuration) * 100;

  const getStepAnimation = (step: ActivityStep) => {
    switch (step.type) {
      case 'breathe-in':
        return 'animate-breathe scale-110';
      case 'breathe-out':
        return 'animate-breathe scale-90';
      case 'hold':
        return 'animate-pulse-slow';
      default:
        return 'animate-float';
    }
  };

  const getStepColor = (step: ActivityStep) => {
    switch (step.type) {
      case 'breathe-in':
        return 'from-sky to-sage';
      case 'breathe-out':
        return 'from-sage to-lavender';
      case 'hold':
        return 'from-lavender to-sky';
      case 'visualize':
        return 'from-sunset to-lavender';
      default:
        return 'from-sage-light to-sky-light';
    }
  };

  const moveToNextStep = useCallback(() => {
    if (currentStepIndex < activity.steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
      setStepTimeRemaining(activity.steps[currentStepIndex + 1].duration);
    } else {
      setState('completed');
      addCompletedSession(activity.id, activity.duration);
    }
  }, [currentStepIndex, activity, addCompletedSession]);

  useEffect(() => {
    if (state !== 'playing') return;

    const interval = setInterval(() => {
      setStepTimeRemaining((prev) => {
        if (prev <= 1) {
          moveToNextStep();
          return 0;
        }
        return prev - 1;
      });
      setTotalElapsed((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [state, moveToNextStep]);

  const handleStart = () => {
    setState('playing');
    setStepTimeRemaining(activity.steps[0].duration);
  };

  const handlePause = () => {
    setState((prev) => (prev === 'playing' ? 'paused' : 'playing'));
  };

  const handleReset = () => {
    setState('ready');
    setCurrentStepIndex(0);
    setStepTimeRemaining(0);
    setTotalElapsed(0);
  };

  const handleClose = () => {
    navigate(-1);
  };

  if (state === 'completed') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-hero">
        <div className="text-center animate-fade-in">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-sage flex items-center justify-center shadow-glow">
            <CheckCircle2 className="w-12 h-12 text-primary-foreground" />
          </div>
          <h2 className="font-display text-3xl font-semibold text-foreground mb-2">
            Session Complete
          </h2>
          <p className="text-muted-foreground mb-8">
            Great job! You completed {activity.duration} minutes of {activity.title.toLowerCase()}.
          </p>
          <div className="flex gap-4 justify-center">
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Repeat
            </Button>
            <Button variant="sage" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn('min-h-screen flex flex-col', activity.imageGradient)}>
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <Button variant="glass" size="icon" onClick={handleClose}>
          <X className="w-5 h-5" />
        </Button>
        <div className="text-center">
          <h1 className="font-display text-lg font-medium text-foreground">
            {activity.title}
          </h1>
          <p className="text-sm text-muted-foreground">
            Step {currentStepIndex + 1} of {activity.steps.length}
          </p>
        </div>
        <div className="w-10" />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        {state === 'ready' ? (
          <div className="text-center animate-fade-in">
            <div className="w-40 h-40 mx-auto mb-8 rounded-full bg-gradient-to-br from-sage to-sky flex items-center justify-center shadow-glow animate-breathe">
              <Play className="w-16 h-16 text-primary-foreground ml-2" />
            </div>
            <h2 className="font-display text-2xl font-semibold text-foreground mb-2">
              Ready to begin?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-sm">
              Find a comfortable position and prepare for {activity.duration} minutes of {activity.title.toLowerCase()}.
            </p>
            <Button variant="sage" size="xl" onClick={handleStart}>
              <Play className="w-5 h-5 mr-2" />
              Start Session
            </Button>
          </div>
        ) : (
          <div className="text-center animate-fade-in w-full max-w-md">
            {/* Breathing Circle */}
            <div
              className={cn(
                'w-48 h-48 mx-auto mb-10 rounded-full bg-gradient-to-br flex items-center justify-center shadow-glow transition-all duration-1000',
                getStepColor(currentStep),
                state === 'playing' && getStepAnimation(currentStep)
              )}
            >
              <span className="text-5xl font-display font-bold text-primary-foreground">
                {stepTimeRemaining}
              </span>
            </div>

            {/* Instruction */}
            <p className="text-xl font-medium text-foreground mb-2">
              {currentStep.instruction}
            </p>
            <p className="text-sm text-muted-foreground capitalize mb-8">
              {currentStep.type.replace('-', ' ')}
            </p>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <Button variant="outline" size="icon" onClick={handleReset}>
                <RotateCcw className="w-5 h-5" />
              </Button>
              <Button
                variant="sage"
                size="xl"
                onClick={handlePause}
                className="w-16 h-16 rounded-full"
              >
                {state === 'playing' ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6 ml-0.5" />
                )}
              </Button>
              <div className="w-10" />
            </div>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      {state !== 'ready' && (
        <div className="p-6">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between mt-2 text-sm text-muted-foreground">
            <span>{Math.floor(totalElapsed / 60)}:{(totalElapsed % 60).toString().padStart(2, '0')}</span>
            <span>{Math.floor(totalDuration / 60)}:{(totalDuration % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>
      )}
    </div>
  );
}
