import { Link } from 'react-router-dom';
import { Activity, goalLabels, typeLabels, goalColors } from '@/data/activities';
import { useUserData } from '@/context/UserDataContext';
import { Button } from '@/components/ui/button';
import { Heart, Clock, Play } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActivityCardProps {
  activity: Activity;
  featured?: boolean;
}

export function ActivityCard({ activity, featured }: ActivityCardProps) {
  const { isFavorite, toggleFavorite } = useUserData();
  const favorite = isFavorite(activity.id);

  return (
    <div
      className={cn(
        'group relative rounded-2xl overflow-hidden bg-card border border-border/50 shadow-card transition-all duration-300 hover:shadow-glow hover:-translate-y-1',
        featured && 'md:col-span-2 md:row-span-2'
      )}
    >
      <div className={cn('h-32 md:h-40', activity.imageGradient, featured && 'md:h-56')} />
      
      <Button
        variant="glass"
        size="icon"
        className="absolute top-3 right-3 h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={(e) => {
          e.preventDefault();
          toggleFavorite(activity.id);
        }}
      >
        <Heart className={cn('w-4 h-4', favorite && 'fill-current text-destructive')} />
      </Button>

      <div className="p-5">
        <div className="flex items-center gap-2 mb-2">
          <span className={cn('px-2.5 py-0.5 rounded-full text-xs font-medium', goalColors[activity.goal])}>
            {goalLabels[activity.goal]}
          </span>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
            {typeLabels[activity.type]}
          </span>
        </div>

        <h3 className={cn('font-display font-semibold text-foreground mb-1', featured ? 'text-2xl' : 'text-lg')}>
          {activity.title}
        </h3>
        
        <p className={cn('text-muted-foreground mb-4 line-clamp-2', featured ? 'text-base' : 'text-sm')}>
          {activity.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{activity.duration} min</span>
          </div>

          <Button variant="sage" size="sm" asChild>
            <Link to={`/session/${activity.id}`}>
              <Play className="w-4 h-4 mr-1" />
              Start
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
