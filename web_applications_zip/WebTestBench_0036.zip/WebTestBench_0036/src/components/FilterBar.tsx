import { Goal, Duration, ActivityType, goalLabels, typeLabels } from '@/data/activities';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Clock, Target, Sparkles } from 'lucide-react';

interface FilterBarProps {
  selectedGoal: Goal | null;
  selectedDuration: Duration | null;
  selectedType: ActivityType | null;
  onGoalChange: (goal: Goal | null) => void;
  onDurationChange: (duration: Duration | null) => void;
  onTypeChange: (type: ActivityType | null) => void;
}

const durations: Duration[] = [5, 10, 15, 20, 30];
const goals: Goal[] = ['calm', 'focus', 'sleep', 'stress', 'energy'];
const types: ActivityType[] = ['meditation', 'breathing', 'relaxation'];

export function FilterBar({
  selectedGoal,
  selectedDuration,
  selectedType,
  onGoalChange,
  onDurationChange,
  onTypeChange,
}: FilterBarProps) {
  return (
    <div className="space-y-4 p-4 bg-card/60 backdrop-blur-sm rounded-2xl border border-border/50">
      {/* Goals */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Target className="w-4 h-4 text-sage" />
          <span className="text-sm font-medium text-foreground">Goal</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedGoal === null ? 'sage' : 'outline'}
            size="sm"
            onClick={() => onGoalChange(null)}
          >
            All
          </Button>
          {goals.map((goal) => (
            <Button
              key={goal}
              variant={selectedGoal === goal ? 'sage' : 'outline'}
              size="sm"
              onClick={() => onGoalChange(goal)}
            >
              {goalLabels[goal]}
            </Button>
          ))}
        </div>
      </div>

      {/* Duration */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-4 h-4 text-sage" />
          <span className="text-sm font-medium text-foreground">Duration</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedDuration === null ? 'sage' : 'outline'}
            size="sm"
            onClick={() => onDurationChange(null)}
          >
            Any
          </Button>
          {durations.map((duration) => (
            <Button
              key={duration}
              variant={selectedDuration === duration ? 'sage' : 'outline'}
              size="sm"
              onClick={() => onDurationChange(duration)}
            >
              {duration} min
            </Button>
          ))}
        </div>
      </div>

      {/* Type */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-sage" />
          <span className="text-sm font-medium text-foreground">Type</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedType === null ? 'sage' : 'outline'}
            size="sm"
            onClick={() => onTypeChange(null)}
          >
            All
          </Button>
          {types.map((type) => (
            <Button
              key={type}
              variant={selectedType === type ? 'sage' : 'outline'}
              size="sm"
              onClick={() => onTypeChange(type)}
            >
              {typeLabels[type]}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
