import { useAuth } from '@/context/AuthContext';
import { useUserData } from '@/context/UserDataContext';
import { Header } from '@/components/Header';
import { StatsCard } from '@/components/StatsCard';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { LogOut, Calendar, Award } from 'lucide-react';

export default function Profile() {
  const { user, logout } = useAuth();
  const { streak, totalMinutes, getSessionCount } = useUserData();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container max-w-2xl py-8 px-4">
        {/* Profile Header */}
        <div className="bg-card rounded-3xl border border-border/50 shadow-card p-8 mb-6 text-center animate-fade-in">
          <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-sage/30">
            <AvatarFallback className="bg-sage text-primary-foreground text-3xl font-display">
              {user?.name?.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <h1 className="font-display text-2xl font-semibold text-foreground mb-1">
            {user?.name}
          </h1>
          <p className="text-muted-foreground">{user?.email}</p>

          <div className="flex items-center justify-center gap-6 mt-6 pt-6 border-t border-border">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-sunset mb-1">
                <Calendar className="w-4 h-4" />
                <span className="font-bold text-lg">{streak}</span>
              </div>
              <span className="text-xs text-muted-foreground">Day Streak</span>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-sage mb-1">
                <Award className="w-4 h-4" />
                <span className="font-bold text-lg">{getSessionCount()}</span>
              </div>
              <span className="text-xs text-muted-foreground">Sessions</span>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg text-lavender mb-1">{totalMinutes}</div>
              <span className="text-xs text-muted-foreground">Minutes</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <StatsCard />
        </div>

        {/* Actions */}
        <div className="bg-card rounded-2xl border border-border/50 shadow-card p-4 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <Button
            variant="ghost"
            className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-3" />
            Sign out
          </Button>
        </div>
      </main>
    </div>
  );
}
