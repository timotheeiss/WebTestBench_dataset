import { useMemo } from 'react';
import { Header } from '@/components/Header';
import { ActivityCard } from '@/components/ActivityCard';
import { useUserData } from '@/context/UserDataContext';
import { activities } from '@/data/activities';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export default function Favorites() {
  const { favorites } = useUserData();

  const favoriteActivities = useMemo(() => {
    return activities.filter((a) => favorites.includes(a.id));
  }, [favorites]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 px-4">
        <div className="mb-8 animate-fade-in">
          <h1 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
            Your Favorites
          </h1>
          <p className="text-lg text-muted-foreground">
            Quick access to your saved activities
          </p>
        </div>

        {favoriteActivities.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl border border-border/50 animate-fade-in">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Heart className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-display font-semibold text-foreground mb-2">
              No favorites yet
            </h2>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Tap the heart icon on any activity to save it here for quick access.
            </p>
            <Button variant="sage" asChild>
              <Link to="/dashboard">Browse Activities</Link>
            </Button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in">
            {favoriteActivities.map((activity) => (
              <ActivityCard key={activity.id} activity={activity} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
