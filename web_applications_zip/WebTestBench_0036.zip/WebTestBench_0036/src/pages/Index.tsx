import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { activities, goalLabels } from '@/data/activities';
import { Play, Heart, BarChart3, Wind, Moon, Brain, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

const features = [
  {
    icon: Wind,
    title: 'Breathing Exercises',
    description: 'Powerful techniques to calm your nervous system instantly.',
    color: 'text-sky',
    bg: 'bg-sky-light',
  },
  {
    icon: Moon,
    title: 'Sleep Meditations',
    description: 'Drift into deep, restorative sleep with guided journeys.',
    color: 'text-lavender',
    bg: 'bg-lavender-light',
  },
  {
    icon: Brain,
    title: 'Focus Sessions',
    description: 'Sharpen concentration and enter productive flow states.',
    color: 'text-sage',
    bg: 'bg-sage-light',
  },
  {
    icon: Sparkles,
    title: 'Track Progress',
    description: 'See your growth with streaks, stats, and weekly insights.',
    color: 'text-sunset',
    bg: 'bg-sunset-light',
  },
];

export default function Index() {
  const { isAuthenticated } = useAuth();

  const featuredActivities = activities.filter((a) => a.featured).slice(0, 3);

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="container py-16 md:py-24 px-4">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <h1 className="font-display text-4xl md:text-6xl font-semibold text-foreground mb-6 leading-tight">
              Find your calm,
              <span className="block text-gradient">one breath at a time</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto">
              Guided meditations, breathing exercises, and relaxation techniques to help you reduce stress, sleep better, and live mindfully.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <Button variant="sage" size="xl" asChild>
                  <Link to="/dashboard">
                    <Play className="w-5 h-5 mr-2" />
                    Go to Dashboard
                  </Link>
                </Button>
              ) : (
                <>
                  <Button variant="sage" size="xl" asChild>
                    <Link to="/register">
                      Get Started Free
                    </Link>
                  </Button>
                  <Button variant="outline" size="xl" asChild>
                    <Link to="/login">
                      Sign In
                    </Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="container py-16 px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div
                key={feature.title}
                className="bg-card rounded-2xl border border-border/50 shadow-card p-6 animate-fade-in hover:-translate-y-1 transition-transform duration-300"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center mb-4', feature.bg)}>
                  <feature.icon className={cn('w-6 h-6', feature.color)} />
                </div>
                <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Featured Activities */}
        <section className="container py-16 px-4">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl font-semibold text-foreground mb-3">
              Start with these
            </h2>
            <p className="text-muted-foreground">
              Popular activities loved by our community
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {featuredActivities.map((activity, i) => (
              <div
                key={activity.id}
                className="group bg-card rounded-2xl border border-border/50 shadow-card overflow-hidden animate-fade-in hover:shadow-glow hover:-translate-y-1 transition-all duration-300"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className={cn('h-32', activity.imageGradient)} />
                <div className="p-5">
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium bg-sage-light text-sage-dark mb-2">
                    {goalLabels[activity.goal]}
                  </span>
                  <h3 className="font-display text-lg font-semibold text-foreground mb-1">
                    {activity.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {activity.duration} minutes
                  </p>
                  <Button variant="sage" size="sm" className="w-full" asChild>
                    <Link to={isAuthenticated ? `/session/${activity.id}` : '/register'}>
                      <Play className="w-4 h-4 mr-1" />
                      Try Now
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        {!isAuthenticated && (
          <section className="container py-16 px-4">
            <div className="max-w-2xl mx-auto text-center bg-card rounded-3xl border border-border/50 shadow-card p-10 animate-fade-in">
              <h2 className="font-display text-2xl md:text-3xl font-semibold text-foreground mb-4">
                Ready to start your mindful journey?
              </h2>
              <p className="text-muted-foreground mb-6">
                Join thousands who have found peace, focus, and better sleep with Mindful.
              </p>
              <Button variant="sage" size="xl" asChild>
                <Link to="/register">
                  Create Free Account
                </Link>
              </Button>
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="container py-8 px-4 border-t border-border/50">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2024 Mindful. Find your calm.</p>
            <div className="flex items-center gap-4">
              <Link to="/" className="hover:text-foreground transition-colors">About</Link>
              <Link to="/" className="hover:text-foreground transition-colors">Privacy</Link>
              <Link to="/" className="hover:text-foreground transition-colors">Terms</Link>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
