import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/Header';
import { ActivityCard } from '@/components/ActivityCard';
import { FilterBar } from '@/components/FilterBar';
import { StatsCard } from '@/components/StatsCard';
import { activities, Goal, Duration, ActivityType } from '@/data/activities';
import { Button } from '@/components/ui/button';
import { Filter, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Dashboard() {
  const { user } = useAuth();
  const [showFilters, setShowFilters] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<Duration | null>(null);
  const [selectedType, setSelectedType] = useState<ActivityType | null>(null);

  const featuredActivities = activities.filter((a) => a.featured);
  
  const filteredActivities = useMemo(() => {
    return activities.filter((activity) => {
      if (selectedGoal && activity.goal !== selectedGoal) return false;
      if (selectedDuration && activity.duration !== selectedDuration) return false;
      if (selectedType && activity.type !== selectedType) return false;
      return true;
    });
  }, [selectedGoal, selectedDuration, selectedType]);

  const hasFilters = selectedGoal || selectedDuration || selectedType;

  const clearFilters = () => {
    setSelectedGoal(null);
    setSelectedDuration(null);
    setSelectedType(null);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 px-4">
        {/* Welcome Section */}
        <div className="mb-8 animate-fade-in">
          <h1 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
            {getGreeting()}, {user?.name?.split(' ')[0]}
          </h1>
          <p className="text-lg text-muted-foreground">
            What would you like to practice today?
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_320px] gap-8">
          {/* Main Content */}
          <div className="space-y-8">
            {/* Featured Section */}
            {!hasFilters && (
              <section>
                <h2 className="font-display text-xl font-semibold text-foreground mb-4">
                  Featured for You
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {featuredActivities.map((activity, i) => (
                    <ActivityCard key={activity.id} activity={activity} featured={i === 0} />
                  ))}
                </div>
              </section>
            )}

            {/* All Activities */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-xl font-semibold text-foreground">
                  {hasFilters ? 'Filtered Results' : 'All Activities'}
                  {hasFilters && (
                    <span className="ml-2 text-sm font-normal text-muted-foreground">
                      ({filteredActivities.length})
                    </span>
                  )}
                </h2>
                <div className="flex items-center gap-2">
                  {hasFilters && (
                    <Button variant="ghost" size="sm" onClick={clearFilters}>
                      <X className="w-4 h-4 mr-1" />
                      Clear
                    </Button>
                  )}
                  <Button
                    variant={showFilters ? 'sage' : 'outline'}
                    size="sm"
                    onClick={() => setShowFilters(!showFilters)}
                    className="lg:hidden"
                  >
                    <Filter className="w-4 h-4 mr-1" />
                    Filter
                  </Button>
                </div>
              </div>

              {/* Mobile Filters */}
              <div className={cn('lg:hidden mb-4', showFilters ? 'block' : 'hidden')}>
                <FilterBar
                  selectedGoal={selectedGoal}
                  selectedDuration={selectedDuration}
                  selectedType={selectedType}
                  onGoalChange={setSelectedGoal}
                  onDurationChange={setSelectedDuration}
                  onTypeChange={setSelectedType}
                />
              </div>

              {filteredActivities.length === 0 ? (
                <div className="text-center py-12 bg-card rounded-2xl border border-border/50">
                  <p className="text-muted-foreground mb-4">No activities match your filters.</p>
                  <Button variant="outline" onClick={clearFilters}>
                    Clear filters
                  </Button>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredActivities.map((activity) => (
                    <ActivityCard key={activity.id} activity={activity} />
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6 hidden lg:block">
            <StatsCard />
            <FilterBar
              selectedGoal={selectedGoal}
              selectedDuration={selectedDuration}
              selectedType={selectedType}
              onGoalChange={setSelectedGoal}
              onDurationChange={setSelectedDuration}
              onTypeChange={setSelectedType}
            />
          </aside>
        </div>
      </main>
    </div>
  );
}
