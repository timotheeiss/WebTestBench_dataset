import { useParams, Navigate } from 'react-router-dom';
import { activities } from '@/data/activities';
import { SessionPlayer } from '@/components/SessionPlayer';

export default function Session() {
  const { id } = useParams<{ id: string }>();
  const activity = activities.find((a) => a.id === id);

  if (!activity) {
    return <Navigate to="/dashboard" replace />;
  }

  return <SessionPlayer activity={activity} />;
}
