import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface CompletedSession {
  activityId: string;
  completedAt: string;
  duration: number;
}

interface UserData {
  favorites: string[];
  completedSessions: CompletedSession[];
  streak: number;
  lastSessionDate: string | null;
}

interface UserDataContextType {
  favorites: string[];
  completedSessions: CompletedSession[];
  streak: number;
  totalMinutes: number;
  toggleFavorite: (activityId: string) => void;
  isFavorite: (activityId: string) => boolean;
  addCompletedSession: (activityId: string, duration: number) => void;
  getSessionCount: () => number;
  getWeeklyData: () => { day: string; minutes: number }[];
}

const UserDataContext = createContext<UserDataContextType | undefined>(undefined);

const STORAGE_KEY = 'mindful_user_data';

const defaultUserData: UserData = {
  favorites: [],
  completedSessions: [],
  streak: 0,
  lastSessionDate: null,
};

// Generate some mock completed sessions for demo
const generateMockSessions = (): CompletedSession[] => {
  const sessions: CompletedSession[] = [];
  const now = new Date();
  
  // Add sessions for the past week
  for (let i = 6; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Random 1-3 sessions per day
    const sessionsPerDay = Math.floor(Math.random() * 3) + 1;
    for (let j = 0; j < sessionsPerDay; j++) {
      sessions.push({
        activityId: ['morning-calm', 'box-breathing', 'focus-flow', 'quick-calm'][Math.floor(Math.random() * 4)],
        completedAt: date.toISOString(),
        duration: [5, 10, 15, 20][Math.floor(Math.random() * 4)],
      });
    }
  }
  
  return sessions;
};

export function UserDataProvider({ children }: { children: ReactNode }) {
  const [userData, setUserData] = useState<UserData>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        // If invalid, use defaults with mock data
      }
    }
    return {
      ...defaultUserData,
      completedSessions: generateMockSessions(),
      favorites: ['morning-calm', 'box-breathing'],
      streak: 7,
      lastSessionDate: new Date().toISOString(),
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
  }, [userData]);

  const toggleFavorite = (activityId: string) => {
    setUserData((prev) => ({
      ...prev,
      favorites: prev.favorites.includes(activityId)
        ? prev.favorites.filter((id) => id !== activityId)
        : [...prev.favorites, activityId],
    }));
  };

  const isFavorite = (activityId: string) => userData.favorites.includes(activityId);

  const addCompletedSession = (activityId: string, duration: number) => {
    const now = new Date();
    const today = now.toDateString();
    const lastDate = userData.lastSessionDate ? new Date(userData.lastSessionDate).toDateString() : null;
    
    let newStreak = userData.streak;
    if (lastDate !== today) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      if (lastDate === yesterday.toDateString()) {
        newStreak += 1;
      } else if (lastDate !== today) {
        newStreak = 1;
      }
    }

    setUserData((prev) => ({
      ...prev,
      completedSessions: [
        ...prev.completedSessions,
        { activityId, completedAt: now.toISOString(), duration },
      ],
      streak: newStreak,
      lastSessionDate: now.toISOString(),
    }));
  };

  const getSessionCount = () => userData.completedSessions.length;

  const totalMinutes = userData.completedSessions.reduce((sum, s) => sum + s.duration, 0);

  const getWeeklyData = () => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const now = new Date();
    const weekData: { day: string; minutes: number }[] = [];

    for (let i = 6; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const dayStr = date.toDateString();
      
      const minutes = userData.completedSessions
        .filter((s) => new Date(s.completedAt).toDateString() === dayStr)
        .reduce((sum, s) => sum + s.duration, 0);

      weekData.push({
        day: days[date.getDay()],
        minutes,
      });
    }

    return weekData;
  };

  return (
    <UserDataContext.Provider
      value={{
        favorites: userData.favorites,
        completedSessions: userData.completedSessions,
        streak: userData.streak,
        totalMinutes,
        toggleFavorite,
        isFavorite,
        addCompletedSession,
        getSessionCount,
        getWeeklyData,
      }}
    >
      {children}
    </UserDataContext.Provider>
  );
}

export function useUserData() {
  const context = useContext(UserDataContext);
  if (context === undefined) {
    throw new Error('useUserData must be used within a UserDataProvider');
  }
  return context;
}
