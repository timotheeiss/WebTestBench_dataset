import { useState, useCallback } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TicketList } from '@/components/TicketList';
import { AssignmentManagement } from '@/components/AssignmentManagement';
import { HistoryRecords } from '@/components/HistoryRecords';
import { Ticket, TicketStatus, TicketNote, HistoryEntry } from '@/types/ticket';
import { initialTickets, employees, initialHistory } from '@/data/mockData';
import { ClipboardList, UserCog, History, Ticket as TicketIcon } from 'lucide-react';

const Index = () => {
  const [tickets, setTickets] = useState<Ticket[]>(initialTickets);
  const [history, setHistory] = useState<HistoryEntry[]>(initialHistory);

  const addHistoryEntry = useCallback((ticketId: string, action: string, performedBy: string, details?: string) => {
    const newEntry: HistoryEntry = {
      id: `hist-${Date.now()}`,
      ticketId,
      action,
      performedBy,
      timestamp: new Date(),
      details,
    };
    setHistory((prev) => [newEntry, ...prev]);
  }, []);

  const handleUpdateStatus = useCallback((ticketId: string, status: TicketStatus) => {
    setTickets((prev) =>
      prev.map((ticket) => {
        if (ticket.id !== ticketId) return ticket;
        
        const updates: Partial<Ticket> = {
          status,
          updatedAt: new Date(),
        };

        if (status === 'Resolved') {
          updates.resolvedAt = new Date();
        }
        if (status === 'Closed') {
          updates.closedAt = new Date();
        }

        return { ...ticket, ...updates };
      })
    );

    const ticket = tickets.find((t) => t.id === ticketId);
    const performedBy = ticket?.assigneeName || 'System';
    
    if (status === 'Resolved') {
      addHistoryEntry(ticketId, 'Ticket Resolved', performedBy, `Status changed to Resolved`);
    } else if (status === 'Closed') {
      addHistoryEntry(ticketId, 'Ticket Closed', performedBy, `Ticket closed and archived`);
    } else if (status === 'In Progress') {
      addHistoryEntry(ticketId, 'Status Changed', performedBy, `Changed to In Progress`);
    }
  }, [tickets, addHistoryEntry]);

  const handleAssignTicket = useCallback((ticketIds: string[], employeeId: string) => {
    const employee = employees.find((e) => e.id === employeeId);
    if (!employee) return;

    setTickets((prev) =>
      prev.map((ticket) => {
        if (!ticketIds.includes(ticket.id)) return ticket;
        return {
          ...ticket,
          assigneeId: employeeId,
          assigneeName: employee.name,
          status: 'Assigned' as TicketStatus,
          updatedAt: new Date(),
        };
      })
    );

    ticketIds.forEach((ticketId) => {
      addHistoryEntry(ticketId, 'Ticket Assigned', 'System', `Assigned to ${employee.name}`);
    });
  }, [addHistoryEntry]);

  const handleAddNote = useCallback((ticketId: string, note: Omit<TicketNote, 'id'>) => {
    const newNote: TicketNote = {
      ...note,
      id: `note-${Date.now()}`,
    };

    setTickets((prev) =>
      prev.map((ticket) => {
        if (ticket.id !== ticketId) return ticket;
        return {
          ...ticket,
          notes: [...ticket.notes, newNote],
          updatedAt: new Date(),
        };
      })
    );

    addHistoryEntry(ticketId, 'Note Added', note.author, `Added ${note.type} note`);
  }, [addHistoryEntry]);

  const openTicketCount = tickets.filter(t => t.status !== 'Closed' && t.status !== 'Resolved').length;
  const newTicketCount = tickets.filter(t => t.status === 'New').length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                <TicketIcon className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Ticket Management</h1>
                <p className="text-sm text-muted-foreground">Customer Complaint System</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-2xl font-bold text-foreground">{openTicketCount}</p>
                <p className="text-xs text-muted-foreground">Open Tickets</p>
              </div>
              {newTicketCount > 0 && (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full status-new">
                  <span className="text-sm font-medium">{newTicketCount} New</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="list" className="space-y-6">
          <TabsList className="grid w-full max-w-lg grid-cols-3 bg-secondary/50">
            <TabsTrigger value="list" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              <span className="hidden sm:inline">Ticket List</span>
              <span className="sm:hidden">List</span>
            </TabsTrigger>
            <TabsTrigger value="assignment" className="flex items-center gap-2">
              <UserCog className="h-4 w-4" />
              <span className="hidden sm:inline">Assignment</span>
              <span className="sm:hidden">Assign</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              <span className="hidden sm:inline">History</span>
              <span className="sm:hidden">History</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="mt-6">
            <TicketList
              tickets={tickets}
              employees={employees}
              onUpdateStatus={handleUpdateStatus}
              onAddNote={handleAddNote}
            />
          </TabsContent>

          <TabsContent value="assignment" className="mt-6">
            <AssignmentManagement
              tickets={tickets}
              employees={employees}
              onAssignTicket={handleAssignTicket}
              onUpdateStatus={handleUpdateStatus}
            />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <HistoryRecords history={history} tickets={tickets} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Index;
