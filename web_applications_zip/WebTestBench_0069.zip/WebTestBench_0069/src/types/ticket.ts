export type TicketStatus = 'New' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed';
export type TicketPriority = 'High' | 'Medium' | 'Low';

export interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  avatar?: string;
}

export interface HistoryEntry {
  id: string;
  ticketId: string;
  action: string;
  performedBy: string;
  timestamp: Date;
  details?: string;
}

export interface TicketNote {
  id: string;
  content: string;
  author: string;
  timestamp: Date;
  type: 'investigation' | 'solution' | 'general';
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  customerName: string;
  customerEmail: string;
  status: TicketStatus;
  priority: TicketPriority;
  assigneeId: string | null;
  assigneeName: string | null;
  createdAt: Date;
  updatedAt: Date;
  resolvedAt: Date | null;
  closedAt: Date | null;
  notes: TicketNote[];
  category: string;
}
