import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { Ticket, TicketNote, TicketStatus, Employee } from '@/types/ticket';
import { format } from 'date-fns';
import { MessageSquare, FileText, Lightbulb, Clock, User, Mail } from 'lucide-react';

interface TicketDetailModalProps {
  ticket: Ticket | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddNote: (ticketId: string, note: Omit<TicketNote, 'id'>) => void;
  employees: Employee[];
}

export const TicketDetailModal = ({
  ticket,
  isOpen,
  onClose,
  onUpdateStatus,
  onAddNote,
  employees,
}: TicketDetailModalProps) => {
  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState<'investigation' | 'solution' | 'general'>('general');

  if (!ticket) return null;

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    
    const assignee = employees.find(e => e.id === ticket.assigneeId);
    onAddNote(ticket.id, {
      content: newNote,
      author: assignee?.name || 'Unknown',
      timestamp: new Date(),
      type: noteType,
    });
    setNewNote('');
  };

  const getNoteIcon = (type: TicketNote['type']) => {
    switch (type) {
      case 'investigation':
        return <FileText className="h-4 w-4 text-primary" />;
      case 'solution':
        return <Lightbulb className="h-4 w-4 text-[hsl(var(--status-resolved))]" />;
      default:
        return <MessageSquare className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const canChangeStatus = ticket.status !== 'Closed';
  const canResolve = ticket.status === 'In Progress' || ticket.status === 'Assigned';
  const canClose = ticket.status === 'Resolved';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <DialogTitle className="text-lg font-semibold text-foreground">
                {ticket.id}: {ticket.title}
              </DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">{ticket.category}</p>
            </div>
            <div className="flex gap-2">
              <StatusBadge status={ticket.status} />
              <PriorityBadge priority={ticket.priority} />
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Customer Info */}
          <div className="bg-secondary/50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-foreground mb-3">Customer Information</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span>{ticket.customerName}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span>{ticket.customerEmail}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-sm font-medium text-foreground mb-2">Description</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">{ticket.description}</p>
          </div>

          {/* Timestamps */}
          <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>Created: {format(ticket.createdAt, 'MMM d, yyyy h:mm a')}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>Updated: {format(ticket.updatedAt, 'MMM d, yyyy h:mm a')}</span>
            </div>
            {ticket.assigneeName && (
              <div className="flex items-center gap-1">
                <User className="h-3 w-3" />
                <span>Assigned to: {ticket.assigneeName}</span>
              </div>
            )}
          </div>

          {/* Notes Section */}
          <div>
            <h4 className="text-sm font-medium text-foreground mb-3">Notes & Investigation</h4>
            
            {ticket.notes.length > 0 ? (
              <div className="space-y-3 mb-4">
                {ticket.notes.map((note) => (
                  <div
                    key={note.id}
                    className="bg-card border rounded-lg p-3"
                  >
                    <div className="flex items-start gap-2">
                      {getNoteIcon(note.type)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-foreground">{note.author}</span>
                          <span className="text-xs text-muted-foreground">
                            {format(note.timestamp, 'MMM d, h:mm a')}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{note.content}</p>
                        <span className="inline-block mt-2 text-xs px-2 py-0.5 rounded bg-secondary text-secondary-foreground capitalize">
                          {note.type}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground mb-4">No notes yet.</p>
            )}

            {/* Add Note Form */}
            {ticket.assigneeId && canChangeStatus && (
              <div className="space-y-3 border-t pt-4">
                <div className="flex gap-2">
                  <Select value={noteType} onValueChange={(v) => setNoteType(v as typeof noteType)}>
                    <SelectTrigger className="w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="investigation">Investigation</SelectItem>
                      <SelectItem value="solution">Solution</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea
                  placeholder="Add a note..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  rows={3}
                />
                <Button onClick={handleAddNote} size="sm" disabled={!newNote.trim()}>
                  Add Note
                </Button>
              </div>
            )}
          </div>

          {/* Actions */}
          {canChangeStatus && (
            <div className="flex gap-2 border-t pt-4">
              {canResolve && (
                <Button
                  variant="outline"
                  onClick={() => onUpdateStatus(ticket.id, 'Resolved')}
                  className="text-[hsl(var(--status-resolved))] border-[hsl(var(--status-resolved))] hover:bg-[hsl(var(--status-resolved-bg))]"
                >
                  Mark as Resolved
                </Button>
              )}
              {canClose && (
                <Button
                  variant="outline"
                  onClick={() => onUpdateStatus(ticket.id, 'Closed')}
                  className="text-[hsl(var(--status-closed))] border-[hsl(var(--status-closed))] hover:bg-[hsl(var(--status-closed-bg))]"
                >
                  Close Ticket
                </Button>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
