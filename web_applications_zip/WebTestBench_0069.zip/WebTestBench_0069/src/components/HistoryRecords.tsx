import { useState, useMemo } from 'react';
import { HistoryEntry, Ticket } from '@/types/ticket';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { format } from 'date-fns';
import { Search, History, User, Clock, ArrowRight, FileText } from 'lucide-react';

interface HistoryRecordsProps {
  history: HistoryEntry[];
  tickets: Ticket[];
}

export const HistoryRecords = ({ history, tickets }: HistoryRecordsProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');

  const uniqueActions = useMemo(() => {
    const actions = new Set(history.map(h => h.action));
    return Array.from(actions);
  }, [history]);

  const filteredHistory = useMemo(() => {
    let result = [...history];

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (h) =>
          h.ticketId.toLowerCase().includes(query) ||
          h.action.toLowerCase().includes(query) ||
          h.performedBy.toLowerCase().includes(query) ||
          h.details?.toLowerCase().includes(query)
      );
    }

    // Filter by action
    if (actionFilter !== 'all') {
      result = result.filter((h) => h.action === actionFilter);
    }

    // Sort by timestamp descending
    result.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return result;
  }, [history, searchQuery, actionFilter]);

  const getTicketTitle = (ticketId: string) => {
    const ticket = tickets.find(t => t.id === ticketId);
    return ticket?.title || 'Unknown Ticket';
  };

  const getActionIcon = (action: string) => {
    if (action.includes('Assigned')) return <User className="h-4 w-4" />;
    if (action.includes('Status')) return <ArrowRight className="h-4 w-4" />;
    if (action.includes('Resolved')) return <FileText className="h-4 w-4" />;
    if (action.includes('Closed')) return <FileText className="h-4 w-4" />;
    return <History className="h-4 w-4" />;
  };

  const getActionColor = (action: string) => {
    if (action.includes('Assigned')) return 'text-[hsl(var(--status-assigned))] bg-[hsl(var(--status-assigned-bg))]';
    if (action.includes('Progress')) return 'text-[hsl(var(--status-in-progress))] bg-[hsl(var(--status-in-progress-bg))]';
    if (action.includes('Resolved')) return 'text-[hsl(var(--status-resolved))] bg-[hsl(var(--status-resolved-bg))]';
    if (action.includes('Closed')) return 'text-[hsl(var(--status-closed))] bg-[hsl(var(--status-closed-bg))]';
    return 'text-primary bg-primary/10';
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-4 p-4 bg-card rounded-lg border">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search history by ticket ID, action, or user..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={actionFilter} onValueChange={setActionFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All Actions" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Actions</SelectItem>
            {uniqueActions.map((action) => (
              <SelectItem key={action} value={action}>
                {action}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Results count */}
      <p className="text-sm text-muted-foreground">
        Showing {filteredHistory.length} of {history.length} records
      </p>

      {/* Timeline */}
      <div className="space-y-3">
        {filteredHistory.map((entry, index) => (
          <Card key={entry.id} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className={`p-2 rounded-lg shrink-0 ${getActionColor(entry.action)}`}>
                  {getActionIcon(entry.action)}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="font-medium text-foreground">{entry.action}</h4>
                      <p className="text-sm text-primary font-mono">
                        {entry.ticketId}
                      </p>
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {getTicketTitle(entry.ticketId)}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {format(entry.timestamp, 'MMM d, yyyy')}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {format(entry.timestamp, 'h:mm a')}
                      </p>
                    </div>
                  </div>

                  {entry.details && (
                    <p className="text-sm text-muted-foreground mt-2 py-2 px-3 bg-secondary/50 rounded-md">
                      {entry.details}
                    </p>
                  )}

                  <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                    <User className="h-3 w-3" />
                    <span>{entry.performedBy}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredHistory.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No history records found.</p>
          </div>
        )}
      </div>
    </div>
  );
};
