import { useState, useMemo } from 'react';
import { Ticket, TicketStatus, TicketPriority, Employee, TicketNote } from '@/types/ticket';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { TicketDetailModal } from './TicketDetailModal';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { Search, ArrowUpDown, ChevronDown, ChevronUp, Check, X } from 'lucide-react';

interface TicketListProps {
  tickets: Ticket[];
  employees: Employee[];
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddNote: (ticketId: string, note: Omit<TicketNote, 'id'>) => void;
}

type SortField = 'createdAt' | 'updatedAt' | 'priority' | 'status';
type SortDirection = 'asc' | 'desc';

export const TicketList = ({ tickets, employees, onUpdateStatus, onAddNote }: TicketListProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<TicketPriority | 'all'>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);

  const priorityOrder: Record<TicketPriority, number> = { High: 3, Medium: 2, Low: 1 };
  const statusOrder: Record<TicketStatus, number> = {
    New: 5,
    Assigned: 4,
    'In Progress': 3,
    Resolved: 2,
    Closed: 1,
  };

  const filteredAndSortedTickets = useMemo(() => {
    let result = [...tickets];

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (t) =>
          t.id.toLowerCase().includes(query) ||
          t.title.toLowerCase().includes(query) ||
          t.customerName.toLowerCase().includes(query) ||
          t.customerEmail.toLowerCase().includes(query)
      );
    }

    // Filter by status
    if (statusFilter !== 'all') {
      result = result.filter((t) => t.status === statusFilter);
    }

    // Filter by priority
    if (priorityFilter !== 'all') {
      result = result.filter((t) => t.priority === priorityFilter);
    }

    // Sort
    result.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case 'createdAt':
          comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          break;
        case 'updatedAt':
          comparison = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
          break;
        case 'priority':
          comparison = priorityOrder[a.priority] - priorityOrder[b.priority];
          break;
        case 'status':
          comparison = statusOrder[a.status] - statusOrder[b.status];
          break;
      }
      return sortDirection === 'desc' ? -comparison : comparison;
    });

    return result;
  }, [tickets, searchQuery, statusFilter, priorityFilter, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4 text-muted-foreground" />;
    return sortDirection === 'asc' ? (
      <ChevronUp className="h-4 w-4 text-primary" />
    ) : (
      <ChevronDown className="h-4 w-4 text-primary" />
    );
  };

  const handleInlineAction = (e: React.MouseEvent, ticketId: string, status: TicketStatus) => {
    e.stopPropagation();
    onUpdateStatus(ticketId, status);
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-4 p-4 bg-card rounded-lg border">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tickets by ID, title, or customer..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as TicketStatus | 'all')}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="New">New</SelectItem>
            <SelectItem value="Assigned">Assigned</SelectItem>
            <SelectItem value="In Progress">In Progress</SelectItem>
            <SelectItem value="Resolved">Resolved</SelectItem>
            <SelectItem value="Closed">Closed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as TicketPriority | 'all')}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All Priorities" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="High">High</SelectItem>
            <SelectItem value="Medium">Medium</SelectItem>
            <SelectItem value="Low">Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Results count */}
      <p className="text-sm text-muted-foreground">
        Showing {filteredAndSortedTickets.length} of {tickets.length} tickets
      </p>

      {/* Table */}
      <div className="border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-secondary/50">
              <TableHead className="w-28">ID</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead className="w-32">
                <button
                  className="flex items-center gap-1 hover:text-foreground transition-colors"
                  onClick={() => handleSort('status')}
                >
                  Status <SortIcon field="status" />
                </button>
              </TableHead>
              <TableHead className="w-24">
                <button
                  className="flex items-center gap-1 hover:text-foreground transition-colors"
                  onClick={() => handleSort('priority')}
                >
                  Priority <SortIcon field="priority" />
                </button>
              </TableHead>
              <TableHead className="w-32">Assignee</TableHead>
              <TableHead className="w-32">
                <button
                  className="flex items-center gap-1 hover:text-foreground transition-colors"
                  onClick={() => handleSort('createdAt')}
                >
                  Created <SortIcon field="createdAt" />
                </button>
              </TableHead>
              <TableHead className="w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAndSortedTickets.map((ticket) => (
              <TableRow
                key={ticket.id}
                className="cursor-pointer hover:bg-secondary/30 transition-colors"
                onClick={() => setSelectedTicket(ticket)}
              >
                <TableCell className="font-mono text-sm text-primary">{ticket.id}</TableCell>
                <TableCell className="font-medium max-w-xs truncate">{ticket.title}</TableCell>
                <TableCell className="text-muted-foreground">{ticket.customerName}</TableCell>
                <TableCell>
                  <StatusBadge status={ticket.status} />
                </TableCell>
                <TableCell>
                  <PriorityBadge priority={ticket.priority} />
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {ticket.assigneeName || '—'}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {format(ticket.createdAt, 'MMM d, yyyy')}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {(ticket.status === 'Assigned' || ticket.status === 'In Progress') && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-[hsl(var(--status-resolved))] hover:bg-[hsl(var(--status-resolved-bg))]"
                        onClick={(e) => handleInlineAction(e, ticket.id, 'Resolved')}
                        title="Mark as Resolved"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                    )}
                    {ticket.status === 'Resolved' && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-[hsl(var(--status-closed))] hover:bg-[hsl(var(--status-closed-bg))]"
                        onClick={(e) => handleInlineAction(e, ticket.id, 'Closed')}
                        title="Close Ticket"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {filteredAndSortedTickets.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                  No tickets found matching your filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <TicketDetailModal
        ticket={selectedTicket}
        isOpen={!!selectedTicket}
        onClose={() => setSelectedTicket(null)}
        onUpdateStatus={onUpdateStatus}
        onAddNote={onAddNote}
        employees={employees}
      />
    </div>
  );
};
