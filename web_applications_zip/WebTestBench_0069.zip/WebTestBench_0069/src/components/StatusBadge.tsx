import { TicketStatus, TicketPriority } from '@/types/ticket';
import { cn } from '@/lib/utils';

interface StatusBadgeProps {
  status: TicketStatus;
  className?: string;
}

export const StatusBadge = ({ status, className }: StatusBadgeProps) => {
  const statusClasses: Record<TicketStatus, string> = {
    'New': 'status-new',
    'Assigned': 'status-assigned',
    'In Progress': 'status-in-progress',
    'Resolved': 'status-resolved',
    'Closed': 'status-closed',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
        statusClasses[status],
        className
      )}
    >
      {status}
    </span>
  );
};

interface PriorityBadgeProps {
  priority: TicketPriority;
  className?: string;
}

export const PriorityBadge = ({ priority, className }: PriorityBadgeProps) => {
  const priorityClasses: Record<TicketPriority, string> = {
    'High': 'priority-high',
    'Medium': 'priority-medium',
    'Low': 'priority-low',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
        priorityClasses[priority],
        className
      )}
    >
      {priority}
    </span>
  );
};
