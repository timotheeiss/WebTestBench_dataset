import { useState, useMemo } from 'react';
import { Ticket, TicketStatus, Employee } from '@/types/ticket';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { format } from 'date-fns';
import { UserPlus, Play, CheckCircle, Users, AlertCircle } from 'lucide-react';

interface AssignmentManagementProps {
  tickets: Ticket[];
  employees: Employee[];
  onAssignTicket: (ticketIds: string[], employeeId: string) => void;
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
}

export const AssignmentManagement = ({
  tickets,
  employees,
  onAssignTicket,
  onUpdateStatus,
}: AssignmentManagementProps) => {
  const [selectedTickets, setSelectedTickets] = useState<string[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');

  // Filter to show only actionable tickets (not Closed)
  const actionableTickets = useMemo(() => 
    tickets.filter(t => t.status !== 'Closed'),
    [tickets]
  );

  const unassignedTickets = useMemo(() => 
    actionableTickets.filter(t => t.status === 'New'),
    [actionableTickets]
  );

  const assignedTickets = useMemo(() => 
    actionableTickets.filter(t => t.status === 'Assigned' || t.status === 'In Progress' || t.status === 'Resolved'),
    [actionableTickets]
  );

  const handleSelectTicket = (ticketId: string, checked: boolean) => {
    if (checked) {
      setSelectedTickets([...selectedTickets, ticketId]);
    } else {
      setSelectedTickets(selectedTickets.filter((id) => id !== ticketId));
    }
  };

  const handleSelectAllUnassigned = (checked: boolean) => {
    if (checked) {
      setSelectedTickets(unassignedTickets.map((t) => t.id));
    } else {
      setSelectedTickets([]);
    }
  };

  const handleBatchAssign = () => {
    if (selectedTickets.length === 0 || !selectedEmployee) return;
    onAssignTicket(selectedTickets, selectedEmployee);
    setSelectedTickets([]);
    setSelectedEmployee('');
  };

  const handleStartProgress = (ticketId: string) => {
    onUpdateStatus(ticketId, 'In Progress');
  };

  const handleResolve = (ticketId: string) => {
    onUpdateStatus(ticketId, 'Resolved');
  };

  const handleClose = (ticketId: string) => {
    onUpdateStatus(ticketId, 'Closed');
  };

  const getEmployeeTicketCount = (employeeId: string) => {
    return actionableTickets.filter(t => t.assigneeId === employeeId && t.status !== 'Closed').length;
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg status-new">
                <AlertCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{unassignedTickets.length}</p>
                <p className="text-sm text-muted-foreground">Unassigned</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg status-assigned">
                <UserPlus className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{actionableTickets.filter(t => t.status === 'Assigned').length}</p>
                <p className="text-sm text-muted-foreground">Assigned</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg status-in-progress">
                <Play className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{actionableTickets.filter(t => t.status === 'In Progress').length}</p>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg status-resolved">
                <CheckCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{actionableTickets.filter(t => t.status === 'Resolved').length}</p>
                <p className="text-sm text-muted-foreground">Resolved</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Unassigned Tickets Pool */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-[hsl(var(--status-new))]" />
              Unassigned Tickets
            </CardTitle>
            <CardDescription>
              Select tickets and assign them to an employee
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Batch Assignment Controls */}
            <div className="flex flex-wrap gap-3 mb-4 p-3 bg-secondary/50 rounded-lg">
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select Employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      <div className="flex items-center justify-between gap-2">
                        <span>{emp.name}</span>
                        <span className="text-xs text-muted-foreground">
                          ({getEmployeeTicketCount(emp.id)} active)
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={handleBatchAssign}
                disabled={selectedTickets.length === 0 || !selectedEmployee}
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Assign {selectedTickets.length > 0 && `(${selectedTickets.length})`}
              </Button>
            </div>

            {/* Ticket List */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {unassignedTickets.length > 0 && (
                <div className="flex items-center gap-2 py-2 border-b">
                  <Checkbox
                    checked={selectedTickets.length === unassignedTickets.length && unassignedTickets.length > 0}
                    onCheckedChange={handleSelectAllUnassigned}
                  />
                  <span className="text-sm text-muted-foreground">Select All</span>
                </div>
              )}
              {unassignedTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  className="flex items-center gap-3 p-3 border rounded-lg hover:bg-secondary/30 transition-colors"
                >
                  <Checkbox
                    checked={selectedTickets.includes(ticket.id)}
                    onCheckedChange={(checked) => handleSelectTicket(ticket.id, !!checked)}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-primary">{ticket.id}</span>
                      <PriorityBadge priority={ticket.priority} />
                    </div>
                    <p className="text-sm font-medium truncate">{ticket.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {ticket.customerName} • {format(ticket.createdAt, 'MMM d, h:mm a')}
                    </p>
                  </div>
                </div>
              ))}
              {unassignedTickets.length === 0 && (
                <p className="text-center py-8 text-muted-foreground">
                  No unassigned tickets. Great job!
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Employee Workload */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Employee Workload
            </CardTitle>
            <CardDescription>
              View and manage tickets assigned to each employee
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-[32rem] overflow-y-auto">
              {employees.map((employee) => {
                const empTickets = assignedTickets.filter((t) => t.assigneeId === employee.id);
                return (
                  <div key={employee.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-medium">{employee.name}</h4>
                        <p className="text-xs text-muted-foreground">{employee.department}</p>
                      </div>
                      <span className="text-sm font-medium text-primary">
                        {empTickets.length} ticket{empTickets.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    {empTickets.length > 0 ? (
                      <div className="space-y-2">
                        {empTickets.map((ticket) => (
                          <div
                            key={ticket.id}
                            className="flex items-center justify-between gap-2 p-2 bg-secondary/30 rounded-md"
                          >
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs text-primary">{ticket.id}</span>
                                <StatusBadge status={ticket.status} />
                              </div>
                              <p className="text-sm truncate">{ticket.title}</p>
                            </div>
                            <div className="flex gap-1">
                              {ticket.status === 'Assigned' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 text-xs"
                                  onClick={() => handleStartProgress(ticket.id)}
                                >
                                  <Play className="h-3 w-3 mr-1" />
                                  Start
                                </Button>
                              )}
                              {ticket.status === 'In Progress' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 text-xs text-[hsl(var(--status-resolved))]"
                                  onClick={() => handleResolve(ticket.id)}
                                >
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Resolve
                                </Button>
                              )}
                              {ticket.status === 'Resolved' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 text-xs text-[hsl(var(--status-closed))]"
                                  onClick={() => handleClose(ticket.id)}
                                >
                                  Close
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No active tickets</p>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
