import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  Book, 
  FileText, 
  BarChart3, 
  Upload, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Globe,
  Shield,
  Database,
  Layout
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { modules } from '@/data/documents';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Globe,
  Shield,
  Database,
  Layout,
};

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ isCollapsed, onToggle }: SidebarProps) {
  const location = useLocation();
  const [expandedModules, setExpandedModules] = useState<string[]>(['api']);

  const navItems = [
    { path: '/', icon: Book, label: 'Knowledge Base' },
    { path: '/expenses', icon: FileText, label: 'Expense Reports' },
    { path: '/upload', icon: Upload, label: 'Upload Receipts' },
    { path: '/statistics', icon: BarChart3, label: 'Statistics' },
  ];

  const toggleModule = (moduleId: string) => {
    setExpandedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 z-40 h-screen bg-sidebar text-sidebar-foreground transition-all duration-300 flex flex-col',
        isCollapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Logo */}
      <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
              <Book className="w-5 h-5 text-sidebar-primary-foreground" />
            </div>
            <span className="font-semibold text-lg">TechDocs</span>
          </div>
        )}
        <button
          onClick={onToggle}
          className="p-2 rounded-lg hover:bg-sidebar-accent transition-colors"
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <ChevronLeft className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin py-4">
        <ul className="space-y-1 px-2">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'hover:bg-sidebar-accent text-sidebar-foreground/80 hover:text-sidebar-foreground'
                  )
                }
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!isCollapsed && <span className="text-sm font-medium">{item.label}</span>}
              </NavLink>
            </li>
          ))}
        </ul>

        {/* Modules Section */}
        {!isCollapsed && location.pathname === '/' && (
          <div className="mt-6 px-2">
            <h3 className="px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider mb-2">
              Modules
            </h3>
            <ul className="space-y-1">
              {modules.map((module) => {
                const IconComponent = iconMap[module.icon];
                return (
                  <li key={module.id}>
                    <button
                      onClick={() => toggleModule(module.id)}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors text-left',
                        expandedModules.includes(module.id)
                          ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                          : 'hover:bg-sidebar-accent/50 text-sidebar-foreground/70'
                      )}
                    >
                      {IconComponent && <IconComponent className="w-4 h-4 flex-shrink-0" />}
                      <span className="text-sm">{module.name}</span>
                      <span className="ml-auto text-xs text-sidebar-foreground/50">
                        {module.documentCount}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <button
          className={cn(
            'flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-sidebar-accent transition-colors w-full',
            isCollapsed && 'justify-center'
          )}
        >
          <Settings className="w-5 h-5" />
          {!isCollapsed && <span className="text-sm">Settings</span>}
        </button>
      </div>
    </aside>
  );
}
