import { 
  FileText, 
  Send, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  RefreshCw,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { type TimelineEntry } from '@/data/expenses';

const actionConfig: Record<TimelineEntry['action'], {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  color: string;
}> = {
  created: {
    icon: FileText,
    label: 'Created',
    color: 'text-muted-foreground border-muted',
  },
  submitted: {
    icon: Send,
    label: 'Submitted',
    color: 'text-info border-info',
  },
  approved: {
    icon: CheckCircle,
    label: 'Approved',
    color: 'text-success border-success',
  },
  rejected: {
    icon: XCircle,
    label: 'Rejected',
    color: 'text-destructive border-destructive',
  },
  revision_requested: {
    icon: AlertCircle,
    label: 'Revision Requested',
    color: 'text-warning border-warning',
  },
  resubmitted: {
    icon: RefreshCw,
    label: 'Resubmitted',
    color: 'text-accent border-accent',
  },
  comment: {
    icon: MessageSquare,
    label: 'Comment',
    color: 'text-muted-foreground border-muted',
  },
};

interface TimelineProps {
  entries: TimelineEntry[];
}

export function Timeline({ entries }: TimelineProps) {
  return (
    <div className="relative">
      <div className="timeline-line" />
      <ul className="space-y-6">
        {entries.map((entry, index) => {
          const config = actionConfig[entry.action];
          const Icon = config.icon;
          const isLast = index === entries.length - 1;

          return (
            <li key={entry.id} className="relative flex gap-4">
              <div
                className={cn(
                  'timeline-dot',
                  config.color
                )}
              >
                <Icon className="w-4 h-4" />
              </div>
              <div className={cn('flex-1 pb-6', isLast && 'pb-0')}>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-foreground">{config.label}</span>
                  <span className="text-sm text-muted-foreground">by {entry.actor}</span>
                </div>
                <time className="text-xs text-muted-foreground">
                  {new Date(entry.timestamp).toLocaleString()}
                </time>
                {entry.comment && (
                  <div className="mt-2 p-3 bg-secondary rounded-lg text-sm text-foreground">
                    {entry.comment}
                  </div>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
