import { Link } from 'react-router-dom';
import { Calendar, Paperclip, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { StatusBadge } from './StatusBadge';
import { type ExpenseReport } from '@/data/expenses';

interface ExpenseCardProps {
  report: ExpenseReport;
}

export function ExpenseCard({ report }: ExpenseCardProps) {
  return (
    <Link to={`/expense/${report.id}`}>
      <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors">
                {report.title}
              </h3>
              <p className="text-sm text-muted-foreground">{report.submittedBy}</p>
            </div>
            <StatusBadge status={report.status} />
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{report.createdAt}</span>
              </div>
              <div className="flex items-center gap-1">
                <Paperclip className="w-4 h-4" />
                <span>{report.attachments.length}</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-lg font-semibold text-foreground">
              <DollarSign className="w-5 h-5 text-accent" />
              {report.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
          </div>
          <div className="mt-3 text-xs text-muted-foreground">
            {report.items.length} expense items
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
