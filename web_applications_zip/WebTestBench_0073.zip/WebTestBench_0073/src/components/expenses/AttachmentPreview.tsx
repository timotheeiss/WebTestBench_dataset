import { useState } from 'react';
import { FileText, Image, Download, Edit2, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { type Attachment } from '@/data/expenses';
import { cn } from '@/lib/utils';

interface AttachmentPreviewProps {
  attachment: Attachment;
  onAnnotationChange?: (annotation: string) => void;
}

export function AttachmentPreview({ attachment, onAnnotationChange }: AttachmentPreviewProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [annotation, setAnnotation] = useState(attachment.annotations || '');

  const isImage = attachment.type.startsWith('image/');
  const isPdf = attachment.type === 'application/pdf';

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleSaveAnnotation = () => {
    onAnnotationChange?.(annotation);
    setIsEditing(false);
  };

  return (
    <>
      <div
        onClick={() => setIsOpen(true)}
        className={cn(
          'group relative flex items-center gap-3 p-3 rounded-lg border border-border',
          'hover:border-accent hover:bg-accent/5 cursor-pointer transition-all'
        )}
      >
        <div className="p-2 rounded bg-accent/10 text-accent">
          {isImage ? <Image className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm text-foreground truncate">{attachment.name}</p>
          <p className="text-xs text-muted-foreground">{formatSize(attachment.size)}</p>
          {attachment.annotations && (
            <p className="text-xs text-accent mt-1 truncate">📝 {attachment.annotations}</p>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            // In real app, would download file
          }}
        >
          <Download className="w-4 h-4" />
        </Button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {isImage ? <Image className="w-5 h-5 text-accent" /> : <FileText className="w-5 h-5 text-accent" />}
              {attachment.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Preview area */}
            <div className="aspect-[4/3] bg-secondary rounded-lg flex items-center justify-center overflow-hidden">
              {isImage ? (
                <div className="text-center p-8">
                  <Image className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Image Preview</p>
                  <p className="text-sm text-muted-foreground">{attachment.name}</p>
                </div>
              ) : isPdf ? (
                <div className="text-center p-8">
                  <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">PDF Document</p>
                  <p className="text-sm text-muted-foreground">{attachment.name}</p>
                </div>
              ) : (
                <div className="text-center p-8">
                  <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">File Preview Not Available</p>
                </div>
              )}
            </div>

            {/* Annotations */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground">Annotations</label>
                {!isEditing && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEditing(true)}
                  >
                    <Edit2 className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                )}
              </div>
              {isEditing ? (
                <div className="space-y-2">
                  <Textarea
                    value={annotation}
                    onChange={(e) => setAnnotation(e.target.value)}
                    placeholder="Add notes about this attachment..."
                    rows={3}
                  />
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSaveAnnotation}>
                      Save
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground p-3 bg-secondary rounded-lg min-h-[60px]">
                  {annotation || 'No annotations added'}
                </p>
              )}
            </div>

            {/* Metadata */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2 border-t">
              <span>Size: {formatSize(attachment.size)}</span>
              <span>Uploaded: {attachment.uploadedAt}</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
