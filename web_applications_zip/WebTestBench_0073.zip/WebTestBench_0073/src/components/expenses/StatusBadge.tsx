import { type ExpenseStatus } from '@/data/expenses';
import { cn } from '@/lib/utils';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  FileEdit
} from 'lucide-react';

const statusConfig: Record<ExpenseStatus, { 
  label: string; 
  className: string;
  icon: React.ComponentType<{ className?: string }>;
}> = {
  draft: {
    label: 'Draft',
    className: 'bg-muted text-muted-foreground',
    icon: FileEdit,
  },
  pending: {
    label: 'Pending',
    className: 'bg-warning/10 text-warning',
    icon: Clock,
  },
  approved: {
    label: 'Approved',
    className: 'bg-success/10 text-success',
    icon: CheckCircle,
  },
  rejected: {
    label: 'Rejected',
    className: 'bg-destructive/10 text-destructive',
    icon: XCircle,
  },
  revision: {
    label: 'Revision',
    className: 'bg-info/10 text-info',
    icon: AlertCircle,
  },
};

interface StatusBadgeProps {
  status: ExpenseStatus;
  className?: string;
  showIcon?: boolean;
}

export function StatusBadge({ status, className, showIcon = true }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
        config.className,
        className
      )}
    >
      {showIcon && <Icon className="w-3.5 h-3.5" />}
      {config.label}
    </span>
  );
}
