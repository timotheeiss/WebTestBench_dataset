import { useState } from 'react';
import { ChevronDown, ChevronRight, Code } from 'lucide-react';
import { cn } from '@/lib/utils';
import { type DocumentSection } from '@/data/documents';

interface CollapsibleSectionProps {
  section: DocumentSection;
  defaultExpanded?: boolean;
}

export function CollapsibleSection({ section, defaultExpanded = true }: CollapsibleSectionProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  return (
    <div className="doc-section rounded-lg">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 w-full text-left group"
      >
        <span className="text-accent">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5" />
          ) : (
            <ChevronRight className="w-5 h-5" />
          )}
        </span>
        <h3 className="font-semibold text-lg text-foreground group-hover:text-accent transition-colors">
          {section.title}
        </h3>
      </button>
      
      <div
        className={cn(
          'overflow-hidden transition-all duration-300',
          isExpanded ? 'max-h-[2000px] opacity-100 mt-4' : 'max-h-0 opacity-0'
        )}
      >
        <p className="text-muted-foreground leading-relaxed mb-4">
          {section.content}
        </p>
        
        {section.codeExample && (
          <div className="mt-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <Code className="w-4 h-4" />
              <span>Example</span>
            </div>
            <pre className="bg-primary text-primary-foreground rounded-lg p-4 overflow-x-auto text-sm font-mono">
              <code>{section.codeExample}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
