import { Link } from 'react-router-dom';
import { FileText, Clock, User } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { ModuleBadge } from './ModuleBadge';
import { type TechDocument } from '@/data/documents';

interface DocumentCardProps {
  document: TechDocument;
}

export function DocumentCard({ document }: DocumentCardProps) {
  return (
    <Link to={`/document/${document.id}`}>
      <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10 text-accent group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors line-clamp-1">
                  {document.title}
                </h3>
                <p className="text-sm text-muted-foreground">v{document.version}</p>
              </div>
            </div>
            <ModuleBadge module={document.module} />
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {document.description}
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <User className="w-3.5 h-3.5" />
              <span>{document.author}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{document.lastUpdated}</span>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {document.sections.length} sections
            </span>
            {document.relatedDocIds.length > 0 && (
              <>
                <span className="text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground">
                  {document.relatedDocIds.length} related
                </span>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
