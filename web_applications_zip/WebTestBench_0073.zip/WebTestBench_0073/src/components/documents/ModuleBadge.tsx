import { type ModuleType } from '@/data/documents';
import { cn } from '@/lib/utils';

const moduleStyles: Record<ModuleType, string> = {
  api: 'module-badge-api',
  auth: 'module-badge-auth',
  database: 'module-badge-db',
  ui: 'module-badge-ui',
};

const moduleLabels: Record<ModuleType, string> = {
  api: 'API',
  auth: 'Auth',
  database: 'Database',
  ui: 'UI',
};

interface ModuleBadgeProps {
  module: ModuleType;
  className?: string;
}

export function ModuleBadge({ module, className }: ModuleBadgeProps) {
  return (
    <span className={cn('module-badge', moduleStyles[module], className)}>
      {moduleLabels[module]}
    </span>
  );
}
