import { Link } from 'react-router-dom';
import { ArrowRight, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ModuleBadge } from './ModuleBadge';
import { type TechDocument } from '@/data/documents';

interface RelatedDocumentsProps {
  documents: TechDocument[];
}

export function RelatedDocuments({ documents }: RelatedDocumentsProps) {
  if (documents.length === 0) return null;

  return (
    <Card className="glass-panel">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <FileText className="w-5 h-5 text-accent" />
          Related Documents
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {documents.map((doc) => (
          <Link
            key={doc.id}
            to={`/document/${doc.id}`}
            className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
          >
            <div className="flex items-center gap-3">
              <div className="p-1.5 rounded bg-accent/10 text-accent group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <p className="font-medium text-sm text-foreground group-hover:text-accent transition-colors">
                  {doc.title}
                </p>
                <p className="text-xs text-muted-foreground">v{doc.version}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ModuleBadge module={doc.module} />
              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-accent group-hover:translate-x-1 transition-all" />
            </div>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}
