import { useState } from 'react';
import { Check, ChevronRight, ChevronLeft, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { categoryLabels, type ExpenseCategory } from '@/data/expenses';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface FormData {
  title: string;
  description: string;
  category: ExpenseCategory | '';
  amount: string;
  date: string;
  vendor: string;
  notes: string;
}

interface FormErrors {
  [key: string]: string;
}

const steps = [
  { id: 1, name: 'Basic Info', description: 'Report details' },
  { id: 2, name: 'Expense Details', description: 'Amount and category' },
  { id: 3, name: 'Additional Info', description: 'Notes and vendor' },
  { id: 4, name: 'Review', description: 'Confirm submission' },
];

export function MultiStepForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    category: '',
    amount: '',
    date: '',
    vendor: '',
    notes: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});

  const validateStep = (step: number): boolean => {
    const newErrors: FormErrors = {};

    switch (step) {
      case 1:
        if (!formData.title.trim()) {
          newErrors.title = 'Title is required';
        }
        if (!formData.description.trim()) {
          newErrors.description = 'Description is required';
        }
        break;
      case 2:
        if (!formData.category) {
          newErrors.category = 'Category is required';
        }
        if (!formData.amount || parseFloat(formData.amount) <= 0) {
          newErrors.amount = 'Valid amount is required';
        }
        if (!formData.date) {
          newErrors.date = 'Date is required';
        }
        break;
      case 3:
        if (!formData.vendor.trim()) {
          newErrors.vendor = 'Vendor is required';
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, steps.length));
    }
  };

  const handlePrev = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    toast.success('Expense report submitted successfully!');
    // Reset form
    setFormData({
      title: '',
      description: '',
      category: '',
      amount: '',
      date: '',
      vendor: '',
      notes: '',
    });
    setCurrentStep(1);
  };

  const updateField = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      {steps.map((step, index) => (
        <div key={step.id} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center font-medium text-sm transition-colors',
                currentStep > step.id
                  ? 'bg-success text-success-foreground'
                  : currentStep === step.id
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-secondary text-muted-foreground'
              )}
            >
              {currentStep > step.id ? (
                <Check className="w-5 h-5" />
              ) : (
                step.id
              )}
            </div>
            <div className="mt-2 text-center hidden sm:block">
              <p className="text-xs font-medium text-foreground">{step.name}</p>
              <p className="text-xs text-muted-foreground">{step.description}</p>
            </div>
          </div>
          {index < steps.length - 1 && (
            <div
              className={cn(
                'w-16 h-0.5 mx-2',
                currentStep > step.id ? 'bg-success' : 'bg-secondary'
              )}
            />
          )}
        </div>
      ))}
    </div>
  );

  const renderField = (
    label: string,
    name: keyof FormData,
    type: 'text' | 'number' | 'date' | 'textarea' | 'select' = 'text',
    options?: { value: string; label: string }[]
  ) => {
    const hasError = !!errors[name];

    return (
      <div className="space-y-2">
        <Label htmlFor={name} className="text-foreground">
          {label} <span className="text-destructive">*</span>
        </Label>
        {type === 'textarea' ? (
          <Textarea
            id={name}
            value={formData[name]}
            onChange={(e) => updateField(name, e.target.value)}
            className={cn(hasError && 'border-destructive')}
            rows={4}
          />
        ) : type === 'select' ? (
          <Select
            value={formData[name]}
            onValueChange={(value) => updateField(name, value)}
          >
            <SelectTrigger className={cn(hasError && 'border-destructive')}>
              <SelectValue placeholder={`Select ${label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {options?.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <Input
            id={name}
            type={type}
            value={formData[name]}
            onChange={(e) => updateField(name, e.target.value)}
            className={cn(hasError && 'border-destructive')}
          />
        )}
        {hasError && (
          <p className="text-sm text-destructive flex items-center gap-1">
            <AlertCircle className="w-4 h-4" />
            {errors[name]}
          </p>
        )}
      </div>
    );
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            {renderField('Report Title', 'title')}
            {renderField('Description', 'description', 'textarea')}
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            {renderField('Category', 'category', 'select', 
              Object.entries(categoryLabels).map(([value, label]) => ({ value, label }))
            )}
            {renderField('Amount ($)', 'amount', 'number')}
            {renderField('Date', 'date', 'date')}
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            {renderField('Vendor / Merchant', 'vendor')}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-foreground">
                Additional Notes
              </Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => updateField('notes', e.target.value)}
                rows={4}
                placeholder="Any additional information..."
              />
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Review Your Submission</h3>
            <div className="grid grid-cols-2 gap-4 p-4 bg-secondary rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Title</p>
                <p className="font-medium">{formData.title}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Category</p>
                <p className="font-medium">
                  {formData.category ? categoryLabels[formData.category as ExpenseCategory] : '-'}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Amount</p>
                <p className="font-medium">${formData.amount}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Date</p>
                <p className="font-medium">{formData.date}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Vendor</p>
                <p className="font-medium">{formData.vendor}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-muted-foreground">Description</p>
                <p className="font-medium">{formData.description}</p>
              </div>
              {formData.notes && (
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Notes</p>
                  <p className="font-medium">{formData.notes}</p>
                </div>
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>New Expense Report</CardTitle>
      </CardHeader>
      <CardContent>
        {renderStepIndicator()}
        <div className="min-h-[300px]">{renderStep()}</div>
        <div className="flex justify-between mt-8 pt-4 border-t">
          <Button
            variant="outline"
            onClick={handlePrev}
            disabled={currentStep === 1}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>
          {currentStep < steps.length ? (
            <Button onClick={handleNext} className="gap-2">
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} className="gap-2 bg-success hover:bg-success/90">
              <Check className="w-4 h-4" />
              Submit Report
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
