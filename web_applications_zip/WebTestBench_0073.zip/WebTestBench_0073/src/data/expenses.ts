export type ExpenseStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'revision';
export type ExpenseCategory = 'travel' | 'meals' | 'supplies' | 'equipment' | 'software' | 'other';

export interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  annotations?: string;
  uploadedAt: string;
}

export interface TimelineEntry {
  id: string;
  action: 'created' | 'submitted' | 'approved' | 'rejected' | 'revision_requested' | 'resubmitted' | 'comment';
  actor: string;
  timestamp: string;
  comment?: string;
}

export interface ExpenseItem {
  id: string;
  description: string;
  category: ExpenseCategory;
  amount: number;
  date: string;
  attachmentIds: string[];
}

export interface ExpenseReport {
  id: string;
  title: string;
  status: ExpenseStatus;
  items: ExpenseItem[];
  attachments: Attachment[];
  timeline: TimelineEntry[];
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
  submittedBy: string;
}

export const categoryLabels: Record<ExpenseCategory, string> = {
  travel: 'Travel',
  meals: 'Meals & Entertainment',
  supplies: 'Office Supplies',
  equipment: 'Equipment',
  software: 'Software & Subscriptions',
  other: 'Other',
};

export const statusLabels: Record<ExpenseStatus, string> = {
  draft: 'Draft',
  pending: 'Pending Approval',
  approved: 'Approved',
  rejected: 'Rejected',
  revision: 'Revision Requested',
};

export const sampleExpenseReports: ExpenseReport[] = [
  {
    id: 'exp-001',
    title: 'Q1 Conference Travel',
    status: 'approved',
    submittedBy: 'John Smith',
    totalAmount: 2450.00,
    createdAt: '2024-01-05',
    updatedAt: '2024-01-15',
    items: [
      {
        id: 'item-001',
        description: 'Flight to San Francisco',
        category: 'travel',
        amount: 650.00,
        date: '2024-01-10',
        attachmentIds: ['att-001'],
      },
      {
        id: 'item-002',
        description: 'Hotel - 3 nights',
        category: 'travel',
        amount: 1200.00,
        date: '2024-01-10',
        attachmentIds: ['att-002'],
      },
      {
        id: 'item-003',
        description: 'Team dinner',
        category: 'meals',
        amount: 350.00,
        date: '2024-01-11',
        attachmentIds: ['att-003'],
      },
      {
        id: 'item-004',
        description: 'Uber rides',
        category: 'travel',
        amount: 250.00,
        date: '2024-01-12',
        attachmentIds: [],
      },
    ],
    attachments: [
      {
        id: 'att-001',
        name: 'flight_receipt.pdf',
        type: 'application/pdf',
        size: 245000,
        url: '/receipts/flight_receipt.pdf',
        uploadedAt: '2024-01-05',
      },
      {
        id: 'att-002',
        name: 'hotel_invoice.pdf',
        type: 'application/pdf',
        size: 189000,
        url: '/receipts/hotel_invoice.pdf',
        uploadedAt: '2024-01-05',
        annotations: 'Includes parking fees',
      },
      {
        id: 'att-003',
        name: 'dinner_receipt.jpg',
        type: 'image/jpeg',
        size: 1240000,
        url: '/receipts/dinner_receipt.jpg',
        uploadedAt: '2024-01-12',
      },
    ],
    timeline: [
      {
        id: 'tl-001',
        action: 'created',
        actor: 'John Smith',
        timestamp: '2024-01-05T09:00:00Z',
      },
      {
        id: 'tl-002',
        action: 'submitted',
        actor: 'John Smith',
        timestamp: '2024-01-13T14:30:00Z',
        comment: 'Submitting for Q1 conference expenses',
      },
      {
        id: 'tl-003',
        action: 'approved',
        actor: 'Manager Sarah Lee',
        timestamp: '2024-01-15T10:15:00Z',
        comment: 'Approved. All receipts verified.',
      },
    ],
  },
  {
    id: 'exp-002',
    title: 'Office Equipment Purchase',
    status: 'revision',
    submittedBy: 'Emily Chen',
    totalAmount: 1899.00,
    createdAt: '2024-01-18',
    updatedAt: '2024-01-20',
    items: [
      {
        id: 'item-005',
        description: 'Standing desk',
        category: 'equipment',
        amount: 799.00,
        date: '2024-01-15',
        attachmentIds: ['att-004'],
      },
      {
        id: 'item-006',
        description: 'Monitor arm',
        category: 'equipment',
        amount: 150.00,
        date: '2024-01-15',
        attachmentIds: ['att-004'],
      },
      {
        id: 'item-007',
        description: 'Ergonomic chair',
        category: 'equipment',
        amount: 950.00,
        date: '2024-01-16',
        attachmentIds: ['att-005'],
      },
    ],
    attachments: [
      {
        id: 'att-004',
        name: 'desk_order.pdf',
        type: 'application/pdf',
        size: 156000,
        url: '/receipts/desk_order.pdf',
        uploadedAt: '2024-01-18',
      },
      {
        id: 'att-005',
        name: 'chair_receipt.png',
        type: 'image/png',
        size: 890000,
        url: '/receipts/chair_receipt.png',
        uploadedAt: '2024-01-18',
      },
    ],
    timeline: [
      {
        id: 'tl-004',
        action: 'created',
        actor: 'Emily Chen',
        timestamp: '2024-01-18T11:00:00Z',
      },
      {
        id: 'tl-005',
        action: 'submitted',
        actor: 'Emily Chen',
        timestamp: '2024-01-18T16:00:00Z',
      },
      {
        id: 'tl-006',
        action: 'revision_requested',
        actor: 'Manager Tom Wilson',
        timestamp: '2024-01-20T09:30:00Z',
        comment: 'Please provide pre-approval documentation for equipment over $500',
      },
    ],
  },
  {
    id: 'exp-003',
    title: 'Software Subscriptions - January',
    status: 'pending',
    submittedBy: 'Mike Johnson',
    totalAmount: 449.00,
    createdAt: '2024-01-20',
    updatedAt: '2024-01-20',
    items: [
      {
        id: 'item-008',
        description: 'Figma Pro - Annual',
        category: 'software',
        amount: 144.00,
        date: '2024-01-01',
        attachmentIds: ['att-006'],
      },
      {
        id: 'item-009',
        description: 'GitHub Copilot - Annual',
        category: 'software',
        amount: 100.00,
        date: '2024-01-05',
        attachmentIds: ['att-007'],
      },
      {
        id: 'item-010',
        description: 'Linear - Team',
        category: 'software',
        amount: 80.00,
        date: '2024-01-10',
        attachmentIds: [],
      },
      {
        id: 'item-011',
        description: 'Notion Team',
        category: 'software',
        amount: 125.00,
        date: '2024-01-15',
        attachmentIds: ['att-008'],
      },
    ],
    attachments: [
      {
        id: 'att-006',
        name: 'figma_invoice.pdf',
        type: 'application/pdf',
        size: 98000,
        url: '/receipts/figma_invoice.pdf',
        uploadedAt: '2024-01-20',
      },
      {
        id: 'att-007',
        name: 'github_receipt.pdf',
        type: 'application/pdf',
        size: 67000,
        url: '/receipts/github_receipt.pdf',
        uploadedAt: '2024-01-20',
      },
      {
        id: 'att-008',
        name: 'notion_billing.pdf',
        type: 'application/pdf',
        size: 112000,
        url: '/receipts/notion_billing.pdf',
        uploadedAt: '2024-01-20',
      },
    ],
    timeline: [
      {
        id: 'tl-007',
        action: 'created',
        actor: 'Mike Johnson',
        timestamp: '2024-01-20T08:00:00Z',
      },
      {
        id: 'tl-008',
        action: 'submitted',
        actor: 'Mike Johnson',
        timestamp: '2024-01-20T14:00:00Z',
        comment: 'Monthly software subscriptions for the development team',
      },
    ],
  },
  {
    id: 'exp-004',
    title: 'Client Meeting Expenses',
    status: 'rejected',
    submittedBy: 'Sarah Kim',
    totalAmount: 280.00,
    createdAt: '2024-01-08',
    updatedAt: '2024-01-12',
    items: [
      {
        id: 'item-012',
        description: 'Client lunch meeting',
        category: 'meals',
        amount: 180.00,
        date: '2024-01-08',
        attachmentIds: [],
      },
      {
        id: 'item-013',
        description: 'Parking',
        category: 'travel',
        amount: 25.00,
        date: '2024-01-08',
        attachmentIds: [],
      },
      {
        id: 'item-014',
        description: 'Coffee for meeting',
        category: 'meals',
        amount: 75.00,
        date: '2024-01-08',
        attachmentIds: [],
      },
    ],
    attachments: [],
    timeline: [
      {
        id: 'tl-009',
        action: 'created',
        actor: 'Sarah Kim',
        timestamp: '2024-01-08T17:00:00Z',
      },
      {
        id: 'tl-010',
        action: 'submitted',
        actor: 'Sarah Kim',
        timestamp: '2024-01-09T09:00:00Z',
      },
      {
        id: 'tl-011',
        action: 'rejected',
        actor: 'Manager David Park',
        timestamp: '2024-01-12T11:00:00Z',
        comment: 'Missing receipts for all items. Please resubmit with proper documentation.',
      },
    ],
  },
  {
    id: 'exp-005',
    title: 'Office Supplies - Q1',
    status: 'draft',
    submittedBy: 'Alex Chen',
    totalAmount: 156.50,
    createdAt: '2024-01-22',
    updatedAt: '2024-01-22',
    items: [
      {
        id: 'item-015',
        description: 'Notebooks and pens',
        category: 'supplies',
        amount: 45.50,
        date: '2024-01-20',
        attachmentIds: [],
      },
      {
        id: 'item-016',
        description: 'Printer paper',
        category: 'supplies',
        amount: 65.00,
        date: '2024-01-21',
        attachmentIds: [],
      },
      {
        id: 'item-017',
        description: 'Whiteboard markers',
        category: 'supplies',
        amount: 46.00,
        date: '2024-01-22',
        attachmentIds: [],
      },
    ],
    attachments: [],
    timeline: [
      {
        id: 'tl-012',
        action: 'created',
        actor: 'Alex Chen',
        timestamp: '2024-01-22T10:00:00Z',
      },
    ],
  },
];

export interface MonthlyStats {
  month: string;
  total: number;
  approved: number;
  pending: number;
  rejected: number;
}

export interface CategoryStats {
  category: ExpenseCategory;
  amount: number;
  count: number;
}

export const monthlyStats: MonthlyStats[] = [
  { month: 'Aug', total: 3200, approved: 2800, pending: 200, rejected: 200 },
  { month: 'Sep', total: 4100, approved: 3500, pending: 400, rejected: 200 },
  { month: 'Oct', total: 2800, approved: 2400, pending: 300, rejected: 100 },
  { month: 'Nov', total: 5200, approved: 4200, pending: 600, rejected: 400 },
  { month: 'Dec', total: 6100, approved: 5000, pending: 800, rejected: 300 },
  { month: 'Jan', total: 5234.50, approved: 2450, pending: 449, rejected: 280 },
];

export const categoryStats: CategoryStats[] = [
  { category: 'travel', amount: 2100, count: 4 },
  { category: 'meals', amount: 605, count: 4 },
  { category: 'equipment', amount: 1899, count: 3 },
  { category: 'software', amount: 449, count: 4 },
  { category: 'supplies', amount: 156.50, count: 3 },
  { category: 'other', amount: 25, count: 1 },
];
