export type ModuleType = 'api' | 'auth' | 'database' | 'ui';

export interface DocumentSection {
  id: string;
  title: string;
  content: string;
  codeExample?: string;
}

export interface TechDocument {
  id: string;
  title: string;
  module: ModuleType;
  description: string;
  sections: DocumentSection[];
  relatedDocIds: string[];
  lastUpdated: string;
  author: string;
  version: string;
}

export interface Module {
  id: ModuleType;
  name: string;
  description: string;
  icon: string;
  documentCount: number;
}

export const modules: Module[] = [
  {
    id: 'api',
    name: 'API Gateway',
    description: 'RESTful API specifications and endpoints',
    icon: 'Globe',
    documentCount: 3,
  },
  {
    id: 'auth',
    name: 'Authentication',
    description: 'Security, OAuth, and session management',
    icon: 'Shield',
    documentCount: 2,
  },
  {
    id: 'database',
    name: 'Database',
    description: 'Schema design, queries, and migrations',
    icon: 'Database',
    documentCount: 2,
  },
  {
    id: 'ui',
    name: 'UI Components',
    description: 'React component library and design system',
    icon: 'Layout',
    documentCount: 2,
  },
];

export const documents: TechDocument[] = [
  {
    id: 'api-rest-standards',
    title: 'REST API Design Standards',
    module: 'api',
    description: 'Guidelines for designing consistent and scalable RESTful APIs',
    lastUpdated: '2024-01-15',
    author: 'Alex Chen',
    version: '2.1.0',
    sections: [
      {
        id: 'naming',
        title: 'Resource Naming Conventions',
        content: 'All API endpoints should follow kebab-case naming conventions. Resources should be nouns, not verbs. Use plural forms for collections (e.g., /users, /orders). Nested resources should reflect the relationship clearly.',
        codeExample: `// Good examples
GET /api/v1/users
GET /api/v1/users/{id}/orders
POST /api/v1/expense-reports

// Bad examples
GET /api/v1/getUsers
GET /api/v1/user/order/{id}`,
      },
      {
        id: 'versioning',
        title: 'API Versioning Strategy',
        content: 'We use URL-based versioning with the format /api/v{major}. Breaking changes require a new major version. Minor updates and patches should be backward compatible.',
      },
      {
        id: 'response-format',
        title: 'Response Format',
        content: 'All responses must follow a consistent JSON structure with data envelope. Include metadata for pagination where applicable. Error responses should include error code, message, and optional details.',
        codeExample: `{
  "success": true,
  "data": { ... },
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 150
  }
}`,
      },
    ],
    relatedDocIds: ['api-error-handling', 'auth-jwt-implementation'],
  },
  {
    id: 'api-error-handling',
    title: 'Error Handling Guidelines',
    module: 'api',
    description: 'Standardized error responses and exception handling patterns',
    lastUpdated: '2024-01-10',
    author: 'Sarah Kim',
    version: '1.3.0',
    sections: [
      {
        id: 'error-codes',
        title: 'Standard Error Codes',
        content: 'Use HTTP status codes correctly. 4xx for client errors, 5xx for server errors. Include application-specific error codes for detailed error handling on the client side.',
        codeExample: `// Error Response Structure
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      { "field": "email", "message": "Invalid email format" }
    ]
  }
}`,
      },
      {
        id: 'retry-logic',
        title: 'Retry and Timeout Handling',
        content: 'Implement exponential backoff for transient failures. Set reasonable timeout limits. Include Retry-After header for rate-limited responses.',
      },
    ],
    relatedDocIds: ['api-rest-standards'],
  },
  {
    id: 'api-rate-limiting',
    title: 'Rate Limiting Configuration',
    module: 'api',
    description: 'Request throttling and quota management specifications',
    lastUpdated: '2024-01-08',
    author: 'Mike Johnson',
    version: '1.0.0',
    sections: [
      {
        id: 'limits',
        title: 'Rate Limit Tiers',
        content: 'Different API consumers have different rate limits based on their tier. Free tier: 100 requests/minute. Pro tier: 1000 requests/minute. Enterprise: Custom limits.',
      },
      {
        id: 'headers',
        title: 'Rate Limit Headers',
        content: 'All responses include rate limit headers to help clients manage their request frequency.',
        codeExample: `X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1704067200`,
      },
    ],
    relatedDocIds: ['api-rest-standards', 'api-error-handling'],
  },
  {
    id: 'auth-jwt-implementation',
    title: 'JWT Authentication',
    module: 'auth',
    description: 'JSON Web Token implementation and security best practices',
    lastUpdated: '2024-01-12',
    author: 'David Park',
    version: '3.0.0',
    sections: [
      {
        id: 'token-structure',
        title: 'Token Structure',
        content: 'JWTs consist of three parts: header, payload, and signature. We use RS256 algorithm for signing. Access tokens expire in 15 minutes, refresh tokens in 7 days.',
        codeExample: `// Token payload structure
{
  "sub": "user_123",
  "email": "user@example.com",
  "roles": ["user", "admin"],
  "iat": 1704067200,
  "exp": 1704068100
}`,
      },
      {
        id: 'refresh-flow',
        title: 'Token Refresh Flow',
        content: 'When access token expires, use the refresh token to obtain a new access token. Refresh tokens are rotated on each use to prevent token reuse attacks.',
      },
      {
        id: 'security',
        title: 'Security Considerations',
        content: 'Store tokens securely. Use HttpOnly cookies for web applications. Implement token revocation for logout and security incidents. Never store sensitive data in JWT payload.',
      },
    ],
    relatedDocIds: ['auth-oauth-integration', 'api-rest-standards'],
  },
  {
    id: 'auth-oauth-integration',
    title: 'OAuth 2.0 Integration',
    module: 'auth',
    description: 'Third-party authentication provider integration guide',
    lastUpdated: '2024-01-05',
    author: 'Emily Wong',
    version: '2.0.0',
    sections: [
      {
        id: 'providers',
        title: 'Supported Providers',
        content: 'We support Google, GitHub, and Microsoft as OAuth providers. Each provider requires specific configuration and scopes.',
      },
      {
        id: 'flow',
        title: 'Authorization Flow',
        content: 'We implement the Authorization Code flow with PKCE for enhanced security. This is suitable for both web and mobile applications.',
        codeExample: `// OAuth flow endpoints
GET /auth/oauth/{provider}/authorize
POST /auth/oauth/{provider}/callback
POST /auth/oauth/{provider}/token`,
      },
    ],
    relatedDocIds: ['auth-jwt-implementation'],
  },
  {
    id: 'db-schema-design',
    title: 'Database Schema Guidelines',
    module: 'database',
    description: 'Best practices for designing efficient database schemas',
    lastUpdated: '2024-01-14',
    author: 'Chris Lee',
    version: '1.5.0',
    sections: [
      {
        id: 'naming',
        title: 'Naming Conventions',
        content: 'Use snake_case for table and column names. Prefix junction tables with both related table names. Use descriptive names that reflect the business domain.',
        codeExample: `-- Good naming
CREATE TABLE expense_reports (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Junction table
CREATE TABLE expense_report_attachments (
  expense_report_id UUID,
  attachment_id UUID,
  PRIMARY KEY (expense_report_id, attachment_id)
);`,
      },
      {
        id: 'indexes',
        title: 'Indexing Strategy',
        content: 'Create indexes for frequently queried columns. Use composite indexes for multi-column queries. Avoid over-indexing as it impacts write performance.',
      },
    ],
    relatedDocIds: ['db-migrations'],
  },
  {
    id: 'db-migrations',
    title: 'Database Migration Guide',
    module: 'database',
    description: 'Version-controlled database schema migrations',
    lastUpdated: '2024-01-11',
    author: 'Lisa Chen',
    version: '1.2.0',
    sections: [
      {
        id: 'structure',
        title: 'Migration File Structure',
        content: 'Each migration file should have an up and down function. File names follow the pattern: YYYYMMDDHHMMSS_description.sql',
        codeExample: `-- 20240115120000_add_expense_categories.sql
-- Up
ALTER TABLE expense_reports
ADD COLUMN category_id UUID REFERENCES categories(id);

-- Down
ALTER TABLE expense_reports
DROP COLUMN category_id;`,
      },
      {
        id: 'best-practices',
        title: 'Migration Best Practices',
        content: 'Always test migrations in staging before production. Make migrations reversible when possible. Avoid data migrations in schema migration files.',
      },
    ],
    relatedDocIds: ['db-schema-design'],
  },
  {
    id: 'ui-component-library',
    title: 'Component Library Overview',
    module: 'ui',
    description: 'React component library architecture and usage',
    lastUpdated: '2024-01-13',
    author: 'Tom Wilson',
    version: '4.0.0',
    sections: [
      {
        id: 'architecture',
        title: 'Component Architecture',
        content: 'Components follow atomic design principles. We have atoms (buttons, inputs), molecules (form fields, cards), and organisms (forms, tables). All components are fully typed with TypeScript.',
      },
      {
        id: 'styling',
        title: 'Styling Approach',
        content: 'We use Tailwind CSS with custom design tokens. All colors and spacing values come from the design system. Components support variant props for different visual styles.',
        codeExample: `// Button variants
<Button variant="primary">Primary</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="ghost">Ghost</Button>`,
      },
      {
        id: 'accessibility',
        title: 'Accessibility Requirements',
        content: 'All components must meet WCAG 2.1 AA standards. Include proper ARIA attributes. Support keyboard navigation. Maintain minimum contrast ratios.',
      },
    ],
    relatedDocIds: ['ui-form-patterns'],
  },
  {
    id: 'ui-form-patterns',
    title: 'Form Design Patterns',
    module: 'ui',
    description: 'Standard patterns for form validation and submission',
    lastUpdated: '2024-01-09',
    author: 'Rachel Green',
    version: '2.2.0',
    sections: [
      {
        id: 'validation',
        title: 'Validation Strategy',
        content: 'Use Zod schemas for form validation. Show inline errors below fields. Validate on blur for individual fields, validate all on submit. Disable submit button during validation.',
        codeExample: `const formSchema = z.object({
  email: z.string().email("Invalid email"),
  amount: z.number().min(0, "Amount must be positive"),
  date: z.date(),
});`,
      },
      {
        id: 'multi-step',
        title: 'Multi-Step Forms',
        content: 'Break complex forms into logical steps. Show progress indicator. Validate each step before allowing progression. Allow navigation back to previous steps without losing data.',
      },
    ],
    relatedDocIds: ['ui-component-library'],
  },
];

export function getDocumentById(id: string): TechDocument | undefined {
  return documents.find(doc => doc.id === id);
}

export function getDocumentsByModule(module: ModuleType): TechDocument[] {
  return documents.filter(doc => doc.module === module);
}

export function getRelatedDocuments(docId: string): TechDocument[] {
  const doc = getDocumentById(docId);
  if (!doc) return [];
  return doc.relatedDocIds
    .map(id => getDocumentById(id))
    .filter((d): d is TechDocument => d !== undefined);
}
