import { useState } from 'react';
import { Search, Book, FileText, ArrowRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { DocumentCard } from '@/components/documents/DocumentCard';
import { MainLayout } from '@/components/layout/MainLayout';
import { documents, modules, type ModuleType } from '@/data/documents';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ReactNode> = {
  Globe: '🌐',
  Shield: '🛡️',
  Database: '🗄️',
  Layout: '📱',
};

export default function Index() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModule, setSelectedModule] = useState<ModuleType | 'all'>('all');

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesModule = selectedModule === 'all' || doc.module === selectedModule;
    return matchesSearch && matchesModule;
  });

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-accent/10">
              <Book className="w-6 h-6 text-accent" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">
              Technical Knowledge Base
            </h1>
          </div>
          <p className="text-muted-foreground">
            Browse technical specifications, API documentation, and engineering guidelines
          </p>
        </div>

        {/* Search and filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search documentation..."
              className="pl-10 h-12"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setSelectedModule('all')}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-colors',
                selectedModule === 'all'
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              )}
            >
              All Modules
            </button>
            {modules.map((module) => (
              <button
                key={module.id}
                onClick={() => setSelectedModule(module.id)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2',
                  selectedModule === module.id
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                )}
              >
                <span>{iconMap[module.icon]}</span>
                {module.name}
              </button>
            ))}
          </div>
        </div>

        {/* Module overview cards */}
        {selectedModule === 'all' && !searchQuery && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {modules.map((module) => (
              <button
                key={module.id}
                onClick={() => setSelectedModule(module.id)}
                className="p-4 rounded-xl bg-card border border-border hover:border-accent hover:shadow-lg transition-all text-left group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{iconMap[module.icon]}</span>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-accent group-hover:translate-x-1 transition-all" />
                </div>
                <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors">
                  {module.name}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  {module.description}
                </p>
                <p className="text-xs text-accent mt-2">
                  {module.documentCount} documents
                </p>
              </button>
            ))}
          </div>
        )}

        {/* Documents grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
              <FileText className="w-5 h-5 text-accent" />
              {selectedModule === 'all' ? 'All Documents' : modules.find(m => m.id === selectedModule)?.name}
              <span className="text-sm font-normal text-muted-foreground">
                ({filteredDocs.length} documents)
              </span>
            </h2>
          </div>

          {filteredDocs.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No documents found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDocs.map((doc) => (
                <DocumentCard key={doc.id} document={doc} />
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
