import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Clock, User, Tag, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MainLayout } from '@/components/layout/MainLayout';
import { CollapsibleSection } from '@/components/documents/CollapsibleSection';
import { RelatedDocuments } from '@/components/documents/RelatedDocuments';
import { ModuleBadge } from '@/components/documents/ModuleBadge';
import { getDocumentById, getRelatedDocuments } from '@/data/documents';

export default function DocumentDetail() {
  const { id } = useParams<{ id: string }>();
  const document = id ? getDocumentById(id) : undefined;
  const relatedDocs = id ? getRelatedDocuments(id) : [];

  if (!document) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto text-center py-12">
          <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Document Not Found
          </h1>
          <p className="text-muted-foreground mb-6">
            The document you're looking for doesn't exist.
          </p>
          <Link to="/">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Knowledge Base
            </Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto">
        {/* Back navigation */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Knowledge Base
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl mb-2">{document.title}</CardTitle>
                    <p className="text-muted-foreground">{document.description}</p>
                  </div>
                  <ModuleBadge module={document.module} />
                </div>
                <div className="flex flex-wrap items-center gap-4 pt-4 border-t text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    {document.author}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {document.lastUpdated}
                  </div>
                  <div className="flex items-center gap-1">
                    <Tag className="w-4 h-4" />
                    v{document.version}
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Sections */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-accent" />
                  Content Sections
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {document.sections.map((section, index) => (
                  <CollapsibleSection
                    key={section.id}
                    section={section}
                    defaultExpanded={index === 0}
                  />
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Table of Contents */}
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">On This Page</CardTitle>
              </CardHeader>
              <CardContent>
                <nav className="space-y-2">
                  {document.sections.map((section) => (
                    <a
                      key={section.id}
                      href={`#${section.id}`}
                      className="block text-sm text-muted-foreground hover:text-accent transition-colors py-1 border-l-2 border-transparent hover:border-accent pl-3"
                    >
                      {section.title}
                    </a>
                  ))}
                </nav>
              </CardContent>
            </Card>

            {/* Related Documents */}
            <RelatedDocuments documents={relatedDocs} />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
