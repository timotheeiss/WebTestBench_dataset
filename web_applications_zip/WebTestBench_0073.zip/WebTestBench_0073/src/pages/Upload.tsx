import { Upload as UploadIcon, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MainLayout } from '@/components/layout/MainLayout';
import { UploadZone } from '@/components/upload/UploadZone';
import { MultiStepForm } from '@/components/forms/MultiStepForm';

export default function Upload() {
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-accent/10">
              <UploadIcon className="w-6 h-6 text-accent" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">
              Upload Receipts
            </h1>
          </div>
          <p className="text-muted-foreground">
            Upload receipts and create new expense reports
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Zone */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-accent" />
                Upload Receipts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <UploadZone />
            </CardContent>
          </Card>

          {/* New Expense Form */}
          <div>
            <MultiStepForm />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
