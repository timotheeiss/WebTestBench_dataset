import { 
  BarChart3, 
  DollarSign, 
  TrendingUp, 
  FileCheck, 
  Clock,
  Download 
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/statistics/StatCard';
import { monthlyStats, categoryStats, categoryLabels } from '@/data/expenses';

const COLORS = ['hsl(173, 58%, 39%)', 'hsl(215, 28%, 45%)', 'hsl(38, 92%, 50%)', 'hsl(142, 71%, 45%)', 'hsl(199, 89%, 48%)', 'hsl(0, 84%, 60%)'];

export default function Statistics() {
  const totalExpenses = monthlyStats.reduce((sum, m) => sum + m.total, 0);
  const totalApproved = monthlyStats.reduce((sum, m) => sum + m.approved, 0);
  const approvalRate = ((totalApproved / totalExpenses) * 100).toFixed(1);
  const avgProcessingTime = '3.2 days';

  const pieData = categoryStats.map((stat) => ({
    name: categoryLabels[stat.category],
    value: stat.amount,
  }));

  const handleExport = () => {
    // Create CSV content
    const headers = ['Month', 'Total', 'Approved', 'Pending', 'Rejected'];
    const rows = monthlyStats.map(m => 
      [m.month, m.total, m.approved, m.pending, m.rejected].join(',')
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    
    // Download
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'expense-statistics.csv';
    a.click();
  };

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-accent/10">
                <BarChart3 className="w-6 h-6 text-accent" />
              </div>
              <h1 className="text-3xl font-bold text-foreground">
                Statistics
              </h1>
            </div>
            <p className="text-muted-foreground">
              Personal expense reimbursement analytics and insights
            </p>
          </div>
          <Button onClick={handleExport} className="gap-2">
            <Download className="w-4 h-4" />
            Export Data
          </Button>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Total Expenses"
            value={`$${totalExpenses.toLocaleString()}`}
            change="+12% from last period"
            changeType="positive"
            icon={DollarSign}
            gradient="from-accent/20 to-accent/5"
          />
          <StatCard
            title="Approval Rate"
            value={`${approvalRate}%`}
            change="+2.4% from last period"
            changeType="positive"
            icon={FileCheck}
            gradient="from-success/20 to-success/5"
          />
          <StatCard
            title="Avg. Processing"
            value={avgProcessingTime}
            change="-0.5 days from last period"
            changeType="positive"
            icon={Clock}
            gradient="from-info/20 to-info/5"
          />
          <StatCard
            title="Pending Amount"
            value={`$${monthlyStats[5].pending.toLocaleString()}`}
            change="3 reports pending"
            changeType="neutral"
            icon={TrendingUp}
            gradient="from-warning/20 to-warning/5"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Monthly Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly Expense Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyStats}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="month" 
                      stroke="hsl(var(--muted-foreground))"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                      tickFormatter={(value) => `$${value}`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                      formatter={(value: number) => [`$${value}`, '']}
                    />
                    <Bar 
                      dataKey="approved" 
                      name="Approved"
                      fill="hsl(var(--success))" 
                      radius={[4, 4, 0, 0]} 
                    />
                    <Bar 
                      dataKey="pending" 
                      name="Pending"
                      fill="hsl(var(--warning))" 
                      radius={[4, 4, 0, 0]} 
                    />
                    <Bar 
                      dataKey="rejected" 
                      name="Rejected"
                      fill="hsl(var(--destructive))" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Expenses by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => 
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {pieData.map((_, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={COLORS[index % COLORS.length]} 
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                      formatter={(value: number) => [`$${value}`, '']}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Category Breakdown Table */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                      Category
                    </th>
                    <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                      Items
                    </th>
                    <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                      Amount
                    </th>
                    <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                      % of Total
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {categoryStats.map((stat, index) => (
                    <tr key={stat.category} className="border-b last:border-0">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: COLORS[index] }}
                          />
                          <span className="font-medium text-foreground">
                            {categoryLabels[stat.category]}
                          </span>
                        </div>
                      </td>
                      <td className="text-right py-3 px-4 text-muted-foreground">
                        {stat.count}
                      </td>
                      <td className="text-right py-3 px-4 font-medium text-foreground">
                        ${stat.amount.toFixed(2)}
                      </td>
                      <td className="text-right py-3 px-4 text-muted-foreground">
                        {((stat.amount / 5234.5) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
