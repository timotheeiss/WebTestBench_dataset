import { useState, useMemo } from 'react';
import { FileText, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MainLayout } from '@/components/layout/MainLayout';
import { ExpenseCard } from '@/components/expenses/ExpenseCard';
import { ExpenseFilters, type FilterState } from '@/components/expenses/ExpenseFilters';
import { sampleExpenseReports } from '@/data/expenses';

export default function Expenses() {
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    status: 'all',
    category: 'all',
    dateFrom: '',
    dateTo: '',
    minAmount: '',
    maxAmount: '',
  });

  const filteredReports = useMemo(() => {
    return sampleExpenseReports.filter((report) => {
      // Search filter
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        if (
          !report.title.toLowerCase().includes(searchLower) &&
          !report.submittedBy.toLowerCase().includes(searchLower)
        ) {
          return false;
        }
      }

      // Status filter
      if (filters.status !== 'all' && report.status !== filters.status) {
        return false;
      }

      // Category filter (check if any item matches the category)
      if (filters.category !== 'all') {
        const hasCategory = report.items.some(
          (item) => item.category === filters.category
        );
        if (!hasCategory) return false;
      }

      // Date range filter
      if (filters.dateFrom && report.createdAt < filters.dateFrom) {
        return false;
      }
      if (filters.dateTo && report.createdAt > filters.dateTo) {
        return false;
      }

      // Amount range filter
      if (filters.minAmount && report.totalAmount < parseFloat(filters.minAmount)) {
        return false;
      }
      if (filters.maxAmount && report.totalAmount > parseFloat(filters.maxAmount)) {
        return false;
      }

      return true;
    });
  }, [filters]);

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-accent/10">
                <FileText className="w-6 h-6 text-accent" />
              </div>
              <h1 className="text-3xl font-bold text-foreground">
                Expense Reports
              </h1>
            </div>
            <p className="text-muted-foreground">
              Manage and track your expense reimbursement requests
            </p>
          </div>
          <Link to="/upload">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              New Report
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="mb-6">
          <ExpenseFilters filters={filters} onFilterChange={setFilters} />
        </div>

        {/* Reports Grid */}
        {filteredReports.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No expense reports found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredReports.map((report) => (
              <ExpenseCard key={report.id} report={report} />
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
