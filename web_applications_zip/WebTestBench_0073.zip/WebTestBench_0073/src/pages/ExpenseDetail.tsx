import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  DollarSign, 
  Calendar, 
  User, 
  Paperclip,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatusBadge } from '@/components/expenses/StatusBadge';
import { Timeline } from '@/components/expenses/Timeline';
import { AttachmentPreview } from '@/components/expenses/AttachmentPreview';
import { sampleExpenseReports, categoryLabels } from '@/data/expenses';

export default function ExpenseDetail() {
  const { id } = useParams<{ id: string }>();
  const report = sampleExpenseReports.find((r) => r.id === id);

  if (!report) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto text-center py-12">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Expense Report Not Found
          </h1>
          <p className="text-muted-foreground mb-6">
            The expense report you're looking for doesn't exist.
          </p>
          <Link to="/expenses">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Expenses
            </Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto">
        {/* Back navigation */}
        <Link
          to="/expenses"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Expense Reports
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl mb-2">{report.title}</CardTitle>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {report.submittedBy}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {report.createdAt}
                      </div>
                    </div>
                  </div>
                  <StatusBadge status={report.status} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-3xl font-bold text-foreground">
                  <DollarSign className="w-8 h-8 text-accent" />
                  {report.totalAmount.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Expense Items */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-accent" />
                  Expense Items ({report.items.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="divide-y">
                  {report.items.map((item) => (
                    <div key={item.id} className="py-4 first:pt-0 last:pb-0">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="font-medium text-foreground">
                            {item.description}
                          </p>
                          <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                            <span className="px-2 py-0.5 bg-secondary rounded text-xs">
                              {categoryLabels[item.category]}
                            </span>
                            <span>{item.date}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">
                            ${item.amount.toFixed(2)}
                          </p>
                          {item.attachmentIds.length > 0 && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1 justify-end mt-1">
                              <Paperclip className="w-3 h-3" />
                              {item.attachmentIds.length} attachment(s)
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Attachments */}
            {report.attachments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Paperclip className="w-5 h-5 text-accent" />
                    Attachments ({report.attachments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {report.attachments.map((attachment) => (
                      <AttachmentPreview
                        key={attachment.id}
                        attachment={attachment}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Approval Timeline */}
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">Approval Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <Timeline entries={report.timeline} />
              </CardContent>
            </Card>

            {/* Actions */}
            {(report.status === 'draft' || report.status === 'revision') && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button className="w-full">Submit for Approval</Button>
                  <Button variant="outline" className="w-full">
                    Edit Report
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
