import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Challenge, DifficultyLevel } from '@/types';
import { CheckCircle, Clock, Zap } from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';

interface ChallengeCardProps {
  challenge: Challenge;
}

const difficultyConfig: Record<DifficultyLevel, { color: string; icon: React.ReactNode }> = {
  easy: { color: 'bg-success/20 text-success border-success/30', icon: <CheckCircle className="w-3 h-3" /> },
  medium: { color: 'bg-warning/20 text-warning border-warning/30', icon: <Clock className="w-3 h-3" /> },
  hard: { color: 'bg-destructive/20 text-destructive border-destructive/30', icon: <Zap className="w-3 h-3" /> },
};

export const ChallengeCard = ({ challenge }: ChallengeCardProps) => {
  const currentUser = getCurrentUser();
  const isSolved = currentUser?.solvedChallenges.includes(challenge.id);
  const config = difficultyConfig[challenge.difficulty];

  return (
    <Link to={`/challenge/${challenge.id}`}>
      <Card className="h-full hover:border-primary/50 transition-all duration-300 hover:shadow-glow/20 group bg-card/50">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-lg group-hover:text-primary transition-colors line-clamp-2">
              {challenge.title}
            </CardTitle>
            {isSolved && (
              <CheckCircle className="w-5 h-5 text-success flex-shrink-0" />
            )}
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="outline" className={`${config.color} flex items-center gap-1`}>
              {config.icon}
              {challenge.difficulty}
            </Badge>
            <Badge variant="secondary" className="capitalize">
              {challenge.topic.replace('-', ' ')}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {challenge.description.slice(0, 100)}...
          </p>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              {challenge.testCases.length} test cases
            </span>
            <span className="text-sm font-semibold text-primary">
              +{challenge.points} pts
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};
