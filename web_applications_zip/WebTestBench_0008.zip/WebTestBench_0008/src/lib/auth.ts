import { User } from '@/types';

const USERS_KEY = 'codeforge_users';
const CURRENT_USER_KEY = 'codeforge_current_user';

// Initialize with demo users
const demoUsers: User[] = [
  { id: '1', username: 'alice_codes', email: 'alice@demo.com', totalPoints: 80, solvedChallenges: ['1', '2', '3', '7', '8'] },
  { id: '2', username: 'bob_dev', email: 'bob@demo.com', totalPoints: 50, solvedChallenges: ['1', '2', '4'] },
  { id: '3', username: 'charlie_algo', email: 'charlie@demo.com', totalPoints: 110, solvedChallenges: ['1', '2', '3', '4', '5', '6', '7'] },
];

export const initializeStorage = () => {
  if (!localStorage.getItem(USERS_KEY)) {
    localStorage.setItem(USERS_KEY, JSON.stringify(demoUsers));
  }
};

export const getCurrentUser = (): User | null => {
  const userId = localStorage.getItem(CURRENT_USER_KEY);
  if (!userId) return null;
  
  const users = getUsers();
  return users.find(u => u.id === userId) || null;
};

export const login = (email: string, password: string): User | null => {
  const users = getUsers();
  const user = users.find(u => u.email === email);
  
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, user.id);
    return user;
  }
  return null;
};

export const register = (username: string, email: string, password: string): User => {
  const users = getUsers();
  const newUser: User = {
    id: Date.now().toString(),
    username,
    email,
    totalPoints: 0,
    solvedChallenges: [],
  };
  
  users.push(newUser);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  localStorage.setItem(CURRENT_USER_KEY, newUser.id);
  
  return newUser;
};

export const logout = () => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

export const updateUser = (user: User) => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  if (index !== -1) {
    users[index] = user;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
};

export const getUsers = (): User[] => {
  const usersJson = localStorage.getItem(USERS_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};
