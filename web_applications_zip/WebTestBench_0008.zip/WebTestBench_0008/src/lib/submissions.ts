import { Submission } from '@/types';

const SUBMISSIONS_KEY = 'codeforge_submissions';

export const getSubmissions = (): Submission[] => {
  const submissionsJson = localStorage.getItem(SUBMISSIONS_KEY);
  return submissionsJson ? JSON.parse(submissionsJson) : [];
};

export const getUserSubmissions = (userId: string): Submission[] => {
  return getSubmissions().filter(s => s.userId === userId);
};

export const addSubmission = (submission: Submission) => {
  const submissions = getSubmissions();
  submissions.push(submission);
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
};

export const getChallengeSubmissions = (userId: string, challengeId: string): Submission[] => {
  return getSubmissions().filter(s => s.userId === userId && s.challengeId === challengeId);
};
