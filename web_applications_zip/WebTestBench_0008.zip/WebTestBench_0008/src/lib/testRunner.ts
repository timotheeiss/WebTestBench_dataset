import { Challenge } from '@/types';

export const runTests = (challenge: Challenge, code: string) => {
  const results = {
    passed: 0,
    total: challenge.testCases.length,
    details: [] as { input: string; expected: string; actual: string; passed: boolean }[],
  };

  challenge.testCases.forEach(testCase => {
    try {
      // Create a sandboxed function from user code
      const wrappedCode = `
        ${code}
        return ${extractFunctionName(code)}(${testCase.input});
      `;
      
      const func = new Function(wrappedCode);
      const actual = func();
      const actualStr = JSON.stringify(actual);
      const expectedStr = testCase.expected;
      
      const passed = actualStr === expectedStr;
      
      if (passed) results.passed++;
      
      results.details.push({
        input: testCase.input,
        expected: expectedStr,
        actual: actualStr,
        passed,
      });
    } catch (error) {
      results.details.push({
        input: testCase.input,
        expected: testCase.expected,
        actual: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        passed: false,
      });
    }
  });

  return results;
};

const extractFunctionName = (code: string): string => {
  const match = code.match(/function\s+(\w+)\s*\(/);
  return match ? match[1] : 'solution';
};
