export type DifficultyLevel = 'easy' | 'medium' | 'hard';
export type Topic = 'arrays' | 'strings' | 'algorithms' | 'data-structures' | 'dynamic-programming' | 'recursion';

export interface TestCase {
  input: string;
  expected: string;
  hidden?: boolean;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: DifficultyLevel;
  topic: Topic;
  points: number;
  testCases: TestCase[];
  starterCode: string;
  hints?: string[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  totalPoints: number;
  solvedChallenges: string[];
}

export interface Submission {
  id: string;
  userId: string;
  challengeId: string;
  code: string;
  passed: boolean;
  testResults: {
    passed: number;
    total: number;
    details: { input: string; expected: string; actual: string; passed: boolean }[];
  };
  submittedAt: string;
  pointsEarned: number;
}
