import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { Navbar } from '@/components/Navbar';
import { challenges } from '@/data/challenges';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { runTests } from '@/lib/testRunner';
import { addSubmission, getChallengeSubmissions } from '@/lib/submissions';
import { getCurrentUser, updateUser } from '@/lib/auth';
import { toast } from 'sonner';
import { CheckCircle, XCircle, Play, ArrowLeft, Clock, Zap, Trophy } from 'lucide-react';
import { Submission } from '@/types';

const difficultyColors = {
  easy: 'bg-success/20 text-success border-success/30',
  medium: 'bg-warning/20 text-warning border-warning/30',
  hard: 'bg-destructive/20 text-destructive border-destructive/30',
};

const ChallengeDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const challenge = challenges.find(c => c.id === id);
  const currentUser = getCurrentUser();
  
  const [code, setCode] = useState(challenge?.starterCode || '');
  const [testResults, setTestResults] = useState<Submission['testResults'] | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  if (!challenge) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 text-center">
          <p>Challenge not found</p>
          <Button onClick={() => navigate('/challenges')} className="mt-4">
            Back to Challenges
          </Button>
        </div>
      </div>
    );
  }

  const isSolved = currentUser?.solvedChallenges.includes(challenge.id);
  const pastSubmissions = currentUser ? getChallengeSubmissions(currentUser.id, challenge.id) : [];

  const handleRunTests = () => {
    setIsRunning(true);
    
    setTimeout(() => {
      const results = runTests(challenge, code);
      setTestResults(results);
      
      const passed = results.passed === results.total;
      
      if (currentUser) {
        const pointsEarned = passed && !isSolved ? challenge.points : 0;
        
        const submission: Submission = {
          id: Date.now().toString(),
          userId: currentUser.id,
          challengeId: challenge.id,
          code,
          passed,
          testResults: results,
          submittedAt: new Date().toISOString(),
          pointsEarned,
        };
        
        addSubmission(submission);

        if (passed && !isSolved) {
          const updatedUser = {
            ...currentUser,
            totalPoints: currentUser.totalPoints + challenge.points,
            solvedChallenges: [...currentUser.solvedChallenges, challenge.id],
          };
          updateUser(updatedUser);
          toast.success(`Congratulations! You earned ${challenge.points} points!`);
        } else if (passed) {
          toast.success('All tests passed!');
        } else {
          toast.error(`${results.passed}/${results.total} tests passed`);
        }
      }
      
      setIsRunning(false);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-4">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/challenges')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Challenges
        </Button>

        <div className="grid lg:grid-cols-2 gap-4 h-[calc(100vh-180px)]">
          {/* Left Panel - Problem Description */}
          <div className="flex flex-col overflow-hidden">
            <Card className="flex-1 overflow-hidden flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-xl mb-2 flex items-center gap-2">
                      {challenge.title}
                      {isSolved && <CheckCircle className="w-5 h-5 text-success" />}
                    </CardTitle>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className={difficultyColors[challenge.difficulty]}>
                        {challenge.difficulty === 'easy' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {challenge.difficulty === 'medium' && <Clock className="w-3 h-3 mr-1" />}
                        {challenge.difficulty === 'hard' && <Zap className="w-3 h-3 mr-1" />}
                        {challenge.difficulty}
                      </Badge>
                      <Badge variant="secondary" className="capitalize">
                        {challenge.topic.replace('-', ' ')}
                      </Badge>
                      <Badge variant="outline" className="text-primary border-primary/30">
                        <Trophy className="w-3 h-3 mr-1" />
                        {challenge.points} pts
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto">
                <Tabs defaultValue="description">
                  <TabsList className="mb-4">
                    <TabsTrigger value="description">Description</TabsTrigger>
                    <TabsTrigger value="history">History ({pastSubmissions.length})</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="description" className="space-y-4">
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-foreground bg-transparent p-0">
                        {challenge.description}
                      </pre>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Examples</h4>
                      {challenge.testCases.slice(0, 2).map((test, i) => (
                        <div key={i} className="bg-muted/50 rounded-lg p-3 mb-2 font-mono text-sm">
                          <p><span className="text-muted-foreground">Input:</span> {test.input}</p>
                          <p><span className="text-muted-foreground">Output:</span> {test.expected}</p>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="history">
                    {pastSubmissions.length === 0 ? (
                      <p className="text-muted-foreground text-sm">No submissions yet</p>
                    ) : (
                      <div className="space-y-2">
                        {pastSubmissions.slice().reverse().map(sub => (
                          <div 
                            key={sub.id}
                            className={`p-3 rounded-lg border ${sub.passed ? 'border-success/30 bg-success/5' : 'border-destructive/30 bg-destructive/5'}`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {sub.passed ? (
                                  <CheckCircle className="w-4 h-4 text-success" />
                                ) : (
                                  <XCircle className="w-4 h-4 text-destructive" />
                                )}
                                <span className="text-sm font-medium">
                                  {sub.testResults.passed}/{sub.testResults.total} passed
                                </span>
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {new Date(sub.submittedAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Code Editor */}
          <div className="flex flex-col gap-4 overflow-hidden">
            <Card className="flex-1 overflow-hidden flex flex-col">
              <CardHeader className="py-3 flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium">JavaScript</CardTitle>
                <Button 
                  onClick={handleRunTests}
                  disabled={isRunning}
                  className="bg-gradient-primary shadow-glow"
                  size="sm"
                >
                  <Play className="w-4 h-4 mr-2" />
                  {isRunning ? 'Running...' : 'Run Tests'}
                </Button>
              </CardHeader>
              <CardContent className="flex-1 p-0 overflow-hidden">
                <Editor
                  height="100%"
                  defaultLanguage="javascript"
                  value={code}
                  onChange={(value) => setCode(value || '')}
                  theme="vs-dark"
                  options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    lineNumbers: 'on',
                    scrollBeyondLastLine: false,
                    automaticLayout: true,
                    tabSize: 2,
                  }}
                />
              </CardContent>
            </Card>

            {/* Test Results */}
            {testResults && (
              <Card className={`border ${testResults.passed === testResults.total ? 'border-success/50' : 'border-destructive/50'}`}>
                <CardHeader className="py-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    {testResults.passed === testResults.total ? (
                      <CheckCircle className="w-5 h-5 text-success" />
                    ) : (
                      <XCircle className="w-5 h-5 text-destructive" />
                    )}
                    Test Results: {testResults.passed}/{testResults.total} passed
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 max-h-40 overflow-auto">
                  <div className="space-y-2">
                    {testResults.details.map((result, i) => (
                      <div
                        key={i}
                        className={`p-2 rounded text-xs font-mono ${
                          result.passed ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                        }`}
                      >
                        <p>Input: {result.input}</p>
                        <p>Expected: {result.expected}</p>
                        <p>Got: {result.actual}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default ChallengeDetail;
