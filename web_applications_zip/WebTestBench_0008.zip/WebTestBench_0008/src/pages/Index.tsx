import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Navbar } from '@/components/Navbar';
import { Code2, Trophy, Target, Zap, ChevronRight, CheckCircle } from 'lucide-react';
import { challenges } from '@/data/challenges';

const Index = () => {
  const featuredChallenges = challenges.slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }} />
        </div>
        
        <div className="relative container mx-auto px-4 py-24 lg:py-32">
          <div className="max-w-3xl mx-auto text-center">
            <Badge variant="outline" className="mb-6 px-4 py-1 border-primary/30 text-primary">
              Level Up Your Coding Skills
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Master Programming Through
              <span className="text-gradient block">Practice & Challenges</span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Solve algorithmic challenges, learn from test cases, and track your progress. 
              Join thousands of developers improving their skills every day.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-gradient-primary shadow-glow text-lg">
                <Link to="/register">
                  Get Started Free
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg">
                <Link to="/challenges">
                  Browse Challenges
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why CodeForge?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to become a better programmer
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card rounded-xl p-6 border shadow-card hover:shadow-glow/10 transition-all">
              <div className="bg-gradient-primary w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Code2 className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Interactive Editor</h3>
              <p className="text-muted-foreground">
                Write code in a powerful Monaco editor with syntax highlighting and auto-completion.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 border shadow-card hover:shadow-glow/10 transition-all">
              <div className="bg-gradient-accent w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Instant Feedback</h3>
              <p className="text-muted-foreground">
                Run your code against test cases and get immediate feedback on your solutions.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 border shadow-card hover:shadow-glow/10 transition-all">
              <div className="bg-gradient-success w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Trophy className="w-6 h-6 text-success-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Track Progress</h3>
              <p className="text-muted-foreground">
                Earn points, climb the leaderboard, and track your improvement over time.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Challenges */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Challenges</h2>
              <p className="text-muted-foreground">Start with these popular problems</p>
            </div>
            <Button variant="outline" asChild>
              <Link to="/challenges">View All</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {featuredChallenges.map(challenge => (
              <Link key={challenge.id} to={`/challenge/${challenge.id}`}>
                <div className="bg-card rounded-xl p-6 border hover:border-primary/50 transition-all hover:shadow-glow/20 h-full">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge 
                      variant="outline" 
                      className={`
                        ${challenge.difficulty === 'easy' ? 'bg-success/20 text-success border-success/30' : ''}
                        ${challenge.difficulty === 'medium' ? 'bg-warning/20 text-warning border-warning/30' : ''}
                        ${challenge.difficulty === 'hard' ? 'bg-destructive/20 text-destructive border-destructive/30' : ''}
                      `}
                    >
                      {challenge.difficulty}
                    </Badge>
                    <Badge variant="secondary" className="capitalize">
                      {challenge.topic.replace('-', ' ')}
                    </Badge>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{challenge.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {challenge.description.slice(0, 100)}...
                  </p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {challenge.testCases.length} test cases
                    </span>
                    <span className="text-sm font-semibold text-primary">
                      +{challenge.points} pts
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-hero relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
        </div>
        
        <div className="relative container mx-auto px-4 text-center">
          <Target className="w-16 h-16 text-primary mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Coding?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Join our community of developers and start solving challenges today.
            It's completely free to get started.
          </p>
          <Button asChild size="lg" className="bg-gradient-primary shadow-glow">
            <Link to="/register">
              Create Free Account
              <ChevronRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-primary p-1.5 rounded-lg">
                <Code2 className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-semibold">CodeForge</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CodeForge. Built for developers, by developers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
