import { Navbar } from '@/components/Navbar';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { getCurrentUser } from '@/lib/auth';
import { getUserSubmissions } from '@/lib/submissions';
import { challenges } from '@/data/challenges';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { Trophy, Target, CheckCircle, Clock, Zap, TrendingUp, Code } from 'lucide-react';

const Dashboard = () => {
  const currentUser = getCurrentUser();
  const submissions = currentUser ? getUserSubmissions(currentUser.id) : [];
  
  const solvedCount = currentUser?.solvedChallenges.length || 0;
  const totalChallenges = challenges.length;
  const progressPercent = (solvedCount / totalChallenges) * 100;

  // Stats by difficulty
  const statsByDifficulty = {
    easy: { solved: 0, total: 0 },
    medium: { solved: 0, total: 0 },
    hard: { solved: 0, total: 0 },
  };

  challenges.forEach(c => {
    statsByDifficulty[c.difficulty].total++;
    if (currentUser?.solvedChallenges.includes(c.id)) {
      statsByDifficulty[c.difficulty].solved++;
    }
  });

  // Recent submissions
  const recentSubmissions = submissions.slice(-5).reverse();

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {currentUser?.username}!
            </h1>
            <p className="text-muted-foreground">
              Track your progress and keep coding
            </p>
          </div>

          {/* Stats Overview */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
            <Card className="bg-gradient-primary text-primary-foreground">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium opacity-90">Total Points</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Trophy className="w-8 h-8" />
                  <span className="text-3xl font-bold">{currentUser?.totalPoints || 0}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Challenges Solved</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Target className="w-8 h-8 text-primary" />
                  <span className="text-3xl font-bold">{solvedCount}</span>
                  <span className="text-muted-foreground">/ {totalChallenges}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Code className="w-8 h-8 text-accent" />
                  <span className="text-3xl font-bold">{submissions.length}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-8 h-8 text-success" />
                  <span className="text-3xl font-bold">
                    {submissions.length > 0 
                      ? Math.round((submissions.filter(s => s.passed).length / submissions.length) * 100)
                      : 0}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Progress by Difficulty */}
            <Card>
              <CardHeader>
                <CardTitle>Progress by Difficulty</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      <span className="text-sm font-medium">Easy</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {statsByDifficulty.easy.solved}/{statsByDifficulty.easy.total}
                    </span>
                  </div>
                  <Progress 
                    value={(statsByDifficulty.easy.solved / statsByDifficulty.easy.total) * 100} 
                    className="h-2 [&>div]:bg-success"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-warning" />
                      <span className="text-sm font-medium">Medium</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {statsByDifficulty.medium.solved}/{statsByDifficulty.medium.total}
                    </span>
                  </div>
                  <Progress 
                    value={(statsByDifficulty.medium.solved / statsByDifficulty.medium.total) * 100} 
                    className="h-2 [&>div]:bg-warning"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-destructive" />
                      <span className="text-sm font-medium">Hard</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {statsByDifficulty.hard.solved}/{statsByDifficulty.hard.total}
                    </span>
                  </div>
                  <Progress 
                    value={(statsByDifficulty.hard.solved / (statsByDifficulty.hard.total || 1)) * 100} 
                    className="h-2 [&>div]:bg-destructive"
                  />
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Overall Progress</span>
                    <span className="text-sm text-muted-foreground">
                      {Math.round(progressPercent)}%
                    </span>
                  </div>
                  <Progress value={progressPercent} className="h-3" />
                </div>
              </CardContent>
            </Card>

            {/* Recent Submissions */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                {recentSubmissions.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">No submissions yet</p>
                    <Link to="/challenges">
                      <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                        Start Coding
                      </Badge>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentSubmissions.map(sub => {
                      const challenge = challenges.find(c => c.id === sub.challengeId);
                      return (
                        <Link key={sub.id} to={`/challenge/${sub.challengeId}`}>
                          <div className={`p-3 rounded-lg border transition-colors hover:bg-muted/50 ${
                            sub.passed ? 'border-success/30' : 'border-destructive/30'
                          }`}>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {sub.passed ? (
                                  <CheckCircle className="w-4 h-4 text-success" />
                                ) : (
                                  <span className="w-4 h-4 rounded-full bg-destructive/20 flex items-center justify-center text-xs text-destructive">✕</span>
                                )}
                                <span className="font-medium text-sm">{challenge?.title}</span>
                              </div>
                              <div className="text-right">
                                <p className="text-xs text-muted-foreground">
                                  {new Date(sub.submittedAt).toLocaleDateString()}
                                </p>
                                {sub.pointsEarned > 0 && (
                                  <p className="text-xs text-success">+{sub.pointsEarned} pts</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  );
};

export default Dashboard;
