import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { ChallengeCard } from '@/components/ChallengeCard';
import { challenges } from '@/data/challenges';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search } from 'lucide-react';
import { DifficultyLevel, Topic } from '@/types';

const difficulties: DifficultyLevel[] = ['easy', 'medium', 'hard'];
const topics: Topic[] = ['arrays', 'strings', 'algorithms', 'data-structures', 'dynamic-programming', 'recursion'];

const Challenges = () => {
  const [search, setSearch] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  const filteredChallenges = challenges.filter(challenge => {
    const matchesSearch = challenge.title.toLowerCase().includes(search.toLowerCase()) ||
      challenge.description.toLowerCase().includes(search.toLowerCase());
    const matchesDifficulty = !selectedDifficulty || challenge.difficulty === selectedDifficulty;
    const matchesTopic = !selectedTopic || challenge.topic === selectedTopic;
    
    return matchesSearch && matchesDifficulty && matchesTopic;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Challenges</h1>
          <p className="text-muted-foreground">
            Practice coding problems organized by difficulty and topic
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search challenges..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Difficulty</p>
              <div className="flex flex-wrap gap-2">
                {difficulties.map(diff => (
                  <Button
                    key={diff}
                    variant={selectedDifficulty === diff ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedDifficulty(selectedDifficulty === diff ? null : diff)}
                    className="capitalize"
                  >
                    {diff}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-2">Topic</p>
              <div className="flex flex-wrap gap-2">
                {topics.map(topic => (
                  <Button
                    key={topic}
                    variant={selectedTopic === topic ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedTopic(selectedTopic === topic ? null : topic)}
                    className="capitalize"
                  >
                    {topic.replace('-', ' ')}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-4">
          <Badge variant="secondary">
            {filteredChallenges.length} challenge{filteredChallenges.length !== 1 ? 's' : ''}
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredChallenges.map(challenge => (
            <ChallengeCard key={challenge.id} challenge={challenge} />
          ))}
        </div>

        {filteredChallenges.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No challenges found matching your criteria</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Challenges;
