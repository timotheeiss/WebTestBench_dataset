import { Challenge } from '@/types';

export const challenges: Challenge[] = [
  {
    id: '1',
    title: 'Two Sum',
    description: `Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.`,
    difficulty: 'easy',
    topic: 'arrays',
    points: 10,
    starterCode: `function twoSum(nums, target) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '[2,7,11,15], 9', expected: '[0,1]' },
      { input: '[3,2,4], 6', expected: '[1,2]' },
      { input: '[3,3], 6', expected: '[0,1]' },
    ],
  },
  {
    id: '2',
    title: 'Reverse String',
    description: `Write a function that reverses a string. The input string is given as an array of characters.

You must do this by modifying the input array in-place with O(1) extra memory.`,
    difficulty: 'easy',
    topic: 'strings',
    points: 10,
    starterCode: `function reverseString(s) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '["h","e","l","l","o"]', expected: '["o","l","l","e","h"]' },
      { input: '["H","a","n","n","a","h"]', expected: '["h","a","n","n","a","H"]' },
    ],
  },
  {
    id: '3',
    title: 'Valid Palindrome',
    description: `A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward.

Given a string s, return true if it is a palindrome, or false otherwise.`,
    difficulty: 'easy',
    topic: 'strings',
    points: 10,
    starterCode: `function isPalindrome(s) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '"A man, a plan, a canal: Panama"', expected: 'true' },
      { input: '"race a car"', expected: 'false' },
      { input: '" "', expected: 'true' },
    ],
  },
  {
    id: '4',
    title: 'Maximum Subarray',
    description: `Given an integer array nums, find the subarray with the largest sum, and return its sum.

A subarray is a contiguous part of an array.`,
    difficulty: 'medium',
    topic: 'algorithms',
    points: 20,
    starterCode: `function maxSubArray(nums) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '[-2,1,-3,4,-1,2,1,-5,4]', expected: '6' },
      { input: '[1]', expected: '1' },
      { input: '[5,4,-1,7,8]', expected: '23' },
    ],
  },
  {
    id: '5',
    title: 'Binary Search',
    description: `Given an array of integers nums which is sorted in ascending order, and an integer target, write a function to search target in nums.

If target exists, then return its index. Otherwise, return -1.`,
    difficulty: 'medium',
    topic: 'algorithms',
    points: 20,
    starterCode: `function search(nums, target) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '[-1,0,3,5,9,12], 9', expected: '4' },
      { input: '[-1,0,3,5,9,12], 2', expected: '-1' },
    ],
  },
  {
    id: '6',
    title: 'Valid Parentheses',
    description: `Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

An input string is valid if:
1. Open brackets must be closed by the same type of brackets.
2. Open brackets must be closed in the correct order.`,
    difficulty: 'medium',
    topic: 'data-structures',
    points: 20,
    starterCode: `function isValid(s) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '"()"', expected: 'true' },
      { input: '"()[]{}"', expected: 'true' },
      { input: '"(]"', expected: 'false' },
      { input: '"([)]"', expected: 'false' },
    ],
  },
  {
    id: '7',
    title: 'Climbing Stairs',
    description: `You are climbing a staircase. It takes n steps to reach the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?`,
    difficulty: 'easy',
    topic: 'dynamic-programming',
    points: 10,
    starterCode: `function climbStairs(n) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '2', expected: '2' },
      { input: '3', expected: '3' },
      { input: '5', expected: '8' },
    ],
  },
  {
    id: '8',
    title: 'Fibonacci Number',
    description: `The Fibonacci numbers, commonly denoted F(n) form a sequence, such that each number is the sum of the two preceding ones, starting from 0 and 1.

Given n, calculate F(n).`,
    difficulty: 'easy',
    topic: 'recursion',
    points: 10,
    starterCode: `function fib(n) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '2', expected: '1' },
      { input: '3', expected: '2' },
      { input: '4', expected: '3' },
      { input: '5', expected: '5' },
    ],
  },
  {
    id: '9',
    title: 'Merge Sorted Array',
    description: `You are given two integer arrays nums1 and nums2, sorted in non-decreasing order, and two integers m and n, representing the number of elements in nums1 and nums2 respectively.

Merge nums1 and nums2 into a single array sorted in non-decreasing order.`,
    difficulty: 'medium',
    topic: 'arrays',
    points: 20,
    starterCode: `function merge(nums1, m, nums2, n) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '[1,2,3,0,0,0], 3, [2,5,6], 3', expected: '[1,2,2,3,5,6]' },
      { input: '[1], 1, [], 0', expected: '[1]' },
    ],
  },
  {
    id: '10',
    title: 'Longest Common Subsequence',
    description: `Given two strings text1 and text2, return the length of their longest common subsequence. If there is no common subsequence, return 0.

A subsequence is a sequence that can be derived from another sequence by deleting some or no elements without changing the order of the remaining elements.`,
    difficulty: 'hard',
    topic: 'dynamic-programming',
    points: 30,
    starterCode: `function longestCommonSubsequence(text1, text2) {
  // Write your solution here
  
}`,
    testCases: [
      { input: '"abcde", "ace"', expected: '3' },
      { input: '"abc", "abc"', expected: '3' },
      { input: '"abc", "def"', expected: '0' },
    ],
  },
];
