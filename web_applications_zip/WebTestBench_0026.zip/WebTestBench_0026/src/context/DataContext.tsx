import React, { createContext, useContext, useState, ReactNode } from "react";
import { Project, Employee, StaffingStatus } from "@/types";
import { initialProjects, initialEmployees, skills } from "@/data/mockData";

interface DataContextType {
  projects: Project[];
  employees: Employee[];
  skills: typeof skills;
  addProject: (project: Omit<Project, "id">) => void;
  updateProject: (project: Project) => void;
  deleteProject: (id: string) => void;
  assignEmployee: (projectId: string, roleId: string, employeeId: string | null) => void;
  getProjectStaffingStatus: (project: Project) => StaffingStatus;
  getEmployeeById: (id: string) => Employee | undefined;
  getSkillName: (skillId: string) => string;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);

  const addProject = (projectData: Omit<Project, "id">) => {
    const newProject: Project = {
      ...projectData,
      id: `proj-${Date.now()}`,
    };
    setProjects((prev) => [...prev, newProject]);
  };

  const updateProject = (updatedProject: Project) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === updatedProject.id ? updatedProject : p))
    );
  };

  const deleteProject = (id: string) => {
    const project = projects.find((p) => p.id === id);
    if (project) {
      // Remove project from employees' currentProjectIds
      const assignedEmployeeIds = project.roles
        .filter((r) => r.assignedEmployeeId)
        .map((r) => r.assignedEmployeeId!);

      setEmployees((prev) =>
        prev.map((emp) => {
          if (assignedEmployeeIds.includes(emp.id)) {
            const newProjectIds = emp.currentProjectIds.filter((pid) => pid !== id);
            return {
              ...emp,
              currentProjectIds: newProjectIds,
              availability: newProjectIds.length === 0 ? "available" : 
                           newProjectIds.length === 1 ? "partial" : "unavailable",
            };
          }
          return emp;
        })
      );
    }
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  const assignEmployee = (projectId: string, roleId: string, employeeId: string | null) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id !== projectId) return project;

        return {
          ...project,
          roles: project.roles.map((role) => {
            if (role.id !== roleId) return role;

            // If there was a previously assigned employee, update their status
            if (role.assignedEmployeeId) {
              setEmployees((prevEmp) =>
                prevEmp.map((emp) => {
                  if (emp.id === role.assignedEmployeeId) {
                    const newProjectIds = emp.currentProjectIds.filter(
                      (pid) => pid !== projectId
                    );
                    return {
                      ...emp,
                      currentProjectIds: newProjectIds,
                      availability:
                        newProjectIds.length === 0
                          ? "available"
                          : newProjectIds.length === 1
                          ? "partial"
                          : "unavailable",
                    };
                  }
                  return emp;
                })
              );
            }

            // Assign new employee
            if (employeeId) {
              setEmployees((prevEmp) =>
                prevEmp.map((emp) => {
                  if (emp.id === employeeId) {
                    const newProjectIds = [...new Set([...emp.currentProjectIds, projectId])];
                    return {
                      ...emp,
                      currentProjectIds: newProjectIds,
                      availability:
                        newProjectIds.length === 0
                          ? "available"
                          : newProjectIds.length === 1
                          ? "partial"
                          : "unavailable",
                    };
                  }
                  return emp;
                })
              );
            }

            return { ...role, assignedEmployeeId: employeeId };
          }),
        };
      })
    );
  };

  const getProjectStaffingStatus = (project: Project): StaffingStatus => {
    const assignedCount = project.roles.filter((r) => r.assignedEmployeeId).length;
    const totalRoles = project.roles.length;

    if (assignedCount === 0) return "unstaffed";
    if (assignedCount === totalRoles) return "fully-staffed";
    return "partially-staffed";
  };

  const getEmployeeById = (id: string) => employees.find((e) => e.id === id);

  const getSkillName = (skillId: string) => {
    const skill = skills.find((s) => s.id === skillId);
    return skill?.name || skillId;
  };

  return (
    <DataContext.Provider
      value={{
        projects,
        employees,
        skills,
        addProject,
        updateProject,
        deleteProject,
        assignEmployee,
        getProjectStaffingStatus,
        getEmployeeById,
        getSkillName,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
