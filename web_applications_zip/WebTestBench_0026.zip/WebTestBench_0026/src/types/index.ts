export type Priority = "high" | "medium" | "low";
export type Availability = "available" | "partial" | "unavailable";
export type StaffingStatus = "fully-staffed" | "partially-staffed" | "unstaffed";

export interface Skill {
  id: string;
  name: string;
}

export interface ProjectRole {
  id: string;
  title: string;
  requiredSkills: string[];
  assignedEmployeeId: string | null;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  priority: Priority;
  startDate: string;
  expectedDuration: number; // in weeks
  roles: ProjectRole[];
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  avatar: string;
  title: string;
  skills: string[];
  availability: Availability;
  currentProjectIds: string[];
}
