import { useState, useMemo } from "react";
import { useData } from "@/context/DataContext";
import { Layout } from "@/components/layout/Layout";
import { StatusBadge } from "@/components/ui/status-badge";
import { SkillBadge } from "@/components/ui/skill-badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, Mail, FolderKanban } from "lucide-react";
import { Availability } from "@/types";

export default function Employees() {
  const { employees, projects, skills } = useData();
  const [search, setSearch] = useState("");
  const [availabilityFilter, setAvailabilityFilter] = useState<Availability | "all">(
    "all"
  );
  const [skillFilter, setSkillFilter] = useState<string>("all");

  const filteredEmployees = useMemo(() => {
    return employees.filter((employee) => {
      const matchesSearch =
        employee.name.toLowerCase().includes(search.toLowerCase()) ||
        employee.email.toLowerCase().includes(search.toLowerCase()) ||
        employee.title.toLowerCase().includes(search.toLowerCase());

      const matchesAvailability =
        availabilityFilter === "all" || employee.availability === availabilityFilter;

      const matchesSkill =
        skillFilter === "all" || employee.skills.includes(skillFilter);

      return matchesSearch && matchesAvailability && matchesSkill;
    });
  }, [employees, search, availabilityFilter, skillFilter]);

  const getEmployeeProjects = (projectIds: string[]) => {
    return projectIds
      .map((id) => projects.find((p) => p.id === id))
      .filter(Boolean);
  };

  return (
    <Layout>
      <div className="animate-fade-in">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Employees</h1>
          <p className="mt-1 text-muted-foreground">
            View and manage team members and their assignments
          </p>
        </div>

        <div className="mb-6 flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or title..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select
            value={availabilityFilter}
            onValueChange={(value) =>
              setAvailabilityFilter(value as Availability | "all")
            }
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Availability" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Availability</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="partial">Partially Available</SelectItem>
              <SelectItem value="unavailable">Unavailable</SelectItem>
            </SelectContent>
          </Select>
          <Select value={skillFilter} onValueChange={setSkillFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Skill" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Skills</SelectItem>
              {skills.map((skill) => (
                <SelectItem key={skill.id} value={skill.id}>
                  {skill.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredEmployees.map((employee) => {
            const employeeProjects = getEmployeeProjects(employee.currentProjectIds);

            return (
              <div
                key={employee.id}
                className="rounded-xl border border-border bg-card p-5 transition-shadow hover:shadow-md"
              >
                <div className="mb-4 flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={employee.avatar} alt={employee.name} />
                      <AvatarFallback>
                        {employee.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-card-foreground">
                        {employee.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">{employee.title}</p>
                    </div>
                  </div>
                  <StatusBadge status={employee.availability} />
                </div>

                <div className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span className="truncate">{employee.email}</span>
                </div>

                <div className="mb-4">
                  <p className="mb-2 text-xs font-medium uppercase text-muted-foreground">
                    Skills
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {employee.skills.map((skillId) => (
                      <SkillBadge key={skillId} skillId={skillId} />
                    ))}
                  </div>
                </div>

                {employeeProjects.length > 0 && (
                  <div>
                    <p className="mb-2 text-xs font-medium uppercase text-muted-foreground">
                      Current Projects
                    </p>
                    <div className="space-y-1.5">
                      {employeeProjects.map((project) => (
                        <div
                          key={project!.id}
                          className="flex items-center gap-2 rounded-md bg-muted/50 px-2.5 py-1.5 text-sm"
                        >
                          <FolderKanban className="h-3.5 w-3.5 text-muted-foreground" />
                          <span className="truncate">{project!.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {employeeProjects.length === 0 && (
                  <div className="rounded-md bg-muted/50 px-3 py-2 text-center text-sm text-muted-foreground">
                    Not assigned to any projects
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredEmployees.length === 0 && (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
            <p className="text-lg font-medium text-foreground">No employees found</p>
            <p className="text-muted-foreground">
              Try adjusting your search or filters
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
