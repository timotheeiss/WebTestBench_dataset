import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useData } from "@/context/DataContext";
import { Layout } from "@/components/layout/Layout";
import { ProjectForm } from "@/components/projects/ProjectForm";
import { AssignmentDialog } from "@/components/projects/AssignmentDialog";
import { StatusBadge } from "@/components/ui/status-badge";
import { SkillBadge } from "@/components/ui/skill-badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  ArrowLeft,
  Calendar,
  Users,
  Edit,
  Trash2,
  UserPlus,
  UserMinus,
} from "lucide-react";
import { ProjectRole } from "@/types";
import { toast } from "sonner";

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { projects, getProjectStaffingStatus, getEmployeeById, deleteProject, assignEmployee } =
    useData();

  const project = projects.find((p) => p.id === id);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<ProjectRole | null>(null);

  if (!project) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center py-16">
          <p className="text-lg text-muted-foreground">Project not found</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/projects")}>
            Back to Projects
          </Button>
        </div>
      </Layout>
    );
  }

  const staffingStatus = getProjectStaffingStatus(project);
  const assignedCount = project.roles.filter((r) => r.assignedEmployeeId).length;

  const handleDelete = () => {
    deleteProject(project.id);
    toast.success("Project deleted");
    navigate("/projects");
  };

  const handleUnassign = (roleId: string) => {
    assignEmployee(project.id, roleId, null);
    toast.success("Employee unassigned");
  };

  return (
    <Layout>
      <div className="animate-fade-in">
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate("/projects")}
        >
          <ArrowLeft className="mr-1.5 h-4 w-4" />
          Back to Projects
        </Button>

        <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-3">
              <h1 className="text-3xl font-bold text-foreground">{project.name}</h1>
              <StatusBadge status={project.priority} />
            </div>
            <p className="max-w-2xl text-muted-foreground">{project.description}</p>
            <div className="mt-4 flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                <span>Started {new Date(project.startDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                <span>{project.expectedDuration} weeks duration</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="h-4 w-4" />
                <span>
                  {assignedCount}/{project.roles.length} roles filled
                </span>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsEditOpen(true)}>
              <Edit className="mr-1.5 h-4 w-4" />
              Edit
            </Button>
            <Button variant="outline" onClick={() => setIsDeleteOpen(true)}>
              <Trash2 className="mr-1.5 h-4 w-4" />
              Delete
            </Button>
          </div>
        </div>

        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Project Roles</h2>
            <p className="text-sm text-muted-foreground">
              Assign team members to project roles
            </p>
          </div>
          <StatusBadge status={staffingStatus} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {project.roles.map((role) => {
            const assignedEmployee = role.assignedEmployeeId
              ? getEmployeeById(role.assignedEmployeeId)
              : null;

            return (
              <div
                key={role.id}
                className="rounded-xl border border-border bg-card p-5"
              >
                <div className="mb-4">
                  <h3 className="font-semibold text-card-foreground">{role.title}</h3>
                  {role.requiredSkills.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {role.requiredSkills.map((skillId) => (
                        <SkillBadge key={skillId} skillId={skillId} />
                      ))}
                    </div>
                  )}
                </div>

                {assignedEmployee ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage
                          src={assignedEmployee.avatar}
                          alt={assignedEmployee.name}
                        />
                        <AvatarFallback>
                          {assignedEmployee.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-card-foreground">
                          {assignedEmployee.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {assignedEmployee.title}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setSelectedRole(role)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleUnassign(role.id)}
                      >
                        <UserMinus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setSelectedRole(role)}
                  >
                    <UserPlus className="mr-1.5 h-4 w-4" />
                    Assign Employee
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        <ProjectForm
          project={project}
          open={isEditOpen}
          onOpenChange={setIsEditOpen}
        />

        {selectedRole && (
          <AssignmentDialog
            projectId={project.id}
            role={selectedRole}
            open={!!selectedRole}
            onOpenChange={(open) => !open && setSelectedRole(null)}
          />
        )}

        <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Project</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{project.name}"? This action cannot
                be undone and will unassign all employees from this project.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </Layout>
  );
}
