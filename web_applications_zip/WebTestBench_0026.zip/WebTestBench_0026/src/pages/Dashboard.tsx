import { useData } from "@/context/DataContext";
import { Layout } from "@/components/layout/Layout";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { ProjectOverviewCard } from "@/components/dashboard/ProjectOverviewCard";
import { FolderKanban, Users, CheckCircle, AlertTriangle, AlertCircle } from "lucide-react";

export default function Dashboard() {
  const { projects, employees, getProjectStaffingStatus } = useData();

  const fullyStaffed = projects.filter(
    (p) => getProjectStaffingStatus(p) === "fully-staffed"
  ).length;
  const partiallyStaffed = projects.filter(
    (p) => getProjectStaffingStatus(p) === "partially-staffed"
  ).length;
  const unstaffed = projects.filter(
    (p) => getProjectStaffingStatus(p) === "unstaffed"
  ).length;

  const availableEmployees = employees.filter(
    (e) => e.availability === "available"
  ).length;

  return (
    <Layout>
      <div className="animate-fade-in">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="mt-1 text-muted-foreground">
            Overview of projects and staff assignments
          </p>
        </div>

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Projects"
            value={projects.length}
            icon={<FolderKanban className="h-6 w-6 text-primary" />}
            iconClassName="bg-primary/10"
          />
          <StatsCard
            title="Fully Staffed"
            value={fullyStaffed}
            icon={<CheckCircle className="h-6 w-6 text-status-success" />}
            iconClassName="bg-status-success/10"
            description={`${Math.round((fullyStaffed / projects.length) * 100) || 0}% of projects`}
          />
          <StatsCard
            title="Need Attention"
            value={partiallyStaffed + unstaffed}
            icon={<AlertTriangle className="h-6 w-6 text-status-warning" />}
            iconClassName="bg-status-warning/10"
            description={`${partiallyStaffed} partial, ${unstaffed} unstaffed`}
          />
          <StatsCard
            title="Available Staff"
            value={availableEmployees}
            icon={<Users className="h-6 w-6 text-primary" />}
            iconClassName="bg-primary/10"
            description={`of ${employees.length} total employees`}
          />
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-semibold text-foreground">Projects Overview</h2>
          <p className="text-sm text-muted-foreground">
            Manage assignments and track staffing status
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <ProjectOverviewCard key={project.id} project={project} />
          ))}
        </div>

        {projects.length === 0 && (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
            <AlertCircle className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium text-foreground">No projects yet</p>
            <p className="text-muted-foreground">Create your first project to get started</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
