import { cn } from "@/lib/utils";
import { StaffingStatus, Priority, Availability } from "@/types";

interface StatusBadgeProps {
  status: StaffingStatus | Priority | Availability;
  className?: string;
}

const statusConfig: Record<string, { label: string; className: string }> = {
  // Staffing status
  "fully-staffed": {
    label: "Fully Staffed",
    className: "bg-status-success/10 text-status-success border-status-success/20",
  },
  "partially-staffed": {
    label: "Partial",
    className: "bg-status-warning/10 text-status-warning border-status-warning/20",
  },
  unstaffed: {
    label: "Unstaffed",
    className: "bg-status-danger/10 text-status-danger border-status-danger/20",
  },
  // Priority
  high: {
    label: "High",
    className: "bg-priority-high/10 text-priority-high border-priority-high/20",
  },
  medium: {
    label: "Medium",
    className: "bg-priority-medium/10 text-priority-medium border-priority-medium/20",
  },
  low: {
    label: "Low",
    className: "bg-priority-low/10 text-priority-low border-priority-low/20",
  },
  // Availability
  available: {
    label: "Available",
    className: "bg-status-success/10 text-status-success border-status-success/20",
  },
  partial: {
    label: "Partially Available",
    className: "bg-status-warning/10 text-status-warning border-status-warning/20",
  },
  unavailable: {
    label: "Unavailable",
    className: "bg-status-danger/10 text-status-danger border-status-danger/20",
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
}
