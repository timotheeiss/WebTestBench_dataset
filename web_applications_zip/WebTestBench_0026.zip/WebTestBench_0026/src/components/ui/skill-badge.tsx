import { cn } from "@/lib/utils";
import { useData } from "@/context/DataContext";

interface SkillBadgeProps {
  skillId: string;
  className?: string;
}

export function SkillBadge({ skillId, className }: SkillBadgeProps) {
  const { getSkillName } = useData();

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md bg-primary/10 px-2 py-1 text-xs font-medium text-primary",
        className
      )}
    >
      {getSkillName(skillId)}
    </span>
  );
}
