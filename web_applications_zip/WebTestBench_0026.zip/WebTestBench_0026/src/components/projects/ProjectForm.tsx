import { useState } from "react";
import { Project, ProjectRole, Priority } from "@/types";
import { useData } from "@/context/DataContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface ProjectFormProps {
  project?: Project;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProjectForm({ project, open, onOpenChange }: ProjectFormProps) {
  const { skills, addProject, updateProject } = useData();
  const isEditing = !!project;

  const [formData, setFormData] = useState({
    name: project?.name || "",
    description: project?.description || "",
    priority: project?.priority || "medium" as Priority,
    startDate: project?.startDate || new Date().toISOString().split("T")[0],
    expectedDuration: project?.expectedDuration || 4,
    roles: project?.roles || [] as ProjectRole[],
  });

  const [newRole, setNewRole] = useState({
    title: "",
    requiredSkills: [] as string[],
  });

  const handleAddRole = () => {
    if (!newRole.title) {
      toast.error("Please enter a role title");
      return;
    }

    const role: ProjectRole = {
      id: `role-${Date.now()}`,
      title: newRole.title,
      requiredSkills: newRole.requiredSkills,
      assignedEmployeeId: null,
    };

    setFormData((prev) => ({
      ...prev,
      roles: [...prev.roles, role],
    }));

    setNewRole({ title: "", requiredSkills: [] });
  };

  const handleRemoveRole = (roleId: string) => {
    setFormData((prev) => ({
      ...prev,
      roles: prev.roles.filter((r) => r.id !== roleId),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.description) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (formData.roles.length === 0) {
      toast.error("Please add at least one role");
      return;
    }

    if (isEditing && project) {
      updateProject({ ...project, ...formData });
      toast.success("Project updated successfully");
    } else {
      addProject(formData);
      toast.success("Project created successfully");
    }

    onOpenChange(false);
  };

  const toggleSkill = (skillId: string) => {
    setNewRole((prev) => ({
      ...prev,
      requiredSkills: prev.requiredSkills.includes(skillId)
        ? prev.requiredSkills.filter((s) => s !== skillId)
        : [...prev.requiredSkills, skillId],
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Project" : "Create New Project"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label htmlFor="name">Project Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="Enter project name"
                className="mt-1.5"
              />
            </div>

            <div className="sm:col-span-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, description: e.target.value }))
                }
                placeholder="Describe the project"
                className="mt-1.5"
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="priority">Priority</Label>
              <Select
                value={formData.priority}
                onValueChange={(value: Priority) =>
                  setFormData((prev) => ({ ...prev, priority: value }))
                }
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="duration">Expected Duration (weeks)</Label>
              <Input
                id="duration"
                type="number"
                min={1}
                value={formData.expectedDuration}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    expectedDuration: parseInt(e.target.value) || 1,
                  }))
                }
                className="mt-1.5"
              />
            </div>

            <div>
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={formData.startDate}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, startDate: e.target.value }))
                }
                className="mt-1.5"
              />
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="mb-4 font-semibold">Project Roles</h3>

            {formData.roles.length > 0 && (
              <div className="mb-4 space-y-2">
                {formData.roles.map((role) => (
                  <div
                    key={role.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-muted/30 p-3"
                  >
                    <div>
                      <p className="font-medium">{role.title}</p>
                      <p className="text-sm text-muted-foreground">
                        Skills: {role.requiredSkills.length > 0
                          ? role.requiredSkills
                              .map((s) => skills.find((sk) => sk.id === s)?.name)
                              .join(", ")
                          : "None specified"}
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveRole(role.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="rounded-lg border border-dashed border-border p-4">
              <div className="mb-3">
                <Label htmlFor="roleTitle">Role Title</Label>
                <Input
                  id="roleTitle"
                  value={newRole.title}
                  onChange={(e) =>
                    setNewRole((prev) => ({ ...prev, title: e.target.value }))
                  }
                  placeholder="e.g., Frontend Developer"
                  className="mt-1.5"
                />
              </div>

              <div className="mb-3">
                <Label>Required Skills</Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <button
                      key={skill.id}
                      type="button"
                      onClick={() => toggleSkill(skill.id)}
                      className={`rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ${
                        newRole.requiredSkills.includes(skill.id)
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-background text-foreground hover:border-primary/50"
                      }`}
                    >
                      {skill.name}
                    </button>
                  ))}
                </div>
              </div>

              <Button type="button" variant="outline" onClick={handleAddRole}>
                <Plus className="mr-1.5 h-4 w-4" />
                Add Role
              </Button>
            </div>
          </div>

          <div className="flex justify-end gap-3 border-t border-border pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              {isEditing ? "Update Project" : "Create Project"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
