import { useState, useMemo } from "react";
import { ProjectRole } from "@/types";
import { useData } from "@/context/DataContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatusBadge } from "@/components/ui/status-badge";
import { SkillBadge } from "@/components/ui/skill-badge";
import { Search, Check, X } from "lucide-react";
import { toast } from "sonner";

interface AssignmentDialogProps {
  projectId: string;
  role: ProjectRole;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AssignmentDialog({
  projectId,
  role,
  open,
  onOpenChange,
}: AssignmentDialogProps) {
  const { employees, assignEmployee, getSkillName } = useData();
  const [search, setSearch] = useState("");

  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      const matchesSearch =
        emp.name.toLowerCase().includes(search.toLowerCase()) ||
        emp.title.toLowerCase().includes(search.toLowerCase());

      return matchesSearch;
    });
  }, [employees, search]);

  const sortedEmployees = useMemo(() => {
    return [...filteredEmployees].sort((a, b) => {
      // Sort by skill match first
      const aMatchCount = role.requiredSkills.filter((s) =>
        a.skills.includes(s)
      ).length;
      const bMatchCount = role.requiredSkills.filter((s) =>
        b.skills.includes(s)
      ).length;

      if (bMatchCount !== aMatchCount) return bMatchCount - aMatchCount;

      // Then by availability
      const availabilityOrder = { available: 0, partial: 1, unavailable: 2 };
      return availabilityOrder[a.availability] - availabilityOrder[b.availability];
    });
  }, [filteredEmployees, role.requiredSkills]);

  const handleAssign = (employeeId: string) => {
    assignEmployee(projectId, role.id, employeeId);
    toast.success("Employee assigned successfully");
    onOpenChange(false);
  };

  const handleUnassign = () => {
    assignEmployee(projectId, role.id, null);
    toast.success("Employee unassigned");
    onOpenChange(false);
  };

  const getSkillMatchCount = (employeeSkills: string[]) => {
    return role.requiredSkills.filter((s) => employeeSkills.includes(s)).length;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[80vh] max-w-lg">
        <DialogHeader>
          <DialogTitle>Assign Employee to {role.title}</DialogTitle>
        </DialogHeader>

        {role.requiredSkills.length > 0 && (
          <div className="mb-4">
            <p className="mb-2 text-sm text-muted-foreground">Required Skills:</p>
            <div className="flex flex-wrap gap-1.5">
              {role.requiredSkills.map((skillId) => (
                <SkillBadge key={skillId} skillId={skillId} />
              ))}
            </div>
          </div>
        )}

        {role.assignedEmployeeId && (
          <div className="mb-4 flex items-center justify-between rounded-lg border border-border bg-muted/30 p-3">
            <span className="text-sm text-muted-foreground">
              Currently assigned employee
            </span>
            <Button variant="outline" size="sm" onClick={handleUnassign}>
              <X className="mr-1.5 h-4 w-4" />
              Unassign
            </Button>
          </div>
        )}

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search employees..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="max-h-[400px] space-y-2 overflow-y-auto scrollbar-thin">
          {sortedEmployees.map((employee) => {
            const matchCount = getSkillMatchCount(employee.skills);
            const isCurrentlyAssigned = role.assignedEmployeeId === employee.id;

            return (
              <div
                key={employee.id}
                className={`flex items-center justify-between rounded-lg border p-3 transition-colors ${
                  isCurrentlyAssigned
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/30"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={employee.avatar} alt={employee.name} />
                    <AvatarFallback>
                      {employee.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{employee.name}</p>
                      {isCurrentlyAssigned && (
                        <Check className="h-4 w-4 text-primary" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{employee.title}</p>
                    {role.requiredSkills.length > 0 && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        {matchCount}/{role.requiredSkills.length} skills matched
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={employee.availability} />
                  {!isCurrentlyAssigned && (
                    <Button size="sm" onClick={() => handleAssign(employee.id)}>
                      Assign
                    </Button>
                  )}
                </div>
              </div>
            );
          })}

          {sortedEmployees.length === 0 && (
            <div className="py-8 text-center text-muted-foreground">
              No employees found
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
