import { useNavigate } from "react-router-dom";
import { Project } from "@/types";
import { useData } from "@/context/DataContext";
import { StatusBadge } from "@/components/ui/status-badge";
import { Users, Calendar, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProjectOverviewCardProps {
  project: Project;
}

export function ProjectOverviewCard({ project }: ProjectOverviewCardProps) {
  const navigate = useNavigate();
  const { getProjectStaffingStatus, getEmployeeById } = useData();
  
  const staffingStatus = getProjectStaffingStatus(project);
  const assignedCount = project.roles.filter((r) => r.assignedEmployeeId).length;

  return (
    <div className="group rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-md">
      <div className="mb-3 flex items-start justify-between">
        <div className="flex-1">
          <h3 className="font-semibold text-card-foreground">{project.name}</h3>
          <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
            {project.description}
          </p>
        </div>
        <StatusBadge status={project.priority} />
      </div>

      <div className="mb-4 flex items-center gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Users className="h-4 w-4" />
          <span>
            {assignedCount}/{project.roles.length} roles filled
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Calendar className="h-4 w-4" />
          <span>{project.expectedDuration} weeks</span>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <StatusBadge status={staffingStatus} />
        <Button
          variant="ghost"
          size="sm"
          className="opacity-0 transition-opacity group-hover:opacity-100"
          onClick={() => navigate(`/projects/${project.id}`)}
        >
          View Details
          <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
