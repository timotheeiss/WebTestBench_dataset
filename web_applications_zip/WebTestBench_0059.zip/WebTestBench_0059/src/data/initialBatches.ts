import { SampleBatch } from '@/types/batch';

// Helper to create dates relative to today
const daysFromNow = (days: number): string => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
};

export const initialBatches: SampleBatch[] = [
  {
    id: '1',
    name: 'Blood Sample Alpha-001',
    cabinetNumber: 'A1',
    shelfNumber: '3',
    expirationDate: daysFromNow(-2), // Expired
    createdAt: '2025-01-01T10:00:00Z',
  },
  {
    id: '2',
    name: 'Tissue Sample Beta-042',
    cabinetNumber: 'A2',
    shelfNumber: '1',
    expirationDate: daysFromNow(2), // Critical - 2 days
    createdAt: '2025-01-03T14:30:00Z',
  },
  {
    id: '3',
    name: 'Serum Sample Gamma-108',
    cabinetNumber: 'B1',
    shelfNumber: '2',
    expirationDate: daysFromNow(5), // Warning - 5 days
    createdAt: '2025-01-05T09:15:00Z',
  },
  {
    id: '4',
    name: 'DNA Extract Delta-023',
    cabinetNumber: 'B2',
    shelfNumber: '4',
    expirationDate: daysFromNow(30), // Safe
    createdAt: '2025-01-08T11:45:00Z',
  },
  {
    id: '5',
    name: 'Protein Sample Epsilon-067',
    cabinetNumber: 'C1',
    shelfNumber: '1',
    expirationDate: daysFromNow(14), // Safe
    createdAt: '2025-01-10T16:20:00Z',
  },
  {
    id: '6',
    name: 'RNA Sample Zeta-012',
    cabinetNumber: 'C2',
    shelfNumber: '3',
    expirationDate: daysFromNow(3), // Warning - 3 days
    createdAt: '2025-01-11T08:00:00Z',
  },
];
