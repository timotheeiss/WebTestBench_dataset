import { SampleBatch, ExpirationStatus } from '@/types/batch';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Pencil, Trash2, FlaskConical } from 'lucide-react';
import { format } from 'date-fns';

interface BatchTableProps {
  batches: SampleBatch[];
  getExpirationStatus: (date: string) => ExpirationStatus;
  getDaysUntilExpiration: (date: string) => number;
  onEdit: (batch: SampleBatch) => void;
  onDelete: (id: string) => void;
}

const statusConfig: Record<ExpirationStatus, { label: string; className: string }> = {
  expired: { label: 'Expired', className: 'bg-destructive text-destructive-foreground' },
  critical: { label: 'Critical', className: 'bg-destructive/90 text-destructive-foreground' },
  warning: { label: 'Warning', className: 'bg-warning text-warning-foreground' },
  safe: { label: 'Safe', className: 'bg-success text-success-foreground' },
};

export const BatchTable = ({
  batches,
  getExpirationStatus,
  getDaysUntilExpiration,
  onEdit,
  onDelete,
}: BatchTableProps) => {
  if (batches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground animate-fade-in">
        <FlaskConical className="h-16 w-16 mb-4 opacity-30" />
        <p className="text-lg font-medium">No sample batches found</p>
        <p className="text-sm">Add your first batch using the Add/Edit tab</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border bg-card shadow-lab overflow-hidden animate-fade-in">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="font-semibold">Sample Name</TableHead>
            <TableHead className="font-semibold">Cabinet</TableHead>
            <TableHead className="font-semibold">Shelf</TableHead>
            <TableHead className="font-semibold">Expiration Date</TableHead>
            <TableHead className="font-semibold">Status</TableHead>
            <TableHead className="font-semibold text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {batches.map((batch) => {
            const status = getExpirationStatus(batch.expirationDate);
            const daysLeft = getDaysUntilExpiration(batch.expirationDate);
            const config = statusConfig[status];

            return (
              <TableRow key={batch.id} className="hover:bg-muted/30 transition-colors">
                <TableCell className="font-medium">{batch.name}</TableCell>
                <TableCell>{batch.cabinetNumber}</TableCell>
                <TableCell>{batch.shelfNumber}</TableCell>
                <TableCell>{format(new Date(batch.expirationDate), 'MMM dd, yyyy')}</TableCell>
                <TableCell>
                  <Badge className={config.className}>
                    {config.label}
                    {status !== 'expired' && status !== 'safe' && (
                      <span className="ml-1">({daysLeft}d)</span>
                    )}
                    {status === 'expired' && (
                      <span className="ml-1">({Math.abs(daysLeft)}d ago)</span>
                    )}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onEdit(batch)}
                      className="h-8 w-8 p-0"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onDelete(batch.id)}
                      className="h-8 w-8 p-0 hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};
