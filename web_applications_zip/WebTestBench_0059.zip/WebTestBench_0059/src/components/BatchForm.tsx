import { useState, useEffect } from 'react';
import { SampleBatch, ValidationError } from '@/types/batch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Save, X, AlertCircle } from 'lucide-react';

interface BatchFormProps {
  editingBatch: SampleBatch | null;
  onAdd: (name: string, cabinet: string, shelf: string, expDate: string) => ValidationError[];
  onUpdate: (id: string, name: string, cabinet: string, shelf: string, expDate: string) => ValidationError[];
  onCancel: () => void;
  onSuccess: (message: string) => void;
}

export const BatchForm = ({ editingBatch, onAdd, onUpdate, onCancel, onSuccess }: BatchFormProps) => {
  const [name, setName] = useState('');
  const [cabinetNumber, setCabinetNumber] = useState('');
  const [shelfNumber, setShelfNumber] = useState('');
  const [expirationDate, setExpirationDate] = useState('');
  const [errors, setErrors] = useState<ValidationError[]>([]);

  const isEditing = editingBatch !== null;

  useEffect(() => {
    if (editingBatch) {
      setName(editingBatch.name);
      setCabinetNumber(editingBatch.cabinetNumber);
      setShelfNumber(editingBatch.shelfNumber);
      setExpirationDate(editingBatch.expirationDate);
      setErrors([]);
    }
  }, [editingBatch]);

  const resetForm = () => {
    setName('');
    setCabinetNumber('');
    setShelfNumber('');
    setExpirationDate('');
    setErrors([]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let validationErrors: ValidationError[];

    if (isEditing && editingBatch) {
      validationErrors = onUpdate(editingBatch.id, name, cabinetNumber, shelfNumber, expirationDate);
      if (validationErrors.length === 0) {
        onSuccess(`Sample "${name}" updated successfully`);
        resetForm();
      }
    } else {
      validationErrors = onAdd(name, cabinetNumber, shelfNumber, expirationDate);
      if (validationErrors.length === 0) {
        onSuccess(`Sample "${name}" added successfully`);
        resetForm();
      }
    }

    setErrors(validationErrors);
  };

  const handleCancel = () => {
    resetForm();
    onCancel();
  };

  const getFieldError = (field: string): string | undefined => {
    return errors.find((e) => e.field === field)?.message;
  };

  return (
    <Card className="shadow-lab animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isEditing ? <Save className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
          {isEditing ? 'Edit Sample Batch' : 'Add New Sample Batch'}
        </CardTitle>
        <CardDescription>
          {isEditing
            ? 'Update the sample batch information below'
            : 'Fill in the details to add a new sample batch to the system'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {errors.length > 0 && (
            <Alert variant="destructive" className="animate-slide-up">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <ul className="list-disc list-inside space-y-1">
                  {errors.map((error, idx) => (
                    <li key={idx}>{error.message}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="name">Sample Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Blood Sample Alpha-001"
              className={getFieldError('name') ? 'border-destructive' : ''}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cabinet">Cabinet Number</Label>
              <Input
                id="cabinet"
                value={cabinetNumber}
                onChange={(e) => setCabinetNumber(e.target.value)}
                placeholder="e.g., A1"
                className={getFieldError('cabinetNumber') || getFieldError('location') ? 'border-destructive' : ''}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shelf">Shelf Number</Label>
              <Input
                id="shelf"
                value={shelfNumber}
                onChange={(e) => setShelfNumber(e.target.value)}
                placeholder="e.g., 3"
                className={getFieldError('shelfNumber') || getFieldError('location') ? 'border-destructive' : ''}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="expiration">Expiration Date</Label>
            <Input
              id="expiration"
              type="date"
              value={expirationDate}
              onChange={(e) => setExpirationDate(e.target.value)}
              className={getFieldError('expirationDate') ? 'border-destructive' : ''}
            />
            <p className="text-xs text-muted-foreground">Format: YYYY-MM-DD</p>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1">
              {isEditing ? (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Update Batch
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Batch
                </>
              )}
            </Button>
            {isEditing && (
              <Button type="button" variant="outline" onClick={handleCancel}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
};
