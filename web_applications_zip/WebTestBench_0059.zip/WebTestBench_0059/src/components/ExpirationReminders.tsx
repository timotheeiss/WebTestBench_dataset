import { SampleBatch, ExpirationStatus } from '@/types/batch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Clock, CheckCircle2, Pencil, MapPin } from 'lucide-react';
import { format } from 'date-fns';

interface ExpirationRemindersProps {
  expiringBatches: SampleBatch[];
  getExpirationStatus: (date: string) => ExpirationStatus;
  getDaysUntilExpiration: (date: string) => number;
  onEdit: (batch: SampleBatch) => void;
}

const statusIcons: Record<ExpirationStatus, React.ReactNode> = {
  expired: <AlertTriangle className="h-5 w-5" />,
  critical: <AlertTriangle className="h-5 w-5" />,
  warning: <Clock className="h-5 w-5" />,
  safe: <CheckCircle2 className="h-5 w-5" />,
};

const statusColors: Record<ExpirationStatus, string> = {
  expired: 'border-l-destructive bg-destructive/5',
  critical: 'border-l-destructive/80 bg-destructive/5',
  warning: 'border-l-warning bg-warning/5',
  safe: 'border-l-success bg-success/5',
};

const statusTextColors: Record<ExpirationStatus, string> = {
  expired: 'text-destructive',
  critical: 'text-destructive',
  warning: 'text-warning-foreground',
  safe: 'text-success',
};

export const ExpirationReminders = ({
  expiringBatches,
  getExpirationStatus,
  getDaysUntilExpiration,
  onEdit,
}: ExpirationRemindersProps) => {
  if (expiringBatches.length === 0) {
    return (
      <Card className="shadow-lab animate-fade-in">
        <CardContent className="flex flex-col items-center justify-center py-16">
          <CheckCircle2 className="h-16 w-16 text-success mb-4" />
          <p className="text-lg font-medium text-foreground">All samples are safe!</p>
          <p className="text-sm text-muted-foreground">No samples are expiring within the next 7 days</p>
        </CardContent>
      </Card>
    );
  }

  const expiredCount = expiringBatches.filter((b) => getExpirationStatus(b.expirationDate) === 'expired').length;
  const criticalCount = expiringBatches.filter((b) => getExpirationStatus(b.expirationDate) === 'critical').length;
  const warningCount = expiringBatches.filter((b) => getExpirationStatus(b.expirationDate) === 'warning').length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-destructive">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Expired</p>
                <p className="text-3xl font-bold text-destructive">{expiredCount}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-destructive opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-warning">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Critical (≤3 days)</p>
                <p className="text-3xl font-bold text-warning">{criticalCount}</p>
              </div>
              <Clock className="h-8 w-8 text-warning opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-primary">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Warning (≤7 days)</p>
                <p className="text-3xl font-bold text-primary">{warningCount}</p>
              </div>
              <Clock className="h-8 w-8 text-primary opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed List */}
      <Card className="shadow-lab">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Expiration Alerts
          </CardTitle>
          <CardDescription>
            Samples requiring attention, sorted by urgency
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {expiringBatches.map((batch) => {
            const status = getExpirationStatus(batch.expirationDate);
            const daysLeft = getDaysUntilExpiration(batch.expirationDate);

            return (
              <div
                key={batch.id}
                className={`border-l-4 rounded-lg p-4 ${statusColors[status]} transition-all hover:shadow-md animate-slide-up`}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={statusTextColors[status]}>{statusIcons[status]}</span>
                      <h4 className="font-semibold">{batch.name}</h4>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Cabinet {batch.cabinetNumber}, Shelf {batch.shelfNumber}
                      </span>
                      <span>
                        Expires: {format(new Date(batch.expirationDate), 'MMM dd, yyyy')}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge
                      className={
                        status === 'expired'
                          ? 'bg-destructive text-destructive-foreground'
                          : status === 'critical'
                          ? 'bg-destructive/90 text-destructive-foreground'
                          : 'bg-warning text-warning-foreground'
                      }
                    >
                      {status === 'expired'
                        ? `Expired ${Math.abs(daysLeft)} days ago`
                        : `${daysLeft} day${daysLeft !== 1 ? 's' : ''} left`}
                    </Badge>
                    <Button variant="outline" size="sm" onClick={() => onEdit(batch)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
};
