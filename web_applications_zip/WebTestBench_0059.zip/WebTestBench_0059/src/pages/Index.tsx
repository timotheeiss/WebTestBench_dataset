import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BatchTable } from '@/components/BatchTable';
import { BatchForm } from '@/components/BatchForm';
import { ExpirationReminders } from '@/components/ExpirationReminders';
import { useBatchManager } from '@/hooks/useBatchManager';
import { useToast } from '@/hooks/use-toast';
import { FlaskConical, Table, PlusCircle, Bell } from 'lucide-react';

const TAB_STORAGE_KEY = 'lab-batches-active-tab';

const Index = () => {
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState(() => {
    try {
      return localStorage.getItem(TAB_STORAGE_KEY) || 'table';
    } catch {
      return 'table';
    }
  });

  const {
    batches,
    editingBatch,
    addBatch,
    updateBatch,
    deleteBatch,
    startEditing,
    cancelEditing,
    getExpirationStatus,
    getDaysUntilExpiration,
    expiringBatches,
  } = useBatchManager();

  // Persist active tab to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(TAB_STORAGE_KEY, activeTab);
    } catch (error) {
      console.error('Failed to save active tab:', error);
    }
  }, [activeTab]);

  const handleEdit = (batch: typeof batches[0]) => {
    startEditing(batch);
    setActiveTab('form');
  };

  const handleDelete = (id: string) => {
    const batch = batches.find((b) => b.id === id);
    deleteBatch(id);
    toast({
      title: 'Batch Deleted',
      description: `"${batch?.name}" has been removed from the system.`,
    });
  };

  const handleSuccess = (message: string) => {
    toast({
      title: 'Success',
      description: message,
    });
  };

  const handleTabChange = (value: string) => {
    if (value !== 'form' && editingBatch) {
      cancelEditing();
    }
    setActiveTab(value);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="gradient-lab">
        <div className="container py-8">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-primary-foreground/20 flex items-center justify-center">
              <FlaskConical className="h-7 w-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-primary-foreground">
                Laboratory Sample Manager
              </h1>
              <p className="text-primary-foreground/80 text-sm">
                Track and manage your sample batches with expiration monitoring
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3 mx-auto">
            <TabsTrigger value="table" className="flex items-center gap-2">
              <Table className="h-4 w-4" />
              <span className="hidden sm:inline">Batch Table</span>
              <span className="sm:hidden">Table</span>
            </TabsTrigger>
            <TabsTrigger value="form" className="flex items-center gap-2">
              <PlusCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Add/Edit</span>
              <span className="sm:hidden">Add</span>
            </TabsTrigger>
            <TabsTrigger value="reminders" className="flex items-center gap-2 relative">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Reminders</span>
              <span className="sm:hidden">Alerts</span>
              {expiringBatches.length > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-medium">
                  {expiringBatches.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="table" className="mt-6">
            <BatchTable
              batches={batches}
              getExpirationStatus={getExpirationStatus}
              getDaysUntilExpiration={getDaysUntilExpiration}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabsContent>

          <TabsContent value="form" className="mt-6">
            <div className="max-w-xl mx-auto">
              <BatchForm
                editingBatch={editingBatch}
                onAdd={addBatch}
                onUpdate={updateBatch}
                onCancel={cancelEditing}
                onSuccess={handleSuccess}
              />
            </div>
          </TabsContent>

          <TabsContent value="reminders" className="mt-6">
            <ExpirationReminders
              expiringBatches={expiringBatches}
              getExpirationStatus={getExpirationStatus}
              getDaysUntilExpiration={getDaysUntilExpiration}
              onEdit={handleEdit}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t mt-auto">
        <div className="container py-4 text-center text-sm text-muted-foreground">
          <p>Laboratory Sample Manager • {batches.length} batches • Data saved locally</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
