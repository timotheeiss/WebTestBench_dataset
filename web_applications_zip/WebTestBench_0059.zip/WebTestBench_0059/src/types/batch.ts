export interface SampleBatch {
  id: string;
  name: string;
  cabinetNumber: string;
  shelfNumber: string;
  expirationDate: string; // ISO date string
  createdAt: string;
}

export interface StorageLocation {
  cabinetNumber: string;
  shelfNumber: string;
}

export type ExpirationStatus = 'expired' | 'critical' | 'warning' | 'safe';

export interface ValidationError {
  field: string;
  message: string;
}
