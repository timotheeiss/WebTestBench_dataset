import { useState, useCallback, useMemo, useEffect } from 'react';
import { SampleBatch, StorageLocation, ExpirationStatus, ValidationError } from '@/types/batch';
import { initialBatches } from '@/data/initialBatches';

const STORAGE_KEY = 'lab-batches-data';

const loadBatchesFromStorage = (): SampleBatch[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Failed to load batches from storage:', error);
  }
  return initialBatches;
};

const saveBatchesToStorage = (batches: SampleBatch[]) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(batches));
  } catch (error) {
    console.error('Failed to save batches to storage:', error);
  }
};

export const useBatchManager = () => {
  const [batches, setBatches] = useState<SampleBatch[]>(loadBatchesFromStorage);
  const [editingBatch, setEditingBatch] = useState<SampleBatch | null>(null);

  // Persist batches to localStorage whenever they change
  useEffect(() => {
    saveBatchesToStorage(batches);
  }, [batches]);

  const generateId = (): string => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  const isLocationDuplicate = useCallback(
    (location: StorageLocation, excludeId?: string): boolean => {
      return batches.some(
        (batch) =>
          batch.id !== excludeId &&
          batch.cabinetNumber.toLowerCase() === location.cabinetNumber.toLowerCase() &&
          batch.shelfNumber === location.shelfNumber
      );
    },
    [batches]
  );

  const validateBatch = useCallback(
    (
      name: string,
      cabinetNumber: string,
      shelfNumber: string,
      expirationDate: string,
      excludeId?: string
    ): ValidationError[] => {
      const errors: ValidationError[] = [];

      if (!name.trim()) {
        errors.push({ field: 'name', message: 'Sample name is required' });
      }

      if (!cabinetNumber.trim()) {
        errors.push({ field: 'cabinetNumber', message: 'Cabinet number is required' });
      }

      if (!shelfNumber.trim()) {
        errors.push({ field: 'shelfNumber', message: 'Shelf number is required' });
      }

      if (!expirationDate) {
        errors.push({ field: 'expirationDate', message: 'Expiration date is required' });
      } else {
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegex.test(expirationDate)) {
          errors.push({ field: 'expirationDate', message: 'Invalid date format (use YYYY-MM-DD)' });
        } else {
          const date = new Date(expirationDate);
          if (isNaN(date.getTime())) {
            errors.push({ field: 'expirationDate', message: 'Invalid date' });
          }
        }
      }

      if (
        cabinetNumber.trim() &&
        shelfNumber.trim() &&
        isLocationDuplicate({ cabinetNumber, shelfNumber }, excludeId)
      ) {
        errors.push({
          field: 'location',
          message: `Storage location (Cabinet ${cabinetNumber}, Shelf ${shelfNumber}) is already in use`,
        });
      }

      return errors;
    },
    [isLocationDuplicate]
  );

  const addBatch = useCallback(
    (name: string, cabinetNumber: string, shelfNumber: string, expirationDate: string): ValidationError[] => {
      const errors = validateBatch(name, cabinetNumber, shelfNumber, expirationDate);

      if (errors.length === 0) {
        const newBatch: SampleBatch = {
          id: generateId(),
          name: name.trim(),
          cabinetNumber: cabinetNumber.trim().toUpperCase(),
          shelfNumber: shelfNumber.trim(),
          expirationDate,
          createdAt: new Date().toISOString(),
        };
        setBatches((prev) => [...prev, newBatch]);
      }

      return errors;
    },
    [validateBatch]
  );

  const updateBatch = useCallback(
    (
      id: string,
      name: string,
      cabinetNumber: string,
      shelfNumber: string,
      expirationDate: string
    ): ValidationError[] => {
      const errors = validateBatch(name, cabinetNumber, shelfNumber, expirationDate, id);

      if (errors.length === 0) {
        setBatches((prev) =>
          prev.map((batch) =>
            batch.id === id
              ? {
                  ...batch,
                  name: name.trim(),
                  cabinetNumber: cabinetNumber.trim().toUpperCase(),
                  shelfNumber: shelfNumber.trim(),
                  expirationDate,
                }
              : batch
          )
        );
        setEditingBatch(null);
      }

      return errors;
    },
    [validateBatch]
  );

  const deleteBatch = useCallback((id: string): void => {
    setBatches((prev) => prev.filter((batch) => batch.id !== id));
    setEditingBatch((prev) => (prev?.id === id ? null : prev));
  }, []);

  const getExpirationStatus = useCallback((expirationDate: string): ExpirationStatus => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expDate = new Date(expirationDate);
    expDate.setHours(0, 0, 0, 0);

    const diffTime = expDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return 'expired';
    if (diffDays <= 3) return 'critical';
    if (diffDays <= 7) return 'warning';
    return 'safe';
  }, []);

  const getDaysUntilExpiration = useCallback((expirationDate: string): number => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expDate = new Date(expirationDate);
    expDate.setHours(0, 0, 0, 0);

    const diffTime = expDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }, []);

  const expiringBatches = useMemo(() => {
    return batches
      .filter((batch) => {
        const status = getExpirationStatus(batch.expirationDate);
        return status !== 'safe';
      })
      .sort((a, b) => new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime());
  }, [batches, getExpirationStatus]);

  const startEditing = useCallback((batch: SampleBatch) => {
    setEditingBatch(batch);
  }, []);

  const cancelEditing = useCallback(() => {
    setEditingBatch(null);
  }, []);

  return {
    batches,
    editingBatch,
    addBatch,
    updateBatch,
    deleteBatch,
    startEditing,
    cancelEditing,
    getExpirationStatus,
    getDaysUntilExpiration,
    expiringBatches,
  };
};
