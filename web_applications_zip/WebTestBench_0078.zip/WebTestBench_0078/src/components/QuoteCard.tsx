import { format } from 'date-fns';
import { Building2, DollarSign, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/StatusBadge';
import { Quote } from '@/types/procurement';
import { cn } from '@/lib/utils';

interface QuoteCardProps {
  quote: Quote;
  quantity: number;
  canSelect?: boolean;
  onSelect?: () => void;
}

export const QuoteCard = ({ quote, quantity, canSelect = false, onSelect }: QuoteCardProps) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <Card
      className={cn(
        'transition-all duration-200',
        quote.status === 'selected' && 'ring-2 ring-status-ordered border-status-ordered/50',
        quote.status === 'rejected' && 'opacity-50'
      )}
    >
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-secondary">
              <Building2 className="w-4 h-4 text-secondary-foreground" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground">{quote.supplierName}</h4>
              <p className="text-xs text-muted-foreground">
                Submitted {format(quote.submittedAt, 'MMM d, yyyy')}
              </p>
            </div>
          </div>
          <StatusBadge status={quote.status} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Unit Price</p>
            <p className="text-lg font-semibold text-foreground">{formatCurrency(quote.unitPrice)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Total ({quantity} units)</p>
            <p className="text-lg font-semibold text-primary">{formatCurrency(quote.totalPrice)}</p>
          </div>
        </div>
        
        {canSelect && quote.status === 'active' && (
          <Button
            onClick={onSelect}
            className="w-full"
            size="sm"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Select This Quote
          </Button>
        )}
        
        {quote.status === 'selected' && (
          <div className="flex items-center justify-center gap-2 text-sm text-status-ordered-foreground bg-status-ordered-bg py-2 rounded-md">
            <CheckCircle2 className="w-4 h-4" />
            <span className="font-medium">Winning Quote</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
