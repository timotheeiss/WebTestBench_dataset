import { ShoppingCart } from 'lucide-react';
import { CreateRequestDialog } from '@/components/CreateRequestDialog';

export const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary">
            <ShoppingCart className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">ProcureFlow</h1>
            <p className="text-xs text-muted-foreground">Purchase Management</p>
          </div>
        </div>
        <CreateRequestDialog />
      </div>
    </header>
  );
};
