import { format } from 'date-fns';
import { FileText, Building2, Package, Calendar, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { PurchaseOrder } from '@/types/procurement';

interface PurchaseOrderViewProps {
  order: PurchaseOrder;
}

export const PurchaseOrderView = ({ order }: PurchaseOrderViewProps) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <Card className="border-2 border-status-ordered/30 bg-gradient-to-br from-status-ordered-bg/50 to-card">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-status-ordered/10">
            <FileText className="w-6 h-6 text-status-ordered" />
          </div>
          <div>
            <CardTitle className="text-lg">Purchase Order</CardTitle>
            <p className="text-sm text-muted-foreground font-mono">{order.id}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex items-start gap-3">
            <Building2 className="w-4 h-4 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-xs text-muted-foreground">Supplier</p>
              <p className="font-medium">{order.supplierName}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-xs text-muted-foreground">Generated</p>
              <p className="font-medium">{format(order.generatedAt, 'MMM d, yyyy')}</p>
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <Package className="w-4 h-4 text-muted-foreground mt-0.5" />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Item</p>
              <p className="font-medium">{order.itemName}</p>
            </div>
          </div>
          
          <div className="bg-secondary/50 rounded-lg p-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Quantity</p>
                <p className="text-lg font-semibold">{order.quantity}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Unit Price</p>
                <p className="text-lg font-semibold">{formatCurrency(order.unitPrice)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total</p>
                <p className="text-lg font-semibold text-status-ordered">{formatCurrency(order.totalPrice)}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 text-xs text-muted-foreground">
          <span>Request: {order.requestId}</span>
          <span>Quote: {order.quoteId}</span>
        </div>
      </CardContent>
    </Card>
  );
};
