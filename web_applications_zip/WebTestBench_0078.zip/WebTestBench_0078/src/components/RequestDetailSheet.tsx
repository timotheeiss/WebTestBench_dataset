import { format } from 'date-fns';
import { Package, Calendar, Hash, AlertTriangle, FileWarning } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { StatusBadge } from '@/components/StatusBadge';
import { QuoteCard } from '@/components/QuoteCard';
import { AddQuoteDialog } from '@/components/AddQuoteDialog';
import { PurchaseOrderView } from '@/components/PurchaseOrderView';
import { useProcurement } from '@/contexts/ProcurementContext';
import { useToast } from '@/hooks/use-toast';
import { PurchaseRequest } from '@/types/procurement';

interface RequestDetailSheetProps {
  request: PurchaseRequest | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const RequestDetailSheet = ({ request, open, onOpenChange }: RequestDetailSheetProps) => {
  const { getQuotesForRequest, getOrderForRequest, selectQuote, revokeRequest } = useProcurement();
  const { toast } = useToast();

  if (!request) return null;

  const quotes = getQuotesForRequest(request.id);
  const order = getOrderForRequest(request.id);
  const canAddQuotes = request.status === 'pending' || request.status === 'quoted';
  const canSelectQuote = request.status === 'quoted' && quotes.some(q => q.status === 'active');
  const canRevoke = request.status === 'pending' || request.status === 'quoted';

  const handleSelectQuote = (quoteId: string) => {
    try {
      const newOrder = selectQuote(quoteId, request.id);
      toast({
        title: 'Purchase Order Generated',
        description: `Order ${newOrder.id} has been created successfully.`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to select quote. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleRevoke = () => {
    revokeRequest(request.id);
    toast({
      title: 'Request Revoked',
      description: 'The purchase request has been revoked. All quotes are now invalid.',
    });
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-[540px] overflow-y-auto">
        <SheetHeader className="space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Hash className="w-4 h-4" />
            <span className="font-mono">{request.id}</span>
            <StatusBadge status={request.status} />
          </div>
          <SheetTitle className="text-xl">{request.itemName}</SheetTitle>
          <SheetDescription className="text-base">
            {request.description}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Request Details */}
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Package className="w-4 h-4" />
              <span>Quantity: <span className="font-semibold text-foreground">{request.quantity}</span></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{format(request.createdAt, 'MMMM d, yyyy')}</span>
            </div>
          </div>

          {/* Warning for non-modifiable requests */}
          {(request.status === 'pending' || request.status === 'quoted') && (
            <div className="flex items-start gap-3 p-3 rounded-lg bg-status-pending-bg border border-status-pending/20">
              <FileWarning className="w-5 h-5 text-status-pending mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-status-pending-foreground">Request cannot be modified</p>
                <p className="text-muted-foreground">To make changes, revoke this request and submit a new one.</p>
              </div>
            </div>
          )}

          <Separator />

          {/* Purchase Order (if exists) */}
          {order && (
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Purchase Order</h3>
              <PurchaseOrderView order={order} />
            </div>
          )}

          {/* Quotes Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">
                Supplier Quotes {quotes.length > 0 && `(${quotes.length})`}
              </h3>
              {canAddQuotes && (
                <AddQuoteDialog requestId={request.id} quantity={request.quantity} />
              )}
            </div>

            {quotes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Package className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p>No quotes received yet</p>
                <p className="text-sm">Add supplier quotes to compare pricing</p>
              </div>
            ) : (
              <div className="space-y-3">
                {quotes.map((quote) => (
                  <QuoteCard
                    key={quote.id}
                    quote={quote}
                    quantity={request.quantity}
                    canSelect={canSelectQuote}
                    onSelect={() => handleSelectQuote(quote.id)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Revoke Action */}
          {canRevoke && (
            <>
              <Separator />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Revoke Request
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Revoke Purchase Request?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. All quotes for this request will become invalid.
                      You will need to create a new request if you still need this item.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleRevoke} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Revoke Request
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};
