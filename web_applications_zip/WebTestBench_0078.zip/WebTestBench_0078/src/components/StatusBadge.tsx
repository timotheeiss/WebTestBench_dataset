import { cn } from '@/lib/utils';
import { RequestStatus, QuoteStatus } from '@/types/procurement';

interface StatusBadgeProps {
  status: RequestStatus | QuoteStatus;
  className?: string;
}

const statusConfig: Record<RequestStatus | QuoteStatus, { label: string; className: string }> = {
  pending: {
    label: 'Pending',
    className: 'bg-status-pending-bg text-status-pending-foreground border-status-pending/30',
  },
  quoted: {
    label: 'Quoted',
    className: 'bg-status-quoted-bg text-status-quoted-foreground border-status-quoted/30',
  },
  ordered: {
    label: 'Ordered',
    className: 'bg-status-ordered-bg text-status-ordered-foreground border-status-ordered/30',
  },
  revoked: {
    label: 'Revoked',
    className: 'bg-status-revoked-bg text-status-revoked-foreground border-status-revoked/30',
  },
  active: {
    label: 'Active',
    className: 'bg-status-quoted-bg text-status-quoted-foreground border-status-quoted/30',
  },
  selected: {
    label: 'Selected',
    className: 'bg-status-ordered-bg text-status-ordered-foreground border-status-ordered/30',
  },
  rejected: {
    label: 'Rejected',
    className: 'bg-status-revoked-bg text-status-revoked-foreground border-status-revoked/30',
  },
};

export const StatusBadge = ({ status, className }: StatusBadgeProps) => {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border',
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
};
