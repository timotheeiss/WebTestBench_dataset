import { format } from 'date-fns';
import { Package, Calendar, Hash } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { StatusBadge } from '@/components/StatusBadge';
import { PurchaseRequest } from '@/types/procurement';
import { cn } from '@/lib/utils';

interface PurchaseRequestCardProps {
  request: PurchaseRequest;
  onClick?: () => void;
  quotesCount?: number;
}

export const PurchaseRequestCard = ({ request, onClick, quotesCount = 0 }: PurchaseRequestCardProps) => {
  const isClickable = request.status !== 'revoked';

  return (
    <Card
      className={cn(
        'transition-all duration-200',
        isClickable && 'cursor-pointer hover:shadow-md hover:border-primary/30',
        request.status === 'revoked' && 'opacity-60'
      )}
      onClick={isClickable ? onClick : undefined}
    >
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <Hash className="w-3.5 h-3.5" />
              <span className="font-mono">{request.id}</span>
            </div>
            <h3 className="font-semibold text-foreground truncate">{request.itemName}</h3>
          </div>
          <StatusBadge status={request.status} />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {request.description}
        </p>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Package className="w-4 h-4" />
              <span>Qty: <span className="font-medium text-foreground">{request.quantity}</span></span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{format(request.createdAt, 'MMM d, yyyy')}</span>
            </div>
          </div>
          {quotesCount > 0 && request.status !== 'revoked' && (
            <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded-md">
              {quotesCount} quote{quotesCount !== 1 ? 's' : ''}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
