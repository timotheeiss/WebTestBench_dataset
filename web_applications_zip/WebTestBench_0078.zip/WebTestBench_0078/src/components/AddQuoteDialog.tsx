import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useProcurement } from '@/contexts/ProcurementContext';
import { useToast } from '@/hooks/use-toast';

interface AddQuoteDialogProps {
  requestId: string;
  quantity: number;
}

export const AddQuoteDialog = ({ requestId, quantity }: AddQuoteDialogProps) => {
  const [open, setOpen] = useState(false);
  const [supplierName, setSupplierName] = useState('');
  const [unitPrice, setUnitPrice] = useState('');
  const [totalPrice, setTotalPrice] = useState('');
  const { addQuote } = useProcurement();
  const { toast } = useToast();

  useEffect(() => {
    const price = parseFloat(unitPrice);
    if (!isNaN(price) && price > 0) {
      setTotalPrice((price * quantity).toFixed(2));
    } else {
      setTotalPrice('');
    }
  }, [unitPrice, quantity]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!supplierName.trim() || !unitPrice) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all fields.',
        variant: 'destructive',
      });
      return;
    }

    const price = parseFloat(unitPrice);
    if (isNaN(price) || price <= 0) {
      toast({
        title: 'Validation Error',
        description: 'Unit price must be a positive number.',
        variant: 'destructive',
      });
      return;
    }

    addQuote({
      requestId,
      supplierName: supplierName.trim(),
      unitPrice: price,
      totalPrice: price * quantity,
    });

    toast({
      title: 'Quote Added',
      description: 'The supplier quote has been added successfully.',
    });

    setSupplierName('');
    setUnitPrice('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Quote
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Add Supplier Quote</DialogTitle>
            <DialogDescription>
              Enter the supplier's quote details for this purchase request.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="supplierName">Supplier Name</Label>
              <Input
                id="supplierName"
                placeholder="e.g., ABC Supplies Inc."
                value={supplierName}
                onChange={(e) => setSupplierName(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="unitPrice">Unit Price ($)</Label>
              <Input
                id="unitPrice"
                type="number"
                step="0.01"
                min="0.01"
                placeholder="0.00"
                value={unitPrice}
                onChange={(e) => setUnitPrice(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="totalPrice">Total Price (Auto-calculated)</Label>
              <Input
                id="totalPrice"
                type="text"
                value={totalPrice ? `$${totalPrice}` : ''}
                disabled
                className="bg-muted"
              />
              <p className="text-xs text-muted-foreground">
                Based on quantity of {quantity} units
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Add Quote</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
