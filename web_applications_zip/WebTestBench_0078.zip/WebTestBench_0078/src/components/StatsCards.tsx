import { ClipboardList, MessageSquareQuote, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useProcurement } from '@/contexts/ProcurementContext';

export const StatsCards = () => {
  const { requests, quotes, orders } = useProcurement();

  const stats = [
    {
      label: 'Total Requests',
      value: requests.length,
      icon: ClipboardList,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      label: 'Active Quotes',
      value: quotes.filter(q => q.status === 'active').length,
      icon: MessageSquareQuote,
      color: 'text-status-quoted',
      bgColor: 'bg-status-quoted-bg',
    },
    {
      label: 'Orders Generated',
      value: orders.length,
      icon: CheckCircle,
      color: 'text-status-ordered',
      bgColor: 'bg-status-ordered-bg',
    },
    {
      label: 'Revoked',
      value: requests.filter(r => r.status === 'revoked').length,
      icon: XCircle,
      color: 'text-status-revoked',
      bgColor: 'bg-status-revoked-bg',
    },
  ];

  return (
    <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.label}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
