export type RequestStatus = 'pending' | 'quoted' | 'ordered' | 'revoked';
export type QuoteStatus = 'active' | 'selected' | 'rejected';

export interface PurchaseRequest {
  id: string;
  itemName: string;
  quantity: number;
  description: string;
  status: RequestStatus;
  createdAt: Date;
  selectedQuoteId?: string;
}

export interface Quote {
  id: string;
  requestId: string;
  supplierName: string;
  unitPrice: number;
  totalPrice: number;
  status: QuoteStatus;
  submittedAt: Date;
}

export interface PurchaseOrder {
  id: string;
  requestId: string;
  quoteId: string;
  itemName: string;
  quantity: number;
  supplierName: string;
  unitPrice: number;
  totalPrice: number;
  generatedAt: Date;
}
