import React, { createContext, useContext, useState, useCallback } from 'react';
import { PurchaseRequest, Quote, PurchaseOrder, RequestStatus, QuoteStatus } from '@/types/procurement';
import { initialRequests, initialQuotes, initialOrders } from '@/data/mockData';

interface ProcurementContextType {
  requests: PurchaseRequest[];
  quotes: Quote[];
  orders: PurchaseOrder[];
  createRequest: (data: Omit<PurchaseRequest, 'id' | 'status' | 'createdAt'>) => void;
  revokeRequest: (requestId: string) => void;
  addQuote: (data: Omit<Quote, 'id' | 'status' | 'submittedAt'>) => void;
  selectQuote: (quoteId: string, requestId: string) => PurchaseOrder;
  getRequestById: (id: string) => PurchaseRequest | undefined;
  getQuotesForRequest: (requestId: string) => Quote[];
  getOrderForRequest: (requestId: string) => PurchaseOrder | undefined;
}

const ProcurementContext = createContext<ProcurementContextType | undefined>(undefined);

export const ProcurementProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [requests, setRequests] = useState<PurchaseRequest[]>(initialRequests);
  const [quotes, setQuotes] = useState<Quote[]>(initialQuotes);
  const [orders, setOrders] = useState<PurchaseOrder[]>(initialOrders);

  const generateId = (prefix: string) => {
    const num = Math.floor(Math.random() * 900) + 100;
    return `${prefix}-${num}`;
  };

  const createRequest = useCallback((data: Omit<PurchaseRequest, 'id' | 'status' | 'createdAt'>) => {
    const newRequest: PurchaseRequest = {
      ...data,
      id: generateId('REQ'),
      status: 'pending',
      createdAt: new Date(),
    };
    setRequests(prev => [newRequest, ...prev]);
  }, []);

  const revokeRequest = useCallback((requestId: string) => {
    setRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status: 'revoked' as RequestStatus } : req
      )
    );
    // Also reject all quotes for this request
    setQuotes(prev =>
      prev.map(quote =>
        quote.requestId === requestId ? { ...quote, status: 'rejected' as QuoteStatus } : quote
      )
    );
  }, []);

  const addQuote = useCallback((data: Omit<Quote, 'id' | 'status' | 'submittedAt'>) => {
    const newQuote: Quote = {
      ...data,
      id: generateId('QT'),
      status: 'active',
      submittedAt: new Date(),
    };
    setQuotes(prev => [...prev, newQuote]);
    
    // Update request status to 'quoted' if it was 'pending'
    setRequests(prev =>
      prev.map(req =>
        req.id === data.requestId && req.status === 'pending'
          ? { ...req, status: 'quoted' as RequestStatus }
          : req
      )
    );
  }, []);

  const selectQuote = useCallback((quoteId: string, requestId: string): PurchaseOrder => {
    const quote = quotes.find(q => q.id === quoteId);
    const request = requests.find(r => r.id === requestId);
    
    if (!quote || !request) {
      throw new Error('Quote or request not found');
    }

    // Update the selected quote and reject others
    setQuotes(prev =>
      prev.map(q => {
        if (q.requestId === requestId) {
          return {
            ...q,
            status: q.id === quoteId ? 'selected' as QuoteStatus : 'rejected' as QuoteStatus,
          };
        }
        return q;
      })
    );

    // Update request status
    setRequests(prev =>
      prev.map(req =>
        req.id === requestId
          ? { ...req, status: 'ordered' as RequestStatus, selectedQuoteId: quoteId }
          : req
      )
    );

    // Create purchase order
    const newOrder: PurchaseOrder = {
      id: generateId('PO'),
      requestId,
      quoteId,
      itemName: request.itemName,
      quantity: request.quantity,
      supplierName: quote.supplierName,
      unitPrice: quote.unitPrice,
      totalPrice: quote.totalPrice,
      generatedAt: new Date(),
    };

    setOrders(prev => [...prev, newOrder]);
    return newOrder;
  }, [quotes, requests]);

  const getRequestById = useCallback((id: string) => {
    return requests.find(r => r.id === id);
  }, [requests]);

  const getQuotesForRequest = useCallback((requestId: string) => {
    return quotes.filter(q => q.requestId === requestId);
  }, [quotes]);

  const getOrderForRequest = useCallback((requestId: string) => {
    return orders.find(o => o.requestId === requestId);
  }, [orders]);

  return (
    <ProcurementContext.Provider
      value={{
        requests,
        quotes,
        orders,
        createRequest,
        revokeRequest,
        addQuote,
        selectQuote,
        getRequestById,
        getQuotesForRequest,
        getOrderForRequest,
      }}
    >
      {children}
    </ProcurementContext.Provider>
  );
};

export const useProcurement = () => {
  const context = useContext(ProcurementContext);
  if (!context) {
    throw new Error('useProcurement must be used within a ProcurementProvider');
  }
  return context;
};
