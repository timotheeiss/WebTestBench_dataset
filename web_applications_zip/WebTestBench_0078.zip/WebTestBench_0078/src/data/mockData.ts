import { PurchaseRequest, Quote, PurchaseOrder } from '@/types/procurement';

export const initialRequests: PurchaseRequest[] = [
  {
    id: 'REQ-001',
    itemName: 'Office Chairs (Ergonomic)',
    quantity: 25,
    description: 'High-quality ergonomic office chairs with lumbar support and adjustable armrests for the new open office space.',
    status: 'quoted',
    createdAt: new Date('2026-01-08'),
  },
  {
    id: 'REQ-002',
    itemName: 'MacBook Pro 14"',
    quantity: 10,
    description: 'Apple MacBook Pro 14-inch with M3 Pro chip, 18GB RAM, 512GB SSD for the development team.',
    status: 'ordered',
    createdAt: new Date('2026-01-05'),
    selectedQuoteId: 'QT-003',
  },
  {
    id: 'REQ-003',
    itemName: 'Standing Desks',
    quantity: 15,
    description: 'Electric height-adjustable standing desks, 60x30 inches, with memory presets.',
    status: 'pending',
    createdAt: new Date('2026-01-10'),
  },
  {
    id: 'REQ-004',
    itemName: 'Conference Room Projector',
    quantity: 2,
    description: '4K laser projector with wireless connectivity for the main conference rooms.',
    status: 'revoked',
    createdAt: new Date('2026-01-03'),
  },
];

export const initialQuotes: Quote[] = [
  {
    id: 'QT-001',
    requestId: 'REQ-001',
    supplierName: 'OfficePro Supplies',
    unitPrice: 449.99,
    totalPrice: 11249.75,
    status: 'active',
    submittedAt: new Date('2026-01-09'),
  },
  {
    id: 'QT-002',
    requestId: 'REQ-001',
    supplierName: 'ErgoFurniture Co.',
    unitPrice: 389.00,
    totalPrice: 9725.00,
    status: 'active',
    submittedAt: new Date('2026-01-09'),
  },
  {
    id: 'QT-003',
    requestId: 'REQ-002',
    supplierName: 'TechWorld Solutions',
    unitPrice: 1999.00,
    totalPrice: 19990.00,
    status: 'selected',
    submittedAt: new Date('2026-01-06'),
  },
  {
    id: 'QT-004',
    requestId: 'REQ-002',
    supplierName: 'Apple Authorized Reseller',
    unitPrice: 2199.00,
    totalPrice: 21990.00,
    status: 'rejected',
    submittedAt: new Date('2026-01-06'),
  },
];

export const initialOrders: PurchaseOrder[] = [
  {
    id: 'PO-001',
    requestId: 'REQ-002',
    quoteId: 'QT-003',
    itemName: 'MacBook Pro 14"',
    quantity: 10,
    supplierName: 'TechWorld Solutions',
    unitPrice: 1999.00,
    totalPrice: 19990.00,
    generatedAt: new Date('2026-01-07'),
  },
];
