import { useState } from 'react';
import { Header } from '@/components/Header';
import { StatsCards } from '@/components/StatsCards';
import { PurchaseRequestCard } from '@/components/PurchaseRequestCard';
import { RequestDetailSheet } from '@/components/RequestDetailSheet';
import { useProcurement } from '@/contexts/ProcurementContext';
import { PurchaseRequest } from '@/types/procurement';

const Index = () => {
  const { requests, getQuotesForRequest } = useProcurement();
  const [selectedRequest, setSelectedRequest] = useState<PurchaseRequest | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);

  const handleRequestClick = (request: PurchaseRequest) => {
    setSelectedRequest(request);
    setSheetOpen(true);
  };

  // Sort requests: pending/quoted first, then ordered, then revoked
  const sortedRequests = [...requests].sort((a, b) => {
    const order = { pending: 0, quoted: 1, ordered: 2, revoked: 3 };
    return order[a.status] - order[b.status];
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 space-y-8">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Dashboard</h2>
          <p className="text-muted-foreground">
            Manage purchase requests, review supplier quotes, and generate orders.
          </p>
        </div>

        <StatsCards />

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Purchase Requests</h3>
          
          {sortedRequests.length === 0 ? (
            <div className="text-center py-16 bg-card rounded-xl border">
              <p className="text-muted-foreground mb-2">No purchase requests yet</p>
              <p className="text-sm text-muted-foreground">
                Click "New Request" to create your first purchase request
              </p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {sortedRequests.map((request) => (
                <PurchaseRequestCard
                  key={request.id}
                  request={request}
                  quotesCount={getQuotesForRequest(request.id).length}
                  onClick={() => handleRequestClick(request)}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <RequestDetailSheet
        request={selectedRequest}
        open={sheetOpen}
        onOpenChange={setSheetOpen}
      />
    </div>
  );
};

export default Index;
