import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import type { ErrorPattern, SearchResult } from "@/data/errors";

interface ErrorCardProps {
  error: ErrorPattern;
  index: number;
  score?: number;
  matchType?: 'exact' | 'partial' | 'fuzzy';
}

const categoryColors: Record<string, string> = {
  npm: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  import: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  network: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  runtime: "bg-red-500/10 text-red-400 border-red-500/20",
  filesystem: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  syntax: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  auth: "bg-green-500/10 text-green-400 border-green-500/20",
  react: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  typescript: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
};

const matchTypeColors = {
  exact: "bg-primary/20 text-primary border-primary/30",
  partial: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  fuzzy: "bg-muted text-muted-foreground border-border",
};

function getScoreColor(score: number): string {
  if (score >= 80) return "text-primary";
  if (score >= 50) return "text-yellow-400";
  return "text-muted-foreground";
}

export function ErrorCard({ error, index, score, matchType }: ErrorCardProps) {
  return (
    <Link
      to={`/error/${error.id}`}
      className="group block opacity-0 animate-fade-in"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="p-5 rounded-lg bg-card border border-border hover:border-primary/50 transition-all duration-200 hover:bg-card/80">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className={`px-2 py-0.5 text-xs font-medium rounded border ${categoryColors[error.category] || "bg-muted text-muted-foreground border-border"}`}>
                {error.category}
              </span>
              {score !== undefined && matchType && (
                <>
                  <span className={`px-2 py-0.5 text-xs font-medium rounded border ${matchTypeColors[matchType]}`}>
                    {matchType}
                  </span>
                  <span className={`font-mono text-xs font-medium ${getScoreColor(score)}`}>
                    {score}% match
                  </span>
                </>
              )}
            </div>
            <h3 className="font-mono text-sm font-medium text-foreground group-hover:text-primary transition-colors mb-2 truncate">
              {error.name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {error.description}
            </p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0 mt-1" />
        </div>
      </div>
    </Link>
  );
}
