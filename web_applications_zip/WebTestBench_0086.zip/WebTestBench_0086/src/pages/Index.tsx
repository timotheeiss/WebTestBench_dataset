import { useState, useMemo } from "react";
import { Terminal, Zap } from "lucide-react";
import { SearchInput } from "@/components/SearchInput";
import { ErrorCard } from "@/components/ErrorCard";
import { searchErrors, errorPatterns, type SearchResult } from "@/data/errors";

const Index = () => {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    if (!query.trim()) return [];
    return searchErrors(query);
  }, [query]);

  const showResults = query.trim().length > 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container max-w-4xl py-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
              <Terminal className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">Error Lookup</h1>
              <p className="text-sm text-muted-foreground">Diagnose errors instantly</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-4xl py-12">
        {/* Hero Section */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-foreground mb-3">
            Paste your error. Get answers.
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Search our database of common development errors to find root causes and step-by-step diagnostic guides.
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <SearchInput value={query} onChange={setQuery} />
          {!showResults && (
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Try pasting an error like "Cannot find module" or "CORS policy"
            </p>
          )}
        </div>

        {/* Results */}
        {showResults && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-muted-foreground">
                {results.length === 0
                  ? "No matching errors found"
                  : `${results.length} matching ${results.length === 1 ? "error" : "errors"}`}
              </h3>
            </div>

            {results.length === 0 ? (
              <div className="py-12 text-center">
                <div className="p-4 rounded-full bg-muted/50 w-fit mx-auto mb-4">
                  <Zap className="w-6 h-6 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground mb-2">No matches for your search</p>
                <p className="text-sm text-muted-foreground/70">
                  Try different keywords or paste a complete error message
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {results.map((result, index) => (
                  <ErrorCard 
                    key={result.error.id} 
                    error={result.error} 
                    index={index}
                    score={result.score}
                    matchType={result.matchType}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Browse All (when not searching) */}
        {!showResults && (
          <div className="mt-16">
            <h3 className="text-sm font-medium text-muted-foreground mb-4">
              Browse all {errorPatterns.length} error patterns
            </h3>
            <div className="space-y-3">
              {errorPatterns.map((error, index) => (
                <ErrorCard key={error.id} error={error} index={index} />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="container max-w-4xl py-6">
          <p className="text-xs text-muted-foreground text-center">
            Built for developers. No tracking. No ads.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
