import { useParams, Link } from "react-router-dom";
import { ArrowLeft, AlertCircle, CheckCircle2, Lightbulb } from "lucide-react";
import { getErrorById } from "@/data/errors";

const categoryColors: Record<string, string> = {
  npm: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  import: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  network: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  runtime: "bg-red-500/10 text-red-400 border-red-500/20",
  filesystem: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  syntax: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  auth: "bg-green-500/10 text-green-400 border-green-500/20",
  react: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  typescript: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
};

export default function ErrorDetail() {
  const { id } = useParams<{ id: string }>();
  const error = id ? getErrorById(id) : undefined;

  if (!error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Error not found</h1>
          <p className="text-muted-foreground mb-6">This error pattern doesn't exist in our database.</p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to search
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container max-w-4xl py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to search
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container max-w-4xl py-10">
        {/* Title Section */}
        <div className="mb-10">
          <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded border mb-4 ${categoryColors[error.category] || "bg-muted text-muted-foreground border-border"}`}>
            {error.category}
          </span>
          <h1 className="text-2xl md:text-3xl font-bold font-mono text-foreground mb-4">
            {error.name}
          </h1>
          <p className="text-lg text-muted-foreground">
            {error.description}
          </p>
        </div>

        {/* Pattern Keywords */}
        <div className="mb-10 p-4 rounded-lg bg-card border border-border">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">
            Pattern Keywords
          </h3>
          <div className="flex flex-wrap gap-2">
            {error.pattern.map((keyword) => (
              <code
                key={keyword}
                className="px-2 py-1 text-xs font-mono bg-muted rounded text-foreground"
              >
                {keyword}
              </code>
            ))}
          </div>
        </div>

        {/* Root Causes */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-5">
            <AlertCircle className="w-5 h-5 text-destructive" />
            <h2 className="text-lg font-semibold text-foreground">Common Root Causes</h2>
          </div>
          <div className="space-y-3">
            {error.rootCauses.map((cause, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-4 rounded-lg bg-card border border-border opacity-0 animate-fade-in"
                style={{ animationDelay: `${index * 75}ms` }}
              >
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-destructive/10 text-destructive text-xs font-medium flex items-center justify-center">
                  {index + 1}
                </span>
                <p className="text-foreground">{cause}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Diagnostic Steps */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-5">
            <Lightbulb className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Self-Check Diagnostic Steps</h2>
          </div>
          <div className="space-y-3">
            {error.diagnosticSteps.map((step, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-4 rounded-lg bg-card border border-border opacity-0 animate-fade-in"
                style={{ animationDelay: `${(error.rootCauses.length + index) * 75}ms` }}
              >
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-foreground font-mono text-sm">{step}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Quick Tips */}
        <section className="p-6 rounded-lg bg-primary/5 border border-primary/20">
          <h3 className="text-sm font-medium text-primary mb-3">Pro Tip</h3>
          <p className="text-sm text-muted-foreground">
            Always check the full stack trace, not just the first line. The root cause is often deeper in the call stack. Use your IDE's "Go to definition" feature to trace imports and understand where the error originates.
          </p>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-10">
        <div className="container max-w-4xl py-6">
          <p className="text-xs text-muted-foreground text-center">
            Built for developers. No tracking. No ads.
          </p>
        </div>
      </footer>
    </div>
  );
}
