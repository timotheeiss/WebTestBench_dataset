export interface ErrorPattern {
  id: string;
  name: string;
  pattern: string[];
  description: string;
  rootCauses: string[];
  diagnosticSteps: string[];
  category: string;
}

export interface SearchResult {
  error: ErrorPattern;
  score: number;
  matchType: 'exact' | 'partial' | 'fuzzy';
}

export const errorPatterns: ErrorPattern[] = [
  {
    id: "npm-eacces",
    name: "EACCES Permission Denied",
    pattern: ["EACCES", "permission denied", "npm ERR!", "EPERM"],
    description: "Permission error when installing npm packages globally or accessing system directories.",
    category: "npm",
    rootCauses: [
      "Attempting to install packages globally without proper permissions",
      "Node.js was installed with root/admin privileges",
      "File system permissions are incorrectly configured",
      "Antivirus or security software blocking file operations"
    ],
    diagnosticSteps: [
      "Check if you're running the command with proper permissions (try sudo on Unix)",
      "Verify the ownership of your npm cache: ls -la ~/.npm",
      "Consider using nvm to manage Node installations without root",
      "Check if your antivirus is blocking npm operations"
    ]
  },
  {
    id: "module-not-found",
    name: "Cannot find module",
    pattern: ["Cannot find module", "Module not found", "Error: Cannot resolve"],
    description: "The application cannot locate a required module or package in the project.",
    category: "import",
    rootCauses: [
      "The package is not installed in node_modules",
      "Typo in the import path or module name",
      "The module was deleted or moved without updating imports",
      "Using incorrect relative path (missing ./ or ../)"
    ],
    diagnosticSteps: [
      "Run npm install to ensure all dependencies are installed",
      "Check the exact spelling of the module name in package.json",
      "Verify the import path matches the actual file location",
      "Delete node_modules and package-lock.json, then reinstall"
    ]
  },
  {
    id: "cors-error",
    name: "CORS Policy Blocked",
    pattern: ["CORS", "Access-Control-Allow-Origin", "blocked by CORS policy", "cross-origin"],
    description: "Browser blocked a request due to Cross-Origin Resource Sharing restrictions.",
    category: "network",
    rootCauses: [
      "Server doesn't include proper CORS headers in response",
      "Making requests to a different domain/port without CORS configuration",
      "Credentials mode mismatch between request and server",
      "Preflight OPTIONS request failing"
    ],
    diagnosticSteps: [
      "Check if the server is configured to allow your origin",
      "Verify the request headers match what the server expects",
      "Use browser DevTools Network tab to inspect the failed request",
      "Test if the API works with tools like Postman (which bypass CORS)"
    ]
  },
  {
    id: "undefined-property",
    name: "Cannot read property of undefined",
    pattern: ["Cannot read property", "of undefined", "of null", "TypeError"],
    description: "Attempting to access a property or method on a variable that is undefined or null.",
    category: "runtime",
    rootCauses: [
      "Variable was never initialized or assigned a value",
      "Async data hasn't loaded yet when accessed",
      "Object property doesn't exist or has a typo",
      "Array index is out of bounds"
    ],
    diagnosticSteps: [
      "Add console.log before the error line to check the variable value",
      "Use optional chaining (?.) for potentially undefined values",
      "Ensure async data has loaded before accessing it",
      "Verify the property name matches exactly (case-sensitive)"
    ]
  },
  {
    id: "enoent",
    name: "ENOENT: No such file or directory",
    pattern: ["ENOENT", "no such file or directory", "ENOTDIR"],
    description: "The system cannot find the specified file or directory path.",
    category: "filesystem",
    rootCauses: [
      "The file or folder doesn't exist at the specified path",
      "Typo in the file path or filename",
      "Working directory is different than expected",
      "File was deleted or moved"
    ],
    diagnosticSteps: [
      "Verify the file exists: ls -la /path/to/file",
      "Check your current working directory: pwd",
      "Use absolute paths instead of relative paths",
      "Ensure the file extension is correct"
    ]
  },
  {
    id: "syntax-error",
    name: "SyntaxError: Unexpected token",
    pattern: ["SyntaxError", "Unexpected token", "Unexpected identifier", "Parsing error"],
    description: "JavaScript parser encountered invalid syntax that cannot be interpreted.",
    category: "syntax",
    rootCauses: [
      "Missing or extra brackets, braces, or parentheses",
      "Forgotten comma in array or object literal",
      "Using reserved keyword as variable name",
      "Mixing up arrow function syntax"
    ],
    diagnosticSteps: [
      "Check the line number mentioned in the error",
      "Look for missing closing brackets or braces",
      "Use your IDE's syntax highlighting to spot issues",
      "Run a linter (ESLint) to catch syntax problems"
    ]
  },
  {
    id: "port-in-use",
    name: "EADDRINUSE: Port already in use",
    pattern: ["EADDRINUSE", "address already in use", "port is already allocated"],
    description: "The network port you're trying to use is already occupied by another process.",
    category: "network",
    rootCauses: [
      "Another instance of your application is already running",
      "A different application is using the same port",
      "Previous process didn't shut down properly",
      "System service is occupying the port"
    ],
    diagnosticSteps: [
      "Find what's using the port: lsof -i :PORT or netstat -ano | findstr :PORT",
      "Kill the process using the port if safe to do so",
      "Change your application to use a different port",
      "Restart your computer to clear hung processes"
    ]
  },
  {
    id: "out-of-memory",
    name: "JavaScript heap out of memory",
    pattern: ["heap out of memory", "FATAL ERROR", "allocation failed", "JavaScript heap"],
    description: "Node.js ran out of allocated memory while executing your application.",
    category: "runtime",
    rootCauses: [
      "Processing very large files or datasets",
      "Memory leak in application code",
      "Infinite loop creating objects",
      "Too many concurrent operations"
    ],
    diagnosticSteps: [
      "Increase Node memory limit: node --max-old-space-size=4096",
      "Profile memory usage with Chrome DevTools",
      "Check for memory leaks with heap snapshots",
      "Process large data in smaller chunks"
    ]
  },
  {
    id: "connection-refused",
    name: "ECONNREFUSED: Connection refused",
    pattern: ["ECONNREFUSED", "Connection refused", "connect ECONNREFUSED"],
    description: "Unable to establish a connection to the target server or service.",
    category: "network",
    rootCauses: [
      "The target service is not running",
      "Wrong host or port configuration",
      "Firewall blocking the connection",
      "Service is running but not accepting connections"
    ],
    diagnosticSteps: [
      "Verify the target service is running and healthy",
      "Check if host and port configuration is correct",
      "Test connectivity: ping host or telnet host port",
      "Check firewall rules aren't blocking traffic"
    ]
  },
  {
    id: "jwt-expired",
    name: "JWT Token Expired",
    pattern: ["jwt expired", "TokenExpiredError", "token has expired", "jwt malformed"],
    description: "The JSON Web Token used for authentication has passed its expiration time.",
    category: "auth",
    rootCauses: [
      "Token validity period has passed",
      "Server and client clocks are out of sync",
      "Token refresh mechanism not implemented",
      "User session timed out"
    ],
    diagnosticSteps: [
      "Check the token's exp claim: decode it at jwt.io",
      "Implement automatic token refresh before expiration",
      "Sync server and client system clocks",
      "Clear stored tokens and re-authenticate"
    ]
  },
  {
    id: "react-hooks-rules",
    name: "React Hooks Rules Violation",
    pattern: ["Hooks can only be called", "Invalid hook call", "rendered more hooks than"],
    description: "React hooks are being used incorrectly, violating the Rules of Hooks.",
    category: "react",
    rootCauses: [
      "Calling hooks inside conditions, loops, or nested functions",
      "Multiple versions of React in the project",
      "Calling hooks from regular JavaScript functions",
      "Hook call order changes between renders"
    ],
    diagnosticSteps: [
      "Ensure hooks are only called at the top level of components",
      "Check for duplicate React packages: npm ls react",
      "Move conditional logic inside the hook, not around it",
      "Use the ESLint plugin eslint-plugin-react-hooks"
    ]
  },
  {
    id: "type-error-assignment",
    name: "TypeScript Type Mismatch",
    pattern: ["Type '", "is not assignable to type", "TS2322", "TS2345"],
    description: "TypeScript detected a type incompatibility in your code.",
    category: "typescript",
    rootCauses: [
      "Passing wrong type to function or component",
      "Object shape doesn't match interface",
      "Missing required properties",
      "Null or undefined where value expected"
    ],
    diagnosticSteps: [
      "Read the full error to see expected vs actual types",
      "Check if you need to handle null/undefined cases",
      "Verify imported types match the library version",
      "Use type assertions (as Type) only when certain"
    ]
  }
];

// Calculate Levenshtein distance for fuzzy matching
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[b.length][a.length];
}

// Calculate similarity ratio (0-1)
function similarityRatio(a: string, b: string): number {
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  const distance = levenshteinDistance(a, b);
  return 1 - distance / maxLen;
}

// Tokenize query into keywords
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[\s\-_:.,;!?'"()\[\]{}]+/)
    .filter(token => token.length > 1);
}

// Check if any word in text contains the token
function fuzzyContains(text: string, token: string, threshold = 0.7): { match: boolean; score: number } {
  const words = tokenize(text);
  let bestScore = 0;
  
  for (const word of words) {
    // Exact substring match
    if (word.includes(token) || token.includes(word)) {
      bestScore = Math.max(bestScore, 0.9);
    }
    // Fuzzy match
    const similarity = similarityRatio(word, token);
    if (similarity >= threshold) {
      bestScore = Math.max(bestScore, similarity);
    }
  }
  
  return { match: bestScore > 0, score: bestScore };
}

export function searchErrors(query: string): SearchResult[] {
  if (!query.trim()) return [];
  
  const queryTokens = tokenize(query);
  const lowerQuery = query.toLowerCase();
  const results: SearchResult[] = [];
  
  for (const error of errorPatterns) {
    let totalScore = 0;
    let matchType: 'exact' | 'partial' | 'fuzzy' = 'fuzzy';
    
    // Exact pattern match (highest priority) - score: 100
    const exactPatternMatch = error.pattern.some(p => 
      lowerQuery.includes(p.toLowerCase()) || p.toLowerCase().includes(lowerQuery)
    );
    if (exactPatternMatch) {
      totalScore += 100;
      matchType = 'exact';
    }
    
    // Exact name match - score: 80
    if (error.name.toLowerCase().includes(lowerQuery) || 
        lowerQuery.includes(error.name.toLowerCase())) {
      totalScore += 80;
      matchType = matchType === 'fuzzy' ? 'exact' : matchType;
    }
    
    // Keyword matching with fuzzy support
    const searchableFields = [
      { text: error.name, weight: 5 },
      { text: error.description, weight: 3 },
      { text: error.pattern.join(' '), weight: 8 },
      { text: error.category, weight: 2 },
      { text: error.rootCauses.join(' '), weight: 2 }
    ];
    
    for (const token of queryTokens) {
      for (const field of searchableFields) {
        const { match, score } = fuzzyContains(field.text, token);
        if (match) {
          totalScore += score * field.weight * 10;
          if (score >= 0.9 && matchType === 'fuzzy') {
            matchType = 'partial';
          }
        }
      }
    }
    
    // Bonus for category keyword match
    if (queryTokens.some(t => error.category.toLowerCase().includes(t))) {
      totalScore += 15;
    }
    
    // Only include if we have some match
    if (totalScore > 0) {
      // Normalize score to 0-100
      const normalizedScore = Math.min(100, Math.round(totalScore / 2));
      results.push({ error, score: normalizedScore, matchType });
    }
  }
  
  // Sort by score descending
  return results.sort((a, b) => b.score - a.score);
}

export function getErrorById(id: string): ErrorPattern | undefined {
  return errorPatterns.find(error => error.id === id);
}
