import { useMemo } from 'react';
import { Check, X, HelpCircle, Clock, Users } from 'lucide-react';
import { Event, Guest, RSVPStatus } from '@/types/event';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

interface GuestSummaryProps {
  event: Event;
}

const statusConfig: Record<RSVPStatus, { label: string; icon: typeof Check; variant: 'success' | 'destructive' | 'warning' | 'muted' }> = {
  yes: { label: 'Attending', icon: Check, variant: 'success' },
  no: { label: 'Not Attending', icon: X, variant: 'destructive' },
  maybe: { label: 'Maybe', icon: HelpCircle, variant: 'warning' },
  pending: { label: 'Pending', icon: Clock, variant: 'muted' },
};

export function GuestSummary({ event }: GuestSummaryProps) {
  const guestsByStatus = useMemo(() => {
    const groups: Record<RSVPStatus, Guest[]> = {
      yes: [],
      no: [],
      maybe: [],
      pending: [],
    };
    event.guests.forEach(guest => {
      groups[guest.rsvpStatus].push(guest);
    });
    return groups;
  }, [event.guests]);

  const guestsByOption = useMemo(() => {
    const groups: Record<string, Guest[]> = {};
    event.invitationOptions.forEach(opt => {
      groups[opt.id] = event.guests.filter(g => g.selectedOption === opt.id && g.rsvpStatus === 'yes');
    });
    return groups;
  }, [event.guests, event.invitationOptions]);

  const preferenceBreakdown = useMemo(() => {
    const breakdown: Record<string, Record<string, number>> = {};
    event.preferenceQuestions.forEach(q => {
      breakdown[q.id] = {};
      q.options.forEach(opt => {
        breakdown[q.id][opt] = event.guests.filter(
          g => g.rsvpStatus === 'yes' && g.preferences[q.id] === opt
        ).length;
      });
    });
    return breakdown;
  }, [event.guests, event.preferenceQuestions]);

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-accent" />
          <CardTitle className="font-display text-xl">Guest Summary</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="status" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            <TabsTrigger value="status">By Status</TabsTrigger>
            <TabsTrigger value="option">By Option</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
          </TabsList>

          <TabsContent value="status" className="space-y-4">
            {(Object.keys(statusConfig) as RSVPStatus[]).map(status => {
              const config = statusConfig[status];
              const guests = guestsByStatus[status];
              const Icon = config.icon;
              
              return (
                <div key={status} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant={config.variant} className="gap-1">
                      <Icon className="h-3 w-3" />
                      {config.label}
                    </Badge>
                    <span className="text-sm text-muted-foreground">({guests.length})</span>
                  </div>
                  {guests.length > 0 ? (
                    <div className="flex flex-wrap gap-2 pl-4">
                      {guests.map(guest => (
                        <span
                          key={guest.id}
                          className="text-sm px-2 py-1 rounded-md bg-secondary"
                        >
                          {guest.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground pl-4">No guests</p>
                  )}
                </div>
              );
            })}
          </TabsContent>

          <TabsContent value="option" className="space-y-4">
            {event.invitationOptions.map(option => {
              const guests = guestsByOption[option.id] || [];
              
              return (
                <div key={option.id} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="accent">{option.name}</Badge>
                    <span className="text-sm text-muted-foreground">({guests.length})</span>
                  </div>
                  {guests.length > 0 ? (
                    <div className="flex flex-wrap gap-2 pl-4">
                      {guests.map(guest => (
                        <span
                          key={guest.id}
                          className="text-sm px-2 py-1 rounded-md bg-secondary"
                        >
                          {guest.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground pl-4">No guests</p>
                  )}
                </div>
              );
            })}
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            {event.preferenceQuestions.map(question => (
              <div key={question.id} className="space-y-2">
                <h4 className="font-medium">{question.question}</h4>
                <div className="space-y-1 pl-4">
                  {question.options.map(option => {
                    const count = preferenceBreakdown[question.id]?.[option] || 0;
                    const total = guestsByStatus.yes.length;
                    const percentage = total > 0 ? (count / total) * 100 : 0;
                    
                    return (
                      <div key={option} className="flex items-center gap-3">
                        <div className="w-32 text-sm truncate">{option}</div>
                        <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent transition-all"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground w-16 text-right">
                          {count} ({percentage.toFixed(0)}%)
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            {event.preferenceQuestions.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No preference questions for this event.
              </p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
