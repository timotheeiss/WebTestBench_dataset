import { useState } from 'react';
import { Check, X, HelpCircle } from 'lucide-react';
import { Event, RSVPStatus, InvitationOption, PreferenceQuestion } from '@/types/event';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';

interface RSVPFormProps {
  event: Event;
  onSubmit: (status: RSVPStatus, selectedOption?: string, preferences?: Record<string, string>) => void;
  initialStatus?: RSVPStatus;
  initialOption?: string;
  initialPreferences?: Record<string, string>;
}

export function RSVPForm({ event, onSubmit, initialStatus, initialOption, initialPreferences = {} }: RSVPFormProps) {
  const [status, setStatus] = useState<RSVPStatus | null>(initialStatus || null);
  const [selectedOption, setSelectedOption] = useState(initialOption || '');
  const [preferences, setPreferences] = useState<Record<string, string>>(initialPreferences);

  const handleSubmit = () => {
    if (status) {
      onSubmit(status, status === 'yes' ? selectedOption : undefined, status === 'yes' ? preferences : {});
    }
  };

  const isComplete = status && (status !== 'yes' || (
    selectedOption &&
    event.preferenceQuestions
      .filter(q => q.required)
      .every(q => preferences[q.id])
  ));

  if (!event.isRsvpOpen) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-muted-foreground">RSVPs are currently closed for this event.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="font-display text-xl">RSVP</CardTitle>
        <CardDescription>Let us know if you can make it!</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Response buttons */}
        <div className="space-y-2">
          <Label className="text-base">Will you attend?</Label>
          <div className="flex gap-2">
            {[
              { value: 'yes' as const, label: 'Yes', icon: Check, activeClass: 'bg-success text-success-foreground border-success' },
              { value: 'no' as const, label: 'No', icon: X, activeClass: 'bg-destructive text-destructive-foreground border-destructive' },
              { value: 'maybe' as const, label: 'Maybe', icon: HelpCircle, activeClass: 'bg-warning text-warning-foreground border-warning' },
            ].map(({ value, label, icon: Icon, activeClass }) => (
              <Button
                key={value}
                type="button"
                variant="outline"
                className={cn(
                  "flex-1 gap-2",
                  status === value && activeClass
                )}
                onClick={() => setStatus(value)}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Invitation options - only show for 'yes' */}
        {status === 'yes' && event.invitationOptions.length > 0 && (
          <div className="space-y-3 animate-fade-in">
            <Label className="text-base">Select your attendance option</Label>
            <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
              {event.invitationOptions.map((option) => (
                <div
                  key={option.id}
                  className={cn(
                    "flex items-start space-x-3 rounded-lg border p-4 cursor-pointer transition-all",
                    selectedOption === option.id ? "border-accent bg-accent/5" : "hover:border-accent/50"
                  )}
                  onClick={() => setSelectedOption(option.id)}
                >
                  <RadioGroupItem value={option.id} id={option.id} className="mt-0.5" />
                  <div className="flex-1">
                    <Label htmlFor={option.id} className="font-medium cursor-pointer">
                      {option.name}
                      {option.price !== undefined && option.price > 0 && (
                        <span className="ml-2 text-accent">${option.price}</span>
                      )}
                    </Label>
                    {option.description && (
                      <p className="text-sm text-muted-foreground mt-0.5">{option.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </RadioGroup>
          </div>
        )}

        {/* Preference questions - only show for 'yes' */}
        {status === 'yes' && selectedOption && event.preferenceQuestions.length > 0 && (
          <div className="space-y-4 animate-fade-in">
            {event.preferenceQuestions.map((question) => (
              <div key={question.id} className="space-y-2">
                <Label className="text-base">
                  {question.question}
                  {question.required && <span className="text-destructive ml-1">*</span>}
                </Label>
                <RadioGroup
                  value={preferences[question.id] || ''}
                  onValueChange={(value) => setPreferences({ ...preferences, [question.id]: value })}
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {question.options.map((option) => (
                      <div
                        key={option}
                        className={cn(
                          "flex items-center space-x-2 rounded-lg border px-3 py-2 cursor-pointer transition-all",
                          preferences[question.id] === option ? "border-accent bg-accent/5" : "hover:border-accent/50"
                        )}
                        onClick={() => setPreferences({ ...preferences, [question.id]: option })}
                      >
                        <RadioGroupItem value={option} id={`${question.id}-${option}`} />
                        <Label htmlFor={`${question.id}-${option}`} className="flex-1 cursor-pointer text-sm">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>
            ))}
          </div>
        )}

        <Button
          onClick={handleSubmit}
          disabled={!isComplete}
          variant="accent"
          size="lg"
          className="w-full"
        >
          {initialStatus ? 'Update RSVP' : 'Submit RSVP'}
        </Button>
      </CardContent>
    </Card>
  );
}
