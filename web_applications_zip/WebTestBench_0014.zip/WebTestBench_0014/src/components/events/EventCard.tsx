import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { CalendarDays, MapPin, Users, Clock, ChevronRight } from 'lucide-react';
import { Event } from '@/types/event';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { categoryOptions } from '@/data/mockEvents';
import { cn } from '@/lib/utils';

interface EventCardProps {
  event: Event;
  compact?: boolean;
}

export function EventCard({ event, compact = false }: EventCardProps) {
  const category = categoryOptions.find(c => c.value === event.category);
  
  const yesCount = event.guests.filter(g => g.rsvpStatus === 'yes').length;
  const maybeCount = event.guests.filter(g => g.rsvpStatus === 'maybe').length;
  const pendingCount = event.guests.filter(g => g.rsvpStatus === 'pending').length;
  
  const isPast = new Date(event.date) < new Date();
  const statusBadge = event.status === 'canceled' 
    ? { label: 'Canceled', variant: 'destructive' as const }
    : event.status === 'completed'
    ? { label: 'Completed', variant: 'muted' as const }
    : isPast
    ? { label: 'Past', variant: 'muted' as const }
    : { label: 'Active', variant: 'success' as const };

  if (compact) {
    return (
      <Link to={`/event/${event.id}`}>
        <Card className="group overflow-hidden transition-all duration-200 hover:shadow-elegant hover:-translate-y-0.5">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-secondary text-2xl">
                {category?.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold truncate group-hover:text-accent transition-colors">
                  {event.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(event.date), 'MMM d, yyyy')}
                </p>
              </div>
              <Badge variant={statusBadge.variant}>{statusBadge.label}</Badge>
              <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-accent transition-colors" />
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  }

  return (
    <Link to={`/event/${event.id}`}>
      <Card className={cn(
        "group overflow-hidden transition-all duration-300 hover:shadow-elegant hover:-translate-y-1",
        event.status === 'canceled' && "opacity-75"
      )}>
        {event.coverImage && (
          <div className="relative h-48 overflow-hidden">
            <img
              src={event.coverImage}
              alt={event.title}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent" />
            <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
              <Badge variant="accent" className="backdrop-blur-sm">
                {category?.icon} {category?.label}
              </Badge>
              <Badge variant={statusBadge.variant} className="backdrop-blur-sm">
                {statusBadge.label}
              </Badge>
            </div>
          </div>
        )}
        
        <CardContent className={cn("p-5", !event.coverImage && "pt-5")}>
          {!event.coverImage && (
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="accent">
                {category?.icon} {category?.label}
              </Badge>
              <Badge variant={statusBadge.variant}>{statusBadge.label}</Badge>
            </div>
          )}
          
          <h3 className="font-display text-xl mb-2 group-hover:text-accent transition-colors line-clamp-2">
            {event.title}
          </h3>
          
          {event.description && (
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {event.description}
            </p>
          )}
          
          <div className="space-y-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CalendarDays className="h-4 w-4 flex-shrink-0" />
              <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 flex-shrink-0" />
              <span>
                {format(new Date(event.date), 'h:mm a')}
                {event.endDate && ` - ${format(new Date(event.endDate), 'h:mm a')}`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{event.location}</span>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-medium text-success">{yesCount} yes</span>
                {maybeCount > 0 && (
                  <>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-warning">{maybeCount} maybe</span>
                  </>
                )}
                {pendingCount > 0 && (
                  <>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-muted-foreground">{pendingCount} pending</span>
                  </>
                )}
              </div>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-accent group-hover:translate-x-0.5 transition-all" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
