import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { MessageCircle, Send } from 'lucide-react';
import { Comment } from '@/types/event';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface CommentSectionProps {
  comments: Comment[];
  onAddComment: (content: string, guestName: string) => void;
  currentGuestName?: string;
}

export function CommentSection({ comments, onAddComment, currentGuestName = 'Guest' }: CommentSectionProps) {
  const [newComment, setNewComment] = useState('');
  const [authorName, setAuthorName] = useState(currentGuestName);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      onAddComment(newComment.trim(), authorName || 'Anonymous');
      setNewComment('');
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-accent" />
          <CardTitle className="text-lg font-display">Discussion</CardTitle>
          <span className="text-sm text-muted-foreground">({comments.length})</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="Your name"
              className="flex-shrink-0 w-32 px-3 py-2 text-sm rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <Textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Share a message or question..."
              className="min-h-[60px] resize-none"
            />
          </div>
          <div className="flex justify-end">
            <Button type="submit" variant="accent" size="sm" disabled={!newComment.trim()}>
              <Send className="h-4 w-4 mr-1" />
              Post
            </Button>
          </div>
        </form>
        
        {comments.length > 0 && (
          <div className="space-y-4 pt-4 border-t border-border">
            {[...comments].reverse().map((comment) => (
              <div key={comment.id} className="flex gap-3 animate-fade-in">
                <Avatar className="h-9 w-9 flex-shrink-0">
                  <AvatarFallback className="bg-secondary text-sm">
                    {getInitials(comment.guestName)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-medium text-sm">{comment.guestName}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-sm text-foreground/90">{comment.content}</p>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {comments.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-4">
            No comments yet. Be the first to share!
          </p>
        )}
      </CardContent>
    </Card>
  );
}
