import { useState } from 'react';
import { Check, Lock, BarChart3 } from 'lucide-react';
import { Poll } from '@/types/event';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface PollCardProps {
  poll: Poll;
  onVote: (optionId: string) => void;
  currentGuestId?: string;
  isOrganizer?: boolean;
  onToggleStatus?: () => void;
}

export function PollCard({ poll, onVote, currentGuestId, isOrganizer, onToggleStatus }: PollCardProps) {
  const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes.length, 0);
  
  const hasVoted = currentGuestId && poll.options.some(opt => opt.votes.includes(currentGuestId));

  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-accent" />
            <CardTitle className="text-lg font-display">{poll.question}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={poll.isOpen ? 'success' : 'muted'}>
              {poll.isOpen ? 'Open' : 'Closed'}
            </Badge>
            {poll.allowMultiple && (
              <Badge variant="outline">Multiple choice</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {poll.options.map((option) => {
          const percentage = totalVotes > 0 ? (option.votes.length / totalVotes) * 100 : 0;
          const isSelected = currentGuestId && option.votes.includes(currentGuestId);
          
          return (
            <button
              key={option.id}
              onClick={() => poll.isOpen && onVote(option.id)}
              disabled={!poll.isOpen}
              className={cn(
                "relative w-full text-left rounded-lg border p-3 transition-all",
                poll.isOpen && "hover:border-accent cursor-pointer",
                isSelected && "border-accent bg-accent/5",
                !poll.isOpen && "cursor-default"
              )}
            >
              <div 
                className="absolute inset-0 rounded-lg bg-accent/10 transition-all"
                style={{ width: `${percentage}%` }}
              />
              <div className="relative flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isSelected && <Check className="h-4 w-4 text-accent" />}
                  <span className={cn("font-medium", isSelected && "text-accent")}>
                    {option.text}
                  </span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {option.votes.length} vote{option.votes.length !== 1 ? 's' : ''} ({percentage.toFixed(0)}%)
                </span>
              </div>
            </button>
          );
        })}
        
        <div className="flex items-center justify-between pt-2 text-sm text-muted-foreground">
          <span>{totalVotes} total vote{totalVotes !== 1 ? 's' : ''}</span>
          {isOrganizer && onToggleStatus && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onToggleStatus}
              className="gap-1"
            >
              <Lock className="h-3 w-3" />
              {poll.isOpen ? 'Close Poll' : 'Reopen Poll'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
