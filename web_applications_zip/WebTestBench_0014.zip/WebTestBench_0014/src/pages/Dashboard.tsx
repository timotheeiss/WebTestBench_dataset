import { useMemo } from 'react';
import { CalendarDays, PartyPopper, TrendingUp, Users } from 'lucide-react';
import { useEvents } from '@/contexts/EventContext';
import { Layout } from '@/components/layout/Layout';
import { EventCard } from '@/components/events/EventCard';
import { Card, CardContent } from '@/components/ui/card';

export default function Dashboard() {
  const { events } = useEvents();
  
  const activeEvents = useMemo(() => {
    return events.filter(e => 
      e.status === 'active' && new Date(e.date) >= new Date()
    ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [events]);

  const stats = useMemo(() => {
    const totalGuests = activeEvents.reduce((sum, e) => sum + e.guests.length, 0);
    const yesResponses = activeEvents.reduce((sum, e) => 
      sum + e.guests.filter(g => g.rsvpStatus === 'yes').length, 0);
    const pendingResponses = activeEvents.reduce((sum, e) => 
      sum + e.guests.filter(g => g.rsvpStatus === 'pending').length, 0);
    
    return {
      totalEvents: activeEvents.length,
      totalGuests,
      yesResponses,
      pendingResponses,
    };
  }, [activeEvents]);

  return (
    <Layout>
      <div className="space-y-8">
        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-2xl bg-primary p-8 text-primary-foreground">
          <div className="relative z-10">
            <h1 className="font-display text-3xl md:text-4xl mb-2">
              Welcome to Gather
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-xl">
              Create beautiful events, manage RSVPs, and bring people together with ease.
            </p>
          </div>
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/20 blur-3xl" />
          <div className="absolute -bottom-10 right-20 h-32 w-32 rounded-full bg-coral/20 blur-3xl" />
        </div>

        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: 'Active Events', value: stats.totalEvents, icon: CalendarDays, color: 'text-accent' },
            { label: 'Total Guests', value: stats.totalGuests, icon: Users, color: 'text-coral' },
            { label: 'Confirmed', value: stats.yesResponses, icon: PartyPopper, color: 'text-success' },
            { label: 'Awaiting Reply', value: stats.pendingResponses, icon: TrendingUp, color: 'text-muted-foreground' },
          ].map(({ label, value, icon: Icon, color }) => (
            <Card key={label} className="animate-fade-in">
              <CardContent className="p-4 flex items-center gap-4">
                <div className={`rounded-lg bg-secondary p-3 ${color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{label}</p>
                  <p className="text-2xl font-semibold">{value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Active Events */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-2xl">Upcoming Events</h2>
            <span className="text-sm text-muted-foreground">{activeEvents.length} events</span>
          </div>
          
          {activeEvents.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {activeEvents.map((event, index) => (
                <div 
                  key={event.id} 
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <EventCard event={event} />
                </div>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <PartyPopper className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="font-display text-xl mb-2">No upcoming events</h3>
                <p className="text-muted-foreground">
                  Create your first event to get started!
                </p>
              </CardContent>
            </Card>
          )}
        </section>
      </div>
    </Layout>
  );
}
