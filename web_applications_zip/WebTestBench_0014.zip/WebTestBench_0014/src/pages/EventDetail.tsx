import { useParams, useNavigate, Link } from 'react-router-dom';
import { format } from 'date-fns';
import { 
  CalendarDays, 
  Clock, 
  MapPin, 
  Shirt, 
  Info, 
  Edit, 
  Trash2,
  ArrowLeft,
  LockOpen,
  Lock,
  AlertCircle
} from 'lucide-react';
import { useEvents } from '@/contexts/EventContext';
import { Layout } from '@/components/layout/Layout';
import { RSVPForm } from '@/components/events/RSVPForm';
import { PollCard } from '@/components/events/PollCard';
import { CommentSection } from '@/components/events/CommentSection';
import { GuestSummary } from '@/components/events/GuestSummary';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { categoryOptions } from '@/data/mockEvents';
import { RSVPStatus } from '@/types/event';
import { useState } from 'react';
import { toast } from 'sonner';

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getEvent, updateEvent, deleteEvent, updateGuestRSVP, votePoll, togglePollStatus, addComment, toggleRsvpStatus } = useEvents();
  
  const event = getEvent(id!);
  
  // Simulate a current guest (in reality this would come from auth)
  const [currentGuestId] = useState('g1');
  const currentGuest = event?.guests.find(g => g.id === currentGuestId);
  
  if (!event) {
    return (
      <Layout>
        <div className="text-center py-12">
          <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h1 className="font-display text-2xl mb-2">Event Not Found</h1>
          <p className="text-muted-foreground mb-4">This event doesn't exist or has been removed.</p>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const category = categoryOptions.find(c => c.value === event.category);
  const isPast = new Date(event.date) < new Date();

  const handleRSVP = (status: RSVPStatus, selectedOption?: string, preferences?: Record<string, string>) => {
    if (currentGuestId) {
      updateGuestRSVP(event.id, currentGuestId, status, selectedOption, preferences);
      toast.success('RSVP updated successfully!');
    }
  };

  const handleVote = (pollId: string, optionId: string) => {
    if (currentGuestId) {
      votePoll(event.id, pollId, optionId, currentGuestId);
    }
  };

  const handleAddComment = (content: string, guestName: string) => {
    addComment(event.id, { guestId: currentGuestId || 'guest', guestName, content });
    toast.success('Comment posted!');
  };

  const handleDelete = () => {
    deleteEvent(event.id);
    toast.success('Event deleted');
    navigate('/');
  };

  const handleToggleRsvp = () => {
    toggleRsvpStatus(event.id);
    toast.success(event.isRsvpOpen ? 'RSVPs are now closed' : 'RSVPs are now open');
  };

  const handleCancelEvent = () => {
    updateEvent(event.id, { status: 'canceled' });
    toast.success('Event canceled');
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to events
        </Link>

        {/* Hero Section */}
        {event.coverImage && (
          <div className="relative h-64 md:h-80 rounded-2xl overflow-hidden">
            <img
              src={event.coverImage}
              alt={event.title}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 text-primary-foreground">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="accent" className="backdrop-blur-sm">
                  {category?.icon} {category?.label}
                </Badge>
                {event.status === 'canceled' && (
                  <Badge variant="destructive">Canceled</Badge>
                )}
                {isPast && event.status !== 'canceled' && (
                  <Badge variant="muted">Past Event</Badge>
                )}
              </div>
              <h1 className="font-display text-3xl md:text-4xl">{event.title}</h1>
            </div>
          </div>
        )}

        {!event.coverImage && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="accent">
                {category?.icon} {category?.label}
              </Badge>
              {event.status === 'canceled' && (
                <Badge variant="destructive">Canceled</Badge>
              )}
            </div>
            <h1 className="font-display text-3xl md:text-4xl">{event.title}</h1>
          </div>
        )}

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Event Details */}
            <Card>
              <CardContent className="p-6 space-y-4">
                {event.description && (
                  <p className="text-foreground/90 leading-relaxed">{event.description}</p>
                )}
                
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="flex items-start gap-3">
                    <CalendarDays className="h-5 w-5 text-accent mt-0.5" />
                    <div>
                      <p className="font-medium">{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(event.date), 'h:mm a')}
                        {event.endDate && ` - ${format(new Date(event.endDate), 'h:mm a')}`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-coral mt-0.5" />
                    <div>
                      <p className="font-medium">{event.location}</p>
                      {event.address && (
                        <p className="text-sm text-muted-foreground">{event.address}</p>
                      )}
                    </div>
                  </div>
                </div>

                {(event.dressCode || event.specialInstructions) && (
                  <>
                    <Separator />
                    <div className="grid gap-4 sm:grid-cols-2">
                      {event.dressCode && (
                        <div className="flex items-start gap-3">
                          <Shirt className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-muted-foreground">Dress Code</p>
                            <p className="text-sm">{event.dressCode}</p>
                          </div>
                        </div>
                      )}
                      
                      {event.specialInstructions && (
                        <div className="flex items-start gap-3">
                          <Info className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-muted-foreground">Special Instructions</p>
                            <p className="text-sm">{event.specialInstructions}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Schedule */}
            {event.schedule && event.schedule.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="font-display flex items-center gap-2">
                    <Clock className="h-5 w-5 text-accent" />
                    Schedule
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative space-y-4">
                    {event.schedule.map((item, index) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className="w-3 h-3 rounded-full bg-accent" />
                          {index < event.schedule!.length - 1 && (
                            <div className="w-0.5 flex-1 bg-border mt-2" />
                          )}
                        </div>
                        <div className="flex-1 pb-4">
                          <p className="text-sm font-medium text-accent">{item.time}</p>
                          <p className="font-semibold">{item.title}</p>
                          {item.description && (
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Polls */}
            {event.polls.length > 0 && (
              <div className="space-y-4">
                <h2 className="font-display text-xl">Polls</h2>
                {event.polls.map(poll => (
                  <PollCard
                    key={poll.id}
                    poll={poll}
                    onVote={(optionId) => handleVote(poll.id, optionId)}
                    currentGuestId={currentGuestId}
                    isOrganizer={true}
                    onToggleStatus={() => togglePollStatus(event.id, poll.id)}
                  />
                ))}
              </div>
            )}

            {/* Comments */}
            <CommentSection
              comments={event.comments}
              onAddComment={handleAddComment}
              currentGuestName={currentGuest?.name}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Organizer Actions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-semibold">Organizer Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link to={`/event/${event.id}/edit`} className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Event
                  </Button>
                </Link>
                
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={handleToggleRsvp}
                >
                  {event.isRsvpOpen ? (
                    <>
                      <Lock className="h-4 w-4 mr-2" />
                      Close RSVPs
                    </>
                  ) : (
                    <>
                      <LockOpen className="h-4 w-4 mr-2" />
                      Open RSVPs
                    </>
                  )}
                </Button>

                {event.status === 'active' && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive">
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Cancel Event
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Cancel this event?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will mark the event as canceled. Guests will be notified and the event will move to the archive.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Keep Event</AlertDialogCancel>
                        <AlertDialogAction onClick={handleCancelEvent}>Cancel Event</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Event
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete this event?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This action cannot be undone. All event data, RSVPs, and comments will be permanently deleted.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardContent>
            </Card>

            {/* RSVP Form */}
            {event.status === 'active' && !isPast && (
              <RSVPForm
                event={event}
                onSubmit={handleRSVP}
                initialStatus={currentGuest?.rsvpStatus}
                initialOption={currentGuest?.selectedOption}
                initialPreferences={currentGuest?.preferences}
              />
            )}

            {/* Guest Summary */}
            <GuestSummary event={event} />
          </div>
        </div>
      </div>
    </Layout>
  );
}
