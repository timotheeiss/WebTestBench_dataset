import { useState } from 'react';
import { useNavigate, Link, useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  CalendarDays,
  MapPin,
  Clock,
  ListPlus,
  HelpCircle
} from 'lucide-react';
import { useEvents } from '@/contexts/EventContext';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { categoryOptions } from '@/data/mockEvents';
import { Event, EventCategory, InvitationOption, PreferenceQuestion, EventScheduleItem, Poll, PollOption } from '@/types/event';
import { toast } from 'sonner';

interface FormData {
  title: string;
  description: string;
  date: string;
  time: string;
  endDate: string;
  endTime: string;
  location: string;
  address: string;
  category: EventCategory;
  coverImage: string;
  dressCode: string;
  specialInstructions: string;
  schedule: EventScheduleItem[];
  invitationOptions: InvitationOption[];
  preferenceQuestions: PreferenceQuestion[];
  polls: Omit<Poll, 'id'>[];
  isRsvpOpen: boolean;
  rsvpDeadline: string;
}

export default function CreateEvent() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { createEvent, getEvent, updateEvent } = useEvents();
  
  const existingEvent = id ? getEvent(id) : null;
  const isEditing = !!existingEvent;

  const [formData, setFormData] = useState<FormData>(() => {
    if (existingEvent) {
      return {
        title: existingEvent.title,
        description: existingEvent.description || '',
        date: format(new Date(existingEvent.date), 'yyyy-MM-dd'),
        time: format(new Date(existingEvent.date), 'HH:mm'),
        endDate: existingEvent.endDate ? format(new Date(existingEvent.endDate), 'yyyy-MM-dd') : '',
        endTime: existingEvent.endDate ? format(new Date(existingEvent.endDate), 'HH:mm') : '',
        location: existingEvent.location,
        address: existingEvent.address || '',
        category: existingEvent.category,
        coverImage: existingEvent.coverImage || '',
        dressCode: existingEvent.dressCode || '',
        specialInstructions: existingEvent.specialInstructions || '',
        schedule: existingEvent.schedule || [],
        invitationOptions: existingEvent.invitationOptions,
        preferenceQuestions: existingEvent.preferenceQuestions,
        polls: existingEvent.polls.map(p => ({ ...p })),
        isRsvpOpen: existingEvent.isRsvpOpen,
        rsvpDeadline: existingEvent.rsvpDeadline ? format(new Date(existingEvent.rsvpDeadline), 'yyyy-MM-dd') : '',
      };
    }
    return {
      title: '',
      description: '',
      date: '',
      time: '',
      endDate: '',
      endTime: '',
      location: '',
      address: '',
      category: 'social',
      coverImage: '',
      dressCode: '',
      specialInstructions: '',
      schedule: [],
      invitationOptions: [{ id: `opt-${Date.now()}`, name: 'Full Event', description: '' }],
      preferenceQuestions: [],
      polls: [],
      isRsvpOpen: true,
      rsvpDeadline: '',
    };
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.date || !formData.time || !formData.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const dateTime = new Date(`${formData.date}T${formData.time}`);
    const endDateTime = formData.endDate && formData.endTime 
      ? new Date(`${formData.endDate}T${formData.endTime}`)
      : undefined;

    const eventData = {
      title: formData.title,
      description: formData.description || undefined,
      date: dateTime,
      endDate: endDateTime,
      location: formData.location,
      address: formData.address || undefined,
      category: formData.category,
      status: 'active' as const,
      coverImage: formData.coverImage || undefined,
      dressCode: formData.dressCode || undefined,
      specialInstructions: formData.specialInstructions || undefined,
      schedule: formData.schedule.length > 0 ? formData.schedule : undefined,
      invitationOptions: formData.invitationOptions.filter(opt => opt.name.trim()),
      preferenceQuestions: formData.preferenceQuestions.filter(q => q.question.trim() && q.options.some(o => o.trim())),
      guests: existingEvent?.guests || [],
      isRsvpOpen: formData.isRsvpOpen,
      rsvpDeadline: formData.rsvpDeadline ? new Date(formData.rsvpDeadline) : undefined,
      polls: formData.polls.map(p => ({ 
        ...p, 
        id: `poll-${Date.now()}-${Math.random()}`,
        options: p.options.map(o => ({ ...o, id: o.id || `opt-${Date.now()}-${Math.random()}` }))
      })),
      comments: existingEvent?.comments || [],
    };

    if (isEditing) {
      updateEvent(id!, eventData);
      toast.success('Event updated successfully!');
      navigate(`/event/${id}`);
    } else {
      const newEvent = createEvent(eventData);
      toast.success('Event created successfully!');
      navigate(`/event/${newEvent.id}`);
    }
  };

  const addScheduleItem = () => {
    setFormData({
      ...formData,
      schedule: [
        ...formData.schedule,
        { id: `sched-${Date.now()}`, time: '', title: '', description: '' }
      ]
    });
  };

  const updateScheduleItem = (index: number, field: string, value: string) => {
    const updated = [...formData.schedule];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, schedule: updated });
  };

  const removeScheduleItem = (index: number) => {
    setFormData({
      ...formData,
      schedule: formData.schedule.filter((_, i) => i !== index)
    });
  };

  const addInvitationOption = () => {
    setFormData({
      ...formData,
      invitationOptions: [
        ...formData.invitationOptions,
        { id: `opt-${Date.now()}`, name: '', description: '' }
      ]
    });
  };

  const updateInvitationOption = (index: number, field: string, value: string | number) => {
    const updated = [...formData.invitationOptions];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, invitationOptions: updated });
  };

  const removeInvitationOption = (index: number) => {
    if (formData.invitationOptions.length > 1) {
      setFormData({
        ...formData,
        invitationOptions: formData.invitationOptions.filter((_, i) => i !== index)
      });
    }
  };

  const addPreferenceQuestion = () => {
    setFormData({
      ...formData,
      preferenceQuestions: [
        ...formData.preferenceQuestions,
        { id: `q-${Date.now()}`, question: '', options: ['', ''], required: false }
      ]
    });
  };

  const updatePreferenceQuestion = (index: number, field: string, value: string | boolean | string[]) => {
    const updated = [...formData.preferenceQuestions];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, preferenceQuestions: updated });
  };

  const removePreferenceQuestion = (index: number) => {
    setFormData({
      ...formData,
      preferenceQuestions: formData.preferenceQuestions.filter((_, i) => i !== index)
    });
  };

  const addPoll = () => {
    setFormData({
      ...formData,
      polls: [
        ...formData.polls,
        { 
          question: '', 
          options: [
            { id: `po-${Date.now()}-1`, text: '', votes: [] },
            { id: `po-${Date.now()}-2`, text: '', votes: [] }
          ], 
          isOpen: true, 
          allowMultiple: false 
        }
      ]
    });
  };

  const updatePoll = (index: number, field: string, value: string | boolean | PollOption[]) => {
    const updated = [...formData.polls];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, polls: updated });
  };

  const removePoll = (index: number) => {
    setFormData({
      ...formData,
      polls: formData.polls.filter((_, i) => i !== index)
    });
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-6">
        <Link to={isEditing ? `/event/${id}` : '/'} className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          {isEditing ? 'Back to event' : 'Back to dashboard'}
        </Link>

        <div>
          <h1 className="font-display text-3xl mb-2">
            {isEditing ? 'Edit Event' : 'Create New Event'}
          </h1>
          <p className="text-muted-foreground">
            {isEditing ? 'Update your event details below.' : 'Fill in the details to create your event.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-accent" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Event Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Sarah's Birthday Party"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Tell your guests what to expect..."
                  rows={3}
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value as EventCategory })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOptions.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.icon} {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coverImage">Cover Image URL</Label>
                  <Input
                    id="coverImage"
                    value={formData.coverImage}
                    onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                    placeholder="https://..."
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Date & Time */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <Clock className="h-5 w-5 text-accent" />
                Date & Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="date">Start Date *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Start Time *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="rsvpDeadline">RSVP Deadline</Label>
                <Input
                  id="rsvpDeadline"
                  type="date"
                  value={formData.rsvpDeadline}
                  onChange={(e) => setFormData({ ...formData, rsvpDeadline: e.target.value })}
                />
              </div>

              <div className="flex items-center gap-3">
                <Switch
                  id="isRsvpOpen"
                  checked={formData.isRsvpOpen}
                  onCheckedChange={(checked) => setFormData({ ...formData, isRsvpOpen: checked })}
                />
                <Label htmlFor="isRsvpOpen">RSVPs are open</Label>
              </div>
            </CardContent>
          </Card>

          {/* Location */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <MapPin className="h-5 w-5 text-coral" />
                Location
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="location">Venue Name *</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g., The Grand Ballroom"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Full Address</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="123 Main St, City, State ZIP"
                />
              </div>
            </CardContent>
          </Card>

          {/* Additional Details */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Additional Details</CardTitle>
              <CardDescription>Optional information for your guests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dressCode">Dress Code</Label>
                <Input
                  id="dressCode"
                  value={formData.dressCode}
                  onChange={(e) => setFormData({ ...formData, dressCode: e.target.value })}
                  placeholder="e.g., Smart casual"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="specialInstructions">Special Instructions</Label>
                <Textarea
                  id="specialInstructions"
                  value={formData.specialInstructions}
                  onChange={(e) => setFormData({ ...formData, specialInstructions: e.target.value })}
                  placeholder="Parking info, accessibility notes, etc."
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          {/* Schedule */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="font-display flex items-center gap-2">
                  <ListPlus className="h-5 w-5 text-accent" />
                  Schedule
                </CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addScheduleItem}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Item
                </Button>
              </div>
              <CardDescription>Break down your event into time slots</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.schedule.map((item, index) => (
                <div key={item.id} className="flex gap-3 items-start p-3 bg-secondary/50 rounded-lg">
                  <div className="grid gap-2 flex-1 sm:grid-cols-4">
                    <Input
                      placeholder="Time"
                      value={item.time}
                      onChange={(e) => updateScheduleItem(index, 'time', e.target.value)}
                    />
                    <Input
                      placeholder="Title"
                      value={item.title}
                      onChange={(e) => updateScheduleItem(index, 'title', e.target.value)}
                      className="sm:col-span-2"
                    />
                    <Input
                      placeholder="Description"
                      value={item.description || ''}
                      onChange={(e) => updateScheduleItem(index, 'description', e.target.value)}
                    />
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeScheduleItem(index)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              {formData.schedule.length === 0 && (
                <p className="text-center text-muted-foreground py-4">
                  No schedule items yet. Add one to help guests know what to expect.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Invitation Options */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="font-display">Invitation Options</CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addInvitationOption}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Option
                </Button>
              </div>
              <CardDescription>Different ways guests can attend (e.g., "Dinner only", "Full evening")</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.invitationOptions.map((option, index) => (
                <div key={option.id} className="flex gap-3 items-start p-3 bg-secondary/50 rounded-lg">
                  <div className="grid gap-2 flex-1 sm:grid-cols-2">
                    <Input
                      placeholder="Option name"
                      value={option.name}
                      onChange={(e) => updateInvitationOption(index, 'name', e.target.value)}
                    />
                    <Input
                      placeholder="Description (optional)"
                      value={option.description || ''}
                      onChange={(e) => updateInvitationOption(index, 'description', e.target.value)}
                    />
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeInvitationOption(index)}
                    className="text-destructive hover:text-destructive"
                    disabled={formData.invitationOptions.length === 1}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Preference Questions */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="font-display flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-accent" />
                  Preference Questions
                </CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addPreferenceQuestion}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Question
                </Button>
              </div>
              <CardDescription>Questions guests answer when RSVPing "Yes"</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.preferenceQuestions.map((question, qIndex) => (
                <div key={question.id} className="p-4 bg-secondary/50 rounded-lg space-y-3">
                  <div className="flex gap-3 items-start">
                    <div className="flex-1 space-y-3">
                      <Input
                        placeholder="Question (e.g., Meal preference)"
                        value={question.question}
                        onChange={(e) => updatePreferenceQuestion(qIndex, 'question', e.target.value)}
                      />
                      <div className="space-y-2">
                        <Label className="text-sm">Options</Label>
                        {question.options.map((opt, oIndex) => (
                          <div key={oIndex} className="flex gap-2">
                            <Input
                              placeholder={`Option ${oIndex + 1}`}
                              value={opt}
                              onChange={(e) => {
                                const newOptions = [...question.options];
                                newOptions[oIndex] = e.target.value;
                                updatePreferenceQuestion(qIndex, 'options', newOptions);
                              }}
                            />
                            {question.options.length > 2 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  const newOptions = question.options.filter((_, i) => i !== oIndex);
                                  updatePreferenceQuestion(qIndex, 'options', newOptions);
                                }}
                                className="text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        ))}
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            updatePreferenceQuestion(qIndex, 'options', [...question.options, '']);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add option
                        </Button>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={question.required}
                          onCheckedChange={(checked) => updatePreferenceQuestion(qIndex, 'required', checked)}
                        />
                        <Label className="text-sm">Required</Label>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removePreferenceQuestion(qIndex)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {formData.preferenceQuestions.length === 0 && (
                <p className="text-center text-muted-foreground py-4">
                  No preference questions yet. Add one to collect info from attending guests.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Polls */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="font-display">Polls</CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addPoll}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Poll
                </Button>
              </div>
              <CardDescription>Let guests vote on venue, activity, or other choices</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.polls.map((poll, pIndex) => (
                <div key={pIndex} className="p-4 bg-secondary/50 rounded-lg space-y-3">
                  <div className="flex gap-3 items-start">
                    <div className="flex-1 space-y-3">
                      <Input
                        placeholder="Poll question"
                        value={poll.question}
                        onChange={(e) => updatePoll(pIndex, 'question', e.target.value)}
                      />
                      <div className="space-y-2">
                        <Label className="text-sm">Options</Label>
                        {poll.options.map((opt, oIndex) => (
                          <div key={opt.id} className="flex gap-2">
                            <Input
                              placeholder={`Option ${oIndex + 1}`}
                              value={opt.text}
                              onChange={(e) => {
                                const newOptions = [...poll.options];
                                newOptions[oIndex] = { ...newOptions[oIndex], text: e.target.value };
                                updatePoll(pIndex, 'options', newOptions);
                              }}
                            />
                            {poll.options.length > 2 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  const newOptions = poll.options.filter((_, i) => i !== oIndex);
                                  updatePoll(pIndex, 'options', newOptions);
                                }}
                                className="text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        ))}
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            updatePoll(pIndex, 'options', [
                              ...poll.options,
                              { id: `po-${Date.now()}`, text: '', votes: [] }
                            ]);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add option
                        </Button>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={poll.allowMultiple}
                            onCheckedChange={(checked) => updatePoll(pIndex, 'allowMultiple', checked)}
                          />
                          <Label className="text-sm">Allow multiple selections</Label>
                        </div>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removePoll(pIndex)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {formData.polls.length === 0 && (
                <p className="text-center text-muted-foreground py-4">
                  No polls yet. Add one to let guests vote on options.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex gap-4 justify-end">
            <Link to={isEditing ? `/event/${id}` : '/'}>
              <Button type="button" variant="outline">Cancel</Button>
            </Link>
            <Button type="submit" variant="accent" size="lg">
              {isEditing ? 'Save Changes' : 'Create Event'}
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}
