import { useMemo } from 'react';
import { Archive as ArchiveIcon, CalendarX, CheckCircle } from 'lucide-react';
import { useEvents } from '@/contexts/EventContext';
import { Layout } from '@/components/layout/Layout';
import { EventCard } from '@/components/events/EventCard';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Archive() {
  const { events } = useEvents();
  
  const archivedEvents = useMemo(() => {
    const now = new Date();
    return events.filter(e => 
      e.status === 'canceled' || 
      e.status === 'completed' ||
      new Date(e.date) < now
    ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [events]);

  const pastEvents = archivedEvents.filter(e => e.status !== 'canceled');
  const canceledEvents = archivedEvents.filter(e => e.status === 'canceled');

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-3xl mb-2">Archive</h1>
          <p className="text-muted-foreground">
            View past and canceled events with their final RSVP and poll results.
          </p>
        </div>

        <Tabs defaultValue="past" className="w-full">
          <TabsList>
            <TabsTrigger value="past" className="gap-2">
              <CheckCircle className="h-4 w-4" />
              Past Events ({pastEvents.length})
            </TabsTrigger>
            <TabsTrigger value="canceled" className="gap-2">
              <CalendarX className="h-4 w-4" />
              Canceled ({canceledEvents.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="past" className="mt-6">
            {pastEvents.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {pastEvents.map((event, index) => (
                  <div 
                    key={event.id} 
                    className="animate-fade-in"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <EventCard event={event} />
                  </div>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <ArchiveIcon className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <h3 className="font-display text-xl mb-2">No past events</h3>
                  <p className="text-muted-foreground">
                    Completed events will appear here.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="canceled" className="mt-6">
            {canceledEvents.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {canceledEvents.map((event, index) => (
                  <div 
                    key={event.id} 
                    className="animate-fade-in"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <EventCard event={event} />
                  </div>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <CalendarX className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <h3 className="font-display text-xl mb-2">No canceled events</h3>
                  <p className="text-muted-foreground">
                    Canceled events will be stored here for reference.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
