import { Event, EventCategory } from '@/types/event';

// Helper to create dates relative to now
const futureDate = (daysFromNow: number, hour: number = 15) => {
  const date = new Date();
  date.setDate(date.getDate() + daysFromNow);
  date.setHours(hour, 0, 0, 0);
  return date;
};

const pastDate = (daysAgo: number, hour: number = 15) => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  date.setHours(hour, 0, 0, 0);
  return date;
};

export const mockEvents: Event[] = [
  {
    id: '1',
    title: "Sarah & James's Garden Wedding",
    description: "Join us for an intimate garden celebration as we begin our journey together. We can't wait to share this special day with our closest friends and family.",
    date: futureDate(30, 15),
    endDate: futureDate(30, 23),
    location: 'Rosewood Gardens',
    address: '425 Magnolia Lane, Napa Valley, CA 94558',
    category: 'wedding',
    status: 'active',
    coverImage: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1200',
    schedule: [
      { id: 's1', time: '3:00 PM', title: 'Guest Arrival', description: 'Welcome drinks and canapes' },
      { id: 's2', time: '4:00 PM', title: 'Ceremony', description: 'Garden ceremony under the oak tree' },
      { id: 's3', time: '5:00 PM', title: 'Cocktail Hour', description: 'Garden terrace with live music' },
      { id: 's4', time: '6:30 PM', title: 'Reception Dinner', description: 'Three-course dinner in the pavilion' },
      { id: 's5', time: '8:30 PM', title: 'Dancing & Celebration', description: 'Live band and open bar' },
    ],
    dressCode: 'Garden formal – light colors encouraged, comfortable shoes recommended for grass',
    specialInstructions: 'Please park in the designated lot. A shuttle will run from the parking area. Ceremony will be outdoors – sunscreen and shade provided.',
    invitationOptions: [
      { id: 'opt1', name: 'Full Celebration', description: 'Ceremony through reception', price: 0 },
      { id: 'opt2', name: 'Reception Only', description: 'Join us from 5:00 PM', price: 0 },
      { id: 'opt3', name: 'Ceremony Only', description: 'Ceremony and cocktail hour', price: 0 },
    ],
    preferenceQuestions: [
      { id: 'q1', question: 'Meal preference', options: ['Herb-crusted salmon', 'Filet mignon', 'Wild mushroom risotto (V)'], required: true },
      { id: 'q2', question: 'Any dietary restrictions?', options: ['None', 'Gluten-free', 'Dairy-free', 'Nut allergy'], required: false },
      { id: 'q3', question: 'Will you be bringing a plus one?', options: ['Yes', 'No'], required: true },
    ],
    guests: [
      { id: 'g1', name: 'Michael Chen', email: 'michael@email.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Filet mignon', q2: 'None', q3: 'Yes' }, rsvpDate: pastDate(5) },
      { id: 'g2', name: 'Emily Watson', email: 'emily@email.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Wild mushroom risotto (V)', q2: 'Gluten-free', q3: 'No' }, rsvpDate: pastDate(3) },
      { id: 'g3', name: 'David Park', email: 'david@email.com', rsvpStatus: 'maybe', selectedOption: 'opt2', preferences: { q1: 'Herb-crusted salmon', q2: 'None', q3: 'Yes' }, rsvpDate: pastDate(1) },
      { id: 'g4', name: 'Lisa Thompson', email: 'lisa@email.com', rsvpStatus: 'no', preferences: {}, rsvpDate: pastDate(7) },
      { id: 'g5', name: 'Robert Kim', email: 'robert@email.com', rsvpStatus: 'pending', preferences: {} },
    ],
    rsvpDeadline: futureDate(25),
    isRsvpOpen: true,
    polls: [
      {
        id: 'poll1',
        question: 'Which song should we have for our first dance?',
        options: [
          { id: 'p1o1', text: '"At Last" - Etta James', votes: ['g1', 'g3'] },
          { id: 'p1o2', text: '"Can\'t Help Falling in Love" - Elvis', votes: ['g2'] },
          { id: 'p1o3', text: '"Perfect" - Ed Sheeran', votes: [] },
        ],
        isOpen: true,
        allowMultiple: false,
      },
    ],
    comments: [
      { id: 'c1', guestId: 'g1', guestName: 'Michael Chen', content: 'So excited for the big day! Will there be vegetarian options for my plus one?', timestamp: pastDate(5) },
      { id: 'c2', guestId: 'g2', guestName: 'Emily Watson', content: 'The venue looks absolutely stunning! Can\'t wait! 🌸', timestamp: pastDate(3) },
    ],
    createdAt: pastDate(60),
    updatedAt: pastDate(1),
  },
  {
    id: '2',
    title: "Marcus's 40th Birthday Bash",
    description: "Help us celebrate four decades of Marcus! Join us for an evening of great food, drinks, and memories at an exclusive rooftop venue.",
    date: futureDate(14, 19),
    endDate: futureDate(15, 1),
    location: 'The Skyline Lounge',
    address: '888 Downtown Plaza, Floor 45, Los Angeles, CA 90071',
    category: 'birthday',
    status: 'active',
    coverImage: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=1200',
    schedule: [
      { id: 's1', time: '7:00 PM', title: 'Arrivals & Cocktails', description: 'Signature cocktails and city views' },
      { id: 's2', time: '8:00 PM', title: 'Dinner Service', description: 'Chef\'s tasting menu' },
      { id: 's3', time: '9:30 PM', title: 'Toasts & Cake', description: 'Speeches and birthday celebration' },
      { id: 's4', time: '10:00 PM', title: 'Dancing', description: 'DJ and open bar until late' },
    ],
    dressCode: 'Upscale casual – think stylish and comfortable',
    specialInstructions: 'Street parking limited. We recommend rideshare or the parking garage on 9th St. Elevator access via main lobby.',
    invitationOptions: [
      { id: 'opt1', name: 'Full Evening', description: 'Dinner, drinks & dancing', price: 75 },
      { id: 'opt2', name: 'Drinks & Dancing', description: 'Join from 10:00 PM', price: 35 },
    ],
    preferenceQuestions: [
      { id: 'q1', question: 'Dinner selection', options: ['Prime ribeye', 'Pan-seared halibut', 'Truffle pasta (V)'], required: true },
      { id: 'q2', question: 'Preferred spirit', options: ['Whiskey', 'Vodka', 'Tequila', 'Non-alcoholic'], required: false },
    ],
    guests: [
      { id: 'g1', name: 'Amanda Foster', email: 'amanda@email.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Pan-seared halibut', q2: 'Vodka' }, rsvpDate: pastDate(2) },
      { id: 'g2', name: 'Chris Johnson', email: 'chris@email.com', rsvpStatus: 'yes', selectedOption: 'opt2', preferences: { q2: 'Whiskey' }, rsvpDate: pastDate(1) },
      { id: 'g3', name: 'Nina Patel', email: 'nina@email.com', rsvpStatus: 'pending', preferences: {} },
    ],
    rsvpDeadline: futureDate(10),
    isRsvpOpen: true,
    polls: [
      {
        id: 'poll1',
        question: 'What decade\'s music should dominate the dance floor?',
        options: [
          { id: 'p1o1', text: '80s Classics', votes: ['g1'] },
          { id: 'p1o2', text: '90s Hits', votes: [] },
          { id: 'p1o3', text: '2000s Bangers', votes: ['g2'] },
          { id: 'p1o4', text: 'Mix it up!', votes: [] },
        ],
        isOpen: true,
        allowMultiple: false,
      },
    ],
    comments: [
      { id: 'c1', guestId: 'g1', guestName: 'Amanda Foster', content: 'Happy early birthday Marcus! Is there parking validation?', timestamp: pastDate(2) },
    ],
    createdAt: pastDate(30),
    updatedAt: pastDate(1),
  },
  {
    id: '3',
    title: 'Annual Company Holiday Party',
    description: 'Celebrate the year\'s achievements with your colleagues! Join us for festive fun, awards, and entertainment.',
    date: pastDate(30, 18),
    endDate: pastDate(30, 22),
    location: 'Grand Ballroom, Marriott Downtown',
    address: '550 Convention Way, San Francisco, CA 94102',
    category: 'corporate',
    status: 'completed',
    coverImage: 'https://images.unsplash.com/photo-1482575832494-771f74bf6857?w=1200',
    schedule: [
      { id: 's1', time: '6:00 PM', title: 'Welcome Reception', description: 'Champagne and appetizers' },
      { id: 's2', time: '7:00 PM', title: 'Dinner & Awards', description: 'Annual recognition ceremony' },
      { id: 's3', time: '8:30 PM', title: 'Entertainment', description: 'Live band performance' },
      { id: 's4', time: '9:30 PM', title: 'Raffle & Closing', description: 'Prize drawings' },
    ],
    dressCode: 'Festive cocktail attire',
    invitationOptions: [
      { id: 'opt1', name: 'Full Event', description: 'Dinner and entertainment' },
    ],
    preferenceQuestions: [
      { id: 'q1', question: 'Entrée choice', options: ['Chicken', 'Salmon', 'Vegetarian'], required: true },
    ],
    guests: [
      { id: 'g1', name: 'Team Member 1', email: 't1@company.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Chicken' }, rsvpDate: pastDate(35) },
      { id: 'g2', name: 'Team Member 2', email: 't2@company.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Salmon' }, rsvpDate: pastDate(34) },
      { id: 'g3', name: 'Team Member 3', email: 't3@company.com', rsvpStatus: 'no', preferences: {}, rsvpDate: pastDate(33) },
    ],
    isRsvpOpen: false,
    polls: [],
    comments: [],
    createdAt: pastDate(60),
    updatedAt: pastDate(30),
  },
  {
    id: '4',
    title: 'Summer Backyard BBQ',
    description: 'Kick off summer with friends, food, and fun! Casual afternoon hangout with games and grilled goodness.',
    date: futureDate(45, 14),
    endDate: futureDate(45, 20),
    location: 'The Johnson Residence',
    address: '1234 Oak Street, Pasadena, CA 91101',
    category: 'social',
    status: 'active',
    coverImage: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=1200',
    dressCode: 'Casual – shorts, sundresses, sunscreen!',
    specialInstructions: 'Pool available – bring swimwear if interested. We have lawn games set up. BYOB welcome!',
    invitationOptions: [
      { id: 'opt1', name: 'All Day', description: 'Join whenever, stay as long as you like' },
    ],
    preferenceQuestions: [
      { id: 'q1', question: 'Dietary preference', options: ['Carnivore', 'Vegetarian', 'Vegan', 'Pescatarian'], required: true },
      { id: 'q2', question: 'Bringing anything?', options: ['Side dish', 'Dessert', 'Drinks', 'Just myself!'], required: false },
    ],
    guests: [
      { id: 'g1', name: 'Jake Williams', email: 'jake@email.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Carnivore', q2: 'Drinks' }, rsvpDate: pastDate(2) },
      { id: 'g2', name: 'Sarah Miller', email: 'sarah.m@email.com', rsvpStatus: 'yes', selectedOption: 'opt1', preferences: { q1: 'Vegetarian', q2: 'Side dish' }, rsvpDate: pastDate(1) },
    ],
    rsvpDeadline: futureDate(40),
    isRsvpOpen: true,
    polls: [
      {
        id: 'poll1',
        question: 'What games should we set up?',
        options: [
          { id: 'p1o1', text: 'Cornhole', votes: ['g1', 'g2'] },
          { id: 'p1o2', text: 'Volleyball', votes: ['g1'] },
          { id: 'p1o3', text: 'Giant Jenga', votes: ['g2'] },
          { id: 'p1o4', text: 'Croquet', votes: [] },
        ],
        isOpen: true,
        allowMultiple: true,
      },
    ],
    comments: [
      { id: 'c1', guestId: 'g1', guestName: 'Jake Williams', content: 'Can I bring my dog? He\'s very friendly!', timestamp: pastDate(2) },
    ],
    createdAt: pastDate(14),
    updatedAt: pastDate(1),
  },
];

export const categoryOptions: { value: EventCategory; label: string; icon: string }[] = [
  { value: 'birthday', label: 'Birthday', icon: '🎂' },
  { value: 'wedding', label: 'Wedding', icon: '💒' },
  { value: 'corporate', label: 'Corporate', icon: '💼' },
  { value: 'social', label: 'Social', icon: '🎉' },
  { value: 'holiday', label: 'Holiday', icon: '🎄' },
  { value: 'celebration', label: 'Celebration', icon: '✨' },
  { value: 'other', label: 'Other', icon: '📅' },
];
