export type RSVPStatus = 'yes' | 'no' | 'maybe' | 'pending';

export type EventCategory = 
  | 'birthday' 
  | 'wedding' 
  | 'corporate' 
  | 'social' 
  | 'holiday' 
  | 'celebration' 
  | 'other';

export type EventStatus = 'active' | 'canceled' | 'completed';

export interface InvitationOption {
  id: string;
  name: string;
  description?: string;
  price?: number;
}

export interface PreferenceQuestion {
  id: string;
  question: string;
  options: string[];
  required: boolean;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // guest IDs who voted for this option
}

export interface Poll {
  id: string;
  question: string;
  options: PollOption[];
  isOpen: boolean;
  allowMultiple: boolean;
}

export interface Comment {
  id: string;
  guestId: string;
  guestName: string;
  content: string;
  timestamp: Date;
}

export interface GuestPreferences {
  [questionId: string]: string;
}

export interface Guest {
  id: string;
  name: string;
  email: string;
  rsvpStatus: RSVPStatus;
  selectedOption?: string; // invitation option ID
  preferences: GuestPreferences;
  rsvpDate?: Date;
}

export interface EventScheduleItem {
  id: string;
  time: string;
  title: string;
  description?: string;
}

export interface Event {
  id: string;
  title: string;
  description?: string;
  date: Date;
  endDate?: Date;
  location: string;
  address?: string;
  category: EventCategory;
  status: EventStatus;
  coverImage?: string;
  
  // Optional sections
  schedule?: EventScheduleItem[];
  dressCode?: string;
  specialInstructions?: string;
  
  // Invitation configuration
  invitationOptions: InvitationOption[];
  preferenceQuestions: PreferenceQuestion[];
  
  // Guest management
  guests: Guest[];
  rsvpDeadline?: Date;
  isRsvpOpen: boolean;
  
  // Interactive features
  polls: Poll[];
  comments: Comment[];
  
  // Metadata
  createdAt: Date;
  updatedAt: Date;
}
