import React, { createContext, useContext, useState, useCallback } from 'react';
import { Event, Guest, RSVPStatus, Poll, Comment, EventStatus } from '@/types/event';
import { mockEvents } from '@/data/mockEvents';

interface EventContextType {
  events: Event[];
  getEvent: (id: string) => Event | undefined;
  createEvent: (event: Omit<Event, 'id' | 'createdAt' | 'updatedAt'>) => Event;
  updateEvent: (id: string, updates: Partial<Event>) => void;
  deleteEvent: (id: string) => void;
  updateEventStatus: (id: string, status: EventStatus) => void;
  
  // Guest management
  addGuest: (eventId: string, guest: Omit<Guest, 'id'>) => void;
  updateGuestRSVP: (eventId: string, guestId: string, status: RSVPStatus, selectedOption?: string, preferences?: Record<string, string>) => void;
  
  // Poll management
  addPoll: (eventId: string, poll: Omit<Poll, 'id'>) => void;
  votePoll: (eventId: string, pollId: string, optionId: string, guestId: string) => void;
  togglePollStatus: (eventId: string, pollId: string) => void;
  
  // Comment management
  addComment: (eventId: string, comment: Omit<Comment, 'id' | 'timestamp'>) => void;
  
  // RSVP management
  toggleRsvpStatus: (eventId: string) => void;
}

const EventContext = createContext<EventContextType | undefined>(undefined);

export function EventProvider({ children }: { children: React.ReactNode }) {
  const [events, setEvents] = useState<Event[]>(mockEvents);

  const getEvent = useCallback((id: string) => {
    return events.find(e => e.id === id);
  }, [events]);

  const createEvent = useCallback((eventData: Omit<Event, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newEvent: Event = {
      ...eventData,
      id: `event-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setEvents(prev => [...prev, newEvent]);
    return newEvent;
  }, []);

  const updateEvent = useCallback((id: string, updates: Partial<Event>) => {
    setEvents(prev => prev.map(event => 
      event.id === id 
        ? { ...event, ...updates, updatedAt: new Date() }
        : event
    ));
  }, []);

  const deleteEvent = useCallback((id: string) => {
    setEvents(prev => prev.filter(event => event.id !== id));
  }, []);

  const updateEventStatus = useCallback((id: string, status: EventStatus) => {
    updateEvent(id, { status });
  }, [updateEvent]);

  const addGuest = useCallback((eventId: string, guest: Omit<Guest, 'id'>) => {
    const newGuest: Guest = {
      ...guest,
      id: `guest-${Date.now()}`,
    };
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? { ...event, guests: [...event.guests, newGuest], updatedAt: new Date() }
        : event
    ));
  }, []);

  const updateGuestRSVP = useCallback((
    eventId: string, 
    guestId: string, 
    status: RSVPStatus, 
    selectedOption?: string, 
    preferences?: Record<string, string>
  ) => {
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? {
            ...event,
            guests: event.guests.map(guest => 
              guest.id === guestId 
                ? { 
                    ...guest, 
                    rsvpStatus: status, 
                    selectedOption: selectedOption || guest.selectedOption,
                    preferences: preferences || guest.preferences,
                    rsvpDate: new Date()
                  }
                : guest
            ),
            updatedAt: new Date()
          }
        : event
    ));
  }, []);

  const addPoll = useCallback((eventId: string, poll: Omit<Poll, 'id'>) => {
    const newPoll: Poll = {
      ...poll,
      id: `poll-${Date.now()}`,
    };
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? { ...event, polls: [...event.polls, newPoll], updatedAt: new Date() }
        : event
    ));
  }, []);

  const votePoll = useCallback((eventId: string, pollId: string, optionId: string, guestId: string) => {
    setEvents(prev => prev.map(event => {
      if (event.id !== eventId) return event;
      
      return {
        ...event,
        polls: event.polls.map(poll => {
          if (poll.id !== pollId) return poll;
          
          // Remove previous vote if not allowing multiple
          const updatedOptions = poll.options.map(option => ({
            ...option,
            votes: poll.allowMultiple 
              ? option.id === optionId 
                ? option.votes.includes(guestId)
                  ? option.votes.filter(v => v !== guestId)
                  : [...option.votes, guestId]
                : option.votes
              : option.id === optionId
                ? option.votes.includes(guestId)
                  ? option.votes.filter(v => v !== guestId)
                  : [...option.votes, guestId]
                : option.votes.filter(v => v !== guestId)
          }));
          
          return { ...poll, options: updatedOptions };
        }),
        updatedAt: new Date()
      };
    }));
  }, []);

  const togglePollStatus = useCallback((eventId: string, pollId: string) => {
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? {
            ...event,
            polls: event.polls.map(poll => 
              poll.id === pollId ? { ...poll, isOpen: !poll.isOpen } : poll
            ),
            updatedAt: new Date()
          }
        : event
    ));
  }, []);

  const addComment = useCallback((eventId: string, comment: Omit<Comment, 'id' | 'timestamp'>) => {
    const newComment: Comment = {
      ...comment,
      id: `comment-${Date.now()}`,
      timestamp: new Date(),
    };
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? { ...event, comments: [...event.comments, newComment], updatedAt: new Date() }
        : event
    ));
  }, []);

  const toggleRsvpStatus = useCallback((eventId: string) => {
    setEvents(prev => prev.map(event => 
      event.id === eventId 
        ? { ...event, isRsvpOpen: !event.isRsvpOpen, updatedAt: new Date() }
        : event
    ));
  }, []);

  return (
    <EventContext.Provider value={{
      events,
      getEvent,
      createEvent,
      updateEvent,
      deleteEvent,
      updateEventStatus,
      addGuest,
      updateGuestRSVP,
      addPoll,
      votePoll,
      togglePollStatus,
      addComment,
      toggleRsvpStatus,
    }}>
      {children}
    </EventContext.Provider>
  );
}

export function useEvents() {
  const context = useContext(EventContext);
  if (!context) {
    throw new Error('useEvents must be used within an EventProvider');
  }
  return context;
}
