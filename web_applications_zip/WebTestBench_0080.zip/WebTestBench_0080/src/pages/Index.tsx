import { useState, useEffect } from 'react';
import { Terminal, Sparkles } from 'lucide-react';
import { SearchInput } from '@/components/SearchInput';
import { SearchResults } from '@/components/SearchResults';
import { useDebounce } from '@/hooks/useDebounce';
import { useFuzzySearch } from '@/hooks/useFuzzySearch';
import { useHelpfulRatings } from '@/hooks/useHelpfulRatings';

const Index = () => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const debouncedQuery = useDebounce(query, 300);
  const searchResults = useFuzzySearch(debouncedQuery);
  const { isHelpful, toggleRating } = useHelpfulRatings();

  // Handle the searching state for UI feedback
  useEffect(() => {
    if (query !== debouncedQuery) {
      setIsSearching(true);
    } else {
      setIsSearching(false);
    }
  }, [query, debouncedQuery]);

  return (
    <div className="min-h-screen bg-background">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-3xl mx-auto px-4 py-12">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 mb-6">
            <Terminal className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">
            <span className="text-gradient">Error Lookup</span>
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Paste your error message and find solutions. Fuzzy search helps you find matches even with partial text.
          </p>
        </header>

        {/* Search */}
        <div className="mb-8">
          <SearchInput
            value={query}
            onChange={setQuery}
            isSearching={isSearching}
          />
          
          {!query && (
            <div className="flex items-center justify-center gap-2 mt-4 text-sm text-muted-foreground">
              <Sparkles className="w-4 h-4 text-accent" />
              <span>Try: "undefined", "CORS", "hooks", or "cannot read"</span>
            </div>
          )}
        </div>

        {/* Results */}
        <SearchResults
          results={searchResults}
          isHelpful={isHelpful}
          onToggleHelpful={toggleRating}
          query={debouncedQuery}
          isSearching={isSearching}
        />
      </div>
    </div>
  );
};

export default Index;
