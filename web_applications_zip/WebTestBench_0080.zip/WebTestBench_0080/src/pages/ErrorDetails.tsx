import { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, AlertTriangle, Lightbulb, ThumbsUp } from 'lucide-react';
import { errorDatabase } from '@/data/errors';
import { useHelpfulRatings } from '@/hooks/useHelpfulRatings';
import { TroubleshootingStep } from '@/components/TroubleshootingStep';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const ErrorDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { isHelpful, toggleRating, incrementStepVote, getStepVotes, hasVotedStep } = useHelpfulRatings();
  
  const error = useMemo(() => {
    return errorDatabase.find(e => e.id === id);
  }, [id]);

  const sortedSteps = useMemo(() => {
    if (!error) return [];
    return [...error.troubleshootingSteps].sort((a, b) => {
      const votesA = getStepVotes(a.id, a.helpfulVotes);
      const votesB = getStepVotes(b.id, b.helpfulVotes);
      return votesB - votesA;
    });
  }, [error, getStepVotes]);

  if (!error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Error Not Found</h1>
          <p className="text-muted-foreground mb-6">The error you're looking for doesn't exist.</p>
          <Link to="/">
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Search
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const helpful = isHelpful(error.id);

  return (
    <div className="min-h-screen bg-background">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-3xl mx-auto px-4 py-8">
        {/* Back link */}
        <Link 
          to="/" 
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-8 group"
        >
          <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Search
        </Link>

        {/* Error header */}
        <div className="glass-card rounded-xl p-6 mb-6 animate-fade-in">
          <div className="flex items-start justify-between gap-4 mb-4">
            <h1 className="font-mono text-lg text-primary leading-tight">
              {error.name}
            </h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleRating(error.id)}
              className={cn(
                "shrink-0 h-8 gap-1.5 transition-all duration-200",
                helpful 
                  ? "text-success bg-success/10 hover:bg-success/20" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <ThumbsUp className={cn("h-4 w-4", helpful && "fill-current")} />
              <span className="text-xs">Helpful</span>
            </Button>
          </div>
          
          <p className="text-foreground mb-4">{error.fullDescription}</p>
          
          <div className="flex flex-wrap gap-2">
            {error.tags.map(tag => (
              <span 
                key={tag}
                className="px-2 py-0.5 text-xs rounded-full bg-secondary text-secondary-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Common causes */}
        <div className="mb-8 animate-slide-up" style={{ animationDelay: '100ms' }}>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-accent" />
            </div>
            <h2 className="text-lg font-semibold">Common Causes</h2>
          </div>
          <div className="glass-card rounded-xl p-4">
            <ul className="space-y-3">
              {error.commonCauses.map((cause, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="text-accent mt-1">•</span>
                  <span className="text-muted-foreground">{cause}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Troubleshooting steps */}
        <div className="animate-slide-up" style={{ animationDelay: '200ms' }}>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
              <Lightbulb className="w-4 h-4 text-success" />
            </div>
            <h2 className="text-lg font-semibold">Troubleshooting Steps</h2>
            <span className="text-xs text-muted-foreground ml-auto">
              Sorted by helpfulness
            </span>
          </div>
          <div className="space-y-3">
            {sortedSteps.map((step, index) => (
              <TroubleshootingStep
                key={step.id}
                step={step}
                index={index}
                totalVotes={getStepVotes(step.id, step.helpfulVotes)}
                hasVoted={hasVotedStep(step.id)}
                onVote={() => incrementStepVote(step.id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorDetails;
