import { useMemo } from 'react';
import { ErrorEntry, errorDatabase } from '@/data/errors';

function fuzzyMatch(text: string, pattern: string): { matches: boolean; score: number } {
  if (!pattern) return { matches: true, score: 0 };
  
  const textLower = text.toLowerCase();
  const patternLower = pattern.toLowerCase();
  
  // Exact match gets highest score
  if (textLower.includes(patternLower)) {
    return { matches: true, score: 100 - textLower.indexOf(patternLower) };
  }
  
  // Word-based matching
  const patternWords = patternLower.split(/\s+/).filter(Boolean);
  const matchedWords = patternWords.filter(word => textLower.includes(word));
  
  if (matchedWords.length > 0) {
    return { 
      matches: true, 
      score: (matchedWords.length / patternWords.length) * 50 
    };
  }
  
  // Character sequence matching (fuzzy)
  let patternIndex = 0;
  let consecutiveMatches = 0;
  let maxConsecutive = 0;
  
  for (let i = 0; i < textLower.length && patternIndex < patternLower.length; i++) {
    if (textLower[i] === patternLower[patternIndex]) {
      patternIndex++;
      consecutiveMatches++;
      maxConsecutive = Math.max(maxConsecutive, consecutiveMatches);
    } else {
      consecutiveMatches = 0;
    }
  }
  
  if (patternIndex === patternLower.length) {
    return { matches: true, score: maxConsecutive + (patternIndex / patternLower.length) * 20 };
  }
  
  return { matches: false, score: 0 };
}

function searchError(error: ErrorEntry, query: string): { matches: boolean; score: number } {
  const fields = [
    { text: error.name, weight: 3 },
    { text: error.shortDescription, weight: 2 },
    { text: error.fullDescription, weight: 1.5 },
    { text: error.tags.join(' '), weight: 2 },
    { text: error.commonCauses.join(' '), weight: 1 }
  ];
  
  let totalScore = 0;
  let hasMatch = false;
  
  for (const field of fields) {
    const result = fuzzyMatch(field.text, query);
    if (result.matches && result.score > 0) {
      hasMatch = true;
      totalScore += result.score * field.weight;
    }
  }
  
  return { matches: hasMatch, score: totalScore };
}

export interface SearchResult {
  error: ErrorEntry;
  score: number;
}

export function useFuzzySearch(query: string): SearchResult[] {
  return useMemo(() => {
    if (!query.trim()) {
      // Return all errors sorted by name when no query
      return errorDatabase
        .map(error => ({ error, score: 0 }))
        .sort((a, b) => a.error.name.localeCompare(b.error.name));
    }
    
    const results: SearchResult[] = [];
    
    for (const error of errorDatabase) {
      const { matches, score } = searchError(error, query);
      if (matches) {
        results.push({ error, score });
      }
    }
    
    // Sort by score descending
    return results.sort((a, b) => b.score - a.score);
  }, [query]);
}
