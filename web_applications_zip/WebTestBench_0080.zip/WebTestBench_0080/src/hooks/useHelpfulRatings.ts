import { useState, useCallback } from 'react';

export interface HelpfulRatings {
  [errorId: string]: boolean;
}

export interface StepRatings {
  [stepId: string]: number;
}

export function useHelpfulRatings() {
  const [ratings, setRatings] = useState<HelpfulRatings>({});
  const [stepRatings, setStepRatings] = useState<StepRatings>({});

  const toggleRating = useCallback((errorId: string) => {
    setRatings(prev => ({
      ...prev,
      [errorId]: !prev[errorId]
    }));
  }, []);

  const isHelpful = useCallback((errorId: string): boolean => {
    return ratings[errorId] ?? false;
  }, [ratings]);

  const incrementStepVote = useCallback((stepId: string) => {
    setStepRatings(prev => ({
      ...prev,
      [stepId]: (prev[stepId] || 0) + 1
    }));
  }, []);

  const getStepVotes = useCallback((stepId: string, baseVotes: number): number => {
    return baseVotes + (stepRatings[stepId] || 0);
  }, [stepRatings]);

  const hasVotedStep = useCallback((stepId: string): boolean => {
    return (stepRatings[stepId] || 0) > 0;
  }, [stepRatings]);

  return {
    ratings,
    toggleRating,
    isHelpful,
    incrementStepVote,
    getStepVotes,
    hasVotedStep
  };
}
