export interface TroubleshootingStep {
  id: string;
  description: string;
  helpfulVotes: number;
}

export interface ErrorEntry {
  id: string;
  name: string;
  shortDescription: string;
  fullDescription: string;
  commonCauses: string[];
  troubleshootingSteps: TroubleshootingStep[];
  tags: string[];
}

export const errorDatabase: ErrorEntry[] = [
  {
    id: "cannot-read-property-undefined",
    name: "TypeError: Cannot read property of undefined",
    shortDescription: "Attempting to access a property on an undefined value",
    fullDescription: "This error occurs when you try to access a property or call a method on a variable that is undefined. JavaScript cannot read properties of something that doesn't exist.",
    commonCauses: [
      "Accessing an object property before the object is initialized",
      "Typo in variable or property name",
      "Async data not loaded yet when trying to access it",
      "Incorrect destructuring of objects or arrays",
      "API response missing expected fields"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Add optional chaining (?.) before accessing nested properties", helpfulVotes: 42 },
      { id: "ts2", description: "Check if the variable is defined before accessing its properties", helpfulVotes: 38 },
      { id: "ts3", description: "Use nullish coalescing (??) to provide default values", helpfulVotes: 27 },
      { id: "ts4", description: "Verify the data structure matches your expectations using console.log", helpfulVotes: 35 },
      { id: "ts5", description: "Ensure async data is loaded before rendering dependent components", helpfulVotes: 31 }
    ],
    tags: ["TypeError", "undefined", "null", "property access", "JavaScript"]
  },
  {
    id: "module-not-found",
    name: "Module not found: Can't resolve",
    shortDescription: "The bundler cannot find the specified module or package",
    fullDescription: "This build error indicates that Webpack, Vite, or another bundler cannot locate a module you're trying to import. The module might not be installed, the path might be incorrect, or there might be a case-sensitivity issue.",
    commonCauses: [
      "Package not installed (missing npm install)",
      "Incorrect import path (typo or wrong relative path)",
      "Case sensitivity mismatch in file/folder names",
      "Missing file extension in import statement",
      "Circular dependency issues"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Run 'npm install' or 'yarn install' to ensure all dependencies are installed", helpfulVotes: 56 },
      { id: "ts2", description: "Verify the exact spelling and casing of the module name", helpfulVotes: 41 },
      { id: "ts3", description: "Check if the file exists at the specified path", helpfulVotes: 38 },
      { id: "ts4", description: "Try clearing node_modules and reinstalling: rm -rf node_modules && npm install", helpfulVotes: 47 },
      { id: "ts5", description: "Ensure your tsconfig.json or jsconfig.json paths are configured correctly", helpfulVotes: 29 }
    ],
    tags: ["build error", "import", "module", "webpack", "vite", "package"]
  },
  {
    id: "cors-error",
    name: "CORS: Cross-Origin Request Blocked",
    shortDescription: "Browser blocked a request to a different origin due to CORS policy",
    fullDescription: "Cross-Origin Resource Sharing (CORS) is a security feature that restricts web pages from making requests to a different domain than the one serving the page. This error occurs when the server doesn't include proper CORS headers.",
    commonCauses: [
      "API server not configured to allow cross-origin requests",
      "Missing Access-Control-Allow-Origin header on the server",
      "Credentials included but server doesn't allow credentials",
      "Preflight OPTIONS request failing",
      "Incorrect protocol (HTTP vs HTTPS) mismatch"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Configure the server to include 'Access-Control-Allow-Origin' header", helpfulVotes: 63 },
      { id: "ts2", description: "Use a proxy during development (e.g., Vite's proxy config)", helpfulVotes: 58 },
      { id: "ts3", description: "Ensure the server handles OPTIONS preflight requests", helpfulVotes: 42 },
      { id: "ts4", description: "Check if you're mixing HTTP and HTTPS protocols", helpfulVotes: 31 },
      { id: "ts5", description: "For development, consider using a browser extension to disable CORS (not for production!)", helpfulVotes: 25 }
    ],
    tags: ["CORS", "cross-origin", "API", "fetch", "XMLHttpRequest", "security"]
  },
  {
    id: "react-hooks-order",
    name: "React: Hooks Order Error",
    shortDescription: "Hooks must be called in the same order on every render",
    fullDescription: "React relies on the order of Hook calls to correctly preserve state between re-renders. Calling Hooks inside conditions, loops, or nested functions breaks this invariant.",
    commonCauses: [
      "Calling a Hook inside an if statement",
      "Calling a Hook inside a loop",
      "Calling a Hook after a conditional return",
      "Calling a Hook inside a callback function",
      "Different number of Hook calls between renders"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Move all Hook calls to the top level of your component function", helpfulVotes: 71 },
      { id: "ts2", description: "Use conditional logic inside the Hook, not around it", helpfulVotes: 54 },
      { id: "ts3", description: "Ensure early returns don't skip Hook calls", helpfulVotes: 45 },
      { id: "ts4", description: "Install eslint-plugin-react-hooks to catch these errors early", helpfulVotes: 62 },
      { id: "ts5", description: "Extract complex logic into custom Hooks that handle conditions internally", helpfulVotes: 38 }
    ],
    tags: ["React", "Hooks", "useState", "useEffect", "rules of hooks"]
  },
  {
    id: "maximum-update-depth",
    name: "Maximum update depth exceeded",
    shortDescription: "Component is stuck in an infinite re-render loop",
    fullDescription: "React limits the number of nested updates to prevent infinite loops. This error usually means a component is calling setState during render, or useEffect is causing a re-render that triggers the effect again.",
    commonCauses: [
      "Calling setState directly in the component body (outside useEffect)",
      "useEffect with a missing or incorrect dependency array",
      "Passing a function call instead of a function reference to an event handler",
      "State update inside useEffect without proper dependencies",
      "Object/array as useEffect dependency without memoization"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Move state updates inside useEffect with proper dependencies", helpfulVotes: 67 },
      { id: "ts2", description: "Use useCallback for function handlers passed as props", helpfulVotes: 49 },
      { id: "ts3", description: "Change onClick={handleClick()} to onClick={handleClick}", helpfulVotes: 72 },
      { id: "ts4", description: "Add the dependency array to useEffect: useEffect(() => {}, [])", helpfulVotes: 55 },
      { id: "ts5", description: "Use useMemo for objects/arrays used as dependencies", helpfulVotes: 41 }
    ],
    tags: ["React", "infinite loop", "useEffect", "setState", "render"]
  },
  {
    id: "network-error",
    name: "Network Error / Failed to fetch",
    shortDescription: "The network request failed to complete",
    fullDescription: "This error indicates that a network request couldn't be completed. Unlike HTTP errors (404, 500), this means the request never got a response from the server at all.",
    commonCauses: [
      "No internet connection",
      "Server is down or unreachable",
      "Request timeout exceeded",
      "CORS issue blocking the request",
      "Incorrect API URL or endpoint"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Check your internet connection", helpfulVotes: 34 },
      { id: "ts2", description: "Verify the API endpoint URL is correct", helpfulVotes: 52 },
      { id: "ts3", description: "Try the request in a tool like Postman to isolate the issue", helpfulVotes: 48 },
      { id: "ts4", description: "Check browser DevTools Network tab for more details", helpfulVotes: 57 },
      { id: "ts5", description: "Implement retry logic with exponential backoff", helpfulVotes: 31 }
    ],
    tags: ["network", "fetch", "API", "connection", "timeout"]
  },
  {
    id: "json-parse-error",
    name: "SyntaxError: Unexpected token in JSON",
    shortDescription: "Failed to parse a string as valid JSON",
    fullDescription: "This error occurs when JSON.parse() or the .json() method receives invalid JSON. This often happens when an API returns HTML error pages, plain text, or malformed JSON.",
    commonCauses: [
      "API returned HTML instead of JSON (often an error page)",
      "Missing or extra commas in JSON structure",
      "Unescaped special characters in strings",
      "Single quotes instead of double quotes in JSON",
      "Trailing commas (not allowed in JSON)"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Log the raw response text before parsing to see what was received", helpfulVotes: 61 },
      { id: "ts2", description: "Check response.ok before calling response.json()", helpfulVotes: 53 },
      { id: "ts3", description: "Validate your JSON with a JSON validator tool", helpfulVotes: 44 },
      { id: "ts4", description: "Ensure the Content-Type header is set to application/json", helpfulVotes: 39 },
      { id: "ts5", description: "Handle non-JSON responses gracefully with try-catch", helpfulVotes: 47 }
    ],
    tags: ["JSON", "parse", "SyntaxError", "API", "response"]
  },
  {
    id: "undefined-is-not-a-function",
    name: "TypeError: undefined is not a function",
    shortDescription: "Attempted to call something that isn't a function",
    fullDescription: "This error happens when you try to invoke a value as a function, but that value is undefined (or sometimes null or another non-function type).",
    commonCauses: [
      "Typo in function name",
      "Calling a method on an undefined object",
      "Callback not passed correctly to a component",
      "Importing a named export that doesn't exist",
      "Using wrong array method name (e.g., map vs filter)"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Verify the function exists and is spelled correctly", helpfulVotes: 45 },
      { id: "ts2", description: "Check that the object containing the method is defined", helpfulVotes: 52 },
      { id: "ts3", description: "Ensure named imports match the exact export names", helpfulVotes: 41 },
      { id: "ts4", description: "Add type checking: typeof fn === 'function' before calling", helpfulVotes: 33 },
      { id: "ts5", description: "Use optional chaining for callbacks: onCallback?.()", helpfulVotes: 48 }
    ],
    tags: ["TypeError", "function", "undefined", "callback", "JavaScript"]
  },
  {
    id: "key-prop-warning",
    name: "React: Each child should have a unique 'key' prop",
    shortDescription: "List items are missing unique key attributes",
    fullDescription: "When rendering lists in React, each element needs a unique 'key' prop to help React identify which items have changed, been added, or removed. Using proper keys improves performance and prevents bugs.",
    commonCauses: [
      "Forgot to add key prop when mapping over arrays",
      "Using array index as key (can cause issues with reordering)",
      "Duplicate keys in the list",
      "Key prop passed to wrong element (should be on outermost element in map)",
      "Key value is undefined or null"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Add a unique 'key' prop using an ID from your data", helpfulVotes: 68 },
      { id: "ts2", description: "Avoid using array index as key if list can be reordered or filtered", helpfulVotes: 54 },
      { id: "ts3", description: "Ensure the key is on the outermost element returned in map()", helpfulVotes: 43 },
      { id: "ts4", description: "Generate stable IDs if your data doesn't have them (uuid, nanoid)", helpfulVotes: 37 },
      { id: "ts5", description: "Check for duplicate key values in your data", helpfulVotes: 29 }
    ],
    tags: ["React", "key", "list", "map", "warning", "performance"]
  },
  {
    id: "async-await-error",
    name: "Unhandled Promise Rejection",
    shortDescription: "An async operation failed without error handling",
    fullDescription: "This occurs when a Promise is rejected but there's no .catch() handler or try-catch block to handle the error. Modern JavaScript requires all Promise rejections to be handled.",
    commonCauses: [
      "Missing try-catch around await statements",
      "No .catch() on Promise chains",
      "Async function called without error handling",
      "Error thrown inside async callback",
      "Network request failing without error handling"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Wrap async/await code in try-catch blocks", helpfulVotes: 59 },
      { id: "ts2", description: "Add .catch() at the end of Promise chains", helpfulVotes: 51 },
      { id: "ts3", description: "Use global error boundaries in React for async errors", helpfulVotes: 38 },
      { id: "ts4", description: "Log the actual error to understand what failed", helpfulVotes: 63 },
      { id: "ts5", description: "Implement a global unhandledrejection event listener for debugging", helpfulVotes: 27 }
    ],
    tags: ["async", "await", "Promise", "error handling", "rejection"]
  },
  {
    id: "state-not-updating",
    name: "React State Not Updating Immediately",
    shortDescription: "State appears stale or updates are not reflected",
    fullDescription: "React state updates are asynchronous and batched. Reading state immediately after calling setState will show the old value. This is by design for performance optimization.",
    commonCauses: [
      "Reading state right after setState (it's async)",
      "Closure capturing stale state value",
      "Mutating state directly instead of creating new object",
      "Missing the functional update form for state based on previous",
      "useEffect not having the state in its dependency array"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Use useEffect to react to state changes", helpfulVotes: 64 },
      { id: "ts2", description: "Use functional updates: setState(prev => prev + 1)", helpfulVotes: 71 },
      { id: "ts3", description: "Never mutate state directly; create new objects/arrays", helpfulVotes: 58 },
      { id: "ts4", description: "Add state to useEffect dependency array when needed", helpfulVotes: 45 },
      { id: "ts5", description: "Use useRef for values you need to access immediately without re-render", helpfulVotes: 39 }
    ],
    tags: ["React", "useState", "state", "async", "stale closure"]
  },
  {
    id: "hydration-mismatch",
    name: "React Hydration Mismatch",
    shortDescription: "Server-rendered HTML doesn't match client render",
    fullDescription: "In SSR/SSG applications, React expects the initial client render to match the server-rendered HTML exactly. Mismatches cause this warning and can lead to visual glitches.",
    commonCauses: [
      "Using browser-only APIs (window, localStorage) during initial render",
      "Date/time formatting differences between server and client",
      "Random values generated differently on server vs client",
      "Third-party scripts modifying the DOM",
      "Conditional rendering based on client-only state"
    ],
    troubleshootingSteps: [
      { id: "ts1", description: "Wrap browser-only code in useEffect", helpfulVotes: 67 },
      { id: "ts2", description: "Use dynamic import with { ssr: false } for client-only components", helpfulVotes: 54 },
      { id: "ts3", description: "Use suppressHydrationWarning for intentional differences", helpfulVotes: 38 },
      { id: "ts4", description: "Ensure consistent date formatting between server and client", helpfulVotes: 42 },
      { id: "ts5", description: "Use mounted state pattern for client-only rendering", helpfulVotes: 49 }
    ],
    tags: ["React", "SSR", "hydration", "Next.js", "server rendering"]
  }
];
