import { ThumbsUp, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ErrorEntry } from '@/data/errors';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface ErrorCardProps {
  error: ErrorEntry;
  isHelpful: boolean;
  onToggleHelpful: () => void;
  animationDelay?: number;
}

export function ErrorCard({ 
  error, 
  isHelpful, 
  onToggleHelpful,
  animationDelay = 0 
}: ErrorCardProps) {
  return (
    <div 
      className="glass-card rounded-lg p-4 hover:border-primary/30 transition-all duration-300 animate-slide-up group"
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      <div className="flex items-start justify-between gap-4">
        <Link 
          to={`/error/${error.id}`}
          className="flex-1 min-w-0"
        >
          <h3 className="font-mono text-sm text-primary group-hover:text-primary/80 transition-colors line-clamp-1">
            {error.name}
          </h3>
          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
            {error.shortDescription}
          </p>
          <div className="flex flex-wrap gap-2 mt-3">
            {error.tags.slice(0, 4).map(tag => (
              <span 
                key={tag}
                className="px-2 py-0.5 text-xs rounded-full bg-secondary text-secondary-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        </Link>
        
        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.preventDefault();
              onToggleHelpful();
            }}
            className={cn(
              "h-8 gap-1.5 transition-all duration-200",
              isHelpful 
                ? "text-success bg-success/10 hover:bg-success/20" 
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <ThumbsUp className={cn("h-4 w-4", isHelpful && "fill-current")} />
            <span className="text-xs">Helpful</span>
          </Button>
          
          <Link to={`/error/${error.id}`}>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 text-muted-foreground hover:text-primary"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
