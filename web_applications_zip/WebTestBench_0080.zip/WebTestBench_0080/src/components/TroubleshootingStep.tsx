import { ThumbsUp, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface TroubleshootingStepProps {
  step: {
    id: string;
    description: string;
    helpfulVotes: number;
  };
  index: number;
  totalVotes: number;
  hasVoted: boolean;
  onVote: () => void;
}

export function TroubleshootingStep({ 
  step, 
  index, 
  totalVotes,
  hasVoted,
  onVote 
}: TroubleshootingStepProps) {
  return (
    <div 
      className="glass-card rounded-lg p-4 animate-slide-up"
      style={{ animationDelay: `${(index + 1) * 100}ms` }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium text-sm">
          {index + 1}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-foreground">{step.description}</p>
          <div className="flex items-center gap-4 mt-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={onVote}
              disabled={hasVoted}
              className={cn(
                "h-7 gap-1.5 text-xs transition-all duration-200",
                hasVoted 
                  ? "text-success bg-success/10 cursor-default" 
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              {hasVoted ? (
                <Check className="h-3.5 w-3.5" />
              ) : (
                <ThumbsUp className="h-3.5 w-3.5" />
              )}
              <span>{hasVoted ? 'Voted' : 'This helped'}</span>
            </Button>
            <span className="text-xs text-muted-foreground">
              {totalVotes} vote{totalVotes !== 1 ? 's' : ''}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
