import { SearchResult } from '@/hooks/useFuzzySearch';
import { ErrorCard } from './ErrorCard';
import { AlertCircle, SearchX } from 'lucide-react';

interface SearchResultsProps {
  results: SearchResult[];
  isHelpful: (errorId: string) => boolean;
  onToggleHelpful: (errorId: string) => void;
  query: string;
  isSearching: boolean;
}

export function SearchResults({ 
  results, 
  isHelpful, 
  onToggleHelpful, 
  query,
  isSearching 
}: SearchResultsProps) {
  if (isSearching) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground animate-pulse-soft">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
          <AlertCircle className="w-8 h-8 text-primary" />
        </div>
        <p>Searching...</p>
      </div>
    );
  }

  if (query && results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground animate-fade-in">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
          <SearchX className="w-8 h-8" />
        </div>
        <p className="text-lg font-medium mb-2">No errors found</p>
        <p className="text-sm">Try searching with different keywords</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {query && (
        <p className="text-sm text-muted-foreground mb-4">
          Found <span className="text-primary font-medium">{results.length}</span> matching error{results.length !== 1 ? 's' : ''}
        </p>
      )}
      {results.map((result, index) => (
        <ErrorCard
          key={result.error.id}
          error={result.error}
          isHelpful={isHelpful(result.error.id)}
          onToggleHelpful={() => onToggleHelpful(result.error.id)}
          animationDelay={index * 50}
        />
      ))}
    </div>
  );
}
