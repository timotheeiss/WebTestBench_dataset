export type CandidateStatus = 'new' | 'screening' | 'interviewing' | 'hired' | 'rejected';

export interface Skill {
  id: string;
  name: string;
}

export interface Interview {
  id: string;
  candidateId: string;
  date: Date;
  interviewerId: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  reminderSet: boolean;
  feedback?: InterviewFeedback;
}

export interface InterviewFeedback {
  rating: number;
  technicalSkills: number;
  communication: number;
  cultureFit: number;
  comments: string;
  recommendation: 'strong_yes' | 'yes' | 'no' | 'strong_no';
  submittedAt: Date;
}

export interface Interviewer {
  id: string;
  name: string;
  email: string;
  department: string;
  avatar?: string;
}

export interface Candidate {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  skills: Skill[];
  notes: string;
  status: CandidateStatus;
  createdAt: Date;
  updatedAt: Date;
  position: string;
  experience: string;
  interviews: Interview[];
}

export interface DuplicateCandidate {
  candidate: Candidate;
  matchScore: number;
  matchReasons: string[];
}
