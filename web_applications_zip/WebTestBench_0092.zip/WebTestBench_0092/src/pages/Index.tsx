import { useState, useMemo } from 'react';
import { Candidate, CandidateStatus } from '@/types/candidate';
import { initialInterviewers } from '@/data/initialData';
import { useCandidates } from '@/hooks/useCandidates';
import { Header } from '@/components/Header';
import { FilterBar } from '@/components/FilterBar';
import { CandidateCard } from '@/components/CandidateCard';
import { CandidateForm } from '@/components/CandidateForm';
import { CandidateDetails } from '@/components/CandidateDetails';
import { ScheduleInterviewDialog } from '@/components/ScheduleInterviewDialog';
import { FeedbackDialog } from '@/components/FeedbackDialog';
import { useToast } from '@/hooks/use-toast';
import { Users } from 'lucide-react';

const Index = () => {
  const { 
    candidates, 
    addCandidate, 
    updateCandidate,
    updateStatus, 
    scheduleInterview, 
    submitFeedback,
    checkDuplicates,
    mergeCandidates,
  } = useCandidates();
  
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<CandidateStatus | 'all'>('all');
  
  // Dialog states
  const [candidateFormOpen, setCandidateFormOpen] = useState(false);
  const [editingCandidate, setEditingCandidate] = useState<Candidate | undefined>();
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [feedbackDialogOpen, setFeedbackDialogOpen] = useState(false);

  // Filter and search candidates
  const filteredCandidates = useMemo(() => {
    return candidates.filter(candidate => {
      const matchesStatus = statusFilter === 'all' || candidate.status === statusFilter;
      const matchesSearch = searchQuery === '' || 
        `${candidate.firstName} ${candidate.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
        candidate.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        candidate.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
        candidate.skills.some(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesStatus && matchesSearch;
    });
  }, [candidates, statusFilter, searchQuery]);

  // Count candidates by status
  const statusCounts = useMemo(() => {
    const counts: Record<CandidateStatus | 'all', number> = {
      all: candidates.length,
      new: 0,
      screening: 0,
      interviewing: 0,
      hired: 0,
      rejected: 0,
    };
    candidates.forEach(c => counts[c.status]++);
    return counts;
  }, [candidates]);

  const handleAddCandidate = () => {
    setEditingCandidate(undefined);
    setCandidateFormOpen(true);
  };

  const handleEditCandidate = (candidate: Candidate) => {
    setEditingCandidate(candidate);
    setCandidateFormOpen(true);
    setDetailsOpen(false);
  };

  const handleCandidateSubmit = (data: Omit<Candidate, 'id' | 'createdAt' | 'updatedAt' | 'interviews'>) => {
    if (editingCandidate) {
      updateCandidate(editingCandidate.id, data);
      toast({
        title: 'Candidate Updated',
        description: `${data.firstName} ${data.lastName}'s profile has been updated.`,
      });
    } else {
      addCandidate(data);
      toast({
        title: 'Candidate Added',
        description: `${data.firstName} ${data.lastName} has been added to the pipeline.`,
      });
    }
  };

  const handleViewDetails = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setDetailsOpen(true);
  };

  const handleScheduleInterview = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setScheduleDialogOpen(true);
  };

  const handleSubmitFeedback = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setFeedbackDialogOpen(true);
  };

  const handleUpdateStatus = (id: string, status: 'hired' | 'rejected') => {
    updateStatus(id, status);
    const candidate = candidates.find(c => c.id === id);
    toast({
      title: status === 'hired' ? '🎉 Candidate Hired!' : 'Candidate Rejected',
      description: candidate 
        ? `${candidate.firstName} ${candidate.lastName} has been marked as ${status}.`
        : undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        onAddCandidate={handleAddCandidate}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        totalCandidates={candidates.length}
      />

      <main className="container py-6">
        <FilterBar 
          activeFilter={statusFilter}
          onFilterChange={setStatusFilter}
          counts={statusCounts}
        />

        {filteredCandidates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-1">No candidates found</h3>
            <p className="text-muted-foreground max-w-sm">
              {searchQuery || statusFilter !== 'all' 
                ? 'Try adjusting your search or filters'
                : 'Get started by adding your first candidate'}
            </p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-6">
            {filteredCandidates.map(candidate => (
              <CandidateCard
                key={candidate.id}
                candidate={candidate}
                interviewers={initialInterviewers}
                onScheduleInterview={handleScheduleInterview}
                onSubmitFeedback={handleSubmitFeedback}
                onUpdateStatus={handleUpdateStatus}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        )}
      </main>

      {/* Dialogs */}
      <CandidateForm
        open={candidateFormOpen}
        onOpenChange={setCandidateFormOpen}
        onSubmit={handleCandidateSubmit}
        onCheckDuplicates={checkDuplicates}
        onMerge={(targetId) => {
          if (editingCandidate) {
            mergeCandidates(targetId, editingCandidate.id);
          }
        }}
        initialData={editingCandidate}
      />

      <CandidateDetails
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        candidate={selectedCandidate}
        interviewers={initialInterviewers}
        onScheduleInterview={handleScheduleInterview}
        onSubmitFeedback={handleSubmitFeedback}
        onUpdateStatus={handleUpdateStatus}
        onEdit={handleEditCandidate}
      />

      <ScheduleInterviewDialog
        open={scheduleDialogOpen}
        onOpenChange={setScheduleDialogOpen}
        candidate={selectedCandidate}
        interviewers={initialInterviewers}
        onSchedule={scheduleInterview}
      />

      <FeedbackDialog
        open={feedbackDialogOpen}
        onOpenChange={setFeedbackDialogOpen}
        candidate={selectedCandidate}
        onSubmit={submitFeedback}
      />
    </div>
  );
};

export default Index;
