import { useState, useCallback } from 'react';
import { Candidate, CandidateStatus, Interview, InterviewFeedback, DuplicateCandidate } from '@/types/candidate';
import { initialCandidates } from '@/data/initialData';

export function useCandidates() {
  const [candidates, setCandidates] = useState<Candidate[]>(initialCandidates);

  const addCandidate = useCallback((candidate: Omit<Candidate, 'id' | 'createdAt' | 'updatedAt' | 'interviews'>) => {
    const newCandidate: Candidate = {
      ...candidate,
      id: `cand-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
      interviews: [],
    };
    setCandidates(prev => [...prev, newCandidate]);
    return newCandidate;
  }, []);

  const updateCandidate = useCallback((id: string, updates: Partial<Candidate>) => {
    setCandidates(prev => prev.map(c => 
      c.id === id ? { ...c, ...updates, updatedAt: new Date() } : c
    ));
  }, []);

  const deleteCandidate = useCallback((id: string) => {
    setCandidates(prev => prev.filter(c => c.id !== id));
  }, []);

  const updateStatus = useCallback((id: string, status: CandidateStatus) => {
    updateCandidate(id, { status });
  }, [updateCandidate]);

  const scheduleInterview = useCallback((candidateId: string, interview: Omit<Interview, 'id' | 'candidateId' | 'status'>) => {
    const newInterview: Interview = {
      ...interview,
      id: `int-${Date.now()}`,
      candidateId,
      status: 'scheduled',
    };
    
    setCandidates(prev => prev.map(c => {
      if (c.id === candidateId) {
        return {
          ...c,
          interviews: [...c.interviews, newInterview],
          status: c.status === 'new' || c.status === 'screening' ? 'interviewing' : c.status,
          updatedAt: new Date(),
        };
      }
      return c;
    }));
    
    return newInterview;
  }, []);

  const submitFeedback = useCallback((candidateId: string, interviewId: string, feedback: InterviewFeedback) => {
    setCandidates(prev => prev.map(c => {
      if (c.id === candidateId) {
        return {
          ...c,
          interviews: c.interviews.map(i => 
            i.id === interviewId ? { ...i, feedback, status: 'completed' as const } : i
          ),
          updatedAt: new Date(),
        };
      }
      return c;
    }));
  }, []);

  const checkDuplicates = useCallback((firstName: string, lastName: string, email: string, phone: string): DuplicateCandidate[] => {
    const duplicates: DuplicateCandidate[] = [];
    
    candidates.forEach(candidate => {
      const matchReasons: string[] = [];
      let matchScore = 0;
      
      // Email match (strongest indicator)
      if (email && candidate.email.toLowerCase() === email.toLowerCase()) {
        matchScore += 50;
        matchReasons.push('Same email address');
      }
      
      // Phone match
      if (phone && candidate.phone.replace(/\D/g, '') === phone.replace(/\D/g, '')) {
        matchScore += 30;
        matchReasons.push('Same phone number');
      }
      
      // Name match
      const fullNameMatch = 
        candidate.firstName.toLowerCase() === firstName.toLowerCase() &&
        candidate.lastName.toLowerCase() === lastName.toLowerCase();
      
      if (fullNameMatch) {
        matchScore += 20;
        matchReasons.push('Same full name');
      }
      
      if (matchScore >= 20) {
        duplicates.push({
          candidate,
          matchScore,
          matchReasons,
        });
      }
    });
    
    return duplicates.sort((a, b) => b.matchScore - a.matchScore);
  }, [candidates]);

  const mergeCandidates = useCallback((targetId: string, sourceId: string) => {
    const target = candidates.find(c => c.id === targetId);
    const source = candidates.find(c => c.id === sourceId);
    
    if (!target || !source) return;
    
    // Merge skills (unique)
    const mergedSkills = [...target.skills];
    source.skills.forEach(skill => {
      if (!mergedSkills.find(s => s.name === skill.name)) {
        mergedSkills.push(skill);
      }
    });
    
    // Merge notes
    const mergedNotes = target.notes + (source.notes ? `\n\n--- Merged from duplicate profile ---\n${source.notes}` : '');
    
    // Merge interviews
    const mergedInterviews = [...target.interviews, ...source.interviews];
    
    updateCandidate(targetId, {
      skills: mergedSkills,
      notes: mergedNotes,
      interviews: mergedInterviews,
    });
    
    deleteCandidate(sourceId);
  }, [candidates, updateCandidate, deleteCandidate]);

  return {
    candidates,
    addCandidate,
    updateCandidate,
    deleteCandidate,
    updateStatus,
    scheduleInterview,
    submitFeedback,
    checkDuplicates,
    mergeCandidates,
  };
}
