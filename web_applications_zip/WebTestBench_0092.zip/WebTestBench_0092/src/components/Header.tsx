import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UserPlus, Search, Users } from 'lucide-react';

interface HeaderProps {
  onAddCandidate: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  totalCandidates: number;
}

export function Header({ 
  onAddCandidate, 
  searchQuery, 
  onSearchChange,
  totalCandidates 
}: HeaderProps) {
  return (
    <header className="border-b bg-card">
      <div className="container py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <Users className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-semibold">TalentHub</h1>
              <p className="text-sm text-muted-foreground">
                {totalCandidates} candidates in pipeline
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search candidates..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-9 w-64"
              />
            </div>
            <Button onClick={onAddCandidate}>
              <UserPlus className="h-4 w-4 mr-2" />
              Add Candidate
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
