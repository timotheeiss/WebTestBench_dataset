import { useState, useEffect } from 'react';
import { Candidate, DuplicateCandidate, Skill, CandidateStatus } from '@/types/candidate';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, X, Plus } from 'lucide-react';
import { availableSkills } from '@/data/initialData';

interface CandidateFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (candidate: Omit<Candidate, 'id' | 'createdAt' | 'updatedAt' | 'interviews'>) => void;
  onCheckDuplicates: (firstName: string, lastName: string, email: string, phone: string) => DuplicateCandidate[];
  onMerge?: (targetId: string) => void;
  initialData?: Candidate;
}

export function CandidateForm({
  open,
  onOpenChange,
  onSubmit,
  onCheckDuplicates,
  onMerge,
  initialData,
}: CandidateFormProps) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [position, setPosition] = useState('');
  const [experience, setExperience] = useState('');
  const [skills, setSkills] = useState<Skill[]>([]);
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<CandidateStatus>('new');
  const [duplicates, setDuplicates] = useState<DuplicateCandidate[]>([]);
  const [skillInput, setSkillInput] = useState('');

  useEffect(() => {
    if (initialData) {
      setFirstName(initialData.firstName);
      setLastName(initialData.lastName);
      setEmail(initialData.email);
      setPhone(initialData.phone);
      setPosition(initialData.position);
      setExperience(initialData.experience);
      setSkills(initialData.skills);
      setNotes(initialData.notes);
      setStatus(initialData.status);
    } else {
      resetForm();
    }
  }, [initialData, open]);

  const resetForm = () => {
    setFirstName('');
    setLastName('');
    setEmail('');
    setPhone('');
    setPosition('');
    setExperience('');
    setSkills([]);
    setNotes('');
    setStatus('new');
    setDuplicates([]);
    setSkillInput('');
  };

  const handleCheckDuplicates = () => {
    if (!initialData && (firstName || lastName || email || phone)) {
      const found = onCheckDuplicates(firstName, lastName, email, phone);
      setDuplicates(found);
    }
  };

  const addSkill = (skillName: string) => {
    if (skillName && !skills.find(s => s.name === skillName)) {
      setSkills([...skills, { id: `skill-${Date.now()}`, name: skillName }]);
      setSkillInput('');
    }
  };

  const removeSkill = (skillId: string) => {
    setSkills(skills.filter(s => s.id !== skillId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      firstName,
      lastName,
      email,
      phone,
      position,
      experience,
      skills,
      notes,
      status,
    });
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {initialData ? 'Edit Candidate' : 'Add New Candidate'}
          </DialogTitle>
          <DialogDescription>
            {initialData 
              ? 'Update the candidate information below.'
              : 'Enter the candidate details to create a new profile.'
            }
          </DialogDescription>
        </DialogHeader>

        {duplicates.length > 0 && !initialData && (
          <Alert variant="destructive" className="bg-warning/10 border-warning text-warning-foreground">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Potential Duplicates Found</AlertTitle>
            <AlertDescription className="mt-2">
              <div className="space-y-2">
                {duplicates.map(dup => (
                  <div 
                    key={dup.candidate.id} 
                    className="flex items-center justify-between p-2 bg-background/50 rounded"
                  >
                    <div>
                      <p className="font-medium">
                        {dup.candidate.firstName} {dup.candidate.lastName}
                      </p>
                      <p className="text-sm opacity-80">
                        {dup.matchReasons.join(' • ')}
                      </p>
                    </div>
                    {onMerge && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          onMerge(dup.candidate.id);
                          onOpenChange(false);
                        }}
                      >
                        Merge
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                onBlur={handleCheckDuplicates}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                onBlur={handleCheckDuplicates}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onBlur={handleCheckDuplicates}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                onBlur={handleCheckDuplicates}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Input
                id="position"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
                placeholder="e.g., Senior Developer"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="experience">Experience</Label>
              <Input
                id="experience"
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                placeholder="e.g., 5 years"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Skills</Label>
            <div className="flex gap-2">
              <Select value={skillInput} onValueChange={addSkill}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select a skill..." />
                </SelectTrigger>
                <SelectContent>
                  {availableSkills
                    .filter(s => !skills.find(sk => sk.name === s))
                    .map(skill => (
                      <SelectItem key={skill} value={skill}>
                        {skill}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Or type custom skill"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSkill(skillInput);
                  }
                }}
                className="flex-1"
              />
              <Button 
                type="button" 
                variant="outline" 
                size="icon"
                onClick={() => addSkill(skillInput)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {skills.map(skill => (
                <Badge 
                  key={skill.id} 
                  variant="secondary"
                  className="flex items-center gap-1"
                >
                  {skill.name}
                  <button
                    type="button"
                    onClick={() => removeSkill(skill.id)}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional information about the candidate..."
              rows={4}
            />
          </div>

          {initialData && (
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as CandidateStatus)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="screening">Screening</SelectItem>
                  <SelectItem value="interviewing">Interviewing</SelectItem>
                  <SelectItem value="hired">Hired</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {initialData ? 'Update Candidate' : 'Add Candidate'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
