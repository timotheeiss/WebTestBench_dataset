import { Candidate, Interviewer } from '@/types/candidate';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge } from './StatusBadge';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  Phone, 
  Calendar, 
  MessageSquare, 
  CheckCircle2, 
  XCircle,
  MoreHorizontal,
  Clock
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';

interface CandidateCardProps {
  candidate: Candidate;
  interviewers: Interviewer[];
  onScheduleInterview: (candidate: Candidate) => void;
  onSubmitFeedback: (candidate: Candidate) => void;
  onUpdateStatus: (id: string, status: 'hired' | 'rejected') => void;
  onViewDetails: (candidate: Candidate) => void;
}

export function CandidateCard({
  candidate,
  interviewers,
  onScheduleInterview,
  onSubmitFeedback,
  onUpdateStatus,
  onViewDetails,
}: CandidateCardProps) {
  const latestInterview = candidate.interviews[candidate.interviews.length - 1];
  const interviewer = latestInterview 
    ? interviewers.find(i => i.id === latestInterview.interviewerId)
    : null;

  return (
    <Card className="card-hover animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <h3 
              className="font-semibold text-lg cursor-pointer hover:text-primary transition-colors"
              onClick={() => onViewDetails(candidate)}
            >
              {candidate.firstName} {candidate.lastName}
            </h3>
            <p className="text-sm text-muted-foreground">{candidate.position}</p>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={candidate.status} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onViewDetails(candidate)}>
                  View Details
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onScheduleInterview(candidate)}>
                  <Calendar className="mr-2 h-4 w-4" />
                  Schedule Interview
                </DropdownMenuItem>
                {latestInterview && latestInterview.status === 'scheduled' && (
                  <DropdownMenuItem onClick={() => onSubmitFeedback(candidate)}>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Submit Feedback
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onUpdateStatus(candidate.id, 'hired')}
                  className="text-success"
                  disabled={candidate.status === 'hired'}
                >
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  Mark as Hired
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => onUpdateStatus(candidate.id, 'rejected')}
                  className="text-destructive"
                  disabled={candidate.status === 'rejected'}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            <span>{candidate.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            <span>{candidate.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>{candidate.experience} experience</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {candidate.skills.slice(0, 4).map(skill => (
            <Badge key={skill.id} variant="secondary" className="text-xs">
              {skill.name}
            </Badge>
          ))}
          {candidate.skills.length > 4 && (
            <Badge variant="outline" className="text-xs">
              +{candidate.skills.length - 4} more
            </Badge>
          )}
        </div>

        {latestInterview && (
          <div className="pt-3 border-t">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>
                  {format(new Date(latestInterview.date), 'MMM d, yyyy h:mm a')}
                </span>
              </div>
              {interviewer && (
                <span className="text-muted-foreground">
                  with {interviewer.name}
                </span>
              )}
            </div>
            {latestInterview.feedback && (
              <div className="mt-2 flex items-center gap-2">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map(star => (
                    <span 
                      key={star} 
                      className={star <= latestInterview.feedback!.rating ? 'text-warning' : 'text-muted'}
                    >
                      ★
                    </span>
                  ))}
                </div>
                <span className="text-xs text-muted-foreground">
                  {latestInterview.feedback.recommendation.replace('_', ' ')}
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
