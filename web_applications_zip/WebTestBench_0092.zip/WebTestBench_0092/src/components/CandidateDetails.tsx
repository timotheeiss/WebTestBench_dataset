import { Candidate, Interviewer } from '@/types/candidate';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from './StatusBadge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Mail, 
  Phone, 
  Calendar, 
  Clock, 
  User, 
  FileText,
  Star,
  Download,
  CheckCircle2,
  XCircle,
  Edit,
} from 'lucide-react';
import { format } from 'date-fns';
import { downloadICSFile } from '@/utils/calendar';

interface CandidateDetailsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidate: Candidate | null;
  interviewers: Interviewer[];
  onScheduleInterview: (candidate: Candidate) => void;
  onSubmitFeedback: (candidate: Candidate) => void;
  onUpdateStatus: (id: string, status: 'hired' | 'rejected') => void;
  onEdit: (candidate: Candidate) => void;
}

export function CandidateDetails({
  open,
  onOpenChange,
  candidate,
  interviewers,
  onScheduleInterview,
  onSubmitFeedback,
  onUpdateStatus,
  onEdit,
}: CandidateDetailsProps) {
  if (!candidate) return null;

  const getInterviewer = (id: string) => interviewers.find(i => i.id === id);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <SheetTitle className="text-2xl">
                {candidate.firstName} {candidate.lastName}
              </SheetTitle>
              <p className="text-muted-foreground">{candidate.position}</p>
            </div>
            <StatusBadge status={candidate.status} />
          </div>
          
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => onEdit(candidate)}>
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button size="sm" onClick={() => onScheduleInterview(candidate)}>
              <Calendar className="h-4 w-4 mr-1" />
              Schedule
            </Button>
            {candidate.status !== 'hired' && candidate.status !== 'rejected' && (
              <>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="text-success border-success hover:bg-success hover:text-success-foreground"
                  onClick={() => onUpdateStatus(candidate.id, 'hired')}
                >
                  <CheckCircle2 className="h-4 w-4 mr-1" />
                  Hire
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground"
                  onClick={() => onUpdateStatus(candidate.id, 'rejected')}
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </>
            )}
          </div>
        </SheetHeader>

        <Tabs defaultValue="overview" className="mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="interviews">Interviews</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <a href={`mailto:${candidate.email}`} className="text-primary hover:underline">
                    {candidate.email}
                  </a>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{candidate.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{candidate.experience} experience</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {candidate.skills.map(skill => (
                    <Badge key={skill.id} variant="secondary">
                      {skill.name}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Timeline</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Created</span>
                  <span>{format(new Date(candidate.createdAt), 'PPP')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Updated</span>
                  <span>{format(new Date(candidate.updatedAt), 'PPP')}</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="interviews" className="space-y-4 mt-4">
            {candidate.interviews.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">No interviews scheduled yet</p>
                  <Button 
                    className="mt-4" 
                    onClick={() => onScheduleInterview(candidate)}
                  >
                    Schedule Interview
                  </Button>
                </CardContent>
              </Card>
            ) : (
              candidate.interviews.map(interview => {
                const interviewer = getInterviewer(interview.interviewerId);
                return (
                  <Card key={interview.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-medium">
                          {format(new Date(interview.date), 'PPP')} at {format(new Date(interview.date), 'p')}
                        </CardTitle>
                        <Badge variant={
                          interview.status === 'completed' ? 'default' :
                          interview.status === 'scheduled' ? 'secondary' : 'destructive'
                        }>
                          {interview.status}
                        </Badge>
                      </div>
                      {interviewer && (
                        <p className="text-sm text-muted-foreground">
                          Interviewer: {interviewer.name} ({interviewer.department})
                        </p>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {interview.status === 'scheduled' && interviewer && (
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => downloadICSFile(interview, candidate, interviewer)}
                          >
                            <Download className="h-4 w-4 mr-1" />
                            Export to Calendar
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => onSubmitFeedback(candidate)}
                          >
                            Submit Feedback
                          </Button>
                        </div>
                      )}
                      
                      {interview.feedback && (
                        <div className="space-y-3 pt-3 border-t">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">Rating:</span>
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map(star => (
                                <Star 
                                  key={star}
                                  className={`h-4 w-4 ${
                                    star <= interview.feedback!.rating 
                                      ? 'fill-warning text-warning' 
                                      : 'text-muted'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <span className="text-muted-foreground">Technical</span>
                              <p className="font-medium">{interview.feedback.technicalSkills}/5</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Communication</span>
                              <p className="font-medium">{interview.feedback.communication}/5</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Culture Fit</span>
                              <p className="font-medium">{interview.feedback.cultureFit}/5</p>
                            </div>
                          </div>
                          
                          <div>
                            <span className="text-sm text-muted-foreground">Recommendation:</span>
                            <Badge 
                              variant="outline"
                              className={`ml-2 ${
                                interview.feedback.recommendation.includes('yes') 
                                  ? 'border-success text-success' 
                                  : 'border-destructive text-destructive'
                              }`}
                            >
                              {interview.feedback.recommendation.replace('_', ' ')}
                            </Badge>
                          </div>
                          
                          <div>
                            <span className="text-sm text-muted-foreground">Comments:</span>
                            <p className="mt-1 text-sm">{interview.feedback.comments}</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>

          <TabsContent value="notes" className="mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Candidate Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                {candidate.notes ? (
                  <p className="text-sm whitespace-pre-wrap">{candidate.notes}</p>
                ) : (
                  <p className="text-sm text-muted-foreground italic">No notes added yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
