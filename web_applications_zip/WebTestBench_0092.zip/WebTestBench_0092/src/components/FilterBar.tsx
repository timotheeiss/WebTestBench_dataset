import { CandidateStatus } from '@/types/candidate';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FilterBarProps {
  activeFilter: CandidateStatus | 'all';
  onFilterChange: (filter: CandidateStatus | 'all') => void;
  counts: Record<CandidateStatus | 'all', number>;
}

const filters: { value: CandidateStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'new', label: 'New' },
  { value: 'screening', label: 'Screening' },
  { value: 'interviewing', label: 'Interviewing' },
  { value: 'hired', label: 'Hired' },
  { value: 'rejected', label: 'Rejected' },
];

export function FilterBar({ activeFilter, onFilterChange, counts }: FilterBarProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {filters.map(filter => (
        <Button
          key={filter.value}
          variant={activeFilter === filter.value ? 'default' : 'outline'}
          size="sm"
          onClick={() => onFilterChange(filter.value)}
          className={cn(
            'whitespace-nowrap',
            activeFilter === filter.value && 'shadow-sm'
          )}
        >
          {filter.label}
          <span className={cn(
            'ml-2 px-1.5 py-0.5 rounded-full text-xs',
            activeFilter === filter.value 
              ? 'bg-primary-foreground/20 text-primary-foreground'
              : 'bg-muted text-muted-foreground'
          )}>
            {counts[filter.value]}
          </span>
        </Button>
      ))}
    </div>
  );
}
