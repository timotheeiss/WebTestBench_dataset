import { useState } from 'react';
import { Candidate, InterviewFeedback } from '@/types/candidate';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeedbackDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidate: Candidate | null;
  onSubmit: (candidateId: string, interviewId: string, feedback: InterviewFeedback) => void;
}

export function FeedbackDialog({
  open,
  onOpenChange,
  candidate,
  onSubmit,
}: FeedbackDialogProps) {
  const [rating, setRating] = useState(3);
  const [technicalSkills, setTechnicalSkills] = useState([3]);
  const [communication, setCommunication] = useState([3]);
  const [cultureFit, setCultureFit] = useState([3]);
  const [comments, setComments] = useState('');
  const [recommendation, setRecommendation] = useState<InterviewFeedback['recommendation']>('yes');
  const [hoveredStar, setHoveredStar] = useState(0);

  const pendingInterview = candidate?.interviews.find(i => i.status === 'scheduled');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!candidate || !pendingInterview) return;

    const feedback: InterviewFeedback = {
      rating,
      technicalSkills: technicalSkills[0],
      communication: communication[0],
      cultureFit: cultureFit[0],
      comments,
      recommendation,
      submittedAt: new Date(),
    };

    onSubmit(candidate.id, pendingInterview.id, feedback);
    onOpenChange(false);
    resetForm();
  };

  const resetForm = () => {
    setRating(3);
    setTechnicalSkills([3]);
    setCommunication([3]);
    setCultureFit([3]);
    setComments('');
    setRecommendation('yes');
    setHoveredStar(0);
  };

  const recommendationLabels = {
    strong_yes: { label: 'Strong Yes', description: 'Exceptional candidate, hire immediately' },
    yes: { label: 'Yes', description: 'Good candidate, recommend moving forward' },
    no: { label: 'No', description: 'Does not meet requirements' },
    strong_no: { label: 'Strong No', description: 'Significant concerns, do not proceed' },
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit Interview Feedback</DialogTitle>
          <DialogDescription>
            {candidate && (
              <>Provide your assessment of <strong>{candidate.firstName} {candidate.lastName}</strong> for the {candidate.position} role.</>
            )}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Overall Rating */}
          <div className="space-y-2">
            <Label>Overall Rating</Label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredStar(star)}
                  onMouseLeave={() => setHoveredStar(0)}
                  className="p-1 transition-transform hover:scale-110"
                >
                  <Star 
                    className={cn(
                      'h-8 w-8 transition-colors',
                      star <= (hoveredStar || rating) 
                        ? 'fill-warning text-warning' 
                        : 'text-muted-foreground'
                    )}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Detailed Ratings */}
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Technical Skills</Label>
                <span className="text-sm text-muted-foreground">{technicalSkills[0]}/5</span>
              </div>
              <Slider
                value={technicalSkills}
                onValueChange={setTechnicalSkills}
                min={1}
                max={5}
                step={1}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Communication</Label>
                <span className="text-sm text-muted-foreground">{communication[0]}/5</span>
              </div>
              <Slider
                value={communication}
                onValueChange={setCommunication}
                min={1}
                max={5}
                step={1}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Culture Fit</Label>
                <span className="text-sm text-muted-foreground">{cultureFit[0]}/5</span>
              </div>
              <Slider
                value={cultureFit}
                onValueChange={setCultureFit}
                min={1}
                max={5}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          {/* Recommendation */}
          <div className="space-y-2">
            <Label>Recommendation</Label>
            <Select value={recommendation} onValueChange={(v) => setRecommendation(v as InterviewFeedback['recommendation'])}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(recommendationLabels).map(([key, { label, description }]) => (
                  <SelectItem key={key} value={key}>
                    <div className="flex flex-col">
                      <span className={cn(
                        key === 'strong_yes' && 'text-success',
                        key === 'yes' && 'text-info',
                        key === 'no' && 'text-warning',
                        key === 'strong_no' && 'text-destructive'
                      )}>{label}</span>
                      <span className="text-xs text-muted-foreground">{description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Comments */}
          <div className="space-y-2">
            <Label htmlFor="comments">Comments</Label>
            <Textarea
              id="comments"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Share your detailed feedback about the candidate..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              Submit Feedback
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
