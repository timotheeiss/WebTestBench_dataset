import { CandidateStatus } from '@/types/candidate';
import { cn } from '@/lib/utils';

interface StatusBadgeProps {
  status: CandidateStatus;
  className?: string;
}

const statusConfig: Record<CandidateStatus, { label: string; className: string }> = {
  new: { label: 'New', className: 'status-new' },
  screening: { label: 'Screening', className: 'status-screening' },
  interviewing: { label: 'Interviewing', className: 'status-interviewing' },
  hired: { label: 'Hired', className: 'status-hired' },
  rejected: { label: 'Rejected', className: 'status-rejected' },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <span className={cn('status-badge', config.className, className)}>
      {config.label}
    </span>
  );
}
