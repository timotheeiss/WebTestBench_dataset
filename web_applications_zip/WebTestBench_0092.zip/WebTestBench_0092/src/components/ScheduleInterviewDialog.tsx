import { useState } from 'react';
import { Candidate, Interviewer, Interview } from '@/types/candidate';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { CalendarIcon, Download, Bell } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { downloadICSFile } from '@/utils/calendar';
import { useToast } from '@/hooks/use-toast';

interface ScheduleInterviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidate: Candidate | null;
  interviewers: Interviewer[];
  onSchedule: (candidateId: string, interview: Omit<Interview, 'id' | 'candidateId' | 'status'>) => Interview;
}

export function ScheduleInterviewDialog({
  open,
  onOpenChange,
  candidate,
  interviewers,
  onSchedule,
}: ScheduleInterviewDialogProps) {
  const [date, setDate] = useState<Date | undefined>();
  const [time, setTime] = useState('10:00');
  const [interviewerId, setInterviewerId] = useState('');
  const [reminderSet, setReminderSet] = useState(true);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!candidate || !date || !interviewerId) return;

    const [hours, minutes] = time.split(':').map(Number);
    const interviewDate = new Date(date);
    interviewDate.setHours(hours, minutes, 0, 0);

    const interview = onSchedule(candidate.id, {
      date: interviewDate,
      interviewerId,
      reminderSet,
    });

    const interviewer = interviewers.find(i => i.id === interviewerId);
    
    if (reminderSet) {
      toast({
        title: 'Reminder Set',
        description: `You'll be reminded about the interview with ${candidate.firstName} ${candidate.lastName}`,
      });
    }

    // Option to export to calendar
    if (interviewer) {
      toast({
        title: 'Interview Scheduled',
        description: `Interview with ${candidate.firstName} ${candidate.lastName} scheduled for ${format(interviewDate, 'PPP')} at ${time}`,
        action: (
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => downloadICSFile(interview, candidate, interviewer)}
          >
            <Download className="h-4 w-4 mr-1" />
            Add to Calendar
          </Button>
        ),
      });
    }

    onOpenChange(false);
    resetForm();
  };

  const resetForm = () => {
    setDate(undefined);
    setTime('10:00');
    setInterviewerId('');
    setReminderSet(true);
  };

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Schedule Interview</DialogTitle>
          <DialogDescription>
            {candidate && (
              <>Schedule an interview with <strong>{candidate.firstName} {candidate.lastName}</strong> for the {candidate.position} position.</>
            )}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label>Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !date && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP') : 'Select a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="time">Time</Label>
            <Select value={time} onValueChange={setTime}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {timeSlots.map(slot => (
                  <SelectItem key={slot} value={slot}>
                    {slot}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="interviewer">Interviewer</Label>
            <Select value={interviewerId} onValueChange={setInterviewerId}>
              <SelectTrigger>
                <SelectValue placeholder="Select an interviewer" />
              </SelectTrigger>
              <SelectContent>
                {interviewers.map(interviewer => (
                  <SelectItem key={interviewer.id} value={interviewer.id}>
                    <div className="flex flex-col">
                      <span>{interviewer.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {interviewer.department}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-sm">Set Reminder</p>
                <p className="text-xs text-muted-foreground">
                  Get notified before the interview
                </p>
              </div>
            </div>
            <Switch 
              checked={reminderSet} 
              onCheckedChange={setReminderSet}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!date || !interviewerId}
            >
              Schedule Interview
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
