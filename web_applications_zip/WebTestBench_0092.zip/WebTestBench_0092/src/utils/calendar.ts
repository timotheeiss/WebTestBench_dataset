import { Interview, Candidate, Interviewer } from '@/types/candidate';
import { format } from 'date-fns';

export function generateICSContent(
  interview: Interview,
  candidate: Candidate,
  interviewer: Interviewer
): string {
  const startDate = new Date(interview.date);
  const endDate = new Date(startDate.getTime() + 60 * 60 * 1000); // 1 hour duration

  const formatICSDate = (date: Date): string => {
    return format(date, "yyyyMMdd'T'HHmmss");
  };

  const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Talent Hub//Interview Scheduler//EN
BEGIN:VEVENT
UID:${interview.id}@talenthub.app
DTSTAMP:${formatICSDate(new Date())}
DTSTART:${formatICSDate(startDate)}
DTEND:${formatICSDate(endDate)}
SUMMARY:Interview: ${candidate.firstName} ${candidate.lastName} - ${candidate.position}
DESCRIPTION:Interview with ${candidate.firstName} ${candidate.lastName} for the ${candidate.position} position.\\n\\nCandidate Email: ${candidate.email}\\nCandidate Phone: ${candidate.phone}
ORGANIZER:mailto:${interviewer.email}
ATTENDEE:mailto:${candidate.email}
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

  return icsContent;
}

export function downloadICSFile(
  interview: Interview,
  candidate: Candidate,
  interviewer: Interviewer
): void {
  const icsContent = generateICSContent(interview, candidate, interviewer);
  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `interview-${candidate.lastName}-${format(interview.date, 'yyyy-MM-dd')}.ics`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
