import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAssets } from '@/contexts/AssetContext';
import { DataAsset } from '@/types';
import { AssetCard } from '@/components/AssetCard';
import { AssetFormDialog } from '@/components/AssetFormDialog';
import { DeleteConfirmDialog } from '@/components/DeleteConfirmDialog';
import { Avatar } from '@/components/Avatar';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Database, Mail } from 'lucide-react';

const OwnerDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { people, getAssetsByOwner, deleteAsset } = useAssets();
  const [formOpen, setFormOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<DataAsset | null>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; asset: DataAsset | null }>({
    open: false,
    asset: null,
  });

  const person = people.find((p) => p.id === id);
  const assets = id ? getAssetsByOwner(id) : [];

  if (!person) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-background">
        <div className="container mx-auto px-6 py-8">
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <h3 className="text-lg font-medium text-foreground mb-1">
              Owner not found
            </h3>
            <p className="text-muted-foreground mb-4">
              The requested owner does not exist
            </p>
            <Link to="/owners">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Owners
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleEdit = (asset: DataAsset) => {
    setEditingAsset(asset);
    setFormOpen(true);
  };

  const handleDelete = (assetId: string) => {
    const asset = assets.find((a) => a.id === assetId);
    if (asset) {
      setDeleteDialog({ open: true, asset });
    }
  };

  const confirmDelete = () => {
    if (deleteDialog.asset) {
      deleteAsset(deleteDialog.asset.id);
      setDeleteDialog({ open: false, asset: null });
    }
  };

  const handleFormClose = (open: boolean) => {
    setFormOpen(open);
    if (!open) {
      setEditingAsset(null);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-background">
      <div className="container mx-auto px-6 py-8">
        {/* Back Link */}
        <Link
          to="/owners"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Owners
        </Link>

        {/* Owner Info */}
        <div className="bg-card border border-border rounded-xl p-6 mb-8 shadow-soft">
          <div className="flex items-center gap-4">
            <Avatar initials={person.avatar} size="lg" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">{person.name}</h1>
              <div className="flex items-center gap-2 text-muted-foreground mt-1">
                <Mail className="h-4 w-4" />
                <span>{person.email}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Assets Section */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-foreground">
            Owned Assets ({assets.length})
          </h2>
        </div>

        {assets.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {assets.map((asset) => (
              <AssetCard
                key={asset.id}
                asset={asset}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center bg-card border border-border rounded-xl">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Database className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-1">
              No assets assigned
            </h3>
            <p className="text-muted-foreground">
              {person.name} doesn't own any data assets yet
            </p>
          </div>
        )}
      </div>

      {/* Dialogs */}
      <AssetFormDialog
        open={formOpen}
        onOpenChange={handleFormClose}
        asset={editingAsset}
      />
      <DeleteConfirmDialog
        open={deleteDialog.open}
        onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}
        onConfirm={confirmDelete}
        assetName={deleteDialog.asset?.name || ''}
      />
    </div>
  );
};

export default OwnerDetail;
