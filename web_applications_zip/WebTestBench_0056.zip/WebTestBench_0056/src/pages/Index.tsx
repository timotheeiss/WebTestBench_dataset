import { useState } from 'react';
import { useAssets } from '@/contexts/AssetContext';
import { DataAsset } from '@/types';
import { AssetCard } from '@/components/AssetCard';
import { AssetFormDialog } from '@/components/AssetFormDialog';
import { DeleteConfirmDialog } from '@/components/DeleteConfirmDialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search, Database } from 'lucide-react';

const Index = () => {
  const { assets } = useAssets();
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<DataAsset | null>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; asset: DataAsset | null }>({
    open: false,
    asset: null,
  });
  const { deleteAsset } = useAssets();

  const filteredAssets = assets.filter(
    (asset) =>
      asset.name.toLowerCase().includes(search.toLowerCase()) ||
      asset.description.toLowerCase().includes(search.toLowerCase())
  );

  const handleEdit = (asset: DataAsset) => {
    setEditingAsset(asset);
    setFormOpen(true);
  };

  const handleDelete = (id: string) => {
    const asset = assets.find((a) => a.id === id);
    if (asset) {
      setDeleteDialog({ open: true, asset });
    }
  };

  const confirmDelete = () => {
    if (deleteDialog.asset) {
      deleteAsset(deleteDialog.asset.id);
      setDeleteDialog({ open: false, asset: null });
    }
  };

  const handleFormClose = (open: boolean) => {
    setFormOpen(open);
    if (!open) {
      setEditingAsset(null);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-background">
      <div className="container mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Data Assets</h1>
            <p className="text-muted-foreground mt-1">
              Manage your data assets and their ownership
            </p>
          </div>
          <Button onClick={() => setFormOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Add Asset
          </Button>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search assets..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card"
          />
        </div>

        {/* Assets Grid */}
        {filteredAssets.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredAssets.map((asset) => (
              <AssetCard
                key={asset.id}
                asset={asset}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Database className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-1">
              {search ? 'No assets found' : 'No data assets yet'}
            </h3>
            <p className="text-muted-foreground mb-4">
              {search
                ? 'Try adjusting your search terms'
                : 'Get started by adding your first data asset'}
            </p>
            {!search && (
              <Button onClick={() => setFormOpen(true)} variant="outline" className="gap-2">
                <Plus className="h-4 w-4" />
                Add Your First Asset
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Dialogs */}
      <AssetFormDialog
        open={formOpen}
        onOpenChange={handleFormClose}
        asset={editingAsset}
      />
      <DeleteConfirmDialog
        open={deleteDialog.open}
        onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}
        onConfirm={confirmDelete}
        assetName={deleteDialog.asset?.name || ''}
      />
    </div>
  );
};

export default Index;
