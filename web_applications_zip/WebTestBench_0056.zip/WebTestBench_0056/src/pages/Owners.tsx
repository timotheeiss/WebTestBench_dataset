import { useAssets } from '@/contexts/AssetContext';
import { OwnerCard } from '@/components/OwnerCard';
import { Users } from 'lucide-react';

const Owners = () => {
  const { people } = useAssets();

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-background">
      <div className="container mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground">Owners</h1>
          <p className="text-muted-foreground mt-1">
            View data assets by owner
          </p>
        </div>

        {/* Owners Grid */}
        {people.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {people.map((person) => (
              <OwnerCard key={person.id} person={person} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-1">
              No owners found
            </h3>
            <p className="text-muted-foreground">
              There are no people in the system yet
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Owners;
