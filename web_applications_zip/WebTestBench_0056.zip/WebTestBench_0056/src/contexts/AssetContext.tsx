import React, { createContext, useContext, useState, ReactNode } from 'react';
import { DataAsset, Person } from '@/types';
import { initialAssets, people } from '@/data/mockData';

interface AssetContextType {
  assets: DataAsset[];
  people: Person[];
  addAsset: (asset: Omit<DataAsset, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateAsset: (id: string, asset: Partial<DataAsset>) => void;
  deleteAsset: (id: string) => void;
  getOwnerById: (id: string | null) => Person | undefined;
  getAssetsByOwner: (ownerId: string) => DataAsset[];
}

const AssetContext = createContext<AssetContextType | undefined>(undefined);

export function AssetProvider({ children }: { children: ReactNode }) {
  const [assets, setAssets] = useState<DataAsset[]>(initialAssets);

  const addAsset = (assetData: Omit<DataAsset, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newAsset: DataAsset = {
      ...assetData,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setAssets(prev => [...prev, newAsset]);
  };

  const updateAsset = (id: string, assetData: Partial<DataAsset>) => {
    setAssets(prev =>
      prev.map(asset =>
        asset.id === id
          ? { ...asset, ...assetData, updatedAt: new Date() }
          : asset
      )
    );
  };

  const deleteAsset = (id: string) => {
    setAssets(prev => prev.filter(asset => asset.id !== id));
  };

  const getOwnerById = (id: string | null) => {
    if (!id) return undefined;
    return people.find(person => person.id === id);
  };

  const getAssetsByOwner = (ownerId: string) => {
    return assets.filter(asset => asset.ownerId === ownerId);
  };

  return (
    <AssetContext.Provider
      value={{
        assets,
        people,
        addAsset,
        updateAsset,
        deleteAsset,
        getOwnerById,
        getAssetsByOwner,
      }}
    >
      {children}
    </AssetContext.Provider>
  );
}

export function useAssets() {
  const context = useContext(AssetContext);
  if (context === undefined) {
    throw new Error('useAssets must be used within an AssetProvider');
  }
  return context;
}
