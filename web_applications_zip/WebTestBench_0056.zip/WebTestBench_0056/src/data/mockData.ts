import { Person, DataAsset } from '@/types';

export const people: Person[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    email: 'sarah.chen@company.com',
    avatar: 'SC',
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    email: 'marcus.j@company.com',
    avatar: 'MJ',
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    email: 'elena.r@company.com',
    avatar: 'ER',
  },
  {
    id: '4',
    name: 'David Kim',
    email: 'david.kim@company.com',
    avatar: 'DK',
  },
  {
    id: '5',
    name: 'Priya Patel',
    email: 'priya.p@company.com',
    avatar: 'PP',
  },
];

export const initialAssets: DataAsset[] = [
  {
    id: '1',
    name: 'Customer Database',
    description: 'Primary customer information including contact details, preferences, and purchase history.',
    ownerId: '1',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-03-20'),
  },
  {
    id: '2',
    name: 'Product Catalog',
    description: 'Complete inventory of products with pricing, specifications, and availability status.',
    ownerId: '2',
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-03-18'),
  },
  {
    id: '3',
    name: 'Analytics Configuration',
    description: 'Settings and parameters for the analytics dashboard and reporting tools.',
    ownerId: '3',
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-03-22'),
  },
  {
    id: '4',
    name: 'User Permissions Matrix',
    description: 'Access control definitions for all system roles and user groups.',
    ownerId: '1',
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-03-15'),
  },
  {
    id: '5',
    name: 'API Keys Registry',
    description: 'Secure storage of API keys and tokens for third-party integrations.',
    ownerId: '4',
    createdAt: new Date('2024-03-01'),
    updatedAt: new Date('2024-03-21'),
  },
  {
    id: '6',
    name: 'Email Templates',
    description: 'Collection of email templates for automated communications and marketing campaigns.',
    ownerId: null,
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date('2024-03-19'),
  },
];
