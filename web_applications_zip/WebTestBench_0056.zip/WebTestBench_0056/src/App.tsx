import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AssetProvider } from "@/contexts/AssetContext";
import { Header } from "@/components/Header";
import Index from "./pages/Index";
import Owners from "./pages/Owners";
import OwnerDetail from "./pages/OwnerDetail";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AssetProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Header />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/owners" element={<Owners />} />
            <Route path="/owner/:id" element={<OwnerDetail />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AssetProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
