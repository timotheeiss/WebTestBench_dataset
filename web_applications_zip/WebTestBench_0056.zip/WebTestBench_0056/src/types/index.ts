export interface Person {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

export interface DataAsset {
  id: string;
  name: string;
  description: string;
  ownerId: string | null;
  createdAt: Date;
  updatedAt: Date;
}
