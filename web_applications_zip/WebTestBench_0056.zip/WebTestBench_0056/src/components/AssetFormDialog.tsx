import { useState, useEffect } from 'react';
import { DataAsset } from '@/types';
import { useAssets } from '@/contexts/AssetContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar } from './Avatar';

interface AssetFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  asset?: DataAsset | null;
}

export function AssetFormDialog({ open, onOpenChange, asset }: AssetFormDialogProps) {
  const { people, addAsset, updateAsset } = useAssets();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [ownerId, setOwnerId] = useState<string>('');

  const isEditing = !!asset;

  useEffect(() => {
    if (asset) {
      setName(asset.name);
      setDescription(asset.description);
      setOwnerId(asset.ownerId || '');
    } else {
      setName('');
      setDescription('');
      setOwnerId('');
    }
  }, [asset, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const assetData = {
      name: name.trim(),
      description: description.trim(),
      ownerId: ownerId || null,
    };

    if (isEditing && asset) {
      updateAsset(asset.id, assetData);
    } else {
      addAsset(assetData);
    }

    onOpenChange(false);
  };

  const isValid = name.trim().length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            {isEditing ? 'Edit Data Asset' : 'Add New Data Asset'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5 mt-2">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium">
              Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Customer Database"
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium">
              Description
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what this data asset contains..."
              rows={3}
              className="bg-background resize-none"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="owner" className="text-sm font-medium">
              Primary Owner
            </Label>
            <Select value={ownerId} onValueChange={setOwnerId}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select an owner" />
              </SelectTrigger>
              <SelectContent className="bg-popover">
                <SelectItem value="">
                  <span className="text-muted-foreground italic">No owner</span>
                </SelectItem>
                {people.map((person) => (
                  <SelectItem key={person.id} value={person.id}>
                    <div className="flex items-center gap-2">
                      <Avatar initials={person.avatar} size="sm" />
                      <span>{person.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={!isValid}>
              {isEditing ? 'Save Changes' : 'Add Asset'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
