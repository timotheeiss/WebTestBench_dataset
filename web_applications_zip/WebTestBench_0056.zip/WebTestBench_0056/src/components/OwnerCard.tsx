import { Person } from '@/types';
import { useAssets } from '@/contexts/AssetContext';
import { Avatar } from './Avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Database } from 'lucide-react';
import { Link } from 'react-router-dom';

interface OwnerCardProps {
  person: Person;
}

export function OwnerCard({ person }: OwnerCardProps) {
  const { getAssetsByOwner } = useAssets();
  const assetCount = getAssetsByOwner(person.id).length;

  return (
    <Link to={`/owner/${person.id}`}>
      <Card className="group bg-card border-border shadow-soft hover:shadow-card-hover transition-all duration-300 cursor-pointer animate-fade-in">
        <CardContent className="p-5">
          <div className="flex items-center gap-4">
            <Avatar initials={person.avatar} size="lg" />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {person.name}
              </h3>
              <p className="text-sm text-muted-foreground truncate">
                {person.email}
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground bg-muted px-3 py-1.5 rounded-full">
              <Database className="h-4 w-4" />
              <span className="text-sm font-medium">{assetCount}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
