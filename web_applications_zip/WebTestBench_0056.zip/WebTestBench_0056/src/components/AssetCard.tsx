import { DataAsset } from '@/types';
import { useAssets } from '@/contexts/AssetContext';
import { Avatar } from './Avatar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2, User } from 'lucide-react';

interface AssetCardProps {
  asset: DataAsset;
  onEdit: (asset: DataAsset) => void;
  onDelete: (id: string) => void;
}

export function AssetCard({ asset, onEdit, onDelete }: AssetCardProps) {
  const { getOwnerById } = useAssets();
  const owner = getOwnerById(asset.ownerId);

  return (
    <Card className="group bg-card border-border shadow-soft hover:shadow-card-hover transition-all duration-300 animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <CardTitle className="text-base font-semibold text-foreground leading-tight">
            {asset.name}
          </CardTitle>
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              onClick={() => onEdit(asset)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={() => onDelete(asset.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {asset.description}
        </p>
        <div className="flex items-center gap-2">
          {owner ? (
            <>
              <Avatar initials={owner.avatar} size="sm" />
              <span className="text-sm font-medium text-foreground">
                {owner.name}
              </span>
            </>
          ) : (
            <div className="flex items-center gap-2 text-tertiary">
              <div className="w-7 h-7 rounded-full border-2 border-dashed border-border flex items-center justify-center">
                <User className="h-3.5 w-3.5" />
              </div>
              <span className="text-sm italic">No owner assigned</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
