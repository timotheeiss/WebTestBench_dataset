export interface Ingredient {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  expirationDate?: string;
  category: 'produce' | 'dairy' | 'protein' | 'grains' | 'pantry' | 'frozen' | 'other';
}

export interface RecipeIngredient {
  name: string;
  quantity: number;
  unit: string;
}

export interface Recipe {
  id: string;
  name: string;
  description: string;
  prepTime: number;
  cookTime: number;
  servings: number;
  ingredients: RecipeIngredient[];
  instructions: string[];
  tags: string[];
  image?: string;
}

export interface MealSlot {
  id: string;
  dayIndex: number;
  mealType: 'breakfast' | 'lunch' | 'dinner';
  recipe: Recipe | null;
  locked: boolean;
}

export interface DietaryPreferences {
  vegetarian: boolean;
  highProtein: boolean;
  budgetFriendly: boolean;
  quickMeals: boolean;
}

export const defaultPantryItems: Ingredient[] = [
  { id: '1', name: 'Chicken Breast', quantity: 500, unit: 'g', expirationDate: '2024-12-16', category: 'protein' },
  { id: '2', name: 'Eggs', quantity: 12, unit: 'pcs', expirationDate: '2024-12-20', category: 'protein' },
  { id: '3', name: 'Spinach', quantity: 200, unit: 'g', expirationDate: '2024-12-14', category: 'produce' },
  { id: '4', name: 'Tomatoes', quantity: 6, unit: 'pcs', expirationDate: '2024-12-15', category: 'produce' },
  { id: '5', name: 'Onions', quantity: 4, unit: 'pcs', expirationDate: '2024-12-25', category: 'produce' },
  { id: '6', name: 'Garlic', quantity: 2, unit: 'heads', expirationDate: '2024-12-30', category: 'produce' },
  { id: '7', name: 'Rice', quantity: 1000, unit: 'g', category: 'grains' },
  { id: '8', name: 'Pasta', quantity: 500, unit: 'g', category: 'grains' },
  { id: '9', name: 'Olive Oil', quantity: 500, unit: 'ml', category: 'pantry' },
  { id: '10', name: 'Milk', quantity: 1000, unit: 'ml', expirationDate: '2024-12-17', category: 'dairy' },
  { id: '11', name: 'Cheese', quantity: 200, unit: 'g', expirationDate: '2024-12-18', category: 'dairy' },
  { id: '12', name: 'Bell Peppers', quantity: 3, unit: 'pcs', expirationDate: '2024-12-16', category: 'produce' },
  { id: '13', name: 'Bread', quantity: 1, unit: 'loaf', expirationDate: '2024-12-15', category: 'grains' },
  { id: '14', name: 'Butter', quantity: 250, unit: 'g', expirationDate: '2024-12-28', category: 'dairy' },
  { id: '15', name: 'Greek Yogurt', quantity: 500, unit: 'g', expirationDate: '2024-12-16', category: 'dairy' },
];

export const recipes: Recipe[] = [
  {
    id: 'r1',
    name: 'Spinach & Tomato Omelette',
    description: 'A quick and nutritious breakfast loaded with fresh vegetables',
    prepTime: 5,
    cookTime: 10,
    servings: 2,
    ingredients: [
      { name: 'Eggs', quantity: 4, unit: 'pcs' },
      { name: 'Spinach', quantity: 50, unit: 'g' },
      { name: 'Tomatoes', quantity: 1, unit: 'pcs' },
      { name: 'Cheese', quantity: 30, unit: 'g' },
      { name: 'Butter', quantity: 15, unit: 'g' },
    ],
    instructions: [
      'Beat eggs in a bowl with salt and pepper',
      'Melt butter in a non-stick pan over medium heat',
      'Add spinach and diced tomatoes, sauté for 2 minutes',
      'Pour eggs over vegetables and cook until set',
      'Add cheese, fold and serve'
    ],
    tags: ['vegetarian', 'high-protein', 'quick', 'breakfast']
  },
  {
    id: 'r2',
    name: 'Garlic Chicken Stir-Fry',
    description: 'Tender chicken with colorful bell peppers in a savory garlic sauce',
    prepTime: 15,
    cookTime: 15,
    servings: 3,
    ingredients: [
      { name: 'Chicken Breast', quantity: 400, unit: 'g' },
      { name: 'Bell Peppers', quantity: 2, unit: 'pcs' },
      { name: 'Garlic', quantity: 0.5, unit: 'heads' },
      { name: 'Onions', quantity: 1, unit: 'pcs' },
      { name: 'Olive Oil', quantity: 30, unit: 'ml' },
      { name: 'Rice', quantity: 300, unit: 'g' },
    ],
    instructions: [
      'Cut chicken into bite-sized pieces and season',
      'Slice bell peppers and onions',
      'Heat oil in a wok, cook chicken until golden',
      'Add minced garlic, onions and peppers',
      'Stir-fry until vegetables are tender-crisp',
      'Serve over cooked rice'
    ],
    tags: ['high-protein', 'dinner', 'budget-friendly']
  },
  {
    id: 'r3',
    name: 'Greek Yogurt Parfait',
    description: 'Creamy yogurt layered with fresh flavors',
    prepTime: 5,
    cookTime: 0,
    servings: 1,
    ingredients: [
      { name: 'Greek Yogurt', quantity: 200, unit: 'g' },
    ],
    instructions: [
      'Layer yogurt in a glass',
      'Add toppings of choice',
      'Drizzle with honey if desired'
    ],
    tags: ['vegetarian', 'high-protein', 'quick', 'breakfast', 'budget-friendly']
  },
  {
    id: 'r4',
    name: 'Tomato Pasta Primavera',
    description: 'Classic pasta with fresh tomatoes and herbs',
    prepTime: 10,
    cookTime: 20,
    servings: 4,
    ingredients: [
      { name: 'Pasta', quantity: 400, unit: 'g' },
      { name: 'Tomatoes', quantity: 4, unit: 'pcs' },
      { name: 'Garlic', quantity: 0.5, unit: 'heads' },
      { name: 'Onions', quantity: 1, unit: 'pcs' },
      { name: 'Olive Oil', quantity: 40, unit: 'ml' },
      { name: 'Cheese', quantity: 50, unit: 'g' },
    ],
    instructions: [
      'Cook pasta according to package directions',
      'Sauté garlic and onions in olive oil',
      'Add diced tomatoes and simmer',
      'Toss with drained pasta',
      'Top with grated cheese and serve'
    ],
    tags: ['vegetarian', 'dinner', 'budget-friendly', 'lunch']
  },
  {
    id: 'r5',
    name: 'Cheesy Scrambled Eggs on Toast',
    description: 'Fluffy eggs with melted cheese on crispy toast',
    prepTime: 5,
    cookTime: 8,
    servings: 2,
    ingredients: [
      { name: 'Eggs', quantity: 4, unit: 'pcs' },
      { name: 'Cheese', quantity: 40, unit: 'g' },
      { name: 'Butter', quantity: 20, unit: 'g' },
      { name: 'Bread', quantity: 0.25, unit: 'loaf' },
      { name: 'Milk', quantity: 50, unit: 'ml' },
    ],
    instructions: [
      'Beat eggs with milk, salt and pepper',
      'Melt butter in a pan over low heat',
      'Add eggs and stir gently',
      'Add cheese when eggs are almost set',
      'Toast bread and serve eggs on top'
    ],
    tags: ['vegetarian', 'quick', 'breakfast', 'high-protein']
  },
  {
    id: 'r6',
    name: 'Chicken Rice Bowl',
    description: 'Simple and satisfying rice bowl with seasoned chicken',
    prepTime: 10,
    cookTime: 25,
    servings: 2,
    ingredients: [
      { name: 'Chicken Breast', quantity: 300, unit: 'g' },
      { name: 'Rice', quantity: 250, unit: 'g' },
      { name: 'Onions', quantity: 1, unit: 'pcs' },
      { name: 'Garlic', quantity: 0.25, unit: 'heads' },
      { name: 'Olive Oil', quantity: 20, unit: 'ml' },
    ],
    instructions: [
      'Cook rice according to package directions',
      'Season and grill chicken breast',
      'Sauté onions and garlic',
      'Slice chicken and serve over rice',
      'Top with sautéed vegetables'
    ],
    tags: ['high-protein', 'lunch', 'dinner', 'budget-friendly']
  },
  {
    id: 'r7',
    name: 'Spinach & Cheese Quesadilla',
    description: 'Crispy tortilla filled with wilted spinach and melted cheese',
    prepTime: 5,
    cookTime: 10,
    servings: 2,
    ingredients: [
      { name: 'Spinach', quantity: 100, unit: 'g' },
      { name: 'Cheese', quantity: 80, unit: 'g' },
      { name: 'Butter', quantity: 20, unit: 'g' },
    ],
    instructions: [
      'Wilt spinach in a pan',
      'Layer cheese and spinach on tortilla',
      'Fold and cook in buttered pan until golden',
      'Flip and cook other side',
      'Cut into wedges and serve'
    ],
    tags: ['vegetarian', 'quick', 'lunch', 'budget-friendly']
  },
  {
    id: 'r8',
    name: 'Bell Pepper Egg Cups',
    description: 'Eggs baked inside colorful bell pepper rings',
    prepTime: 10,
    cookTime: 20,
    servings: 2,
    ingredients: [
      { name: 'Bell Peppers', quantity: 2, unit: 'pcs' },
      { name: 'Eggs', quantity: 4, unit: 'pcs' },
      { name: 'Cheese', quantity: 40, unit: 'g' },
      { name: 'Olive Oil', quantity: 10, unit: 'ml' },
    ],
    instructions: [
      'Preheat oven to 375°F (190°C)',
      'Cut bell peppers into thick rings',
      'Place rings in oiled baking dish',
      'Crack an egg into each ring',
      'Bake until eggs are set, top with cheese'
    ],
    tags: ['vegetarian', 'high-protein', 'breakfast', 'lunch']
  },
];

export const categoryColors: Record<string, string> = {
  produce: 'bg-success/20 text-success',
  dairy: 'bg-primary/20 text-primary',
  protein: 'bg-accent/20 text-accent',
  grains: 'bg-warning/20 text-warning-foreground',
  pantry: 'bg-muted text-muted-foreground',
  frozen: 'bg-primary/30 text-primary',
  other: 'bg-secondary text-secondary-foreground',
};
