import { useState, useMemo } from 'react';
import { Utensils } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PantryManager } from '@/components/PantryManager';
import { PreferencesPanel } from '@/components/PreferencesPanel';
import { DayPlanCard } from '@/components/DayPlanCard';
import { IngredientUsagePanel } from '@/components/IngredientUsagePanel';
import { GroceryList } from '@/components/GroceryList';
import { defaultPantryItems, Ingredient, MealSlot, DietaryPreferences } from '@/data/recipes';
import { generateMealPlan, calculateIngredientUsage, generateGroceryList } from '@/utils/mealPlanner';
import { toast } from '@/hooks/use-toast';

const Index = () => {
  const [pantry, setPantry] = useState<Ingredient[]>(defaultPantryItems);
  const [mealPlan, setMealPlan] = useState<MealSlot[]>([]);
  const [numberOfDays, setNumberOfDays] = useState(5);
  const [preferences, setPreferences] = useState<DietaryPreferences>({
    vegetarian: false,
    highProtein: false,
    budgetFriendly: true,
    quickMeals: false
  });

  const handleGeneratePlan = () => {
    const lockedMeals = mealPlan.filter(m => m.locked);
    const newPlan = generateMealPlan(numberOfDays, pantry, preferences, mealPlan);
    setMealPlan(newPlan);
    
    toast({
      title: 'Meal Plan Generated!',
      description: `Created ${numberOfDays}-day plan with ${lockedMeals.length} locked meals preserved.`,
    });
  };

  const handleToggleLock = (mealId: string) => {
    setMealPlan(prev =>
      prev.map(meal =>
        meal.id === mealId ? { ...meal, locked: !meal.locked } : meal
      )
    );
  };

  const ingredientUsage = useMemo(
    () => calculateIngredientUsage(mealPlan, pantry),
    [mealPlan, pantry]
  );

  const groceryItems = useMemo(
    () => generateGroceryList(ingredientUsage),
    [ingredientUsage]
  );

  const mealsByDay = useMemo(() => {
    const grouped: Record<number, MealSlot[]> = {};
    mealPlan.forEach(meal => {
      if (!grouped[meal.dayIndex]) {
        grouped[meal.dayIndex] = [];
      }
      grouped[meal.dayIndex].push(meal);
    });
    return grouped;
  }, [mealPlan]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg gradient-fresh">
              <Utensils className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-foreground">
                Pantry Planner
              </h1>
              <p className="text-sm text-muted-foreground">
                Smart meal planning that reduces food waste
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="plan" className="space-y-6">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
            <TabsTrigger value="pantry">Pantry</TabsTrigger>
            <TabsTrigger value="plan">Meal Plan</TabsTrigger>
            <TabsTrigger value="grocery">Grocery</TabsTrigger>
          </TabsList>

          {/* Pantry Tab */}
          <TabsContent value="pantry" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PantryManager pantry={pantry} onUpdatePantry={setPantry} />
              <PreferencesPanel
                preferences={preferences}
                onUpdatePreferences={setPreferences}
                numberOfDays={numberOfDays}
                onUpdateNumberOfDays={setNumberOfDays}
                onGeneratePlan={handleGeneratePlan}
                hasExistingPlan={mealPlan.length > 0}
              />
            </div>
          </TabsContent>

          {/* Meal Plan Tab */}
          <TabsContent value="plan" className="space-y-6">
            {mealPlan.length === 0 ? (
              <div className="text-center py-16">
                <div className="p-4 rounded-full bg-muted inline-block mb-4">
                  <Utensils className="w-8 h-8 text-muted-foreground" />
                </div>
                <h2 className="font-display text-2xl font-semibold mb-2">
                  No Meal Plan Yet
                </h2>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Add ingredients to your pantry and generate a personalized meal plan
                  that prioritizes using food before it expires.
                </p>
                <PreferencesPanel
                  preferences={preferences}
                  onUpdatePreferences={setPreferences}
                  numberOfDays={numberOfDays}
                  onUpdateNumberOfDays={setNumberOfDays}
                  onGeneratePlan={handleGeneratePlan}
                  hasExistingPlan={false}
                />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <h2 className="font-display text-2xl font-semibold">
                      Your {numberOfDays}-Day Plan
                    </h2>
                    <p className="text-muted-foreground">
                      Click the lock icon to preserve meals when regenerating
                    </p>
                  </div>
                  <PreferencesPanel
                    preferences={preferences}
                    onUpdatePreferences={setPreferences}
                    numberOfDays={numberOfDays}
                    onUpdateNumberOfDays={setNumberOfDays}
                    onGeneratePlan={handleGeneratePlan}
                    hasExistingPlan={true}
                  />
                </div>

                <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {Object.entries(mealsByDay).map(([dayIndex, meals]) => (
                    <DayPlanCard
                      key={dayIndex}
                      dayIndex={Number(dayIndex)}
                      meals={meals}
                      onToggleLock={handleToggleLock}
                    />
                  ))}
                </div>

                <IngredientUsagePanel usage={ingredientUsage} />
              </div>
            )}
          </TabsContent>

          {/* Grocery Tab */}
          <TabsContent value="grocery" className="space-y-6">
            {mealPlan.length === 0 ? (
              <div className="text-center py-16">
                <div className="p-4 rounded-full bg-muted inline-block mb-4">
                  <Utensils className="w-8 h-8 text-muted-foreground" />
                </div>
                <h2 className="font-display text-2xl font-semibold mb-2">
                  Generate a Plan First
                </h2>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Your grocery list will appear here once you've created a meal plan.
                </p>
              </div>
            ) : (
              <div className="grid lg:grid-cols-2 gap-6">
                <GroceryList groceryItems={groceryItems} />
                <IngredientUsagePanel usage={ingredientUsage} />
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-12 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Pantry Planner — Reduce waste, eat well, save money</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
