import { Package, Check, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { IngredientUsage } from '@/utils/mealPlanner';

interface IngredientUsagePanelProps {
  usage: IngredientUsage[];
}

export function IngredientUsagePanel({ usage }: IngredientUsagePanelProps) {
  if (usage.length === 0) {
    return null;
  }

  const sortedUsage = [...usage].sort((a, b) => {
    // Sort by missing first, then by coverage percentage
    if (a.missing > 0 && b.missing === 0) return -1;
    if (a.missing === 0 && b.missing > 0) return 1;
    return b.totalNeeded - a.totalNeeded;
  });

  return (
    <Card className="shadow-soft">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-primary" />
          <CardTitle className="font-display text-xl">Ingredient Usage</CardTitle>
        </div>
        <p className="text-sm text-muted-foreground">
          How your pantry will be used across all planned meals
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
          {sortedUsage.map((item, index) => {
            const coveragePercent = Math.min(100, (item.availableInPantry / item.totalNeeded) * 100);
            const isFullyCovered = item.missing === 0;

            return (
              <div
                key={item.ingredientName}
                className="space-y-2 animate-fade-in"
                style={{ animationDelay: `${index * 30}ms` }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {isFullyCovered ? (
                      <Check className="w-4 h-4 text-success" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-warning" />
                    )}
                    <span className="font-medium">{item.ingredientName}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {item.availableInPantry} / {item.totalNeeded} {item.unit}
                  </div>
                </div>
                
                <Progress 
                  value={coveragePercent} 
                  className={`h-2 ${isFullyCovered ? '[&>div]:bg-success' : '[&>div]:bg-warning'}`}
                />
                
                <div className="flex flex-wrap gap-1">
                  {item.usages.map((use, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {use.recipeName}: {use.quantity} {item.unit}
                    </Badge>
                  ))}
                </div>
                
                {!isFullyCovered && (
                  <p className="text-xs text-warning font-medium">
                    Need to buy: {item.missing} {item.unit}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
