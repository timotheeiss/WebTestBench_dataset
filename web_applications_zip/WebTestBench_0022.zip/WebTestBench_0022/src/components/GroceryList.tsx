import { ShoppingCart, Check, Copy } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { IngredientUsage } from '@/utils/mealPlanner';
import { toast } from '@/hooks/use-toast';

interface GroceryListProps {
  groceryItems: IngredientUsage[];
}

export function GroceryList({ groceryItems }: GroceryListProps) {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  if (groceryItems.length === 0) {
    return (
      <Card className="shadow-soft border-success/30 bg-success/5">
        <CardContent className="p-6 flex flex-col items-center justify-center text-center">
          <div className="p-3 rounded-full bg-success/20 mb-3">
            <Check className="w-6 h-6 text-success" />
          </div>
          <h3 className="font-display font-semibold text-lg mb-1">All Set!</h3>
          <p className="text-sm text-muted-foreground">
            You have all the ingredients you need in your pantry.
          </p>
        </CardContent>
      </Card>
    );
  }

  const toggleItem = (name: string) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(name)) {
      newChecked.delete(name);
    } else {
      newChecked.add(name);
    }
    setCheckedItems(newChecked);
  };

  const copyToClipboard = () => {
    const listText = groceryItems
      .map(item => `${item.ingredientName}: ${item.missing} ${item.unit}`)
      .join('\n');
    
    navigator.clipboard.writeText(listText);
    toast({
      title: 'Copied to clipboard!',
      description: 'Your grocery list is ready to paste.',
    });
  };

  const remainingItems = groceryItems.filter(item => !checkedItems.has(item.ingredientName));

  return (
    <Card className="shadow-soft">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-accent" />
            <CardTitle className="font-display text-xl">Grocery List</CardTitle>
          </div>
          <Button variant="outline" size="sm" onClick={copyToClipboard}>
            <Copy className="w-4 h-4 mr-1" />
            Copy
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          {remainingItems.length} items needed • {checkedItems.size} checked off
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
          {groceryItems.map((item, index) => {
            const isChecked = checkedItems.has(item.ingredientName);
            
            return (
              <div
                key={item.ingredientName}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all animate-fade-in ${
                  isChecked 
                    ? 'bg-muted/50 opacity-60' 
                    : 'bg-accent/10 hover:bg-accent/20'
                }`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <Checkbox
                  id={item.ingredientName}
                  checked={isChecked}
                  onCheckedChange={() => toggleItem(item.ingredientName)}
                />
                <label
                  htmlFor={item.ingredientName}
                  className={`flex-1 cursor-pointer ${isChecked ? 'line-through' : ''}`}
                >
                  <span className="font-medium">{item.ingredientName}</span>
                  <span className="text-muted-foreground ml-2">
                    {item.missing} {item.unit}
                  </span>
                </label>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
