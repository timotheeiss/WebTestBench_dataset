import { Lock, Unlock, Clock, Users, ChefHat } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MealSlot } from '@/data/recipes';

interface MealCardProps {
  meal: MealSlot;
  onToggleLock: (mealId: string) => void;
}

const mealTypeLabels = {
  breakfast: 'Breakfast',
  lunch: 'Lunch',
  dinner: 'Dinner'
};

const mealTypeColors = {
  breakfast: 'bg-warning/20 text-warning-foreground',
  lunch: 'bg-primary/20 text-primary',
  dinner: 'bg-accent/20 text-accent'
};

export function MealCard({ meal, onToggleLock }: MealCardProps) {
  const { recipe, mealType, locked } = meal;

  if (!recipe) {
    return (
      <Card className="border-dashed border-2 bg-muted/30">
        <CardContent className="p-4 flex items-center justify-center h-[140px]">
          <p className="text-muted-foreground text-sm">No recipe assigned</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`group transition-all duration-200 hover:shadow-medium ${locked ? 'ring-2 ring-primary/50 bg-primary/5' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <Badge className={`${mealTypeColors[mealType]} text-xs`}>
            {mealTypeLabels[mealType]}
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onToggleLock(meal.id)}
            className={`h-7 w-7 ${locked ? 'text-primary' : 'text-muted-foreground opacity-0 group-hover:opacity-100'} transition-all`}
            title={locked ? 'Unlock meal' : 'Lock meal'}
          >
            {locked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
          </Button>
        </div>

        <h4 className="font-display font-semibold text-base mb-2 line-clamp-1">
          {recipe.name}
        </h4>
        
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {recipe.description}
        </p>

        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{recipe.prepTime + recipe.cookTime}m</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            <span>{recipe.servings}</span>
          </div>
          <div className="flex items-center gap-1">
            <ChefHat className="w-3 h-3" />
            <span>{recipe.ingredients.length} items</span>
          </div>
        </div>

        {locked && (
          <div className="mt-3 pt-3 border-t border-border">
            <p className="text-xs text-primary font-medium flex items-center gap-1">
              <Lock className="w-3 h-3" />
              Locked - won't change on regenerate
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
