import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MealSlot } from '@/data/recipes';
import { MealCard } from './MealCard';

interface DayPlanCardProps {
  dayIndex: number;
  meals: MealSlot[];
  onToggleLock: (mealId: string) => void;
}

const dayNames = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];

export function DayPlanCard({ dayIndex, meals, onToggleLock }: DayPlanCardProps) {
  const breakfast = meals.find(m => m.mealType === 'breakfast');
  const lunch = meals.find(m => m.mealType === 'lunch');
  const dinner = meals.find(m => m.mealType === 'dinner');

  const lockedCount = meals.filter(m => m.locked).length;

  return (
    <Card className="shadow-soft animate-fade-in" style={{ animationDelay: `${dayIndex * 100}ms` }}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="font-display text-lg">{dayNames[dayIndex]}</CardTitle>
          {lockedCount > 0 && (
            <span className="text-xs text-primary font-medium">
              {lockedCount} locked
            </span>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {breakfast && <MealCard meal={breakfast} onToggleLock={onToggleLock} />}
        {lunch && <MealCard meal={lunch} onToggleLock={onToggleLock} />}
        {dinner && <MealCard meal={dinner} onToggleLock={onToggleLock} />}
      </CardContent>
    </Card>
  );
}
