import { useState } from 'react';
import { Plus, Trash2, AlertTriangle, Calendar, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Ingredient, categoryColors } from '@/data/recipes';
import { getDaysUntilExpiration, getExpirationStatus } from '@/utils/mealPlanner';

interface PantryManagerProps {
  pantry: Ingredient[];
  onUpdatePantry: (pantry: Ingredient[]) => void;
}

export function PantryManager({ pantry, onUpdatePantry }: PantryManagerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newItem, setNewItem] = useState<Partial<Ingredient>>({
    name: '',
    quantity: 0,
    unit: 'g',
    category: 'other',
    expirationDate: ''
  });

  const handleAddItem = () => {
    if (!newItem.name || !newItem.quantity) return;
    
    const item: Ingredient = {
      id: `item-${Date.now()}`,
      name: newItem.name,
      quantity: newItem.quantity,
      unit: newItem.unit || 'g',
      category: newItem.category || 'other',
      expirationDate: newItem.expirationDate || undefined
    };
    
    onUpdatePantry([...pantry, item]);
    setNewItem({ name: '', quantity: 0, unit: 'g', category: 'other', expirationDate: '' });
    setIsAddDialogOpen(false);
  };

  const handleRemoveItem = (id: string) => {
    onUpdatePantry(pantry.filter(item => item.id !== id));
  };

  const sortedPantry = [...pantry].sort((a, b) => {
    const statusA = getExpirationStatus(a.expirationDate);
    const statusB = getExpirationStatus(b.expirationDate);
    const priority = { 'expired': 0, 'expiring-soon': 1, 'fresh': 2, 'no-date': 3 };
    return priority[statusA] - priority[statusB];
  });

  const getExpirationBadge = (expirationDate?: string) => {
    const status = getExpirationStatus(expirationDate);
    const days = getDaysUntilExpiration(expirationDate);
    
    if (status === 'no-date') return null;
    
    if (status === 'expired') {
      return (
        <Badge variant="destructive" className="text-xs animate-pulse-soft">
          <AlertTriangle className="w-3 h-3 mr-1" />
          Expired
        </Badge>
      );
    }
    
    if (status === 'expiring-soon') {
      return (
        <Badge className="bg-warning text-warning-foreground text-xs">
          <Calendar className="w-3 h-3 mr-1" />
          {days === 0 ? 'Today' : days === 1 ? 'Tomorrow' : `${days} days`}
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="text-xs text-muted-foreground">
        <Calendar className="w-3 h-3 mr-1" />
        {days} days
      </Badge>
    );
  };

  return (
    <Card className="shadow-soft">
      <CardHeader className="flex flex-row items-center justify-between pb-4">
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-primary" />
          <CardTitle className="font-display text-xl">My Pantry</CardTitle>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gradient-fresh text-primary-foreground hover:opacity-90">
              <Plus className="w-4 h-4 mr-1" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">Add Pantry Item</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Item Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Chicken Breast"
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="0"
                    value={newItem.quantity || ''}
                    onChange={(e) => setNewItem({ ...newItem, quantity: Number(e.target.value) })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select
                    value={newItem.unit}
                    onValueChange={(value) => setNewItem({ ...newItem, unit: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">grams (g)</SelectItem>
                      <SelectItem value="kg">kilograms (kg)</SelectItem>
                      <SelectItem value="ml">milliliters (ml)</SelectItem>
                      <SelectItem value="L">liters (L)</SelectItem>
                      <SelectItem value="pcs">pieces</SelectItem>
                      <SelectItem value="cups">cups</SelectItem>
                      <SelectItem value="tbsp">tablespoons</SelectItem>
                      <SelectItem value="loaf">loaf</SelectItem>
                      <SelectItem value="heads">heads</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={newItem.category}
                  onValueChange={(value) => setNewItem({ ...newItem, category: value as Ingredient['category'] })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="produce">Produce</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="protein">Protein</SelectItem>
                    <SelectItem value="grains">Grains</SelectItem>
                    <SelectItem value="pantry">Pantry Staples</SelectItem>
                    <SelectItem value="frozen">Frozen</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="expiration">Expiration Date (optional)</Label>
                <Input
                  id="expiration"
                  type="date"
                  value={newItem.expirationDate}
                  onChange={(e) => setNewItem({ ...newItem, expirationDate: e.target.value })}
                />
              </div>
              <Button onClick={handleAddItem} className="gradient-fresh text-primary-foreground">
                Add to Pantry
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
          {sortedPantry.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Your pantry is empty. Add some items to get started!
            </p>
          ) : (
            sortedPantry.map((item, index) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-lg bg-card border border-border/50 hover:border-primary/30 transition-colors animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <Badge className={`${categoryColors[item.category]} text-xs shrink-0`}>
                    {item.category}
                  </Badge>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate">{item.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {item.quantity} {item.unit}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {getExpirationBadge(item.expirationDate)}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveItem(item.id)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
