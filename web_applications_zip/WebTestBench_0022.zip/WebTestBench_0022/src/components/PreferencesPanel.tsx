import { Leaf, Dumbbell, Wallet, Clock, CalendarDays, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DietaryPreferences } from '@/data/recipes';

interface PreferencesPanelProps {
  preferences: DietaryPreferences;
  onUpdatePreferences: (preferences: DietaryPreferences) => void;
  numberOfDays: number;
  onUpdateNumberOfDays: (days: number) => void;
  onGeneratePlan: () => void;
  hasExistingPlan: boolean;
}

export function PreferencesPanel({
  preferences,
  onUpdatePreferences,
  numberOfDays,
  onUpdateNumberOfDays,
  onGeneratePlan,
  hasExistingPlan
}: PreferencesPanelProps) {
  const preferenceOptions = [
    {
      key: 'vegetarian' as keyof DietaryPreferences,
      label: 'Vegetarian',
      icon: Leaf,
      description: 'Plant-based meals only'
    },
    {
      key: 'highProtein' as keyof DietaryPreferences,
      label: 'High Protein',
      icon: Dumbbell,
      description: 'Protein-rich recipes'
    },
    {
      key: 'budgetFriendly' as keyof DietaryPreferences,
      label: 'Budget Friendly',
      icon: Wallet,
      description: 'Cost-effective ingredients'
    },
    {
      key: 'quickMeals' as keyof DietaryPreferences,
      label: 'Quick Meals',
      icon: Clock,
      description: '30 minutes or less'
    }
  ];

  return (
    <Card className="shadow-soft">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-accent" />
          <CardTitle className="font-display text-xl">Preferences</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          {preferenceOptions.map(({ key, label, icon: Icon, description }) => (
            <div
              key={key}
              className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-md bg-background">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <Label htmlFor={key} className="font-medium cursor-pointer">
                    {label}
                  </Label>
                  <p className="text-xs text-muted-foreground">{description}</p>
                </div>
              </div>
              <Switch
                id={key}
                checked={preferences[key]}
                onCheckedChange={(checked) =>
                  onUpdatePreferences({ ...preferences, [key]: checked })
                }
              />
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-primary" />
            <Label className="font-medium">Plan Duration</Label>
          </div>
          <Select
            value={numberOfDays.toString()}
            onValueChange={(value) => onUpdateNumberOfDays(Number(value))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3">3 Days</SelectItem>
              <SelectItem value="5">5 Days</SelectItem>
              <SelectItem value="7">7 Days (Full Week)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={onGeneratePlan}
          className="w-full gradient-fresh text-primary-foreground font-medium h-12 text-base hover:opacity-90 transition-opacity"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          {hasExistingPlan ? 'Regenerate Plan' : 'Generate Meal Plan'}
        </Button>
        
        {hasExistingPlan && (
          <p className="text-xs text-center text-muted-foreground">
            Locked meals will be preserved when regenerating
          </p>
        )}
      </CardContent>
    </Card>
  );
}
