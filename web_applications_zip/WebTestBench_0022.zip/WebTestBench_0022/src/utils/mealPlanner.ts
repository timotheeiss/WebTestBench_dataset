import { Recipe, Ingredient, MealSlot, DietaryPreferences, RecipeIngredient, recipes } from '@/data/recipes';

export function getDaysUntilExpiration(expirationDate?: string): number | null {
  if (!expirationDate) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expDate = new Date(expirationDate);
  expDate.setHours(0, 0, 0, 0);
  const diffTime = expDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getExpirationStatus(expirationDate?: string): 'expired' | 'expiring-soon' | 'fresh' | 'no-date' {
  const days = getDaysUntilExpiration(expirationDate);
  if (days === null) return 'no-date';
  if (days < 0) return 'expired';
  if (days <= 3) return 'expiring-soon';
  return 'fresh';
}

export function filterRecipesByPreferences(recipes: Recipe[], preferences: DietaryPreferences): Recipe[] {
  return recipes.filter(recipe => {
    if (preferences.vegetarian && !recipe.tags.includes('vegetarian')) return false;
    if (preferences.highProtein && !recipe.tags.includes('high-protein')) return false;
    if (preferences.budgetFriendly && !recipe.tags.includes('budget-friendly')) return false;
    if (preferences.quickMeals && (recipe.prepTime + recipe.cookTime) > 30) return false;
    return true;
  });
}

export function scoreRecipeByPantry(recipe: Recipe, pantry: Ingredient[]): number {
  let score = 0;
  let expiringBonus = 0;
  
  recipe.ingredients.forEach(recipeIng => {
    const pantryItem = pantry.find(p => 
      p.name.toLowerCase() === recipeIng.name.toLowerCase()
    );
    
    if (pantryItem) {
      // Base score for having ingredient
      score += 10;
      
      // Bonus for expiring items
      const status = getExpirationStatus(pantryItem.expirationDate);
      if (status === 'expiring-soon') {
        expiringBonus += 25;
      } else if (status === 'expired') {
        expiringBonus += 5; // Still usable, less priority
      }
      
      // Check if we have enough quantity
      if (pantryItem.quantity >= recipeIng.quantity) {
        score += 5;
      }
    } else {
      // Penalty for missing ingredients
      score -= 5;
    }
  });
  
  return score + expiringBonus;
}

export function generateMealPlan(
  numberOfDays: number,
  pantry: Ingredient[],
  preferences: DietaryPreferences,
  existingMeals: MealSlot[]
): MealSlot[] {
  const filteredRecipes = filterRecipesByPreferences(recipes, preferences);
  const mealTypes: ('breakfast' | 'lunch' | 'dinner')[] = ['breakfast', 'lunch', 'dinner'];
  
  const newMeals: MealSlot[] = [];
  let mealId = Date.now();
  
  for (let day = 0; day < numberOfDays; day++) {
    for (const mealType of mealTypes) {
      const existingMeal = existingMeals.find(
        m => m.dayIndex === day && m.mealType === mealType
      );
      
      if (existingMeal?.locked) {
        newMeals.push(existingMeal);
        continue;
      }
      
      // Get recipes suitable for this meal type
      let suitableRecipes = filteredRecipes.filter(r => {
        if (mealType === 'breakfast') return r.tags.includes('breakfast');
        if (mealType === 'lunch') return r.tags.includes('lunch') || r.tags.includes('dinner');
        return r.tags.includes('dinner') || r.tags.includes('lunch');
      });
      
      if (suitableRecipes.length === 0) {
        suitableRecipes = filteredRecipes;
      }
      
      // Score recipes by pantry availability and expiration
      const scoredRecipes = suitableRecipes.map(recipe => ({
        recipe,
        score: scoreRecipeByPantry(recipe, pantry)
      }));
      
      // Sort by score and add some randomness
      scoredRecipes.sort((a, b) => b.score - a.score);
      
      // Pick from top recipes with some variety
      const topRecipes = scoredRecipes.slice(0, Math.min(3, scoredRecipes.length));
      const selectedRecipe = topRecipes[Math.floor(Math.random() * topRecipes.length)]?.recipe || null;
      
      newMeals.push({
        id: `meal-${mealId++}`,
        dayIndex: day,
        mealType,
        recipe: selectedRecipe,
        locked: false
      });
    }
  }
  
  return newMeals;
}

export interface IngredientUsage {
  ingredientName: string;
  totalNeeded: number;
  unit: string;
  availableInPantry: number;
  missing: number;
  usages: { recipeName: string; quantity: number }[];
}

export function calculateIngredientUsage(meals: MealSlot[], pantry: Ingredient[]): IngredientUsage[] {
  const usageMap = new Map<string, IngredientUsage>();
  
  meals.forEach(meal => {
    if (!meal.recipe) return;
    
    meal.recipe.ingredients.forEach(ing => {
      const key = ing.name.toLowerCase();
      const existing = usageMap.get(key);
      
      if (existing) {
        existing.totalNeeded += ing.quantity;
        existing.usages.push({ recipeName: meal.recipe!.name, quantity: ing.quantity });
      } else {
        const pantryItem = pantry.find(p => p.name.toLowerCase() === key);
        usageMap.set(key, {
          ingredientName: ing.name,
          totalNeeded: ing.quantity,
          unit: ing.unit,
          availableInPantry: pantryItem?.quantity || 0,
          missing: 0,
          usages: [{ recipeName: meal.recipe!.name, quantity: ing.quantity }]
        });
      }
    });
  });
  
  // Calculate missing amounts
  usageMap.forEach(usage => {
    usage.missing = Math.max(0, usage.totalNeeded - usage.availableInPantry);
  });
  
  return Array.from(usageMap.values());
}

export function generateGroceryList(ingredientUsage: IngredientUsage[]): IngredientUsage[] {
  return ingredientUsage.filter(usage => usage.missing > 0);
}
