import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

interface Confirmation {
  policyId: string;
  confirmedAt: string;
}

const CONFIRMATIONS_KEY = 'policy_confirmations';

export function useConfirmations() {
  const { user } = useAuth();
  const [confirmations, setConfirmations] = useState<Confirmation[]>([]);

  const getStorageKey = () => `${CONFIRMATIONS_KEY}_${user?.id}`;

  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(getStorageKey());
      if (stored) {
        try {
          setConfirmations(JSON.parse(stored));
        } catch {
          setConfirmations([]);
        }
      } else {
        setConfirmations([]);
      }
    }
  }, [user]);

  const confirmPolicy = (policyId: string) => {
    const newConfirmation: Confirmation = {
      policyId,
      confirmedAt: new Date().toISOString()
    };
    
    const updated = [...confirmations.filter(c => c.policyId !== policyId), newConfirmation];
    setConfirmations(updated);
    localStorage.setItem(getStorageKey(), JSON.stringify(updated));
  };

  const isConfirmed = (policyId: string): boolean => {
    return confirmations.some(c => c.policyId === policyId);
  };

  const getConfirmationDate = (policyId: string): string | null => {
    const confirmation = confirmations.find(c => c.policyId === policyId);
    return confirmation ? confirmation.confirmedAt : null;
  };

  return {
    confirmations,
    confirmPolicy,
    isConfirmed,
    getConfirmationDate,
    confirmedCount: confirmations.length
  };
}
