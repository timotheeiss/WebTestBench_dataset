export interface User {
  id: string;
  email: string;
  password: string;
  name: string;
  department: string;
  avatar?: string;
}

export const users: User[] = [
  {
    id: "user-001",
    email: "john.doe@company.com",
    password: "password123",
    name: "John Doe",
    department: "Engineering"
  },
  {
    id: "user-002",
    email: "jane.smith@company.com",
    password: "password123",
    name: "Jane Smith",
    department: "Marketing"
  },
  {
    id: "user-003",
    email: "admin@company.com",
    password: "admin",
    name: "Admin User",
    department: "Human Resources"
  }
];
