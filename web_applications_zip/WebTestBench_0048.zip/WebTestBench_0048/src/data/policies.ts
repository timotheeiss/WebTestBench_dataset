export type PolicyCategory = 'Administration' | 'Human Resources' | 'Finance' | 'Compliance';
export type Priority = 'high' | 'medium' | 'low';

export interface Policy {
  id: string;
  title: string;
  category: PolicyCategory;
  summary: string;
  content: string;
  effectiveDate: string;
  lastUpdated: string;
  confirmationDeadline?: string; // ISO date string
}

export const policies: Policy[] = [
  {
    id: "pol-001",
    title: "Code of Conduct",
    category: "Administration",
    summary: "Guidelines for professional behavior and ethical standards expected of all employees.",
    confirmationDeadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 days from now - HIGH
    content: `
## Purpose
This Code of Conduct establishes the fundamental principles and standards of behavior expected from all employees of the organization.

## Scope
This policy applies to all employees, contractors, and representatives of the company.

## Core Principles

### 1. Integrity
All employees are expected to act with honesty and integrity in all business dealings. This includes:
- Being truthful in all communications
- Honoring commitments and promises
- Reporting accurate information

### 2. Respect
We are committed to maintaining a respectful workplace where:
- All individuals are treated with dignity
- Diverse perspectives are valued
- Harassment and discrimination are not tolerated

### 3. Professionalism
Employees should maintain professional standards by:
- Dressing appropriately for the workplace
- Communicating respectfully with colleagues and clients
- Meeting deadlines and fulfilling responsibilities

### 4. Confidentiality
Protecting sensitive information is paramount:
- Do not share confidential business information
- Secure all documents and digital files
- Report any suspected breaches immediately

## Compliance
Violations of this Code of Conduct may result in disciplinary action, up to and including termination of employment.
    `,
    effectiveDate: "2024-01-01",
    lastUpdated: "2024-06-15"
  },
  {
    id: "pol-002",
    title: "Remote Work Policy",
    category: "Human Resources",
    summary: "Guidelines and expectations for employees working remotely or in hybrid arrangements.",
    confirmationDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days - MEDIUM
    content: `
## Purpose
This policy outlines the expectations and guidelines for employees who work remotely, whether on a full-time or hybrid basis.

## Eligibility
Remote work arrangements may be available to employees whose roles permit remote execution of duties, subject to manager approval.

## Requirements

### 1. Work Environment
Remote employees must:
- Maintain a dedicated, quiet workspace
- Ensure reliable internet connectivity (minimum 25 Mbps)
- Have appropriate equipment for their role

### 2. Availability
During working hours, employees must:
- Be reachable via company communication tools
- Respond to messages within a reasonable timeframe
- Attend all scheduled meetings

### 3. Security
When working remotely:
- Use company-approved VPN for all work activities
- Never access company data on public Wi-Fi without VPN
- Keep devices secure and locked when not in use

### 4. Communication
Effective communication is essential:
- Provide regular updates to your manager
- Participate actively in team meetings
- Document work progress appropriately

## Equipment
The company will provide standard equipment. Employees are responsible for maintaining a safe working environment.
    `,
    effectiveDate: "2024-02-01",
    lastUpdated: "2024-08-10"
  },
  {
    id: "pol-003",
    title: "Data Protection & Privacy",
    category: "Compliance",
    summary: "Requirements for handling personal data and maintaining privacy compliance.",
    confirmationDeadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 1 day - HIGH
    content: `
## Purpose
This policy ensures compliance with data protection regulations and establishes best practices for handling personal information.

## Scope
This policy covers all personal data processed by the organization, including employee, customer, and vendor information.

## Principles

### 1. Data Minimization
Only collect data that is necessary for the specific purpose. Do not retain data longer than required.

### 2. Purpose Limitation
Personal data should only be used for the purpose for which it was collected. Any new use requires additional consent or legal basis.

### 3. Accuracy
Ensure all personal data is accurate and up-to-date. Implement processes to correct inaccurate data promptly.

### 4. Security
Protect personal data through:
- Encryption of sensitive data
- Access controls and authentication
- Regular security assessments

## Data Subject Rights
Individuals have the right to:
- Access their personal data
- Request correction of inaccurate data
- Request deletion under certain circumstances
- Object to processing

## Breach Response
In case of a data breach:
1. Report immediately to the IT Security team
2. Document all known details
3. Do not attempt to cover up or minimize the incident

## Training
All employees must complete annual data protection training.
    `,
    effectiveDate: "2024-01-15",
    lastUpdated: "2024-09-01"
  },
  {
    id: "pol-004",
    title: "Anti-Harassment Policy",
    category: "Human Resources",
    summary: "Zero-tolerance policy for harassment and procedures for reporting incidents.",
    confirmationDeadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 14 days - LOW
    content: `
## Purpose
This policy establishes our commitment to providing a workplace free from harassment and discrimination of any kind.

## Definition
Harassment includes any unwelcome conduct based on race, color, religion, sex, national origin, age, disability, genetic information, or any other protected characteristic.

## Prohibited Conduct

### 1. Verbal Harassment
- Offensive jokes, slurs, or epithets
- Threats or intimidation
- Unwelcome comments about appearance

### 2. Physical Harassment
- Unwanted physical contact
- Blocking movement or gestures
- Assault or threats of assault

### 3. Visual Harassment
- Offensive posters, drawings, or images
- Offensive emails or messages
- Inappropriate gestures

### 4. Sexual Harassment
- Unwelcome sexual advances
- Requests for sexual favors
- Sexually explicit materials

## Reporting Procedures
If you experience or witness harassment:
1. Report to your supervisor or HR immediately
2. Document the incident with dates, times, and witnesses
3. You may also report anonymously via the ethics hotline

## Non-Retaliation
Retaliation against anyone who reports harassment or participates in an investigation is strictly prohibited and will result in disciplinary action.

## Investigation
All complaints will be investigated promptly and confidentially. Appropriate action will be taken based on findings.
    `,
    effectiveDate: "2024-01-01",
    lastUpdated: "2024-05-20"
  },
  {
    id: "pol-005",
    title: "Expense Reimbursement Policy",
    category: "Finance",
    summary: "Guidelines for submitting and processing business expense reimbursements.",
    confirmationDeadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 5 days - MEDIUM
    content: `
## Purpose
This policy provides guidelines for employees seeking reimbursement for legitimate business expenses.

## Eligible Expenses

### 1. Travel
- Airfare (economy class for flights under 6 hours)
- Ground transportation (taxi, rideshare, rental car)
- Accommodation (up to company per diem rates)
- Meals (reasonable amounts per company guidelines)

### 2. Business Entertainment
- Client meals (with prior approval for amounts over $100)
- Team events (with manager approval)

### 3. Professional Development
- Conference registration fees
- Training materials
- Professional membership dues

## Submission Requirements

### Documentation
All expense claims must include:
- Itemized receipts
- Business purpose description
- Names of attendees (for meals/entertainment)
- Project or cost center code

### Deadlines
- Submit expenses within 30 days of incurrence
- Late submissions may be denied

## Approval Process
1. Submit through expense management system
2. Manager review and approval
3. Finance department processing
4. Reimbursement via payroll (typically 2 pay cycles)

## Non-Reimbursable Items
- Personal expenses
- Alcohol (except client entertainment with approval)
- Upgrades beyond policy limits
- Expenses without receipts over $25
    `,
    effectiveDate: "2024-03-01",
    lastUpdated: "2024-07-22"
  },
  {
    id: "pol-006",
    title: "Information Security Policy",
    category: "Compliance",
    summary: "Requirements for protecting company information systems and data assets.",
    confirmationDeadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 days - HIGH (exactly 3 days)
    content: `
## Purpose
This policy establishes requirements for protecting the confidentiality, integrity, and availability of company information systems.

## Password Requirements

### Standards
- Minimum 12 characters
- Combination of uppercase, lowercase, numbers, and symbols
- No dictionary words or personal information
- Unique password for each system

### Management
- Change passwords every 90 days
- Never share passwords
- Use company-approved password manager

## Device Security

### Company Devices
- Enable full-disk encryption
- Install security updates within 48 hours
- Use only approved software
- Report lost or stolen devices immediately

### Personal Devices
- BYOD requires IT approval
- Must install MDM software
- Keep personal and work data separate

## Network Security
- Always use VPN when outside office
- Never connect to unsecured networks
- Report suspicious network activity

## Incident Reporting
Report security incidents immediately to:
- IT Security: security@company.com
- Emergency: IT Helpdesk ext. 5555

## Consequences
Violations may result in:
- Disciplinary action
- Termination of employment
- Legal action if warranted
    `,
    effectiveDate: "2024-01-01",
    lastUpdated: "2024-10-05"
  },
  {
    id: "pol-007",
    title: "Travel & Booking Policy",
    category: "Administration",
    summary: "Guidelines for booking business travel and accommodation arrangements.",
    confirmationDeadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 10 days - LOW
    content: `
## Purpose
This policy provides guidelines for booking business travel efficiently and cost-effectively.

## Booking Procedures
- Book flights at least 14 days in advance when possible
- Use approved travel management system
- Select economy class for flights under 6 hours

## Accommodation
- Book hotels within per diem limits
- Prefer company-partnered properties

## Approval
- All travel requires manager pre-approval
- International travel requires VP approval
    `,
    effectiveDate: "2024-04-01",
    lastUpdated: "2024-09-15"
  },
  {
    id: "pol-008",
    title: "Annual Leave Policy",
    category: "Human Resources",
    summary: "Guidelines for requesting and managing annual leave entitlements.",
    confirmationDeadline: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 4 days - MEDIUM
    content: `
## Purpose
This policy outlines the annual leave entitlements and procedures for all employees.

## Entitlement
- Full-time employees: 20 days per year
- Part-time employees: Pro-rated based on hours

## Requesting Leave
- Submit requests at least 2 weeks in advance
- Use the HR portal for all leave requests
- Manager approval required

## Carryover
- Maximum 5 days can be carried over
- Must be used within Q1 of following year
    `,
    effectiveDate: "2024-01-01",
    lastUpdated: "2024-08-01"
  }
];

export const categories: PolicyCategory[] = ['Administration', 'Human Resources', 'Finance', 'Compliance'];

// Utility function to calculate priority based on deadline
export function getPolicyPriority(policy: Policy, isConfirmed: boolean): Priority | null {
  if (isConfirmed || !policy.confirmationDeadline) return null;
  
  const now = new Date();
  const deadline = new Date(policy.confirmationDeadline);
  const daysUntilDeadline = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  
  if (daysUntilDeadline <= 3) return 'high';
  if (daysUntilDeadline <= 7) return 'medium';
  return 'low';
}
