import { Priority } from '@/data/policies';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PriorityBadgeProps {
  priority: Priority;
  showLabel?: boolean;
  className?: string;
}

const priorityConfig: Record<Priority, { label: string; icon: React.ReactNode; className: string }> = {
  high: {
    label: 'High',
    icon: <AlertTriangle className="h-3 w-3" />,
    className: 'bg-priority-high-muted text-priority-high border-priority-high/20',
  },
  medium: {
    label: 'Medium',
    icon: <AlertCircle className="h-3 w-3" />,
    className: 'bg-priority-medium-muted text-priority-medium border-priority-medium/20',
  },
  low: {
    label: 'Low',
    icon: <Info className="h-3 w-3" />,
    className: 'bg-priority-low-muted text-priority-low border-priority-low/20',
  },
};

export function PriorityBadge({ priority, showLabel = true, className }: PriorityBadgeProps) {
  const config = priorityConfig[priority];
  
  return (
    <Badge 
      variant="outline" 
      className={cn('gap-1 font-medium border', config.className, className)}
    >
      {config.icon}
      {showLabel && config.label}
    </Badge>
  );
}
