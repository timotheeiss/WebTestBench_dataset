import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useConfirmations } from '@/hooks/useConfirmations';
import { policies, categories, getPolicyPriority, Priority } from '@/data/policies';
import { PolicyCard } from './PolicyCard';
import { ProgressChart } from './ProgressChart';
import { CategoryStats } from './CategoryStats';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, LogOut, Filter } from 'lucide-react';

type FilterType = 'all' | 'pending' | 'confirmed';

export function Dashboard() {
  const { user, logout } = useAuth();
  const { isConfirmed, getConfirmationDate, confirmedCount } = useConfirmations();
  const [filter, setFilter] = useState<FilterType>('all');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);

  const pendingCount = policies.length - confirmedCount;

  // Sort and filter policies with priority
  const sortedAndFilteredPolicies = useMemo(() => {
    // First, add priority to each policy
    const policiesWithPriority = policies.map(policy => ({
      policy,
      priority: getPolicyPriority(policy, isConfirmed(policy.id)),
      isConfirmedPolicy: isConfirmed(policy.id)
    }));

    // Filter based on status and category
    const filtered = policiesWithPriority.filter(({ policy, isConfirmedPolicy }) => {
      const matchesStatus = 
        filter === 'all' ||
        (filter === 'confirmed' && isConfirmedPolicy) ||
        (filter === 'pending' && !isConfirmedPolicy);
      
      const matchesCategory = !categoryFilter || policy.category === categoryFilter;
      
      return matchesStatus && matchesCategory;
    });

    // Sort: high priority first, then medium, then low, then confirmed
    const priorityOrder: Record<Priority | 'none', number> = {
      high: 0,
      medium: 1,
      low: 2,
      none: 3
    };

    return filtered.sort((a, b) => {
      const priorityA = a.priority ?? 'none';
      const priorityB = b.priority ?? 'none';
      return priorityOrder[priorityA] - priorityOrder[priorityB];
    });
  }, [filter, categoryFilter, isConfirmed]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
                <Shield className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-semibold">Policy Portal</h1>
                <p className="text-sm text-primary-foreground/70">
                  Welcome, {user?.name}
                </p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={logout}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Dashboard Charts */}
        <div className="grid gap-6 md:grid-cols-2 mb-8 animate-fade-in">
          <ProgressChart confirmed={confirmedCount} pending={pendingCount} />
          <CategoryStats policies={policies} isConfirmed={isConfirmed} />
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Status:</span>
            <div className="flex gap-1">
              {(['all', 'pending', 'confirmed'] as FilterType[]).map((f) => (
                <Button
                  key={f}
                  variant={filter === f ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setFilter(f)}
                  className="capitalize"
                >
                  {f}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-2 sm:ml-auto">
            <span className="text-sm font-medium text-muted-foreground">Category:</span>
            <div className="flex flex-wrap gap-1">
              <Badge
                variant={categoryFilter === null ? 'default' : 'secondary'}
                className="cursor-pointer"
                onClick={() => setCategoryFilter(null)}
              >
                All
              </Badge>
              {categories.map((cat) => (
                <Badge
                  key={cat}
                  variant={categoryFilter === cat ? 'default' : 'secondary'}
                  className="cursor-pointer"
                  onClick={() => setCategoryFilter(cat)}
                >
                  {cat}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Policy Grid */}
        {sortedAndFilteredPolicies.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {sortedAndFilteredPolicies.map(({ policy, priority }, index) => (
              <div
                key={policy.id}
                className="animate-slide-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <PolicyCard
                  policy={policy}
                  isConfirmed={isConfirmed(policy.id)}
                  confirmedAt={getConfirmationDate(policy.id)}
                  priority={priority}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No policies match your filters.</p>
          </div>
        )}
      </main>
    </div>
  );
}
