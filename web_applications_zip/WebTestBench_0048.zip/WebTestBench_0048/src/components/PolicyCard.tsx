import { Link } from 'react-router-dom';
import { Policy, Priority } from '@/data/policies';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PriorityBadge } from './PriorityBadge';
import { CheckCircle2, Clock, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

interface PolicyCardProps {
  policy: Policy;
  isConfirmed: boolean;
  confirmedAt?: string | null;
  priority?: Priority | null;
}

export function PolicyCard({ policy, isConfirmed, confirmedAt, priority }: PolicyCardProps) {
  return (
    <Link to={`/policy/${policy.id}`}>
      <Card className="group hover:shadow-md transition-all duration-200 hover:border-primary/20 cursor-pointer h-full">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Badge variant="secondary" className="text-xs font-medium">
                  {policy.category}
                </Badge>
                {priority && <PriorityBadge priority={priority} />}
              </div>
              <CardTitle className="text-lg leading-tight group-hover:text-primary transition-colors">
                {policy.title}
              </CardTitle>
            </div>
            <div className="flex-shrink-0">
              {isConfirmed ? (
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-success-muted">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                </div>
              ) : (
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-warning-muted">
                  <Clock className="h-5 w-5 text-warning" />
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <CardDescription className="line-clamp-2 mb-4">
            {policy.summary}
          </CardDescription>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {isConfirmed && confirmedAt
                ? `Confirmed ${format(new Date(confirmedAt), 'MMM d, yyyy')}`
                : policy.confirmationDeadline
                  ? `Due ${format(new Date(policy.confirmationDeadline), 'MMM d, yyyy')}`
                  : `Updated ${format(new Date(policy.lastUpdated), 'MMM d, yyyy')}`}
            </span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
