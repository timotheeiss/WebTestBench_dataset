import { useParams, useNavigate, Link } from 'react-router-dom';
import { policies } from '@/data/policies';
import { useConfirmations } from '@/hooks/useConfirmations';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, CheckCircle2, Clock, Calendar, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { useState } from 'react';
import { toast } from 'sonner';

export function PolicyDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isConfirmed, getConfirmationDate, confirmPolicy } = useConfirmations();
  const [acknowledged, setAcknowledged] = useState(false);

  const policy = policies.find(p => p.id === id);

  if (!policy) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Policy Not Found</h1>
          <p className="text-muted-foreground mb-4">The policy you're looking for doesn't exist.</p>
          <Button onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const confirmed = isConfirmed(policy.id);
  const confirmedAt = getConfirmationDate(policy.id);

  const handleConfirm = () => {
    confirmPolicy(policy.id);
    toast.success('Policy confirmed successfully!', {
      description: `You have confirmed "${policy.title}"`,
    });
    setAcknowledged(false);
  };

  // Simple markdown-like rendering
  const renderContent = (content: string) => {
    const lines = content.trim().split('\n');
    const elements: React.ReactNode[] = [];
    
    lines.forEach((line, index) => {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('## ')) {
        elements.push(
          <h2 key={index} className="text-xl font-semibold mt-8 mb-4 text-foreground first:mt-0">
            {trimmed.replace('## ', '')}
          </h2>
        );
      } else if (trimmed.startsWith('### ')) {
        elements.push(
          <h3 key={index} className="text-lg font-medium mt-6 mb-3 text-foreground">
            {trimmed.replace('### ', '')}
          </h3>
        );
      } else if (trimmed.startsWith('- ')) {
        elements.push(
          <li key={index} className="text-muted-foreground ml-4 mb-1">
            {trimmed.replace('- ', '')}
          </li>
        );
      } else if (/^\d+\./.test(trimmed)) {
        elements.push(
          <li key={index} className="text-muted-foreground ml-4 mb-1 list-decimal">
            {trimmed.replace(/^\d+\.\s*/, '')}
          </li>
        );
      } else if (trimmed) {
        elements.push(
          <p key={index} className="text-muted-foreground mb-3 leading-relaxed">
            {trimmed}
          </p>
        );
      }
    });

    return elements;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="container py-4">
          <Link 
            to="/dashboard" 
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Dashboard
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container py-8 animate-fade-in">
        <div className="max-w-3xl mx-auto">
          {/* Policy Header */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="secondary">{policy.category}</Badge>
              {confirmed ? (
                <Badge className="bg-success-muted text-success border-0">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  Confirmed
                </Badge>
              ) : (
                <Badge className="bg-warning-muted text-warning border-0">
                  <Clock className="h-3 w-3 mr-1" />
                  Pending
                </Badge>
              )}
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-4">{policy.title}</h1>
            <p className="text-lg text-muted-foreground mb-4">{policy.summary}</p>
            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                <span>Effective: {format(new Date(policy.effectiveDate), 'MMMM d, yyyy')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <RefreshCw className="h-4 w-4" />
                <span>Updated: {format(new Date(policy.lastUpdated), 'MMMM d, yyyy')}</span>
              </div>
            </div>
          </div>

          {/* Policy Content */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="prose prose-sm max-w-none">
                {renderContent(policy.content)}
              </div>
            </CardContent>
          </Card>

          {/* Confirmation Section */}
          <Card className={confirmed ? 'bg-success-muted border-success/20' : 'border-primary/20'}>
            <CardContent className="p-6">
              {confirmed ? (
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-success/10">
                    <CheckCircle2 className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Policy Confirmed</p>
                    <p className="text-sm text-muted-foreground">
                      You confirmed this policy on {confirmedAt && format(new Date(confirmedAt), 'MMMM d, yyyy \'at\' h:mm a')}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id="acknowledge"
                      checked={acknowledged}
                      onCheckedChange={(checked) => setAcknowledged(checked === true)}
                    />
                    <label htmlFor="acknowledge" className="text-sm text-muted-foreground cursor-pointer leading-relaxed">
                      I have read and understood this policy. I agree to comply with its terms and conditions as part of my employment.
                    </label>
                  </div>
                  <Button 
                    onClick={handleConfirm} 
                    disabled={!acknowledged}
                    className="w-full sm:w-auto"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Confirm Policy
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
