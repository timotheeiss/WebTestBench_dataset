import { Policy, PolicyCategory, categories } from '@/data/policies';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Briefcase, Users, DollarSign, Shield } from 'lucide-react';

interface CategoryStatsProps {
  policies: Policy[];
  isConfirmed: (policyId: string) => boolean;
}

const categoryIcons: Record<PolicyCategory, React.ReactNode> = {
  'Administration': <Briefcase className="h-4 w-4" />,
  'Human Resources': <Users className="h-4 w-4" />,
  'Finance': <DollarSign className="h-4 w-4" />,
  'Compliance': <Shield className="h-4 w-4" />,
};

const categoryColors: Record<PolicyCategory, string> = {
  'Administration': 'bg-chart-1',
  'Human Resources': 'bg-chart-2',
  'Finance': 'bg-chart-3',
  'Compliance': 'bg-chart-4',
};

export function CategoryStats({ policies, isConfirmed }: CategoryStatsProps) {
  const getCategoryStats = (category: PolicyCategory) => {
    const categoryPolicies = policies.filter(p => p.category === category);
    const confirmed = categoryPolicies.filter(p => isConfirmed(p.id)).length;
    const total = categoryPolicies.length;
    const percentage = total > 0 ? Math.round((confirmed / total) * 100) : 0;
    return { confirmed, total, percentage };
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Status by Category</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {categories.map((category) => {
            const stats = getCategoryStats(category);
            return (
              <div key={category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-md ${categoryColors[category]} text-primary-foreground`}>
                      {categoryIcons[category]}
                    </div>
                    <span className="text-sm font-medium text-foreground">{category}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {stats.confirmed}/{stats.total}
                  </span>
                </div>
                <Progress value={stats.percentage} className="h-2" />
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
