import { useState, useCallback } from 'react';
import { BudgetState, Transaction, ExpenseCategory, IncomeSource, SavingsGoal } from '@/types/budget';
import { initialData } from '@/data/initialData';

export function useBudgetStore() {
  const [state, setState] = useState<BudgetState>(initialData);

  const addTransaction = useCallback((transaction: Omit<Transaction, 'id'>) => {
    setState(prev => ({
      ...prev,
      transactions: [
        { ...transaction, id: `t${Date.now()}` },
        ...prev.transactions,
      ],
    }));
  }, []);

  const updateTransaction = useCallback((id: string, updates: Partial<Transaction>) => {
    setState(prev => ({
      ...prev,
      transactions: prev.transactions.map(t =>
        t.id === id ? { ...t, ...updates } : t
      ),
    }));
  }, []);

  const deleteTransaction = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      transactions: prev.transactions.filter(t => t.id !== id),
    }));
  }, []);

  const addCategory = useCallback((category: Omit<ExpenseCategory, 'id'>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        expenseCategories: [
          ...prev.profile.expenseCategories,
          { ...category, id: `cat${Date.now()}` },
        ],
      },
    }));
  }, []);

  const updateCategory = useCallback((id: string, updates: Partial<ExpenseCategory>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        expenseCategories: prev.profile.expenseCategories.map(c =>
          c.id === id ? { ...c, ...updates } : c
        ),
      },
    }));
  }, []);

  const deleteCategory = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        expenseCategories: prev.profile.expenseCategories.filter(c => c.id !== id),
      },
    }));
  }, []);

  const addIncomeSource = useCallback((source: Omit<IncomeSource, 'id'>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        incomeSources: [
          ...prev.profile.incomeSources,
          { ...source, id: `inc${Date.now()}` },
        ],
      },
    }));
  }, []);

  const updateIncomeSource = useCallback((id: string, updates: Partial<IncomeSource>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        incomeSources: prev.profile.incomeSources.map(s =>
          s.id === id ? { ...s, ...updates } : s
        ),
      },
    }));
  }, []);

  const deleteIncomeSource = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        incomeSources: prev.profile.incomeSources.filter(s => s.id !== id),
      },
    }));
  }, []);

  const addSavingsGoal = useCallback((goal: Omit<SavingsGoal, 'id'>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        savingsGoals: [
          ...prev.profile.savingsGoals,
          { ...goal, id: `goal${Date.now()}` },
        ],
      },
    }));
  }, []);

  const updateSavingsGoal = useCallback((id: string, updates: Partial<SavingsGoal>) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        savingsGoals: prev.profile.savingsGoals.map(g =>
          g.id === id ? { ...g, ...updates } : g
        ),
      },
    }));
  }, []);

  const deleteSavingsGoal = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        savingsGoals: prev.profile.savingsGoals.filter(g => g.id !== id),
      },
    }));
  }, []);

  const updateProfileName = useCallback((name: string) => {
    setState(prev => ({
      ...prev,
      profile: { ...prev.profile, name },
    }));
  }, []);

  const getMonthlyIncome = useCallback(() => {
    return state.profile.incomeSources.reduce((total, source) => {
      switch (source.frequency) {
        case 'weekly': return total + source.amount * 4;
        case 'biweekly': return total + source.amount * 2;
        case 'yearly': return total + source.amount / 12;
        default: return total + source.amount;
      }
    }, 0);
  }, [state.profile.incomeSources]);

  const getMonthlyBudget = useCallback(() => {
    return state.profile.expenseCategories.reduce((total, cat) => total + cat.budgetAmount, 0);
  }, [state.profile.expenseCategories]);

  const getSpendingByCategory = useCallback((month: number, year: number) => {
    return state.transactions
      .filter(t => {
        const date = new Date(t.date);
        return t.type === 'expense' && date.getMonth() === month && date.getFullYear() === year;
      })
      .reduce((acc, t) => {
        acc[t.categoryId] = (acc[t.categoryId] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>);
  }, [state.transactions]);

  return {
    state,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addCategory,
    updateCategory,
    deleteCategory,
    addIncomeSource,
    updateIncomeSource,
    deleteIncomeSource,
    addSavingsGoal,
    updateSavingsGoal,
    deleteSavingsGoal,
    updateProfileName,
    getMonthlyIncome,
    getMonthlyBudget,
    getSpendingByCategory,
  };
}
