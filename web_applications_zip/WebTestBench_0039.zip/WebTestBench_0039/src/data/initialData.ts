import { BudgetState } from '@/types/budget';

export const initialData: BudgetState = {
  profile: {
    name: 'Alex Johnson',
    currency: 'USD',
    incomeSources: [
      { id: '1', name: 'Salary', amount: 5500, frequency: 'monthly' },
      { id: '2', name: 'Freelance', amount: 800, frequency: 'monthly' },
    ],
    expenseCategories: [
      { id: 'housing', name: 'Housing', budgetAmount: 1500, color: 'hsl(var(--chart-1))', icon: 'Home' },
      { id: 'food', name: 'Food & Dining', budgetAmount: 600, color: 'hsl(var(--chart-2))', icon: 'UtensilsCrossed' },
      { id: 'transport', name: 'Transportation', budgetAmount: 400, color: 'hsl(var(--chart-3))', icon: 'Car' },
      { id: 'utilities', name: 'Utilities', budgetAmount: 200, color: 'hsl(var(--chart-4))', icon: 'Zap' },
      { id: 'entertainment', name: 'Entertainment', budgetAmount: 300, color: 'hsl(var(--chart-5))', icon: 'Gamepad2' },
      { id: 'shopping', name: 'Shopping', budgetAmount: 250, color: 'hsl(160 60% 45%)', icon: 'ShoppingBag' },
      { id: 'health', name: 'Health', budgetAmount: 150, color: 'hsl(200 70% 50%)', icon: 'Heart' },
      { id: 'other', name: 'Other', budgetAmount: 200, color: 'hsl(220 60% 50%)', icon: 'MoreHorizontal' },
    ],
    savingsGoals: [
      { id: '1', name: 'Emergency Fund', targetAmount: 15000, currentAmount: 8500, deadline: '2025-12-31' },
      { id: '2', name: 'Vacation', targetAmount: 3000, currentAmount: 1200, deadline: '2025-06-30' },
      { id: '3', name: 'New Car', targetAmount: 25000, currentAmount: 5000, deadline: '2026-06-30' },
    ],
  },
  transactions: [
    { id: 't1', amount: 1500, description: 'Monthly rent', categoryId: 'housing', date: '2025-12-01', type: 'expense' },
    { id: 't2', amount: 85.50, description: 'Grocery shopping', categoryId: 'food', date: '2025-12-02', type: 'expense' },
    { id: 't3', amount: 45, description: 'Gas station', categoryId: 'transport', date: '2025-12-03', type: 'expense' },
    { id: 't4', amount: 120, description: 'Electric bill', categoryId: 'utilities', date: '2025-12-04', type: 'expense' },
    { id: 't5', amount: 65, description: 'Restaurant dinner', categoryId: 'food', date: '2025-12-05', type: 'expense' },
    { id: 't6', amount: 15.99, description: 'Netflix subscription', categoryId: 'entertainment', date: '2025-12-06', type: 'expense' },
    { id: 't7', amount: 250, description: 'New shoes', categoryId: 'shopping', date: '2025-12-07', type: 'expense' },
    { id: 't8', amount: 42.30, description: 'Pharmacy', categoryId: 'health', date: '2025-12-08', type: 'expense' },
    { id: 't9', amount: 35, description: 'Uber rides', categoryId: 'transport', date: '2025-12-09', type: 'expense' },
    { id: 't10', amount: 180, description: 'Weekly groceries', categoryId: 'food', date: '2025-12-10', type: 'expense' },
    { id: 't11', amount: 50, description: 'Movie tickets', categoryId: 'entertainment', date: '2025-12-11', type: 'expense' },
    { id: 't12', amount: 75, description: 'Internet bill', categoryId: 'utilities', date: '2025-12-12', type: 'expense' },
    { id: 't13', amount: 5500, description: 'Monthly salary', categoryId: 'income', date: '2025-12-01', type: 'income' },
    { id: 't14', amount: 800, description: 'Freelance payment', categoryId: 'income', date: '2025-12-15', type: 'income' },
  ],
};
