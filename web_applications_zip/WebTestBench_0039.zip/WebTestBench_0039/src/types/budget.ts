export interface IncomeSource {
  id: string;
  name: string;
  amount: number;
  frequency: 'monthly' | 'weekly' | 'biweekly' | 'yearly';
}

export interface ExpenseCategory {
  id: string;
  name: string;
  budgetAmount: number;
  color: string;
  icon: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
}

export interface Transaction {
  id: string;
  amount: number;
  description: string;
  categoryId: string;
  date: string;
  type: 'expense' | 'income';
}

export interface UserProfile {
  name: string;
  currency: string;
  incomeSources: IncomeSource[];
  expenseCategories: ExpenseCategory[];
  savingsGoals: SavingsGoal[];
}

export interface BudgetState {
  profile: UserProfile;
  transactions: Transaction[];
}
