import { useState } from 'react';
import { Transaction, ExpenseCategory } from '@/types/budget';
import { TransactionList } from '@/components/transactions/TransactionList';
import { AddTransactionDialog } from '@/components/transactions/AddTransactionDialog';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

interface TransactionsViewProps {
  transactions: Transaction[];
  categories: ExpenseCategory[];
  currency: string;
  onAddTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  onUpdateTransaction: (id: string, updates: Partial<Transaction>) => void;
  onDeleteTransaction: (id: string) => void;
}

export function TransactionsView({
  transactions,
  categories,
  currency,
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
}: TransactionsViewProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTransaction, setEditTransaction] = useState<Transaction | null>(null);

  const handleEdit = (transaction: Transaction) => {
    setEditTransaction(transaction);
    setDialogOpen(true);
  };

  const handleDialogClose = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      setEditTransaction(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display">Transactions</h1>
          <p className="text-muted-foreground mt-1">
            Track and manage your income and expenses
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> Add Transaction
        </Button>
      </div>

      <TransactionList
        transactions={transactions}
        categories={categories}
        currency={currency}
        onDelete={onDeleteTransaction}
        onEdit={handleEdit}
      />

      <AddTransactionDialog
        open={dialogOpen}
        onOpenChange={handleDialogClose}
        categories={categories}
        onSave={onAddTransaction}
        editTransaction={editTransaction}
        onUpdate={onUpdateTransaction}
      />
    </div>
  );
}
