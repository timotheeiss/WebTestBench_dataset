import { useMemo } from 'react';
import { StatCard } from '@/components/dashboard/StatCard';
import { BudgetProgress } from '@/components/dashboard/BudgetProgress';
import { SpendingChart } from '@/components/dashboard/SpendingChart';
import { SavingsGoalCard } from '@/components/dashboard/SavingsGoalCard';
import { UserProfile, Transaction } from '@/types/budget';
import { formatCurrency, getMonthName, getCurrentMonth, getCurrentYear } from '@/lib/formatters';
import { DollarSign, TrendingDown, TrendingUp, PiggyBank } from 'lucide-react';

interface DashboardViewProps {
  profile: UserProfile;
  transactions: Transaction[];
  getMonthlyIncome: () => number;
  getMonthlyBudget: () => number;
  getSpendingByCategory: (month: number, year: number) => Record<string, number>;
}

export function DashboardView({
  profile,
  transactions,
  getMonthlyIncome,
  getMonthlyBudget,
  getSpendingByCategory,
}: DashboardViewProps) {
  const currentMonth = getCurrentMonth();
  const currentYear = getCurrentYear();
  const monthlyIncome = getMonthlyIncome();
  const monthlyBudget = getMonthlyBudget();
  const spending = getSpendingByCategory(currentMonth, currentYear);

  const totalSpent = useMemo(() => {
    return Object.values(spending).reduce((sum, amount) => sum + amount, 0);
  }, [spending]);

  const monthlyIncomeReceived = useMemo(() => {
    return transactions
      .filter(t => {
        const date = new Date(t.date);
        return t.type === 'income' && date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      })
      .reduce((sum, t) => sum + t.amount, 0);
  }, [transactions, currentMonth, currentYear]);

  const remainingBudget = monthlyBudget - totalSpent;
  const totalSavings = profile.savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-display">
          Welcome back, {profile.name.split(' ')[0]}
        </h1>
        <p className="text-muted-foreground mt-1">
          Here's your financial overview for {getMonthName(currentMonth)} {currentYear}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Monthly Income"
          value={formatCurrency(monthlyIncomeReceived, profile.currency)}
          subtitle={`Expected: ${formatCurrency(monthlyIncome, profile.currency)}`}
          icon={DollarSign}
          variant="success"
        />
        <StatCard
          title="Total Spent"
          value={formatCurrency(totalSpent, profile.currency)}
          subtitle={`Budget: ${formatCurrency(monthlyBudget, profile.currency)}`}
          icon={TrendingDown}
          variant={totalSpent > monthlyBudget ? 'destructive' : 'default'}
        />
        <StatCard
          title="Remaining Budget"
          value={formatCurrency(Math.abs(remainingBudget), profile.currency)}
          subtitle={remainingBudget < 0 ? 'Over budget!' : 'Available to spend'}
          icon={TrendingUp}
          variant={remainingBudget < 0 ? 'warning' : 'default'}
        />
        <StatCard
          title="Total Savings"
          value={formatCurrency(totalSavings, profile.currency)}
          subtitle={`${profile.savingsGoals.length} active goals`}
          icon={PiggyBank}
        />
      </div>

      {/* Charts and Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SpendingChart
          categories={profile.expenseCategories}
          spending={spending}
          currency={profile.currency}
        />
        <BudgetProgress
          categories={profile.expenseCategories}
          spending={spending}
          currency={profile.currency}
        />
      </div>

      {/* Savings Goals */}
      <SavingsGoalCard goals={profile.savingsGoals} currency={profile.currency} />
    </div>
  );
}
