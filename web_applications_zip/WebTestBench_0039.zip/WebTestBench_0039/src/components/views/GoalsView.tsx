import { useState } from 'react';
import { SavingsGoal } from '@/types/budget';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Target, Plus, Calendar, TrendingUp, Trash2 } from 'lucide-react';

interface GoalsViewProps {
  goals: SavingsGoal[];
  currency: string;
  onAddGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  onUpdateGoal: (id: string, updates: Partial<SavingsGoal>) => void;
  onDeleteGoal: (id: string) => void;
}

export function GoalsView({
  goals,
  currency,
  onAddGoal,
  onUpdateGoal,
  onDeleteGoal,
}: GoalsViewProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalCurrent, setNewGoalCurrent] = useState('');
  const [newGoalDeadline, setNewGoalDeadline] = useState('');

  const handleAddGoal = () => {
    if (newGoalName && newGoalTarget) {
      onAddGoal({
        name: newGoalName,
        targetAmount: parseFloat(newGoalTarget),
        currentAmount: parseFloat(newGoalCurrent) || 0,
        deadline: newGoalDeadline || undefined,
      });
      setNewGoalName('');
      setNewGoalTarget('');
      setNewGoalCurrent('');
      setNewGoalDeadline('');
      setDialogOpen(false);
    }
  };

  const totalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0);
  const totalSaved = goals.reduce((sum, g) => sum + g.currentAmount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display">Savings Goals</h1>
          <p className="text-muted-foreground mt-1">
            Track your progress towards financial milestones
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> Add Goal
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <div className="flex items-center gap-2 text-primary mb-2">
            <Target className="h-5 w-5" />
            <span className="text-sm font-medium">Total Goals</span>
          </div>
          <p className="text-3xl font-bold font-display">{goals.length}</p>
        </div>
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <div className="flex items-center gap-2 text-success mb-2">
            <TrendingUp className="h-5 w-5" />
            <span className="text-sm font-medium">Total Saved</span>
          </div>
          <p className="text-3xl font-bold font-display text-success">
            {formatCurrency(totalSaved, currency)}
          </p>
        </div>
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Target className="h-5 w-5" />
            <span className="text-sm font-medium">Target Total</span>
          </div>
          <p className="text-3xl font-bold font-display">{formatCurrency(totalTarget, currency)}</p>
        </div>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {goals.map((goal, index) => {
          const percentage = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
          const remaining = goal.targetAmount - goal.currentAmount;
          const isComplete = goal.currentAmount >= goal.targetAmount;

          return (
            <div
              key={goal.id}
              className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-lg">{goal.name}</h3>
                  {goal.deadline && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                      <Calendar className="h-4 w-4" />
                      Target: {formatDate(goal.deadline)}
                    </div>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDeleteGoal(goal.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{percentage.toFixed(0)}%</span>
                  </div>
                  <Progress value={percentage} className="h-3" />
                </div>

                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm text-muted-foreground">Current</p>
                    <p className="text-xl font-bold font-display text-primary">
                      {formatCurrency(goal.currentAmount, currency)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Target</p>
                    <p className="text-xl font-bold font-display">
                      {formatCurrency(goal.targetAmount, currency)}
                    </p>
                  </div>
                </div>

                {!isComplete && (
                  <p className="text-sm text-muted-foreground text-center pt-2 border-t">
                    {formatCurrency(remaining, currency)} remaining
                  </p>
                )}
                {isComplete && (
                  <p className="text-sm text-success text-center pt-2 border-t font-medium">
                    🎉 Goal achieved!
                  </p>
                )}

                {/* Quick update */}
                <div className="flex gap-2 pt-2">
                  <Input
                    type="number"
                    placeholder="Add amount"
                    className="flex-1"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const input = e.target as HTMLInputElement;
                        const value = parseFloat(input.value);
                        if (value > 0) {
                          onUpdateGoal(goal.id, { currentAmount: goal.currentAmount + value });
                          input.value = '';
                        }
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      const input = (e.target as HTMLElement).previousElementSibling as HTMLInputElement;
                      const value = parseFloat(input.value);
                      if (value > 0) {
                        onUpdateGoal(goal.id, { currentAmount: goal.currentAmount + value });
                        input.value = '';
                      }
                    }}
                  >
                    Add
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {goals.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>No savings goals yet. Create one to start tracking!</p>
        </div>
      )}

      {/* Add Goal Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Add Savings Goal</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Goal Name</Label>
              <Input
                placeholder="e.g., Emergency Fund, Vacation, New Car"
                value={newGoalName}
                onChange={(e) => setNewGoalName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Target Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  type="number"
                  placeholder="10000"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Current Savings (optional)</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  type="number"
                  placeholder="0"
                  value={newGoalCurrent}
                  onChange={(e) => setNewGoalCurrent(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Target Date (optional)</Label>
              <Input
                type="date"
                value={newGoalDeadline}
                onChange={(e) => setNewGoalDeadline(e.target.value)}
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button className="flex-1" onClick={handleAddGoal} disabled={!newGoalName || !newGoalTarget}>
                Create Goal
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
