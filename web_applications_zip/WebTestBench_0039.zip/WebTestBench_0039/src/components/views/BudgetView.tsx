import { ExpenseCategory } from '@/types/budget';
import { BudgetProgress } from '@/components/dashboard/BudgetProgress';
import { formatCurrency, getMonthName, getCurrentMonth, getCurrentYear } from '@/lib/formatters';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface BudgetViewProps {
  categories: ExpenseCategory[];
  spending: Record<string, number>;
  currency: string;
  monthlyBudget: number;
}

export function BudgetView({
  categories,
  spending,
  currency,
  monthlyBudget,
}: BudgetViewProps) {
  const currentMonth = getCurrentMonth();
  const currentYear = getCurrentYear();

  const chartData = categories.map(cat => ({
    name: cat.name,
    budget: cat.budgetAmount,
    spent: spending[cat.id] || 0,
    color: cat.color,
    isOver: (spending[cat.id] || 0) > cat.budgetAmount,
  }));

  const totalSpent = Object.values(spending).reduce((sum, amount) => sum + amount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-display">Budget Overview</h1>
        <p className="text-muted-foreground mt-1">
          {getMonthName(currentMonth)} {currentYear} • Total budget: {formatCurrency(monthlyBudget, currency)}
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <p className="text-sm font-medium text-muted-foreground">Total Budget</p>
          <p className="text-3xl font-bold font-display mt-2">{formatCurrency(monthlyBudget, currency)}</p>
        </div>
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
          <p className="text-3xl font-bold font-display mt-2">{formatCurrency(totalSpent, currency)}</p>
        </div>
        <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
          <p className="text-sm font-medium text-muted-foreground">Remaining</p>
          <p className={`text-3xl font-bold font-display mt-2 ${monthlyBudget - totalSpent < 0 ? 'text-destructive' : 'text-success'}`}>
            {formatCurrency(monthlyBudget - totalSpent, currency)}
          </p>
        </div>
      </div>

      {/* Bar Chart */}
      <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
        <h3 className="text-lg font-semibold font-display mb-4">Budget vs Spending by Category</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ left: 80, right: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis type="number" tickFormatter={(v) => `$${v}`} />
              <YAxis type="category" dataKey="name" width={75} />
              <Tooltip
                formatter={(value: number, name: string) => [formatCurrency(value, currency), name]}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Bar dataKey="budget" name="Budget" fill="hsl(var(--muted))" radius={[0, 4, 4, 0]} />
              <Bar dataKey="spent" name="Spent" radius={[0, 4, 4, 0]}>
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.isOver ? 'hsl(var(--destructive))' : entry.color}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Progress */}
      <BudgetProgress
        categories={categories}
        spending={spending}
        currency={currency}
      />
    </div>
  );
}
