import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { ExpenseCategory } from '@/types/budget';
import { formatCurrency } from '@/lib/formatters';

interface SpendingChartProps {
  categories: ExpenseCategory[];
  spending: Record<string, number>;
  currency: string;
}

export function SpendingChart({ categories, spending, currency }: SpendingChartProps) {
  const data = categories
    .map(cat => ({
      name: cat.name,
      value: spending[cat.id] || 0,
      color: cat.color,
    }))
    .filter(item => item.value > 0);

  const total = data.reduce((sum, item) => sum + item.value, 0);

  if (data.length === 0) {
    return (
      <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
        <h3 className="text-lg font-semibold font-display mb-4">Spending Distribution</h3>
        <div className="h-64 flex items-center justify-center text-muted-foreground">
          No spending data for this month
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
      <h3 className="text-lg font-semibold font-display mb-4">Spending Distribution</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number) => formatCurrency(value, currency)}
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
              }}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => (
                <span className="text-sm text-foreground">{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-center">
        <p className="text-sm text-muted-foreground">Total Spent</p>
        <p className="text-2xl font-bold font-display">{formatCurrency(total, currency)}</p>
      </div>
    </div>
  );
}
