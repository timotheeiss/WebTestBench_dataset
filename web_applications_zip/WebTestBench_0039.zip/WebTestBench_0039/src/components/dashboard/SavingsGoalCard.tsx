import { Progress } from '@/components/ui/progress';
import { SavingsGoal } from '@/types/budget';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { Target, Calendar } from 'lucide-react';

interface SavingsGoalCardProps {
  goals: SavingsGoal[];
  currency: string;
}

export function SavingsGoalCard({ goals, currency }: SavingsGoalCardProps) {
  return (
    <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
      <div className="flex items-center gap-2 mb-4">
        <Target className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold font-display">Savings Goals</h3>
      </div>
      <div className="space-y-4">
        {goals.map((goal, index) => {
          const percentage = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
          const remaining = goal.targetAmount - goal.currentAmount;

          return (
            <div
              key={goal.id}
              className="p-4 rounded-lg bg-muted/50 animate-slide-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-medium">{goal.name}</h4>
                  {goal.deadline && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(goal.deadline)}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-primary">
                    {formatCurrency(goal.currentAmount, currency)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    of {formatCurrency(goal.targetAmount, currency)}
                  </p>
                </div>
              </div>
              <Progress value={percentage} className="h-2 mb-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{percentage.toFixed(0)}% complete</span>
                <span>{formatCurrency(remaining, currency)} to go</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
