import { cn } from '@/lib/utils';
import { formatCurrency } from '@/lib/formatters';
import { Progress } from '@/components/ui/progress';
import { ExpenseCategory } from '@/types/budget';
import { AlertTriangle } from 'lucide-react';

interface BudgetProgressProps {
  categories: ExpenseCategory[];
  spending: Record<string, number>;
  currency: string;
}

export function BudgetProgress({ categories, spending, currency }: BudgetProgressProps) {
  return (
    <div className="rounded-xl bg-card p-6 shadow-sm border border-border/50 animate-fade-in">
      <h3 className="text-lg font-semibold font-display mb-4">Budget vs. Actual</h3>
      <div className="space-y-5">
        {categories.map((category, index) => {
          const spent = spending[category.id] || 0;
          const percentage = Math.min((spent / category.budgetAmount) * 100, 100);
          const isOverBudget = spent > category.budgetAmount;
          const overAmount = spent - category.budgetAmount;

          return (
            <div
              key={category.id}
              className="animate-slide-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-sm font-medium">{category.name}</span>
                  {isOverBudget && (
                    <AlertTriangle className="h-4 w-4 text-warning" />
                  )}
                </div>
                <div className="text-right">
                  <span className={cn(
                    "text-sm font-medium",
                    isOverBudget && "text-destructive"
                  )}>
                    {formatCurrency(spent, currency)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {' / '}{formatCurrency(category.budgetAmount, currency)}
                  </span>
                </div>
              </div>
              <div className="relative">
                <Progress
                  value={percentage}
                  className={cn(
                    "h-2",
                    isOverBudget && "[&>div]:bg-destructive"
                  )}
                  style={{
                    ['--progress-color' as string]: isOverBudget ? undefined : category.color,
                  }}
                />
                {isOverBudget && (
                  <p className="text-xs text-destructive mt-1">
                    Over budget by {formatCurrency(overAmount, currency)}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
