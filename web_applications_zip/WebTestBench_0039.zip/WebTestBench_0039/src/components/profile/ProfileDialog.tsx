import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserProfile, IncomeSource, ExpenseCategory, SavingsGoal } from '@/types/budget';
import { formatCurrency } from '@/lib/formatters';
import { Plus, Trash2, DollarSign, Tag, Target } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: UserProfile;
  onUpdateName: (name: string) => void;
  onAddIncome: (source: Omit<IncomeSource, 'id'>) => void;
  onDeleteIncome: (id: string) => void;
  onAddCategory: (category: Omit<ExpenseCategory, 'id'>) => void;
  onUpdateCategory: (id: string, updates: Partial<ExpenseCategory>) => void;
  onDeleteCategory: (id: string) => void;
  onAddGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  onUpdateGoal: (id: string, updates: Partial<SavingsGoal>) => void;
  onDeleteGoal: (id: string) => void;
}

const CATEGORY_COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
  'hsl(160 60% 45%)',
  'hsl(200 70% 50%)',
  'hsl(220 60% 50%)',
];

export function ProfileDialog({
  open,
  onOpenChange,
  profile,
  onUpdateName,
  onAddIncome,
  onDeleteIncome,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onAddGoal,
  onUpdateGoal,
  onDeleteGoal,
}: ProfileDialogProps) {
  const [name, setName] = useState(profile.name);
  const [newIncomeName, setNewIncomeName] = useState('');
  const [newIncomeAmount, setNewIncomeAmount] = useState('');
  const [newIncomeFrequency, setNewIncomeFrequency] = useState<IncomeSource['frequency']>('monthly');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryBudget, setNewCategoryBudget] = useState('');
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalCurrent, setNewGoalCurrent] = useState('');
  const [newGoalDeadline, setNewGoalDeadline] = useState('');

  const handleAddIncome = () => {
    if (newIncomeName && newIncomeAmount) {
      onAddIncome({
        name: newIncomeName,
        amount: parseFloat(newIncomeAmount),
        frequency: newIncomeFrequency,
      });
      setNewIncomeName('');
      setNewIncomeAmount('');
    }
  };

  const handleAddCategory = () => {
    if (newCategoryName && newCategoryBudget) {
      const colorIndex = profile.expenseCategories.length % CATEGORY_COLORS.length;
      onAddCategory({
        name: newCategoryName,
        budgetAmount: parseFloat(newCategoryBudget),
        color: CATEGORY_COLORS[colorIndex],
        icon: 'Tag',
      });
      setNewCategoryName('');
      setNewCategoryBudget('');
    }
  };

  const handleAddGoal = () => {
    if (newGoalName && newGoalTarget) {
      onAddGoal({
        name: newGoalName,
        targetAmount: parseFloat(newGoalTarget),
        currentAmount: parseFloat(newGoalCurrent) || 0,
        deadline: newGoalDeadline || undefined,
      });
      setNewGoalName('');
      setNewGoalTarget('');
      setNewGoalCurrent('');
      setNewGoalDeadline('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Profile Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" className="mt-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="income">Income</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="goals">Goals</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <div className="flex gap-2">
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                />
                <Button onClick={() => onUpdateName(name)}>Save</Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="income" className="space-y-4 mt-4">
            <div className="flex items-center gap-2 mb-4">
              <DollarSign className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Income Sources</h4>
            </div>

            {/* Existing income sources */}
            <div className="space-y-2">
              {profile.incomeSources.map(source => (
                <div key={source.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div>
                    <p className="font-medium">{source.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(source.amount, profile.currency)} / {source.frequency}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDeleteIncome(source.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            {/* Add new income */}
            <div className="border-t pt-4 space-y-3">
              <Label>Add New Income Source</Label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <Input
                  placeholder="Source name"
                  value={newIncomeName}
                  onChange={(e) => setNewIncomeName(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Amount"
                  value={newIncomeAmount}
                  onChange={(e) => setNewIncomeAmount(e.target.value)}
                />
                <Select value={newIncomeFrequency} onValueChange={(v: IncomeSource['frequency']) => setNewIncomeFrequency(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleAddIncome} className="w-full" disabled={!newIncomeName || !newIncomeAmount}>
                <Plus className="h-4 w-4 mr-2" /> Add Income Source
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4 mt-4">
            <div className="flex items-center gap-2 mb-4">
              <Tag className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Expense Categories</h4>
            </div>

            {/* Existing categories */}
            <div className="space-y-2">
              {profile.expenseCategories.map(cat => (
                <div key={cat.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: cat.color }}
                    />
                    <div>
                      <p className="font-medium">{cat.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Budget: {formatCurrency(cat.budgetAmount, profile.currency)}/mo
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      className="w-24"
                      value={cat.budgetAmount}
                      onChange={(e) => onUpdateCategory(cat.id, { budgetAmount: parseFloat(e.target.value) || 0 })}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDeleteCategory(cat.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add new category */}
            <div className="border-t pt-4 space-y-3">
              <Label>Add New Category</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Input
                  placeholder="Category name"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Monthly budget"
                  value={newCategoryBudget}
                  onChange={(e) => setNewCategoryBudget(e.target.value)}
                />
              </div>
              <Button onClick={handleAddCategory} className="w-full" disabled={!newCategoryName || !newCategoryBudget}>
                <Plus className="h-4 w-4 mr-2" /> Add Category
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="goals" className="space-y-4 mt-4">
            <div className="flex items-center gap-2 mb-4">
              <Target className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Savings Goals</h4>
            </div>

            {/* Existing goals */}
            <div className="space-y-2">
              {profile.savingsGoals.map(goal => (
                <div key={goal.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex-1">
                    <p className="font-medium">{goal.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(goal.currentAmount, profile.currency)} / {formatCurrency(goal.targetAmount, profile.currency)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      className="w-28"
                      placeholder="Current"
                      value={goal.currentAmount}
                      onChange={(e) => onUpdateGoal(goal.id, { currentAmount: parseFloat(e.target.value) || 0 })}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDeleteGoal(goal.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add new goal */}
            <div className="border-t pt-4 space-y-3">
              <Label>Add New Savings Goal</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Input
                  placeholder="Goal name"
                  value={newGoalName}
                  onChange={(e) => setNewGoalName(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Target amount"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Current amount (optional)"
                  value={newGoalCurrent}
                  onChange={(e) => setNewGoalCurrent(e.target.value)}
                />
                <Input
                  type="date"
                  placeholder="Deadline (optional)"
                  value={newGoalDeadline}
                  onChange={(e) => setNewGoalDeadline(e.target.value)}
                />
              </div>
              <Button onClick={handleAddGoal} className="w-full" disabled={!newGoalName || !newGoalTarget}>
                <Plus className="h-4 w-4 mr-2" /> Add Goal
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
