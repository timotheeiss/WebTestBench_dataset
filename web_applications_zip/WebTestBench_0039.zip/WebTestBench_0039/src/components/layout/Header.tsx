import { Wallet, User } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  userName: string;
  onProfileClick: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Header({ userName, onProfileClick, activeTab, onTabChange }: HeaderProps) {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'transactions', label: 'Transactions' },
    { id: 'budget', label: 'Budget' },
    { id: 'goals', label: 'Goals' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-primary p-2">
              <Wallet className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold font-display">BudgetWise</span>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            {tabs.map(tab => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => onTabChange(tab.id)}
                className="font-medium"
              >
                {tab.label}
              </Button>
            ))}
          </nav>

          <Button
            variant="ghost"
            size="sm"
            onClick={onProfileClick}
            className="flex items-center gap-2"
          >
            <div className="rounded-full bg-muted p-1.5">
              <User className="h-4 w-4" />
            </div>
            <span className="hidden sm:inline font-medium">{userName}</span>
          </Button>
        </div>

        {/* Mobile navigation */}
        <nav className="md:hidden flex items-center gap-1 pb-3 overflow-x-auto">
          {tabs.map(tab => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => onTabChange(tab.id)}
              className="font-medium whitespace-nowrap"
            >
              {tab.label}
            </Button>
          ))}
        </nav>
      </div>
    </header>
  );
}
