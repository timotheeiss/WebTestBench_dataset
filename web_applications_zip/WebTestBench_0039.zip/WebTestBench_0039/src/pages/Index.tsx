import { useState } from 'react';
import { useBudgetStore } from '@/hooks/useBudgetStore';
import { Header } from '@/components/layout/Header';
import { DashboardView } from '@/components/views/DashboardView';
import { TransactionsView } from '@/components/views/TransactionsView';
import { BudgetView } from '@/components/views/BudgetView';
import { GoalsView } from '@/components/views/GoalsView';
import { ProfileDialog } from '@/components/profile/ProfileDialog';
import { getCurrentMonth, getCurrentYear } from '@/lib/formatters';

const Index = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [profileOpen, setProfileOpen] = useState(false);

  const {
    state,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addCategory,
    updateCategory,
    deleteCategory,
    addIncomeSource,
    deleteIncomeSource,
    addSavingsGoal,
    updateSavingsGoal,
    deleteSavingsGoal,
    updateProfileName,
    getMonthlyIncome,
    getMonthlyBudget,
    getSpendingByCategory,
  } = useBudgetStore();

  const currentMonth = getCurrentMonth();
  const currentYear = getCurrentYear();
  const spending = getSpendingByCategory(currentMonth, currentYear);

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={state.profile.name}
        onProfileClick={() => setProfileOpen(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <main className="container mx-auto px-4 py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            profile={state.profile}
            transactions={state.transactions}
            getMonthlyIncome={getMonthlyIncome}
            getMonthlyBudget={getMonthlyBudget}
            getSpendingByCategory={getSpendingByCategory}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsView
            transactions={state.transactions}
            categories={state.profile.expenseCategories}
            currency={state.profile.currency}
            onAddTransaction={addTransaction}
            onUpdateTransaction={updateTransaction}
            onDeleteTransaction={deleteTransaction}
          />
        )}

        {activeTab === 'budget' && (
          <BudgetView
            categories={state.profile.expenseCategories}
            spending={spending}
            currency={state.profile.currency}
            monthlyBudget={getMonthlyBudget()}
          />
        )}

        {activeTab === 'goals' && (
          <GoalsView
            goals={state.profile.savingsGoals}
            currency={state.profile.currency}
            onAddGoal={addSavingsGoal}
            onUpdateGoal={updateSavingsGoal}
            onDeleteGoal={deleteSavingsGoal}
          />
        )}
      </main>

      <ProfileDialog
        open={profileOpen}
        onOpenChange={setProfileOpen}
        profile={state.profile}
        onUpdateName={updateProfileName}
        onAddIncome={addIncomeSource}
        onDeleteIncome={deleteIncomeSource}
        onAddCategory={addCategory}
        onUpdateCategory={updateCategory}
        onDeleteCategory={deleteCategory}
        onAddGoal={addSavingsGoal}
        onUpdateGoal={updateSavingsGoal}
        onDeleteGoal={deleteSavingsGoal}
      />
    </div>
  );
};

export default Index;
