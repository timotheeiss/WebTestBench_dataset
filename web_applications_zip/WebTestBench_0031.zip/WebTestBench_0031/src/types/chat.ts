export interface User {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatar: string;
  isOnline: boolean;
  createdAt: Date;
}

export interface Message {
  id: string;
  roomId: string;
  userId: string;
  content: string;
  timestamp: Date;
}

export interface ChatRoom {
  id: string;
  name: string;
  description: string;
  icon: string;
  memberIds: string[];
  createdAt: Date;
}

export interface Theme {
  id: string;
  name: string;
  className: string;
}

export interface FontStyle {
  id: string;
  name: string;
  className: string;
}

export type ThemeId = 'indigo' | 'emerald' | 'rose' | 'amber' | 'cyan';
export type FontStyleId = 'default' | 'modern' | 'rounded' | 'mono';
