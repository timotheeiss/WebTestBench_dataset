import { User, ChatRoom, Message, Theme, FontStyle } from '@/types/chat';

export const themes: Theme[] = [
  { id: 'indigo', name: 'Indigo', className: 'theme-indigo' },
  { id: 'emerald', name: 'Emerald', className: 'theme-emerald' },
  { id: 'rose', name: 'Rose', className: 'theme-rose' },
  { id: 'amber', name: 'Amber', className: 'theme-amber' },
  { id: 'cyan', name: 'Cyan', className: 'theme-cyan' },
];

export const fontStyles: FontStyle[] = [
  { id: 'default', name: 'Clean', className: 'font-style-default' },
  { id: 'modern', name: 'Modern', className: 'font-style-modern' },
  { id: 'rounded', name: 'Friendly', className: 'font-style-rounded' },
  { id: 'mono', name: 'Monospace', className: 'font-style-mono' },
];

export const defaultUsers: User[] = [
  {
    id: 'user-1',
    username: 'alex_dev',
    displayName: 'Alex Chen',
    bio: 'Full-stack developer passionate about clean code and coffee ☕',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex',
    isOnline: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: 'user-2',
    username: 'sarah_designs',
    displayName: 'Sarah Miller',
    bio: 'UI/UX Designer | Making the web beautiful one pixel at a time ✨',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
    isOnline: true,
    createdAt: new Date('2024-02-20'),
  },
  {
    id: 'user-3',
    username: 'mike_pm',
    displayName: 'Mike Johnson',
    bio: 'Product Manager | Bridging the gap between ideas and reality 🚀',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike',
    isOnline: false,
    createdAt: new Date('2024-01-05'),
  },
  {
    id: 'user-4',
    username: 'emma_qa',
    displayName: 'Emma Wilson',
    bio: 'QA Engineer | Finding bugs so you don\'t have to 🐛',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=emma',
    isOnline: true,
    createdAt: new Date('2024-03-10'),
  },
];

export const defaultRooms: ChatRoom[] = [
  {
    id: 'room-general',
    name: 'General',
    description: 'General discussion and announcements',
    icon: '💬',
    memberIds: ['user-1', 'user-2', 'user-3', 'user-4'],
    createdAt: new Date('2024-01-01'),
  },
  {
    id: 'room-dev',
    name: 'Development',
    description: 'Technical discussions and code reviews',
    icon: '💻',
    memberIds: ['user-1', 'user-2', 'user-4'],
    createdAt: new Date('2024-01-01'),
  },
  {
    id: 'room-design',
    name: 'Design',
    description: 'UI/UX discussions and feedback',
    icon: '🎨',
    memberIds: ['user-1', 'user-2', 'user-3'],
    createdAt: new Date('2024-01-01'),
  },
  {
    id: 'room-random',
    name: 'Random',
    description: 'Off-topic fun and memes',
    icon: '🎲',
    memberIds: ['user-1', 'user-2', 'user-3', 'user-4'],
    createdAt: new Date('2024-01-01'),
  },
];

export const defaultMessages: Message[] = [
  {
    id: 'msg-1',
    roomId: 'room-general',
    userId: 'user-1',
    content: 'Hey everyone! 👋 Welcome to the new chat platform!',
    timestamp: new Date('2024-12-13T09:00:00'),
  },
  {
    id: 'msg-2',
    roomId: 'room-general',
    userId: 'user-2',
    content: 'This looks amazing! Love the design 🎨',
    timestamp: new Date('2024-12-13T09:05:00'),
  },
  {
    id: 'msg-3',
    roomId: 'room-general',
    userId: 'user-3',
    content: 'Great work team! Looking forward to using this for our daily standups.',
    timestamp: new Date('2024-12-13T09:10:00'),
  },
  {
    id: 'msg-4',
    roomId: 'room-general',
    userId: 'user-4',
    content: 'Just ran some tests and everything seems to work smoothly! 🚀',
    timestamp: new Date('2024-12-13T09:15:00'),
  },
  {
    id: 'msg-5',
    roomId: 'room-dev',
    userId: 'user-1',
    content: 'Anyone have experience with the new React 19 features?',
    timestamp: new Date('2024-12-13T10:00:00'),
  },
  {
    id: 'msg-6',
    roomId: 'room-dev',
    userId: 'user-4',
    content: 'Yes! The new compiler is incredible. Seeing 2x performance improvements in some cases.',
    timestamp: new Date('2024-12-13T10:05:00'),
  },
  {
    id: 'msg-7',
    roomId: 'room-dev',
    userId: 'user-1',
    content: 'That\'s awesome! We should plan a migration strategy soon 📋',
    timestamp: new Date('2024-12-13T10:10:00'),
  },
  {
    id: 'msg-8',
    roomId: 'room-design',
    userId: 'user-2',
    content: 'Just uploaded the new mockups for the dashboard redesign!',
    timestamp: new Date('2024-12-13T11:00:00'),
  },
  {
    id: 'msg-9',
    roomId: 'room-design',
    userId: 'user-3',
    content: 'These look fantastic Sarah! Love the new color palette 💜',
    timestamp: new Date('2024-12-13T11:15:00'),
  },
  {
    id: 'msg-10',
    roomId: 'room-random',
    userId: 'user-4',
    content: 'Anyone else excited for the weekend? 🎉',
    timestamp: new Date('2024-12-13T12:00:00'),
  },
  {
    id: 'msg-11',
    roomId: 'room-random',
    userId: 'user-1',
    content: 'Absolutely! Planning to catch up on some side projects 🛠️',
    timestamp: new Date('2024-12-13T12:05:00'),
  },
  {
    id: 'msg-12',
    roomId: 'room-random',
    userId: 'user-2',
    content: 'I\'m going hiking! Need to disconnect for a bit 🏔️',
    timestamp: new Date('2024-12-13T12:10:00'),
  },
];

export const emojiList = [
  '😀', '😃', '😄', '😁', '😅', '😂', '🤣', '😊', '😇', '🙂',
  '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋',
  '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐',
  '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥', '😌',
  '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧',
  '🥵', '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '🥸', '😎', '🤓',
  '👋', '👍', '👎', '👊', '✊', '🤛', '🤜', '🤝', '🙏', '✌️',
  '🤞', '🤟', '🤘', '👌', '🤏', '👈', '👉', '👆', '👇', '☝️',
  '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔',
  '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '❣️', '💌',
  '🔥', '✨', '⭐', '🌟', '💫', '🎉', '🎊', '🎈', '🎁', '🏆',
  '🚀', '💻', '📱', '💡', '🔔', '📢', '💬', '💭', '🗯️', '💤',
];
