import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Message, ChatRoom } from '@/types/chat';
import { defaultMessages, defaultRooms } from '@/data/mockData';
import { useAuth } from './AuthContext';

interface ChatContextType {
  rooms: ChatRoom[];
  messages: Message[];
  currentRoom: ChatRoom | null;
  setCurrentRoom: (room: ChatRoom) => void;
  sendMessage: (content: string) => void;
  searchMessages: (query: string) => Message[];
  getRoomMessages: (roomId: string) => Message[];
  joinRoom: (roomId: string) => void;
}

const ChatContext = createContext<ChatContextType | null>(null);

const MESSAGES_KEY = 'chat_app_messages';
const ROOMS_KEY = 'chat_app_rooms';

export function ChatProvider({ children }: { children: ReactNode }) {
  const { currentUser } = useAuth();
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentRoom, setCurrentRoom] = useState<ChatRoom | null>(null);

  useEffect(() => {
    // Load data from localStorage or use defaults
    const storedMessages = localStorage.getItem(MESSAGES_KEY);
    const storedRooms = localStorage.getItem(ROOMS_KEY);

    if (storedMessages) {
      const parsed = JSON.parse(storedMessages);
      setMessages(parsed.map((m: Message) => ({ ...m, timestamp: new Date(m.timestamp) })));
    } else {
      setMessages(defaultMessages);
      localStorage.setItem(MESSAGES_KEY, JSON.stringify(defaultMessages));
    }

    if (storedRooms) {
      setRooms(JSON.parse(storedRooms));
    } else {
      setRooms(defaultRooms);
      localStorage.setItem(ROOMS_KEY, JSON.stringify(defaultRooms));
    }
  }, []);

  useEffect(() => {
    // Set default room when user logs in
    if (currentUser && rooms.length > 0 && !currentRoom) {
      const generalRoom = rooms.find(r => r.id === 'room-general');
      setCurrentRoom(generalRoom || rooms[0]);
    }
  }, [currentUser, rooms, currentRoom]);

  const sendMessage = (content: string) => {
    if (!currentUser || !currentRoom || !content.trim()) return;

    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      roomId: currentRoom.id,
      userId: currentUser.id,
      content: content.trim(),
      timestamp: new Date(),
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(updatedMessages));
  };

  const searchMessages = (query: string): Message[] => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    return messages.filter(m => 
      m.content.toLowerCase().includes(lowerQuery)
    );
  };

  const getRoomMessages = (roomId: string): Message[] => {
    return messages
      .filter(m => m.roomId === roomId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const joinRoom = (roomId: string) => {
    if (!currentUser) return;

    const updatedRooms = rooms.map(room => {
      if (room.id === roomId && !room.memberIds.includes(currentUser.id)) {
        return { ...room, memberIds: [...room.memberIds, currentUser.id] };
      }
      return room;
    });

    setRooms(updatedRooms);
    localStorage.setItem(ROOMS_KEY, JSON.stringify(updatedRooms));
  };

  return (
    <ChatContext.Provider value={{
      rooms,
      messages,
      currentRoom,
      setCurrentRoom,
      sendMessage,
      searchMessages,
      getRoomMessages,
      joinRoom,
    }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}
