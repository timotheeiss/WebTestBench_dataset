import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ThemeId, FontStyleId } from '@/types/chat';
import { themes, fontStyles } from '@/data/mockData';

interface PreferencesContextType {
  theme: ThemeId;
  fontStyle: FontStyleId;
  setTheme: (theme: ThemeId) => void;
  setFontStyle: (style: FontStyleId) => void;
  availableThemes: typeof themes;
  availableFontStyles: typeof fontStyles;
}

const PreferencesContext = createContext<PreferencesContextType | null>(null);

const PREFS_KEY = 'chat_app_preferences';

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeId>('indigo');
  const [fontStyle, setFontStyleState] = useState<FontStyleId>('default');

  useEffect(() => {
    const stored = localStorage.getItem(PREFS_KEY);
    if (stored) {
      const prefs = JSON.parse(stored);
      setThemeState(prefs.theme || 'indigo');
      setFontStyleState(prefs.fontStyle || 'default');
    }
  }, []);

  useEffect(() => {
    // Apply theme class to document
    const themeConfig = themes.find(t => t.id === theme);
    const fontConfig = fontStyles.find(f => f.id === fontStyle);
    
    // Remove all theme classes
    themes.forEach(t => document.documentElement.classList.remove(t.className));
    fontStyles.forEach(f => document.documentElement.classList.remove(f.className));
    
    // Add current classes
    if (themeConfig) {
      document.documentElement.classList.add(themeConfig.className);
    }
    if (fontConfig) {
      document.documentElement.classList.add(fontConfig.className);
    }
  }, [theme, fontStyle]);

  const setTheme = (newTheme: ThemeId) => {
    setThemeState(newTheme);
    const prefs = { theme: newTheme, fontStyle };
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  };

  const setFontStyle = (newStyle: FontStyleId) => {
    setFontStyleState(newStyle);
    const prefs = { theme, fontStyle: newStyle };
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  };

  return (
    <PreferencesContext.Provider value={{
      theme,
      fontStyle,
      setTheme,
      setFontStyle,
      availableThemes: themes,
      availableFontStyles: fontStyles,
    }}>
      {children}
    </PreferencesContext.Provider>
  );
}

export function usePreferences() {
  const context = useContext(PreferencesContext);
  if (!context) {
    throw new Error('usePreferences must be used within a PreferencesProvider');
  }
  return context;
}
