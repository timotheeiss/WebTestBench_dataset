import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types/chat';
import { defaultUsers } from '@/data/mockData';

interface AuthContextType {
  currentUser: User | null;
  users: User[];
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (username: string, displayName: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEY = 'chat_app_auth';
const USERS_KEY = 'chat_app_users';
const PASSWORDS_KEY = 'chat_app_passwords';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    // Load users from localStorage or use defaults
    const storedUsers = localStorage.getItem(USERS_KEY);
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    } else {
      setUsers(defaultUsers);
      localStorage.setItem(USERS_KEY, JSON.stringify(defaultUsers));
      // Set default passwords
      const defaultPasswords: Record<string, string> = {};
      defaultUsers.forEach(user => {
        defaultPasswords[user.username] = 'password123';
      });
      localStorage.setItem(PASSWORDS_KEY, JSON.stringify(defaultPasswords));
    }

    // Check for existing session
    const storedAuth = localStorage.getItem(STORAGE_KEY);
    if (storedAuth) {
      const userId = JSON.parse(storedAuth);
      const storedUsersList = localStorage.getItem(USERS_KEY);
      if (storedUsersList) {
        const allUsers = JSON.parse(storedUsersList);
        const user = allUsers.find((u: User) => u.id === userId);
        if (user) {
          setCurrentUser({ ...user, isOnline: true });
        }
      }
    }
  }, []);

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const storedPasswords = localStorage.getItem(PASSWORDS_KEY);
    const passwords: Record<string, string> = storedPasswords ? JSON.parse(storedPasswords) : {};

    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
    
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    if (passwords[user.username] !== password) {
      return { success: false, error: 'Invalid password' };
    }

    const loggedInUser = { ...user, isOnline: true };
    setCurrentUser(loggedInUser);
    
    // Update user's online status
    const updatedUsers = users.map(u => 
      u.id === user.id ? loggedInUser : u
    );
    setUsers(updatedUsers);
    localStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user.id));

    return { success: true };
  };

  const register = async (username: string, displayName: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
      return { success: false, error: 'Username already taken' };
    }

    if (username.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters' };
    }

    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    const newUser: User = {
      id: `user-${Date.now()}`,
      username: username.toLowerCase(),
      displayName: displayName || username,
      bio: 'Hey there! I\'m new here 👋',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      isOnline: true,
      createdAt: new Date(),
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    setCurrentUser(newUser);
    
    localStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser.id));
    
    // Store password
    const storedPasswords = localStorage.getItem(PASSWORDS_KEY);
    const passwords: Record<string, string> = storedPasswords ? JSON.parse(storedPasswords) : {};
    passwords[username.toLowerCase()] = password;
    localStorage.setItem(PASSWORDS_KEY, JSON.stringify(passwords));

    return { success: true };
  };

  const logout = () => {
    if (currentUser) {
      const updatedUsers = users.map(u => 
        u.id === currentUser.id ? { ...u, isOnline: false } : u
      );
      setUsers(updatedUsers);
      localStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
    }
    setCurrentUser(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  const updateProfile = (updates: Partial<User>) => {
    if (!currentUser) return;

    const updatedUser = { ...currentUser, ...updates };
    setCurrentUser(updatedUser);

    const updatedUsers = users.map(u => 
      u.id === currentUser.id ? updatedUser : u
    );
    setUsers(updatedUsers);
    localStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      users,
      isAuthenticated: !!currentUser,
      login,
      register,
      logout,
      updateProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
