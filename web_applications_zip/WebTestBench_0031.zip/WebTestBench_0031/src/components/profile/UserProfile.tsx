import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePreferences } from '@/contexts/PreferencesContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from '@/components/ui/sheet';
import { Settings, LogOut, Check, Palette, Type } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export function UserProfile() {
  const { currentUser, logout, updateProfile } = useAuth();
  const { 
    theme, 
    fontStyle, 
    setTheme, 
    setFontStyle,
    availableThemes,
    availableFontStyles 
  } = usePreferences();

  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [isEditing, setIsEditing] = useState(false);

  if (!currentUser) return null;

  const handleSaveProfile = () => {
    updateProfile({ displayName, bio });
    setIsEditing(false);
    toast.success('Profile updated!');
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
  };

  const themeColors: Record<string, string> = {
    indigo: 'bg-indigo-500',
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500',
    amber: 'bg-amber-500',
    cyan: 'bg-cyan-500',
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <button className="flex items-center gap-3 p-3 hover:bg-muted/50 rounded-lg transition-colors w-full">
          <img
            src={currentUser.avatar}
            alt={currentUser.displayName}
            className="w-10 h-10 rounded-full"
          />
          <div className="flex-1 text-left min-w-0">
            <p className="font-medium text-foreground text-sm truncate">
              {currentUser.displayName}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              @{currentUser.username}
            </p>
          </div>
          <Settings className="w-4 h-4 text-muted-foreground" />
        </button>
      </SheetTrigger>

      <SheetContent className="bg-background border-border overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-foreground">Settings</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Profile Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <img
                src={currentUser.avatar}
                alt={currentUser.displayName}
                className="w-16 h-16 rounded-full"
              />
              <div>
                <p className="font-semibold text-foreground">{currentUser.displayName}</p>
                <p className="text-sm text-muted-foreground">@{currentUser.username}</p>
              </div>
            </div>

            {isEditing ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="displayName">Display Name</Label>
                  <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="bg-muted/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="bg-muted/50 resize-none"
                    rows={3}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleSaveProfile} size="sm">
                    Save
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsEditing(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">{currentUser.bio}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setIsEditing(true)}
                >
                  Edit Profile
                </Button>
              </div>
            )}
          </div>

          <Separator className="bg-border" />

          {/* Theme Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-foreground">
              <Palette className="w-4 h-4" />
              <span className="font-medium">Theme Color</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {availableThemes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTheme(t.id as any)}
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                    themeColors[t.id],
                    theme === t.id && "ring-2 ring-offset-2 ring-offset-background ring-foreground"
                  )}
                >
                  {theme === t.id && <Check className="w-5 h-5 text-white" />}
                </button>
              ))}
            </div>
          </div>

          <Separator className="bg-border" />

          {/* Font Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-foreground">
              <Type className="w-4 h-4" />
              <span className="font-medium">Font Style</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {availableFontStyles.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFontStyle(f.id as any)}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm transition-all border",
                    f.className,
                    fontStyle === f.id 
                      ? "bg-primary text-primary-foreground border-primary" 
                      : "bg-muted/50 text-foreground border-border hover:bg-muted"
                  )}
                >
                  {f.name}
                </button>
              ))}
            </div>
          </div>

          <Separator className="bg-border" />

          {/* Logout */}
          <Button 
            variant="destructive" 
            className="w-full"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
