import { ChatSidebar } from '@/components/chat/ChatSidebar';
import { ChatArea } from '@/components/chat/ChatArea';
import { MemberList } from '@/components/chat/MemberList';
import { UserProfile } from '@/components/profile/UserProfile';
import { MessageCircle } from 'lucide-react';

export function ChatLayout() {
  return (
    <div className="h-screen flex bg-background">
      {/* Left Sidebar - Rooms + Profile */}
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-border bg-chat-sidebar flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <MessageCircle className="w-4 h-4 text-primary" />
          </div>
          <span className="font-bold text-foreground font-display">ChatFlow</span>
        </div>
        <ChatSidebar />
        <div className="border-t border-border bg-chat-sidebar">
          <UserProfile />
        </div>
      </div>

      {/* Main Chat Area */}
      <ChatArea />

      {/* Right Sidebar - Members */}
      <MemberList />
    </div>
  );
}
