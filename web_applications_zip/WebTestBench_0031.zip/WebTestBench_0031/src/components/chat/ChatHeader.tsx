import { useState } from 'react';
import { useChat } from '@/contexts/ChatContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Hash, Search, Users, X } from 'lucide-react';

interface ChatHeaderProps {
  onSearchResults: (messageIds: string[]) => void;
  onClearSearch: () => void;
}

export function ChatHeader({ onSearchResults, onClearSearch }: ChatHeaderProps) {
  const { currentRoom, searchMessages, getRoomMessages } = useChat();
  const { users } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  if (!currentRoom) return null;

  const onlineMembers = currentRoom.memberIds.filter(id => 
    users.find(u => u.id === id)?.isOnline
  ).length;

  const handleSearch = () => {
    if (searchQuery.trim()) {
      const results = searchMessages(searchQuery);
      const roomResults = results.filter(m => m.roomId === currentRoom.id);
      onSearchResults(roomResults.map(m => m.id));
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setIsSearching(false);
    onClearSearch();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
    if (e.key === 'Escape') {
      handleClearSearch();
    }
  };

  return (
    <div className="h-14 px-4 flex items-center justify-between border-b border-border bg-chat-header">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">{currentRoom.icon}</span>
          <Hash className="w-4 h-4 text-muted-foreground" />
          <h1 className="font-semibold text-foreground">{currentRoom.name}</h1>
        </div>
        <span className="text-muted-foreground text-sm hidden sm:block">
          {currentRoom.description}
        </span>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Users className="w-4 h-4" />
          <span>{onlineMembers} online</span>
        </div>

        {isSearching ? (
          <div className="flex items-center gap-2">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Search messages..."
              className="w-48 h-8 bg-muted/50 border-border/50 text-sm"
              autoFocus
            />
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={handleClearSearch}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSearching(true)}
            className="text-muted-foreground hover:text-foreground"
          >
            <Search className="w-4 h-4" />
          </Button>
        )}
      </div>
    </div>
  );
}
