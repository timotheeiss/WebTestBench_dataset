import { Button } from '@/components/ui/button';
import { ChevronUp, ChevronDown, X } from 'lucide-react';

interface SearchResultsProps {
  totalResults: number;
  currentIndex: number;
  onNext: () => void;
  onPrevious: () => void;
  onClose: () => void;
}

export function SearchResults({ 
  totalResults, 
  currentIndex, 
  onNext, 
  onPrevious, 
  onClose 
}: SearchResultsProps) {
  if (totalResults === 0) {
    return (
      <div className="px-4 py-2 bg-muted/50 border-b border-border flex items-center justify-between">
        <span className="text-sm text-muted-foreground">No messages found</span>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-7 w-7">
          <X className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="px-4 py-2 bg-primary/10 border-b border-border flex items-center justify-between">
      <span className="text-sm text-foreground">
        {currentIndex + 1} of {totalResults} results
      </span>
      <div className="flex items-center gap-1">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onPrevious}
          disabled={currentIndex === 0}
          className="h-7 w-7"
        >
          <ChevronUp className="w-4 h-4" />
        </Button>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onNext}
          disabled={currentIndex === totalResults - 1}
          className="h-7 w-7"
        >
          <ChevronDown className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-7 w-7">
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
