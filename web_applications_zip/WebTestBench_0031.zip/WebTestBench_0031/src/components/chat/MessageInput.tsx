import { useState, KeyboardEvent } from 'react';
import { useChat } from '@/contexts/ChatContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { EmojiPicker } from './EmojiPicker';
import { Send } from 'lucide-react';

export function MessageInput() {
  const [message, setMessage] = useState('');
  const { sendMessage, currentRoom } = useChat();

  const handleSend = () => {
    if (message.trim()) {
      sendMessage(message);
      setMessage('');
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleEmojiSelect = (emoji: string) => {
    setMessage(prev => prev + emoji);
  };

  if (!currentRoom) return null;

  return (
    <div className="p-4 border-t border-border bg-card">
      <div className="flex items-center gap-2">
        <EmojiPicker onEmojiSelect={handleEmojiSelect} />
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={`Message #${currentRoom.name}`}
          className="flex-1 bg-muted/50 border-border/50 focus:border-primary"
        />
        <Button 
          onClick={handleSend} 
          disabled={!message.trim()}
          className="px-4"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
