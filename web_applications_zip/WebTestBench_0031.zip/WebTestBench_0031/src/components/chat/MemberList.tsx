import { useChat } from '@/contexts/ChatContext';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

export function MemberList() {
  const { currentRoom } = useChat();
  const { users } = useAuth();

  if (!currentRoom) return null;

  const members = users.filter(u => currentRoom.memberIds.includes(u.id));
  const onlineMembers = members.filter(m => m.isOnline);
  const offlineMembers = members.filter(m => !m.isOnline);

  return (
    <div className="w-60 bg-chat-sidebar border-l border-border hidden lg:flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <h2 className="font-semibold text-foreground text-sm">Members</h2>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin p-2">
        {onlineMembers.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-muted-foreground uppercase px-2 mb-2">
              Online — {onlineMembers.length}
            </p>
            {onlineMembers.map(member => (
              <div 
                key={member.id}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="relative">
                  <img
                    src={member.avatar}
                    alt={member.displayName}
                    className="w-8 h-8 rounded-full"
                  />
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-online rounded-full border-2 border-chat-sidebar" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {member.displayName}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {offlineMembers.length > 0 && (
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase px-2 mb-2">
              Offline — {offlineMembers.length}
            </p>
            {offlineMembers.map(member => (
              <div 
                key={member.id}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors opacity-60"
              >
                <div className="relative">
                  <img
                    src={member.avatar}
                    alt={member.displayName}
                    className="w-8 h-8 rounded-full grayscale"
                  />
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-offline rounded-full border-2 border-chat-sidebar" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {member.displayName}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
