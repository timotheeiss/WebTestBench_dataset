import { useChat } from '@/contexts/ChatContext';
import { useAuth } from '@/contexts/AuthContext';
import { ChatRoom } from '@/types/chat';
import { cn } from '@/lib/utils';
import { Hash, Users } from 'lucide-react';

export function ChatSidebar() {
  const { rooms, currentRoom, setCurrentRoom, getRoomMessages } = useChat();
  const { users } = useAuth();

  const getLastMessage = (room: ChatRoom) => {
    const roomMessages = getRoomMessages(room.id);
    if (roomMessages.length === 0) return null;
    
    const lastMsg = roomMessages[roomMessages.length - 1];
    const user = users.find(u => u.id === lastMsg.userId);
    return {
      content: lastMsg.content.length > 30 
        ? lastMsg.content.slice(0, 30) + '...' 
        : lastMsg.content,
      userName: user?.displayName || 'Unknown',
    };
  };

  const getOnlineCount = (room: ChatRoom) => {
    return room.memberIds.filter(id => 
      users.find(u => u.id === id)?.isOnline
    ).length;
  };

  return (
    <div className="w-64 bg-chat-sidebar border-r border-border flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <h2 className="font-semibold text-foreground flex items-center gap-2">
          <Hash className="w-5 h-5 text-primary" />
          Chat Rooms
        </h2>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin p-2 space-y-1">
        {rooms.map(room => {
          const lastMessage = getLastMessage(room);
          const onlineCount = getOnlineCount(room);
          const isActive = currentRoom?.id === room.id;

          return (
            <button
              key={room.id}
              onClick={() => setCurrentRoom(room)}
              className={cn(
                "w-full text-left p-3 rounded-lg transition-all duration-200",
                "hover:bg-muted/50 group",
                isActive && "bg-primary/20 hover:bg-primary/25"
              )}
            >
              <div className="flex items-center gap-3">
                <span className="text-xl">{room.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      "font-medium text-sm",
                      isActive ? "text-primary" : "text-foreground"
                    )}>
                      {room.name}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Users className="w-3 h-3" />
                      {onlineCount}
                    </span>
                  </div>
                  {lastMessage && (
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      <span className="text-foreground/70">{lastMessage.userName}:</span>{' '}
                      {lastMessage.content}
                    </p>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
