import { Message, User } from '@/types/chat';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { forwardRef } from 'react';

interface MessageBubbleProps {
  message: Message;
  isHighlighted?: boolean;
}

export const MessageBubble = forwardRef<HTMLDivElement, MessageBubbleProps>(
  ({ message, isHighlighted }, ref) => {
    const { currentUser, users } = useAuth();
    
    const sender = users.find(u => u.id === message.userId);
    const isOwn = currentUser?.id === message.userId;

    return (
      <div
        ref={ref}
        className={cn(
          "flex gap-3 px-4 py-2 transition-colors duration-300 fade-in",
          isHighlighted && "message-highlight rounded-lg"
        )}
      >
        <img
          src={sender?.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=default'}
          alt={sender?.displayName || 'User'}
          className="w-10 h-10 rounded-full flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2">
            <span className={cn(
              "font-semibold text-sm",
              isOwn ? "text-primary" : "text-foreground"
            )}>
              {sender?.displayName || 'Unknown User'}
            </span>
            <span className="text-xs text-muted-foreground">
              {format(new Date(message.timestamp), 'MMM d, h:mm a')}
            </span>
          </div>
          <p className="text-foreground/90 mt-0.5 break-words">
            {message.content}
          </p>
        </div>
      </div>
    );
  }
);

MessageBubble.displayName = 'MessageBubble';
