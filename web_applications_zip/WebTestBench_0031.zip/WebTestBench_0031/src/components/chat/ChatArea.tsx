import { useState } from 'react';
import { ChatHeader } from './ChatHeader';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { SearchResults } from './SearchResults';

export function ChatArea() {
  const [searchResultIds, setSearchResultIds] = useState<string[]>([]);
  const [currentSearchIndex, setCurrentSearchIndex] = useState(0);

  const handleSearchResults = (ids: string[]) => {
    setSearchResultIds(ids);
    setCurrentSearchIndex(0);
  };

  const handleClearSearch = () => {
    setSearchResultIds([]);
    setCurrentSearchIndex(0);
  };

  const handleNextResult = () => {
    if (currentSearchIndex < searchResultIds.length - 1) {
      setCurrentSearchIndex(prev => prev + 1);
    }
  };

  const handlePreviousResult = () => {
    if (currentSearchIndex > 0) {
      setCurrentSearchIndex(prev => prev - 1);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-card min-w-0">
      <ChatHeader 
        onSearchResults={handleSearchResults} 
        onClearSearch={handleClearSearch} 
      />
      
      {searchResultIds.length > 0 && (
        <SearchResults
          totalResults={searchResultIds.length}
          currentIndex={currentSearchIndex}
          onNext={handleNextResult}
          onPrevious={handlePreviousResult}
          onClose={handleClearSearch}
        />
      )}

      <MessageList 
        highlightedIds={searchResultIds}
        currentHighlightIndex={currentSearchIndex}
      />
      <MessageInput />
    </div>
  );
}
