import { useEffect, useRef, useState } from 'react';
import { useChat } from '@/contexts/ChatContext';
import { MessageBubble } from './MessageBubble';
import { Message } from '@/types/chat';

interface MessageListProps {
  highlightedIds: string[];
  currentHighlightIndex: number;
}

export function MessageList({ highlightedIds, currentHighlightIndex }: MessageListProps) {
  const { currentRoom, getRoomMessages } = useChat();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    if (currentRoom) {
      setMessages(getRoomMessages(currentRoom.id));
    }
  }, [currentRoom, getRoomMessages]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (highlightedIds.length === 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, highlightedIds.length]);

  // Scroll to highlighted message
  useEffect(() => {
    if (highlightedIds.length > 0 && currentHighlightIndex >= 0) {
      const targetId = highlightedIds[currentHighlightIndex];
      const element = messageRefs.current.get(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [highlightedIds, currentHighlightIndex]);

  if (!currentRoom) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        Select a chat room to start messaging
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
        <span className="text-4xl mb-2">{currentRoom.icon}</span>
        <p>No messages yet in #{currentRoom.name}</p>
        <p className="text-sm">Be the first to send a message!</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin py-4">
      {messages.map((message, index) => (
        <MessageBubble
          key={message.id}
          ref={(el) => {
            if (el) messageRefs.current.set(message.id, el);
          }}
          message={message}
          isHighlighted={highlightedIds.includes(message.id) && 
            highlightedIds[currentHighlightIndex] === message.id}
        />
      ))}
      <div ref={messagesEndRef} />
    </div>
  );
}
