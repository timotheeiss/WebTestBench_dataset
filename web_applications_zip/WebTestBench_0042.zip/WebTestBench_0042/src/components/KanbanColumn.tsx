import { Task, TaskStatus } from '@/types/project';
import { TaskCard } from './TaskCard';
import { cn } from '@/lib/utils';
import { Droppable } from '@hello-pangea/dnd';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface KanbanColumnProps {
  id: TaskStatus;
  title: string;
  tasks: Task[];
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void;
  onDeleteTask: (taskId: string) => void;
  onTaskClick: (task: Task) => void;
  onAddTask: () => void;
}

const columnStyles: Record<TaskStatus, string> = {
  'todo': 'bg-column-todo',
  'in-progress': 'bg-column-progress',
  'review': 'bg-column-review',
  'done': 'bg-column-done',
};

const columnHeaderStyles: Record<TaskStatus, string> = {
  'todo': 'text-muted-foreground',
  'in-progress': 'text-primary',
  'review': 'text-accent',
  'done': 'text-success',
};

export const KanbanColumn = ({
  id,
  title,
  tasks,
  onUpdateTask,
  onDeleteTask,
  onTaskClick,
  onAddTask,
}: KanbanColumnProps) => {
  return (
    <div className={cn('flex flex-col rounded-xl p-3 min-h-[500px]', columnStyles[id])}>
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2">
          <h2 className={cn('font-mono font-semibold text-sm uppercase tracking-wide', columnHeaderStyles[id])}>
            {title}
          </h2>
          <span className="text-xs font-medium text-muted-foreground bg-background/50 px-2 py-0.5 rounded-full">
            {tasks.length}
          </span>
        </div>
        {id === 'todo' && (
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onAddTask}>
            <Plus className="h-4 w-4" />
          </Button>
        )}
      </div>

      <Droppable droppableId={id}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className={cn(
              'flex-1 space-y-3 min-h-[100px] rounded-lg transition-colors',
              snapshot.isDraggingOver && 'bg-primary/5 ring-2 ring-primary/20 ring-dashed'
            )}
          >
            {tasks.map((task, index) => (
              <TaskCard
                key={task.id}
                task={task}
                index={index}
                onUpdate={(updates) => onUpdateTask(task.id, updates)}
                onDelete={() => onDeleteTask(task.id)}
                onClick={() => onTaskClick(task)}
              />
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
};
