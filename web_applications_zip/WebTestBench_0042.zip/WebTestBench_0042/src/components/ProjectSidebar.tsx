import { useState } from 'react';
import { useProject } from '@/context/ProjectContext';
import { cn } from '@/lib/utils';
import { Plus, FolderKanban, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const colorOptions = [
  '#0ea5e9',
  '#8b5cf6',
  '#10b981',
  '#f59e0b',
  '#ef4444',
  '#ec4899',
];

export const ProjectSidebar = () => {
  const { projects, currentProjectId, setCurrentProjectId, addProject } = useProject();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [selectedColor, setSelectedColor] = useState(colorOptions[0]);

  const handleAddProject = () => {
    if (newProjectName.trim()) {
      addProject(newProjectName.trim(), newProjectDesc.trim(), selectedColor);
      setNewProjectName('');
      setNewProjectDesc('');
      setSelectedColor(colorOptions[0]);
      setIsDialogOpen(false);
    }
  };

  return (
    <aside
      className={cn(
        'h-full bg-sidebar border-r border-sidebar-border transition-all duration-300 flex flex-col',
        isCollapsed ? 'w-16' : 'w-64'
      )}
    >
      <div className="p-4 border-b border-sidebar-border flex items-center justify-between">
        {!isCollapsed && (
          <h1 className="font-mono text-lg font-bold text-sidebar-foreground tracking-tight">
            ProjectHub
          </h1>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="h-8 w-8 text-sidebar-foreground hover:bg-sidebar-accent"
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <div className="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin">
        {!isCollapsed && (
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-2 mb-2">
            Projects
          </p>
        )}
        {projects.map((project) => (
          <button
            key={project.id}
            onClick={() => setCurrentProjectId(project.id)}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200',
              currentProjectId === project.id
                ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
            )}
          >
            <div
              className="w-3 h-3 rounded-sm flex-shrink-0"
              style={{ backgroundColor: project.color }}
            />
            {!isCollapsed && (
              <span className="text-sm font-medium truncate">{project.name}</span>
            )}
          </button>
        ))}
      </div>

      <div className="p-3 border-t border-sidebar-border">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                'w-full justify-start gap-2 text-sidebar-foreground hover:bg-sidebar-accent',
                isCollapsed && 'justify-center'
              )}
            >
              <Plus className="h-4 w-4" />
              {!isCollapsed && <span>New Project</span>}
            </Button>
          </DialogTrigger>
          <DialogContent className="glass">
            <DialogHeader>
              <DialogTitle className="font-mono">Create New Project</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Name</label>
                <Input
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  placeholder="Project name"
                  className="mt-1.5"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Description</label>
                <Textarea
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  placeholder="Brief description..."
                  className="mt-1.5 resize-none"
                  rows={3}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Color</label>
                <div className="flex gap-2 mt-2">
                  {colorOptions.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={cn(
                        'w-8 h-8 rounded-lg transition-transform',
                        selectedColor === color && 'ring-2 ring-ring ring-offset-2 ring-offset-background scale-110'
                      )}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              <Button onClick={handleAddProject} className="w-full">
                Create Project
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </aside>
  );
};
