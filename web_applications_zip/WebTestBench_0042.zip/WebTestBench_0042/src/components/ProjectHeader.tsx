import { useProject } from '@/context/ProjectContext';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, Clock, AlertCircle, ListTodo } from 'lucide-react';

export const ProjectHeader = () => {
  const { currentProject } = useProject();

  if (!currentProject) return null;

  const totalTasks = currentProject.tasks.length;
  const doneTasks = currentProject.tasks.filter((t) => t.status === 'done').length;
  const inProgressTasks = currentProject.tasks.filter((t) => t.status === 'in-progress').length;
  const todoTasks = currentProject.tasks.filter((t) => t.status === 'todo').length;
  const reviewTasks = currentProject.tasks.filter((t) => t.status === 'review').length;
  const progressPercentage = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  const stats = [
    { label: 'To Do', value: todoTasks, icon: ListTodo, color: 'text-muted-foreground' },
    { label: 'In Progress', value: inProgressTasks, icon: Clock, color: 'text-primary' },
    { label: 'Review', value: reviewTasks, icon: AlertCircle, color: 'text-accent' },
    { label: 'Done', value: doneTasks, icon: CheckCircle2, color: 'text-success' },
  ];

  return (
    <header className="px-6 py-5 border-b border-border bg-background">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: currentProject.color }}
            />
            <h1 className="text-2xl font-mono font-bold tracking-tight">
              {currentProject.name}
            </h1>
          </div>
          <p className="text-muted-foreground text-sm max-w-md">
            {currentProject.description}
          </p>
        </div>

        <div className="flex items-center gap-6">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className={`flex items-center justify-center gap-1.5 ${stat.color}`}>
                <stat.icon className="h-4 w-4" />
                <span className="text-xl font-mono font-bold">{stat.value}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </div>
          ))}

          <div className="pl-6 border-l border-border">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl font-mono font-bold">{progressPercentage}%</span>
              <span className="text-xs text-muted-foreground">Complete</span>
            </div>
            <Progress value={progressPercentage} className="w-32 h-2" />
          </div>
        </div>
      </div>
    </header>
  );
};
