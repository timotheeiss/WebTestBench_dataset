import { Task, Priority } from '@/types/project';
import { users } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { Calendar, Flag, MoreHorizontal, Trash2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Draggable } from '@hello-pangea/dnd';
import { format, isPast, isToday } from 'date-fns';

interface TaskCardProps {
  task: Task;
  index: number;
  onUpdate: (updates: Partial<Task>) => void;
  onDelete: () => void;
  onClick: () => void;
}

const priorityConfig: Record<Priority, { label: string; className: string }> = {
  high: { label: 'High', className: 'bg-priority-high/15 text-priority-high border-priority-high/30' },
  medium: { label: 'Medium', className: 'bg-priority-medium/15 text-priority-medium border-priority-medium/30' },
  low: { label: 'Low', className: 'bg-priority-low/15 text-priority-low border-priority-low/30' },
};

export const TaskCard = ({ task, index, onUpdate, onDelete, onClick }: TaskCardProps) => {
  const assignee = task.assigneeId ? users.find((u) => u.id === task.assigneeId) : null;
  const isOverdue = task.dueDate && isPast(new Date(task.dueDate)) && task.status !== 'done';
  const isDueToday = task.dueDate && isToday(new Date(task.dueDate));

  return (
    <Draggable draggableId={task.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className={cn(
            'group bg-card border border-border rounded-lg p-4 cursor-pointer transition-all duration-200',
            'hover:border-primary/30 hover:shadow-md',
            snapshot.isDragging && 'shadow-xl rotate-2 border-primary'
          )}
          onClick={onClick}
        >
          <div className="flex items-start justify-between gap-2 mb-3">
            <h3 className="font-medium text-sm text-card-foreground leading-tight line-clamp-2">
              {task.title}
            </h3>
            <DropdownMenu>
              <DropdownMenuTrigger
                onClick={(e) => e.stopPropagation()}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreHorizontal className="h-4 w-4 text-muted-foreground hover:text-foreground" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete();
                  }}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {task.description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
              {task.description}
            </p>
          )}

          {task.progress > 0 && task.progress < 100 && (
            <div className="mb-3">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>Progress</span>
                <span>{task.progress}%</span>
              </div>
              <Progress value={task.progress} className="h-1.5" />
            </div>
          )}

          <div className="flex flex-wrap gap-1.5 mb-3">
            <Badge
              variant="outline"
              className={cn('text-xs px-2 py-0', priorityConfig[task.priority].className)}
            >
              <Flag className="h-3 w-3 mr-1" />
              {priorityConfig[task.priority].label}
            </Badge>
            {task.tags.slice(0, 2).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs px-2 py-0">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between">
            {task.dueDate && (
              <div
                className={cn(
                  'flex items-center gap-1 text-xs',
                  isOverdue && 'text-destructive',
                  isDueToday && !isOverdue && 'text-warning',
                  !isOverdue && !isDueToday && 'text-muted-foreground'
                )}
              >
                <Calendar className="h-3 w-3" />
                {format(new Date(task.dueDate), 'MMM d')}
              </div>
            )}
            {assignee && (
              <Avatar className="h-6 w-6">
                <AvatarImage src={assignee.avatar} alt={assignee.name} />
                <AvatarFallback className="text-xs">
                  {assignee.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        </div>
      )}
    </Draggable>
  );
};
