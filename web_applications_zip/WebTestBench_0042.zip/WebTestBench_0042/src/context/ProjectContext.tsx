import React, { createContext, useContext, useState, useCallback } from 'react';
import { Project, Task, TaskStatus, ChatMessage } from '@/types/project';
import { initialProjects, currentUserId } from '@/data/mockData';

interface ProjectContextType {
  projects: Project[];
  currentProjectId: string;
  setCurrentProjectId: (id: string) => void;
  currentProject: Project | undefined;
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
  moveTask: (taskId: string, newStatus: TaskStatus, newIndex: number) => void;
  addChatMessage: (content: string) => void;
  addProject: (name: string, description: string, color: string) => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [currentProjectId, setCurrentProjectId] = useState<string>(initialProjects[0].id);

  const currentProject = projects.find((p) => p.id === currentProjectId);

  const addTask = useCallback(
    (task: Omit<Task, 'id' | 'createdAt'>) => {
      const newTask: Task = {
        ...task,
        id: `t${Date.now()}`,
        createdAt: new Date().toISOString(),
      };

      setProjects((prev) =>
        prev.map((p) =>
          p.id === currentProjectId ? { ...p, tasks: [...p.tasks, newTask] } : p
        )
      );
    },
    [currentProjectId]
  );

  const updateTask = useCallback(
    (taskId: string, updates: Partial<Task>) => {
      setProjects((prev) =>
        prev.map((p) =>
          p.id === currentProjectId
            ? {
                ...p,
                tasks: p.tasks.map((t) => (t.id === taskId ? { ...t, ...updates } : t)),
              }
            : p
        )
      );
    },
    [currentProjectId]
  );

  const deleteTask = useCallback(
    (taskId: string) => {
      setProjects((prev) =>
        prev.map((p) =>
          p.id === currentProjectId
            ? { ...p, tasks: p.tasks.filter((t) => t.id !== taskId) }
            : p
        )
      );
    },
    [currentProjectId]
  );

  const moveTask = useCallback(
    (taskId: string, newStatus: TaskStatus, newIndex: number) => {
      setProjects((prev) =>
        prev.map((p) => {
          if (p.id !== currentProjectId) return p;

          const task = p.tasks.find((t) => t.id === taskId);
          if (!task) return p;

          const updatedTask = { ...task, status: newStatus };
          const otherTasks = p.tasks.filter((t) => t.id !== taskId);
          const tasksInColumn = otherTasks.filter((t) => t.status === newStatus);
          const tasksOutside = otherTasks.filter((t) => t.status !== newStatus);

          tasksInColumn.splice(newIndex, 0, updatedTask);

          return { ...p, tasks: [...tasksOutside, ...tasksInColumn] };
        })
      );
    },
    [currentProjectId]
  );

  const addChatMessage = useCallback(
    (content: string) => {
      const newMessage: ChatMessage = {
        id: `m${Date.now()}`,
        userId: currentUserId,
        content,
        timestamp: new Date().toISOString(),
      };

      setProjects((prev) =>
        prev.map((p) =>
          p.id === currentProjectId ? { ...p, chat: [...p.chat, newMessage] } : p
        )
      );
    },
    [currentProjectId]
  );

  const addProject = useCallback((name: string, description: string, color: string) => {
    const newProject: Project = {
      id: `p${Date.now()}`,
      name,
      description,
      color,
      tasks: [],
      chat: [],
      createdAt: new Date().toISOString(),
    };

    setProjects((prev) => [...prev, newProject]);
    setCurrentProjectId(newProject.id);
  }, []);

  return (
    <ProjectContext.Provider
      value={{
        projects,
        currentProjectId,
        setCurrentProjectId,
        currentProject,
        addTask,
        updateTask,
        deleteTask,
        moveTask,
        addChatMessage,
        addProject,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = () => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};
