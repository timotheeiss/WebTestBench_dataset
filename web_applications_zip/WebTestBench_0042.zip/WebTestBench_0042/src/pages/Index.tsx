import { ProjectProvider } from '@/context/ProjectContext';
import { ProjectSidebar } from '@/components/ProjectSidebar';
import { ProjectHeader } from '@/components/ProjectHeader';
import { KanbanBoard } from '@/components/KanbanBoard';
import { ChatPanel } from '@/components/ChatPanel';

const Index = () => {
  return (
    <ProjectProvider>
      <div className="flex h-screen bg-background overflow-hidden">
        <ProjectSidebar />
        <main className="flex-1 flex flex-col overflow-hidden">
          <ProjectHeader />
          <KanbanBoard />
        </main>
        <ChatPanel />
      </div>
    </ProjectProvider>
  );
};

export default Index;
