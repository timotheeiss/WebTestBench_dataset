import { Proposal, Member } from '@/types/proposal';

export const members: Member[] = [
  { id: '1', name: 'Alex Chen' },
  { id: '2', name: 'Sarah Miller' },
  { id: '3', name: 'Jordan Lee' },
  { id: '4', name: 'Emma Wilson' },
  { id: '5', name: 'Marcus Johnson' },
];

export const initialProposals: Proposal[] = [
  {
    id: '1',
    title: 'Community Garden Initiative',
    description: `We propose establishing a community garden in the vacant lot on Maple Street. This initiative aims to bring residents together, provide fresh produce for local food banks, and beautify our neighborhood.

**Key Benefits:**
- Fresh, organic produce for community members
- Educational workshops for children and adults
- Reduced food costs for participating families
- Environmental benefits through green space

**Budget Estimate:** $5,000 for initial setup including soil, seeds, tools, and fencing.

**Timeline:** Spring 2024 planting season`,
    authorId: '1',
    authorName: 'Alex Chen',
    status: 'draft',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-20T14:30:00Z',
    comments: [
      {
        id: 'c1',
        authorId: '2',
        authorName: 'Sarah Miller',
        content: 'Love this idea! I have experience with community gardens and would be happy to help organize.',
        createdAt: '2024-01-16T09:00:00Z',
      },
      {
        id: 'c2',
        authorId: '4',
        authorName: 'Emma Wilson',
        content: 'What about water access? We should ensure there is a plan for irrigation.',
        createdAt: '2024-01-17T11:30:00Z',
      },
    ],
    votes: [
      { memberId: '2', memberName: 'Sarah Miller', support: true, createdAt: '2024-01-21T10:00:00Z' },
      { memberId: '3', memberName: 'Jordan Lee', support: true, createdAt: '2024-01-21T11:00:00Z' },
      { memberId: '4', memberName: 'Emma Wilson', support: true, createdAt: '2024-01-21T12:00:00Z' },
      { memberId: '5', memberName: 'Marcus Johnson', support: false, createdAt: '2024-01-21T13:00:00Z' },
    ],
  },
  {
    id: '2',
    title: 'Monthly Neighborhood Cleanup Day',
    description: `Proposal to establish a recurring monthly cleanup event on the first Saturday of each month. Volunteers would gather to pick up litter, maintain public spaces, and plant seasonal flowers.

**Objectives:**
- Cleaner streets and public areas
- Stronger community bonds
- Pride in our neighborhood
- Teaching children about environmental responsibility

**Requirements:**
- Volunteer coordinators for each block
- Supplies: trash bags, gloves, and tools
- Refreshments for volunteers`,
    authorId: '2',
    authorName: 'Sarah Miller',
    status: 'discussion',
    createdAt: '2024-01-18T14:00:00Z',
    updatedAt: '2024-01-19T16:00:00Z',
    comments: [
      {
        id: 'c3',
        authorId: '1',
        authorName: 'Alex Chen',
        content: 'Great initiative! Maybe we could partner with local businesses for refreshments?',
        createdAt: '2024-01-19T08:00:00Z',
      },
    ],
    votes: [],
  },
  {
    id: '3',
    title: 'Street Lighting Improvement',
    description: `Several residents have expressed concerns about inadequate street lighting on Oak Avenue and Pine Street. This proposal requests the city council to install additional LED street lamps.

**Safety Concerns:**
- Poor visibility at night
- Increased crime reports in poorly lit areas
- Pedestrian safety issues

**Proposed Solution:**
- Install 8 new LED street lamps
- Upgrade existing lamps to brighter models
- Add motion-sensor lighting in alleyways`,
    authorId: '3',
    authorName: 'Jordan Lee',
    status: 'approved',
    createdAt: '2024-01-05T09:00:00Z',
    updatedAt: '2024-01-12T17:00:00Z',
    comments: [
      {
        id: 'c4',
        authorId: '5',
        authorName: 'Marcus Johnson',
        content: 'This is long overdue. Fully support this proposal.',
        createdAt: '2024-01-06T10:00:00Z',
      },
      {
        id: 'c5',
        authorId: '4',
        authorName: 'Emma Wilson',
        content: 'Has anyone contacted the city about this? I can help draft the formal request.',
        createdAt: '2024-01-07T14:00:00Z',
      },
    ],
    votes: [
      { memberId: '1', memberName: 'Alex Chen', support: true, createdAt: '2024-01-10T10:00:00Z' },
      { memberId: '2', memberName: 'Sarah Miller', support: true, createdAt: '2024-01-10T11:00:00Z' },
      { memberId: '4', memberName: 'Emma Wilson', support: true, createdAt: '2024-01-10T12:00:00Z' },
      { memberId: '5', memberName: 'Marcus Johnson', support: true, createdAt: '2024-01-10T13:00:00Z' },
    ],
  },
  {
    id: '4',
    title: 'Dog Park Construction',
    description: `Proposal to build a dedicated off-leash dog park in Memorial Park. Many dog owners currently use the main park area, which has caused conflicts with other park users.

**Features Requested:**
- Fenced area with double-gate entry
- Separate sections for large and small dogs
- Water fountains for dogs
- Waste bag stations
- Benches for owners

**Estimated Cost:** $15,000`,
    authorId: '4',
    authorName: 'Emma Wilson',
    status: 'rejected',
    createdAt: '2023-12-20T11:00:00Z',
    updatedAt: '2024-01-02T09:00:00Z',
    comments: [
      {
        id: 'c6',
        authorId: '3',
        authorName: 'Jordan Lee',
        content: 'While I love dogs, the budget seems too high. Can we explore cheaper alternatives?',
        createdAt: '2023-12-21T09:00:00Z',
      },
    ],
    votes: [
      { memberId: '1', memberName: 'Alex Chen', support: false, createdAt: '2023-12-28T10:00:00Z' },
      { memberId: '2', memberName: 'Sarah Miller', support: true, createdAt: '2023-12-28T11:00:00Z' },
      { memberId: '3', memberName: 'Jordan Lee', support: false, createdAt: '2023-12-28T12:00:00Z' },
      { memberId: '5', memberName: 'Marcus Johnson', support: false, createdAt: '2023-12-28T13:00:00Z' },
    ],
  },
  {
    id: '5',
    title: 'Free Community WiFi Hotspots',
    description: `Install public WiFi hotspots in key community areas to bridge the digital divide and ensure all residents have internet access.

**Proposed Locations:**
- Community Center
- Main Library
- Central Park pavilion
- Town Square

**Benefits:**
- Equal access to information
- Support for students and remote workers
- Increased foot traffic to local businesses`,
    authorId: '5',
    authorName: 'Marcus Johnson',
    status: 'draft',
    createdAt: '2024-01-22T08:00:00Z',
    updatedAt: '2024-01-22T08:00:00Z',
    comments: [],
    votes: [],
  },
];
