import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { Proposal, Comment, Vote, Member, ProposalStatus, STAGE_DURATION_MS } from '@/types/proposal';
import { initialProposals, members } from '@/data/proposals';

const STORAGE_KEY = 'community-proposals-data';

interface ProposalContextType {
  proposals: Proposal[];
  members: Member[];
  currentMember: Member;
  addProposal: (title: string, description: string) => void;
  updateProposalStatus: (proposalId: string, status: ProposalStatus) => void;
  addComment: (proposalId: string, content: string) => void;
  addVote: (proposalId: string, support: boolean) => void;
  getProposalById: (id: string) => Proposal | undefined;
  hasVoted: (proposalId: string) => boolean;
  getStageEndTime: (proposalId: string) => number | null;
}

const ProposalContext = createContext<ProposalContextType | undefined>(undefined);

function loadProposalsFromStorage(): Proposal[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load proposals from storage:', e);
  }
  return initialProposals;
}

function saveProposalsToStorage(proposals: Proposal[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(proposals));
  } catch (e) {
    console.error('Failed to save proposals to storage:', e);
  }
}

function processTimedTransitions(proposals: Proposal[]): Proposal[] {
  const now = Date.now();
  let hasChanges = false;

  const updated = proposals.map((proposal) => {
    // Check discussion stage expiration
    if (proposal.status === 'discussion' && proposal.discussionStartedAt) {
      const endTime = new Date(proposal.discussionStartedAt).getTime() + STAGE_DURATION_MS;
      if (now >= endTime) {
        hasChanges = true;
        return {
          ...proposal,
          status: 'voting' as ProposalStatus,
          votingStartedAt: new Date(endTime).toISOString(),
          updatedAt: new Date().toISOString(),
        };
      }
    }

    // Check voting stage expiration
    if (proposal.status === 'voting' && proposal.votingStartedAt) {
      const endTime = new Date(proposal.votingStartedAt).getTime() + STAGE_DURATION_MS;
      if (now >= endTime) {
        hasChanges = true;
        const supportVotes = proposal.votes.filter((v) => v.support).length;
        const opposeVotes = proposal.votes.filter((v) => !v.support).length;
        const newStatus: ProposalStatus = supportVotes > opposeVotes ? 'approved' : 'rejected';
        
        return {
          ...proposal,
          status: newStatus,
          updatedAt: new Date().toISOString(),
        };
      }
    }

    return proposal;
  });

  return hasChanges ? updated : proposals;
}

export function ProposalProvider({ children }: { children: ReactNode }) {
  const [proposals, setProposals] = useState<Proposal[]>(() => {
    const loaded = loadProposalsFromStorage();
    return processTimedTransitions(loaded);
  });
  const [currentMember] = useState<Member>(members[0]);

  // Process timed transitions and save to storage
  const processAndSave = useCallback((props: Proposal[]) => {
    const processed = processTimedTransitions(props);
    saveProposalsToStorage(processed);
    return processed;
  }, []);

  // Periodically check for timed transitions
  useEffect(() => {
    const interval = setInterval(() => {
      setProposals((prev) => {
        const processed = processTimedTransitions(prev);
        if (processed !== prev) {
          saveProposalsToStorage(processed);
        }
        return processed;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Save whenever proposals change
  useEffect(() => {
    saveProposalsToStorage(proposals);
  }, [proposals]);

  const addProposal = (title: string, description: string) => {
    const newProposal: Proposal = {
      id: Date.now().toString(),
      title,
      description,
      authorId: currentMember.id,
      authorName: currentMember.name,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      comments: [],
      votes: [],
    };
    setProposals((prev) => processAndSave([newProposal, ...prev]));
  };

  const updateProposalStatus = (proposalId: string, status: ProposalStatus) => {
    setProposals((prev) =>
      processAndSave(
        prev.map((p) => {
          if (p.id !== proposalId) return p;

          const updates: Partial<Proposal> = {
            status,
            updatedAt: new Date().toISOString(),
          };

          // Set timestamp when entering timed stages
          if (status === 'discussion' && p.status !== 'discussion') {
            updates.discussionStartedAt = new Date().toISOString();
            updates.votingStartedAt = undefined;
          } else if (status === 'voting' && p.status !== 'voting') {
            updates.votingStartedAt = new Date().toISOString();
          }

          return { ...p, ...updates };
        })
      )
    );
  };

  const addComment = (proposalId: string, content: string) => {
    const newComment: Comment = {
      id: Date.now().toString(),
      authorId: currentMember.id,
      authorName: currentMember.name,
      content,
      createdAt: new Date().toISOString(),
    };
    setProposals((prev) =>
      processAndSave(
        prev.map((p) =>
          p.id === proposalId
            ? {
                ...p,
                comments: [...p.comments, newComment],
                updatedAt: new Date().toISOString(),
              }
            : p
        )
      )
    );
  };

  const addVote = (proposalId: string, support: boolean) => {
    const newVote: Vote = {
      memberId: currentMember.id,
      memberName: currentMember.name,
      support,
      createdAt: new Date().toISOString(),
    };
    setProposals((prev) =>
      processAndSave(
        prev.map((p) =>
          p.id === proposalId
            ? {
                ...p,
                votes: [...p.votes.filter((v) => v.memberId !== currentMember.id), newVote],
                updatedAt: new Date().toISOString(),
              }
            : p
        )
      )
    );
  };

  const getProposalById = (id: string) => proposals.find((p) => p.id === id);

  const hasVoted = (proposalId: string) => {
    const proposal = getProposalById(proposalId);
    return proposal?.votes.some((v) => v.memberId === currentMember.id) ?? false;
  };

  const getStageEndTime = (proposalId: string): number | null => {
    const proposal = getProposalById(proposalId);
    if (!proposal) return null;

    if (proposal.status === 'discussion' && proposal.discussionStartedAt) {
      return new Date(proposal.discussionStartedAt).getTime() + STAGE_DURATION_MS;
    }
    if (proposal.status === 'voting' && proposal.votingStartedAt) {
      return new Date(proposal.votingStartedAt).getTime() + STAGE_DURATION_MS;
    }
    return null;
  };

  return (
    <ProposalContext.Provider
      value={{
        proposals,
        members,
        currentMember,
        addProposal,
        updateProposalStatus,
        addComment,
        addVote,
        getProposalById,
        hasVoted,
        getStageEndTime,
      }}
    >
      {children}
    </ProposalContext.Provider>
  );
}

export function useProposals() {
  const context = useContext(ProposalContext);
  if (!context) {
    throw new Error('useProposals must be used within a ProposalProvider');
  }
  return context;
}
