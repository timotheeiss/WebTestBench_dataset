import { useParams, Link } from 'react-router-dom';
import { useProposals } from '@/context/ProposalContext';
import { Header } from '@/components/Header';
import { StatusBadge } from '@/components/StatusBadge';
import { StatusTimeline } from '@/components/StatusTimeline';
import { VotingPanel } from '@/components/VotingPanel';
import { CommentSection } from '@/components/CommentSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Calendar, User } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { ProposalStatus } from '@/types/proposal';

const ProposalDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getProposalById, updateProposalStatus, currentMember, getStageEndTime } = useProposals();

  const proposal = getProposalById(id!);
  const stageEndTime = proposal ? getStageEndTime(proposal.id) : null;
  if (!proposal) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8">
          <div className="text-center py-16">
            <h2 className="text-2xl font-bold mb-2">Proposal not found</h2>
            <p className="text-muted-foreground mb-4">
              The proposal you're looking for doesn't exist.
            </p>
            <Link to="/">
              <Button>Back to Proposals</Button>
            </Link>
          </div>
        </main>
      </div>
    );
  }

  const isAuthor = proposal.authorId === currentMember.id;

  const handleStatusChange = (status: string) => {
    updateProposalStatus(proposal.id, status as ProposalStatus);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Proposals
        </Link>

        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          {/* Main Content */}
          <div className="space-y-6">
            {/* Header */}
            <Card className="shadow-soft overflow-hidden">
              <div className="h-1 gradient-primary" />
              <CardContent className="pt-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                  <h1 className="text-2xl font-bold tracking-tight">
                    {proposal.title}
                  </h1>
                  <StatusBadge status={proposal.status} />
                </div>

                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
                  <span className="flex items-center gap-1.5">
                    <User className="w-4 h-4" />
                    {proposal.authorName}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(proposal.createdAt), 'MMM d, yyyy')}
                  </span>
                  <span className="text-xs">
                    Updated {formatDistanceToNow(new Date(proposal.updatedAt), { addSuffix: true })}
                  </span>
                </div>

                <StatusTimeline currentStatus={proposal.status} stageEndTime={stageEndTime} />
              </CardContent>
            </Card>

            {/* Description */}
            <Card className="shadow-soft">
              <CardContent className="pt-6">
                <h2 className="font-semibold mb-4">Description</h2>
                <div className="prose prose-sm max-w-none text-muted-foreground whitespace-pre-wrap">
                  {proposal.description}
                </div>
              </CardContent>
            </Card>

            {/* Comments */}
            <CommentSection proposal={proposal} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Author Controls */}
            {isAuthor && (
              <Card className="shadow-soft">
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-3">Manage Proposal</h3>
                  <div className="space-y-2">
                    <label className="text-sm text-muted-foreground">
                      Change Status
                    </label>
                    <Select
                      value={proposal.status}
                      onValueChange={handleStatusChange}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="discussion">Discussion</SelectItem>
                        <SelectItem value="voting">Voting</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Voting Panel */}
            <VotingPanel proposal={proposal} />

            {/* Participants */}
            {proposal.votes.length > 0 && (
              <Card className="shadow-soft">
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-3">
                    Voters ({proposal.votes.length})
                  </h3>
                  <div className="space-y-2">
                    {proposal.votes.map((vote) => (
                      <div
                        key={vote.memberId}
                        className="flex items-center justify-between text-sm"
                      >
                        <span>{vote.memberName}</span>
                        <span
                          className={
                            vote.support ? 'text-success' : 'text-destructive'
                          }
                        >
                          {vote.support ? 'Support' : 'Oppose'}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProposalDetail;
