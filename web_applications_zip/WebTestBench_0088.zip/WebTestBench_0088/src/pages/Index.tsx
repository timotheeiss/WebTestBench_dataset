import { useState } from 'react';
import { ProposalCard } from '@/components/ProposalCard';
import { CreateProposalDialog } from '@/components/CreateProposalDialog';
import { StatusFilter } from '@/components/StatusFilter';
import { Header } from '@/components/Header';
import { useProposals } from '@/context/ProposalContext';
import { ProposalStatus } from '@/types/proposal';
import { FileText } from 'lucide-react';

const Index = () => {
  const { proposals } = useProposals();
  const [statusFilter, setStatusFilter] = useState<ProposalStatus | 'all'>('all');

  const filteredProposals =
    statusFilter === 'all'
      ? proposals
      : proposals.filter((p) => p.status === statusFilter);

  const stats = {
    total: proposals.length,
    active: proposals.filter((p) => p.status === 'voting').length,
    approved: proposals.filter((p) => p.status === 'approved').length,
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8">
        {/* Hero Section */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Proposals</h1>
              <p className="text-muted-foreground mt-1">
                Shape the future of our community together
              </p>
            </div>
            <CreateProposalDialog />
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 p-4 rounded-xl gradient-hero">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{stats.total}</div>
              <div className="text-xs text-muted-foreground">Total</div>
            </div>
            <div className="text-center border-x border-border">
              <div className="text-2xl font-bold text-warning">{stats.active}</div>
              <div className="text-xs text-muted-foreground">Active Voting</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-success">{stats.approved}</div>
              <div className="text-xs text-muted-foreground">Approved</div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-6">
          <StatusFilter
            selectedStatus={statusFilter}
            onStatusChange={setStatusFilter}
          />
        </div>

        {/* Proposals Grid */}
        {filteredProposals.length === 0 ? (
          <div className="text-center py-16">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-medium text-lg mb-2">No proposals found</h3>
            <p className="text-muted-foreground">
              {statusFilter === 'all'
                ? 'Be the first to create a proposal!'
                : `No proposals with status "${statusFilter}"`}
            </p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProposals.map((proposal) => (
              <ProposalCard key={proposal.id} proposal={proposal} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Index;
