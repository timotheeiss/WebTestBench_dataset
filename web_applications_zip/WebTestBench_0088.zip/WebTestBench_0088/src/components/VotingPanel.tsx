import { Proposal } from '@/types/proposal';
import { useProposals } from '@/context/ProposalContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ThumbsUp, ThumbsDown, Check } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { CountdownTimer } from './CountdownTimer';

interface VotingPanelProps {
  proposal: Proposal;
}

export function VotingPanel({ proposal }: VotingPanelProps) {
  const { addVote, hasVoted, currentMember, getStageEndTime } = useProposals();
  const stageEndTime = getStageEndTime(proposal.id);
  const userHasVoted = hasVoted(proposal.id);
  const userVote = proposal.votes.find((v) => v.memberId === currentMember.id);

  const supportVotes = proposal.votes.filter((v) => v.support).length;
  const opposeVotes = proposal.votes.filter((v) => !v.support).length;
  const totalVotes = proposal.votes.length;
  const supportPercentage = totalVotes > 0 ? (supportVotes / totalVotes) * 100 : 0;

  const handleVote = (support: boolean) => {
    addVote(proposal.id, support);
  };

  if (proposal.status !== 'voting') {
    return (
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-base">Voting Results</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-success font-medium">Support: {supportVotes}</span>
              <span className="text-destructive font-medium">Oppose: {opposeVotes}</span>
            </div>
            <Progress value={supportPercentage} className="h-2" />
          </div>
          <p className="text-sm text-muted-foreground">
            Total votes: {totalVotes}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-soft border-warning/30">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="text-base flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-warning animate-pulse" />
            Vote on this proposal
          </CardTitle>
          <CountdownTimer endTime={stageEndTime} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-success font-medium">Support: {supportVotes}</span>
            <span className="text-destructive font-medium">Oppose: {opposeVotes}</span>
          </div>
          <Progress value={supportPercentage} className="h-2" />
        </div>

        {userHasVoted ? (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-accent text-accent-foreground">
            <Check className="w-4 h-4" />
            <span className="text-sm font-medium">
              You voted {userVote?.support ? 'in support' : 'in opposition'}
            </span>
          </div>
        ) : (
          <div className="flex gap-2">
            <Button
              onClick={() => handleVote(true)}
              className="flex-1 bg-success hover:bg-success/90 text-success-foreground"
            >
              <ThumbsUp className="w-4 h-4 mr-2" />
              Support
            </Button>
            <Button
              onClick={() => handleVote(false)}
              variant="destructive"
              className="flex-1"
            >
              <ThumbsDown className="w-4 h-4 mr-2" />
              Oppose
            </Button>
          </div>
        )}

        <p className="text-xs text-muted-foreground text-center">
          {totalVotes} vote{totalVotes !== 1 ? 's' : ''} cast
        </p>
      </CardContent>
    </Card>
  );
}
