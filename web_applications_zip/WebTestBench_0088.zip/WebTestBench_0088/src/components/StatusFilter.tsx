import { ProposalStatus } from '@/types/proposal';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface StatusFilterProps {
  selectedStatus: ProposalStatus | 'all';
  onStatusChange: (status: ProposalStatus | 'all') => void;
}

const filters: { value: ProposalStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'draft', label: 'Draft' },
  { value: 'discussion', label: 'Discussion' },
  { value: 'voting', label: 'Voting' },
  { value: 'approved', label: 'Approved' },
  { value: 'rejected', label: 'Rejected' },
];

export function StatusFilter({ selectedStatus, onStatusChange }: StatusFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {filters.map((filter) => (
        <Button
          key={filter.value}
          variant="outline"
          size="sm"
          onClick={() => onStatusChange(filter.value)}
          className={cn(
            'transition-colors',
            selectedStatus === filter.value &&
              'bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground border-primary'
          )}
        >
          {filter.label}
        </Button>
      ))}
    </div>
  );
}
