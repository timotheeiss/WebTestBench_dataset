import { ProposalStatus } from '@/types/proposal';
import { cn } from '@/lib/utils';
import { FileText, MessageCircle, Vote, CheckCircle, XCircle } from 'lucide-react';
import { CountdownTimer } from './CountdownTimer';

interface StatusTimelineProps {
  currentStatus: ProposalStatus;
  stageEndTime?: number | null;
}

const stages = [
  { status: 'draft', label: 'Draft', icon: FileText },
  { status: 'discussion', label: 'Discussion', icon: MessageCircle },
  { status: 'voting', label: 'Voting', icon: Vote },
] as const;

export function StatusTimeline({ currentStatus, stageEndTime }: StatusTimelineProps) {
  const getStageState = (stageStatus: string) => {
    const statusOrder = ['draft', 'discussion', 'voting'];
    const currentIndex = statusOrder.indexOf(currentStatus);
    const stageIndex = statusOrder.indexOf(stageStatus);

    if (currentStatus === 'approved' || currentStatus === 'rejected') {
      return 'completed';
    }
    if (stageIndex < currentIndex) return 'completed';
    if (stageIndex === currentIndex) return 'current';
    return 'upcoming';
  };

  const getFinalState = () => {
    if (currentStatus === 'approved') return 'approved';
    if (currentStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const isTimedStage = currentStatus === 'discussion' || currentStatus === 'voting';

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {stages.map((stage, index) => {
          const state = getStageState(stage.status);
          const Icon = stage.icon;

          return (
            <div key={stage.status} className="flex items-center">
              <div
                className={cn(
                  'flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-colors',
                  state === 'completed' && 'bg-primary/10 text-primary',
                  state === 'current' && 'bg-primary text-primary-foreground',
                  state === 'upcoming' && 'bg-muted text-muted-foreground'
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                {stage.label}
              </div>
              {index < stages.length - 1 && (
                <div
                  className={cn(
                    'w-6 h-0.5 mx-1',
                    state === 'completed' ? 'bg-primary' : 'bg-border'
                  )}
                />
              )}
            </div>
          );
        })}

        <div className="w-6 h-0.5 mx-1 bg-border" />

        <div
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium',
            getFinalState() === 'approved' && 'bg-success/10 text-success',
            getFinalState() === 'rejected' && 'bg-destructive/10 text-destructive',
            getFinalState() === 'pending' && 'bg-muted text-muted-foreground'
          )}
        >
          {getFinalState() === 'approved' && (
            <>
              <CheckCircle className="w-3.5 h-3.5" />
              Approved
            </>
          )}
          {getFinalState() === 'rejected' && (
            <>
              <XCircle className="w-3.5 h-3.5" />
              Rejected
            </>
          )}
          {getFinalState() === 'pending' && (
            <>
              <CheckCircle className="w-3.5 h-3.5" />
              Final
            </>
          )}
        </div>
      </div>

      {isTimedStage && stageEndTime && (
        <CountdownTimer 
          endTime={stageEndTime} 
          label={currentStatus === 'discussion' ? 'Discussion ends in' : 'Voting ends in'} 
        />
      )}
    </div>
  );
}
