import { ProposalStatus } from '@/types/proposal';
import { cn } from '@/lib/utils';
import { FileText, MessageCircle, Vote, CheckCircle, XCircle } from 'lucide-react';

interface StatusBadgeProps {
  status: ProposalStatus;
  className?: string;
}

const statusConfig: Record<
  ProposalStatus,
  { label: string; className: string; icon: React.ElementType }
> = {
  draft: {
    label: 'Draft',
    className: 'bg-muted text-muted-foreground',
    icon: FileText,
  },
  discussion: {
    label: 'Discussion',
    className: 'bg-info/10 text-info',
    icon: MessageCircle,
  },
  voting: {
    label: 'Voting',
    className: 'bg-warning/10 text-warning',
    icon: Vote,
  },
  approved: {
    label: 'Approved',
    className: 'bg-success/10 text-success',
    icon: CheckCircle,
  },
  rejected: {
    label: 'Rejected',
    className: 'bg-destructive/10 text-destructive',
    icon: XCircle,
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-colors',
        config.className,
        className
      )}
    >
      <Icon className="w-3 h-3" />
      {config.label}
    </span>
  );
}
