import { Proposal } from '@/types/proposal';
import { StatusBadge } from './StatusBadge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { MessageCircle, ThumbsUp, ThumbsDown, Calendar, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { CountdownTimer } from './CountdownTimer';
import { useProposals } from '@/context/ProposalContext';

interface ProposalCardProps {
  proposal: Proposal;
}

export function ProposalCard({ proposal }: ProposalCardProps) {
  const { getStageEndTime } = useProposals();
  const stageEndTime = getStageEndTime(proposal.id);
  const supportVotes = proposal.votes.filter((v) => v.support).length;
  const opposeVotes = proposal.votes.filter((v) => !v.support).length;

  return (
    <Link to={`/proposal/${proposal.id}`}>
      <Card className="shadow-soft hover:shadow-elevated transition-all duration-200 cursor-pointer border-transparent hover:border-primary/20 animate-fade-in">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1 flex-1 min-w-0">
              <h3 className="font-semibold text-lg leading-tight text-foreground line-clamp-2">
                {proposal.title}
              </h3>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  {proposal.authorName}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {formatDistanceToNow(new Date(proposal.createdAt), { addSuffix: true })}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {stageEndTime && <CountdownTimer endTime={stageEndTime} />}
              <StatusBadge status={proposal.status} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-sm line-clamp-2 mb-4">
            {proposal.description.slice(0, 150)}...
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <MessageCircle className="w-4 h-4" />
              {proposal.comments.length}
            </span>
            {proposal.votes.length > 0 && (
              <>
                <span className="flex items-center gap-1.5 text-success">
                  <ThumbsUp className="w-4 h-4" />
                  {supportVotes}
                </span>
                <span className="flex items-center gap-1.5 text-destructive">
                  <ThumbsDown className="w-4 h-4" />
                  {opposeVotes}
                </span>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
