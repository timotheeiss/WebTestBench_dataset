import { useCountdown } from '@/hooks/useCountdown';
import { Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CountdownTimerProps {
  endTime: number | null;
  label?: string;
  className?: string;
}

export function CountdownTimer({ endTime, label, className }: CountdownTimerProps) {
  const { formattedTime, isExpired, timeRemaining } = useCountdown(endTime);

  if (endTime === null || isExpired) {
    return null;
  }

  // Show warning color when less than 1 minute remaining
  const isUrgent = timeRemaining < 60000;

  return (
    <div
      className={cn(
        'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
        isUrgent
          ? 'bg-destructive/10 text-destructive animate-pulse'
          : 'bg-warning/10 text-warning',
        className
      )}
    >
      <Clock className="w-3.5 h-3.5" />
      {label && <span>{label}:</span>}
      <span className="font-mono">{formattedTime}</span>
    </div>
  );
}
