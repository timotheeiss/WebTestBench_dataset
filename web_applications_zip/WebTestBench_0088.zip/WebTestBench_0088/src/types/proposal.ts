export type ProposalStatus = 'draft' | 'discussion' | 'voting' | 'approved' | 'rejected';

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

export interface Vote {
  memberId: string;
  memberName: string;
  support: boolean;
  createdAt: string;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  authorId: string;
  authorName: string;
  status: ProposalStatus;
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
  votes: Vote[];
  // Timestamps for timed stages (ISO strings)
  discussionStartedAt?: string;
  votingStartedAt?: string;
}

// Stage duration in milliseconds (5 minutes)
export const STAGE_DURATION_MS = 5 * 60 * 1000;

export interface Member {
  id: string;
  name: string;
  avatar?: string;
}
