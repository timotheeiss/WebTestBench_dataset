import { useState, useEffect } from 'react';

interface CountdownResult {
  timeRemaining: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  formattedTime: string;
}

export function useCountdown(targetTime: number | null): CountdownResult {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (targetTime === null) return;
    
    const interval = setInterval(() => {
      setNow(Date.now());
    }, 1000);

    return () => clearInterval(interval);
  }, [targetTime]);

  if (targetTime === null) {
    return {
      timeRemaining: 0,
      minutes: 0,
      seconds: 0,
      isExpired: true,
      formattedTime: '0:00',
    };
  }

  const timeRemaining = Math.max(0, targetTime - now);
  const isExpired = timeRemaining <= 0;
  const totalSeconds = Math.floor(timeRemaining / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const formattedTime = `${minutes}:${seconds.toString().padStart(2, '0')}`;

  return {
    timeRemaining,
    minutes,
    seconds,
    isExpired,
    formattedTime,
  };
}

export function getStageEndTime(startTime: string | undefined, durationMs: number): number | null {
  if (!startTime) return null;
  return new Date(startTime).getTime() + durationMs;
}
