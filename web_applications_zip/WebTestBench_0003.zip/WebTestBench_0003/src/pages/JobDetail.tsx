import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, DollarSign, Clock, Building2, Briefcase } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { ApplicationForm } from '@/components/jobs/ApplicationForm';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useJobs } from '@/context/JobContext';
import { formatSalary, formatDate, getEmploymentTypeLabel } from '@/lib/formatters';

const JobDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getJobById } = useJobs();
  const job = getJobById(id || '');

  if (!job) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-16 text-center">
          <Briefcase className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h1 className="text-2xl font-bold mb-2">Job not found</h1>
          <p className="text-muted-foreground mb-6">This job listing may have been removed or doesn't exist.</p>
          <Link to="/">
            <Button variant="accent">Browse all jobs</Button>
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to all jobs
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Job Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <Badge variant="accent">{job.industry}</Badge>
                  <Badge variant="secondary">{getEmploymentTypeLabel(job.employmentType)}</Badge>
                </div>

                <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                  {job.title}
                </h1>

                <div className="flex items-center gap-2 text-lg text-muted-foreground mb-4">
                  <Building2 className="h-5 w-5" />
                  <span className="font-medium">{job.company}</span>
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    <span>{job.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <DollarSign className="h-4 w-4" />
                    <span>{formatSalary(job.salaryMin, job.salaryMax, job.employmentType)}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" />
                    <span>Posted {formatDate(job.postedAt)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold mb-4">Job Description</h2>
                <div className="prose prose-sm max-w-none text-muted-foreground">
                  {job.description.split('\n').map((paragraph, index) => {
                    if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                      return (
                        <h3 key={index} className="font-semibold text-foreground mt-4 mb-2">
                          {paragraph.replace(/\*\*/g, '')}
                        </h3>
                      );
                    }
                    if (paragraph.startsWith('- ')) {
                      return (
                        <li key={index} className="ml-4">
                          {paragraph.replace('- ', '')}
                        </li>
                      );
                    }
                    return paragraph ? <p key={index}>{paragraph}</p> : null;
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold mb-4">Required Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill) => (
                    <Badge key={skill} variant="skill" className="px-3 py-1.5">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Application Form */}
          <div className="lg:col-span-1">
            <ApplicationForm jobId={job.id} jobTitle={job.title} company={job.company} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default JobDetail;
