import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { industries, locations, employmentTypes } from '@/data/initialData';
import { FilterState } from '@/types';

interface JobFiltersProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
}

export function JobFilters({ filters, onFilterChange }: JobFiltersProps) {
  const hasActiveFilters =
    filters.industry || filters.location || filters.employmentType || filters.search;

  const clearFilters = () => {
    onFilterChange({
      industry: '',
      location: '',
      employmentType: '',
      search: '',
    });
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search jobs, companies, or skills..."
          value={filters.search}
          onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
          className="pl-10 h-11"
        />
      </div>

      <div className="flex flex-wrap gap-3">
        <Select
          value={filters.industry}
          onValueChange={(value) => onFilterChange({ ...filters, industry: value })}
        >
          <SelectTrigger className="w-[160px] bg-card">
            <SelectValue placeholder="Industry" />
          </SelectTrigger>
          <SelectContent className="bg-card">
            <SelectItem value="all">All Industries</SelectItem>
            {industries.map((industry) => (
              <SelectItem key={industry} value={industry}>
                {industry}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.location}
          onValueChange={(value) => onFilterChange({ ...filters, location: value })}
        >
          <SelectTrigger className="w-[180px] bg-card">
            <SelectValue placeholder="Location" />
          </SelectTrigger>
          <SelectContent className="bg-card">
            <SelectItem value="all">All Locations</SelectItem>
            {locations.map((location) => (
              <SelectItem key={location} value={location}>
                {location}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.employmentType}
          onValueChange={(value) => onFilterChange({ ...filters, employmentType: value })}
        >
          <SelectTrigger className="w-[160px] bg-card">
            <SelectValue placeholder="Job Type" />
          </SelectTrigger>
          <SelectContent className="bg-card">
            <SelectItem value="all">All Types</SelectItem>
            {employmentTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-1.5">
            <X className="h-4 w-4" />
            Clear filters
          </Button>
        )}
      </div>
    </div>
  );
}
