export type DeviceType = 'light' | 'thermostat' | 'lock' | 'camera' | 'speaker' | 'sensor';
export type DeviceStatus = 'online' | 'offline' | 'idle';
export type RoomType = 'living-room' | 'bedroom' | 'kitchen' | 'bathroom' | 'office' | 'garage';

export interface Device {
  id: string;
  name: string;
  type: DeviceType;
  room: RoomType;
  status: DeviceStatus;
  isOn: boolean;
  settings: {
    brightness?: number;
    temperature?: number;
    targetTemp?: number;
    locked?: boolean;
    volume?: number;
    motion?: boolean;
  };
  lastUsed: Date;
  icon: string;
}

export interface Room {
  id: RoomType;
  name: string;
  icon: string;
  deviceCount: number;
}

export interface Schedule {
  id: string;
  deviceId: string;
  deviceName: string;
  action: string;
  time: string;
  days: string[];
  isActive: boolean;
}

export interface Activity {
  id: string;
  deviceId: string;
  deviceName: string;
  action: string;
  timestamp: Date;
  type: 'info' | 'warning' | 'success';
}

export const rooms: Room[] = [
  { id: 'living-room', name: 'Living Room', icon: 'Sofa', deviceCount: 5 },
  { id: 'bedroom', name: 'Bedroom', icon: 'Bed', deviceCount: 4 },
  { id: 'kitchen', name: 'Kitchen', icon: 'ChefHat', deviceCount: 3 },
  { id: 'bathroom', name: 'Bathroom', icon: 'Bath', deviceCount: 2 },
  { id: 'office', name: 'Office', icon: 'Monitor', deviceCount: 4 },
  { id: 'garage', name: 'Garage', icon: 'Car', deviceCount: 2 },
];

export const devices: Device[] = [
  // Living Room
  {
    id: '1',
    name: 'Main Ceiling Light',
    type: 'light',
    room: 'living-room',
    status: 'online',
    isOn: true,
    settings: { brightness: 75 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 5),
    icon: 'Lightbulb',
  },
  {
    id: '2',
    name: 'Floor Lamp',
    type: 'light',
    room: 'living-room',
    status: 'online',
    isOn: false,
    settings: { brightness: 50 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 2),
    icon: 'Lamp',
  },
  {
    id: '3',
    name: 'Smart Thermostat',
    type: 'thermostat',
    room: 'living-room',
    status: 'online',
    isOn: true,
    settings: { temperature: 72, targetTemp: 70 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 30),
    icon: 'Thermometer',
  },
  {
    id: '4',
    name: 'Living Room Speaker',
    type: 'speaker',
    room: 'living-room',
    status: 'idle',
    isOn: false,
    settings: { volume: 40 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 4),
    icon: 'Speaker',
  },
  {
    id: '5',
    name: 'Motion Sensor',
    type: 'sensor',
    room: 'living-room',
    status: 'online',
    isOn: true,
    settings: { motion: false },
    lastUsed: new Date(Date.now() - 1000 * 60 * 15),
    icon: 'Eye',
  },
  // Bedroom
  {
    id: '6',
    name: 'Bedroom Light',
    type: 'light',
    room: 'bedroom',
    status: 'online',
    isOn: false,
    settings: { brightness: 30 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 8),
    icon: 'Lightbulb',
  },
  {
    id: '7',
    name: 'Bedside Lamp',
    type: 'light',
    room: 'bedroom',
    status: 'online',
    isOn: false,
    settings: { brightness: 20 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 8),
    icon: 'Lamp',
  },
  {
    id: '8',
    name: 'Bedroom Thermostat',
    type: 'thermostat',
    room: 'bedroom',
    status: 'online',
    isOn: true,
    settings: { temperature: 68, targetTemp: 65 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 45),
    icon: 'Thermometer',
  },
  {
    id: '9',
    name: 'Bedroom Speaker',
    type: 'speaker',
    room: 'bedroom',
    status: 'offline',
    isOn: false,
    settings: { volume: 25 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 24),
    icon: 'Speaker',
  },
  // Kitchen
  {
    id: '10',
    name: 'Kitchen Light',
    type: 'light',
    room: 'kitchen',
    status: 'online',
    isOn: true,
    settings: { brightness: 100 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 10),
    icon: 'Lightbulb',
  },
  {
    id: '11',
    name: 'Under Cabinet Lights',
    type: 'light',
    room: 'kitchen',
    status: 'online',
    isOn: true,
    settings: { brightness: 60 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 10),
    icon: 'Lightbulb',
  },
  {
    id: '12',
    name: 'Kitchen Camera',
    type: 'camera',
    room: 'kitchen',
    status: 'online',
    isOn: true,
    settings: {},
    lastUsed: new Date(Date.now() - 1000 * 60 * 1),
    icon: 'Camera',
  },
  // Bathroom
  {
    id: '13',
    name: 'Bathroom Light',
    type: 'light',
    room: 'bathroom',
    status: 'online',
    isOn: false,
    settings: { brightness: 80 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60),
    icon: 'Lightbulb',
  },
  {
    id: '14',
    name: 'Exhaust Fan',
    type: 'sensor',
    room: 'bathroom',
    status: 'idle',
    isOn: false,
    settings: {},
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 3),
    icon: 'Fan',
  },
  // Office
  {
    id: '15',
    name: 'Desk Lamp',
    type: 'light',
    room: 'office',
    status: 'online',
    isOn: true,
    settings: { brightness: 85 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 2),
    icon: 'Lamp',
  },
  {
    id: '16',
    name: 'Office Thermostat',
    type: 'thermostat',
    room: 'office',
    status: 'online',
    isOn: true,
    settings: { temperature: 71, targetTemp: 72 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 20),
    icon: 'Thermometer',
  },
  {
    id: '17',
    name: 'Smart Lock',
    type: 'lock',
    room: 'office',
    status: 'online',
    isOn: true,
    settings: { locked: true },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 5),
    icon: 'Lock',
  },
  {
    id: '18',
    name: 'Office Camera',
    type: 'camera',
    room: 'office',
    status: 'online',
    isOn: true,
    settings: {},
    lastUsed: new Date(Date.now() - 1000 * 60 * 1),
    icon: 'Camera',
  },
  // Garage
  {
    id: '19',
    name: 'Garage Light',
    type: 'light',
    room: 'garage',
    status: 'offline',
    isOn: false,
    settings: { brightness: 100 },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 48),
    icon: 'Lightbulb',
  },
  {
    id: '20',
    name: 'Garage Door Lock',
    type: 'lock',
    room: 'garage',
    status: 'online',
    isOn: true,
    settings: { locked: true },
    lastUsed: new Date(Date.now() - 1000 * 60 * 60 * 6),
    icon: 'Lock',
  },
];

export const schedules: Schedule[] = [
  {
    id: '1',
    deviceId: '1',
    deviceName: 'Main Ceiling Light',
    action: 'Turn off',
    time: '23:00',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    isActive: true,
  },
  {
    id: '2',
    deviceId: '3',
    deviceName: 'Smart Thermostat',
    action: 'Set to 68°F',
    time: '22:00',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    isActive: true,
  },
  {
    id: '3',
    deviceId: '6',
    deviceName: 'Bedroom Light',
    action: 'Turn on at 20%',
    time: '06:30',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    isActive: true,
  },
  {
    id: '4',
    deviceId: '15',
    deviceName: 'Desk Lamp',
    action: 'Turn on',
    time: '08:00',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    isActive: false,
  },
  {
    id: '5',
    deviceId: '10',
    deviceName: 'Kitchen Light',
    action: 'Turn off',
    time: '00:00',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    isActive: true,
  },
];

export const activities: Activity[] = [
  {
    id: '1',
    deviceId: '1',
    deviceName: 'Main Ceiling Light',
    action: 'Turned on',
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
    type: 'success',
  },
  {
    id: '2',
    deviceId: '3',
    deviceName: 'Smart Thermostat',
    action: 'Temperature adjusted to 70°F',
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
    type: 'info',
  },
  {
    id: '3',
    deviceId: '17',
    deviceName: 'Smart Lock',
    action: 'Locked remotely',
    timestamp: new Date(Date.now() - 1000 * 60 * 60),
    type: 'success',
  },
  {
    id: '4',
    deviceId: '9',
    deviceName: 'Bedroom Speaker',
    action: 'Went offline',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
    type: 'warning',
  },
  {
    id: '5',
    deviceId: '12',
    deviceName: 'Kitchen Camera',
    action: 'Motion detected',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
    type: 'info',
  },
  {
    id: '6',
    deviceId: '19',
    deviceName: 'Garage Light',
    action: 'Connection lost',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    type: 'warning',
  },
];

export const deviceTypeLabels: Record<DeviceType, string> = {
  light: 'Lights',
  thermostat: 'Thermostats',
  lock: 'Locks',
  camera: 'Cameras',
  speaker: 'Speakers',
  sensor: 'Sensors',
};

export const roomLabels: Record<RoomType, string> = {
  'living-room': 'Living Room',
  'bedroom': 'Bedroom',
  'kitchen': 'Kitchen',
  'bathroom': 'Bathroom',
  'office': 'Office',
  'garage': 'Garage',
};
