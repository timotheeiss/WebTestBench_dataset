import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { RoomCard } from '@/components/dashboard/RoomCard';
import { DeviceCard } from '@/components/devices/DeviceCard';
import { FilterBar } from '@/components/ui/FilterBar';
import { rooms, devices, roomLabels, RoomType } from '@/data/devices';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

const roomOptions = [
  { value: 'all', label: 'All Rooms' },
  ...rooms.map((room) => ({ value: room.id, label: room.name })),
];

const Rooms = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedRoom = searchParams.get('room') || 'all';

  const setSelectedRoom = (room: string) => {
    if (room === 'all') {
      setSearchParams({});
    } else {
      setSearchParams({ room });
    }
  };

  const roomDevices = useMemo(() => {
    if (selectedRoom === 'all') return [];
    return devices.filter((device) => device.room === selectedRoom);
  }, [selectedRoom]);

  const currentRoom = rooms.find((r) => r.id === selectedRoom);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          {selectedRoom !== 'all' && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedRoom('all')}
              className="shrink-0"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {selectedRoom === 'all' ? 'Rooms' : currentRoom?.name}
            </h1>
            <p className="mt-1 text-muted-foreground">
              {selectedRoom === 'all'
                ? 'Browse your smart home by room.'
                : `${roomDevices.length} devices in this room`}
            </p>
          </div>
        </div>

        {/* Room Filter */}
        <FilterBar
          options={roomOptions}
          value={selectedRoom}
          onChange={setSelectedRoom}
        />

        {/* Content */}
        {selectedRoom === 'all' ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {rooms.map((room) => (
              <RoomCard key={room.id} room={room} />
            ))}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {roomDevices.map((device) => (
              <DeviceCard key={device.id} device={device} />
            ))}
          </div>
        )}

        {selectedRoom !== 'all' && roomDevices.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-lg font-medium text-muted-foreground">No devices in this room</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Rooms;
