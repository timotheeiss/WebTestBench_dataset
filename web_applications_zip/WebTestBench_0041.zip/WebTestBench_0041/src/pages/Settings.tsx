import { Layout } from '@/components/layout/Layout';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  Bell, 
  Wifi, 
  Shield, 
  Moon,
  Smartphone,
  Globe
} from 'lucide-react';

const settingsGroups = [
  {
    title: 'Notifications',
    icon: Bell,
    settings: [
      { id: 'push', label: 'Push Notifications', description: 'Receive alerts on your devices', default: true },
      { id: 'email', label: 'Email Notifications', description: 'Get daily digest via email', default: false },
      { id: 'offline', label: 'Offline Alerts', description: 'Alert when devices go offline', default: true },
    ],
  },
  {
    title: 'Network',
    icon: Wifi,
    settings: [
      { id: 'auto-discover', label: 'Auto Discovery', description: 'Automatically find new devices', default: true },
      { id: 'remote', label: 'Remote Access', description: 'Control devices outside home', default: true },
    ],
  },
  {
    title: 'Security',
    icon: Shield,
    settings: [
      { id: '2fa', label: 'Two-Factor Authentication', description: 'Add extra security layer', default: false },
      { id: 'auto-lock', label: 'Auto Lock', description: 'Lock all doors at night', default: true },
    ],
  },
  {
    title: 'Preferences',
    icon: Globe,
    settings: [
      { id: 'celsius', label: 'Use Celsius', description: 'Display temperature in Celsius', default: false },
      { id: '24h', label: '24-Hour Time', description: 'Use 24-hour time format', default: false },
    ],
  },
];

const Settings = () => {
  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="mt-1 text-muted-foreground">
            Manage your smart home preferences.
          </p>
        </div>

        {/* Settings Groups */}
        <div className="space-y-6">
          {settingsGroups.map((group) => (
            <div
              key={group.title}
              className="rounded-xl border border-border bg-card p-6 animate-fade-in"
            >
              <div className="mb-4 flex items-center gap-3">
                <div className="rounded-lg bg-primary/10 p-2">
                  <group.icon className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-lg font-semibold text-foreground">{group.title}</h2>
              </div>
              <div className="space-y-4">
                {group.settings.map((setting) => (
                  <div
                    key={setting.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-4"
                  >
                    <div>
                      <Label htmlFor={setting.id} className="text-sm font-medium text-foreground">
                        {setting.label}
                      </Label>
                      <p className="text-xs text-muted-foreground">{setting.description}</p>
                    </div>
                    <Switch id={setting.id} defaultChecked={setting.default} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
