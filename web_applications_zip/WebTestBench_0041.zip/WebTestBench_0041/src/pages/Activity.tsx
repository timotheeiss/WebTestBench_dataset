import { Layout } from '@/components/layout/Layout';
import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import { activities } from '@/data/devices';
import { Activity as ActivityIcon } from 'lucide-react';

const Activity = () => {
  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Activity Log</h1>
          <p className="mt-1 text-muted-foreground">
            Track all recent activity across your smart home devices.
          </p>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-2 rounded-lg border border-border bg-card p-4">
          <ActivityIcon className="h-5 w-5 text-primary" />
          <span className="text-sm text-muted-foreground">
            Showing <span className="font-medium text-foreground">{activities.length}</span> recent activities
          </span>
        </div>

        {/* Activity Feed */}
        <ActivityFeed activities={activities} />
      </div>
    </Layout>
  );
};

export default Activity;
