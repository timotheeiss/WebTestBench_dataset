import { Layout } from '@/components/layout/Layout';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { DeviceCard } from '@/components/devices/DeviceCard';
import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import { RoomCard } from '@/components/dashboard/RoomCard';
import { devices, rooms, activities } from '@/data/devices';
import { 
  Lightbulb, 
  Wifi, 
  WifiOff, 
  Clock,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  const onlineDevices = devices.filter(d => d.status === 'online').length;
  const offlineDevices = devices.filter(d => d.status === 'offline').length;
  const activeDevices = devices.filter(d => d.isOn && d.status === 'online').length;
  const recentDevices = [...devices]
    .sort((a, b) => b.lastUsed.getTime() - a.lastUsed.getTime())
    .slice(0, 4);

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="mt-1 text-muted-foreground">
            Welcome back! Here's what's happening with your smart home.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Devices"
            value={devices.length}
            subtitle="Across all rooms"
            icon={Lightbulb}
            variant="primary"
          />
          <StatsCard
            title="Online"
            value={onlineDevices}
            subtitle={`${Math.round((onlineDevices / devices.length) * 100)}% connected`}
            icon={Wifi}
            variant="success"
          />
          <StatsCard
            title="Offline"
            value={offlineDevices}
            subtitle="Need attention"
            icon={WifiOff}
            variant={offlineDevices > 0 ? 'destructive' : 'default'}
          />
          <StatsCard
            title="Active Now"
            value={activeDevices}
            subtitle="Currently in use"
            icon={Clock}
            variant="default"
          />
        </div>

        {/* Rooms Section */}
        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold text-foreground">Rooms</h2>
            <Link
              to="/rooms"
              className="flex items-center gap-1 text-sm text-primary hover:underline"
            >
              View all
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {rooms.slice(0, 6).map((room) => (
              <RoomCard key={room.id} room={room} />
            ))}
          </div>
        </div>

        {/* Recent Devices & Activity */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Recent Devices */}
          <div>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Recently Used</h2>
              <Link
                to="/devices"
                className="flex items-center gap-1 text-sm text-primary hover:underline"
              >
                View all
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {recentDevices.map((device) => (
                <DeviceCard key={device.id} device={device} />
              ))}
            </div>
          </div>

          {/* Activity Feed */}
          <div>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Recent Activity</h2>
              <Link
                to="/activity"
                className="flex items-center gap-1 text-sm text-primary hover:underline"
              >
                View all
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <ActivityFeed activities={activities} limit={5} />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Index;
