import { useState, useMemo } from 'react';
import { Layout } from '@/components/layout/Layout';
import { DeviceCard } from '@/components/devices/DeviceCard';
import { FilterBar } from '@/components/ui/FilterBar';
import { devices, deviceTypeLabels, roomLabels, DeviceType, DeviceStatus, RoomType } from '@/data/devices';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const statusOptions = [
  { value: 'all', label: 'All Status' },
  { value: 'online', label: 'Online' },
  { value: 'offline', label: 'Offline' },
  { value: 'idle', label: 'Idle' },
];

const typeOptions = [
  { value: 'all', label: 'All Types' },
  ...Object.entries(deviceTypeLabels).map(([value, label]) => ({ value, label })),
];

const roomOptions = [
  { value: 'all', label: 'All Rooms' },
  ...Object.entries(roomLabels).map(([value, label]) => ({ value, label })),
];

const Devices = () => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [roomFilter, setRoomFilter] = useState('all');

  const filteredDevices = useMemo(() => {
    return devices.filter((device) => {
      const matchesSearch = device.name.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || device.status === statusFilter;
      const matchesType = typeFilter === 'all' || device.type === typeFilter;
      const matchesRoom = roomFilter === 'all' || device.room === roomFilter;
      return matchesSearch && matchesStatus && matchesType && matchesRoom;
    });
  }, [search, statusFilter, typeFilter, roomFilter]);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Devices</h1>
          <p className="mt-1 text-muted-foreground">
            Manage and control all your smart home devices.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-4">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search devices..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-6">
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Status</label>
              <FilterBar
                options={statusOptions}
                value={statusFilter}
                onChange={setStatusFilter}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Type</label>
              <FilterBar
                options={typeOptions}
                value={typeFilter}
                onChange={setTypeFilter}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Room</label>
              <FilterBar
                options={roomOptions}
                value={roomFilter}
                onChange={setRoomFilter}
              />
            </div>
          </div>
        </div>

        {/* Results count */}
        <p className="text-sm text-muted-foreground">
          Showing {filteredDevices.length} of {devices.length} devices
        </p>

        {/* Devices Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredDevices.map((device) => (
            <DeviceCard key={device.id} device={device} />
          ))}
        </div>

        {filteredDevices.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-lg font-medium text-muted-foreground">No devices found</p>
            <p className="text-sm text-muted-foreground">Try adjusting your filters</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Devices;
