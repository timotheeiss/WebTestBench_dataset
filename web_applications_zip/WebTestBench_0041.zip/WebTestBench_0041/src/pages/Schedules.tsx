import { useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { ScheduleCard } from '@/components/schedules/ScheduleCard';
import { schedules as initialSchedules, devices } from '@/data/devices';
import { Button } from '@/components/ui/button';
import { Plus, Clock } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const Schedules = () => {
  const [schedules, setSchedules] = useState(initialSchedules);
  const [isOpen, setIsOpen] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    deviceId: '',
    action: '',
    time: '',
    days: [] as string[],
  });

  const handleToggle = (id: string, isActive: boolean) => {
    setSchedules((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isActive } : s))
    );
  };

  const handleDayToggle = (day: string) => {
    setNewSchedule((prev) => ({
      ...prev,
      days: prev.days.includes(day)
        ? prev.days.filter((d) => d !== day)
        : [...prev.days, day],
    }));
  };

  const handleCreateSchedule = () => {
    if (!newSchedule.deviceId || !newSchedule.action || !newSchedule.time || newSchedule.days.length === 0) {
      return;
    }

    const device = devices.find((d) => d.id === newSchedule.deviceId);
    if (!device) return;

    const schedule = {
      id: String(Date.now()),
      deviceId: newSchedule.deviceId,
      deviceName: device.name,
      action: newSchedule.action,
      time: newSchedule.time,
      days: newSchedule.days,
      isActive: true,
    };

    setSchedules((prev) => [schedule, ...prev]);
    setNewSchedule({ deviceId: '', action: '', time: '', days: [] });
    setIsOpen(false);
  };

  const activeSchedules = schedules.filter((s) => s.isActive);
  const inactiveSchedules = schedules.filter((s) => !s.isActive);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Schedules</h1>
            <p className="mt-1 text-muted-foreground">
              Automate your devices with schedules.
            </p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Schedule
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>Create New Schedule</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Device</Label>
                  <Select
                    value={newSchedule.deviceId}
                    onValueChange={(value) =>
                      setNewSchedule((prev) => ({ ...prev, deviceId: value }))
                    }
                  >
                    <SelectTrigger className="bg-secondary">
                      <SelectValue placeholder="Select a device" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {devices.map((device) => (
                        <SelectItem key={device.id} value={device.id}>
                          {device.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Action</Label>
                  <Input
                    placeholder="e.g., Turn on, Set to 70°F"
                    value={newSchedule.action}
                    onChange={(e) =>
                      setNewSchedule((prev) => ({ ...prev, action: e.target.value }))
                    }
                    className="bg-secondary"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Time</Label>
                  <Input
                    type="time"
                    value={newSchedule.time}
                    onChange={(e) =>
                      setNewSchedule((prev) => ({ ...prev, time: e.target.value }))
                    }
                    className="bg-secondary"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Days</Label>
                  <div className="flex flex-wrap gap-2">
                    {daysOfWeek.map((day) => (
                      <label
                        key={day}
                        className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-secondary px-3 py-2 text-sm transition-colors hover:bg-muted"
                      >
                        <Checkbox
                          checked={newSchedule.days.includes(day)}
                          onCheckedChange={() => handleDayToggle(day)}
                        />
                        {day}
                      </label>
                    ))}
                  </div>
                </div>

                <Button onClick={handleCreateSchedule} className="w-full">
                  Create Schedule
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Active Schedules */}
        <div>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-foreground">
            <Clock className="h-5 w-5 text-primary" />
            Active Schedules ({activeSchedules.length})
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {activeSchedules.map((schedule) => (
              <ScheduleCard
                key={schedule.id}
                schedule={schedule}
                onToggle={handleToggle}
              />
            ))}
          </div>
          {activeSchedules.length === 0 && (
            <p className="py-8 text-center text-muted-foreground">
              No active schedules. Create one to get started!
            </p>
          )}
        </div>

        {/* Inactive Schedules */}
        {inactiveSchedules.length > 0 && (
          <div>
            <h2 className="mb-4 text-lg font-semibold text-muted-foreground">
              Inactive Schedules ({inactiveSchedules.length})
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {inactiveSchedules.map((schedule) => (
                <ScheduleCard
                  key={schedule.id}
                  schedule={schedule}
                  onToggle={handleToggle}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Schedules;
