import { Activity } from '@/data/devices';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { Info, AlertTriangle, CheckCircle } from 'lucide-react';

interface ActivityFeedProps {
  activities: Activity[];
  limit?: number;
}

const typeIcons = {
  info: Info,
  warning: AlertTriangle,
  success: CheckCircle,
};

const typeStyles = {
  info: 'bg-primary/10 text-primary',
  warning: 'bg-warning/10 text-warning',
  success: 'bg-success/10 text-success',
};

export function ActivityFeed({ activities, limit }: ActivityFeedProps) {
  const displayedActivities = limit ? activities.slice(0, limit) : activities;

  return (
    <div className="space-y-3">
      {displayedActivities.map((activity, index) => {
        const Icon = typeIcons[activity.type];
        return (
          <div
            key={activity.id}
            className={cn(
              'flex items-start gap-3 rounded-lg border border-border bg-card/50 p-4 transition-all hover:bg-card',
              'animate-slide-in'
            )}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className={cn('rounded-lg p-2', typeStyles[activity.type])}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-foreground">{activity.deviceName}</p>
              <p className="text-sm text-muted-foreground">{activity.action}</p>
            </div>
            <p className="text-xs text-muted-foreground whitespace-nowrap">
              {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
            </p>
          </div>
        );
      })}
    </div>
  );
}
