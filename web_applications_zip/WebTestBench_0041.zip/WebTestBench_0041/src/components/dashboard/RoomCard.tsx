import { Room, devices as allDevices } from '@/data/devices';
import { cn } from '@/lib/utils';
import { 
  Sofa, 
  Bed, 
  ChefHat, 
  Bath, 
  Monitor, 
  Car,
  Lightbulb,
  Power
} from 'lucide-react';
import { Link } from 'react-router-dom';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Sofa,
  Bed,
  ChefHat,
  Bath,
  Monitor,
  Car,
};

interface RoomCardProps {
  room: Room;
}

export function RoomCard({ room }: RoomCardProps) {
  const Icon = iconMap[room.icon] || Sofa;
  const roomDevices = allDevices.filter(d => d.id && d.room === room.id);
  const activeDevices = roomDevices.filter(d => d.isOn && d.status === 'online').length;
  const onlineDevices = roomDevices.filter(d => d.status === 'online').length;

  return (
    <Link
      to={`/rooms?room=${room.id}`}
      className={cn(
        'group relative overflow-hidden rounded-xl border border-border bg-card p-5',
        'transition-all duration-300 hover:border-primary/30 hover:shadow-lg animate-fade-in',
        activeDevices > 0 && 'border-primary/20'
      )}
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />

      <div className="relative">
        <div className="flex items-start justify-between">
          <div className={cn(
            'rounded-xl p-3 transition-all duration-300',
            activeDevices > 0 ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
          )}>
            <Icon className="h-6 w-6" />
          </div>
          <div className="flex items-center gap-1.5">
            <Power className={cn(
              'h-3.5 w-3.5',
              activeDevices > 0 ? 'text-primary' : 'text-muted-foreground'
            )} />
            <span className={cn(
              'text-sm font-medium',
              activeDevices > 0 ? 'text-primary' : 'text-muted-foreground'
            )}>
              {activeDevices}/{roomDevices.length}
            </span>
          </div>
        </div>

        <div className="mt-4">
          <h3 className="text-lg font-semibold text-foreground">{room.name}</h3>
          <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Lightbulb className="h-3.5 w-3.5" />
              {roomDevices.length} devices
            </span>
            <span className={cn(
              'flex items-center gap-1.5',
              onlineDevices === roomDevices.length ? 'text-success' : 'text-warning'
            )}>
              {onlineDevices} online
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
