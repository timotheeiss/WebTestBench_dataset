import { useState } from 'react';
import { Schedule } from '@/data/devices';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { Clock, Calendar } from 'lucide-react';

interface ScheduleCardProps {
  schedule: Schedule;
  onToggle?: (id: string, isActive: boolean) => void;
}

export function ScheduleCard({ schedule, onToggle }: ScheduleCardProps) {
  const [isActive, setIsActive] = useState(schedule.isActive);

  const handleToggle = (checked: boolean) => {
    setIsActive(checked);
    onToggle?.(schedule.id, checked);
  };

  return (
    <div className={cn(
      'rounded-xl border bg-card p-5 transition-all duration-300 animate-fade-in',
      isActive ? 'border-primary/20' : 'border-border opacity-60'
    )}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">{schedule.deviceName}</h3>
          <p className="mt-1 text-sm text-primary">{schedule.action}</p>
        </div>
        <Switch checked={isActive} onCheckedChange={handleToggle} />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Clock className="h-4 w-4" />
          <span className="font-medium text-foreground">{schedule.time}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Calendar className="h-4 w-4" />
          <span>{schedule.days.join(', ')}</span>
        </div>
      </div>
    </div>
  );
}
