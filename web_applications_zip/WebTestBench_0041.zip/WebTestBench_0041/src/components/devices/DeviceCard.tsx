import { useState } from 'react';
import { Device } from '@/data/devices';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { 
  Lightbulb, 
  Thermometer, 
  Lock, 
  Unlock,
  Camera, 
  Speaker, 
  Eye,
  Lamp,
  Fan,
  Wifi,
  WifiOff
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Lightbulb,
  Thermometer,
  Lock,
  Camera,
  Speaker,
  Eye,
  Lamp,
  Fan,
};

interface DeviceCardProps {
  device: Device;
  onToggle?: (id: string, isOn: boolean) => void;
  onSettingChange?: (id: string, setting: string, value: number) => void;
}

export function DeviceCard({ device, onToggle, onSettingChange }: DeviceCardProps) {
  const [isOn, setIsOn] = useState(device.isOn);
  const [brightness, setBrightness] = useState(device.settings.brightness ?? 50);
  const [targetTemp, setTargetTemp] = useState(device.settings.targetTemp ?? 70);
  const [isLocked, setIsLocked] = useState(device.settings.locked ?? false);

  const Icon = iconMap[device.icon] || Lightbulb;

  const handleToggle = (checked: boolean) => {
    setIsOn(checked);
    onToggle?.(device.id, checked);
  };

  const handleBrightnessChange = (value: number[]) => {
    setBrightness(value[0]);
    onSettingChange?.(device.id, 'brightness', value[0]);
  };

  const handleTempChange = (value: number[]) => {
    setTargetTemp(value[0]);
    onSettingChange?.(device.id, 'targetTemp', value[0]);
  };

  const handleLockToggle = () => {
    setIsLocked(!isLocked);
    onSettingChange?.(device.id, 'locked', isLocked ? 0 : 1);
  };

  const statusColors = {
    online: 'bg-success text-success-foreground',
    offline: 'bg-destructive text-destructive-foreground',
    idle: 'bg-warning text-warning-foreground',
  };

  return (
    <div className={cn(
      'group relative overflow-hidden rounded-xl border bg-card p-5 transition-all duration-300',
      'hover:border-primary/30 hover:shadow-lg animate-fade-in',
      isOn && device.status === 'online' && 'border-primary/20 glow-primary'
    )}>
      {/* Status indicator */}
      <div className="absolute right-3 top-3 flex items-center gap-2">
        {device.status === 'online' ? (
          <Wifi className="h-3.5 w-3.5 text-success" />
        ) : device.status === 'offline' ? (
          <WifiOff className="h-3.5 w-3.5 text-destructive" />
        ) : (
          <Wifi className="h-3.5 w-3.5 text-warning" />
        )}
        <Badge variant="secondary" className={cn('text-[10px] px-2 py-0.5', statusColors[device.status])}>
          {device.status}
        </Badge>
      </div>

      {/* Device icon and name */}
      <div className="flex items-start gap-4">
        <div className={cn(
          'rounded-xl p-3 transition-all duration-300',
          isOn && device.status === 'online' 
            ? 'bg-primary/20 text-primary' 
            : 'bg-muted text-muted-foreground'
        )}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">{device.name}</h3>
          <p className="text-xs text-muted-foreground capitalize">
            {device.room.replace('-', ' ')}
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="mt-5 space-y-4">
        {/* Power toggle for most devices */}
        {device.type !== 'lock' && device.type !== 'camera' && device.type !== 'sensor' && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Power</span>
            <Switch 
              checked={isOn} 
              onCheckedChange={handleToggle}
              disabled={device.status === 'offline'}
            />
          </div>
        )}

        {/* Brightness slider for lights */}
        {device.type === 'light' && isOn && device.status === 'online' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Brightness</span>
              <span className="text-sm font-medium text-foreground">{brightness}%</span>
            </div>
            <Slider
              value={[brightness]}
              onValueChange={handleBrightnessChange}
              max={100}
              step={5}
              className="w-full"
            />
          </div>
        )}

        {/* Temperature control for thermostats */}
        {device.type === 'thermostat' && device.status === 'online' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Current</span>
              <span className="font-medium text-foreground">{device.settings.temperature}°F</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Target</span>
                <span className="text-sm font-medium text-primary">{targetTemp}°F</span>
              </div>
              <Slider
                value={[targetTemp]}
                onValueChange={handleTempChange}
                min={60}
                max={85}
                step={1}
                className="w-full"
              />
            </div>
          </div>
        )}

        {/* Lock toggle */}
        {device.type === 'lock' && device.status === 'online' && (
          <button
            onClick={handleLockToggle}
            className={cn(
              'flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all',
              isLocked 
                ? 'bg-success/10 text-success hover:bg-success/20' 
                : 'bg-destructive/10 text-destructive hover:bg-destructive/20'
            )}
          >
            {isLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
            {isLocked ? 'Locked' : 'Unlocked'}
          </button>
        )}

        {/* Camera status */}
        {device.type === 'camera' && device.status === 'online' && (
          <div className="flex items-center justify-center gap-2 rounded-lg bg-success/10 py-2.5 text-sm font-medium text-success">
            <span className="h-2 w-2 animate-pulse rounded-full bg-success" />
            Recording
          </div>
        )}
      </div>

      {/* Last used */}
      <div className="mt-4 border-t border-border pt-3">
        <p className="text-xs text-muted-foreground">
          Last used {formatDistanceToNow(device.lastUsed, { addSuffix: true })}
        </p>
      </div>
    </div>
  );
}
