import { NavLink } from '@/components/NavLink';
import { 
  LayoutDashboard, 
  Lightbulb, 
  Home, 
  Calendar, 
  Activity,
  Settings,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/devices', icon: Lightbulb, label: 'Devices' },
  { to: '/rooms', icon: Home, label: 'Rooms' },
  { to: '/schedules', icon: Calendar, label: 'Schedules' },
  { to: '/activity', icon: Activity, label: 'Activity' },
];

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border bg-sidebar">
      <div className="flex h-full flex-col">
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 border-b border-border px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 glow-primary">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">SmartHome</h1>
            <p className="text-xs text-muted-foreground">Control Panel</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 px-3 py-4">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={cn(
                'flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all duration-200',
                'text-muted-foreground hover:bg-sidebar-accent hover:text-foreground'
              )}
              activeClassName="bg-primary/10 text-primary glow-primary"
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Settings */}
        <div className="border-t border-border p-3">
          <NavLink
            to="/settings"
            className={cn(
              'flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all duration-200',
              'text-muted-foreground hover:bg-sidebar-accent hover:text-foreground'
            )}
            activeClassName="bg-primary/10 text-primary"
          >
            <Settings className="h-5 w-5" />
            Settings
          </NavLink>
        </div>
      </div>
    </aside>
  );
}
