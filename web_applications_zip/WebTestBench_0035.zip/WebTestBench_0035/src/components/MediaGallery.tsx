import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { Booth } from '@/data/booths';

interface MediaGalleryProps {
  media: Booth['mediaGallery'];
}

const MediaGallery = ({ media }: MediaGalleryProps) => {
  if (media.length === 0) return null;

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {media.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          className="group relative aspect-video overflow-hidden rounded-xl"
        >
          {item.type === 'video' ? (
            <div className="relative h-full w-full bg-muted">
              <video
                src={item.url}
                className="h-full w-full object-cover"
                poster={item.url}
              />
              <div className="absolute inset-0 flex items-center justify-center bg-foreground/20">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-foreground">
                  <Play className="h-6 w-6" />
                </div>
              </div>
            </div>
          ) : (
            <img
              src={item.url}
              alt={item.title}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          )}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/80 to-transparent p-4">
            <p className="text-sm font-medium text-primary-foreground">{item.title}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default MediaGallery;
