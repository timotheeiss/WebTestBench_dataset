import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Package } from 'lucide-react';
import { Booth } from '@/data/booths';

interface BoothCardProps {
  booth: Booth;
  index: number;
}

const BoothCard = ({ booth, index }: BoothCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      <Link to={`/booth/${booth.id}`} className="group block">
        <article className="relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-300 card-shadow hover:card-shadow-hover hover:-translate-y-1">
          {/* Category Badge */}
          <div className="absolute right-4 top-4">
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
              {booth.category}
            </span>
          </div>

          {/* Logo */}
          <div className="mb-4 h-16 w-16 overflow-hidden rounded-lg bg-muted">
            <img
              src={booth.logo}
              alt={`${booth.companyName} logo`}
              className="h-full w-full object-cover"
            />
          </div>

          {/* Content */}
          <h3 className="mb-2 font-display text-xl font-semibold text-card-foreground group-hover:text-accent transition-colors">
            {booth.companyName}
          </h3>
          <p className="mb-4 text-sm font-medium text-accent">{booth.tagline}</p>
          <p className="mb-6 line-clamp-2 text-sm text-muted-foreground">
            {booth.description}
          </p>

          {/* Footer */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Package className="h-4 w-4" />
              <span>{booth.products.length} products</span>
            </div>
            <span className="flex items-center gap-1 text-sm font-medium text-accent opacity-0 transition-all group-hover:opacity-100 group-hover:translate-x-1">
              Visit Booth
              <ArrowRight className="h-4 w-4" />
            </span>
          </div>
        </article>
      </Link>
    </motion.div>
  );
};

export default BoothCard;
