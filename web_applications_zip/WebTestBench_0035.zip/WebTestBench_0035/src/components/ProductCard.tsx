import { motion } from 'framer-motion';
import { Product } from '@/data/booths';

interface ProductCardProps {
  product: Product;
  index: number;
}

const ProductCard = ({ product, index }: ProductCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="group overflow-hidden rounded-xl border border-border bg-card transition-all card-shadow hover:card-shadow-hover"
    >
      {product.image && (
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      )}
      <div className="p-5">
        <h4 className="mb-2 font-display text-lg font-semibold text-card-foreground">
          {product.name}
        </h4>
        <p className="text-sm text-muted-foreground">{product.description}</p>
      </div>
    </motion.div>
  );
};

export default ProductCard;
