import { useState } from 'react';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import BoothCard from '@/components/BoothCard';
import CategoryFilter from '@/components/CategoryFilter';
import Footer from '@/components/Footer';
import { booths, categories } from '@/data/booths';

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredBooths = selectedCategory
    ? booths.filter((booth) => booth.category === selectedCategory)
    : booths;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />

      {/* Booths Section */}
      <section id="booths" className="py-16 sm:py-24">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <h2 className="mb-4 font-display text-3xl font-bold text-foreground sm:text-4xl">
              Explore Exhibitors
            </h2>
            <p className="mb-8 max-w-2xl text-muted-foreground">
              Browse through our curated selection of industry-leading companies.
              Click on any booth to learn more about their products and services.
            </p>
            <CategoryFilter
              categories={categories}
              selected={selectedCategory}
              onSelect={setSelectedCategory}
            />
          </motion.div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredBooths.map((booth, index) => (
              <BoothCard key={booth.id} booth={booth} index={index} />
            ))}
          </div>

          {filteredBooths.length === 0 && (
            <div className="py-16 text-center">
              <p className="text-muted-foreground">No booths found in this category.</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
