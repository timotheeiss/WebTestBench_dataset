import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Globe, Mail, MessageSquare, Package, Image } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import MediaGallery from '@/components/MediaGallery';
import MessageForm from '@/components/MessageForm';
import { booths } from '@/data/booths';

const BoothDetail = () => {
  const { id } = useParams<{ id: string }>();
  const booth = booths.find((b) => b.id === id);

  if (!booth) {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <Header />
        <main className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <h1 className="mb-4 font-display text-3xl font-bold text-foreground">
              Booth Not Found
            </h1>
            <p className="mb-6 text-muted-foreground">
              The booth you're looking for doesn't exist or has been removed.
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-accent hover:underline"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to all booths
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Booth Header */}
      <section className="border-b border-border bg-muted/30 py-12 sm:py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link
              to="/"
              className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to all booths
            </Link>

            <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
              <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-xl bg-card shadow-lg">
                <img
                  src={booth.logo}
                  alt={`${booth.companyName} logo`}
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="flex-1">
                <div className="mb-2 inline-block rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
                  {booth.category}
                </div>
                <h1 className="mb-2 font-display text-3xl font-bold text-foreground sm:text-4xl">
                  {booth.companyName}
                </h1>
                <p className="mb-4 text-lg text-accent">{booth.tagline}</p>
                <p className="max-w-3xl text-muted-foreground">{booth.description}</p>

                <div className="mt-6 flex flex-wrap gap-4">
                  {booth.website && (
                    <a
                      href={booth.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-sm font-medium text-secondary-foreground transition-colors hover:bg-secondary/80"
                    >
                      <Globe className="h-4 w-4" />
                      Visit Website
                    </a>
                  )}
                  <a
                    href={`mailto:${booth.contactEmail}`}
                    className="inline-flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-sm font-medium text-secondary-foreground transition-colors hover:bg-secondary/80"
                  >
                    <Mail className="h-4 w-4" />
                    {booth.contactEmail}
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 sm:py-16">
        <div className="container mx-auto px-4">
          <div className="grid gap-12 lg:grid-cols-3">
            {/* Products & Media */}
            <div className="lg:col-span-2 space-y-12">
              {/* Products */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                    <Package className="h-5 w-5 text-accent" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-foreground">
                    Products & Services
                  </h2>
                </div>
                <div className="grid gap-6 sm:grid-cols-2">
                  {booth.products.map((product, index) => (
                    <ProductCard key={product.id} product={product} index={index} />
                  ))}
                </div>
              </motion.div>

              {/* Media Gallery */}
              {booth.mediaGallery.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="mb-6 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                      <Image className="h-5 w-5 text-accent" />
                    </div>
                    <h2 className="font-display text-2xl font-bold text-foreground">
                      Gallery
                    </h2>
                  </div>
                  <MediaGallery media={booth.mediaGallery} />
                </motion.div>
              )}
            </div>

            {/* Contact Form Sidebar */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="sticky top-24 rounded-xl border border-border bg-card p-6 card-shadow">
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                    <MessageSquare className="h-5 w-5 text-accent" />
                  </div>
                  <h2 className="font-display text-xl font-bold text-card-foreground">
                    Send a Message
                  </h2>
                </div>
                <p className="mb-6 text-sm text-muted-foreground">
                  Have questions? Send a message to {booth.companyName} and they'll get back to you.
                </p>
                <MessageForm boothId={booth.id} companyName={booth.companyName} />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BoothDetail;
