import { Message } from '@/data/booths';

// In-memory message storage (resets on page refresh)
let messages: Message[] = [];

export const addMessage = (boothId: string, senderName: string, senderEmail: string, messageText: string): Message => {
  const newMessage: Message = {
    id: crypto.randomUUID(),
    boothId,
    senderName,
    senderEmail,
    message: messageText,
    timestamp: new Date()
  };
  messages.push(newMessage);
  return newMessage;
};

export const getMessagesForBooth = (boothId: string): Message[] => {
  return messages.filter(m => m.boothId === boothId);
};
