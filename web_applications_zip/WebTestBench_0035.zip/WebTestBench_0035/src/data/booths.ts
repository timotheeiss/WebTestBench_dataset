export interface Product {
  id: string;
  name: string;
  description: string;
  image?: string;
}

export interface Booth {
  id: string;
  companyName: string;
  logo: string;
  tagline: string;
  description: string;
  category: string;
  products: Product[];
  mediaGallery: { type: 'image' | 'video'; url: string; title: string }[];
  contactEmail: string;
  website?: string;
}

export interface Message {
  id: string;
  boothId: string;
  senderName: string;
  senderEmail: string;
  message: string;
  timestamp: Date;
}

export const booths: Booth[] = [
  {
    id: 'techvision',
    companyName: 'TechVision AI',
    logo: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=200&h=200&fit=crop',
    tagline: 'Pioneering the Future of Artificial Intelligence',
    description: 'TechVision AI is at the forefront of machine learning innovation. Our enterprise solutions help businesses automate complex processes, gain actionable insights from data, and stay competitive in an AI-driven world. With over 500 enterprise clients globally, we deliver scalable AI infrastructure that transforms operations.',
    category: 'Technology',
    products: [
      {
        id: 'tv-1',
        name: 'VisionML Platform',
        description: 'End-to-end machine learning platform for enterprise deployment',
        image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=300&fit=crop'
      },
      {
        id: 'tv-2',
        name: 'DataSense Analytics',
        description: 'Real-time data analytics with predictive capabilities',
        image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop'
      },
      {
        id: 'tv-3',
        name: 'AutoML Studio',
        description: 'No-code machine learning model builder for teams',
        image: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=400&h=300&fit=crop'
      }
    ],
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&h=600&fit=crop', title: 'AI Research Lab' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1531746790731-6c087fecd65a?w=800&h=600&fit=crop', title: 'Team Collaboration' }
    ],
    contactEmail: 'sales@techvision.ai',
    website: 'https://techvision.ai'
  },
  {
    id: 'greenleaf',
    companyName: 'GreenLeaf Sustainability',
    logo: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=200&h=200&fit=crop',
    tagline: 'Building a Sustainable Tomorrow',
    description: 'GreenLeaf Sustainability partners with organizations to reduce their environmental footprint. From carbon offset programs to sustainable supply chain consulting, we provide comprehensive solutions that align business growth with environmental responsibility. Join the 200+ companies who have achieved carbon neutrality with us.',
    category: 'Sustainability',
    products: [
      {
        id: 'gl-1',
        name: 'Carbon Tracker Pro',
        description: 'Complete carbon footprint monitoring and reporting system',
        image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=400&h=300&fit=crop'
      },
      {
        id: 'gl-2',
        name: 'EcoSupply Chain',
        description: 'Sustainable sourcing and supplier assessment platform',
        image: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400&h=300&fit=crop'
      }
    ],
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&h=600&fit=crop', title: 'Forest Conservation' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&h=600&fit=crop', title: 'Solar Installation' }
    ],
    contactEmail: 'hello@greenleaf.eco',
    website: 'https://greenleaf.eco'
  },
  {
    id: 'cloudnine',
    companyName: 'CloudNine Solutions',
    logo: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=200&h=200&fit=crop',
    tagline: 'Enterprise Cloud Infrastructure Done Right',
    description: 'CloudNine Solutions delivers enterprise-grade cloud infrastructure with unmatched reliability. Our managed services ensure 99.99% uptime while reducing infrastructure costs by up to 40%. Trusted by Fortune 500 companies for mission-critical workloads.',
    category: 'Technology',
    products: [
      {
        id: 'cn-1',
        name: 'CloudNine Managed Kubernetes',
        description: 'Fully managed K8s clusters with auto-scaling',
        image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop'
      },
      {
        id: 'cn-2',
        name: 'SecureVault',
        description: 'Enterprise secrets and configuration management',
        image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400&h=300&fit=crop'
      },
      {
        id: 'cn-3',
        name: 'CloudWatch 360',
        description: 'Comprehensive monitoring and alerting solution',
        image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop'
      }
    ],
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=600&fit=crop', title: 'Global Data Centers' }
    ],
    contactEmail: 'enterprise@cloudnine.io',
    website: 'https://cloudnine.io'
  },
  {
    id: 'medtech',
    companyName: 'MedTech Innovations',
    logo: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=200&h=200&fit=crop',
    tagline: 'Advancing Healthcare Through Technology',
    description: 'MedTech Innovations develops cutting-edge medical devices and healthcare software. Our FDA-approved solutions help hospitals and clinics deliver better patient outcomes while streamlining operations. With products in over 2,000 healthcare facilities worldwide.',
    category: 'Healthcare',
    products: [
      {
        id: 'mt-1',
        name: 'VitalSync Monitor',
        description: 'Wireless patient monitoring with AI-powered alerts',
        image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&h=300&fit=crop'
      },
      {
        id: 'mt-2',
        name: 'CareFlow EHR',
        description: 'Modern electronic health records system',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=300&fit=crop'
      }
    ],
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&h=600&fit=crop', title: 'Modern Hospital' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1551076805-e1869033e561?w=800&h=600&fit=crop', title: 'Medical Equipment' }
    ],
    contactEmail: 'info@medtech-innovations.com',
    website: 'https://medtech-innovations.com'
  },
  {
    id: 'financeplus',
    companyName: 'FinancePlus',
    logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=200&h=200&fit=crop',
    tagline: 'Modern Financial Solutions for Growing Businesses',
    description: 'FinancePlus provides comprehensive financial management tools designed for modern businesses. From automated invoicing to real-time cash flow analytics, our platform helps companies of all sizes manage their finances with confidence and clarity.',
    category: 'Finance',
    products: [
      {
        id: 'fp-1',
        name: 'InvoiceFlow',
        description: 'Automated invoicing and payment collection',
        image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=300&fit=crop'
      },
      {
        id: 'fp-2',
        name: 'CashFlow Pro',
        description: 'Real-time cash flow forecasting and management',
        image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop'
      },
      {
        id: 'fp-3',
        name: 'ExpenseTrack',
        description: 'Smart expense management with receipt scanning',
        image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=400&h=300&fit=crop'
      }
    ],
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop', title: 'Financial Dashboard' }
    ],
    contactEmail: 'sales@financeplus.io',
    website: 'https://financeplus.io'
  }
];

export const categories = [...new Set(booths.map(b => b.category))];
