import { useMemo } from 'react';
import { BarChart3, Eye, Heart, MessageCircle, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Post, Comment } from '@/contexts/PostsContext';
import { cn } from '@/lib/utils';

interface TagAnalyticsProps {
  posts: Post[];
  comments: Comment[];
}

interface TagStats {
  tag: string;
  type: 'custom' | 'intelligent';
  postCount: number;
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  popularity: number;
}

export default function TagAnalytics({ posts, comments }: TagAnalyticsProps) {
  const tagStats = useMemo(() => {
    const statsMap = new Map<string, TagStats>();

    posts.forEach(post => {
      const postComments = comments.filter(c => c.postId === post.id).length;

      // Process custom tags
      post.tags.forEach(tag => {
        const existing = statsMap.get(`custom-${tag}`);
        if (existing) {
          existing.postCount++;
          existing.totalViews += post.views || 0;
          existing.totalLikes += post.likes.length;
          existing.totalComments += postComments;
        } else {
          statsMap.set(`custom-${tag}`, {
            tag,
            type: 'custom',
            postCount: 1,
            totalViews: post.views || 0,
            totalLikes: post.likes.length,
            totalComments: postComments,
            popularity: 0,
          });
        }
      });

      // Process intelligent tags
      post.autoTags?.forEach(tag => {
        const existing = statsMap.get(`intelligent-${tag}`);
        if (existing) {
          existing.postCount++;
          existing.totalViews += post.views || 0;
          existing.totalLikes += post.likes.length;
          existing.totalComments += postComments;
        } else {
          statsMap.set(`intelligent-${tag}`, {
            tag,
            type: 'intelligent',
            postCount: 1,
            totalViews: post.views || 0,
            totalLikes: post.likes.length,
            totalComments: postComments,
            popularity: 0,
          });
        }
      });
    });

    // Calculate popularity score
    const stats = Array.from(statsMap.values());
    stats.forEach(stat => {
      stat.popularity = stat.totalViews * 0.1 + stat.totalLikes * 2 + stat.totalComments * 3;
    });

    // Sort by popularity
    return stats.sort((a, b) => b.popularity - a.popularity);
  }, [posts, comments]);

  const maxPopularity = Math.max(...tagStats.map(s => s.popularity), 1);

  if (tagStats.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <BarChart3 className="h-5 w-5" />
            Tag Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No tag data available yet. Start adding tags to your posts!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <BarChart3 className="h-5 w-5" />
          Tag Popularity Report
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <p className="text-2xl font-bold text-foreground">{tagStats.length}</p>
              <p className="text-xs text-muted-foreground">Total Tags</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <p className="text-2xl font-bold text-foreground">
                {tagStats.reduce((sum, s) => sum + s.totalViews, 0)}
              </p>
              <p className="text-xs text-muted-foreground">Total Views</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <p className="text-2xl font-bold text-foreground">
                {tagStats.reduce((sum, s) => sum + s.totalLikes, 0)}
              </p>
              <p className="text-xs text-muted-foreground">Total Likes</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <p className="text-2xl font-bold text-foreground">
                {tagStats.reduce((sum, s) => sum + s.totalComments, 0)}
              </p>
              <p className="text-xs text-muted-foreground">Total Comments</p>
            </div>
          </div>

          {/* Tag List */}
          <div className="space-y-3">
            {tagStats.slice(0, 10).map((stat, index) => (
              <div key={`${stat.type}-${stat.tag}`} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-muted-foreground w-6">
                      #{index + 1}
                    </span>
                    <Badge
                      variant={stat.type === 'custom' ? 'secondary' : 'default'}
                      className={cn(
                        stat.type === 'intelligent' && 'bg-primary/10 text-primary border-primary/20'
                      )}
                    >
                      {stat.tag}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {stat.postCount} {stat.postCount === 1 ? 'post' : 'posts'}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {stat.totalViews}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      {stat.totalLikes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-3 w-3" />
                      {stat.totalComments}
                    </span>
                  </div>
                </div>
                <div className="ml-8 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all",
                      stat.type === 'custom' ? 'bg-secondary-foreground/30' : 'bg-primary/50'
                    )}
                    style={{ width: `${(stat.popularity / maxPopularity) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {tagStats.length > 10 && (
            <p className="text-xs text-muted-foreground text-center pt-4">
              Showing top 10 of {tagStats.length} tags
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
