import { useState, useEffect } from 'react';
import { X, Plus, Sparkles, Tag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { extractIntelligentTags } from '@/lib/tagUtils';
import { cn } from '@/lib/utils';

interface TagInputProps {
  customTags: string[];
  onCustomTagsChange: (tags: string[]) => void;
  autoTags: string[];
  onAutoTagsChange: (tags: string[]) => void;
  content: string;
  title: string;
}

export default function TagInput({
  customTags,
  onCustomTagsChange,
  autoTags,
  onAutoTagsChange,
  content,
  title,
}: TagInputProps) {
  const [inputValue, setInputValue] = useState('');
  const [suggestedTags, setSuggestedTags] = useState<string[]>([]);

  useEffect(() => {
    // Extract intelligent tags when content or title changes
    const extracted = extractIntelligentTags(content, title);
    setSuggestedTags(extracted.filter(tag => !autoTags.includes(tag)));
  }, [content, title, autoTags]);

  const handleAddTag = () => {
    const tag = inputValue.trim();
    if (tag && !customTags.includes(tag)) {
      onCustomTagsChange([...customTags, tag]);
      setInputValue('');
    }
  };

  const handleRemoveCustomTag = (tagToRemove: string) => {
    onCustomTagsChange(customTags.filter(tag => tag !== tagToRemove));
  };

  const handleRemoveAutoTag = (tagToRemove: string) => {
    onAutoTagsChange(autoTags.filter(tag => tag !== tagToRemove));
  };

  const handleAddSuggestedTag = (tag: string) => {
    if (!autoTags.includes(tag)) {
      onAutoTagsChange([...autoTags, tag]);
      setSuggestedTags(prev => prev.filter(t => t !== tag));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  return (
    <div className="space-y-4">
      {/* Custom Tags */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Tag className="h-4 w-4" />
          <span>Custom Tags</span>
        </div>
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Add a tag (e.g., Technology, Life)..."
            className="flex-1"
          />
          <Button type="button" variant="outline" size="icon" onClick={handleAddTag}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        {customTags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {customTags.map(tag => (
              <Badge
                key={tag}
                variant="secondary"
                className="gap-1 pr-1 text-sm"
              >
                {tag}
                <button
                  type="button"
                  onClick={() => handleRemoveCustomTag(tag)}
                  className="ml-1 hover:bg-muted rounded p-0.5 transition-colors"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      {/* Intelligent Tags */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="h-4 w-4 text-primary" />
          <span>Intelligent Tags (auto-detected)</span>
        </div>
        
        {autoTags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {autoTags.map(tag => (
              <Badge
                key={tag}
                className="gap-1 pr-1 text-sm bg-primary/10 text-primary border-primary/20"
              >
                <Sparkles className="h-3 w-3" />
                {tag}
                <button
                  type="button"
                  onClick={() => handleRemoveAutoTag(tag)}
                  className="ml-1 hover:bg-primary/20 rounded p-0.5 transition-colors"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Suggested Tags */}
        {suggestedTags.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Suggested based on content:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedTags.map(tag => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleAddSuggestedTag(tag)}
                  className={cn(
                    "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs",
                    "border border-dashed border-primary/40 text-primary/80",
                    "hover:bg-primary/10 hover:border-primary transition-colors"
                  )}
                >
                  <Plus className="h-3 w-3" />
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
