import { Link } from 'react-router-dom';
import { Post } from '@/contexts/PostsContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, Clock, BookmarkPlus, BookmarkCheck } from 'lucide-react';
import { usePosts } from '@/contexts/PostsContext';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface PostCardProps {
  post: Post;
  featured?: boolean;
}

export default function PostCard({ post, featured = false }: PostCardProps) {
  const { likePost, savePost, savedPosts } = usePosts();
  const { user, isAuthenticated } = useAuth();
  
  const hasLiked = user ? post.likes.includes(user.id) : false;
  const hasSaved = savedPosts.includes(post.id);

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isAuthenticated) {
      likePost(post.id);
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isAuthenticated) {
      savePost(post.id);
    }
  };

  if (featured) {
    return (
      <Link 
        to={`/post/${post.id}`}
        className="group block overflow-hidden rounded-2xl bg-card shadow-card transition-smooth hover:shadow-elevated"
      >
        <div className="grid md:grid-cols-2 gap-0">
          {post.coverImage && (
            <div className="relative aspect-[4/3] md:aspect-auto overflow-hidden">
              <img 
                src={post.coverImage} 
                alt={post.title}
                className="absolute inset-0 w-full h-full object-cover transition-smooth group-hover:scale-105"
              />
            </div>
          )}
          <div className="p-6 md:p-8 flex flex-col justify-center">
            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags.slice(0, 2).map(tag => (
                <Badge key={tag} variant="secondary" className="text-xs font-medium">
                  {tag}
                </Badge>
              ))}
            </div>
            
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-3 group-hover:text-primary transition-smooth line-clamp-2">
              {post.title}
            </h2>
            
            <p className="text-muted-foreground mb-6 line-clamp-3">
              {post.excerpt}
            </p>
            
            <div className="flex items-center justify-between mt-auto">
              <Link 
                to={`/profile/${post.authorId}`}
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-3 group/author"
              >
                <Avatar className="h-10 w-10 ring-2 ring-transparent group-hover/author:ring-primary/20 transition-smooth">
                  <AvatarImage src={post.authorAvatar} alt={post.authorName} />
                  <AvatarFallback>{post.authorName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-foreground group-hover/author:text-primary transition-smooth">
                    {post.authorName}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{post.createdAt}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {post.readTime} min read
                    </span>
                  </div>
                </div>
              </Link>
              
              {isAuthenticated && (
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleLike}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm transition-smooth",
                      hasLiked 
                        ? "bg-primary/10 text-primary" 
                        : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                    )}
                  >
                    <Heart className={cn("h-4 w-4", hasLiked && "fill-current animate-heart-beat")} />
                    {post.likes.length}
                  </button>
                  <button 
                    onClick={handleSave}
                    className={cn(
                      "p-2 rounded-full transition-smooth",
                      hasSaved 
                        ? "bg-accent/10 text-accent" 
                        : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                    )}
                  >
                    {hasSaved ? (
                      <BookmarkCheck className="h-4 w-4" />
                    ) : (
                      <BookmarkPlus className="h-4 w-4" />
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link 
      to={`/post/${post.id}`}
      className="group block overflow-hidden rounded-xl bg-card shadow-card transition-smooth hover:shadow-elevated animate-fade-in"
    >
      {post.coverImage && (
        <div className="relative aspect-[16/9] overflow-hidden">
          <img 
            src={post.coverImage} 
            alt={post.title}
            className="absolute inset-0 w-full h-full object-cover transition-smooth group-hover:scale-105"
          />
        </div>
      )}
      
      <div className="p-5">
        <div className="flex flex-wrap gap-2 mb-3">
          {post.tags.slice(0, 2).map(tag => (
            <Badge key={tag} variant="secondary" className="text-xs font-medium">
              {tag}
            </Badge>
          ))}
        </div>
        
        <h3 className="font-serif text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-smooth line-clamp-2">
          {post.title}
        </h3>
        
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {post.excerpt}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-7 w-7">
              <AvatarImage src={post.authorAvatar} alt={post.authorName} />
              <AvatarFallback className="text-xs">{post.authorName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">{post.authorName}</span>
              <span>•</span>
              <span>{post.readTime} min</span>
            </div>
          </div>
          
          {isAuthenticated && (
            <div className="flex items-center gap-1">
              <button 
                onClick={handleLike}
                className={cn(
                  "flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-smooth",
                  hasLiked 
                    ? "text-primary" 
                    : "text-muted-foreground hover:text-primary"
                )}
              >
                <Heart className={cn("h-3.5 w-3.5", hasLiked && "fill-current")} />
                {post.likes.length > 0 && post.likes.length}
              </button>
              <button 
                onClick={handleSave}
                className={cn(
                  "p-1 rounded-full transition-smooth",
                  hasSaved 
                    ? "text-accent" 
                    : "text-muted-foreground hover:text-accent"
                )}
              >
                {hasSaved ? (
                  <BookmarkCheck className="h-3.5 w-3.5" />
                ) : (
                  <BookmarkPlus className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
