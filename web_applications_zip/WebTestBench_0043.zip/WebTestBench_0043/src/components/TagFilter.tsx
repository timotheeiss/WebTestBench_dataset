import { useState } from 'react';
import { X, Filter, Sparkles, Tag, Save, FolderOpen, Plus, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { SavedTagGroup } from '@/lib/tagUtils';
import { cn } from '@/lib/utils';

interface TagFilterProps {
  availableCustomTags: string[];
  availableIntelligentTags: string[];
  selectedCustomTags: string[];
  selectedIntelligentTags: string[];
  onCustomTagsChange: (tags: string[]) => void;
  onIntelligentTagsChange: (tags: string[]) => void;
  savedTagGroups: SavedTagGroup[];
  onSaveTagGroup: (name: string) => void;
  onLoadTagGroup: (group: SavedTagGroup) => void;
  onDeleteTagGroup: (groupId: string) => void;
}

export default function TagFilter({
  availableCustomTags,
  availableIntelligentTags,
  selectedCustomTags,
  selectedIntelligentTags,
  onCustomTagsChange,
  onIntelligentTagsChange,
  savedTagGroups,
  onSaveTagGroup,
  onLoadTagGroup,
  onDeleteTagGroup,
}: TagFilterProps) {
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [savedGroupsOpen, setSavedGroupsOpen] = useState(false);

  const hasActiveFilters = selectedCustomTags.length > 0 || selectedIntelligentTags.length > 0;

  const toggleCustomTag = (tag: string) => {
    if (selectedCustomTags.includes(tag)) {
      onCustomTagsChange(selectedCustomTags.filter(t => t !== tag));
    } else {
      onCustomTagsChange([...selectedCustomTags, tag]);
    }
  };

  const toggleIntelligentTag = (tag: string) => {
    if (selectedIntelligentTags.includes(tag)) {
      onIntelligentTagsChange(selectedIntelligentTags.filter(t => t !== tag));
    } else {
      onIntelligentTagsChange([...selectedIntelligentTags, tag]);
    }
  };

  const clearAllFilters = () => {
    onCustomTagsChange([]);
    onIntelligentTagsChange([]);
  };

  const handleSaveGroup = () => {
    if (groupName.trim() && hasActiveFilters) {
      onSaveTagGroup(groupName.trim());
      setGroupName('');
      setSaveDialogOpen(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filter Controls */}
      <div className="flex flex-wrap items-center gap-2">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Filter className="h-4 w-4" />
              Filter by Tags
              {hasActiveFilters && (
                <Badge variant="secondary" className="ml-1 px-1.5 py-0 text-xs">
                  {selectedCustomTags.length + selectedIntelligentTags.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-4" align="start">
            <div className="space-y-4">
              {/* Custom Tags */}
              {availableCustomTags.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Tag className="h-4 w-4" />
                    Custom Tags
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {availableCustomTags.map(tag => (
                      <button
                        key={tag}
                        onClick={() => toggleCustomTag(tag)}
                        className={cn(
                          "px-2 py-1 rounded-md text-xs transition-colors",
                          selectedCustomTags.includes(tag)
                            ? "bg-secondary text-secondary-foreground"
                            : "bg-muted/50 text-muted-foreground hover:bg-muted"
                        )}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Intelligent Tags */}
              {availableIntelligentTags.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Sparkles className="h-4 w-4 text-primary" />
                    Intelligent Tags
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {availableIntelligentTags.map(tag => (
                      <button
                        key={tag}
                        onClick={() => toggleIntelligentTag(tag)}
                        className={cn(
                          "px-2 py-1 rounded-md text-xs transition-colors",
                          selectedIntelligentTags.includes(tag)
                            ? "bg-primary/20 text-primary"
                            : "bg-primary/5 text-primary/70 hover:bg-primary/10"
                        )}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </PopoverContent>
        </Popover>

        {/* Saved Tag Groups */}
        <Popover open={savedGroupsOpen} onOpenChange={setSavedGroupsOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <FolderOpen className="h-4 w-4" />
              Saved Filters
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-2" align="start">
            {savedTagGroups.length > 0 ? (
              <div className="space-y-1">
                {savedTagGroups.map(group => (
                  <div
                    key={group.id}
                    className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 group"
                  >
                    <button
                      onClick={() => {
                        onLoadTagGroup(group);
                        setSavedGroupsOpen(false);
                      }}
                      className="flex-1 text-left text-sm"
                    >
                      {group.name}
                      <span className="text-xs text-muted-foreground ml-2">
                        ({group.customTags.length + group.intelligentTags.length} tags)
                      </span>
                    </button>
                    <button
                      onClick={() => onDeleteTagGroup(group.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:text-destructive transition-all"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                No saved filters yet
              </p>
            )}
          </PopoverContent>
        </Popover>

        {/* Save Current Filter */}
        {hasActiveFilters && (
          <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2">
                <Save className="h-4 w-4" />
                Save Filter
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save Tag Filter</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Input
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="Filter name..."
                  />
                </div>
                <div className="text-sm text-muted-foreground">
                  <p className="mb-2">Selected tags:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedCustomTags.map(tag => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {selectedIntelligentTags.map(tag => (
                      <Badge key={tag} className="text-xs bg-primary/10 text-primary">
                        <Sparkles className="h-3 w-3 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button onClick={handleSaveGroup} className="w-full">
                  Save Filter
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearAllFilters} className="gap-2 text-muted-foreground">
            <X className="h-4 w-4" />
            Clear
          </Button>
        )}
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground">Active:</span>
          {selectedCustomTags.map(tag => (
            <Badge
              key={tag}
              variant="secondary"
              className="gap-1 pr-1 cursor-pointer hover:bg-secondary/80"
              onClick={() => toggleCustomTag(tag)}
            >
              {tag}
              <X className="h-3 w-3" />
            </Badge>
          ))}
          {selectedIntelligentTags.map(tag => (
            <Badge
              key={tag}
              className="gap-1 pr-1 cursor-pointer bg-primary/10 text-primary hover:bg-primary/20"
              onClick={() => toggleIntelligentTag(tag)}
            >
              <Sparkles className="h-3 w-3" />
              {tag}
              <X className="h-3 w-3" />
            </Badge>
          ))}
          {selectedCustomTags.length > 0 && selectedIntelligentTags.length > 0 && (
            <span className="text-xs text-muted-foreground ml-2">
              (showing posts matching all selected tags)
            </span>
          )}
        </div>
      )}
    </div>
  );
}
