import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { PenLine, Bookmark, User, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="container mx-auto px-4">
          <nav className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link 
              to="/" 
              className="font-serif text-2xl font-bold tracking-tight text-foreground transition-smooth hover:text-primary"
            >
              Inkwell
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-6">
              <Link 
                to="/" 
                className={`text-sm font-medium transition-smooth ${
                  isActive('/') ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Home
              </Link>
              
              {isAuthenticated ? (
                <>
                  <Link 
                    to="/saved" 
                    className={`text-sm font-medium transition-smooth ${
                      isActive('/saved') ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Saved
                  </Link>
                  
                  <Button asChild variant="default" size="sm" className="gap-2">
                    <Link to="/write">
                      <PenLine className="h-4 w-4" />
                      Write
                    </Link>
                  </Button>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="rounded-full ring-2 ring-transparent transition-smooth hover:ring-primary/20 focus:outline-none focus:ring-primary/30">
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={user?.avatar} alt={user?.name} />
                          <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                        </Avatar>
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56 animate-scale-in">
                      <div className="px-2 py-1.5">
                        <p className="text-sm font-medium">{user?.name}</p>
                        <p className="text-xs text-muted-foreground">{user?.email}</p>
                      </div>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link to={`/profile/${user?.id}`} className="cursor-pointer">
                          <User className="mr-2 h-4 w-4" />
                          Profile
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/saved" className="cursor-pointer">
                          <Bookmark className="mr-2 h-4 w-4" />
                          Saved Posts
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive">
                        <LogOut className="mr-2 h-4 w-4" />
                        Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <div className="flex items-center gap-3">
                  <Button asChild variant="ghost" size="sm">
                    <Link to="/login">Sign In</Link>
                  </Button>
                  <Button asChild size="sm">
                    <Link to="/signup">Get Started</Link>
                  </Button>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-foreground"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </nav>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-border py-4 animate-fade-in">
              <div className="flex flex-col gap-3">
                <Link 
                  to="/" 
                  className="px-2 py-2 text-sm font-medium text-foreground hover:text-primary transition-smooth"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Home
                </Link>
                
                {isAuthenticated ? (
                  <>
                    <Link 
                      to="/saved" 
                      className="px-2 py-2 text-sm font-medium text-foreground hover:text-primary transition-smooth"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Saved Posts
                    </Link>
                    <Link 
                      to={`/profile/${user?.id}`}
                      className="px-2 py-2 text-sm font-medium text-foreground hover:text-primary transition-smooth"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Profile
                    </Link>
                    <Link 
                      to="/write" 
                      className="px-2 py-2 text-sm font-medium text-primary hover:text-primary/80 transition-smooth"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Write a Post
                    </Link>
                    <button 
                      onClick={() => { logout(); setMobileMenuOpen(false); }}
                      className="px-2 py-2 text-sm font-medium text-destructive text-left"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <Link 
                      to="/login" 
                      className="px-2 py-2 text-sm font-medium text-foreground hover:text-primary transition-smooth"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Sign In
                    </Link>
                    <Link 
                      to="/signup" 
                      className="px-2 py-2 text-sm font-medium text-primary hover:text-primary/80 transition-smooth"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Get Started
                    </Link>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="border-t border-border bg-secondary/30 py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-serif text-xl font-bold text-foreground">Inkwell</span>
              <span className="text-muted-foreground">•</span>
              <span className="text-sm text-muted-foreground">Stories that matter</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Inkwell. Made with ♥
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
