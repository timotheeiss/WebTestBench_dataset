import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePosts, Comment } from '@/contexts/PostsContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Trash2, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CommentSectionProps {
  postId: string;
}

export default function CommentSection({ postId }: CommentSectionProps) {
  const { user, isAuthenticated } = useAuth();
  const { getPostComments, addComment, deleteComment } = usePosts();
  const [newComment, setNewComment] = useState('');
  
  const comments = getPostComments(postId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      addComment(postId, newComment.trim());
      setNewComment('');
    }
  };

  return (
    <section className="mt-12 pt-12 border-t border-border">
      <h3 className="font-serif text-2xl font-bold text-foreground mb-8 flex items-center gap-2">
        <MessageCircle className="h-6 w-6 text-primary" />
        Comments ({comments.length})
      </h3>
      
      {/* Comment Form */}
      {isAuthenticated ? (
        <form onSubmit={handleSubmit} className="mb-10">
          <div className="flex gap-4">
            <Avatar className="h-10 w-10 shrink-0">
              <AvatarImage src={user?.avatar} alt={user?.name} />
              <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Share your thoughts..."
                className="min-h-[100px] resize-none mb-3"
              />
              <Button 
                type="submit" 
                disabled={!newComment.trim()}
                className="transition-smooth"
              >
                Post Comment
              </Button>
            </div>
          </div>
        </form>
      ) : (
        <div className="bg-secondary/50 rounded-lg p-6 text-center mb-10">
          <p className="text-muted-foreground mb-3">Join the conversation</p>
          <div className="flex justify-center gap-3">
            <Button asChild variant="outline">
              <Link to="/login">Sign In</Link>
            </Button>
            <Button asChild>
              <Link to="/signup">Sign Up</Link>
            </Button>
          </div>
        </div>
      )}
      
      {/* Comments List */}
      <div className="space-y-6">
        {comments.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No comments yet. Be the first to share your thoughts!
          </p>
        ) : (
          comments.map((comment) => (
            <CommentItem 
              key={comment.id} 
              comment={comment}
              canDelete={user?.id === comment.authorId}
              onDelete={() => deleteComment(comment.id)}
            />
          ))
        )}
      </div>
    </section>
  );
}

interface CommentItemProps {
  comment: Comment;
  canDelete: boolean;
  onDelete: () => void;
}

function CommentItem({ comment, canDelete, onDelete }: CommentItemProps) {
  return (
    <div className="flex gap-4 animate-fade-in">
      <Link to={`/profile/${comment.authorId}`}>
        <Avatar className="h-10 w-10 shrink-0 ring-2 ring-transparent hover:ring-primary/20 transition-smooth">
          <AvatarImage src={comment.authorAvatar} alt={comment.authorName} />
          <AvatarFallback>{comment.authorName.charAt(0)}</AvatarFallback>
        </Avatar>
      </Link>
      <div className="flex-1">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <Link 
              to={`/profile/${comment.authorId}`}
              className="font-medium text-foreground hover:text-primary transition-smooth"
            >
              {comment.authorName}
            </Link>
            <span className="text-sm text-muted-foreground">{comment.createdAt}</span>
          </div>
          {canDelete && (
            <button 
              onClick={onDelete}
              className="p-1.5 text-muted-foreground hover:text-destructive transition-smooth rounded-md hover:bg-destructive/10"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
        <p className="text-foreground leading-relaxed">{comment.content}</p>
      </div>
    </div>
  );
}
