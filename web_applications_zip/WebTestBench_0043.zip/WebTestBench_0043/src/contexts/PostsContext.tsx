import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { SavedTagGroup, createTagGroup } from '@/lib/tagUtils';

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  coverImage?: string;
  createdAt: string;
  updatedAt: string;
  published: boolean;
  likes: string[];
  readTime: number;
  tags: string[];
  autoTags: string[];
  views: number;
}

interface PostsContextType {
  posts: Post[];
  comments: Comment[];
  savedPosts: string[];
  savedTagGroups: import('@/lib/tagUtils').SavedTagGroup[];
  createPost: (post: Omit<Post, 'id' | 'authorId' | 'authorName' | 'authorAvatar' | 'createdAt' | 'updatedAt' | 'likes' | 'readTime' | 'views'>) => Post | null;
  updatePost: (id: string, updates: Partial<Post>) => void;
  deletePost: (id: string) => void;
  likePost: (postId: string) => void;
  savePost: (postId: string) => void;
  incrementViews: (postId: string) => void;
  addComment: (postId: string, content: string) => void;
  deleteComment: (commentId: string) => void;
  getPostById: (id: string) => Post | undefined;
  getPostsByAuthor: (authorId: string) => Post[];
  getPostComments: (postId: string) => Comment[];
  saveTagGroup: (name: string, customTags: string[], intelligentTags: string[]) => void;
  deleteTagGroup: (groupId: string) => void;
}

const PostsContext = createContext<PostsContextType | undefined>(undefined);

const DEFAULT_POSTS: Post[] = [
  {
    id: 'post-1',
    title: 'The Art of Writing Clean Code',
    content: `# The Art of Writing Clean Code

Writing clean code is more than just a skill—it's a mindset. After years of software development, I've come to appreciate the profound impact that well-structured, readable code has on both individual productivity and team collaboration.

## Why Clean Code Matters

When we write code, we're not just instructing a computer. We're communicating with future developers—including our future selves. Clean code serves as documentation, reducing the cognitive load required to understand and modify a system.

> "Any fool can write code that a computer can understand. Good programmers write code that humans can understand." — Martin Fowler

## Key Principles

### 1. Meaningful Names

Variables, functions, and classes should reveal their intent. Instead of:

\`\`\`javascript
const d = new Date();
const x = d.getTime();
\`\`\`

Write:

\`\`\`javascript
const currentDate = new Date();
const timestampInMs = currentDate.getTime();
\`\`\`

### 2. Small Functions

Functions should do one thing and do it well. If a function needs a comment to explain what it does, consider breaking it into smaller pieces.

### 3. Avoid Side Effects

Pure functions—those that always produce the same output for the same input and don't modify external state—are easier to test and reason about.

## The Journey Continues

Clean code is a continuous journey, not a destination. Every refactoring session is an opportunity to improve. Every code review is a chance to learn.

Start small. Pick one principle. Apply it consistently. Watch your codebase transform.`,
    excerpt: 'Writing clean code is more than just a skill—it\'s a mindset that transforms how we build software.',
    authorId: 'user-2',
    authorName: 'Marcus Webb',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    coverImage: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=1200&h=600&fit=crop',
    createdAt: '2024-11-15',
    updatedAt: '2024-11-15',
    published: true,
    likes: ['user-1', 'user-3'],
    readTime: 5,
    tags: ['Programming', 'Best Practices', 'Software Development'],
    autoTags: ['JavaScript', 'Code Examples', 'Best Practices'],
    views: 142,
  },
  {
    id: 'post-2',
    title: 'Finding Creativity in Constraints',
    content: `# Finding Creativity in Constraints

As a designer, I used to think that creativity required unlimited freedom. No boundaries. No rules. Just pure, uninhibited expression. I was wrong.

## The Paradox of Choice

When faced with infinite possibilities, we often find ourselves paralyzed. The blank canvas becomes intimidating rather than inspiring. This is where constraints become our unexpected allies.

## Embracing Limitations

Some of the most iconic designs emerged from severe constraints:

- **The original iPhone** was constrained to a single button
- **Twitter's 140 characters** forced users to be concise
- **Instagram's square format** created a distinctive visual language

These weren't limitations to overcome—they were features that defined the experience.

## My Design Process

When starting a new project, I now actively seek constraints:

1. **Time constraints** create urgency and focus
2. **Technical constraints** inspire creative solutions
3. **Brand constraints** ensure consistency and recognition

## The Freedom Within Limits

Paradoxically, working within constraints has made me more creative, not less. When you can't rely on infinite options, you're forced to think deeper, explore further, and find solutions that might never have emerged from unlimited freedom.

Next time you feel stuck, don't ask for more options. Ask for more constraints.`,
    excerpt: 'When faced with infinite possibilities, we often find ourselves paralyzed. This is where constraints become our unexpected allies.',
    authorId: 'user-3',
    authorName: 'Elena Rodriguez',
    authorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    coverImage: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=1200&h=600&fit=crop',
    createdAt: '2024-11-10',
    updatedAt: '2024-11-12',
    published: true,
    likes: ['user-1', 'user-2'],
    readTime: 4,
    tags: ['Design', 'Creativity', 'Process'],
    autoTags: ['Design', 'Opinion'],
    views: 89,
  },
  {
    id: 'post-3',
    title: 'The Future of Human-AI Collaboration',
    content: `# The Future of Human-AI Collaboration

We stand at a fascinating inflection point. Artificial intelligence is no longer a distant promise—it's here, reshaping how we work, create, and think. But the real story isn't about AI replacing humans. It's about how we'll work together.

## Beyond Automation

The first wave of AI focused on automation—doing what humans did, but faster. The next wave is different. It's about augmentation—making humans more capable, more creative, more effective.

## The New Creative Partnership

I've been experimenting with AI tools in my writing process. Here's what I've learned:

### What AI Does Well
- **Generating variations** and exploring possibilities
- **Identifying patterns** in data and text
- **Providing instant feedback** on drafts
- **Handling routine tasks** so I can focus on meaning

### What Humans Bring
- **Judgment and taste** about what matters
- **Emotional intelligence** and empathy
- **Context and nuance** that algorithms miss
- **The spark** that transforms good into great

## The Path Forward

The future belongs to those who learn to dance with AI—neither dismissing it nor depending on it entirely. It's a new skill, this human-AI collaboration, and we're all learning it together.

The question isn't whether AI will change how we work. It's whether we'll shape that change, or simply react to it.

I choose to shape it. Will you?`,
    excerpt: 'The real story isn\'t about AI replacing humans. It\'s about how we\'ll work together to create something neither could alone.',
    authorId: 'user-1',
    authorName: 'Sarah Chen',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face',
    coverImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1200&h=600&fit=crop',
    createdAt: '2024-11-05',
    updatedAt: '2024-11-05',
    published: true,
    likes: ['user-2'],
    readTime: 4,
    tags: ['AI', 'Future', 'Technology'],
    autoTags: ['Machine Learning', 'Opinion', 'Productivity'],
    views: 215,
  },
];

const DEFAULT_COMMENTS: Comment[] = [
  {
    id: 'comment-1',
    postId: 'post-1',
    authorId: 'user-1',
    authorName: 'Sarah Chen',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face',
    content: 'This resonates so much with my experience! The naming conventions tip alone has saved me hours of debugging.',
    createdAt: '2024-11-16',
  },
  {
    id: 'comment-2',
    postId: 'post-1',
    authorId: 'user-3',
    authorName: 'Elena Rodriguez',
    authorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    content: 'Great article! Would love to see a follow-up on refactoring legacy code.',
    createdAt: '2024-11-17',
  },
  {
    id: 'comment-3',
    postId: 'post-2',
    authorId: 'user-2',
    authorName: 'Marcus Webb',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    content: 'I apply this same principle to coding. Technical constraints often lead to the most elegant solutions.',
    createdAt: '2024-11-11',
  },
];

function calculateReadTime(content: string): number {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  return Math.ceil(wordCount / wordsPerMinute);
}

export function PostsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('blog_posts');
    return saved ? JSON.parse(saved) : DEFAULT_POSTS;
  });
  
  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem('blog_comments');
    return saved ? JSON.parse(saved) : DEFAULT_COMMENTS;
  });
  
  const [savedPosts, setSavedPosts] = useState<string[]>(() => {
    const saved = localStorage.getItem('blog_saved_posts');
    return saved ? JSON.parse(saved) : [];
  });

  const [savedTagGroups, setSavedTagGroups] = useState<SavedTagGroup[]>(() => {
    const saved = localStorage.getItem('blog_saved_tag_groups');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('blog_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('blog_comments', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('blog_saved_posts', JSON.stringify(savedPosts));
  }, [savedPosts]);

  useEffect(() => {
    localStorage.setItem('blog_saved_tag_groups', JSON.stringify(savedTagGroups));
  }, [savedTagGroups]);

  const createPost = (postData: Omit<Post, 'id' | 'authorId' | 'authorName' | 'authorAvatar' | 'createdAt' | 'updatedAt' | 'likes' | 'readTime' | 'views'>): Post | null => {
    if (!user) return null;
    
    const now = new Date().toISOString().split('T')[0];
    const newPost: Post = {
      ...postData,
      id: `post-${Date.now()}`,
      authorId: user.id,
      authorName: user.name,
      authorAvatar: user.avatar,
      createdAt: now,
      updatedAt: now,
      likes: [],
      readTime: calculateReadTime(postData.content),
      views: 0,
    };
    
    setPosts(prev => [newPost, ...prev]);
    return newPost;
  };

  const updatePost = (id: string, updates: Partial<Post>) => {
    setPosts(prev => prev.map(post => {
      if (post.id === id) {
        const updatedPost = {
          ...post,
          ...updates,
          updatedAt: new Date().toISOString().split('T')[0],
          readTime: updates.content ? calculateReadTime(updates.content) : post.readTime,
        };
        return updatedPost;
      }
      return post;
    }));
  };

  const deletePost = (id: string) => {
    setPosts(prev => prev.filter(post => post.id !== id));
    setComments(prev => prev.filter(comment => comment.postId !== id));
  };

  const likePost = (postId: string) => {
    if (!user) return;
    
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(user.id);
        return {
          ...post,
          likes: hasLiked 
            ? post.likes.filter(id => id !== user.id)
            : [...post.likes, user.id],
        };
      }
      return post;
    }));
  };

  const savePost = (postId: string) => {
    setSavedPosts(prev => {
      if (prev.includes(postId)) {
        return prev.filter(id => id !== postId);
      }
      return [...prev, postId];
    });
  };

  const incrementViews = (postId: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return { ...post, views: (post.views || 0) + 1 };
      }
      return post;
    }));
  };

  const addComment = (postId: string, content: string) => {
    if (!user) return;
    
    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      postId,
      authorId: user.id,
      authorName: user.name,
      authorAvatar: user.avatar,
      content,
      createdAt: new Date().toISOString().split('T')[0],
    };
    
    setComments(prev => [...prev, newComment]);
  };

  const deleteComment = (commentId: string) => {
    setComments(prev => prev.filter(comment => comment.id !== commentId));
  };

  const getPostById = (id: string) => posts.find(post => post.id === id);
  
  const getPostsByAuthor = (authorId: string) => posts.filter(post => post.authorId === authorId);
  
  const getPostComments = (postId: string) => comments.filter(comment => comment.postId === postId);

  const saveTagGroup = (name: string, customTags: string[], intelligentTags: string[]) => {
    const newGroup = createTagGroup(name, customTags, intelligentTags);
    setSavedTagGroups(prev => [...prev, newGroup]);
  };

  const deleteTagGroup = (groupId: string) => {
    setSavedTagGroups(prev => prev.filter(g => g.id !== groupId));
  };

  return (
    <PostsContext.Provider value={{
      posts,
      comments,
      savedPosts,
      savedTagGroups,
      createPost,
      updatePost,
      deletePost,
      likePost,
      savePost,
      incrementViews,
      addComment,
      deleteComment,
      getPostById,
      getPostsByAuthor,
      getPostComments,
      saveTagGroup,
      deleteTagGroup,
    }}>
      {children}
    </PostsContext.Provider>
  );
}

export function usePosts() {
  const context = useContext(PostsContext);
  if (context === undefined) {
    throw new Error('usePosts must be used within a PostsProvider');
  }
  return context;
}
