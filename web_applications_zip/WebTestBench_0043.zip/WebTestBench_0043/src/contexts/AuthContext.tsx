import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  bio: string;
  avatar: string;
  joinedAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEFAULT_USERS: (User & { password: string })[] = [
  {
    id: 'user-1',
    name: 'Sarah Chen',
    email: 'sarah@example.com',
    password: 'password123',
    bio: 'Writer, thinker, coffee enthusiast. I explore ideas at the intersection of technology and humanity.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face',
    joinedAt: '2024-01-15',
  },
  {
    id: 'user-2',
    name: 'Marcus Webb',
    email: 'marcus@example.com',
    password: 'password123',
    bio: 'Software engineer by day, storyteller by night. Building things that matter.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    joinedAt: '2024-02-20',
  },
  {
    id: 'user-3',
    name: 'Elena Rodriguez',
    email: 'elena@example.com',
    password: 'password123',
    bio: 'Designer and visual thinker. Creating experiences that inspire and delight.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    joinedAt: '2024-03-10',
  },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<(User & { password: string })[]>(() => {
    const saved = localStorage.getItem('blog_users');
    return saved ? JSON.parse(saved) : DEFAULT_USERS;
  });

  useEffect(() => {
    const savedUser = localStorage.getItem('blog_current_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('blog_users', JSON.stringify(users));
  }, [users]);

  const login = (email: string, password: string): boolean => {
    const foundUser = users.find(u => u.email === email && u.password === password);
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('blog_current_user', JSON.stringify(userWithoutPassword));
      return true;
    }
    return false;
  };

  const signup = (name: string, email: string, password: string): boolean => {
    if (users.some(u => u.email === email)) {
      return false;
    }
    
    const newUser: User & { password: string } = {
      id: `user-${Date.now()}`,
      name,
      email,
      password,
      bio: 'Hello! I just joined this amazing community.',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
      joinedAt: new Date().toISOString().split('T')[0],
    };
    
    setUsers(prev => [...prev, newUser]);
    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    localStorage.setItem('blog_current_user', JSON.stringify(userWithoutPassword));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('blog_current_user');
  };

  const updateProfile = (updates: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    localStorage.setItem('blog_current_user', JSON.stringify(updatedUser));
    
    setUsers(prev => prev.map(u => 
      u.id === user.id ? { ...u, ...updates } : u
    ));
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      login, 
      signup, 
      logout, 
      updateProfile 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function useUsers() {
  const saved = localStorage.getItem('blog_users');
  const users: User[] = saved ? JSON.parse(saved) : DEFAULT_USERS;
  return users.map(({ password, ...user }: any) => user as User);
}
