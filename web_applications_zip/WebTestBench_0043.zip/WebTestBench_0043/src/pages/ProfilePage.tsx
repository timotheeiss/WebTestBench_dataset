import { useParams, Link } from 'react-router-dom';
import { useAuth, useUsers } from '@/contexts/AuthContext';
import { usePosts } from '@/contexts/PostsContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PostCard from '@/components/PostCard';
import TagAnalytics from '@/components/TagAnalytics';
import { Calendar, FileText, PenLine } from 'lucide-react';

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();
  const users = useUsers();
  const { getPostsByAuthor, comments } = usePosts();
  
  const profileUser = users.find(u => u.id === id);
  const isOwnProfile = currentUser?.id === id;
  
  if (!profileUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-bold text-foreground mb-4">User not found</h1>
          <Button asChild>
            <Link to="/">Go Home</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  const userPosts = getPostsByAuthor(profileUser.id);
  const publishedPosts = userPosts.filter(p => p.published);
  const draftPosts = userPosts.filter(p => !p.published);

  return (
    <div className="min-h-screen">
      {/* Profile Header */}
      <section className="bg-gradient-to-b from-secondary/50 to-background py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <Avatar className="h-28 w-28 mx-auto mb-6 ring-4 ring-background shadow-elevated">
              <AvatarImage src={profileUser.avatar} alt={profileUser.name} />
              <AvatarFallback className="text-3xl font-serif">
                {profileUser.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            
            <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-3">
              {profileUser.name}
            </h1>
            
            <p className="text-muted-foreground text-lg max-w-xl mx-auto mb-6">
              {profileUser.bio}
            </p>
            
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                Joined {profileUser.joinedAt}
              </div>
              <div className="flex items-center gap-1.5">
                <FileText className="h-4 w-4" />
                {publishedPosts.length} {publishedPosts.length === 1 ? 'post' : 'posts'}
              </div>
            </div>
            
            {isOwnProfile && (
              <div className="mt-8">
                <Button asChild className="gap-2">
                  <Link to="/write">
                    <PenLine className="h-4 w-4" />
                    Write New Post
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Posts Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {isOwnProfile ? (
            <Tabs defaultValue="published" className="w-full">
              <TabsList className="mb-8">
                <TabsTrigger value="published" className="gap-2">
                  Published ({publishedPosts.length})
                </TabsTrigger>
                <TabsTrigger value="drafts" className="gap-2">
                  Drafts ({draftPosts.length})
                </TabsTrigger>
                <TabsTrigger value="analytics" className="gap-2">
                  Analytics
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="published">
                {publishedPosts.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-6">
                    {publishedPosts.map((post, index) => (
                      <div key={post.id} style={{ animationDelay: `${0.1 * index}s` }}>
                        <PostCard post={post} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState 
                    message="No published posts yet" 
                    action={
                      <Button asChild>
                        <Link to="/write">Write your first post</Link>
                      </Button>
                    }
                  />
                )}
              </TabsContent>
              
              <TabsContent value="drafts">
                {draftPosts.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-6">
                    {draftPosts.map((post, index) => (
                      <div key={post.id} style={{ animationDelay: `${0.1 * index}s` }}>
                        <PostCard post={post} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState message="No drafts" />
                )}
              </TabsContent>
              
              <TabsContent value="analytics">
                <TagAnalytics posts={userPosts} comments={comments.filter(c => userPosts.some(p => p.id === c.postId))} />
              </TabsContent>
            </Tabs>
          ) : (
            <>
              <h2 className="font-serif text-2xl font-bold text-foreground mb-8">
                Posts by {profileUser.name}
              </h2>
              {publishedPosts.length > 0 ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {publishedPosts.map((post, index) => (
                    <div key={post.id} style={{ animationDelay: `${0.1 * index}s` }}>
                      <PostCard post={post} />
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState message="No posts yet" />
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}

function EmptyState({ message, action }: { message: string; action?: React.ReactNode }) {
  return (
    <div className="text-center py-16 bg-secondary/30 rounded-2xl">
      <p className="text-muted-foreground text-lg mb-4">{message}</p>
      {action}
    </div>
  );
}
