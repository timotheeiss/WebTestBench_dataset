import { useParams, Link, useNavigate } from 'react-router-dom';
import { usePosts } from '@/contexts/PostsContext';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import CommentSection from '@/components/CommentSection';
import { 
  Heart, 
  Clock, 
  BookmarkPlus, 
  BookmarkCheck, 
  Edit2, 
  Trash2,
  ArrowLeft,
  Share2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function PostPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getPostById, likePost, savePost, savedPosts, deletePost } = usePosts();
  const { user, isAuthenticated } = useAuth();
  
  const post = getPostById(id || '');
  
  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-bold text-foreground mb-4">Post not found</h1>
          <Button asChild>
            <Link to="/">Go Home</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  const hasLiked = user ? post.likes.includes(user.id) : false;
  const hasSaved = savedPosts.includes(post.id);
  const isAuthor = user?.id === post.authorId;

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "The post link has been copied to your clipboard.",
      });
    } catch {
      toast({
        title: "Share",
        description: "Copy this URL to share: " + window.location.href,
      });
    }
  };

  const handleDelete = () => {
    deletePost(post.id);
    toast({
      title: "Post deleted",
      description: "Your post has been permanently deleted.",
    });
    navigate('/');
  };

  return (
    <article className="min-h-screen pb-20">
      {/* Back Button */}
      <div className="container mx-auto px-4 py-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate(-1)}
          className="gap-2 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
      </div>

      {/* Cover Image */}
      {post.coverImage && (
        <div className="w-full aspect-[21/9] max-h-[480px] overflow-hidden mb-10">
          <img 
            src={post.coverImage} 
            alt={post.title}
            className="w-full h-full object-cover animate-fade-in"
          />
        </div>
      )}

      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <header className="mb-10 animate-fade-in">
            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags.map(tag => (
                <Badge key={tag} variant="secondary" className="text-sm">
                  {tag}
                </Badge>
              ))}
            </div>

            {/* Title */}
            <h1 className="font-serif text-3xl md:text-5xl font-bold text-foreground leading-tight mb-6">
              {post.title}
            </h1>

            {/* Author Info */}
            <div className="flex items-center justify-between flex-wrap gap-4">
              <Link 
                to={`/profile/${post.authorId}`}
                className="flex items-center gap-4 group"
              >
                <Avatar className="h-12 w-12 ring-2 ring-transparent group-hover:ring-primary/20 transition-smooth">
                  <AvatarImage src={post.authorAvatar} alt={post.authorName} />
                  <AvatarFallback>{post.authorName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-foreground group-hover:text-primary transition-smooth">
                    {post.authorName}
                  </p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{post.createdAt}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {post.readTime} min read
                    </span>
                  </div>
                </div>
              </Link>

              {/* Actions */}
              <div className="flex items-center gap-2">
                {isAuthenticated && (
                  <>
                    <button 
                      onClick={() => likePost(post.id)}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-smooth",
                        hasLiked 
                          ? "bg-primary/10 text-primary" 
                          : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                      )}
                    >
                      <Heart className={cn("h-4 w-4", hasLiked && "fill-current animate-heart-beat")} />
                      {post.likes.length}
                    </button>
                    <button 
                      onClick={() => savePost(post.id)}
                      className={cn(
                        "p-2.5 rounded-full transition-smooth",
                        hasSaved 
                          ? "bg-accent/10 text-accent" 
                          : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                      )}
                      title={hasSaved ? "Unsave" : "Save"}
                    >
                      {hasSaved ? (
                        <BookmarkCheck className="h-5 w-5" />
                      ) : (
                        <BookmarkPlus className="h-5 w-5" />
                      )}
                    </button>
                  </>
                )}
                <button 
                  onClick={handleShare}
                  className="p-2.5 rounded-full bg-secondary text-muted-foreground hover:bg-secondary/80 transition-smooth"
                  title="Share"
                >
                  <Share2 className="h-5 w-5" />
                </button>
                
                {isAuthor && (
                  <>
                    <Button 
                      variant="outline" 
                      size="icon"
                      asChild
                      className="h-10 w-10 rounded-full"
                    >
                      <Link to={`/edit/${post.id}`}>
                        <Edit2 className="h-4 w-4" />
                      </Link>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="icon"
                          className="h-10 w-10 rounded-full text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete this post?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete your post
                            and remove all associated comments.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={handleDelete}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </>
                )}
              </div>
            </div>
          </header>

          {/* Content */}
          <div className="prose-blog animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {post.content}
            </ReactMarkdown>
          </div>

          {/* Comments */}
          <CommentSection postId={post.id} />
        </div>
      </div>
    </article>
  );
}
