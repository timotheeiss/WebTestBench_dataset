import { useState, useMemo } from 'react';
import { usePosts } from '@/contexts/PostsContext';
import PostCard from '@/components/PostCard';
import TagFilter from '@/components/TagFilter';
import { getAllAvailableTags, SavedTagGroup } from '@/lib/tagUtils';
import { Sparkles } from 'lucide-react';

const Index = () => {
  const { posts, savedTagGroups, saveTagGroup, deleteTagGroup } = usePosts();
  
  const [selectedCustomTags, setSelectedCustomTags] = useState<string[]>([]);
  const [selectedIntelligentTags, setSelectedIntelligentTags] = useState<string[]>([]);
  
  const publishedPosts = posts.filter(post => post.published);
  
  const { customTags, intelligentTags } = useMemo(() => 
    getAllAvailableTags(publishedPosts), [publishedPosts]
  );

  const filteredPosts = useMemo(() => {
    if (selectedCustomTags.length === 0 && selectedIntelligentTags.length === 0) {
      return publishedPosts;
    }
    
    return publishedPosts.filter(post => {
      const matchesCustom = selectedCustomTags.length === 0 || 
        selectedCustomTags.every(tag => post.tags.includes(tag));
      const matchesIntelligent = selectedIntelligentTags.length === 0 || 
        selectedIntelligentTags.every(tag => post.autoTags?.includes(tag));
      return matchesCustom && matchesIntelligent;
    });
  }, [publishedPosts, selectedCustomTags, selectedIntelligentTags]);
  
  const [featuredPost, ...otherPosts] = filteredPosts;

  const handleSaveTagGroup = (name: string) => {
    saveTagGroup(name, selectedCustomTags, selectedIntelligentTags);
  };

  const handleLoadTagGroup = (group: SavedTagGroup) => {
    setSelectedCustomTags(group.customTags);
    setSelectedIntelligentTags(group.intelligentTags);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-28">
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 to-background" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-3xl mx-auto text-center animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Sparkles className="h-4 w-4" />
              Where ideas take flight
            </div>
            <h1 className="font-serif text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
              Stories that inspire,
              <br />
              <span className="text-gradient">ideas that matter</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover thoughtful articles from creators who care about craft. 
              Share your perspective with readers who appreciate depth.
            </p>
          </div>
        </div>
      </section>

      {/* Tag Filter */}
      <section className="container mx-auto px-4 mb-8">
        <TagFilter
          availableCustomTags={customTags}
          availableIntelligentTags={intelligentTags}
          selectedCustomTags={selectedCustomTags}
          selectedIntelligentTags={selectedIntelligentTags}
          onCustomTagsChange={setSelectedCustomTags}
          onIntelligentTagsChange={setSelectedIntelligentTags}
          savedTagGroups={savedTagGroups}
          onSaveTagGroup={handleSaveTagGroup}
          onLoadTagGroup={handleLoadTagGroup}
          onDeleteTagGroup={deleteTagGroup}
        />
      </section>

      {/* Featured Post */}
      {featuredPost && (
        <section className="container mx-auto px-4 mb-16">
          <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <PostCard post={featuredPost} featured />
          </div>
        </section>
      )}

      {/* Posts Grid */}
      <section className="container mx-auto px-4 pb-20">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">
            {selectedCustomTags.length > 0 || selectedIntelligentTags.length > 0 
              ? `Filtered Stories (${filteredPosts.length})`
              : 'Latest Stories'}
          </h2>
          <div className="h-px flex-1 bg-border ml-6" />
        </div>
        
        {otherPosts.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {otherPosts.map((post, index) => (
              <div 
                key={post.id}
                style={{ animationDelay: `${0.1 * (index + 1)}s` }}
              >
                <PostCard post={post} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-secondary/30 rounded-2xl">
            <p className="text-muted-foreground text-lg">
              {selectedCustomTags.length > 0 || selectedIntelligentTags.length > 0 
                ? 'No posts match the selected tags.'
                : 'No more stories yet. Be the first to share yours!'}
            </p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Index;
