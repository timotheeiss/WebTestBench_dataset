import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePosts } from '@/contexts/PostsContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import MarkdownEditor from '@/components/MarkdownEditor';
import TagInput from '@/components/TagInput';
import { toast } from '@/hooks/use-toast';
import { ArrowLeft, Save, ImagePlus, X } from 'lucide-react';

export default function EditPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { getPostById, updatePost } = usePosts();
  
  const post = getPostById(id || '');
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [customTags, setCustomTags] = useState<string[]>([]);
  const [autoTags, setAutoTags] = useState<string[]>([]);
  const [published, setPublished] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (post) {
      setTitle(post.title);
      setContent(post.content);
      setExcerpt(post.excerpt);
      setCoverImage(post.coverImage || '');
      setCustomTags(post.tags);
      setAutoTags(post.autoTags || []);
      setPublished(post.published);
    }
  }, [post]);

  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-bold text-foreground mb-4">Post not found</h1>
          <Button onClick={() => navigate('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  if (post.authorId !== user?.id) {
    navigate(`/post/${post.id}`);
    return null;
  }

  const handleSubmit = () => {
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please add a title for your post.",
        variant: "destructive",
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please write some content for your post.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    updatePost(post.id, {
      title: title.trim(),
      content: content.trim(),
      excerpt: excerpt.trim() || content.trim().slice(0, 150) + '...',
      coverImage: coverImage.trim() || undefined,
      published,
      tags: customTags,
      autoTags,
    });

    toast({
      title: "Post updated!",
      description: "Your changes have been saved.",
    });
    
    navigate(`/post/${post.id}`);
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen py-8 md:py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate(-1)}
              className="gap-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={published}
                  onChange={(e) => setPublished(e.target.checked)}
                  className="rounded"
                />
                Published
              </label>
              <Button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="gap-2"
              >
                <Save className="h-4 w-4" />
                Save Changes
              </Button>
            </div>
          </div>

          {/* Form */}
          <div className="space-y-6 animate-fade-in">
            {/* Title */}
            <div>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Your story title..."
                className="text-3xl md:text-4xl font-serif font-bold border-0 px-0 h-auto py-2 focus-visible:ring-0 placeholder:text-muted-foreground/50"
              />
            </div>

            {/* Cover Image */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Cover Image URL (optional)</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <ImagePlus className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={coverImage}
                    onChange={(e) => setCoverImage(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="pl-10"
                  />
                </div>
                {coverImage && (
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setCoverImage('')}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              {coverImage && (
                <div className="mt-3 rounded-lg overflow-hidden aspect-video bg-muted">
                  <img 
                    src={coverImage} 
                    alt="Cover preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              )}
            </div>

            {/* Excerpt */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Short excerpt (optional)</Label>
              <Input
                value={excerpt}
                onChange={(e) => setExcerpt(e.target.value)}
                placeholder="A brief description of your story..."
                maxLength={200}
              />
              <p className="text-xs text-muted-foreground">{excerpt.length}/200</p>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Tags</Label>
              <TagInput
                customTags={customTags}
                onCustomTagsChange={setCustomTags}
                autoTags={autoTags}
                onAutoTagsChange={setAutoTags}
                content={content}
                title={title}
              />
            </div>

            {/* Content */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Content</Label>
              <MarkdownEditor
                value={content}
                onChange={setContent}
                placeholder="Tell your story... (Markdown supported)"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
