import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePosts } from '@/contexts/PostsContext';
import { Button } from '@/components/ui/button';
import PostCard from '@/components/PostCard';
import { Bookmark, ArrowLeft } from 'lucide-react';
import { useEffect } from 'react';

export default function SavedPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { posts, savedPosts } = usePosts();
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }
  
  const savedPostsList = posts.filter(post => savedPosts.includes(post.id));

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-gradient-to-b from-secondary/50 to-background py-12 md:py-16">
        <div className="container mx-auto px-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate(-1)}
            className="gap-2 text-muted-foreground hover:text-foreground mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          
          <div className="flex items-center gap-4 animate-fade-in">
            <div className="p-3 rounded-full bg-accent/10">
              <Bookmark className="h-6 w-6 text-accent" />
            </div>
            <div>
              <h1 className="font-serif text-3xl font-bold text-foreground">
                Saved Posts
              </h1>
              <p className="text-muted-foreground">
                {savedPostsList.length} {savedPostsList.length === 1 ? 'post' : 'posts'} saved for later
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Saved Posts Grid */}
      <section className="container mx-auto px-4 py-12">
        {savedPostsList.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedPostsList.map((post, index) => (
              <div key={post.id} style={{ animationDelay: `${0.1 * index}s` }}>
                <PostCard post={post} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-secondary/30 rounded-2xl">
            <Bookmark className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="font-serif text-2xl font-bold text-foreground mb-2">
              No saved posts yet
            </h2>
            <p className="text-muted-foreground mb-6">
              When you find stories you love, save them here for easy access.
            </p>
            <Button asChild>
              <Link to="/">Explore Stories</Link>
            </Button>
          </div>
        )}
      </section>
    </div>
  );
}
