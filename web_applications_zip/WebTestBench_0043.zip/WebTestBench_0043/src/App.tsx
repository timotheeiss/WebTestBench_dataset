import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { PostsProvider } from "@/contexts/PostsContext";
import Layout from "@/components/Layout";
import Index from "./pages/Index";
import PostPage from "./pages/PostPage";
import WritePage from "./pages/WritePage";
import EditPage from "./pages/EditPage";
import ProfilePage from "./pages/ProfilePage";
import SavedPage from "./pages/SavedPage";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <PostsProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/" element={<Layout><Index /></Layout>} />
              <Route path="/post/:id" element={<Layout><PostPage /></Layout>} />
              <Route path="/write" element={<Layout><WritePage /></Layout>} />
              <Route path="/edit/:id" element={<Layout><EditPage /></Layout>} />
              <Route path="/profile/:id" element={<Layout><ProfilePage /></Layout>} />
              <Route path="/saved" element={<Layout><SavedPage /></Layout>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </PostsProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
