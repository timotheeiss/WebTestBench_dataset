// Intelligent tag extraction from content

const TECH_KEYWORDS: Record<string, string[]> = {
  'Python': ['python', 'django', 'flask', 'pandas', 'numpy', 'pytorch'],
  'JavaScript': ['javascript', 'js', 'node', 'nodejs', 'npm', 'yarn'],
  'TypeScript': ['typescript', 'ts', '.tsx', '.ts'],
  'React': ['react', 'jsx', 'usestate', 'useeffect', 'hooks'],
  'Vue': ['vue', 'vuejs', 'vuex', 'nuxt'],
  'Angular': ['angular', 'ng-', 'rxjs'],
  'Frontend Development': ['css', 'html', 'dom', 'responsive', 'tailwind', 'sass', 'scss'],
  'Backend Development': ['api', 'rest', 'graphql', 'database', 'server', 'express', 'fastapi'],
  'Machine Learning': ['ml', 'machine learning', 'tensorflow', 'keras', 'neural', 'ai model'],
  'Data Science': ['data analysis', 'visualization', 'statistics', 'dataset', 'jupyter'],
  'DevOps': ['docker', 'kubernetes', 'ci/cd', 'pipeline', 'deployment', 'aws', 'cloud'],
  'Git': ['git', 'github', 'version control', 'commit', 'branch', 'merge'],
  'SQL': ['sql', 'database', 'query', 'mysql', 'postgresql', 'mongodb'],
  'Testing': ['test', 'unit test', 'jest', 'cypress', 'testing'],
};

const TOPIC_KEYWORDS: Record<string, string[]> = {
  'Tutorial': ['how to', 'step by step', 'guide', 'tutorial', 'learn', 'beginner'],
  'Best Practices': ['best practice', 'clean code', 'pattern', 'principle', 'architecture'],
  'Review': ['review', 'comparison', 'vs', 'versus', 'pros and cons'],
  'Opinion': ['think', 'believe', 'opinion', 'perspective', 'my view'],
  'Career': ['career', 'job', 'interview', 'hiring', 'salary', 'resume'],
  'Productivity': ['productivity', 'efficient', 'workflow', 'tools', 'tips'],
  'Design': ['design', 'ui', 'ux', 'user experience', 'interface', 'aesthetic'],
  'Life': ['life', 'personal', 'journey', 'experience', 'story', 'reflection'],
  'Reading Notes': ['reading', 'book', 'notes', 'summary', 'learned from'],
  'Project': ['project', 'built', 'created', 'developed', 'showcase'],
};

export function extractIntelligentTags(content: string, title: string): string[] {
  const combinedText = `${title} ${content}`.toLowerCase();
  const extractedTags: Set<string> = new Set();

  // Check for tech keywords
  Object.entries(TECH_KEYWORDS).forEach(([tag, keywords]) => {
    if (keywords.some(kw => combinedText.includes(kw))) {
      extractedTags.add(tag);
    }
  });

  // Check for topic keywords
  Object.entries(TOPIC_KEYWORDS).forEach(([tag, keywords]) => {
    if (keywords.some(kw => combinedText.includes(kw))) {
      extractedTags.add(tag);
    }
  });

  // Check for code blocks (indicates programming content)
  if (content.includes('```')) {
    extractedTags.add('Code Examples');
  }

  // Limit to top 5 intelligent tags
  return Array.from(extractedTags).slice(0, 5);
}

export function getAllAvailableTags(posts: Array<{ tags: string[]; autoTags?: string[] }>): {
  customTags: string[];
  intelligentTags: string[];
} {
  const customTags = new Set<string>();
  const intelligentTags = new Set<string>();

  posts.forEach(post => {
    post.tags.forEach(tag => customTags.add(tag));
    post.autoTags?.forEach(tag => intelligentTags.add(tag));
  });

  return {
    customTags: Array.from(customTags).sort(),
    intelligentTags: Array.from(intelligentTags).sort(),
  };
}

export interface SavedTagGroup {
  id: string;
  name: string;
  customTags: string[];
  intelligentTags: string[];
  createdAt: string;
}

export function createTagGroup(
  name: string,
  customTags: string[],
  intelligentTags: string[]
): SavedTagGroup {
  return {
    id: `tag-group-${Date.now()}`,
    name,
    customTags,
    intelligentTags,
    createdAt: new Date().toISOString(),
  };
}
