import { useFitness } from '@/context/FitnessContext';
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { Activity, Clock, Flame, Route } from 'lucide-react';

export function SummaryCards() {
  const { workouts } = useFitness();
  
  const now = new Date();
  const weekStart = startOfWeek(now, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(now, { weekStartsOn: 1 });
  const monthStart = startOfMonth(now);
  const monthEnd = endOfMonth(now);

  const weekWorkouts = workouts.filter((w) => 
    isWithinInterval(new Date(w.date), { start: weekStart, end: weekEnd })
  );

  const monthWorkouts = workouts.filter((w) => 
    isWithinInterval(new Date(w.date), { start: monthStart, end: monthEnd })
  );

  const weekStats = {
    workouts: weekWorkouts.length,
    duration: weekWorkouts.reduce((sum, w) => sum + w.duration, 0),
    distance: weekWorkouts.reduce((sum, w) => sum + (w.distance || 0), 0),
  };

  const monthStats = {
    workouts: monthWorkouts.length,
    duration: monthWorkouts.reduce((sum, w) => sum + w.duration, 0),
    distance: monthWorkouts.reduce((sum, w) => sum + (w.distance || 0), 0),
  };

  const summaryItems = [
    {
      label: 'This Week',
      value: weekStats.workouts,
      unit: 'workouts',
      icon: Activity,
      gradient: true,
    },
    {
      label: 'Week Duration',
      value: weekStats.duration,
      unit: 'minutes',
      icon: Clock,
    },
    {
      label: 'This Month',
      value: monthStats.workouts,
      unit: 'workouts',
      icon: Flame,
    },
    {
      label: 'Total Distance',
      value: monthStats.distance.toFixed(1),
      unit: 'km this month',
      icon: Route,
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {summaryItems.map((item, index) => (
        <div
          key={item.label}
          className={`relative overflow-hidden rounded-xl p-4 border transition-all duration-300 hover:scale-[1.02] ${
            item.gradient 
              ? 'bg-gradient-energy text-primary-foreground border-transparent shadow-glow' 
              : 'bg-card border-border shadow-card'
          }`}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="flex items-start justify-between">
            <div>
              <p className={`text-sm font-medium ${item.gradient ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>
                {item.label}
              </p>
              <p className="text-3xl font-display tracking-wide mt-1">
                {item.value}
              </p>
              <p className={`text-sm ${item.gradient ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                {item.unit}
              </p>
            </div>
            <div className={`p-2 rounded-lg ${item.gradient ? 'bg-primary-foreground/20' : 'bg-secondary'}`}>
              <item.icon className={`w-5 h-5 ${item.gradient ? 'text-primary-foreground' : 'text-primary'}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
