import { useFitness } from '@/context/FitnessContext';
import { Header } from './Header';
import { SummaryCards } from './SummaryCards';
import { WorkoutCard } from './WorkoutCard';
import { GoalCard } from './GoalCard';
import { AddWorkoutDialog } from './AddWorkoutDialog';
import { AddGoalDialog } from './AddGoalDialog';
import { Dumbbell, Target } from 'lucide-react';

export function Dashboard() {
  const { workouts, goals } = useFitness();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Summary Section */}
        <section className="animate-slide-up">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-3xl tracking-wide text-foreground">
              Your <span className="text-gradient-energy">Stats</span>
            </h2>
            <AddWorkoutDialog />
          </div>
          <SummaryCards />
        </section>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Workouts Timeline */}
          <section className="lg:col-span-2 animate-slide-up" style={{ animationDelay: '100ms' }}>
            <div className="flex items-center gap-2 mb-4">
              <Dumbbell className="w-5 h-5 text-primary" />
              <h2 className="font-display text-2xl tracking-wide text-foreground">Recent Workouts</h2>
            </div>
            
            {workouts.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary flex items-center justify-center">
                  <Dumbbell className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">No workouts yet</h3>
                <p className="text-muted-foreground mb-4">
                  Log your first workout to start tracking your progress!
                </p>
                <AddWorkoutDialog />
              </div>
            ) : (
              <div className="space-y-3">
                {workouts.slice(0, 10).map((workout) => (
                  <WorkoutCard key={workout.id} workout={workout} />
                ))}
              </div>
            )}
          </section>

          {/* Goals Section */}
          <section className="animate-slide-up" style={{ animationDelay: '200ms' }}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                <h2 className="font-display text-2xl tracking-wide text-foreground">Goals</h2>
              </div>
              <AddGoalDialog />
            </div>
            
            {goals.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-secondary flex items-center justify-center">
                  <Target className="w-6 h-6 text-muted-foreground" />
                </div>
                <h3 className="font-semibold text-foreground mb-1">No goals yet</h3>
                <p className="text-sm text-muted-foreground">
                  Set a goal to stay motivated!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {goals.map((goal) => (
                  <GoalCard key={goal.id} goal={goal} />
                ))}
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
