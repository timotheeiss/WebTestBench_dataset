import { Goal } from '@/types/fitness';
import { useFitness } from '@/context/FitnessContext';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Target, Trash2 } from 'lucide-react';
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';

interface GoalCardProps {
  goal: Goal;
}

export function GoalCard({ goal }: GoalCardProps) {
  const { workouts, deleteGoal } = useFitness();
  
  const now = new Date();
  const periodStart = goal.period === 'week' 
    ? startOfWeek(now, { weekStartsOn: 1 }) 
    : startOfMonth(now);
  const periodEnd = goal.period === 'week' 
    ? endOfWeek(now, { weekStartsOn: 1 }) 
    : endOfMonth(now);

  const periodWorkouts = workouts.filter((w) => {
    const workoutDate = new Date(w.date);
    const inPeriod = isWithinInterval(workoutDate, { start: periodStart, end: periodEnd });
    if (!inPeriod) return false;
    if (goal.exerciseType) {
      return w.exerciseType === goal.exerciseType;
    }
    return true;
  });

  let currentValue = 0;
  if (goal.type === 'frequency') {
    currentValue = periodWorkouts.length;
  } else if (goal.type === 'duration') {
    currentValue = periodWorkouts.reduce((sum, w) => sum + w.duration, 0);
  }

  const progress = Math.min((currentValue / goal.targetValue) * 100, 100);
  const isComplete = currentValue >= goal.targetValue;

  return (
    <div className="group relative bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all duration-300 shadow-card">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${isComplete ? 'bg-gradient-energy text-primary-foreground' : 'bg-secondary text-muted-foreground'}`}>
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{goal.description}</h3>
            <p className="text-sm text-muted-foreground capitalize">
              {goal.period}ly goal
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          onClick={() => deleteGoal(goal.id)}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Progress</span>
          <span className={isComplete ? 'text-primary font-semibold' : 'text-foreground'}>
            {currentValue} / {goal.targetValue} {goal.type === 'duration' ? 'min' : 'times'}
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {isComplete && (
        <div className="mt-3 text-center">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
            🎉 Goal achieved!
          </span>
        </div>
      )}
    </div>
  );
}
