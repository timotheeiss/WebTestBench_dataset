import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { useFitness } from '@/context/FitnessContext';
import { useAuth } from '@/context/AuthContext';
import { ExerciseType, GoalType, GoalPeriod } from '@/types/fitness';
import { exerciseTypeLabels } from '@/data/mockData';
import { toast } from 'sonner';

export function AddGoalDialog() {
  const [open, setOpen] = useState(false);
  const [goalType, setGoalType] = useState<GoalType>('frequency');
  const [exerciseType, setExerciseType] = useState<ExerciseType | 'any'>('any');
  const [targetValue, setTargetValue] = useState('');
  const [period, setPeriod] = useState<GoalPeriod>('week');
  
  const { addGoal } = useFitness();
  const { user } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!targetValue || parseInt(targetValue) <= 0) {
      toast.error('Please enter a valid target');
      return;
    }

    const exerciseLabel = exerciseType === 'any' ? '' : ` ${exerciseTypeLabels[exerciseType].toLowerCase()}`;
    const unit = goalType === 'duration' ? 'minutes' : 'times';
    const description = goalType === 'duration'
      ? `Exercise${exerciseLabel} ${targetValue} ${unit} per ${period}`
      : `${exerciseTypeLabels[exerciseType] || 'Exercise'} ${targetValue} ${unit} per ${period}`;

    addGoal({
      userId: user?.id || 'user-1',
      type: goalType,
      exerciseType: exerciseType === 'any' ? undefined : exerciseType,
      targetValue: parseInt(targetValue),
      period,
      description,
    });

    toast.success('Goal created!');
    setOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setGoalType('frequency');
    setExerciseType('any');
    setTargetValue('');
    setPeriod('week');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Plus className="w-4 h-4" />
          Add Goal
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl tracking-wide">New Goal</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label>Goal Type</Label>
            <Select value={goalType} onValueChange={(v) => setGoalType(v as GoalType)}>
              <SelectTrigger className="bg-secondary border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="frequency">Frequency (times per period)</SelectItem>
                <SelectItem value="duration">Duration (minutes per period)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Exercise Type</Label>
            <Select value={exerciseType} onValueChange={(v) => setExerciseType(v as ExerciseType | 'any')}>
              <SelectTrigger className="bg-secondary border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any exercise</SelectItem>
                {Object.entries(exerciseTypeLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Target</Label>
              <Input
                type="number"
                min="1"
                placeholder={goalType === 'duration' ? '150' : '3'}
                value={targetValue}
                onChange={(e) => setTargetValue(e.target.value)}
                className="bg-secondary border-border"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Period</Label>
              <Select value={period} onValueChange={(v) => setPeriod(v as GoalPeriod)}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Week</SelectItem>
                  <SelectItem value="month">Month</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Create Goal
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
