import { Workout } from '@/types/fitness';
import { exerciseTypeLabels, intensityLabels } from '@/data/mockData';
import { format, isToday, isYesterday } from 'date-fns';
import { 
  Activity, 
  Bike, 
  Dumbbell, 
  Heart, 
  Timer, 
  Route, 
  Trash2,
  Waves,
  Footprints,
  Flame,
  MoreHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFitness } from '@/context/FitnessContext';

const exerciseIcons: Record<string, React.ReactNode> = {
  running: <Footprints className="w-5 h-5" />,
  cycling: <Bike className="w-5 h-5" />,
  swimming: <Waves className="w-5 h-5" />,
  weight_training: <Dumbbell className="w-5 h-5" />,
  yoga: <Heart className="w-5 h-5" />,
  hiit: <Flame className="w-5 h-5" />,
  walking: <Footprints className="w-5 h-5" />,
  other: <Activity className="w-5 h-5" />,
};

const intensityColors: Record<string, string> = {
  low: 'bg-chart-2/20 text-chart-2',
  moderate: 'bg-chart-3/20 text-chart-3',
  high: 'bg-chart-4/20 text-chart-4',
  max: 'bg-destructive/20 text-destructive',
};

function formatWorkoutDate(dateString: string): string {
  const date = new Date(dateString);
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  return format(date, 'MMM d');
}

interface WorkoutCardProps {
  workout: Workout;
}

export function WorkoutCard({ workout }: WorkoutCardProps) {
  const { deleteWorkout } = useFitness();

  return (
    <div className="group relative bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all duration-300 shadow-card animate-fade-in">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-energy flex items-center justify-center text-primary-foreground shrink-0">
          {exerciseIcons[workout.exerciseType]}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <h3 className="font-semibold text-foreground truncate">
              {exerciseTypeLabels[workout.exerciseType]}
            </h3>
            <span className="text-sm text-muted-foreground shrink-0">
              {formatWorkoutDate(workout.date)}
            </span>
          </div>
          
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${intensityColors[workout.intensity]}`}>
              {intensityLabels[workout.intensity]}
            </span>
            <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
              <Timer className="w-3.5 h-3.5" />
              {workout.duration} min
            </span>
            {workout.distance && (
              <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
                <Route className="w-3.5 h-3.5" />
                {workout.distance} km
              </span>
            )}
          </div>
          
          {workout.notes && (
            <p className="text-sm text-muted-foreground line-clamp-2">
              {workout.notes}
            </p>
          )}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          onClick={() => deleteWorkout(workout.id)}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
