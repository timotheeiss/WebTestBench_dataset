import { AuthProvider, useAuth } from '@/context/AuthContext';
import { FitnessProvider } from '@/context/FitnessContext';
import { LoginForm } from '@/components/LoginForm';
import { Dashboard } from '@/components/Dashboard';

function AppContent() {
  const { isAuthenticated } = useAuth();

  return isAuthenticated ? (
    <FitnessProvider>
      <Dashboard />
    </FitnessProvider>
  ) : (
    <LoginForm />
  );
}

const Index = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default Index;
