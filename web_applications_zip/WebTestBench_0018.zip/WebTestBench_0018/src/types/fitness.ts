export type ExerciseType = 
  | 'running'
  | 'cycling'
  | 'swimming'
  | 'weight_training'
  | 'yoga'
  | 'hiit'
  | 'walking'
  | 'other';

export type Intensity = 'low' | 'moderate' | 'high' | 'max';

export interface Workout {
  id: string;
  userId: string;
  exerciseType: ExerciseType;
  intensity: Intensity;
  duration: number; // minutes
  distance?: number; // km
  notes?: string;
  date: string; // ISO date string
  createdAt: string;
}

export type GoalType = 
  | 'frequency' // e.g., "run 3 times a week"
  | 'duration'; // e.g., "exercise 150 minutes per week"

export type GoalPeriod = 'week' | 'month';

export interface Goal {
  id: string;
  userId: string;
  type: GoalType;
  exerciseType?: ExerciseType; // optional filter
  targetValue: number; // count or minutes
  period: GoalPeriod;
  description: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}
