import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Workout, Goal } from '@/types/fitness';
import { initialWorkouts, initialGoals } from '@/data/mockData';

interface FitnessContextType {
  workouts: Workout[];
  goals: Goal[];
  addWorkout: (workout: Omit<Workout, 'id' | 'createdAt'>) => void;
  deleteWorkout: (id: string) => void;
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  deleteGoal: (id: string) => void;
}

const FitnessContext = createContext<FitnessContextType | undefined>(undefined);

export function FitnessProvider({ children }: { children: ReactNode }) {
  const [workouts, setWorkouts] = useState<Workout[]>(initialWorkouts);
  const [goals, setGoals] = useState<Goal[]>(initialGoals);

  const addWorkout = (workout: Omit<Workout, 'id' | 'createdAt'>) => {
    const newWorkout: Workout = {
      ...workout,
      id: `w-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setWorkouts((prev) => [newWorkout, ...prev]);
  };

  const deleteWorkout = (id: string) => {
    setWorkouts((prev) => prev.filter((w) => w.id !== id));
  };

  const addGoal = (goal: Omit<Goal, 'id' | 'createdAt'>) => {
    const newGoal: Goal = {
      ...goal,
      id: `g-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setGoals((prev) => [...prev, newGoal]);
  };

  const deleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  return (
    <FitnessContext.Provider
      value={{ workouts, goals, addWorkout, deleteWorkout, addGoal, deleteGoal }}
    >
      {children}
    </FitnessContext.Provider>
  );
}

export function useFitness() {
  const context = useContext(FitnessContext);
  if (context === undefined) {
    throw new Error('useFitness must be used within a FitnessProvider');
  }
  return context;
}
