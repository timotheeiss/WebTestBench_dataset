import { Workout, Goal, User } from '@/types/fitness';

export const mockUser: User = {
  id: 'user-1',
  name: 'Alex Runner',
  email: 'alex@fittrack.io',
  avatarUrl: undefined,
};

// Generate dates relative to today
const today = new Date();
const daysAgo = (days: number) => {
  const date = new Date(today);
  date.setDate(date.getDate() - days);
  return date.toISOString();
};

export const initialWorkouts: Workout[] = [
  {
    id: 'w1',
    userId: 'user-1',
    exerciseType: 'running',
    intensity: 'moderate',
    duration: 35,
    distance: 5.2,
    notes: 'Morning jog in the park. Felt great!',
    date: daysAgo(0),
    createdAt: daysAgo(0),
  },
  {
    id: 'w2',
    userId: 'user-1',
    exerciseType: 'weight_training',
    intensity: 'high',
    duration: 55,
    notes: 'Upper body day - bench, rows, shoulder press',
    date: daysAgo(1),
    createdAt: daysAgo(1),
  },
  {
    id: 'w3',
    userId: 'user-1',
    exerciseType: 'running',
    intensity: 'high',
    duration: 28,
    distance: 4.5,
    notes: 'Interval training - 8x400m',
    date: daysAgo(2),
    createdAt: daysAgo(2),
  },
  {
    id: 'w4',
    userId: 'user-1',
    exerciseType: 'yoga',
    intensity: 'low',
    duration: 45,
    notes: 'Recovery yoga session',
    date: daysAgo(3),
    createdAt: daysAgo(3),
  },
  {
    id: 'w5',
    userId: 'user-1',
    exerciseType: 'cycling',
    intensity: 'moderate',
    duration: 60,
    distance: 25,
    notes: 'Scenic route along the river',
    date: daysAgo(5),
    createdAt: daysAgo(5),
  },
  {
    id: 'w6',
    userId: 'user-1',
    exerciseType: 'running',
    intensity: 'moderate',
    duration: 42,
    distance: 7,
    notes: 'Long easy run',
    date: daysAgo(7),
    createdAt: daysAgo(7),
  },
  {
    id: 'w7',
    userId: 'user-1',
    exerciseType: 'hiit',
    intensity: 'max',
    duration: 25,
    notes: 'Brutal but effective',
    date: daysAgo(8),
    createdAt: daysAgo(8),
  },
  {
    id: 'w8',
    userId: 'user-1',
    exerciseType: 'swimming',
    intensity: 'moderate',
    duration: 40,
    distance: 1.5,
    notes: 'Lap swimming at the community pool',
    date: daysAgo(10),
    createdAt: daysAgo(10),
  },
];

export const initialGoals: Goal[] = [
  {
    id: 'g1',
    userId: 'user-1',
    type: 'frequency',
    exerciseType: 'running',
    targetValue: 3,
    period: 'week',
    description: 'Run 3 times a week',
    createdAt: daysAgo(30),
  },
  {
    id: 'g2',
    userId: 'user-1',
    type: 'duration',
    targetValue: 150,
    period: 'week',
    description: 'Exercise 150 minutes per week',
    createdAt: daysAgo(30),
  },
  {
    id: 'g3',
    userId: 'user-1',
    type: 'frequency',
    exerciseType: 'weight_training',
    targetValue: 2,
    period: 'week',
    description: 'Strength training twice a week',
    createdAt: daysAgo(20),
  },
];

export const exerciseTypeLabels: Record<string, string> = {
  running: 'Running',
  cycling: 'Cycling',
  swimming: 'Swimming',
  weight_training: 'Weight Training',
  yoga: 'Yoga',
  hiit: 'HIIT',
  walking: 'Walking',
  other: 'Other',
};

export const intensityLabels: Record<string, string> = {
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  max: 'Maximum',
};
