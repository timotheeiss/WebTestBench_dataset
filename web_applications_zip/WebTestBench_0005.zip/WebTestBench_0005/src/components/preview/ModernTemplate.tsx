import { Resume, ResumeSection } from '@/types/resume';
import { format } from 'date-fns';

interface ModernTemplateProps {
  resume: Resume;
}

export function ModernTemplate({ resume }: ModernTemplateProps) {
  const sortedSections = [...resume.sections]
    .filter(s => s.visible)
    .sort((a, b) => a.order - b.order);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month] = dateStr.split('-');
    return format(new Date(parseInt(year), parseInt(month) - 1), 'MMM yyyy');
  };

  const getSectionTitle = (id: string) => {
    const section = resume.sections.find(s => s.id === id);
    return section?.title || id;
  };

  const renderSection = (section: ResumeSection) => {
    switch (section.id) {
      case 'contact':
        return (
          <header className="bg-slate-800 text-white p-6 rounded-t-lg">
            <h1 className="text-2xl font-bold mb-2">{resume.contact.fullName || 'Your Name'}</h1>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-300">
              {resume.contact.email && <span>{resume.contact.email}</span>}
              {resume.contact.phone && <span>{resume.contact.phone}</span>}
              {resume.contact.location && <span>{resume.contact.location}</span>}
              {resume.contact.linkedin && <span>{resume.contact.linkedin}</span>}
              {resume.contact.website && <span>{resume.contact.website}</span>}
            </div>
          </header>
        );

      case 'summary':
        if (!resume.summary) return null;
        return (
          <section className="p-6 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
              <span className="w-1 h-5 bg-orange-500 rounded" />
              {getSectionTitle('summary')}
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed">{resume.summary}</p>
          </section>
        );

      case 'experience':
        if (resume.experience.length === 0) return null;
        return (
          <section className="p-6 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <span className="w-1 h-5 bg-orange-500 rounded" />
              {getSectionTitle('experience')}
            </h2>
            <div className="space-y-4">
              {resume.experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h3 className="font-semibold text-slate-800">{exp.position}</h3>
                      <p className="text-sm text-orange-600">{exp.company}</p>
                    </div>
                    <span className="text-xs text-slate-500">
                      {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mt-2">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>
        );

      case 'education':
        if (resume.education.length === 0) return null;
        return (
          <section className="p-6 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <span className="w-1 h-5 bg-orange-500 rounded" />
              {getSectionTitle('education')}
            </h2>
            <div className="space-y-3">
              {resume.education.map((edu) => (
                <div key={edu.id} className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-slate-800">{edu.institution}</h3>
                    <p className="text-sm text-slate-600">
                      {edu.degree} in {edu.field}
                      {edu.gpa && <span className="text-slate-400"> • GPA: {edu.gpa}</span>}
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </span>
                </div>
              ))}
            </div>
          </section>
        );

      case 'skills':
        if (resume.skills.length === 0) return null;
        return (
          <section className="p-6">
            <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <span className="w-1 h-5 bg-orange-500 rounded" />
              {getSectionTitle('skills')}
            </h2>
            <div className="flex flex-wrap gap-2">
              {resume.skills.map((skill) => (
                <span 
                  key={skill.id}
                  className="px-3 py-1 text-sm bg-slate-100 text-slate-700 rounded-full"
                >
                  {skill.name}
                </span>
              ))}
            </div>
          </section>
        );

      default:
        return null;
    }
  };

  return (
    <div className="resume-preview max-w-[21cm] mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
      {sortedSections.map((section) => (
        <div key={section.id}>{renderSection(section)}</div>
      ))}
    </div>
  );
}
