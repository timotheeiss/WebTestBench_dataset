import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Recipe, Comment, Rating, initialRecipes } from '@/data/recipes';

interface RecipeContextType {
  recipes: Recipe[];
  addRecipe: (recipe: Omit<Recipe, 'id' | 'comments' | 'ratings' | 'createdAt'>) => void;
  addComment: (recipeId: string, comment: Omit<Comment, 'id' | 'createdAt'>) => void;
  addRating: (recipeId: string, rating: Rating) => void;
  getRecipe: (id: string) => Recipe | undefined;
  getAverageRating: (recipeId: string) => number;
}

const RecipeContext = createContext<RecipeContextType | undefined>(undefined);

export function RecipeProvider({ children }: { children: ReactNode }) {
  const [recipes, setRecipes] = useState<Recipe[]>(initialRecipes);

  const addRecipe = (recipeData: Omit<Recipe, 'id' | 'comments' | 'ratings' | 'createdAt'>) => {
    const newRecipe: Recipe = {
      ...recipeData,
      id: Date.now().toString(),
      comments: [],
      ratings: [],
      createdAt: new Date(),
    };
    setRecipes((prev) => [newRecipe, ...prev]);
  };

  const addComment = (recipeId: string, commentData: Omit<Comment, 'id' | 'createdAt'>) => {
    const newComment: Comment = {
      ...commentData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setRecipes((prev) =>
      prev.map((recipe) =>
        recipe.id === recipeId
          ? { ...recipe, comments: [...recipe.comments, newComment] }
          : recipe
      )
    );
  };

  const addRating = (recipeId: string, rating: Rating) => {
    setRecipes((prev) =>
      prev.map((recipe) => {
        if (recipe.id !== recipeId) return recipe;
        const existingIndex = recipe.ratings.findIndex((r) => r.odaj === rating.odaj);
        if (existingIndex >= 0) {
          const updatedRatings = [...recipe.ratings];
          updatedRatings[existingIndex] = rating;
          return { ...recipe, ratings: updatedRatings };
        }
        return { ...recipe, ratings: [...recipe.ratings, rating] };
      })
    );
  };

  const getRecipe = (id: string) => recipes.find((r) => r.id === id);

  const getAverageRating = (recipeId: string) => {
    const recipe = recipes.find((r) => r.id === recipeId);
    if (!recipe || recipe.ratings.length === 0) return 0;
    const sum = recipe.ratings.reduce((acc, r) => acc + r.value, 0);
    return sum / recipe.ratings.length;
  };

  return (
    <RecipeContext.Provider value={{ recipes, addRecipe, addComment, addRating, getRecipe, getAverageRating }}>
      {children}
    </RecipeContext.Provider>
  );
}

export function useRecipes() {
  const context = useContext(RecipeContext);
  if (context === undefined) {
    throw new Error('useRecipes must be used within a RecipeProvider');
  }
  return context;
}
