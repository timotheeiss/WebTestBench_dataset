import pastaImage from '@/assets/pasta.jpg';
import tomatoSoupImage from '@/assets/tomato-soup.jpg';
import salmonImage from '@/assets/salmon.jpg';
import lavaCakeImage from '@/assets/lava-cake.jpg';

export interface Ingredient {
  name: string;
  amount: string;
}

export interface Step {
  order: number;
  description: string;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  createdAt: Date;
}

export interface Rating {
  odaj: string;
  value: number;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  author: string;
  cookTime: string;
  servings: number;
  ingredients: Ingredient[];
  steps: Step[];
  comments: Comment[];
  ratings: Rating[];
  createdAt: Date;
}

export const initialRecipes: Recipe[] = [
  {
    id: "1",
    title: "Classic Homemade Pasta",
    description: "Fresh, silky pasta made from scratch. There's nothing quite like the taste and texture of homemade pasta – it's surprisingly simple and absolutely worth the effort.",
    imageUrl: pastaImage,
    author: "Maria Romano",
    cookTime: "45 mins",
    servings: 4,
    ingredients: [
      { name: "All-purpose flour", amount: "2 cups" },
      { name: "Large eggs", amount: "3" },
      { name: "Olive oil", amount: "1 tbsp" },
      { name: "Salt", amount: "1/2 tsp" },
    ],
    steps: [
      { order: 1, description: "Create a mound of flour on a clean surface and make a well in the center. Crack the eggs into the well and add the olive oil and salt." },
      { order: 2, description: "Using a fork, gently beat the eggs while gradually incorporating flour from the inner edges of the well." },
      { order: 3, description: "Once a shaggy dough forms, use your hands to bring it together. Knead for 8-10 minutes until smooth and elastic." },
      { order: 4, description: "Wrap the dough in plastic wrap and let it rest at room temperature for 30 minutes." },
      { order: 5, description: "Divide the dough into 4 pieces. Roll each piece through a pasta machine or by hand until thin, then cut into desired shape." },
      { order: 6, description: "Cook in salted boiling water for 2-3 minutes until al dente. Serve with your favorite sauce." },
    ],
    comments: [
      { id: "c1", author: "James K.", text: "Made this for Sunday dinner – absolutely incredible! The texture was so much better than store-bought.", createdAt: new Date("2024-01-15") },
      { id: "c2", author: "Sophie L.", text: "My family loved it. I added a bit of semolina flour for extra texture.", createdAt: new Date("2024-01-20") },
    ],
    ratings: [
      { odaj: "user1", value: 5 },
      { odaj: "user2", value: 4 },
      { odaj: "user3", value: 5 },
    ],
    createdAt: new Date("2024-01-10"),
  },
  {
    id: "2",
    title: "Rustic Tomato Basil Soup",
    description: "A comforting bowl of sunshine – ripe tomatoes, fresh basil, and a touch of cream come together in this soul-warming soup perfect for any season.",
    imageUrl: tomatoSoupImage,
    author: "Chef Antonio",
    cookTime: "35 mins",
    servings: 6,
    ingredients: [
      { name: "Ripe tomatoes", amount: "2 lbs" },
      { name: "Fresh basil leaves", amount: "1 cup" },
      { name: "Yellow onion", amount: "1 large" },
      { name: "Garlic cloves", amount: "4" },
      { name: "Vegetable broth", amount: "3 cups" },
      { name: "Heavy cream", amount: "1/2 cup" },
      { name: "Olive oil", amount: "3 tbsp" },
      { name: "Salt and pepper", amount: "to taste" },
    ],
    steps: [
      { order: 1, description: "Core and quarter the tomatoes. Dice the onion and mince the garlic." },
      { order: 2, description: "Heat olive oil in a large pot over medium heat. Sauté onion until translucent, about 5 minutes. Add garlic and cook 1 minute more." },
      { order: 3, description: "Add tomatoes and vegetable broth. Bring to a boil, then reduce heat and simmer for 20 minutes." },
      { order: 4, description: "Remove from heat and stir in most of the basil, reserving some for garnish." },
      { order: 5, description: "Blend until smooth using an immersion blender or regular blender. Return to pot if needed." },
      { order: 6, description: "Stir in cream, season with salt and pepper. Serve hot with fresh basil leaves on top." },
    ],
    comments: [
      { id: "c3", author: "Emma R.", text: "The fresh basil makes such a difference! This is now my go-to soup recipe.", createdAt: new Date("2024-02-05") },
    ],
    ratings: [
      { odaj: "user1", value: 4 },
      { odaj: "user4", value: 5 },
    ],
    createdAt: new Date("2024-02-01"),
  },
  {
    id: "3",
    title: "Honey Glazed Salmon",
    description: "Perfectly caramelized salmon with a sweet and savory honey glaze. Ready in under 30 minutes for an elegant weeknight dinner.",
    imageUrl: salmonImage,
    author: "Lisa Chen",
    cookTime: "25 mins",
    servings: 2,
    ingredients: [
      { name: "Salmon fillets", amount: "2 (6 oz each)" },
      { name: "Honey", amount: "3 tbsp" },
      { name: "Soy sauce", amount: "2 tbsp" },
      { name: "Garlic", amount: "2 cloves, minced" },
      { name: "Lemon juice", amount: "1 tbsp" },
      { name: "Sesame seeds", amount: "1 tsp" },
      { name: "Green onions", amount: "2, sliced" },
    ],
    steps: [
      { order: 1, description: "Preheat oven to 400°F (200°C). Line a baking sheet with parchment paper." },
      { order: 2, description: "Mix honey, soy sauce, garlic, and lemon juice in a small bowl to make the glaze." },
      { order: 3, description: "Place salmon fillets on the prepared baking sheet, skin side down." },
      { order: 4, description: "Brush half the glaze generously over the salmon." },
      { order: 5, description: "Bake for 12-15 minutes, brushing with remaining glaze halfway through." },
      { order: 6, description: "Sprinkle with sesame seeds and green onions before serving." },
    ],
    comments: [],
    ratings: [
      { odaj: "user2", value: 5 },
    ],
    createdAt: new Date("2024-02-10"),
  },
  {
    id: "4",
    title: "Chocolate Lava Cakes",
    description: "Decadent individual chocolate cakes with a molten center. The perfect impressive dessert that's easier than you think!",
    imageUrl: lavaCakeImage,
    author: "Pastry Chef Marie",
    cookTime: "20 mins",
    servings: 4,
    ingredients: [
      { name: "Dark chocolate", amount: "4 oz" },
      { name: "Unsalted butter", amount: "4 tbsp" },
      { name: "Eggs", amount: "2 large" },
      { name: "Egg yolks", amount: "2" },
      { name: "Sugar", amount: "1/4 cup" },
      { name: "All-purpose flour", amount: "2 tbsp" },
      { name: "Cocoa powder", amount: "for dusting" },
    ],
    steps: [
      { order: 1, description: "Preheat oven to 425°F (220°C). Butter four 6-oz ramekins and dust with cocoa powder." },
      { order: 2, description: "Melt chocolate and butter together in a microwave or double boiler. Stir until smooth." },
      { order: 3, description: "Whisk eggs, egg yolks, and sugar until thick and pale, about 2 minutes." },
      { order: 4, description: "Fold the chocolate mixture into the egg mixture, then gently fold in the flour." },
      { order: 5, description: "Divide batter among prepared ramekins. Can be refrigerated for up to 24 hours at this point." },
      { order: 6, description: "Bake for 12-14 minutes until edges are firm but center is soft. Let cool 1 minute, then invert onto plates. Serve immediately." },
    ],
    comments: [
      { id: "c4", author: "David M.", text: "Made these for Valentine's Day and they were a huge hit! The centers were perfectly gooey.", createdAt: new Date("2024-02-14") },
      { id: "c5", author: "Rachel T.", text: "I was nervous about the timing but they came out perfect. Restaurant quality!", createdAt: new Date("2024-02-18") },
    ],
    ratings: [
      { odaj: "user1", value: 5 },
      { odaj: "user2", value: 5 },
      { odaj: "user3", value: 4 },
      { odaj: "user4", value: 5 },
    ],
    createdAt: new Date("2024-02-12"),
  },
];