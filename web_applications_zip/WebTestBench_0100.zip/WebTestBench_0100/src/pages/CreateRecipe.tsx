import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/Header';
import { useRecipes } from '@/context/RecipeContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2, ChefHat, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Ingredient, Step } from '@/data/recipes';

const CreateRecipe = () => {
  const navigate = useNavigate();
  const { addRecipe } = useRecipes();
  const { toast } = useToast();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [author, setAuthor] = useState('');
  const [cookTime, setCookTime] = useState('');
  const [servings, setServings] = useState('4');
  const [imageUrl, setImageUrl] = useState('');
  const [ingredients, setIngredients] = useState<Ingredient[]>([
    { name: '', amount: '' },
  ]);
  const [steps, setSteps] = useState<Step[]>([{ order: 1, description: '' }]);

  const addIngredient = () => {
    setIngredients([...ingredients, { name: '', amount: '' }]);
  };

  const removeIngredient = (index: number) => {
    if (ingredients.length > 1) {
      setIngredients(ingredients.filter((_, i) => i !== index));
    }
  };

  const updateIngredient = (
    index: number,
    field: keyof Ingredient,
    value: string
  ) => {
    const updated = [...ingredients];
    updated[index] = { ...updated[index], [field]: value };
    setIngredients(updated);
  };

  const addStep = () => {
    setSteps([...steps, { order: steps.length + 1, description: '' }]);
  };

  const removeStep = (index: number) => {
    if (steps.length > 1) {
      const updated = steps
        .filter((_, i) => i !== index)
        .map((step, i) => ({ ...step, order: i + 1 }));
      setSteps(updated);
    }
  };

  const updateStep = (index: number, description: string) => {
    const updated = [...steps];
    updated[index] = { ...updated[index], description };
    setSteps(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!title.trim() || !description.trim() || !author.trim()) {
      toast({
        title: 'Missing information',
        description: 'Please fill in the title, description, and your name.',
        variant: 'destructive',
      });
      return;
    }

    const validIngredients = ingredients.filter(
      (i) => i.name.trim() && i.amount.trim()
    );
    const validSteps = steps.filter((s) => s.description.trim());

    if (validIngredients.length === 0) {
      toast({
        title: 'Missing ingredients',
        description: 'Please add at least one ingredient.',
        variant: 'destructive',
      });
      return;
    }

    if (validSteps.length === 0) {
      toast({
        title: 'Missing steps',
        description: 'Please add at least one step.',
        variant: 'destructive',
      });
      return;
    }

    addRecipe({
      title: title.trim(),
      description: description.trim(),
      author: author.trim(),
      cookTime: cookTime.trim() || '30 mins',
      servings: parseInt(servings) || 4,
      imageUrl: imageUrl.trim(),
      ingredients: validIngredients,
      steps: validSteps.map((s, i) => ({ ...s, order: i + 1 })),
    });

    toast({
      title: 'Recipe published!',
      description: 'Your recipe is now live for others to enjoy.',
    });

    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8 md:py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-3xl"
        >
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-primary/10 mb-4">
              <ChefHat className="h-7 w-7 text-primary" />
            </div>
            <h1 className="font-heading text-3xl font-bold text-foreground sm:text-4xl">
              Share Your Recipe
            </h1>
            <p className="mt-3 text-muted-foreground">
              Tell us about your culinary creation
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Info */}
            <div className="bg-card rounded-xl p-6 shadow-card space-y-5">
              <h2 className="font-heading text-lg font-semibold border-b border-border pb-3">
                Basic Information
              </h2>

              <div className="space-y-2">
                <Label htmlFor="title">Recipe Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Grandma's Apple Pie"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="What makes this recipe special?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  className="resize-none"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="author">Your Name</Label>
                  <Input
                    id="author"
                    placeholder="Chef Maria"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cookTime">Cook Time</Label>
                  <Input
                    id="cookTime"
                    placeholder="30 mins"
                    value={cookTime}
                    onChange={(e) => setCookTime(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="servings">Servings</Label>
                  <Input
                    id="servings"
                    type="number"
                    min="1"
                    value={servings}
                    onChange={(e) => setServings(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="imageUrl">Image URL (optional)</Label>
                <Input
                  id="imageUrl"
                  placeholder="https://example.com/image.jpg"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                />
              </div>
            </div>

            {/* Ingredients */}
            <div className="bg-card rounded-xl p-6 shadow-card space-y-5">
              <h2 className="font-heading text-lg font-semibold border-b border-border pb-3">
                Ingredients
              </h2>

              <AnimatePresence>
                {ingredients.map((ingredient, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="flex gap-3 items-start"
                  >
                    <div className="grid gap-3 sm:grid-cols-3 flex-1">
                      <Input
                        placeholder="Amount (e.g., 2 cups)"
                        value={ingredient.amount}
                        onChange={(e) =>
                          updateIngredient(index, 'amount', e.target.value)
                        }
                      />
                      <Input
                        placeholder="Ingredient name"
                        className="sm:col-span-2"
                        value={ingredient.name}
                        onChange={(e) =>
                          updateIngredient(index, 'name', e.target.value)
                        }
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeIngredient(index)}
                      className="text-muted-foreground hover:text-destructive flex-shrink-0"
                      disabled={ingredients.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>

              <Button
                type="button"
                variant="outline"
                onClick={addIngredient}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Ingredient
              </Button>
            </div>

            {/* Steps */}
            <div className="bg-card rounded-xl p-6 shadow-card space-y-5">
              <h2 className="font-heading text-lg font-semibold border-b border-border pb-3">
                Instructions
              </h2>

              <AnimatePresence>
                {steps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="flex gap-3 items-start"
                  >
                    <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold text-sm">
                      {step.order}
                    </div>
                    <Textarea
                      placeholder={`Describe step ${step.order}...`}
                      value={step.description}
                      onChange={(e) => updateStep(index, e.target.value)}
                      rows={2}
                      className="flex-1 resize-none"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeStep(index)}
                      className="text-muted-foreground hover:text-destructive flex-shrink-0"
                      disabled={steps.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>

              <Button
                type="button"
                variant="outline"
                onClick={addStep}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Step
              </Button>
            </div>

            {/* Submit */}
            <div className="flex justify-end">
              <Button type="submit" size="lg" className="gap-2">
                Publish Recipe
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default CreateRecipe;
