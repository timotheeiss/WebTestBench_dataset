import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { CommentSection } from '@/components/CommentSection';
import { StarRating } from '@/components/StarRating';
import { useRecipes } from '@/context/RecipeContext';
import { ArrowLeft, Clock, Users, ChefHat, ListOrdered, Utensils } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

const RecipeDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getRecipe, addRating, getAverageRating } = useRecipes();
  const { toast } = useToast();
  const recipe = getRecipe(id || '');
  const [userRating, setUserRating] = useState(0);

  if (!recipe) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16 text-center">
          <h1 className="font-heading text-2xl font-semibold text-foreground mb-4">
            Recipe not found
          </h1>
          <Link to="/">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to recipes
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <article className="container py-8 md:py-12">
        <Link to="/">
          <Button variant="ghost" className="gap-2 mb-6 -ml-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
            Back to recipes
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Hero */}
          <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
            <div className="aspect-[4/3] overflow-hidden rounded-2xl bg-muted">
              {recipe.imageUrl ? (
                <img
                  src={recipe.imageUrl}
                  alt={recipe.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
                  <ChefHat className="h-24 w-24 text-primary/20" />
                </div>
              )}
            </div>

            <div className="flex flex-col justify-center">
              <h1 className="font-heading text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl">
                {recipe.title}
              </h1>
              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                {recipe.description}
              </p>
              
              {/* Rating Section */}
              <div className="mt-6 p-4 bg-muted/50 rounded-xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Average Rating</p>
                    <div className="flex items-center gap-2">
                      <StarRating
                        rating={Math.round(getAverageRating(recipe.id))}
                        readonly
                        size="md"
                      />
                      <span className="text-sm text-muted-foreground">
                        ({recipe.ratings.length} {recipe.ratings.length === 1 ? 'rating' : 'ratings'})
                      </span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Rate this recipe</p>
                    <StarRating
                      rating={userRating}
                      onRate={(value) => {
                        setUserRating(value);
                        addRating(recipe.id, { odaj: 'current-user', value });
                        toast({
                          title: 'Thanks for rating!',
                          description: `You gave this recipe ${value} star${value > 1 ? 's' : ''}.`,
                        });
                      }}
                      size="md"
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex flex-wrap items-center gap-4 text-muted-foreground">
                <div className="flex items-center gap-2 bg-muted px-3 py-1.5 rounded-full">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm font-medium">{recipe.cookTime}</span>
                </div>
                <div className="flex items-center gap-2 bg-muted px-3 py-1.5 rounded-full">
                  <Users className="h-4 w-4" />
                  <span className="text-sm font-medium">{recipe.servings} servings</span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  Shared by <span className="font-semibold text-foreground">{recipe.author}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatDate(recipe.createdAt)}
                </p>
              </div>
            </div>
          </div>

          {/* Ingredients & Steps */}
          <div className="mt-12 grid gap-8 lg:grid-cols-3">
            {/* Ingredients */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 bg-card rounded-xl p-6 shadow-card">
                <div className="flex items-center gap-2 mb-4">
                  <Utensils className="h-5 w-5 text-primary" />
                  <h2 className="font-heading text-xl font-semibold">Ingredients</h2>
                </div>
                <ul className="space-y-3">
                  {recipe.ingredients.map((ingredient, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-3"
                    >
                      <span className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="font-medium text-foreground">{ingredient.amount}</span>{' '}
                        {ingredient.name}
                      </span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Steps */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <ListOrdered className="h-5 w-5 text-primary" />
                <h2 className="font-heading text-xl font-semibold">Instructions</h2>
              </div>
              <ol className="space-y-6">
                {recipe.steps.map((step, index) => (
                  <motion.li
                    key={step.order}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-4"
                  >
                    <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold text-sm">
                      {step.order}
                    </div>
                    <div className="pt-1">
                      <p className="text-muted-foreground leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </motion.li>
                ))}
              </ol>
            </div>
          </div>

          {/* Comments */}
          <CommentSection recipeId={recipe.id} comments={recipe.comments} />
        </motion.div>
      </article>
    </div>
  );
};

export default RecipeDetail;
