import { Header } from '@/components/Header';
import { RecipeCard } from '@/components/RecipeCard';
import { useRecipes } from '@/context/RecipeContext';
import { ChefHat, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

const Index = () => {
  const { recipes } = useRecipes();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 via-background to-background py-16 md:py-24">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-6">
              <Sparkles className="h-4 w-4" />
              Discover & Share Recipes
            </div>
            <h1 className="font-heading text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
              Where Every Dish
              <span className="block text-primary">Tells a Story</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Explore a collection of handcrafted recipes from home cooks around the world. 
              Share your culinary creations and discover your next favorite meal.
            </p>
          </motion.div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-secondary/5 blur-3xl" />
      </section>

      {/* Recipes Grid */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <ChefHat className="h-6 w-6 text-primary" />
              <h2 className="font-heading text-2xl font-semibold text-foreground">
                All Recipes
              </h2>
            </div>
            <p className="text-sm text-muted-foreground">
              {recipes.length} recipes shared
            </p>
          </div>

          {recipes.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-muted-foreground">
                No recipes yet. Be the first to share one!
              </p>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {recipes.map((recipe, index) => (
                <RecipeCard key={recipe.id} recipe={recipe} index={index} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>Made with love for food enthusiasts everywhere</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
