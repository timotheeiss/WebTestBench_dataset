import { Link } from 'react-router-dom';
import { ChefHat, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground transition-transform group-hover:scale-105">
            <ChefHat className="h-5 w-5" />
          </div>
          <span className="font-heading text-xl font-semibold">TasteBuds</span>
        </Link>
        
        <nav className="flex items-center gap-4">
          <Link to="/">
            <Button variant="ghost" className="font-medium">
              Browse Recipes
            </Button>
          </Link>
          <Link to="/create">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              New Recipe
            </Button>
          </Link>
        </nav>
      </div>
    </header>
  );
}
