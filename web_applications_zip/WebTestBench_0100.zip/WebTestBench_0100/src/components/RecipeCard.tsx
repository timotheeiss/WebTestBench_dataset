import { Link } from 'react-router-dom';
import { Clock, Users, MessageCircle } from 'lucide-react';
import { Recipe } from '@/data/recipes';
import { Card, CardContent } from '@/components/ui/card';
import { StarRating } from '@/components/StarRating';
import { useRecipes } from '@/context/RecipeContext';
import { motion } from 'framer-motion';

interface RecipeCardProps {
  recipe: Recipe;
  index: number;
}

export function RecipeCard({ recipe, index }: RecipeCardProps) {
  const { getAverageRating } = useRecipes();
  const averageRating = getAverageRating(recipe.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      <Link to={`/recipe/${recipe.id}`}>
        <Card className="group overflow-hidden border-border bg-card shadow-card transition-all duration-300 hover:shadow-hover hover:-translate-y-1">
          <div className="aspect-[4/3] overflow-hidden bg-muted">
            {recipe.imageUrl ? (
              <img
                src={recipe.imageUrl}
                alt={recipe.title}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
                <span className="font-heading text-4xl text-primary/30">
                  {recipe.title.charAt(0)}
                </span>
              </div>
            )}
          </div>
          <CardContent className="p-5">
            <h3 className="font-heading text-xl font-semibold text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {recipe.title}
            </h3>
            <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
              {recipe.description}
            </p>
            
            {averageRating > 0 && (
              <div className="mt-3">
                <StarRating
                  rating={Math.round(averageRating)}
                  readonly
                  size="sm"
                  showCount
                  ratingCount={recipe.ratings.length}
                />
              </div>
            )}
            
            <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                <span>{recipe.cookTime}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="h-4 w-4" />
                <span>{recipe.servings} servings</span>
              </div>
              {recipe.comments.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <MessageCircle className="h-4 w-4" />
                  <span>{recipe.comments.length}</span>
                </div>
              )}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              by <span className="font-medium text-foreground">{recipe.author}</span>
            </p>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}
