import { useState } from 'react';
import { MessageCircle, Send, User } from 'lucide-react';
import { Comment } from '@/data/recipes';
import { useRecipes } from '@/context/RecipeContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

interface CommentSectionProps {
  recipeId: string;
  comments: Comment[];
}

export function CommentSection({ recipeId, comments }: CommentSectionProps) {
  const [author, setAuthor] = useState('');
  const [text, setText] = useState('');
  const { addComment } = useRecipes();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !text.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter your name and comment.",
        variant: "destructive",
      });
      return;
    }

    addComment(recipeId, { author: author.trim(), text: text.trim() });
    setAuthor('');
    setText('');
    toast({
      title: "Comment added!",
      description: "Thanks for sharing your thoughts.",
    });
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="mt-12 border-t border-border pt-8">
      <div className="flex items-center gap-2 mb-6">
        <MessageCircle className="h-5 w-5 text-primary" />
        <h2 className="font-heading text-2xl font-semibold">
          Comments ({comments.length})
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="mb-8 space-y-4 bg-muted/50 rounded-lg p-6">
        <h3 className="font-medium text-foreground">Leave a comment</h3>
        <Input
          placeholder="Your name"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          className="bg-background"
        />
        <Textarea
          placeholder="Share your experience with this recipe..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          className="bg-background resize-none"
        />
        <Button type="submit" className="gap-2">
          <Send className="h-4 w-4" />
          Post Comment
        </Button>
      </form>

      <div className="space-y-4">
        <AnimatePresence>
          {comments.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No comments yet. Be the first to share your thoughts!
            </p>
          ) : (
            comments.map((comment, index) => (
              <motion.div
                key={comment.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-card rounded-lg p-5 shadow-soft"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10">
                    <User className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{comment.author}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(comment.createdAt)}
                    </p>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">{comment.text}</p>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
