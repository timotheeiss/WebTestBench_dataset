export type PropertyType = 'house' | 'apartment' | 'villa' | 'cabin' | 'cottage';

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Property {
  id: string;
  title: string;
  location: string;
  description: string;
  propertyType: PropertyType;
  price: number;
  maxGuests: number;
  bedrooms: number;
  bathrooms: number;
  amenities: string[];
  images: string[];
  rating: number;
  reviewCount: number;
  reviews: Review[];
  availableDates: string[];
  ownerId: string;
}

export interface BookingRequest {
  id: string;
  propertyId: string;
  guestName: string;
  guestEmail: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  message: string;
  status: 'pending' | 'approved' | 'declined';
  createdAt: string;
}

// Generate available dates for the next 3 months
const generateAvailableDates = (): string[] => {
  const dates: string[] = [];
  const today = new Date();
  for (let i = 1; i <= 90; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    // Randomly make some dates unavailable
    if (Math.random() > 0.2) {
      dates.push(date.toISOString().split('T')[0]);
    }
  }
  return dates;
};

export const properties: Property[] = [
  {
    id: '1',
    title: 'Seaside Villa with Infinity Pool',
    location: 'Santorini, Greece',
    description: 'Perched on the cliffs of Oia, this stunning villa offers breathtaking views of the Aegean Sea and the famous Santorini sunset. The property features traditional Cycladic architecture with modern luxury amenities, including a private infinity pool that seems to merge with the horizon. Wake up to panoramic sea views, enjoy breakfast on your private terrace, and spend your days exploring the charming streets of Oia or relaxing by the pool.',
    propertyType: 'villa',
    price: 450,
    maxGuests: 6,
    bedrooms: 3,
    bathrooms: 2,
    amenities: ['Infinity Pool', 'Sea View', 'Air Conditioning', 'WiFi', 'Kitchen', 'Terrace', 'Parking', 'BBQ'],
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800',
      'https://images.unsplash.com/photo-1602343168117-bb8ffe3e2e9f?w=800',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800'
    ],
    rating: 4.9,
    reviewCount: 127,
    reviews: [
      { id: 'r1', author: 'Emma S.', rating: 5, comment: 'Absolutely magical! The sunset views are even better than the photos.', date: '2024-10-15' },
      { id: 'r2', author: 'Marcus T.', rating: 5, comment: 'Perfect honeymoon destination. The pool is incredible.', date: '2024-09-22' },
      { id: 'r3', author: 'Sophie L.', rating: 4, comment: 'Beautiful property, great location. A bit of a walk to restaurants but worth it.', date: '2024-08-10' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner1'
  },
  {
    id: '2',
    title: 'Modern Loft in Historic District',
    location: 'Barcelona, Spain',
    description: 'Experience the best of Barcelona from this beautifully renovated loft in the heart of the Gothic Quarter. Original exposed brick walls blend seamlessly with contemporary design, featuring floor-to-ceiling windows that flood the space with natural light. Steps away from La Rambla, the Cathedral, and countless tapas bars, this is the perfect base for exploring the city while enjoying the comforts of a stylish home.',
    propertyType: 'apartment',
    price: 185,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 1,
    amenities: ['WiFi', 'Air Conditioning', 'Kitchen', 'Washer', 'City View', 'Smart TV', 'Coffee Machine'],
    images: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800',
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800'
    ],
    rating: 4.7,
    reviewCount: 89,
    reviews: [
      { id: 'r4', author: 'James W.', rating: 5, comment: 'Incredible location and stunning interior design!', date: '2024-11-01' },
      { id: 'r5', author: 'Laura M.', rating: 4, comment: 'Loved the neighborhood. Great restaurants nearby.', date: '2024-10-18' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner1'
  },
  {
    id: '3',
    title: 'Mountain Retreat Cabin',
    location: 'Aspen, Colorado',
    description: 'Escape to this cozy yet luxurious cabin nestled in the Aspen mountains. Featuring authentic log construction, a massive stone fireplace, and walls of windows showcasing spectacular mountain views. Perfect for ski enthusiasts in winter or hikers in summer. The cabin includes a private hot tub, gourmet kitchen, and is just minutes from world-class skiing and the charming town of Aspen.',
    propertyType: 'cabin',
    price: 375,
    maxGuests: 8,
    bedrooms: 4,
    bathrooms: 3,
    amenities: ['Hot Tub', 'Fireplace', 'Mountain View', 'Ski Storage', 'WiFi', 'Kitchen', 'Parking', 'Game Room'],
    images: [
      'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=800',
      'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=800',
      'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=800'
    ],
    rating: 4.8,
    reviewCount: 64,
    reviews: [
      { id: 'r6', author: 'Michael R.', rating: 5, comment: 'Best ski trip ever! The cabin is absolutely perfect.', date: '2024-02-20' },
      { id: 'r7', author: 'Sarah K.', rating: 5, comment: 'We stayed in summer for hiking - breathtaking views!', date: '2024-07-15' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner2'
  },
  {
    id: '4',
    title: 'Charming Coastal Cottage',
    location: 'Cornwall, England',
    description: 'A picture-perfect English cottage just steps from the beach in the beautiful Cornish coast. Whitewashed walls, thatched roof, and a blooming cottage garden create the quintessential British seaside escape. Inside, find a cozy living room with wood-burning stove, a farmhouse kitchen, and comfortable bedrooms with sea glimpses. Perfect for coastal walks, cream teas, and watching the sunset over the Atlantic.',
    propertyType: 'cottage',
    price: 165,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 1,
    amenities: ['Garden', 'Beach Access', 'Wood Stove', 'WiFi', 'Kitchen', 'Pet Friendly', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1505916349660-8d91a99c3e23?w=800',
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?w=800',
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800'
    ],
    rating: 4.6,
    reviewCount: 52,
    reviews: [
      { id: 'r8', author: 'Helen B.', rating: 5, comment: 'So charming! Felt like stepping into a storybook.', date: '2024-08-25' },
      { id: 'r9', author: 'David P.', rating: 4, comment: 'Lovely cottage, beautiful walks. A bit small but cozy.', date: '2024-07-30' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner2'
  },
  {
    id: '5',
    title: 'Tropical Beach House',
    location: 'Tulum, Mexico',
    description: 'Wake up to the sound of waves at this stunning beachfront property in Tulum. Bohemian-chic design meets eco-luxury with natural materials, open-air living spaces, and direct beach access. The rooftop terrace offers panoramic Caribbean views, perfect for stargazing. Experience the magic of Tulum\'s famous beaches, cenotes, and Mayan ruins, all while enjoying sustainable luxury.',
    propertyType: 'house',
    price: 295,
    maxGuests: 6,
    bedrooms: 3,
    bathrooms: 2,
    amenities: ['Beachfront', 'Rooftop Terrace', 'Outdoor Shower', 'WiFi', 'Kitchen', 'Hammocks', 'Bikes', 'AC'],
    images: [
      'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?w=800',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800',
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800'
    ],
    rating: 4.9,
    reviewCount: 98,
    reviews: [
      { id: 'r10', author: 'Jessica A.', rating: 5, comment: 'Paradise found! Waking up to the beach was incredible.', date: '2024-11-05' },
      { id: 'r11', author: 'Carlos M.', rating: 5, comment: 'Best vacation of my life. The house is stunning.', date: '2024-10-20' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner1'
  },
  {
    id: '6',
    title: 'Sleek City Penthouse',
    location: 'Tokyo, Japan',
    description: 'Experience Tokyo from above in this ultra-modern penthouse in the vibrant Shibuya district. Floor-to-ceiling windows offer mesmerizing city views, including glimpses of Mount Fuji on clear days. Minimalist Japanese design with premium amenities creates a serene urban retreat. Steps from Shibuya Crossing, world-class dining, and excellent transport links to explore all of Tokyo.',
    propertyType: 'apartment',
    price: 320,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['City View', 'Concierge', 'Gym Access', 'WiFi', 'Kitchen', 'Smart Home', 'Washer', 'AC'],
    images: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800',
      'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800',
      'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800'
    ],
    rating: 4.7,
    reviewCount: 73,
    reviews: [
      { id: 'r12', author: 'Alex T.', rating: 5, comment: 'Amazing views and perfect location for exploring Tokyo!', date: '2024-09-10' },
      { id: 'r13', author: 'Yuki H.', rating: 4, comment: 'Beautiful space, very clean. Great for couples.', date: '2024-08-28' }
    ],
    availableDates: generateAvailableDates(),
    ownerId: 'owner2'
  }
];

export const initialBookingRequests: BookingRequest[] = [
  {
    id: 'b1',
    propertyId: '1',
    guestName: 'John Smith',
    guestEmail: 'john.smith@email.com',
    checkIn: '2025-01-15',
    checkOut: '2025-01-20',
    guests: 4,
    message: 'We are celebrating our anniversary and would love to stay at your beautiful villa!',
    status: 'pending',
    createdAt: '2024-12-08'
  },
  {
    id: 'b2',
    propertyId: '2',
    guestName: 'Maria Garcia',
    guestEmail: 'maria.garcia@email.com',
    checkIn: '2025-02-01',
    checkOut: '2025-02-05',
    guests: 2,
    message: 'Looking forward to exploring Barcelona!',
    status: 'approved',
    createdAt: '2024-12-05'
  },
  {
    id: 'b3',
    propertyId: '3',
    guestName: 'Robert Chen',
    guestEmail: 'robert.chen@email.com',
    checkIn: '2025-01-10',
    checkOut: '2025-01-14',
    guests: 6,
    message: 'Family ski trip - very excited!',
    status: 'pending',
    createdAt: '2024-12-07'
  }
];

export const propertyTypes: { value: PropertyType; label: string }[] = [
  { value: 'house', label: 'House' },
  { value: 'apartment', label: 'Apartment' },
  { value: 'villa', label: 'Villa' },
  { value: 'cabin', label: 'Cabin' },
  { value: 'cottage', label: 'Cottage' }
];
