import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Header from '@/components/layout/Header';
import PropertyForm from '@/components/property/PropertyForm';

const EditListing = () => {
  const { id } = useParams<{ id: string }>();
  const { properties } = useApp();
  
  const property = properties.find(p => p.id === id);

  if (!property) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-12 text-center">
          <h1 className="font-display text-2xl font-semibold">Property not found</h1>
          <Link to="/" className="mt-4 inline-block text-primary hover:underline">
            Back to listings
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container py-8">
        <div className="mx-auto max-w-2xl">
          <Link 
            to={`/property/${property.id}`}
            className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to property
          </Link>
          
          <h1 className="mb-2 font-display text-3xl font-bold">Edit Listing</h1>
          <p className="mb-8 text-muted-foreground">
            Update your property details below.
          </p>
          
          <PropertyForm property={property} mode="edit" />
        </div>
      </div>
    </div>
  );
};

export default EditListing;
