import { format } from 'date-fns';
import { Calendar, Mail, Users, MessageSquare, Check, X, Clock } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Header from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';

const ManageBookings = () => {
  const { bookingRequests, properties, updateBookingStatus } = useApp();

  const getProperty = (propertyId: string) => {
    return properties.find(p => p.id === propertyId);
  };

  const handleStatusUpdate = (id: string, status: 'approved' | 'declined') => {
    updateBookingStatus(id, status);
    toast({
      title: `Booking ${status}`,
      description: status === 'approved' 
        ? "The guest will be notified of your approval."
        : "The guest will be notified of your decision."
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="bg-amber-100 text-amber-800"><Clock className="mr-1 h-3 w-3" /> Pending</Badge>;
      case 'approved':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><Check className="mr-1 h-3 w-3" /> Approved</Badge>;
      case 'declined':
        return <Badge variant="secondary" className="bg-red-100 text-red-800"><X className="mr-1 h-3 w-3" /> Declined</Badge>;
      default:
        return null;
    }
  };

  const pendingRequests = bookingRequests.filter(r => r.status === 'pending');
  const processedRequests = bookingRequests.filter(r => r.status !== 'pending');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container py-8">
        <h1 className="mb-2 font-display text-3xl font-bold">Booking Requests</h1>
        <p className="mb-8 text-muted-foreground">
          Review and manage booking requests for your properties.
        </p>

        {bookingRequests.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-muted/50 p-12 text-center">
            <Calendar className="mx-auto h-12 w-12 text-muted-foreground" />
            <p className="mt-4 text-lg text-muted-foreground">
              No booking requests yet.
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              When travelers request to book your properties, they'll appear here.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Pending Requests */}
            {pendingRequests.length > 0 && (
              <section>
                <h2 className="mb-4 font-display text-xl font-semibold">
                  Pending ({pendingRequests.length})
                </h2>
                <div className="space-y-4">
                  {pendingRequests.map(request => {
                    const property = getProperty(request.propertyId);
                    return (
                      <div 
                        key={request.id} 
                        className="rounded-xl border border-border bg-card p-6 shadow-card"
                      >
                        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3">
                              <h3 className="font-semibold">{property?.title || 'Unknown Property'}</h3>
                              {getStatusBadge(request.status)}
                            </div>
                            
                            <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Calendar className="h-4 w-4" />
                                <span>
                                  {format(new Date(request.checkIn), 'MMM d')} - {format(new Date(request.checkOut), 'MMM d, yyyy')}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Users className="h-4 w-4" />
                                <span>{request.guests} guests</span>
                              </div>
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <span className="font-medium text-foreground">{request.guestName}</span>
                              </div>
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Mail className="h-4 w-4" />
                                <span>{request.guestEmail}</span>
                              </div>
                            </div>

                            {request.message && (
                              <div className="mt-4 rounded-lg bg-muted p-3">
                                <div className="flex items-start gap-2">
                                  <MessageSquare className="mt-0.5 h-4 w-4 text-muted-foreground" />
                                  <p className="text-sm">{request.message}</p>
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="flex gap-2 lg:flex-col">
                            <Button 
                              onClick={() => handleStatusUpdate(request.id, 'approved')}
                              className="flex-1 lg:flex-none"
                            >
                              <Check className="mr-2 h-4 w-4" />
                              Approve
                            </Button>
                            <Button 
                              variant="outline"
                              onClick={() => handleStatusUpdate(request.id, 'declined')}
                              className="flex-1 lg:flex-none"
                            >
                              <X className="mr-2 h-4 w-4" />
                              Decline
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* Processed Requests */}
            {processedRequests.length > 0 && (
              <section>
                <h2 className="mb-4 font-display text-xl font-semibold">
                  History ({processedRequests.length})
                </h2>
                <div className="space-y-4">
                  {processedRequests.map(request => {
                    const property = getProperty(request.propertyId);
                    return (
                      <div 
                        key={request.id} 
                        className="rounded-xl border border-border bg-card p-6 shadow-card opacity-75"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-3">
                              <h3 className="font-semibold">{property?.title || 'Unknown Property'}</h3>
                              {getStatusBadge(request.status)}
                            </div>
                            <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
                              <span>{request.guestName}</span>
                              <span>
                                {format(new Date(request.checkIn), 'MMM d')} - {format(new Date(request.checkOut), 'MMM d')}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageBookings;
