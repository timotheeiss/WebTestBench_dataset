import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, MapPin, Users, Bed, Bath, Check, Edit } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Header from '@/components/layout/Header';
import BookingForm from '@/components/property/BookingForm';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

const PropertyDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { properties, userRole } = useApp();
  
  const property = properties.find(p => p.id === id);

  if (!property) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-12 text-center">
          <h1 className="font-display text-2xl font-semibold">Property not found</h1>
          <Link to="/" className="mt-4 inline-block text-primary hover:underline">
            Back to listings
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container py-8">
        {/* Back Button */}
        <Link 
          to="/" 
          className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to listings
        </Link>

        {/* Image Gallery */}
        <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {property.images.slice(0, 3).map((image, index) => (
            <div 
              key={index} 
              className={`relative overflow-hidden rounded-xl ${
                index === 0 ? 'md:col-span-2 md:row-span-2' : ''
              }`}
            >
              <img
                src={image}
                alt={`${property.title} - Photo ${index + 1}`}
                className="h-full w-full object-cover"
                style={{ aspectRatio: index === 0 ? '16/10' : '4/3' }}
              />
            </div>
          ))}
        </div>

        <div className="lg:grid lg:grid-cols-[1fr_380px] lg:gap-12">
          {/* Main Content */}
          <main>
            {/* Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="capitalize">
                    {property.propertyType}
                  </Badge>
                  {property.rating > 0 && (
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-primary text-primary" />
                      <span className="font-medium">{property.rating}</span>
                      <span className="text-muted-foreground">
                        ({property.reviewCount} reviews)
                      </span>
                    </div>
                  )}
                </div>
                <h1 className="mt-2 font-display text-3xl font-bold md:text-4xl">
                  {property.title}
                </h1>
                <div className="mt-2 flex items-center gap-1 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{property.location}</span>
                </div>
              </div>
              
              {userRole === 'owner' && (
                <Button variant="outline" asChild>
                  <Link to={`/edit-listing/${property.id}`}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </Link>
                </Button>
              )}
            </div>

            {/* Quick Stats */}
            <div className="mt-6 flex flex-wrap gap-6">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <span>{property.maxGuests} guests</span>
              </div>
              <div className="flex items-center gap-2">
                <Bed className="h-5 w-5 text-muted-foreground" />
                <span>{property.bedrooms} bedrooms</span>
              </div>
              <div className="flex items-center gap-2">
                <Bath className="h-5 w-5 text-muted-foreground" />
                <span>{property.bathrooms} bathrooms</span>
              </div>
            </div>

            <Separator className="my-8" />

            {/* Description */}
            <section>
              <h2 className="font-display text-xl font-semibold">About this place</h2>
              <p className="mt-4 whitespace-pre-line leading-relaxed text-muted-foreground">
                {property.description}
              </p>
            </section>

            <Separator className="my-8" />

            {/* Amenities */}
            <section>
              <h2 className="font-display text-xl font-semibold">What this place offers</h2>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {property.amenities.map(amenity => (
                  <div key={amenity} className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary/20">
                      <Check className="h-4 w-4 text-secondary" />
                    </div>
                    <span>{amenity}</span>
                  </div>
                ))}
              </div>
            </section>

            <Separator className="my-8" />

            {/* Reviews */}
            <section>
              <h2 className="font-display text-xl font-semibold">
                Reviews {property.reviews.length > 0 && `(${property.reviews.length})`}
              </h2>
              
              {property.reviews.length > 0 ? (
                <div className="mt-4 space-y-6">
                  {property.reviews.map(review => (
                    <div key={review.id} className="rounded-lg bg-muted/50 p-4">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{review.author}</span>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <span className="text-sm">{review.rating}</span>
                        </div>
                      </div>
                      <p className="mt-2 text-muted-foreground">{review.comment}</p>
                      <p className="mt-2 text-sm text-muted-foreground">
                        {format(new Date(review.date), 'MMMM d, yyyy')}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-4 text-muted-foreground">
                  No reviews yet. Be the first to stay here!
                </p>
              )}
            </section>
          </main>

          {/* Booking Form - Desktop */}
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <BookingForm property={property} />
            </div>
          </aside>
        </div>

        {/* Booking Form - Mobile */}
        <div className="mt-8 lg:hidden">
          <BookingForm property={property} />
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
