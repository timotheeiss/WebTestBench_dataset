import { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Header from '@/components/layout/Header';
import PropertyCard from '@/components/property/PropertyCard';
import PropertyFilters, { FilterState } from '@/components/property/PropertyFilters';
import { Input } from '@/components/ui/input';

const Index = () => {
  const { properties } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterState>({
    priceRange: [0, 500],
    guests: null,
    propertyType: 'all',
    sortBy: 'rating'
  });

  const filteredProperties = useMemo(() => {
    let result = properties.filter(property => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
          property.title.toLowerCase().includes(query) ||
          property.location.toLowerCase().includes(query);
        if (!matchesSearch) return false;
      }

      // Price filter
      if (property.price < filters.priceRange[0] || property.price > filters.priceRange[1]) {
        return false;
      }

      // Guests filter
      if (filters.guests && property.maxGuests < filters.guests) {
        return false;
      }

      // Property type filter
      if (filters.propertyType !== 'all' && property.propertyType !== filters.propertyType) {
        return false;
      }

      return true;
    });

    // Sort results
    result.sort((a, b) => {
      switch (filters.sortBy) {
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'rating':
        default:
          return b.rating - a.rating;
      }
    });

    return result;
  }, [properties, searchQuery, filters]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center animate-fade-in">
            <h1 className="font-display text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
              Find Your Perfect
              <span className="block text-primary">Home Away From Home</span>
            </h1>
            <p className="mt-4 text-lg text-muted-foreground md:text-xl">
              Discover unique places to stay from cozy cabins to luxurious villas, 
              all around the world.
            </p>
            
            <div className="relative mx-auto mt-8 max-w-xl">
              <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search destinations, property names..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-14 rounded-full pl-12 pr-6 text-base shadow-soft"
              />
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-secondary/5 blur-3xl" />
      </section>

      {/* Main Content */}
      <section className="container py-12">
        <div className="lg:grid lg:grid-cols-[280px_1fr] lg:gap-8">
          {/* Filters */}
          <aside className="mb-6 lg:mb-0">
            <PropertyFilters filters={filters} onFiltersChange={setFilters} />
          </aside>

          {/* Property Grid */}
          <main>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-display text-2xl font-semibold">
                {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
              </h2>
            </div>

            {filteredProperties.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {filteredProperties.map((property, index) => (
                  <div 
                    key={property.id} 
                    className="animate-slide-up"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <PropertyCard property={property} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-border bg-muted/50 p-12 text-center">
                <p className="text-lg text-muted-foreground">
                  No properties match your filters.
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try adjusting your search criteria.
                </p>
              </div>
            )}
          </main>
        </div>
      </section>
    </div>
  );
};

export default Index;
