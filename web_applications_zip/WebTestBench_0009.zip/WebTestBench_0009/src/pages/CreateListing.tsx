import Header from '@/components/layout/Header';
import PropertyForm from '@/components/property/PropertyForm';

const CreateListing = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container py-8">
        <div className="mx-auto max-w-2xl">
          <h1 className="mb-2 font-display text-3xl font-bold">Create New Listing</h1>
          <p className="mb-8 text-muted-foreground">
            Fill in the details below to list your property for travelers.
          </p>
          
          <PropertyForm mode="create" />
        </div>
      </div>
    </div>
  );
};

export default CreateListing;
