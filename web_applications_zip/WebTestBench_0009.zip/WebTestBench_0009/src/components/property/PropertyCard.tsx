import { Link } from 'react-router-dom';
import { Star, MapPin, Users, Bed } from 'lucide-react';
import { Property } from '@/data/properties';
import { Badge } from '@/components/ui/badge';

interface PropertyCardProps {
  property: Property;
}

const PropertyCard = ({ property }: PropertyCardProps) => {
  return (
    <Link 
      to={`/property/${property.id}`}
      className="group block overflow-hidden rounded-xl bg-card shadow-card card-hover"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={property.images[0]}
          alt={property.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <Badge 
          className="absolute left-3 top-3 bg-background/90 text-foreground backdrop-blur-sm capitalize"
        >
          {property.propertyType}
        </Badge>
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display text-lg font-semibold leading-tight line-clamp-1">
            {property.title}
          </h3>
          {property.rating > 0 && (
            <div className="flex items-center gap-1 text-sm">
              <Star className="h-4 w-4 fill-primary text-primary" />
              <span className="font-medium">{property.rating}</span>
            </div>
          )}
        </div>
        
        <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" />
          <span>{property.location}</span>
        </div>
        
        <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5" />
            <span>{property.maxGuests} guests</span>
          </div>
          <div className="flex items-center gap-1">
            <Bed className="h-3.5 w-3.5" />
            <span>{property.bedrooms} beds</span>
          </div>
        </div>
        
        <div className="mt-4 flex items-baseline gap-1">
          <span className="text-xl font-semibold">${property.price}</span>
          <span className="text-sm text-muted-foreground">/ night</span>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;
