import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, X, Save } from 'lucide-react';
import { Property, PropertyType, propertyTypes } from '@/data/properties';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';

interface PropertyFormProps {
  property?: Property;
  mode: 'create' | 'edit';
}

const COMMON_AMENITIES = [
  'WiFi', 'Kitchen', 'Air Conditioning', 'Parking', 'Pool', 'Hot Tub',
  'Washer', 'Dryer', 'TV', 'BBQ', 'Garden', 'Gym', 'Beach Access',
  'Fireplace', 'Balcony', 'Pet Friendly'
];

const PropertyForm = ({ property, mode }: PropertyFormProps) => {
  const navigate = useNavigate();
  const { addProperty, updateProperty } = useApp();

  const [title, setTitle] = useState(property?.title || '');
  const [location, setLocation] = useState(property?.location || '');
  const [description, setDescription] = useState(property?.description || '');
  const [propertyType, setPropertyType] = useState<PropertyType>(property?.propertyType || 'apartment');
  const [price, setPrice] = useState(property?.price?.toString() || '');
  const [maxGuests, setMaxGuests] = useState(property?.maxGuests?.toString() || '');
  const [bedrooms, setBedrooms] = useState(property?.bedrooms?.toString() || '');
  const [bathrooms, setBathrooms] = useState(property?.bathrooms?.toString() || '');
  const [amenities, setAmenities] = useState<string[]>(property?.amenities || []);
  const [images, setImages] = useState<string[]>(property?.images || ['']);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleAmenity = (amenity: string) => {
    setAmenities(prev =>
      prev.includes(amenity)
        ? prev.filter(a => a !== amenity)
        : [...prev, amenity]
    );
  };

  const addImageField = () => {
    setImages(prev => [...prev, '']);
  };

  const updateImage = (index: number, value: string) => {
    setImages(prev => prev.map((img, i) => i === index ? value : img));
  };

  const removeImage = (index: number) => {
    if (images.length > 1) {
      setImages(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !location || !description || !price || !maxGuests) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    const validImages = images.filter(img => img.trim() !== '');
    if (validImages.length === 0) {
      validImages.push('https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800');
    }

    const propertyData = {
      title,
      location,
      description,
      propertyType,
      price: parseInt(price),
      maxGuests: parseInt(maxGuests),
      bedrooms: parseInt(bedrooms) || 1,
      bathrooms: parseInt(bathrooms) || 1,
      amenities,
      images: validImages
    };

    setTimeout(() => {
      if (mode === 'create') {
        addProperty(propertyData);
        toast({
          title: "Listing created!",
          description: "Your property is now visible to travelers."
        });
      } else if (property) {
        updateProperty(property.id, propertyData);
        toast({
          title: "Listing updated!",
          description: "Your changes have been saved."
        });
      }
      setIsSubmitting(false);
      navigate('/');
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="rounded-xl border border-border bg-card p-6 shadow-card">
        <h2 className="mb-6 font-display text-xl font-semibold">Basic Information</h2>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Property Title *</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Cozy Beach House with Ocean View"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Location *</Label>
            <Input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g., Malibu, California"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Property Type *</Label>
            <Select value={propertyType} onValueChange={(v) => setPropertyType(v as PropertyType)}>
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover">
                {propertyTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Description *</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your property, what makes it special, and what guests can expect..."
              rows={5}
              required
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-card">
        <h2 className="mb-6 font-display text-xl font-semibold">Details & Pricing</h2>
        
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>Price per Night ($) *</Label>
            <Input
              type="number"
              min={1}
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="150"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Max Guests *</Label>
            <Input
              type="number"
              min={1}
              max={20}
              value={maxGuests}
              onChange={(e) => setMaxGuests(e.target.value)}
              placeholder="4"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Bedrooms</Label>
            <Input
              type="number"
              min={0}
              value={bedrooms}
              onChange={(e) => setBedrooms(e.target.value)}
              placeholder="2"
            />
          </div>

          <div className="space-y-2">
            <Label>Bathrooms</Label>
            <Input
              type="number"
              min={0}
              step={0.5}
              value={bathrooms}
              onChange={(e) => setBathrooms(e.target.value)}
              placeholder="1"
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-card">
        <h2 className="mb-6 font-display text-xl font-semibold">Amenities</h2>
        
        <div className="flex flex-wrap gap-2">
          {COMMON_AMENITIES.map(amenity => (
            <button
              key={amenity}
              type="button"
              onClick={() => toggleAmenity(amenity)}
              className={`filter-chip ${amenities.includes(amenity) ? 'active' : ''}`}
            >
              {amenity}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-card">
        <h2 className="mb-6 font-display text-xl font-semibold">Photos</h2>
        
        <div className="space-y-3">
          {images.map((image, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={image}
                onChange={(e) => updateImage(index, e.target.value)}
                placeholder="https://example.com/image.jpg"
              />
              {images.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => removeImage(index)}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          
          <Button
            type="button"
            variant="outline"
            onClick={addImageField}
            className="w-full"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Another Image
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate(-1)}
          className="flex-1"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isSubmitting}
          className="flex-1"
        >
          {isSubmitting ? (
            "Saving..."
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              {mode === 'create' ? 'Create Listing' : 'Save Changes'}
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default PropertyForm;
