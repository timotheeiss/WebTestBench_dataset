import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Property, BookingRequest, properties as initialProperties, initialBookingRequests } from '@/data/properties';

type UserRole = 'traveler' | 'owner';

interface AppContextType {
  properties: Property[];
  bookingRequests: BookingRequest[];
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  addProperty: (property: Omit<Property, 'id' | 'rating' | 'reviewCount' | 'reviews' | 'availableDates' | 'ownerId'>) => void;
  updateProperty: (id: string, property: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  addBookingRequest: (request: Omit<BookingRequest, 'id' | 'status' | 'createdAt'>) => void;
  updateBookingStatus: (id: string, status: BookingRequest['status']) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [properties, setProperties] = useState<Property[]>(initialProperties);
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>(initialBookingRequests);
  const [userRole, setUserRole] = useState<UserRole>('traveler');

  const generateAvailableDates = (): string[] => {
    const dates: string[] = [];
    const today = new Date();
    for (let i = 1; i <= 90; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      if (Math.random() > 0.2) {
        dates.push(date.toISOString().split('T')[0]);
      }
    }
    return dates;
  };

  const addProperty = (property: Omit<Property, 'id' | 'rating' | 'reviewCount' | 'reviews' | 'availableDates' | 'ownerId'>) => {
    const newProperty: Property = {
      ...property,
      id: `prop-${Date.now()}`,
      rating: 0,
      reviewCount: 0,
      reviews: [],
      availableDates: generateAvailableDates(),
      ownerId: 'owner1'
    };
    setProperties(prev => [...prev, newProperty]);
  };

  const updateProperty = (id: string, updates: Partial<Property>) => {
    setProperties(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deleteProperty = (id: string) => {
    setProperties(prev => prev.filter(p => p.id !== id));
  };

  const addBookingRequest = (request: Omit<BookingRequest, 'id' | 'status' | 'createdAt'>) => {
    const newRequest: BookingRequest = {
      ...request,
      id: `booking-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0]
    };
    setBookingRequests(prev => [...prev, newRequest]);
  };

  const updateBookingStatus = (id: string, status: BookingRequest['status']) => {
    setBookingRequests(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  };

  return (
    <AppContext.Provider value={{
      properties,
      bookingRequests,
      userRole,
      setUserRole,
      addProperty,
      updateProperty,
      deleteProperty,
      addBookingRequest,
      updateBookingStatus
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
