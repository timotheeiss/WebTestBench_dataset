import { useState, useCallback } from 'react';
import { Rule, TestOrder, TestResult } from '@/types/rule';
import { defaultRules } from '@/data/defaultRules';

export function useRules() {
  const [rules, setRules] = useState<Rule[]>(defaultRules);

  const addRule = useCallback((rule: Omit<Rule, 'id' | 'createdAt'>) => {
    const newRule: Rule = {
      ...rule,
      id: crypto.randomUUID(),
      createdAt: new Date(),
    };
    setRules((prev) => [...prev, newRule]);
  }, []);

  const updateRule = useCallback((id: string, updates: Partial<Omit<Rule, 'id' | 'createdAt'>>) => {
    setRules((prev) =>
      prev.map((rule) => (rule.id === id ? { ...rule, ...updates } : rule))
    );
  }, []);

  const deleteRule = useCallback((id: string) => {
    setRules((prev) => prev.filter((rule) => rule.id !== id));
  }, []);

  const toggleRule = useCallback((id: string) => {
    setRules((prev) =>
      prev.map((rule) =>
        rule.id === id ? { ...rule, isActive: !rule.isActive } : rule
      )
    );
  }, []);

  const testOrder = useCallback(
    (order: TestOrder): TestResult[] => {
      return rules
        .filter((rule) => rule.isActive)
        .map((rule) => {
          let triggered = false;
          let reason = '';

          if (rule.conditionType === 'amount_threshold') {
            const threshold = parseFloat(rule.conditionValue);
            triggered = order.amount > threshold;
            reason = triggered
              ? `Amount $${order.amount.toLocaleString()} exceeds threshold of $${threshold.toLocaleString()}`
              : `Amount $${order.amount.toLocaleString()} is within threshold of $${threshold.toLocaleString()}`;
          } else if (rule.conditionType === 'blocked_account') {
            const blockedIds = rule.conditionValue.split(',').map((id) => id.trim());
            triggered = blockedIds.includes(order.accountId);
            reason = triggered
              ? `Account "${order.accountId}" is in the blocked list`
              : `Account "${order.accountId}" is not blocked`;
          }

          return {
            ruleId: rule.id,
            ruleName: rule.name,
            triggered,
            reason,
          };
        });
    },
    [rules]
  );

  return {
    rules,
    addRule,
    updateRule,
    deleteRule,
    toggleRule,
    testOrder,
  };
}
