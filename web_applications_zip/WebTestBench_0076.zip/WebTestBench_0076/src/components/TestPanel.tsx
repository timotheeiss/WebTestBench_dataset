import { useState } from 'react';
import { TestOrder, TestResult } from '@/types/rule';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TestPanelProps {
  onTest: (order: TestOrder) => TestResult[];
}

export function TestPanel({ onTest }: TestPanelProps) {
  const [amount, setAmount] = useState('');
  const [accountId, setAccountId] = useState('');
  const [results, setResults] = useState<TestResult[]>([]);
  const [hasRun, setHasRun] = useState(false);

  const handleTest = () => {
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || !accountId.trim()) return;

    const testResults = onTest({
      amount: parsedAmount,
      accountId: accountId.trim(),
    });

    setResults(testResults);
    setHasRun(true);
  };

  const triggeredCount = results.filter((r) => r.triggered).length;

  return (
    <Card className="glass-card border-border">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Play className="w-5 h-5 text-primary" />
          Test Transaction
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="testAmount">Order Amount ($)</Label>
            <Input
              id="testAmount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g., 15000"
              className="bg-input border-border font-mono"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="testAccountId">Account ID</Label>
            <Input
              id="testAccountId"
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              placeholder="e.g., ACC001"
              className="bg-input border-border font-mono"
            />
          </div>
        </div>

        <Button
          onClick={handleTest}
          disabled={!amount || !accountId.trim()}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Play className="w-4 h-4 mr-2" />
          Run Test
        </Button>

        <AnimatePresence mode="wait">
          {hasRun && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3 pt-4 border-t border-border"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-sm text-muted-foreground">
                  Test Results
                </h4>
                <Badge
                  variant={triggeredCount > 0 ? 'destructive' : 'default'}
                  className={triggeredCount === 0 ? 'bg-success text-success-foreground' : ''}
                >
                  {triggeredCount} rule{triggeredCount !== 1 ? 's' : ''} triggered
                </Badge>
              </div>

              <div className="space-y-2">
                {results.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">
                    No active rules to test against
                  </p>
                ) : (
                  results.map((result) => (
                    <motion.div
                      key={result.ruleId}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`p-3 rounded-lg border ${
                        result.triggered
                          ? 'bg-destructive/10 border-destructive/30'
                          : 'bg-success/10 border-success/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {result.triggered ? (
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-success mt-0.5 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">
                            {result.ruleName}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {result.reason}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
