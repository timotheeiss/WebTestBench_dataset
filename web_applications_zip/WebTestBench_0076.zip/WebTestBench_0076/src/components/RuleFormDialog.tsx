import { useState, useEffect } from 'react';
import { Rule, ConditionType } from '@/types/rule';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

interface RuleFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingRule?: Rule | null;
  onSave: (rule: Omit<Rule, 'id' | 'createdAt'>) => void;
  onUpdate: (id: string, updates: Partial<Omit<Rule, 'id' | 'createdAt'>>) => void;
}

export function RuleFormDialog({
  open,
  onOpenChange,
  editingRule,
  onSave,
  onUpdate,
}: RuleFormDialogProps) {
  const [name, setName] = useState('');
  const [conditionType, setConditionType] = useState<ConditionType>('amount_threshold');
  const [conditionValue, setConditionValue] = useState('');
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    if (editingRule) {
      setName(editingRule.name);
      setConditionType(editingRule.conditionType);
      setConditionValue(editingRule.conditionValue);
      setIsActive(editingRule.isActive);
    } else {
      setName('');
      setConditionType('amount_threshold');
      setConditionValue('');
      setIsActive(true);
    }
  }, [editingRule, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !conditionValue.trim()) return;

    const ruleData = {
      name: name.trim(),
      conditionType,
      conditionValue: conditionValue.trim(),
      isActive,
    };

    if (editingRule) {
      onUpdate(editingRule.id, ruleData);
    } else {
      onSave(ruleData);
    }

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            {editingRule ? 'Edit Rule' : 'Create New Rule'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Rule Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., High Value Transaction Block"
              className="bg-input border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="conditionType">Condition Type</Label>
            <Select
              value={conditionType}
              onValueChange={(val) => setConditionType(val as ConditionType)}
            >
              <SelectTrigger className="bg-input border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="amount_threshold">Amount Threshold</SelectItem>
                <SelectItem value="blocked_account">Blocked Account IDs</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="conditionValue">
              {conditionType === 'amount_threshold'
                ? 'Threshold Amount ($)'
                : 'Account IDs (comma-separated)'}
            </Label>
            <Input
              id="conditionValue"
              value={conditionValue}
              onChange={(e) => setConditionValue(e.target.value)}
              placeholder={
                conditionType === 'amount_threshold'
                  ? 'e.g., 10000'
                  : 'e.g., ACC001, ACC002'
              }
              className="bg-input border-border font-mono"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="isActive">Active Status</Label>
            <Switch
              id="isActive"
              checked={isActive}
              onCheckedChange={setIsActive}
              className="data-[state=checked]:bg-success"
            />
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
              {editingRule ? 'Save Changes' : 'Create Rule'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
