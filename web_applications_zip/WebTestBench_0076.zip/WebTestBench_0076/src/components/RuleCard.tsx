import { Rule } from '@/types/rule';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Pencil, Trash2, DollarSign, UserX } from 'lucide-react';
import { motion } from 'framer-motion';

interface RuleCardProps {
  rule: Rule;
  onEdit: (rule: Rule) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string) => void;
}

export function RuleCard({ rule, onEdit, onDelete, onToggle }: RuleCardProps) {
  const isAmountRule = rule.conditionType === 'amount_threshold';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -16 }}
      className="glass-card rounded-lg p-5 hover:border-primary/30 transition-all duration-300"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1 min-w-0">
          <div
            className={`p-2.5 rounded-lg ${
              isAmountRule
                ? 'bg-primary/10 text-primary'
                : 'bg-destructive/10 text-destructive'
            }`}
          >
            {isAmountRule ? (
              <DollarSign className="w-5 h-5" />
            ) : (
              <UserX className="w-5 h-5" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="font-semibold text-foreground truncate">{rule.name}</h3>
              <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                {rule.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>

            <p className="text-sm text-muted-foreground mb-1">
              {isAmountRule ? 'Amount Threshold' : 'Blocked Accounts'}
            </p>

            <p className="text-sm font-mono text-foreground/80 truncate">
              {isAmountRule
                ? `> $${parseFloat(rule.conditionValue).toLocaleString()}`
                : rule.conditionValue}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Switch
            checked={rule.isActive}
            onCheckedChange={() => onToggle(rule.id)}
            className="data-[state=checked]:bg-success"
          />

          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit(rule)}
            className="text-muted-foreground hover:text-foreground hover:bg-accent"
          >
            <Pencil className="w-4 h-4" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(rule.id)}
            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
