export type ConditionType = 'amount_threshold' | 'blocked_account';

export interface Rule {
  id: string;
  name: string;
  conditionType: ConditionType;
  conditionValue: string; // For amount_threshold: number, for blocked_account: comma-separated IDs
  isActive: boolean;
  createdAt: Date;
}

export interface TestOrder {
  amount: number;
  accountId: string;
}

export interface TestResult {
  ruleId: string;
  ruleName: string;
  triggered: boolean;
  reason: string;
}
