import { Rule } from '@/types/rule';

export const defaultRules: Rule[] = [
  {
    id: '1',
    name: 'High Value Transaction Block',
    conditionType: 'amount_threshold',
    conditionValue: '10000',
    isActive: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Suspicious Accounts',
    conditionType: 'blocked_account',
    conditionValue: 'ACC001,ACC002,ACC003',
    isActive: true,
    createdAt: new Date('2024-02-20'),
  },
  {
    id: '3',
    name: 'Very High Value Alert',
    conditionType: 'amount_threshold',
    conditionValue: '50000',
    isActive: false,
    createdAt: new Date('2024-03-10'),
  },
  {
    id: '4',
    name: 'Flagged Merchant Accounts',
    conditionType: 'blocked_account',
    conditionValue: 'MERCH_X,MERCH_Y',
    isActive: true,
    createdAt: new Date('2024-04-05'),
  },
];
