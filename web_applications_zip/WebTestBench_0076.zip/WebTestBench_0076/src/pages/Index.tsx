import { useState } from 'react';
import { Rule } from '@/types/rule';
import { useRules } from '@/hooks/useRules';
import { RuleCard } from '@/components/RuleCard';
import { RuleFormDialog } from '@/components/RuleFormDialog';
import { TestPanel } from '@/components/TestPanel';
import { DeleteConfirmDialog } from '@/components/DeleteConfirmDialog';
import { Button } from '@/components/ui/button';
import { Plus, Shield, AlertCircle } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const Index = () => {
  const { rules, addRule, updateRule, deleteRule, toggleRule, testOrder } = useRules();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [deletingRule, setDeletingRule] = useState<Rule | null>(null);

  const handleEdit = (rule: Rule) => {
    setEditingRule(rule);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    const rule = rules.find((r) => r.id === id);
    if (rule) setDeletingRule(rule);
  };

  const confirmDelete = () => {
    if (deletingRule) {
      deleteRule(deletingRule.id);
      setDeletingRule(null);
    }
  };

  const handleFormClose = (open: boolean) => {
    setIsFormOpen(open);
    if (!open) setEditingRule(null);
  };

  const activeRulesCount = rules.filter((r) => r.isActive).length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-xl sticky top-0 z-40">
        <div className="container max-w-6xl py-4 px-4 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10 glow-primary">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Risk Control</h1>
                <p className="text-sm text-muted-foreground hidden sm:block">
                  Payment System Rules Manager
                </p>
              </div>
            </div>

            <Button
              onClick={() => setIsFormOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Add Rule</span>
              <span className="sm:hidden">Add</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-6xl py-6 px-4 sm:px-6 space-y-6">
        {/* Stats Bar */}
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-card border border-border">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
            <span className="text-muted-foreground">
              {rules.length} total rules
            </span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-card border border-border">
            <div className="w-2 h-2 rounded-full bg-success" />
            <span className="text-muted-foreground">
              {activeRulesCount} active
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Rules List */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-muted-foreground" />
              Rules
            </h2>

            <AnimatePresence mode="popLayout">
              {rules.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass-card rounded-lg p-8 text-center"
                >
                  <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">
                    No rules configured yet. Create your first rule to get started.
                  </p>
                </motion.div>
              ) : (
                <div className="space-y-3">
                  {rules.map((rule) => (
                    <RuleCard
                      key={rule.id}
                      rule={rule}
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onToggle={toggleRule}
                    />
                  ))}
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* Test Panel */}
          <div className="lg:col-span-1">
            <TestPanel onTest={testOrder} />
          </div>
        </div>
      </main>

      {/* Dialogs */}
      <RuleFormDialog
        open={isFormOpen}
        onOpenChange={handleFormClose}
        editingRule={editingRule}
        onSave={addRule}
        onUpdate={updateRule}
      />

      <DeleteConfirmDialog
        open={!!deletingRule}
        onOpenChange={(open) => !open && setDeletingRule(null)}
        onConfirm={confirmDelete}
        ruleName={deletingRule?.name ?? ''}
      />
    </div>
  );
};

export default Index;
