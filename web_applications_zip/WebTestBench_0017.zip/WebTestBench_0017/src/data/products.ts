export type Category = 'cameras' | 'monitors' | 'vacuums';

export type PriceRange = 'budget' | 'mid-range' | 'premium' | 'luxury';

export interface ProductRatings {
  design: number;
  performance: number;
  value: number;
  features: number;
  build: number;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: Category;
  price: number;
  priceRange: PriceRange;
  image: string;
  ratings: ProductRatings;
  overallScore: number;
  verdict: string;
  specs: Record<string, string>;
  pros: string[];
  cons: string[];
  dateAdded: string;
}

export const products: Product[] = [
  {
    id: 'sony-a7iv',
    name: 'Sony A7 IV',
    brand: 'Sony',
    category: 'cameras',
    price: 2499,
    priceRange: 'premium',
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&q=80',
    ratings: { design: 8.5, performance: 9.2, value: 8.0, features: 9.0, build: 8.8 },
    overallScore: 8.7,
    verdict: 'The Sony A7 IV sets a new standard for hybrid full-frame cameras, delivering exceptional image quality and video capabilities that will satisfy both photographers and videographers alike.',
    specs: {
      'Sensor': '33MP Full-Frame CMOS',
      'Video': '4K 60p, 10-bit 4:2:2',
      'AF Points': '759 Phase Detection',
      'ISO Range': '100-51200',
      'Weight': '658g',
      'Battery Life': '580 shots',
    },
    pros: ['Excellent autofocus system', 'Great low-light performance', 'Versatile video features'],
    cons: ['Rolling shutter in video', 'Complex menu system', 'Premium pricing'],
    dateAdded: '2024-01-15',
  },
  {
    id: 'canon-r6ii',
    name: 'Canon EOS R6 Mark II',
    brand: 'Canon',
    category: 'cameras',
    price: 2499,
    priceRange: 'premium',
    image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=600&q=80',
    ratings: { design: 8.8, performance: 9.0, value: 8.2, features: 8.8, build: 9.0 },
    overallScore: 8.8,
    verdict: 'Canon delivers a refined hybrid camera with class-leading autofocus and impressive video capabilities, making it ideal for content creators and professional photographers.',
    specs: {
      'Sensor': '24.2MP Full-Frame CMOS',
      'Video': '4K 60p, 6K RAW',
      'AF Points': '1053 Dual Pixel',
      'ISO Range': '100-102400',
      'Weight': '670g',
      'Battery Life': '760 shots',
    },
    pros: ['Best-in-class autofocus', 'Excellent ergonomics', 'Strong battery life'],
    cons: ['Lower resolution sensor', 'Expensive accessories', 'Limited weather sealing'],
    dateAdded: '2024-02-20',
  },
  {
    id: 'fujifilm-xh2s',
    name: 'Fujifilm X-H2S',
    brand: 'Fujifilm',
    category: 'cameras',
    price: 2499,
    priceRange: 'premium',
    image: 'https://images.unsplash.com/photo-1581591524425-c7e0978865fc?w=600&q=80',
    ratings: { design: 8.2, performance: 9.4, value: 8.5, features: 9.2, build: 8.5 },
    overallScore: 8.8,
    verdict: 'The X-H2S is Fujifilm\'s fastest and most capable camera ever, with groundbreaking video specs and a unique aesthetic that sets it apart from full-frame competitors.',
    specs: {
      'Sensor': '26.1MP APS-C X-Trans',
      'Video': '6.2K 30p, 4K 120p',
      'AF Points': '425 Phase Detection',
      'ISO Range': '160-12800',
      'Weight': '660g',
      'Battery Life': '580 shots',
    },
    pros: ['Incredible video capabilities', 'Unique color science', 'Fast burst shooting'],
    cons: ['APS-C sensor size', 'Learning curve for film simulations', 'Overheating in long recordings'],
    dateAdded: '2024-01-08',
  },
  {
    id: 'lg-27gp950',
    name: 'LG 27GP950-B',
    brand: 'LG',
    category: 'monitors',
    price: 799,
    priceRange: 'premium',
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=600&q=80',
    ratings: { design: 8.5, performance: 9.3, value: 7.8, features: 9.0, build: 8.5 },
    overallScore: 8.6,
    verdict: 'The LG 27GP950-B is one of the best 4K gaming monitors available, offering exceptional HDR performance and fast response times that make it ideal for next-gen gaming.',
    specs: {
      'Resolution': '3840 x 2160 (4K)',
      'Panel': 'Nano IPS',
      'Refresh Rate': '160Hz',
      'Response Time': '1ms GTG',
      'HDR': 'DisplayHDR 600',
      'Connectivity': 'HDMI 2.1, DisplayPort 1.4',
    },
    pros: ['Excellent 4K gaming performance', 'HDMI 2.1 support', 'Great color accuracy'],
    cons: ['Limited HDR brightness', 'No USB-C', 'Pricey for the size'],
    dateAdded: '2024-03-01',
  },
  {
    id: 'dell-aw3423dwf',
    name: 'Dell Alienware AW3423DWF',
    brand: 'Dell',
    category: 'monitors',
    price: 1099,
    priceRange: 'luxury',
    image: 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600&q=80',
    ratings: { design: 9.0, performance: 9.5, value: 8.5, features: 8.8, build: 9.0 },
    overallScore: 9.0,
    verdict: 'The AW3423DWF brings QD-OLED technology to ultrawide gaming with stunning colors, perfect blacks, and incredibly fast response times that redefine what a gaming monitor can be.',
    specs: {
      'Resolution': '3440 x 1440 (UWQHD)',
      'Panel': 'QD-OLED',
      'Refresh Rate': '165Hz',
      'Response Time': '0.1ms GTG',
      'HDR': 'DisplayHDR True Black 400',
      'Connectivity': 'HDMI 2.0, DisplayPort 1.4',
    },
    pros: ['Stunning QD-OLED image quality', 'Perfect blacks and contrast', 'Ultra-fast response'],
    cons: ['Potential burn-in risk', 'No HDMI 2.1', 'Aggressive anti-glare coating'],
    dateAdded: '2024-02-15',
  },
  {
    id: 'asus-pg32ucdm',
    name: 'ASUS ROG Swift PG32UCDM',
    brand: 'ASUS',
    category: 'monitors',
    price: 1299,
    priceRange: 'luxury',
    image: 'https://images.unsplash.com/photo-1616763355603-9755a640a287?w=600&q=80',
    ratings: { design: 8.8, performance: 9.2, value: 7.5, features: 9.5, build: 9.0 },
    overallScore: 8.8,
    verdict: 'ASUS combines 4K resolution with OLED technology in a 32-inch package, delivering exceptional image quality for both gaming and creative work.',
    specs: {
      'Resolution': '3840 x 2160 (4K)',
      'Panel': 'WOLED',
      'Refresh Rate': '240Hz',
      'Response Time': '0.03ms GTG',
      'HDR': 'DisplayHDR True Black 400',
      'Connectivity': 'HDMI 2.1, DisplayPort 1.4, USB-C',
    },
    pros: ['4K OLED perfection', '240Hz refresh rate', 'Excellent connectivity'],
    cons: ['Very expensive', 'Burn-in concerns', 'Limited availability'],
    dateAdded: '2024-03-10',
  },
  {
    id: 'dyson-v15',
    name: 'Dyson V15 Detect',
    brand: 'Dyson',
    category: 'vacuums',
    price: 749,
    priceRange: 'luxury',
    image: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=600&q=80',
    ratings: { design: 9.5, performance: 9.2, value: 7.0, features: 9.8, build: 9.2 },
    overallScore: 8.9,
    verdict: 'The Dyson V15 Detect is the most advanced cordless vacuum we\'ve tested, with innovative laser dust detection and intelligent suction adjustment that delivers exceptional cleaning.',
    specs: {
      'Suction Power': '230 AW',
      'Runtime': 'Up to 60 minutes',
      'Bin Capacity': '0.76L',
      'Weight': '3.1kg',
      'Filtration': 'Whole-machine HEPA',
      'Display': 'LCD Piezo sensor',
    },
    pros: ['Laser reveals hidden dust', 'Excellent suction power', 'Scientific dust measurement'],
    cons: ['Very expensive', 'Heavy for extended use', 'Small dustbin'],
    dateAdded: '2024-01-20',
  },
  {
    id: 'samsung-jet90',
    name: 'Samsung Bespoke Jet',
    brand: 'Samsung',
    category: 'vacuums',
    price: 649,
    priceRange: 'premium',
    image: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=600&q=80',
    ratings: { design: 9.0, performance: 8.5, value: 8.0, features: 8.8, build: 8.5 },
    overallScore: 8.6,
    verdict: 'Samsung\'s Bespoke Jet offers a compelling alternative to Dyson with its all-in-one clean station that automatically empties the dustbin.',
    specs: {
      'Suction Power': '210 AW',
      'Runtime': 'Up to 60 minutes',
      'Bin Capacity': '0.5L',
      'Weight': '2.8kg',
      'Filtration': '5-layer HEPA',
      'Display': 'LED indicators',
    },
    pros: ['Self-emptying station', 'Lightweight design', 'Good value for features'],
    cons: ['Smaller dustbin', 'Less powerful than Dyson', 'Accessories cost extra'],
    dateAdded: '2024-02-28',
  },
  {
    id: 'roborock-s8pro',
    name: 'Roborock S8 Pro Ultra',
    brand: 'Roborock',
    category: 'vacuums',
    price: 1599,
    priceRange: 'luxury',
    image: 'https://images.unsplash.com/photo-1603618090554-0df40bb5e4c7?w=600&q=80',
    ratings: { design: 8.5, performance: 9.0, value: 7.5, features: 9.5, build: 8.8 },
    overallScore: 8.7,
    verdict: 'The Roborock S8 Pro Ultra is the ultimate hands-free cleaning solution, combining powerful vacuuming and mopping with a self-maintaining dock.',
    specs: {
      'Suction Power': '6000 Pa',
      'Runtime': 'Up to 180 minutes',
      'Dustbin': '350ml (auto-empty)',
      'Water Tank': '200ml',
      'Navigation': 'LiDAR + 3D',
      'Dock Features': 'Auto-empty, mop wash, refill',
    },
    pros: ['Truly hands-free operation', 'Excellent navigation', 'Great vacuuming and mopping'],
    cons: ['Very expensive', 'Large dock footprint', 'Complex setup'],
    dateAdded: '2024-03-05',
  },
];

export const categories: { id: Category; name: string; description: string }[] = [
  { id: 'cameras', name: 'Cameras', description: 'Mirrorless, DSLR, and compact cameras for every skill level' },
  { id: 'monitors', name: 'Monitors', description: 'Gaming, professional, and ultrawide displays' },
  { id: 'vacuums', name: 'Vacuums', description: 'Cordless, robot, and traditional vacuum cleaners' },
];

export const priceRanges: { id: PriceRange; name: string; min: number; max: number }[] = [
  { id: 'budget', name: 'Budget', min: 0, max: 300 },
  { id: 'mid-range', name: 'Mid-Range', min: 300, max: 700 },
  { id: 'premium', name: 'Premium', min: 700, max: 1200 },
  { id: 'luxury', name: 'Luxury', min: 1200, max: Infinity },
];

export function getScoreColor(score: number): string {
  if (score >= 9) return 'rating-excellent';
  if (score >= 8) return 'rating-good';
  if (score >= 7) return 'rating-average';
  if (score >= 5) return 'rating-poor';
  return 'rating-bad';
}

export function getScoreBgClass(score: number): string {
  if (score >= 9) return 'bg-rating-excellent text-white';
  if (score >= 8) return 'bg-rating-good text-white';
  if (score >= 7) return 'bg-rating-average text-foreground';
  if (score >= 5) return 'bg-rating-poor text-white';
  return 'bg-rating-bad text-white';
}
