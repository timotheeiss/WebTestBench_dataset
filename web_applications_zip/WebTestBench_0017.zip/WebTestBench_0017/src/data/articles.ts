export type ArticleType = 'review' | 'comparison' | 'best-of';

export interface Article {
  id: string;
  title: string;
  type: ArticleType;
  excerpt: string;
  content: string;
  productIds: string[];
  category: string;
  author: string;
  datePublished: string;
  readTime: number;
  image: string;
  featured?: boolean;
}

export const articles: Article[] = [
  {
    id: 'best-mirrorless-cameras-2024',
    title: 'The Best Mirrorless Cameras of 2024',
    type: 'best-of',
    excerpt: 'We\'ve tested dozens of mirrorless cameras to find the best options for every type of photographer and budget.',
    content: `After months of testing, we've identified the top mirrorless cameras available today. Whether you're a professional looking for the ultimate tool or a beginner wanting to step up from a smartphone, there's a camera here for you.

## Our Testing Process

We evaluate cameras across multiple scenarios: studio portraits, landscape photography, low-light events, and video production. Each camera is used for at least two weeks before we make our final assessments.

## The Winners

Our top pick for most people is the Canon EOS R6 Mark II. It offers the best balance of image quality, autofocus performance, and usability. The Sony A7 IV comes in as a close second, particularly for those who prioritize video features.

For enthusiasts who want something different, the Fujifilm X-H2S offers unique color science and exceptional video capabilities in a more compact APS-C package.

## Key Takeaways

The mirrorless camera market is incredibly competitive right now. All three of our top picks deliver exceptional image quality and reliable autofocus. Your choice should come down to ergonomics, lens ecosystem, and specific feature priorities.`,
    productIds: ['canon-r6ii', 'sony-a7iv', 'fujifilm-xh2s'],
    category: 'cameras',
    author: 'Sarah Chen',
    datePublished: '2024-03-15',
    readTime: 12,
    image: 'https://images.unsplash.com/photo-1452780212940-6f5c0d14d848?w=1200&q=80',
    featured: true,
  },
  {
    id: 'sony-a7iv-review',
    title: 'Sony A7 IV Review: The New Hybrid Standard',
    type: 'review',
    excerpt: 'Sony\'s latest full-frame camera raises the bar for hybrid shooters with improved autofocus and video capabilities.',
    content: `The Sony A7 IV represents a significant evolution in the Alpha lineup, addressing many of the complaints from the A7 III while adding features that were previously reserved for higher-end models.

## Design and Build

Sony has refined the ergonomics with a deeper grip and improved button layout. The new menu system is a welcome change, making navigation much more intuitive than previous generations.

## Image Quality

The new 33MP sensor delivers excellent detail and dynamic range. Colors are natural and pleasing, with improved skin tones compared to the A7 III.

## Autofocus Performance

The real-time tracking and eye AF are best-in-class. Whether you're shooting wildlife, sports, or portraits, the camera locks on and doesn't let go.

## Video Capabilities

4K 60p with 10-bit 4:2:2 internal recording makes this a serious video tool. The rolling shutter is still present but improved from the A7 III.

## Verdict

The Sony A7 IV is the camera to beat in the hybrid full-frame category. It excels at everything and only falters in a few edge cases.`,
    productIds: ['sony-a7iv'],
    category: 'cameras',
    author: 'Marcus Johnson',
    datePublished: '2024-01-20',
    readTime: 15,
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200&q=80',
  },
  {
    id: 'canon-vs-sony-2024',
    title: 'Canon R6 II vs Sony A7 IV: The Ultimate Showdown',
    type: 'comparison',
    excerpt: 'We pit Canon and Sony\'s best hybrid cameras against each other to determine which system deserves your investment.',
    content: `The Canon EOS R6 Mark II and Sony A7 IV are the two most popular hybrid cameras on the market. Let's break down how they compare.

## Autofocus

Both cameras offer excellent autofocus, but Canon's Dual Pixel CMOS AF II edges ahead with faster acquisition and better subject tracking. Sony's eye AF is still phenomenal, but Canon has closed the gap.

## Image Quality

Sony's 33MP sensor provides more resolution, while Canon's 24MP sensor offers slightly better high-ISO performance. In practice, both deliver professional-quality results.

## Video Features

This is where it gets interesting. Canon offers 6K oversampled 4K and internal RAW recording. Sony counters with better rolling shutter and more flexible codec options.

## Ergonomics

Canon wins for photographers familiar with DSLR handling. Sony's menu system has improved but Canon's is more intuitive out of the box.

## Lens Ecosystem

Both systems now have mature lens lineups. Canon's RF lenses are generally more affordable at the high end, while Sony offers more third-party options.

## The Verdict

Choose Canon if you prioritize autofocus and ergonomics. Choose Sony if resolution and video flexibility matter more.`,
    productIds: ['canon-r6ii', 'sony-a7iv'],
    category: 'cameras',
    author: 'Sarah Chen',
    datePublished: '2024-02-28',
    readTime: 10,
    image: 'https://images.unsplash.com/photo-1510127034890-ba27508e9f1c?w=1200&q=80',
    featured: true,
  },
  {
    id: 'best-gaming-monitors-2024',
    title: 'The Best Gaming Monitors of 2024',
    type: 'best-of',
    excerpt: 'From budget 1080p panels to stunning 4K OLEDs, we\'ve found the best gaming monitors for every setup.',
    content: `Gaming monitor technology has advanced rapidly, with OLED panels finally reaching affordable price points and high refresh rates becoming standard.

## Our Top Picks

The Dell Alienware AW3423DWF is our overall winner. Its QD-OLED panel delivers colors and contrast that no LCD can match, with gaming performance to back it up.

For 4K gaming, the LG 27GP950-B offers the best balance of resolution, speed, and HDR performance. HDMI 2.1 makes it perfect for next-gen console gaming.

The ASUS ROG Swift PG32UCDM represents the pinnacle of gaming displays with 4K OLED at 240Hz, but the price reflects its cutting-edge nature.

## What to Consider

Resolution, refresh rate, and panel type are the three main factors. OLED panels offer the best image quality but come with burn-in concerns and higher prices.`,
    productIds: ['dell-aw3423dwf', 'lg-27gp950', 'asus-pg32ucdm'],
    category: 'monitors',
    author: 'Alex Rivera',
    datePublished: '2024-03-10',
    readTime: 14,
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=1200&q=80',
    featured: true,
  },
  {
    id: 'best-cordless-vacuums-2024',
    title: 'The Best Cordless Vacuums of 2024',
    type: 'best-of',
    excerpt: 'Cordless vacuums have finally caught up to their corded counterparts. Here are our top picks.',
    content: `Cordless vacuum technology has matured to the point where they can genuinely replace traditional vacuums for most homes.

## The Premium Choice

The Dyson V15 Detect remains our top pick for those who want the absolute best. Its laser dust detection and intelligent suction adjustment deliver a cleaning experience unlike any other.

## Best Value

The Samsung Bespoke Jet offers nearly all of Dyson's features at a lower price, with the added benefit of a self-emptying station included.

## For Hands-Free Cleaning

The Roborock S8 Pro Ultra is the best robot vacuum we've tested, combining powerful vacuuming, effective mopping, and a self-maintaining dock that handles everything automatically.`,
    productIds: ['dyson-v15', 'samsung-jet90', 'roborock-s8pro'],
    category: 'vacuums',
    author: 'Emily Zhang',
    datePublished: '2024-03-08',
    readTime: 11,
    image: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=1200&q=80',
  },
  {
    id: 'dyson-v15-vs-samsung-jet',
    title: 'Dyson V15 vs Samsung Bespoke Jet: Which Is Worth It?',
    type: 'comparison',
    excerpt: 'Two premium cordless vacuums battle it out. Is the Dyson\'s laser tech worth the extra cost?',
    content: `Both the Dyson V15 Detect and Samsung Bespoke Jet represent the pinnacle of cordless vacuum design, but they take different approaches.

## Suction Power

The Dyson V15 leads with 230 AW versus Samsung's 210 AW. In practice, both handle everyday debris easily, but Dyson pulls ahead on deep carpet cleaning.

## Features

Dyson's laser dust detection is genuinely useful, revealing dust you'd otherwise miss. Samsung counters with an included self-emptying station that adds significant convenience.

## Design

Both are well-built, but Samsung edges ahead on weight at 2.8kg versus Dyson's 3.1kg. For extended cleaning sessions, this difference is noticeable.

## Value

Samsung includes the self-emptying station at a lower total price than Dyson. If you're buying accessories anyway, Samsung offers better value.

## Our Recommendation

Choose Dyson if cleaning performance is paramount. Choose Samsung if you value the self-emptying convenience and lighter weight.`,
    productIds: ['dyson-v15', 'samsung-jet90'],
    category: 'vacuums',
    author: 'Emily Zhang',
    datePublished: '2024-02-25',
    readTime: 9,
    image: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=1200&q=80',
  },
];

export const getArticleTypeLabel = (type: ArticleType): string => {
  switch (type) {
    case 'review': return 'Review';
    case 'comparison': return 'Comparison';
    case 'best-of': return 'Best Of';
  }
};

export const getArticleTypeBadgeClass = (type: ArticleType): string => {
  switch (type) {
    case 'review': return 'bg-primary text-primary-foreground';
    case 'comparison': return 'bg-accent text-accent-foreground';
    case 'best-of': return 'bg-rating-excellent text-white';
  }
};
