import { useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { ArrowLeft, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { ArticleCard } from '@/components/ArticleCard';
import { products } from '@/data/products';
import { articles } from '@/data/articles';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  const results = useMemo(() => {
    const lowerQuery = query.toLowerCase();

    const matchingProducts = products.filter(
      (p) =>
        p.name.toLowerCase().includes(lowerQuery) ||
        p.brand.toLowerCase().includes(lowerQuery) ||
        p.category.toLowerCase().includes(lowerQuery) ||
        p.verdict.toLowerCase().includes(lowerQuery)
    );

    const matchingArticles = articles.filter(
      (a) =>
        a.title.toLowerCase().includes(lowerQuery) ||
        a.excerpt.toLowerCase().includes(lowerQuery) ||
        a.content.toLowerCase().includes(lowerQuery) ||
        a.author.toLowerCase().includes(lowerQuery)
    );

    return { products: matchingProducts, articles: matchingArticles };
  }, [query]);

  const totalResults = results.products.length + results.articles.length;

  return (
    <div className="container py-8 animate-fade-in">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/" className="flex items-center gap-1">
          <ArrowLeft className="w-4 h-4" />
          Home
        </Link>
      </Button>

      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Search className="w-6 h-6 text-muted-foreground" />
          <h1 className="font-heading text-3xl font-bold">
            Search Results
          </h1>
        </div>
        <p className="text-muted-foreground">
          {totalResults > 0
            ? `Found ${totalResults} result${totalResults === 1 ? '' : 's'} for "${query}"`
            : `No results found for "${query}"`}
        </p>
      </div>

      {totalResults > 0 ? (
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="all">
              All ({totalResults})
            </TabsTrigger>
            <TabsTrigger value="products">
              Products ({results.products.length})
            </TabsTrigger>
            <TabsTrigger value="articles">
              Articles ({results.articles.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-12">
            {results.products.length > 0 && (
              <section>
                <h2 className="font-heading text-xl font-semibold mb-4">Products</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {results.products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </section>
            )}

            {results.articles.length > 0 && (
              <section>
                <h2 className="font-heading text-xl font-semibold mb-4">Articles</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {results.articles.map((article) => (
                    <ArticleCard key={article.id} article={article} />
                  ))}
                </div>
              </section>
            )}
          </TabsContent>

          <TabsContent value="products">
            {results.products.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {results.products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No products match your search.
              </p>
            )}
          </TabsContent>

          <TabsContent value="articles">
            {results.articles.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {results.articles.map((article) => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No articles match your search.
              </p>
            )}
          </TabsContent>
        </Tabs>
      ) : (
        <div className="text-center py-16 bg-secondary/30 rounded-lg">
          <h3 className="font-heading text-xl font-semibold mb-2">No Results Found</h3>
          <p className="text-muted-foreground mb-6">
            Try adjusting your search terms or browse our categories
          </p>
          <div className="flex justify-center gap-4">
            <Button asChild>
              <Link to="/products">Browse Products</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/">Go Home</Link>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
