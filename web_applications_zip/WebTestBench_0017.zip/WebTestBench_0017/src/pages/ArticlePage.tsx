import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Clock, User, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { articles, getArticleTypeLabel, getArticleTypeBadgeClass } from '@/data/articles';
import { products } from '@/data/products';
import { cn } from '@/lib/utils';

export function ArticlePage() {
  const { id } = useParams<{ id: string }>();
  const article = articles.find((a) => a.id === id);

  if (!article) {
    return (
      <div className="container py-16 text-center">
        <h1 className="font-heading text-2xl font-bold mb-4">Article Not Found</h1>
        <Button asChild>
          <Link to="/">Go Home</Link>
        </Button>
      </div>
    );
  }

  const featuredProducts = products.filter((p) => article.productIds.includes(p.id));
  const contentParagraphs = article.content.split('\n\n').filter(Boolean);

  return (
    <div className="animate-fade-in">
      {/* Breadcrumb */}
      <div className="container pt-6">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/" className="flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" />
            Home
          </Link>
        </Button>
      </div>

      {/* Hero */}
      <section className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <span className={cn(
              'px-3 py-1 text-xs font-medium rounded-full',
              getArticleTypeBadgeClass(article.type)
            )}>
              {getArticleTypeLabel(article.type)}
            </span>
            <span className="text-sm text-muted-foreground capitalize">{article.category}</span>
          </div>

          <h1 className="font-heading text-3xl md:text-5xl font-bold leading-tight">
            {article.title}
          </h1>

          <p className="mt-4 text-lg text-muted-foreground">
            {article.excerpt}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <User className="w-4 h-4" />
              {article.author}
            </span>
            <span className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {new Date(article.datePublished).toLocaleDateString('en-US', { 
                month: 'long', 
                day: 'numeric', 
                year: 'numeric' 
              })}
            </span>
            <span className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {article.readTime} min read
            </span>
          </div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="container pb-8">
        <div className="max-w-4xl mx-auto">
          <div className="aspect-[21/9] rounded-xl overflow-hidden bg-secondary">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="container py-8">
        <div className="max-w-3xl mx-auto">
          <div className="article-content">
            {contentParagraphs.map((paragraph, index) => {
              if (paragraph.startsWith('## ')) {
                return (
                  <h2 key={index} className="font-heading text-2xl font-bold mt-8 mb-4 text-foreground">
                    {paragraph.replace('## ', '')}
                  </h2>
                );
              }
              return (
                <p key={index} className="text-muted-foreground leading-relaxed mb-4">
                  {paragraph}
                </p>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-12 bg-secondary/30">
          <div className="container">
            <h2 className="font-heading text-2xl font-bold mb-8">Products Mentioned</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
