import { Link } from 'react-router-dom';
import { ArrowRight, Star, TrendingUp, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { ArticleCard } from '@/components/ArticleCard';
import { products, categories } from '@/data/products';
import { articles } from '@/data/articles';

export function HomePage() {
  const featuredArticles = articles.filter((a) => a.featured);
  const latestProducts = [...products].sort((a, b) => 
    new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime()
  ).slice(0, 6);
  const topRatedProducts = [...products].sort((a, b) => b.overallScore - a.overallScore).slice(0, 3);

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary to-primary/80 text-primary-foreground py-20 md:py-32">
        <div className="container">
          <div className="max-w-3xl">
            <h1 className="font-heading text-4xl md:text-6xl font-bold leading-tight">
              Expert Reviews You Can Trust
            </h1>
            <p className="mt-6 text-lg md:text-xl text-primary-foreground/80">
              In-depth guides, comparisons, and buying advice for cameras, monitors, vacuums, and more. 
              We test everything so you don't have to.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button asChild size="lg" variant="secondary">
                <Link to="/products">Browse Products</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/compare">Compare Products</Link>
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent" />
      </section>

      {/* Featured Articles */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-heading text-3xl font-bold">Featured Guides</h2>
            <Button variant="ghost" asChild>
              <Link to="/products" className="flex items-center gap-2">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </div>
          <div className="grid gap-6">
            {featuredArticles.slice(0, 1).map((article) => (
              <ArticleCard key={article.id} article={article} variant="featured" />
            ))}
            <div className="grid md:grid-cols-2 gap-6">
              {featuredArticles.slice(1, 3).map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <h2 className="font-heading text-3xl font-bold mb-8">Browse by Category</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Link
                key={category.id}
                to={`/products?category=${category.id}`}
                className="group relative overflow-hidden rounded-xl bg-card p-6 border transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center gap-4 mb-4">
                  {category.id === 'cameras' && <Zap className="w-8 h-8 text-accent" />}
                  {category.id === 'monitors' && <Star className="w-8 h-8 text-accent" />}
                  {category.id === 'vacuums' && <TrendingUp className="w-8 h-8 text-accent" />}
                  <h3 className="font-heading text-xl font-semibold">{category.name}</h3>
                </div>
                <p className="text-muted-foreground">{category.description}</p>
                <div className="mt-4 text-sm font-medium text-accent flex items-center gap-1 group-hover:gap-2 transition-all">
                  Explore <ArrowRight className="w-4 h-4" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Top Rated Products */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-heading text-3xl font-bold">Top Rated Products</h2>
              <p className="mt-2 text-muted-foreground">The highest scoring products across all categories</p>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/products?sort=score" className="flex items-center gap-2">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {topRatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Latest Reviews */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-heading text-3xl font-bold">Latest Products</h2>
              <p className="mt-2 text-muted-foreground">Recently added to our database</p>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/products?sort=date" className="flex items-center gap-2">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
