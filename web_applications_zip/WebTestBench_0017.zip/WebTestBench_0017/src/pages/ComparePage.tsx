import { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Plus, X, Check, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScoreBadge } from '@/components/ScoreBadge';
import { RatingBar } from '@/components/RatingBar';
import { products, categories } from '@/data/products';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function ComparePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialProducts = searchParams.get('products')?.split(',').filter(Boolean) || [];
  
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(
    initialProducts.length > 0 ? initialProducts.slice(0, 4) : []
  );

  const selectedProducts = useMemo(
    () => selectedProductIds.map((id) => products.find((p) => p.id === id)).filter(Boolean),
    [selectedProductIds]
  );

  const availableProducts = products.filter((p) => !selectedProductIds.includes(p.id));

  const addProduct = (productId: string) => {
    if (selectedProductIds.length < 4 && !selectedProductIds.includes(productId)) {
      const newIds = [...selectedProductIds, productId];
      setSelectedProductIds(newIds);
      setSearchParams({ products: newIds.join(',') });
    }
  };

  const removeProduct = (productId: string) => {
    const newIds = selectedProductIds.filter((id) => id !== productId);
    setSelectedProductIds(newIds);
    if (newIds.length > 0) {
      setSearchParams({ products: newIds.join(',') });
    } else {
      setSearchParams({});
    }
  };

  const allSpecs = useMemo(() => {
    const specKeys = new Set<string>();
    selectedProducts.forEach((product) => {
      if (product) {
        Object.keys(product.specs).forEach((key) => specKeys.add(key));
      }
    });
    return Array.from(specKeys);
  }, [selectedProducts]);

  const ratingKeys = ['design', 'performance', 'value', 'features', 'build'];

  return (
    <div className="container py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="font-heading text-4xl font-bold">Compare Products</h1>
        <p className="mt-2 text-muted-foreground">
          Select up to 4 products to compare side-by-side
        </p>
      </div>

      {/* Product Selector */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[0, 1, 2, 3].map((index) => {
          const product = selectedProducts[index];
          
          return (
            <div
              key={index}
              className="relative bg-card border rounded-lg p-4 min-h-[200px] flex flex-col"
            >
              {product ? (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 h-6 w-6"
                    onClick={() => removeProduct(product.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                  <div className="aspect-square rounded-md overflow-hidden bg-secondary mb-3">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{product.brand}</p>
                    <h3 className="font-medium text-sm line-clamp-2">{product.name}</h3>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="font-semibold">${product.price}</span>
                    <ScoreBadge score={product.overallScore} size="sm" />
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center">
                  <Select onValueChange={addProduct}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Add product" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableProducts.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.brand} {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {selectedProducts.length >= 2 && (
        <>
          {/* Ratings Comparison */}
          <section className="mb-12">
            <h2 className="font-heading text-2xl font-bold mb-6">Ratings</h2>
            <div className="bg-card border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-secondary/30">
                      <th className="px-4 py-3 text-left font-medium">Criteria</th>
                      {selectedProducts.map((product) => (
                        <th key={product?.id} className="px-4 py-3 text-center font-medium min-w-[150px]">
                          {product?.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b bg-accent/5">
                      <td className="px-4 py-4 font-semibold">Overall Score</td>
                      {selectedProducts.map((product) => (
                        <td key={product?.id} className="px-4 py-4 text-center">
                          {product && <ScoreBadge score={product.overallScore} size="md" />}
                        </td>
                      ))}
                    </tr>
                    {ratingKeys.map((key) => (
                      <tr key={key} className="border-b">
                        <td className="px-4 py-3 capitalize">{key}</td>
                        {selectedProducts.map((product) => (
                          <td key={product?.id} className="px-4 py-3">
                            {product && (
                              <div className="max-w-[120px] mx-auto">
                                <RatingBar
                                  label=""
                                  value={product.ratings[key as keyof typeof product.ratings]}
                                  showValue
                                  animate={false}
                                />
                              </div>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Specifications Comparison */}
          <section className="mb-12">
            <h2 className="font-heading text-2xl font-bold mb-6">Specifications</h2>
            <div className="bg-card border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-secondary/30">
                      <th className="px-4 py-3 text-left font-medium">Spec</th>
                      {selectedProducts.map((product) => (
                        <th key={product?.id} className="px-4 py-3 text-center font-medium min-w-[150px]">
                          {product?.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="px-4 py-3 font-medium">Price</td>
                      {selectedProducts.map((product) => (
                        <td key={product?.id} className="px-4 py-3 text-center font-semibold">
                          ${product?.price}
                        </td>
                      ))}
                    </tr>
                    {allSpecs.map((spec) => (
                      <tr key={spec} className="border-b">
                        <td className="px-4 py-3">{spec}</td>
                        {selectedProducts.map((product) => (
                          <td key={product?.id} className="px-4 py-3 text-center text-sm text-muted-foreground">
                            {product?.specs[spec] || '—'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Pros & Cons */}
          <section>
            <h2 className="font-heading text-2xl font-bold mb-6">Pros & Cons</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {selectedProducts.map((product) => (
                <div key={product?.id} className="bg-card border rounded-lg p-4">
                  <h3 className="font-heading font-semibold mb-4">{product?.name}</h3>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-rating-excellent mb-2 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Pros
                    </h4>
                    <ul className="space-y-1">
                      {product?.pros.map((pro, i) => (
                        <li key={i} className="text-xs text-muted-foreground">• {pro}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-rating-bad mb-2 flex items-center gap-1">
                      <Minus className="w-3 h-3" /> Cons
                    </h4>
                    <ul className="space-y-1">
                      {product?.cons.map((con, i) => (
                        <li key={i} className="text-xs text-muted-foreground">• {con}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      {selectedProducts.length < 2 && (
        <div className="text-center py-16 bg-secondary/30 rounded-lg">
          <h3 className="font-heading text-xl font-semibold mb-2">Select Products to Compare</h3>
          <p className="text-muted-foreground mb-6">
            Choose at least 2 products from the dropdowns above to see a detailed comparison
          </p>
          <Button asChild variant="outline">
            <Link to="/products">Browse Products</Link>
          </Button>
        </div>
      )}
    </div>
  );
}
