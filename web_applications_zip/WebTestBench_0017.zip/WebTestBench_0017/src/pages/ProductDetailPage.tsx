import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Check, X, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScoreBadge } from '@/components/ScoreBadge';
import { RatingBar } from '@/components/RatingBar';
import { ArticleCard } from '@/components/ArticleCard';
import { products, categories } from '@/data/products';
import { articles } from '@/data/articles';

export function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="container py-16 text-center">
        <h1 className="font-heading text-2xl font-bold mb-4">Product Not Found</h1>
        <Button asChild>
          <Link to="/products">Browse All Products</Link>
        </Button>
      </div>
    );
  }

  const category = categories.find((c) => c.id === product.category);
  const relatedArticles = articles.filter((a) => a.productIds.includes(product.id));
  const ratingEntries = Object.entries(product.ratings) as [string, number][];

  return (
    <div className="animate-fade-in">
      {/* Breadcrumb */}
      <div className="container pt-6">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/products" className="flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" />
            All Products
          </Link>
        </Button>
      </div>

      {/* Hero Section */}
      <section className="container py-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-secondary">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Product Info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="category-chip">{category?.name}</span>
              <span className="text-sm text-muted-foreground">{product.brand}</span>
            </div>

            <h1 className="font-heading text-3xl md:text-4xl font-bold">{product.name}</h1>
            
            <div className="mt-4 flex items-center gap-4">
              <span className="text-3xl font-bold">${product.price}</span>
              <span className="text-muted-foreground capitalize">{product.priceRange}</span>
            </div>

            {/* Overall Score */}
            <div className="mt-8 flex items-center gap-6">
              <ScoreBadge score={product.overallScore} size="lg" />
              <div>
                <div className="text-sm text-muted-foreground">Overall Score</div>
                <div className="font-heading text-xl font-semibold">
                  {product.overallScore >= 9 ? 'Excellent' : 
                   product.overallScore >= 8 ? 'Great' :
                   product.overallScore >= 7 ? 'Good' : 'Average'}
                </div>
              </div>
            </div>

            {/* Verdict */}
            <div className="mt-8 p-4 bg-secondary/50 rounded-lg border">
              <h3 className="font-heading font-semibold mb-2">Our Verdict</h3>
              <p className="text-muted-foreground">{product.verdict}</p>
            </div>

            {/* Quick Actions */}
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <Link to={`/compare?products=${product.id}`}>
                  Add to Comparison
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Ratings */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="font-heading text-2xl font-bold mb-8">Detailed Ratings</h2>
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-6 max-w-3xl">
            {ratingEntries.map(([key, value], index) => (
              <div key={key} style={{ animationDelay: `${index * 100}ms` }} className="animate-slide-in">
                <RatingBar label={key} value={value} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specs, Pros & Cons */}
      <section className="py-12">
        <div className="container">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Specifications */}
            <div className="lg:col-span-2">
              <h2 className="font-heading text-2xl font-bold mb-6">Specifications</h2>
              <div className="bg-card rounded-lg border overflow-hidden">
                <table className="w-full">
                  <tbody>
                    {Object.entries(product.specs).map(([key, value], index) => (
                      <tr key={key} className={index % 2 === 0 ? 'bg-secondary/30' : ''}>
                        <td className="px-4 py-3 font-medium">{key}</td>
                        <td className="px-4 py-3 text-muted-foreground">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pros & Cons */}
            <div>
              <h2 className="font-heading text-2xl font-bold mb-6">Pros & Cons</h2>
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-rating-excellent mb-3 flex items-center gap-2">
                    <Check className="w-4 h-4" /> Pros
                  </h4>
                  <ul className="space-y-2">
                    {product.pros.map((pro, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-rating-excellent mt-1.5 flex-shrink-0" />
                        {pro}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-rating-bad mb-3 flex items-center gap-2">
                    <X className="w-4 h-4" /> Cons
                  </h4>
                  <ul className="space-y-2">
                    {product.cons.map((con, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-rating-bad mt-1.5 flex-shrink-0" />
                        {con}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="py-12 bg-secondary/30">
          <div className="container">
            <h2 className="font-heading text-2xl font-bold mb-8">Featured In</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
