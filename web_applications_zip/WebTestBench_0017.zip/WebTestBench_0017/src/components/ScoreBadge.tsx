import { cn } from '@/lib/utils';
import { getScoreBgClass } from '@/data/products';

interface ScoreBadgeProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function ScoreBadge({ score, size = 'md', className }: ScoreBadgeProps) {
  const sizeClasses = {
    sm: 'w-10 h-10 text-sm rounded-md',
    md: 'w-12 h-12 text-lg rounded-lg',
    lg: 'w-20 h-20 text-3xl rounded-xl',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center justify-center font-bold',
        sizeClasses[size],
        getScoreBgClass(score),
        className
      )}
    >
      {score.toFixed(1)}
    </div>
  );
}
