import { Link } from 'react-router-dom';
import { Clock, User } from 'lucide-react';
import { Article, getArticleTypeLabel, getArticleTypeBadgeClass } from '@/data/articles';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ArticleCardProps {
  article: Article;
  variant?: 'default' | 'featured';
}

export function ArticleCard({ article, variant = 'default' }: ArticleCardProps) {
  const isFeatured = variant === 'featured';

  return (
    <Link to={`/article/${article.id}`}>
      <Card className={cn(
        'group overflow-hidden transition-all duration-300 hover:shadow-lg',
        isFeatured && 'md:flex'
      )}>
        <div className={cn(
          'relative overflow-hidden bg-secondary',
          isFeatured ? 'md:w-1/2 aspect-[16/9] md:aspect-auto' : 'aspect-[16/9]'
        )}>
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <span className={cn(
              'px-3 py-1 text-xs font-medium rounded-full',
              getArticleTypeBadgeClass(article.type)
            )}>
              {getArticleTypeLabel(article.type)}
            </span>
          </div>
        </div>
        <CardContent className={cn(
          'p-4',
          isFeatured && 'md:w-1/2 md:p-6 md:flex md:flex-col md:justify-center'
        )}>
          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
            <span className="capitalize">{article.category}</span>
            <span>•</span>
            <span>{new Date(article.datePublished).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
          <h3 className={cn(
            'font-heading font-semibold line-clamp-2 group-hover:text-accent transition-colors',
            isFeatured ? 'text-2xl' : 'text-lg'
          )}>
            {article.title}
          </h3>
          <p className={cn(
            'mt-2 text-muted-foreground line-clamp-2',
            isFeatured ? 'text-base' : 'text-sm'
          )}>
            {article.excerpt}
          </p>
          <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {article.author}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {article.readTime} min read
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
