import { Link } from 'react-router-dom';
import { Product, categories } from '@/data/products';
import { ScoreBadge } from './ScoreBadge';
import { Card, CardContent } from '@/components/ui/card';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const category = categories.find((c) => c.id === product.category);

  return (
    <Link to={`/product/${product.id}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
        <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 right-3">
            <ScoreBadge score={product.overallScore} size="sm" />
          </div>
        </div>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="category-chip">{category?.name}</span>
            <span className="text-xs text-muted-foreground">{product.brand}</span>
          </div>
          <h3 className="font-heading text-lg font-semibold line-clamp-2 group-hover:text-accent transition-colors">
            {product.name}
          </h3>
          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{product.verdict}</p>
          <div className="mt-3 flex items-center justify-between">
            <span className="font-semibold text-lg">${product.price}</span>
            <span className="text-xs text-muted-foreground capitalize">{product.priceRange}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
