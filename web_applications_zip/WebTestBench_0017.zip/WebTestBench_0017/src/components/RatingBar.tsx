import { getScoreColor } from '@/data/products';

interface RatingBarProps {
  label: string;
  value: number;
  maxValue?: number;
  showValue?: boolean;
  animate?: boolean;
}

export function RatingBar({ label, value, maxValue = 10, showValue = true, animate = true }: RatingBarProps) {
  const percentage = (value / maxValue) * 100;
  const colorClass = getScoreColor(value);

  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center text-sm">
        <span className="text-muted-foreground capitalize">{label}</span>
        {showValue && <span className="font-medium">{value.toFixed(1)}</span>}
      </div>
      <div className="rating-bar">
        <div
          className={`rating-bar-fill ${colorClass} ${animate ? 'animate-bar-fill' : ''}`}
          style={{ '--bar-width': `${percentage}%`, width: animate ? undefined : `${percentage}%` } as React.CSSProperties}
        />
      </div>
    </div>
  );
}
