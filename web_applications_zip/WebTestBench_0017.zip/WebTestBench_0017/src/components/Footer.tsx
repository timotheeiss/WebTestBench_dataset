import { Link } from 'react-router-dom';
import { categories } from '@/data/products';

export function Footer() {
  return (
    <footer className="border-t bg-secondary/30">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/" className="inline-block">
              <span className="font-heading text-2xl font-bold text-primary">TechVerdict</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground max-w-md">
              In-depth reviews, comparisons, and buying guides to help you make informed tech decisions.
              Our expert team tests every product thoroughly.
            </p>
          </div>
          
          <div>
            <h4 className="font-heading text-sm font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link
                    to={`/products?category=${category.id}`}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-heading text-sm font-semibold mb-4">Resources</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/compare" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Compare Products
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  All Products
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t">
          <p className="text-sm text-muted-foreground text-center">
            © {new Date().getFullYear()} TechVerdict. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
