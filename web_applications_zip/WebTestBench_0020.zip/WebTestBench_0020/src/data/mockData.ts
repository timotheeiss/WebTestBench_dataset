export interface BoxPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  billingCycle: 'monthly' | 'quarterly' | 'yearly';
  maxSubscribers: number;
  currentSubscribers: number;
  products: string[];
  isActive: boolean;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  stockLevel: number;
  reservedUnits: number;
  costPerUnit: number;
  imageUrl?: string;
}

export interface Subscriber {
  id: string;
  name: string;
  email: string;
  planId: string;
  status: 'active' | 'paused' | 'cancelled';
  address: {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
  subscribedAt: string;
  nextBillingDate: string;
}

export interface Payment {
  id: string;
  subscriberId: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  date: string;
  planName: string;
}

export interface Order {
  id: string;
  subscriberId: string;
  planId: string;
  billingCycle: string;
  status: 'pending' | 'preparing' | 'shipped' | 'delivered';
  createdAt: string;
  shippedAt?: string;
  trackingNumber?: string;
}

export const boxPlans: BoxPlan[] = [
  {
    id: 'plan-1',
    name: 'Starter Box',
    description: 'Perfect for newcomers. 3-4 curated items monthly.',
    price: 29.99,
    billingCycle: 'monthly',
    maxSubscribers: 500,
    currentSubscribers: 342,
    products: ['prod-1', 'prod-2', 'prod-4'],
    isActive: true,
  },
  {
    id: 'plan-2',
    name: 'Premium Box',
    description: 'Our bestseller. 5-7 premium items with exclusive extras.',
    price: 49.99,
    billingCycle: 'monthly',
    maxSubscribers: 300,
    currentSubscribers: 287,
    products: ['prod-1', 'prod-2', 'prod-3', 'prod-5', 'prod-6'],
    isActive: true,
  },
  {
    id: 'plan-3',
    name: 'Deluxe Quarterly',
    description: 'Ultimate experience. 10+ luxury items every quarter.',
    price: 149.99,
    billingCycle: 'quarterly',
    maxSubscribers: 100,
    currentSubscribers: 78,
    products: ['prod-1', 'prod-2', 'prod-3', 'prod-4', 'prod-5', 'prod-6', 'prod-7'],
    isActive: true,
  },
  {
    id: 'plan-4',
    name: 'Annual VIP',
    description: 'Best value. All premium perks plus VIP exclusives.',
    price: 499.99,
    billingCycle: 'yearly',
    maxSubscribers: 50,
    currentSubscribers: 23,
    products: ['prod-1', 'prod-2', 'prod-3', 'prod-4', 'prod-5', 'prod-6', 'prod-7', 'prod-8'],
    isActive: false,
  },
];

export const products: Product[] = [
  { id: 'prod-1', name: 'Artisan Chocolate Bar', sku: 'CHO-001', category: 'Sweets', stockLevel: 1200, reservedUnits: 707, costPerUnit: 4.50 },
  { id: 'prod-2', name: 'Organic Tea Sampler', sku: 'TEA-002', category: 'Beverages', stockLevel: 800, reservedUnits: 707, costPerUnit: 8.00 },
  { id: 'prod-3', name: 'Scented Candle Set', sku: 'CAN-003', category: 'Home', stockLevel: 450, reservedUnits: 365, costPerUnit: 12.00 },
  { id: 'prod-4', name: 'Handmade Soap Bar', sku: 'SOP-004', category: 'Bath', stockLevel: 900, reservedUnits: 420, costPerUnit: 6.00 },
  { id: 'prod-5', name: 'Premium Coffee Beans', sku: 'COF-005', category: 'Beverages', stockLevel: 600, reservedUnits: 365, costPerUnit: 15.00 },
  { id: 'prod-6', name: 'Leather Journal', sku: 'JRN-006', category: 'Stationery', stockLevel: 350, reservedUnits: 365, costPerUnit: 18.00 },
  { id: 'prod-7', name: 'Luxury Bath Bomb Set', sku: 'BTH-007', category: 'Bath', stockLevel: 280, reservedUnits: 101, costPerUnit: 22.00 },
  { id: 'prod-8', name: 'Exclusive Wine Selection', sku: 'WIN-008', category: 'Beverages', stockLevel: 100, reservedUnits: 23, costPerUnit: 45.00 },
];

export const subscribers: Subscriber[] = [
  {
    id: 'sub-1',
    name: 'Emma Thompson',
    email: 'emma.t@email.com',
    planId: 'plan-2',
    status: 'active',
    address: { street: '123 Oak Street', city: 'Portland', state: 'OR', zip: '97201', country: 'USA' },
    subscribedAt: '2024-03-15',
    nextBillingDate: '2025-01-15',
  },
  {
    id: 'sub-2',
    name: 'Marcus Chen',
    email: 'marcus.chen@email.com',
    planId: 'plan-1',
    status: 'active',
    address: { street: '456 Pine Avenue', city: 'Seattle', state: 'WA', zip: '98101', country: 'USA' },
    subscribedAt: '2024-06-22',
    nextBillingDate: '2025-01-22',
  },
  {
    id: 'sub-3',
    name: 'Sofia Rodriguez',
    email: 'sofia.r@email.com',
    planId: 'plan-3',
    status: 'active',
    address: { street: '789 Maple Drive', city: 'San Francisco', state: 'CA', zip: '94102', country: 'USA' },
    subscribedAt: '2024-01-10',
    nextBillingDate: '2025-01-10',
  },
  {
    id: 'sub-4',
    name: 'James Wilson',
    email: 'j.wilson@email.com',
    planId: 'plan-2',
    status: 'paused',
    address: { street: '321 Elm Court', city: 'Denver', state: 'CO', zip: '80202', country: 'USA' },
    subscribedAt: '2024-04-05',
    nextBillingDate: '2025-02-05',
  },
  {
    id: 'sub-5',
    name: 'Aisha Patel',
    email: 'aisha.p@email.com',
    planId: 'plan-1',
    status: 'active',
    address: { street: '654 Cedar Lane', city: 'Austin', state: 'TX', zip: '78701', country: 'USA' },
    subscribedAt: '2024-08-18',
    nextBillingDate: '2025-01-18',
  },
  {
    id: 'sub-6',
    name: 'Oliver Brown',
    email: 'oliver.b@email.com',
    planId: 'plan-4',
    status: 'active',
    address: { street: '987 Birch Road', city: 'Chicago', state: 'IL', zip: '60601', country: 'USA' },
    subscribedAt: '2024-02-28',
    nextBillingDate: '2025-02-28',
  },
];

export const payments: Payment[] = [
  { id: 'pay-1', subscriberId: 'sub-1', amount: 49.99, status: 'completed', date: '2024-12-15', planName: 'Premium Box' },
  { id: 'pay-2', subscriberId: 'sub-2', amount: 29.99, status: 'completed', date: '2024-12-22', planName: 'Starter Box' },
  { id: 'pay-3', subscriberId: 'sub-3', amount: 149.99, status: 'completed', date: '2024-10-10', planName: 'Deluxe Quarterly' },
  { id: 'pay-4', subscriberId: 'sub-5', amount: 29.99, status: 'completed', date: '2024-12-18', planName: 'Starter Box' },
  { id: 'pay-5', subscriberId: 'sub-6', amount: 499.99, status: 'completed', date: '2024-02-28', planName: 'Annual VIP' },
  { id: 'pay-6', subscriberId: 'sub-1', amount: 49.99, status: 'completed', date: '2024-11-15', planName: 'Premium Box' },
  { id: 'pay-7', subscriberId: 'sub-4', amount: 49.99, status: 'failed', date: '2024-12-05', planName: 'Premium Box' },
  { id: 'pay-8', subscriberId: 'sub-2', amount: 29.99, status: 'refunded', date: '2024-11-22', planName: 'Starter Box' },
];

export const orders: Order[] = [
  { id: 'ord-1', subscriberId: 'sub-1', planId: 'plan-2', billingCycle: 'January 2025', status: 'preparing', createdAt: '2024-12-28' },
  { id: 'ord-2', subscriberId: 'sub-2', planId: 'plan-1', billingCycle: 'January 2025', status: 'pending', createdAt: '2024-12-29' },
  { id: 'ord-3', subscriberId: 'sub-3', planId: 'plan-3', billingCycle: 'Q1 2025', status: 'pending', createdAt: '2024-12-30' },
  { id: 'ord-4', subscriberId: 'sub-5', planId: 'plan-1', billingCycle: 'January 2025', status: 'shipped', createdAt: '2024-12-26', shippedAt: '2024-12-30', trackingNumber: '1Z999AA10123456784' },
  { id: 'ord-5', subscriberId: 'sub-6', planId: 'plan-4', billingCycle: '2025', status: 'preparing', createdAt: '2024-12-27' },
  { id: 'ord-6', subscriberId: 'sub-1', planId: 'plan-2', billingCycle: 'December 2024', status: 'delivered', createdAt: '2024-11-28', shippedAt: '2024-12-02', trackingNumber: '1Z999AA10123456785' },
];
