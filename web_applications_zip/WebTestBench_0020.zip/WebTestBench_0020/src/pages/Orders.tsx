import { useState } from 'react';
import { Search, Package, Truck, CheckCircle, Clock, Box } from 'lucide-react';
import { orders as initialOrders, subscribers, boxPlans, Order } from '@/data/mockData';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingNumber, setTrackingNumber] = useState('');

  const filteredOrders = orders.filter(order => {
    const subscriber = subscribers.find(s => s.id === order.subscriberId);
    const matchesSearch = 
      subscriber?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getSubscriber = (subscriberId: string) => 
    subscribers.find(s => s.id === subscriberId);

  const getPlanName = (planId: string) => 
    boxPlans.find(p => p.id === planId)?.name || 'Unknown';

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'preparing':
        return <Package className="w-4 h-4" />;
      case 'shipped':
        return <Truck className="w-4 h-4" />;
      case 'delivered':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const updateOrderStatus = (orderId: string, newStatus: Order['status'], tracking?: string) => {
    setOrders(orders.map(o => 
      o.id === orderId 
        ? { 
            ...o, 
            status: newStatus,
            shippedAt: newStatus === 'shipped' ? new Date().toISOString().split('T')[0] : o.shippedAt,
            trackingNumber: tracking || o.trackingNumber,
          }
        : o
    ));
    toast.success(`Order marked as ${newStatus}`);
    setSelectedOrder(null);
    setTrackingNumber('');
  };

  const handleShipOrder = () => {
    if (!selectedOrder) return;
    updateOrderStatus(selectedOrder.id, 'shipped', trackingNumber);
  };

  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const preparingOrders = orders.filter(o => o.status === 'preparing').length;
  const shippedOrders = orders.filter(o => o.status === 'shipped').length;

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">Orders & Fulfillment</h1>
          <p className="text-muted-foreground">Track and manage order preparation and shipping</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-warning" />
            <h3 className="text-sm text-muted-foreground font-medium">Pending</h3>
          </div>
          <p className="text-3xl font-display font-bold">{pendingOrders}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-2 mb-2">
            <Package className="w-5 h-5 text-primary" />
            <h3 className="text-sm text-muted-foreground font-medium">Preparing</h3>
          </div>
          <p className="text-3xl font-display font-bold">{preparingOrders}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-2 mb-2">
            <Truck className="w-5 h-5 text-accent" />
            <h3 className="text-sm text-muted-foreground font-medium">Shipped</h3>
          </div>
          <p className="text-3xl font-display font-bold">{shippedOrders}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-5 h-5 text-success" />
            <h3 className="text-sm text-muted-foreground font-medium">Delivered</h3>
          </div>
          <p className="text-3xl font-display font-bold">
            {orders.filter(o => o.status === 'delivered').length}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by customer or order ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="preparing">Preparing</SelectItem>
            <SelectItem value="shipped">Shipped</SelectItem>
            <SelectItem value="delivered">Delivered</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Orders Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <table className="data-table">
          <thead>
            <tr className="bg-muted/50">
              <th>Order ID</th>
              <th>Customer</th>
              <th>Plan</th>
              <th>Billing Cycle</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map((order) => {
              const subscriber = getSubscriber(order.subscriberId);
              return (
                <tr key={order.id}>
                  <td className="font-mono text-sm">{order.id}</td>
                  <td>
                    <div>
                      <p className="font-medium">{subscriber?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {subscriber?.address.city}, {subscriber?.address.state}
                      </p>
                    </div>
                  </td>
                  <td>{getPlanName(order.planId)}</td>
                  <td>{order.billingCycle}</td>
                  <td>
                    <span className={`status-badge status-${order.status === 'delivered' ? 'active' : order.status}`}>
                      {getStatusIcon(order.status)}
                      <span className="ml-1">{order.status}</span>
                    </span>
                  </td>
                  <td className="text-muted-foreground">{order.createdAt}</td>
                  <td>
                    <div className="flex gap-2">
                      {order.status === 'pending' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateOrderStatus(order.id, 'preparing')}
                        >
                          <Package className="w-3 h-3 mr-1" />
                          Prepare
                        </Button>
                      )}
                      {order.status === 'preparing' && (
                        <Button
                          size="sm"
                          onClick={() => setSelectedOrder(order)}
                        >
                          <Truck className="w-3 h-3 mr-1" />
                          Ship
                        </Button>
                      )}
                      {order.status === 'shipped' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateOrderStatus(order.id, 'delivered')}
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Delivered
                        </Button>
                      )}
                      {order.trackingNumber && (
                        <span className="text-xs text-muted-foreground self-center">
                          {order.trackingNumber}
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filteredOrders.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No orders found matching your criteria.
          </div>
        )}
      </div>

      {/* Ship Order Dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => {
        setSelectedOrder(null);
        setTrackingNumber('');
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ship Order</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 mt-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Box className="w-8 h-8 text-primary" />
                  <div>
                    <p className="font-medium">{getPlanName(selectedOrder.planId)}</p>
                    <p className="text-sm text-muted-foreground">{selectedOrder.billingCycle}</p>
                  </div>
                </div>
                <div className="text-sm">
                  <p className="font-medium">{getSubscriber(selectedOrder.subscriberId)?.name}</p>
                  <p className="text-muted-foreground">
                    {getSubscriber(selectedOrder.subscriberId)?.address.street}<br />
                    {getSubscriber(selectedOrder.subscriberId)?.address.city}, {getSubscriber(selectedOrder.subscriberId)?.address.state} {getSubscriber(selectedOrder.subscriberId)?.address.zip}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tracking">Tracking Number (optional)</Label>
                <Input
                  id="tracking"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  placeholder="1Z999AA10123456784"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => {
                  setSelectedOrder(null);
                  setTrackingNumber('');
                }}>
                  Cancel
                </Button>
                <Button onClick={handleShipOrder}>
                  <Truck className="w-4 h-4 mr-2" />
                  Mark as Shipped
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
