import { useState } from 'react';
import { Search, Edit2, Mail, MapPin } from 'lucide-react';
import { subscribers as initialSubscribers, boxPlans, payments, Subscriber } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

export default function Subscribers() {
  const [subscribers, setSubscribers] = useState<Subscriber[]>(initialSubscribers);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSubscriber, setEditingSubscriber] = useState<Subscriber | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    planId: '',
    status: 'active' as Subscriber['status'],
    street: '',
    city: '',
    state: '',
    zip: '',
    country: '',
  });

  const filteredSubscribers = subscribers.filter(sub => {
    const matchesSearch = sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || sub.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (subscriber: Subscriber) => {
    setEditingSubscriber(subscriber);
    setFormData({
      name: subscriber.name,
      email: subscriber.email,
      planId: subscriber.planId,
      status: subscriber.status,
      street: subscriber.address.street,
      city: subscriber.address.city,
      state: subscriber.address.state,
      zip: subscriber.address.zip,
      country: subscriber.address.country,
    });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!editingSubscriber) return;

    setSubscribers(subscribers.map(s => 
      s.id === editingSubscriber.id 
        ? { 
            ...s, 
            name: formData.name,
            email: formData.email,
            planId: formData.planId,
            status: formData.status,
            address: {
              street: formData.street,
              city: formData.city,
              state: formData.state,
              zip: formData.zip,
              country: formData.country,
            }
          }
        : s
    ));
    toast.success('Subscriber updated successfully');
    setIsDialogOpen(false);
    setEditingSubscriber(null);
  };

  const getPlanName = (planId: string) => boxPlans.find(p => p.id === planId)?.name || 'Unknown';
  const getPlanPrice = (planId: string) => boxPlans.find(p => p.id === planId)?.price || 0;
  const getSubscriberPayments = (subscriberId: string) => payments.filter(p => p.subscriberId === subscriberId);

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">Subscribers</h1>
          <p className="text-muted-foreground">Manage customer subscriptions and details</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Subscribers Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <table className="data-table">
          <thead>
            <tr className="bg-muted/50">
              <th>Subscriber</th>
              <th>Plan</th>
              <th>Status</th>
              <th>Address</th>
              <th>Next Billing</th>
              <th>Total Spent</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredSubscribers.map((subscriber) => {
              const subscriberPayments = getSubscriberPayments(subscriber.id);
              const totalSpent = subscriberPayments
                .filter(p => p.status === 'completed')
                .reduce((sum, p) => sum + p.amount, 0);

              return (
                <tr key={subscriber.id}>
                  <td>
                    <div>
                      <p className="font-medium">{subscriber.name}</p>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {subscriber.email}
                      </p>
                    </div>
                  </td>
                  <td>
                    <div>
                      <p className="font-medium">{getPlanName(subscriber.planId)}</p>
                      <p className="text-sm text-muted-foreground">${getPlanPrice(subscriber.planId)}/mo</p>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge status-${subscriber.status}`}>
                      {subscriber.status}
                    </span>
                  </td>
                  <td>
                    <p className="text-sm flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-muted-foreground" />
                      {subscriber.address.city}, {subscriber.address.state}
                    </p>
                  </td>
                  <td className="text-sm">{subscriber.nextBillingDate}</td>
                  <td className="font-medium">${totalSpent.toFixed(2)}</td>
                  <td>
                    <button
                      onClick={() => handleEdit(subscriber)}
                      className="p-2 rounded-lg hover:bg-muted transition-colors"
                    >
                      <Edit2 className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filteredSubscribers.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No subscribers found matching your criteria.
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Subscriber</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Plan</Label>
                <Select
                  value={formData.planId}
                  onValueChange={(value) => setFormData({ ...formData, planId: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {boxPlans.map((plan) => (
                      <SelectItem key={plan.id} value={plan.id}>
                        {plan.name} (${plan.price})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value: Subscriber['status']) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Shipping Address</Label>
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="Street"
                  value={formData.street}
                  onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                  className="col-span-2"
                />
                <Input
                  placeholder="City"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                />
                <Input
                  placeholder="State"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                />
                <Input
                  placeholder="ZIP Code"
                  value={formData.zip}
                  onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                />
                <Input
                  placeholder="Country"
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Total Subscribers</h3>
          <p className="text-3xl font-display font-bold mt-1">{subscribers.length}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Active</h3>
          <p className="text-3xl font-display font-bold mt-1 text-success">
            {subscribers.filter(s => s.status === 'active').length}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Paused</h3>
          <p className="text-3xl font-display font-bold mt-1 text-warning">
            {subscribers.filter(s => s.status === 'paused').length}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Cancelled</h3>
          <p className="text-3xl font-display font-bold mt-1 text-destructive">
            {subscribers.filter(s => s.status === 'cancelled').length}
          </p>
        </div>
      </div>
    </div>
  );
}
