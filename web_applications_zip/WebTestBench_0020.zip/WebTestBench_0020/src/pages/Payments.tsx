import { useState } from 'react';
import { Search, Download, CheckCircle, XCircle, Clock, RotateCcw } from 'lucide-react';
import { payments as initialPayments, subscribers } from '@/data/mockData';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Payments() {
  const [payments] = useState(initialPayments);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredPayments = payments.filter(payment => {
    const subscriber = subscribers.find(s => s.id === payment.subscriberId);
    const matchesSearch = 
      subscriber?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.planName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || payment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getSubscriberName = (subscriberId: string) => 
    subscribers.find(s => s.id === subscriberId)?.name || 'Unknown';

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-warning" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-destructive" />;
      case 'refunded':
        return <RotateCcw className="w-4 h-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const totalRevenue = payments
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalRefunded = payments
    .filter(p => p.status === 'refunded')
    .reduce((sum, p) => sum + p.amount, 0);

  const failedPayments = payments.filter(p => p.status === 'failed').length;

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">Payment History</h1>
          <p className="text-muted-foreground">Track and review all subscription payments</p>
        </div>
        <Button variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Total Revenue</h3>
          <p className="text-3xl font-display font-bold mt-1 text-success">
            ${totalRevenue.toLocaleString()}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Total Refunded</h3>
          <p className="text-3xl font-display font-bold mt-1">${totalRefunded.toLocaleString()}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Transactions</h3>
          <p className="text-3xl font-display font-bold mt-1">{payments.length}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Failed Payments</h3>
          <p className="text-3xl font-display font-bold mt-1 text-destructive">{failedPayments}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by customer, plan, or payment ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="refunded">Refunded</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Payments Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <table className="data-table">
          <thead>
            <tr className="bg-muted/50">
              <th>Payment ID</th>
              <th>Customer</th>
              <th>Plan</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {filteredPayments.map((payment) => (
              <tr key={payment.id}>
                <td className="font-mono text-sm">{payment.id}</td>
                <td className="font-medium">{getSubscriberName(payment.subscriberId)}</td>
                <td>{payment.planName}</td>
                <td className="font-medium">${payment.amount.toFixed(2)}</td>
                <td>
                  <span className={`status-badge status-${payment.status === 'completed' ? 'active' : payment.status}`}>
                    {getStatusIcon(payment.status)}
                    <span className="ml-1">{payment.status}</span>
                  </span>
                </td>
                <td className="text-muted-foreground">{payment.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredPayments.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No payments found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
