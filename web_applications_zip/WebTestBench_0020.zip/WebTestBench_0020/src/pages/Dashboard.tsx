import { StatCard } from '@/components/dashboard/StatCard';
import { Users, Package, DollarSign, Truck, TrendingUp, AlertTriangle } from 'lucide-react';
import { boxPlans, subscribers, orders, products, payments } from '@/data/mockData';

export default function Dashboard() {
  const totalSubscribers = boxPlans.reduce((sum, plan) => sum + plan.currentSubscribers, 0);
  const activeSubscribers = subscribers.filter(s => s.status === 'active').length;
  const monthlyRevenue = payments
    .filter(p => p.status === 'completed' && p.date.startsWith('2024-12'))
    .reduce((sum, p) => sum + p.amount, 0);
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'preparing').length;
  const lowStockProducts = products.filter(p => p.stockLevel - p.reservedUnits < 100);

  const recentOrders = orders.slice(0, 5);
  const getSubscriberName = (id: string) => subscribers.find(s => s.id === id)?.name || 'Unknown';
  const getPlanName = (id: string) => boxPlans.find(p => p.id === id)?.name || 'Unknown';

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-2xl font-display font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your subscription box business</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Subscribers"
          value={totalSubscribers.toLocaleString()}
          change="+12% from last month"
          changeType="positive"
          icon={Users}
        />
        <StatCard
          title="Monthly Revenue"
          value={`$${monthlyRevenue.toLocaleString()}`}
          change="+8% from last month"
          changeType="positive"
          icon={DollarSign}
          iconColor="bg-success/10"
        />
        <StatCard
          title="Pending Orders"
          value={pendingOrders}
          change="5 need attention"
          changeType="neutral"
          icon={Truck}
          iconColor="bg-warning/10"
        />
        <StatCard
          title="Active Plans"
          value={boxPlans.filter(p => p.isActive).length}
          change={`${boxPlans.length} total plans`}
          changeType="neutral"
          icon={Package}
          iconColor="bg-accent/10"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-display font-semibold">Recent Orders</h2>
            <a href="/orders" className="text-sm text-primary hover:underline">View all</a>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Plan</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order) => (
                <tr key={order.id}>
                  <td className="font-mono text-sm">{order.id}</td>
                  <td>{getSubscriberName(order.subscriberId)}</td>
                  <td>{getPlanName(order.planId)}</td>
                  <td>
                    <span className={`status-badge status-${order.status === 'delivered' ? 'active' : order.status}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Low Stock Alert */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-warning" />
            <h2 className="text-lg font-display font-semibold">Low Stock Alerts</h2>
          </div>
          {lowStockProducts.length === 0 ? (
            <p className="text-muted-foreground text-sm">All products are well stocked!</p>
          ) : (
            <ul className="space-y-3">
              {lowStockProducts.map((product) => (
                <li key={product.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="font-medium text-sm">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.sku}</p>
                  </div>
                  <span className="text-sm font-medium text-warning">
                    {product.stockLevel - product.reservedUnits} left
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Plan Performance */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-display font-semibold">Plan Performance</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {boxPlans.map((plan) => {
            const percentage = Math.round((plan.currentSubscribers / plan.maxSubscribers) * 100);
            return (
              <div key={plan.id} className="p-4 rounded-lg bg-muted/50">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium">{plan.name}</h3>
                  <span className={`status-badge ${plan.isActive ? 'status-active' : 'status-cancelled'}`}>
                    {plan.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <p className="text-2xl font-display font-bold">{plan.currentSubscribers}</p>
                <p className="text-sm text-muted-foreground mb-2">of {plan.maxSubscribers} max</p>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
