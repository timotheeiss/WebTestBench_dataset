import { useState } from 'react';
import { Plus, Edit2, Trash2, AlertTriangle, Package } from 'lucide-react';
import { products as initialProducts, boxPlans, Product } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

const categories = ['Sweets', 'Beverages', 'Home', 'Bath', 'Stationery'];

export default function Products() {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: '',
    stockLevel: '',
    costPerUnit: '',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      sku: '',
      category: '',
      stockLevel: '',
      costPerUnit: '',
    });
    setEditingProduct(null);
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      sku: product.sku,
      category: product.category,
      stockLevel: product.stockLevel.toString(),
      costPerUnit: product.costPerUnit.toString(),
    });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.sku || !formData.category || !formData.stockLevel) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingProduct) {
      setProducts(products.map(p => 
        p.id === editingProduct.id 
          ? { 
              ...p, 
              ...formData, 
              stockLevel: parseInt(formData.stockLevel), 
              costPerUnit: parseFloat(formData.costPerUnit) 
            }
          : p
      ));
      toast.success('Product updated successfully');
    } else {
      const newProduct: Product = {
        id: `prod-${Date.now()}`,
        name: formData.name,
        sku: formData.sku,
        category: formData.category,
        stockLevel: parseInt(formData.stockLevel),
        reservedUnits: 0,
        costPerUnit: parseFloat(formData.costPerUnit),
      };
      setProducts([...products, newProduct]);
      toast.success('Product created successfully');
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
    toast.success('Product deleted');
  };

  const getPlansUsingProduct = (productId: string) => {
    return boxPlans.filter(plan => plan.products.includes(productId));
  };

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">Products & Inventory</h1>
          <p className="text-muted-foreground">Track stock levels and product assignments</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Product
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Product Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Artisan Chocolate"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sku">SKU *</Label>
                  <Input
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                    placeholder="e.g., CHO-001"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="stockLevel">Stock Level *</Label>
                  <Input
                    id="stockLevel"
                    type="number"
                    value={formData.stockLevel}
                    onChange={(e) => setFormData({ ...formData, stockLevel: e.target.value })}
                    placeholder="1000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="costPerUnit">Cost per Unit ($)</Label>
                <Input
                  id="costPerUnit"
                  type="number"
                  step="0.01"
                  value={formData.costPerUnit}
                  onChange={(e) => setFormData({ ...formData, costPerUnit: e.target.value })}
                  placeholder="4.50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => {
                  setIsDialogOpen(false);
                  resetForm();
                }}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  {editingProduct ? 'Update Product' : 'Add Product'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Products Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <table className="data-table">
          <thead>
            <tr className="bg-muted/50">
              <th>Product</th>
              <th>SKU</th>
              <th>Category</th>
              <th>Stock</th>
              <th>Reserved</th>
              <th>Available</th>
              <th>Used In Plans</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => {
              const available = product.stockLevel - product.reservedUnits;
              const isLowStock = available < 100;
              const plansUsing = getPlansUsingProduct(product.id);

              return (
                <tr key={product.id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <Package className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-xs text-muted-foreground">${product.costPerUnit}/unit</p>
                      </div>
                    </div>
                  </td>
                  <td className="font-mono text-sm">{product.sku}</td>
                  <td>
                    <span className="px-2 py-1 bg-muted rounded text-sm">{product.category}</span>
                  </td>
                  <td className="font-medium">{product.stockLevel.toLocaleString()}</td>
                  <td className="text-muted-foreground">{product.reservedUnits.toLocaleString()}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      {isLowStock && <AlertTriangle className="w-4 h-4 text-warning" />}
                      <span className={isLowStock ? 'text-warning font-medium' : ''}>
                        {available.toLocaleString()}
                      </span>
                    </div>
                  </td>
                  <td>
                    {plansUsing.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {plansUsing.map((plan) => (
                          <span key={plan.id} className="px-2 py-0.5 bg-primary/10 text-primary rounded text-xs">
                            {plan.name}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">None</span>
                    )}
                  </td>
                  <td>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleEdit(product)}
                        className="p-2 rounded-lg hover:bg-muted transition-colors"
                      >
                        <Edit2 className="w-4 h-4 text-muted-foreground" />
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="p-2 rounded-lg hover:bg-destructive/10 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Inventory Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Total Products</h3>
          <p className="text-3xl font-display font-bold mt-1">{products.length}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Total Stock Value</h3>
          <p className="text-3xl font-display font-bold mt-1">
            ${products.reduce((sum, p) => sum + (p.stockLevel * p.costPerUnit), 0).toLocaleString()}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-sm text-muted-foreground font-medium">Low Stock Items</h3>
          <p className="text-3xl font-display font-bold mt-1 text-warning">
            {products.filter(p => p.stockLevel - p.reservedUnits < 100).length}
          </p>
        </div>
      </div>
    </div>
  );
}
