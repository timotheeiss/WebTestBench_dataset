export interface KnowledgePage {
  id: string;
  title: string;
  content: string;
  parentId: string | null;
  tags: string[];
  citations: Citation[];
  createdAt: string;
  updatedAt: string;
}

export interface Citation {
  pageId: string;
  note: string;
}

export interface PageLink {
  fromPageId: string;
  toPageId: string;
}

export interface KnowledgeBase {
  pages: KnowledgePage[];
  links: PageLink[];
}

export interface PageWithRelations extends KnowledgePage {
  children: KnowledgePage[];
  backlinks: { page: KnowledgePage; }[];
  citedBy: { page: KnowledgePage; note: string }[];
  citesPages: { page: KnowledgePage; note: string }[];
}
