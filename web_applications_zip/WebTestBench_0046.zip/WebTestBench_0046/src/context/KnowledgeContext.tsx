import React, { createContext, useContext, useState, useCallback, useMemo } from "react";
import { KnowledgePage, PageLink, PageWithRelations } from "@/types/knowledge";
import { initialKnowledgeBase } from "@/data/knowledgeBase";

interface KnowledgeContextType {
  pages: KnowledgePage[];
  links: PageLink[];
  selectedPageId: string | null;
  searchQuery: string;
  selectedTags: string[];
  setSelectedPageId: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  toggleTag: (tag: string) => void;
  clearTags: () => void;
  getPageById: (id: string) => KnowledgePage | undefined;
  getPageWithRelations: (id: string) => PageWithRelations | undefined;
  getChildPages: (parentId: string | null) => KnowledgePage[];
  getRootPages: () => KnowledgePage[];
  getAllTags: () => string[];
  getFilteredPages: () => KnowledgePage[];
  addPage: (page: Omit<KnowledgePage, "id" | "createdAt" | "updatedAt">) => KnowledgePage;
  updatePage: (id: string, updates: Partial<KnowledgePage>) => void;
  deletePage: (id: string) => void;
  addLink: (fromPageId: string, toPageId: string) => void;
}

const KnowledgeContext = createContext<KnowledgeContextType | undefined>(undefined);

export function KnowledgeProvider({ children }: { children: React.ReactNode }) {
  const [pages, setPages] = useState<KnowledgePage[]>(initialKnowledgeBase.pages);
  const [links, setLinks] = useState<PageLink[]>(initialKnowledgeBase.links);
  const [selectedPageId, setSelectedPageId] = useState<string | null>("philosophy");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const getPageById = useCallback(
    (id: string) => pages.find((p) => p.id === id),
    [pages]
  );

  const getChildPages = useCallback(
    (parentId: string | null) => pages.filter((p) => p.parentId === parentId),
    [pages]
  );

  const getRootPages = useCallback(
    () => pages.filter((p) => p.parentId === null),
    [pages]
  );

  const getPageWithRelations = useCallback(
    (id: string): PageWithRelations | undefined => {
      const page = getPageById(id);
      if (!page) return undefined;

      const children = getChildPages(id);

      // Get backlinks (pages that link to this page)
      const backlinks = links
        .filter((l) => l.toPageId === id)
        .map((l) => ({ page: getPageById(l.fromPageId)! }))
        .filter((b) => b.page);

      // Get pages that cite this page
      const citedBy = pages
        .filter((p) => p.citations.some((c) => c.pageId === id))
        .map((p) => ({
          page: p,
          note: p.citations.find((c) => c.pageId === id)?.note || "",
        }));

      // Get pages this page cites
      const citesPages = page.citations
        .map((c) => ({
          page: getPageById(c.pageId)!,
          note: c.note,
        }))
        .filter((c) => c.page);

      return {
        ...page,
        children,
        backlinks,
        citedBy,
        citesPages,
      };
    },
    [pages, links, getPageById, getChildPages]
  );

  const getAllTags = useCallback(() => {
    const tagSet = new Set<string>();
    pages.forEach((p) => p.tags.forEach((t) => tagSet.add(t)));
    return Array.from(tagSet).sort();
  }, [pages]);

  const getFilteredPages = useCallback(() => {
    let filtered = [...pages];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(query) ||
          p.content.toLowerCase().includes(query) ||
          p.tags.some((t) => t.toLowerCase().includes(query)) ||
          p.citations.some((c) => c.note.toLowerCase().includes(query))
      );
    }

    if (selectedTags.length > 0) {
      filtered = filtered.filter((p) =>
        selectedTags.some((tag) => p.tags.includes(tag))
      );
    }

    return filtered;
  }, [pages, searchQuery, selectedTags]);

  const toggleTag = useCallback((tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }, []);

  const clearTags = useCallback(() => {
    setSelectedTags([]);
  }, []);

  const addPage = useCallback(
    (pageData: Omit<KnowledgePage, "id" | "createdAt" | "updatedAt">) => {
      const id = pageData.title.toLowerCase().replace(/\s+/g, "-");
      const now = new Date().toISOString();
      const newPage: KnowledgePage = {
        ...pageData,
        id,
        createdAt: now,
        updatedAt: now,
      };
      setPages((prev) => [...prev, newPage]);
      return newPage;
    },
    []
  );

  const updatePage = useCallback(
    (id: string, updates: Partial<KnowledgePage>) => {
      setPages((prev) =>
        prev.map((p) =>
          p.id === id
            ? { ...p, ...updates, updatedAt: new Date().toISOString() }
            : p
        )
      );
    },
    []
  );

  const deletePage = useCallback((id: string) => {
    setPages((prev) => prev.filter((p) => p.id !== id));
    setLinks((prev) =>
      prev.filter((l) => l.fromPageId !== id && l.toPageId !== id)
    );
  }, []);

  const addLink = useCallback((fromPageId: string, toPageId: string) => {
    setLinks((prev) => {
      if (prev.some((l) => l.fromPageId === fromPageId && l.toPageId === toPageId)) {
        return prev;
      }
      return [...prev, { fromPageId, toPageId }];
    });
  }, []);

  const value = useMemo(
    () => ({
      pages,
      links,
      selectedPageId,
      searchQuery,
      selectedTags,
      setSelectedPageId,
      setSearchQuery,
      toggleTag,
      clearTags,
      getPageById,
      getPageWithRelations,
      getChildPages,
      getRootPages,
      getAllTags,
      getFilteredPages,
      addPage,
      updatePage,
      deletePage,
      addLink,
    }),
    [
      pages,
      links,
      selectedPageId,
      searchQuery,
      selectedTags,
      getPageById,
      getPageWithRelations,
      getChildPages,
      getRootPages,
      getAllTags,
      getFilteredPages,
      toggleTag,
      clearTags,
      addPage,
      updatePage,
      deletePage,
      addLink,
    ]
  );

  return (
    <KnowledgeContext.Provider value={value}>
      {children}
    </KnowledgeContext.Provider>
  );
}

export function useKnowledge() {
  const context = useContext(KnowledgeContext);
  if (context === undefined) {
    throw new Error("useKnowledge must be used within a KnowledgeProvider");
  }
  return context;
}
