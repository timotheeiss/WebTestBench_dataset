import { KnowledgeBase } from "@/types/knowledge";

export const initialKnowledgeBase: KnowledgeBase = {
  pages: [
    {
      id: "philosophy",
      title: "Philosophy",
      content: `Philosophy is the systematic study of fundamental questions about existence, knowledge, values, reason, mind, and language. It serves as the foundation for critical thinking and rigorous inquiry across all domains of human knowledge.

The word "philosophy" comes from the Greek *philosophia*, meaning "love of wisdom." This ancient discipline continues to inform modern science, ethics, and our understanding of consciousness itself.

Key branches include [[epistemology]], [[metaphysics]], ethics, logic, and aesthetics. Each explores different aspects of human experience and knowledge.`,
      parentId: null,
      tags: ["foundational", "inquiry", "wisdom"],
      citations: [],
      createdAt: "2024-01-15T10:00:00Z",
      updatedAt: "2024-03-20T14:30:00Z",
    },
    {
      id: "epistemology",
      title: "Epistemology",
      content: `Epistemology is the branch of philosophy concerned with the nature, sources, and limits of knowledge. It asks fundamental questions: What can we know? How do we know it? What justifies our beliefs?

## Core Questions

1. **What is knowledge?** The classical definition is "justified true belief," though this has been challenged by [[gettier-problems]].
2. **Sources of knowledge:** Reason, perception, testimony, memory, and introspection.
3. **Skepticism:** Can we truly know anything with certainty?

## Key Concepts

The distinction between *a priori* and *a posteriori* knowledge is central to epistemological inquiry. See [[rationalism-empiricism]] for the historical debate.`,
      parentId: "philosophy",
      tags: ["knowledge", "justification", "belief"],
      citations: [
        { pageId: "scientific-method", note: "Epistemology underlies scientific methodology" },
      ],
      createdAt: "2024-01-16T09:00:00Z",
      updatedAt: "2024-03-18T11:20:00Z",
    },
    {
      id: "metaphysics",
      title: "Metaphysics",
      content: `Metaphysics investigates the fundamental nature of reality, including the relationship between mind and matter, substance and attribute, and potentiality and actuality.

## Central Topics

- **Ontology:** The study of being and existence
- **Causation:** What makes things happen?
- **Time and space:** Are they real or constructs?
- **Free will:** Do we have genuine choice?

Metaphysical questions often intersect with [[epistemology]]—what we can know about reality depends on what reality is.

The mind-body problem, explored in [[philosophy-of-mind]], is a classic metaphysical puzzle.`,
      parentId: "philosophy",
      tags: ["reality", "existence", "ontology"],
      citations: [
        { pageId: "philosophy-of-mind", note: "Mind-body problem is fundamentally metaphysical" },
      ],
      createdAt: "2024-01-17T14:00:00Z",
      updatedAt: "2024-02-28T16:45:00Z",
    },
    {
      id: "gettier-problems",
      title: "Gettier Problems",
      content: `In 1963, Edmund Gettier published a three-page paper that revolutionized epistemology. He showed that justified true belief is not sufficient for knowledge.

## The Classic Example

Smith believes Jones will get the job and Jones has ten coins in his pocket. Smith forms the belief: "The person who will get the job has ten coins in their pocket."

Unknown to Smith, *he* will get the job, and *he* also happens to have ten coins. His belief is:
- **True** (he has ten coins and will get the job)
- **Justified** (based on reasonable evidence about Jones)
- **But not knowledge** (the justification doesn't connect to why it's true)

This has spawned decades of attempts to repair the definition of knowledge. See [[knowledge-definition-debate]].`,
      parentId: "epistemology",
      tags: ["knowledge", "counterexample", "justification"],
      citations: [
        { pageId: "epistemology", note: "Challenges classical JTB definition" },
      ],
      createdAt: "2024-02-01T10:30:00Z",
      updatedAt: "2024-03-15T09:00:00Z",
    },
    {
      id: "rationalism-empiricism",
      title: "Rationalism vs Empiricism",
      content: `The debate between rationalism and empiricism is one of the most significant in the history of philosophy.

## Rationalism

Rationalists like Descartes, Spinoza, and Leibniz argued that reason is the primary source of knowledge. Some knowledge is *innate*—present in the mind from birth.

**Key claim:** We can gain knowledge through pure reason, independent of sensory experience.

## Empiricism

Empiricists like Locke, Berkeley, and Hume held that all knowledge derives from sensory experience. The mind begins as a *tabula rasa* (blank slate).

**Key claim:** There is nothing in the intellect that was not first in the senses.

## Synthesis

Kant attempted to synthesize both views, arguing that while all knowledge begins with experience, not all arises from experience. The mind actively structures our experience through innate categories.

This debate directly influences [[scientific-method]] and modern cognitive science.`,
      parentId: "epistemology",
      tags: ["history", "knowledge-sources", "debate"],
      citations: [
        { pageId: "scientific-method", note: "Empiricism shaped modern scientific approach" },
        { pageId: "epistemology", note: "Central historical debate in epistemology" },
      ],
      createdAt: "2024-02-05T11:00:00Z",
      updatedAt: "2024-03-10T15:30:00Z",
    },
    {
      id: "philosophy-of-mind",
      title: "Philosophy of Mind",
      content: `Philosophy of mind examines the nature of mental phenomena and their relationship to the physical world.

## The Hard Problem of Consciousness

David Chalmers distinguished between "easy" problems (explaining cognitive functions) and the "hard" problem: Why is there subjective experience at all? Why does it *feel like* something to be conscious?

## Major Positions

1. **Dualism:** Mind and body are distinct substances (Descartes)
2. **Physicalism:** Mental states are physical states
3. **Functionalism:** Mental states are defined by their causal roles
4. **Panpsychism:** Consciousness is fundamental to reality

The question connects deeply to [[metaphysics]] and has implications for artificial intelligence research.`,
      parentId: "philosophy",
      tags: ["consciousness", "mind-body", "cognition"],
      citations: [
        { pageId: "metaphysics", note: "Addresses fundamental nature of mind" },
      ],
      createdAt: "2024-02-10T13:00:00Z",
      updatedAt: "2024-03-22T10:15:00Z",
    },
    {
      id: "scientific-method",
      title: "Scientific Method",
      content: `The scientific method is a systematic approach to investigating phenomena and acquiring knowledge. It emerged from philosophical inquiry and remains grounded in [[epistemology]].

## Core Steps

1. **Observation:** Noticing patterns or phenomena
2. **Hypothesis:** Proposing explanations
3. **Prediction:** Deriving testable consequences
4. **Experimentation:** Testing predictions
5. **Analysis:** Evaluating results
6. **Conclusion:** Accepting, rejecting, or modifying hypotheses

## Philosophical Foundations

Karl Popper emphasized **falsifiability**—genuine scientific theories must be capable of being proven false. Thomas Kuhn introduced the concept of **paradigm shifts** in scientific revolutions.

The method embodies the empiricist tradition from [[rationalism-empiricism]], while also requiring rational hypothesis formation.`,
      parentId: null,
      tags: ["science", "methodology", "inquiry"],
      citations: [
        { pageId: "epistemology", note: "Scientific method is applied epistemology" },
        { pageId: "rationalism-empiricism", note: "Synthesizes both traditions" },
      ],
      createdAt: "2024-02-15T09:30:00Z",
      updatedAt: "2024-03-25T14:00:00Z",
    },
    {
      id: "knowledge-definition-debate",
      title: "The Knowledge Definition Debate",
      content: `After Gettier's challenge to the JTB (Justified True Belief) definition, philosophers proposed various solutions.

## Proposed Solutions

### No False Lemmas
Knowledge requires that no false beliefs play an essential role in the justification.

### Reliabilism
A belief counts as knowledge if it's produced by a reliable cognitive process.

### Tracking Theory
You know P if you would believe P if it were true, and wouldn't believe P if it were false.

### Virtue Epistemology
Knowledge is true belief resulting from intellectual virtue.

## Current Status

No consensus has emerged. Some philosophers argue the concept of knowledge may be too complex for a simple definition.

This debate illustrates how a single counterexample (see [[gettier-problems]]) can reshape an entire field.`,
      parentId: "epistemology",
      tags: ["knowledge", "definition", "contemporary"],
      citations: [
        { pageId: "gettier-problems", note: "Responds to Gettier's challenge" },
        { pageId: "epistemology", note: "Central ongoing debate" },
      ],
      createdAt: "2024-02-20T16:00:00Z",
      updatedAt: "2024-03-28T11:30:00Z",
    },
  ],
  links: [
    { fromPageId: "philosophy", toPageId: "epistemology" },
    { fromPageId: "philosophy", toPageId: "metaphysics" },
    { fromPageId: "epistemology", toPageId: "gettier-problems" },
    { fromPageId: "epistemology", toPageId: "rationalism-empiricism" },
    { fromPageId: "epistemology", toPageId: "scientific-method" },
    { fromPageId: "metaphysics", toPageId: "philosophy-of-mind" },
    { fromPageId: "metaphysics", toPageId: "epistemology" },
    { fromPageId: "gettier-problems", toPageId: "knowledge-definition-debate" },
    { fromPageId: "rationalism-empiricism", toPageId: "scientific-method" },
    { fromPageId: "scientific-method", toPageId: "epistemology" },
    { fromPageId: "scientific-method", toPageId: "rationalism-empiricism" },
    { fromPageId: "philosophy-of-mind", toPageId: "metaphysics" },
    { fromPageId: "knowledge-definition-debate", toPageId: "gettier-problems" },
  ],
};
