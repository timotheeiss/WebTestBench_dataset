import { KnowledgeProvider } from "@/context/KnowledgeContext";
import { KnowledgeSidebar } from "@/components/knowledge/KnowledgeSidebar";
import { PageView } from "@/components/knowledge/PageView";

const Index = () => {
  return (
    <KnowledgeProvider>
      <div className="flex min-h-screen w-full bg-background">
        <KnowledgeSidebar />
        <PageView />
      </div>
    </KnowledgeProvider>
  );
};

export default Index;
