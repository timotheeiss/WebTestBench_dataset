import { Tag, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useKnowledge } from "@/context/KnowledgeContext";
import { Badge } from "@/components/ui/badge";

export function TagFilter() {
  const { getAllTags, selectedTags, toggleTag, clearTags } = useKnowledge();
  const allTags = getAllTags();

  if (allTags.length === 0) return null;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
          <Tag className="h-3 w-3" />
          <span>Tags</span>
        </div>
        {selectedTags.length > 0 && (
          <button
            onClick={clearTags}
            className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
          >
            <X className="h-3 w-3" />
            Clear
          </button>
        )}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {allTags.map((tag) => (
          <Badge
            key={tag}
            variant="outline"
            onClick={() => toggleTag(tag)}
            className={cn(
              "cursor-pointer text-xs px-2 py-0.5 transition-all duration-200",
              "hover:bg-tag/20 hover:border-tag/50",
              selectedTags.includes(tag) &&
                "bg-tag/20 border-tag/50 text-tag"
            )}
          >
            {tag}
          </Badge>
        ))}
      </div>
    </div>
  );
}
