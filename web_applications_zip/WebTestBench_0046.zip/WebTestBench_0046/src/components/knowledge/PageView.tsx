import { format } from "date-fns";
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  Clock,
  Tag,
  Link2,
  Quote,
  FileText,
} from "lucide-react";
import { useKnowledge } from "@/context/KnowledgeContext";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { PageContent } from "./PageContent";
import { cn } from "@/lib/utils";

export function PageView() {
  const { selectedPageId, getPageWithRelations, setSelectedPageId, toggleTag } =
    useKnowledge();

  if (!selectedPageId) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Select a page to view</p>
        </div>
      </div>
    );
  }

  const pageData = getPageWithRelations(selectedPageId);

  if (!pageData) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        Page not found
      </div>
    );
  }

  const { children, backlinks, citedBy, citesPages, ...page } = pageData;

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-8 py-12 animate-fade-in">
        {/* Header */}
        <header className="mb-8">
          <h1 className="text-4xl font-serif font-bold text-foreground mb-4 tracking-tight">
            {page.title}
          </h1>

          {/* Meta */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              <span>Created {format(new Date(page.createdAt), "MMM d, yyyy")}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>Updated {format(new Date(page.updatedAt), "MMM d, yyyy")}</span>
            </div>
          </div>

          {/* Tags */}
          {page.tags.length > 0 && (
            <div className="flex items-center gap-2 mt-4">
              <Tag className="h-4 w-4 text-muted-foreground" />
              <div className="flex flex-wrap gap-1.5">
                {page.tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    onClick={() => toggleTag(tag)}
                    className="cursor-pointer hover:bg-tag/20 hover:text-tag transition-colors"
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </header>

        <Separator className="mb-8" />

        {/* Content */}
        <article className="mb-12">
          <PageContent content={page.content} />
        </article>

        {/* Children Pages */}
        {children.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-serif font-semibold mb-4 flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              Subpages
            </h3>
            <div className="grid gap-2">
              {children.map((child) => (
                <button
                  key={child.id}
                  onClick={() => setSelectedPageId(child.id)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg bg-card border border-border hover:border-primary/30 hover:bg-card/80 transition-all group text-left"
                >
                  <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  <span className="font-medium">{child.title}</span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Citations - This page cites */}
        {citesPages.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-serif font-semibold mb-4 flex items-center gap-2">
              <Quote className="h-4 w-4 text-citation" />
              Cites
            </h3>
            <div className="space-y-2">
              {citesPages.map((cite) => (
                <button
                  key={cite.page.id}
                  onClick={() => setSelectedPageId(cite.page.id)}
                  className="w-full flex items-start gap-3 px-4 py-3 rounded-lg bg-card border border-border hover:border-citation/30 transition-all group text-left"
                >
                  <ArrowRight className="h-4 w-4 text-citation mt-0.5 shrink-0" />
                  <div>
                    <span className="font-medium block">{cite.page.title}</span>
                    {cite.note && (
                      <span className="text-sm text-muted-foreground italic">
                        "{cite.note}"
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Cited By */}
        {citedBy.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-serif font-semibold mb-4 flex items-center gap-2">
              <Quote className="h-4 w-4 text-backlink" />
              Cited By
            </h3>
            <div className="space-y-2">
              {citedBy.map((cite) => (
                <button
                  key={cite.page.id}
                  onClick={() => setSelectedPageId(cite.page.id)}
                  className="w-full flex items-start gap-3 px-4 py-3 rounded-lg bg-card border border-border hover:border-backlink/30 transition-all group text-left"
                >
                  <ArrowLeft className="h-4 w-4 text-backlink mt-0.5 shrink-0" />
                  <div>
                    <span className="font-medium block">{cite.page.title}</span>
                    {cite.note && (
                      <span className="text-sm text-muted-foreground italic">
                        "{cite.note}"
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Backlinks */}
        {backlinks.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-serif font-semibold mb-4 flex items-center gap-2">
              <Link2 className="h-4 w-4 text-primary" />
              Linked From
            </h3>
            <div className="flex flex-wrap gap-2">
              {backlinks.map((link) => (
                <button
                  key={link.page.id}
                  onClick={() => setSelectedPageId(link.page.id)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-sm font-medium",
                    "bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                  )}
                >
                  {link.page.title}
                </button>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
