import { FileText, ArrowRight } from "lucide-react";
import { useKnowledge } from "@/context/KnowledgeContext";
import { Badge } from "@/components/ui/badge";

export function SearchResults() {
  const { searchQuery, selectedTags, getFilteredPages, setSelectedPageId, setSearchQuery, clearTags } =
    useKnowledge();

  const isFiltering = searchQuery.trim() || selectedTags.length > 0;
  const filteredPages = getFilteredPages();

  if (!isFiltering) return null;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>{filteredPages.length} results</span>
        <button
          onClick={() => {
            setSearchQuery("");
            clearTags();
          }}
          className="hover:text-foreground transition-colors"
        >
          Clear filters
        </button>
      </div>
      <div className="space-y-1 max-h-60 overflow-y-auto">
        {filteredPages.map((page) => (
          <button
            key={page.id}
            onClick={() => {
              setSelectedPageId(page.id);
              setSearchQuery("");
            }}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-sidebar-accent transition-colors text-left group"
          >
            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="truncate flex-1">{page.title}</span>
            <ArrowRight className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        ))}
        {filteredPages.length === 0 && (
          <div className="text-center py-4 text-muted-foreground text-sm">
            No pages found
          </div>
        )}
      </div>
    </div>
  );
}
