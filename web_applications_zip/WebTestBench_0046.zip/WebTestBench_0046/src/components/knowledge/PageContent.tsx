import { useMemo } from "react";
import { useKnowledge } from "@/context/KnowledgeContext";

interface PageContentProps {
  content: string;
}

export function PageContent({ content }: PageContentProps) {
  const { getPageById, setSelectedPageId } = useKnowledge();

  const renderedContent = useMemo(() => {
    // Parse wiki-style links [[page-id]] and markdown
    const lines = content.split("\n");
    
    return lines.map((line, lineIndex) => {
      // Check for headers
      if (line.startsWith("## ")) {
        return (
          <h2 key={lineIndex} className="text-2xl font-serif font-semibold mt-8 mb-4 text-foreground">
            {line.slice(3)}
          </h2>
        );
      }
      if (line.startsWith("### ")) {
        return (
          <h3 key={lineIndex} className="text-xl font-serif font-medium mt-6 mb-3 text-foreground">
            {line.slice(4)}
          </h3>
        );
      }

      // Check for numbered lists
      const numberedMatch = line.match(/^(\d+)\.\s\*\*(.+?)\*\*(.*)$/);
      if (numberedMatch) {
        return (
          <div key={lineIndex} className="flex gap-3 my-2">
            <span className="text-primary font-medium">{numberedMatch[1]}.</span>
            <span>
              <strong className="text-foreground">{numberedMatch[2]}</strong>
              {parseInlineContent(numberedMatch[3], getPageById, setSelectedPageId)}
            </span>
          </div>
        );
      }

      // Check for bullet points
      if (line.startsWith("- **")) {
        const match = line.match(/^- \*\*(.+?)\*\*:?\s*(.*)$/);
        if (match) {
          return (
            <div key={lineIndex} className="flex gap-3 my-2 ml-4">
              <span className="text-primary">•</span>
              <span>
                <strong className="text-foreground">{match[1]}:</strong>{" "}
                {parseInlineContent(match[2], getPageById, setSelectedPageId)}
              </span>
            </div>
          );
        }
      }

      if (line.startsWith("- ")) {
        return (
          <div key={lineIndex} className="flex gap-3 my-2 ml-4">
            <span className="text-primary">•</span>
            <span>{parseInlineContent(line.slice(2), getPageById, setSelectedPageId)}</span>
          </div>
        );
      }

      // Empty lines
      if (line.trim() === "") {
        return <div key={lineIndex} className="h-4" />;
      }

      // Regular paragraph
      return (
        <p key={lineIndex} className="my-3 leading-relaxed text-foreground/90">
          {parseInlineContent(line, getPageById, setSelectedPageId)}
        </p>
      );
    });
  }, [content, getPageById, setSelectedPageId]);

  return <div className="prose-custom">{renderedContent}</div>;
}

function parseInlineContent(
  text: string,
  getPageById: (id: string) => any,
  setSelectedPageId: (id: string) => void
): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let keyIndex = 0;

  while (remaining.length > 0) {
    // Check for wiki links [[page-id]]
    const wikiMatch = remaining.match(/\[\[([^\]]+)\]\]/);
    // Check for italic *text*
    const italicMatch = remaining.match(/\*([^*]+)\*/);
    // Check for bold **text**
    const boldMatch = remaining.match(/\*\*([^*]+)\*\*/);

    // Find the earliest match
    const matches = [
      wikiMatch ? { type: "wiki", match: wikiMatch, index: remaining.indexOf(wikiMatch[0]) } : null,
      boldMatch ? { type: "bold", match: boldMatch, index: remaining.indexOf(boldMatch[0]) } : null,
      italicMatch && !boldMatch?.index?.toString().includes(italicMatch.index?.toString() || "")
        ? { type: "italic", match: italicMatch, index: remaining.indexOf(italicMatch[0]) }
        : null,
    ]
      .filter(Boolean)
      .sort((a, b) => a!.index - b!.index);

    if (matches.length === 0) {
      parts.push(<span key={keyIndex++}>{remaining}</span>);
      break;
    }

    const first = matches[0]!;

    // Add text before the match
    if (first.index > 0) {
      parts.push(<span key={keyIndex++}>{remaining.slice(0, first.index)}</span>);
    }

    if (first.type === "wiki") {
      const pageId = first.match![1];
      const page = getPageById(pageId);
      parts.push(
        <button
          key={keyIndex++}
          onClick={() => setSelectedPageId(pageId)}
          className="text-link hover:text-link-hover underline underline-offset-2 transition-colors font-medium"
        >
          {page?.title || pageId}
        </button>
      );
      remaining = remaining.slice(first.index + first.match![0].length);
    } else if (first.type === "bold") {
      parts.push(
        <strong key={keyIndex++} className="font-semibold text-foreground">
          {first.match![1]}
        </strong>
      );
      remaining = remaining.slice(first.index + first.match![0].length);
    } else if (first.type === "italic") {
      parts.push(
        <em key={keyIndex++} className="italic text-foreground/80">
          {first.match![1]}
        </em>
      );
      remaining = remaining.slice(first.index + first.match![0].length);
    }
  }

  return parts;
}
