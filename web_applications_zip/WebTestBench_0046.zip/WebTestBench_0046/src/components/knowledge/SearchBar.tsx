import { Search, X } from "lucide-react";
import { useKnowledge } from "@/context/KnowledgeContext";
import { Input } from "@/components/ui/input";

export function SearchBar() {
  const { searchQuery, setSearchQuery } = useKnowledge();

  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      <Input
        type="text"
        placeholder="Search pages, tags, citations..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="pl-9 pr-9 bg-sidebar-accent border-sidebar-border focus:border-primary/50 focus:ring-primary/20"
      />
      {searchQuery && (
        <button
          onClick={() => setSearchQuery("")}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
