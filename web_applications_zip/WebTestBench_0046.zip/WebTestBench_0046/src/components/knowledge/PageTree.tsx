import { useState } from "react";
import { ChevronRight, FileText, FolderOpen, Folder } from "lucide-react";
import { cn } from "@/lib/utils";
import { useKnowledge } from "@/context/KnowledgeContext";
import { KnowledgePage } from "@/types/knowledge";

interface PageTreeItemProps {
  page: KnowledgePage;
  level: number;
}

function PageTreeItem({ page, level }: PageTreeItemProps) {
  const { selectedPageId, setSelectedPageId, getChildPages } = useKnowledge();
  const [isExpanded, setIsExpanded] = useState(true);
  const children = getChildPages(page.id);
  const hasChildren = children.length > 0;
  const isSelected = selectedPageId === page.id;

  return (
    <div className="animate-fade-in" style={{ animationDelay: `${level * 30}ms` }}>
      <button
        onClick={() => setSelectedPageId(page.id)}
        className={cn(
          "w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-all duration-200",
          "hover:bg-sidebar-accent group",
          isSelected && "bg-sidebar-accent text-sidebar-primary font-medium"
        )}
        style={{ paddingLeft: `${12 + level * 16}px` }}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className="p-0.5 hover:bg-sidebar-border rounded transition-colors"
          >
            <ChevronRight
              className={cn(
                "h-3.5 w-3.5 text-muted-foreground transition-transform duration-200",
                isExpanded && "rotate-90"
              )}
            />
          </button>
        ) : (
          <span className="w-4" />
        )}
        
        {hasChildren ? (
          isExpanded ? (
            <FolderOpen className="h-4 w-4 text-primary/80" />
          ) : (
            <Folder className="h-4 w-4 text-muted-foreground" />
          )
        ) : (
          <FileText className="h-4 w-4 text-muted-foreground group-hover:text-foreground/80" />
        )}
        
        <span className="truncate">{page.title}</span>
      </button>

      {hasChildren && isExpanded && (
        <div className="ml-2 border-l border-sidebar-border/50">
          {children.map((child) => (
            <PageTreeItem key={child.id} page={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export function PageTree() {
  const { getRootPages } = useKnowledge();
  const rootPages = getRootPages();

  return (
    <div className="space-y-1">
      {rootPages.map((page) => (
        <PageTreeItem key={page.id} page={page} level={0} />
      ))}
    </div>
  );
}
