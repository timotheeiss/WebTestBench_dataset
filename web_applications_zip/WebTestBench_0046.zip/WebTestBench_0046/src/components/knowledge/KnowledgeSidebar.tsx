import { BookOpen, PanelLeftClose, PanelLeft, Plus } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { SearchBar } from "./SearchBar";
import { TagFilter } from "./TagFilter";
import { PageTree } from "./PageTree";
import { SearchResults } from "./SearchResults";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useKnowledge } from "@/context/KnowledgeContext";

export function KnowledgeSidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { searchQuery, selectedTags } = useKnowledge();
  const isFiltering = searchQuery.trim() || selectedTags.length > 0;

  return (
    <aside
      className={cn(
        "h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300",
        isCollapsed ? "w-14" : "w-72"
      )}
    >
      {/* Header */}
      <div className="h-14 flex items-center justify-between px-4 border-b border-sidebar-border shrink-0">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center glow-amber">
              <BookOpen className="h-4 w-4 text-primary" />
            </div>
            <span className="font-serif font-semibold text-lg">Nexus</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="h-8 w-8 shrink-0"
        >
          {isCollapsed ? (
            <PanelLeft className="h-4 w-4" />
          ) : (
            <PanelLeftClose className="h-4 w-4" />
          )}
        </Button>
      </div>

      {!isCollapsed && (
        <>
          {/* Search */}
          <div className="p-4 space-y-4">
            <SearchBar />
            
            {isFiltering ? (
              <SearchResults />
            ) : (
              <TagFilter />
            )}
          </div>

          <Separator className="bg-sidebar-border" />

          {/* Page Tree */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Pages
              </span>
              <Button variant="ghost" size="icon" className="h-6 w-6">
                <Plus className="h-3.5 w-3.5" />
              </Button>
            </div>
            <PageTree />
          </div>
        </>
      )}

      {isCollapsed && (
        <div className="flex-1 flex flex-col items-center py-4 gap-4">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center glow-amber">
            <BookOpen className="h-4 w-4 text-primary" />
          </div>
        </div>
      )}
    </aside>
  );
}
