import { Chapter } from '@/data/document';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChapterNavigationProps {
  chapters: Chapter[];
  currentChapterId: string;
  onChapterClick: (chapterId: string) => void;
}

export function ChapterNavigation({ chapters, currentChapterId, onChapterClick }: ChapterNavigationProps) {
  return (
    <nav className="space-y-1">
      {chapters.map((chapter) => (
        <button
          key={chapter.id}
          onClick={() => onChapterClick(chapter.id)}
          className={cn(
            "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all duration-200",
            currentChapterId === chapter.id
              ? "bg-primary text-primary-foreground shadow-card"
              : "hover:bg-secondary text-ink"
          )}
        >
          <span className={cn(
            "flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full font-display text-sm",
            currentChapterId === chapter.id
              ? "bg-primary-foreground/20"
              : "bg-secondary"
          )}>
            {chapter.number}
          </span>
          <span className="flex-1 font-ui text-sm truncate">{chapter.title}</span>
          <ChevronRight className={cn(
            "w-4 h-4 flex-shrink-0 transition-transform",
            currentChapterId === chapter.id ? "translate-x-0.5" : "opacity-50"
          )} />
        </button>
      ))}
    </nav>
  );
}
