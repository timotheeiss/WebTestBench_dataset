import { ViewLevel } from '@/types/reading';
import { BookOpen, FileText, Layers } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ViewSwitcherProps {
  currentView: ViewLevel;
  onViewChange: (view: ViewLevel) => void;
}

const views: { level: ViewLevel; label: string; icon: React.ReactNode; description: string }[] = [
  { 
    level: 'summary', 
    label: 'Summary', 
    icon: <FileText className="w-4 h-4" />,
    description: 'Brief overview'
  },
  { 
    level: 'chapter', 
    label: 'Chapters', 
    icon: <Layers className="w-4 h-4" />,
    description: 'Chapter breakdown'
  },
  { 
    level: 'full', 
    label: 'Full Text', 
    icon: <BookOpen className="w-4 h-4" />,
    description: 'Complete content'
  },
];

export function ViewSwitcher({ currentView, onViewChange }: ViewSwitcherProps) {
  return (
    <div className="flex items-center gap-1 p-1 bg-secondary/50 rounded-lg">
      {views.map(({ level, label, icon, description }) => (
        <button
          key={level}
          onClick={() => onViewChange(level)}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-md font-ui text-sm transition-all duration-200",
            currentView === level
              ? "bg-paper shadow-card text-ink"
              : "text-ink-muted hover:text-ink hover:bg-paper/50"
          )}
          title={description}
        >
          {icon}
          <span className="hidden sm:inline">{label}</span>
        </button>
      ))}
    </div>
  );
}
