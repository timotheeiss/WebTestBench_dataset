import { useState } from 'react';
import { Plus, X, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AddCommentButtonProps {
  onAdd: (text: string) => void;
}

export function AddCommentButton({ onAdd }: AddCommentButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [text, setText] = useState('');

  const handleSubmit = () => {
    if (text.trim()) {
      onAdd(text.trim());
      setText('');
      setIsOpen(false);
    }
  };

  const handleCancel = () => {
    setText('');
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="inline-flex items-center gap-1 px-2 py-0.5 mx-1 text-xs font-ui text-primary bg-primary/10 rounded hover:bg-primary/20 transition-colors"
        title="Add your note"
      >
        <Plus className="w-3 h-3" />
        <span>Add Note</span>
      </button>
    );
  }

  return (
    <div className="block mt-3 mb-4 ml-4 pl-4 border-l-2 border-primary bg-highlight/30 rounded-r-lg p-4 animate-fade-in">
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="font-ui text-sm font-medium text-ink">Add Your Note</span>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write your thoughts, questions, or insights..."
          className="w-full p-3 text-sm bg-paper border border-border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary placeholder:text-ink-muted"
          rows={3}
          autoFocus
        />
        <div className="flex items-center gap-2">
          <button
            onClick={handleSubmit}
            disabled={!text.trim()}
            className={cn(
              "flex items-center gap-1 px-3 py-1.5 text-xs font-ui rounded transition-colors",
              text.trim()
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-muted text-muted-foreground cursor-not-allowed"
            )}
          >
            <Check className="w-3 h-3" />
            Save Note
          </button>
          <button
            onClick={handleCancel}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-ui text-ink-muted hover:text-ink transition-colors"
          >
            <X className="w-3 h-3" />
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
