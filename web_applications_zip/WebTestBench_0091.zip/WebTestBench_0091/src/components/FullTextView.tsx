import { Chapter } from '@/data/document';
import { UserComment } from '@/types/reading';
import { InlineComment, UserCommentDisplay } from './InlineComment';
import { AddCommentButton } from './AddCommentButton';

interface FullTextViewProps {
  chapter: Chapter;
  likedComments: Set<string>;
  bookmarkedComments: Set<string>;
  userComments: UserComment[];
  onToggleLike: (commentId: string) => void;
  onToggleBookmark: (commentId: string) => void;
  onAddUserComment: (segmentId: string, text: string) => void;
  onEditUserComment: (commentId: string, text: string) => void;
  onDeleteUserComment: (commentId: string) => void;
}

export function FullTextView({
  chapter,
  likedComments,
  bookmarkedComments,
  userComments,
  onToggleLike,
  onToggleBookmark,
  onAddUserComment,
  onEditUserComment,
  onDeleteUserComment,
}: FullTextViewProps) {
  const getUserCommentsForSegment = (segmentId: string) => 
    userComments.filter(c => c.segmentId === segmentId);

  return (
    <article className="animate-fade-in">
      {/* Chapter Header */}
      <header className="mb-10">
        <div className="flex items-center gap-3 mb-4">
          <span className="px-3 py-1 bg-primary/10 rounded-full font-ui text-sm text-primary">
            Chapter {chapter.number}
          </span>
        </div>
        <h1 className="font-display text-3xl md:text-4xl font-bold text-ink leading-tight">
          {chapter.title}
        </h1>
      </header>

      {/* Full Content */}
      <div className="space-y-12">
        {chapter.sections.map((section) => (
          <section key={section.id} id={section.id} className="scroll-mt-24">
            <h2 className="font-display text-2xl font-semibold text-ink mb-6 pb-3 border-b border-border">
              {section.title}
            </h2>
            <div className="space-y-6">
              {section.segments.map((segment) => {
                const segmentUserComments = getUserCommentsForSegment(segment.id);
                
                return (
                  <div key={segment.id} id={segment.id} className="scroll-mt-24 group">
                    <p className="text-lg leading-[1.9] text-ink/90">
                      {segment.content}
                      
                      {/* System Comments */}
                      {segment.comments?.map((comment) => (
                        <InlineComment
                          key={comment.id}
                          comment={comment}
                          isLiked={likedComments.has(comment.id)}
                          isBookmarked={bookmarkedComments.has(comment.id)}
                          onToggleLike={() => onToggleLike(comment.id)}
                          onToggleBookmark={() => onToggleBookmark(comment.id)}
                        />
                      ))}
                      
                      {/* User Comments */}
                      {segmentUserComments.map((comment) => (
                        <UserCommentDisplay
                          key={comment.id}
                          comment={comment}
                          onEdit={(text) => onEditUserComment(comment.id, text)}
                          onDelete={() => onDeleteUserComment(comment.id)}
                        />
                      ))}
                      
                      {/* Add Comment Button */}
                      <span className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <AddCommentButton
                          onAdd={(text) => onAddUserComment(segment.id, text)}
                        />
                      </span>
                    </p>
                  </div>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </article>
  );
}
