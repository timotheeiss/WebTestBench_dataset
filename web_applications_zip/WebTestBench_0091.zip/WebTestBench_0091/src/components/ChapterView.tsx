import { Chapter } from '@/data/document';
import { ArrowRight, FileText } from 'lucide-react';

interface ChapterViewProps {
  chapter: Chapter;
  onNavigateToSection: (sectionId: string) => void;
}

export function ChapterView({ chapter, onNavigateToSection }: ChapterViewProps) {
  return (
    <article className="animate-fade-in">
      {/* Chapter Header */}
      <header className="mb-10">
        <div className="flex items-center gap-3 mb-4">
          <span className="px-3 py-1 bg-primary/10 rounded-full font-ui text-sm text-primary">
            Chapter {chapter.number}
          </span>
        </div>
        <h1 className="font-display text-3xl md:text-4xl font-bold text-ink mb-6 leading-tight">
          {chapter.title}
        </h1>
        <p className="text-lg leading-relaxed text-ink/90 pb-6 border-b border-border">
          {chapter.summary}
        </p>
      </header>

      {/* Sections */}
      <section className="space-y-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-secondary rounded-lg">
            <FileText className="w-4 h-4 text-secondary-foreground" />
          </div>
          <h2 className="font-display text-xl font-semibold text-ink">Sections</h2>
        </div>
        
        {chapter.sections.map((section, index) => (
          <button
            key={section.id}
            onClick={() => onNavigateToSection(section.id)}
            className="group w-full p-5 bg-paper hover:bg-paper-hover border border-border rounded-xl text-left transition-all duration-200 shadow-card hover:shadow-reading"
          >
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-sm text-ink-muted font-ui">
                    Section {index + 1}
                  </span>
                </div>
                <h3 className="font-display text-lg font-semibold text-ink mb-2 group-hover:text-primary transition-colors">
                  {section.title}
                </h3>
                <p className="text-ink-muted text-sm leading-relaxed">
                  {section.summary}
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-ink-muted group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
            </div>
          </button>
        ))}
      </section>
    </article>
  );
}
