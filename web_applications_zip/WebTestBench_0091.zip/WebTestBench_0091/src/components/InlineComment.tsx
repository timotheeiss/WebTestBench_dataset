import { useState } from 'react';
import { Comment } from '@/data/document';
import { UserComment } from '@/types/reading';
import { Heart, Bookmark, ChevronDown, ChevronUp, Trash2, Edit2, Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface InlineCommentProps {
  comment: Comment;
  isLiked: boolean;
  isBookmarked: boolean;
  onToggleLike: () => void;
  onToggleBookmark: () => void;
}

export function InlineComment({ 
  comment, 
  isLiked, 
  isBookmarked, 
  onToggleLike, 
  onToggleBookmark 
}: InlineCommentProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="inline">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={cn(
          "inline-flex items-center gap-1 px-2 py-0.5 mx-1 text-xs font-ui rounded transition-all duration-200",
          isExpanded 
            ? "bg-primary text-primary-foreground" 
            : "bg-highlight-accent text-accent-foreground hover:bg-primary/20"
        )}
      >
        <span className="max-w-[120px] truncate">{comment.author}</span>
        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>
      
      {isExpanded && (
        <div className="block mt-3 mb-4 ml-4 pl-4 border-l-2 border-comment bg-comment rounded-r-lg p-4 animate-fade-in">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-ui text-sm font-medium text-ink">{comment.author}</span>
                <span className="text-xs text-ink-muted">{comment.createdAt}</span>
              </div>
              <p className="text-sm text-ink leading-relaxed">{comment.text}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={onToggleLike}
                className={cn(
                  "flex items-center gap-1 px-2 py-1 rounded text-xs font-ui transition-colors",
                  isLiked 
                    ? "text-liked bg-liked/10" 
                    : "text-ink-muted hover:text-liked hover:bg-liked/5"
                )}
              >
                <Heart className={cn("w-3.5 h-3.5", isLiked && "fill-current")} />
                <span>{comment.likes + (isLiked ? 1 : 0)}</span>
              </button>
              <button
                onClick={onToggleBookmark}
                className={cn(
                  "p-1 rounded transition-colors",
                  isBookmarked 
                    ? "text-bookmarked" 
                    : "text-ink-muted hover:text-bookmarked"
                )}
                title={isBookmarked ? "Remove bookmark" : "Bookmark comment"}
              >
                <Bookmark className={cn("w-4 h-4", isBookmarked && "fill-current")} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface UserCommentDisplayProps {
  comment: UserComment;
  onEdit: (text: string) => void;
  onDelete: () => void;
}

export function UserCommentDisplay({ comment, onEdit, onDelete }: UserCommentDisplayProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(comment.text);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(comment.text);
    setIsEditing(false);
  };

  return (
    <div className="inline">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={cn(
          "inline-flex items-center gap-1 px-2 py-0.5 mx-1 text-xs font-ui rounded transition-all duration-200",
          isExpanded 
            ? "bg-primary text-primary-foreground" 
            : "bg-highlight text-secondary-foreground hover:bg-primary/20"
        )}
      >
        <span>My Note</span>
        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>
      
      {isExpanded && (
        <div className="block mt-3 mb-4 ml-4 pl-4 border-l-2 border-primary/30 bg-highlight/50 rounded-r-lg p-4 animate-fade-in">
          {isEditing ? (
            <div className="space-y-2">
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full p-2 text-sm bg-paper border border-border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                rows={3}
                autoFocus
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSave}
                  className="flex items-center gap-1 px-3 py-1 text-xs font-ui bg-primary text-primary-foreground rounded hover:bg-primary/90 transition-colors"
                >
                  <Check className="w-3 h-3" />
                  Save
                </button>
                <button
                  onClick={handleCancel}
                  className="flex items-center gap-1 px-3 py-1 text-xs font-ui text-ink-muted hover:text-ink transition-colors"
                >
                  <X className="w-3 h-3" />
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-ui text-sm font-medium text-ink">Your Note</span>
                  <span className="text-xs text-ink-muted">
                    {new Date(comment.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <p className="text-sm text-ink leading-relaxed">{comment.text}</p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-1 text-ink-muted hover:text-ink transition-colors"
                  title="Edit note"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={onDelete}
                  className="p-1 text-ink-muted hover:text-destructive transition-colors"
                  title="Delete note"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
