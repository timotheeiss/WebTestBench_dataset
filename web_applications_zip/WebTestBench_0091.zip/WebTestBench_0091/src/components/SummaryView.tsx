import { Document } from '@/data/document';
import { BookOpen, Layers } from 'lucide-react';

interface SummaryViewProps {
  document: Document;
  onNavigateToChapter: (chapterId: string) => void;
}

export function SummaryView({ document, onNavigateToChapter }: SummaryViewProps) {
  return (
    <article className="animate-fade-in">
      {/* Document Header */}
      <header className="mb-12 text-center">
        <h1 className="font-display text-4xl md:text-5xl font-bold text-ink mb-4 leading-tight">
          {document.title}
        </h1>
        <p className="font-ui text-lg text-ink-muted">by {document.author}</p>
      </header>

      {/* Summary Section */}
      <section className="mb-12">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <BookOpen className="w-5 h-5 text-primary" />
          </div>
          <h2 className="font-display text-2xl font-semibold text-ink">Overview</h2>
        </div>
        <p className="text-lg leading-relaxed text-ink/90">
          {document.summary}
        </p>
      </section>

      {/* Chapters Preview */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Layers className="w-5 h-5 text-primary" />
          </div>
          <h2 className="font-display text-2xl font-semibold text-ink">Chapters</h2>
        </div>
        <div className="grid gap-4">
          {document.chapters.map((chapter) => (
            <button
              key={chapter.id}
              onClick={() => onNavigateToChapter(chapter.id)}
              className="group p-6 bg-paper hover:bg-paper-hover border border-border rounded-xl text-left transition-all duration-200 shadow-card hover:shadow-reading"
            >
              <div className="flex items-start gap-4">
                <span className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-secondary rounded-full font-display text-lg text-secondary-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  {chapter.number}
                </span>
                <div className="flex-1 min-w-0">
                  <h3 className="font-display text-xl font-semibold text-ink mb-2 group-hover:text-primary transition-colors">
                    {chapter.title}
                  </h3>
                  <p className="text-ink-muted leading-relaxed line-clamp-2">
                    {chapter.summary}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </article>
  );
}
