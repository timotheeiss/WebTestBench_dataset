import { useEffect, useRef, useCallback } from 'react';
import { Document } from '@/data/document';
import { ViewLevel, ReadingPosition } from '@/types/reading';
import { ViewSwitcher } from './ViewSwitcher';
import { ChapterNavigation } from './ChapterNavigation';
import { SummaryView } from './SummaryView';
import { ChapterView } from './ChapterView';
import { FullTextView } from './FullTextView';
import { useReadingState } from '@/hooks/useReadingState';
import { Menu, X, Bookmark, Heart } from 'lucide-react';
import { useState, useMemo } from 'react';
import { cn } from '@/lib/utils';

interface DocumentReaderProps {
  document: Document;
}

export function DocumentReader({ document }: DocumentReaderProps) {
  const {
    viewLevel,
    position,
    likedComments,
    bookmarkedComments,
    userComments,
    setViewLevel,
    setPosition,
    toggleLike,
    toggleBookmark,
    addUserComment,
    removeUserComment,
    editUserComment,
  } = useReadingState(document.chapters[0].id);

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const currentChapter = useMemo(() => 
    document.chapters.find(c => c.id === position.chapterId) || document.chapters[0],
    [document.chapters, position.chapterId]
  );

  const scrollToElement = useCallback((elementId: string) => {
    setTimeout(() => {
      const element = window.document.getElementById(elementId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  }, []);

  const handleViewChange = useCallback((newLevel: ViewLevel) => {
    // Store current scroll position context before view change
    setViewLevel(newLevel);
    
    // For chapter and full views, scroll to the current chapter/section
    if (newLevel === 'full' && position.sectionId) {
      scrollToElement(position.sectionId);
    } else if (newLevel === 'chapter' || newLevel === 'full') {
      if (contentRef.current) {
        contentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  }, [setViewLevel, position, scrollToElement]);

  const handleChapterClick = useCallback((chapterId: string) => {
    setPosition({ chapterId });
    setIsSidebarOpen(false);
    if (contentRef.current) {
      contentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [setPosition]);

  const handleNavigateToChapter = useCallback((chapterId: string) => {
    setPosition({ chapterId });
    setViewLevel('chapter');
    if (contentRef.current) {
      contentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [setPosition, setViewLevel]);

  const handleNavigateToSection = useCallback((sectionId: string) => {
    setPosition({ ...position, sectionId });
    setViewLevel('full');
    scrollToElement(sectionId);
  }, [position, setPosition, setViewLevel, scrollToElement]);

  // Count stats for sidebar
  const likedCount = likedComments.size;
  const bookmarkedCount = bookmarkedComments.size;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            {/* Mobile menu button */}
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-2 -ml-2 text-ink-muted hover:text-ink transition-colors"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Title - truncated on mobile */}
            <h1 className="font-display text-lg md:text-xl font-semibold text-ink truncate flex-1 lg:flex-initial">
              {document.title}
            </h1>

            {/* View Switcher */}
            <ViewSwitcher currentView={viewLevel} onViewChange={handleViewChange} />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto flex">
        {/* Sidebar */}
        <aside className={cn(
          "fixed lg:sticky top-[73px] left-0 z-30 h-[calc(100vh-73px)] w-72 bg-background lg:bg-transparent border-r border-border lg:border-0 transition-transform duration-300 overflow-y-auto scrollbar-reading",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}>
          <div className="p-4 lg:py-8 lg:pr-6">
            {/* Stats */}
            <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
              <div className="flex items-center gap-2 text-sm text-ink-muted">
                <Heart className={cn("w-4 h-4", likedCount > 0 && "text-liked fill-liked")} />
                <span>{likedCount} liked</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-ink-muted">
                <Bookmark className={cn("w-4 h-4", bookmarkedCount > 0 && "text-bookmarked fill-bookmarked")} />
                <span>{bookmarkedCount} saved</span>
              </div>
            </div>

            {/* Chapter Navigation */}
            <h2 className="font-ui text-sm font-medium text-ink-muted uppercase tracking-wider mb-4">
              Contents
            </h2>
            <ChapterNavigation
              chapters={document.chapters}
              currentChapterId={position.chapterId}
              onChapterClick={handleChapterClick}
            />
          </div>
        </aside>

        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-ink/20 z-20 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main 
          ref={contentRef}
          className="flex-1 min-w-0 px-4 py-8 lg:px-12 lg:py-12"
        >
          <div className="reading-width mx-auto">
            {viewLevel === 'summary' && (
              <SummaryView 
                document={document} 
                onNavigateToChapter={handleNavigateToChapter}
              />
            )}
            {viewLevel === 'chapter' && (
              <ChapterView 
                chapter={currentChapter}
                onNavigateToSection={handleNavigateToSection}
              />
            )}
            {viewLevel === 'full' && (
              <FullTextView
                chapter={currentChapter}
                likedComments={likedComments}
                bookmarkedComments={bookmarkedComments}
                userComments={userComments}
                onToggleLike={toggleLike}
                onToggleBookmark={toggleBookmark}
                onAddUserComment={addUserComment}
                onEditUserComment={editUserComment}
                onDeleteUserComment={removeUserComment}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
