import { useState, useCallback, useMemo } from 'react';
import { ViewLevel, ReadingPosition, UserComment, ReadingState } from '@/types/reading';

const STORAGE_KEY = 'mindful-reader-state';

function loadState(): Partial<ReadingState> {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        ...parsed,
        likedComments: new Set(parsed.likedComments || []),
        bookmarkedComments: new Set(parsed.bookmarkedComments || []),
      };
    }
  } catch (e) {
    console.warn('Failed to load reading state:', e);
  }
  return {};
}

function saveState(state: ReadingState) {
  try {
    const toStore = {
      ...state,
      likedComments: Array.from(state.likedComments),
      bookmarkedComments: Array.from(state.bookmarkedComments),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toStore));
  } catch (e) {
    console.warn('Failed to save reading state:', e);
  }
}

export function useReadingState(initialChapterId: string) {
  const storedState = useMemo(() => loadState(), []);
  
  const [viewLevel, setViewLevelState] = useState<ViewLevel>(
    storedState.viewLevel || 'summary'
  );
  const [position, setPositionState] = useState<ReadingPosition>(
    storedState.position || { chapterId: initialChapterId }
  );
  const [likedComments, setLikedComments] = useState<Set<string>>(
    storedState.likedComments || new Set()
  );
  const [bookmarkedComments, setBookmarkedComments] = useState<Set<string>>(
    storedState.bookmarkedComments || new Set()
  );
  const [userComments, setUserComments] = useState<UserComment[]>(
    storedState.userComments || []
  );

  const updateAndSave = useCallback((updates: Partial<ReadingState>) => {
    const newState: ReadingState = {
      viewLevel: updates.viewLevel ?? viewLevel,
      position: updates.position ?? position,
      likedComments: updates.likedComments ?? likedComments,
      bookmarkedComments: updates.bookmarkedComments ?? bookmarkedComments,
      userComments: updates.userComments ?? userComments,
    };
    saveState(newState);
  }, [viewLevel, position, likedComments, bookmarkedComments, userComments]);

  const setViewLevel = useCallback((level: ViewLevel) => {
    setViewLevelState(level);
    updateAndSave({ viewLevel: level });
  }, [updateAndSave]);

  const setPosition = useCallback((pos: ReadingPosition) => {
    setPositionState(pos);
    updateAndSave({ position: pos });
  }, [updateAndSave]);

  const toggleLike = useCallback((commentId: string) => {
    setLikedComments(prev => {
      const next = new Set(prev);
      if (next.has(commentId)) {
        next.delete(commentId);
      } else {
        next.add(commentId);
      }
      updateAndSave({ likedComments: next });
      return next;
    });
  }, [updateAndSave]);

  const toggleBookmark = useCallback((commentId: string) => {
    setBookmarkedComments(prev => {
      const next = new Set(prev);
      if (next.has(commentId)) {
        next.delete(commentId);
      } else {
        next.add(commentId);
      }
      updateAndSave({ bookmarkedComments: next });
      return next;
    });
  }, [updateAndSave]);

  const addUserComment = useCallback((segmentId: string, text: string) => {
    const newComment: UserComment = {
      id: `user-${Date.now()}`,
      segmentId,
      text,
      createdAt: new Date().toISOString(),
    };
    setUserComments(prev => {
      const next = [...prev, newComment];
      updateAndSave({ userComments: next });
      return next;
    });
    return newComment;
  }, [updateAndSave]);

  const removeUserComment = useCallback((commentId: string) => {
    setUserComments(prev => {
      const next = prev.filter(c => c.id !== commentId);
      updateAndSave({ userComments: next });
      return next;
    });
  }, [updateAndSave]);

  const editUserComment = useCallback((commentId: string, newText: string) => {
    setUserComments(prev => {
      const next = prev.map(c => 
        c.id === commentId ? { ...c, text: newText } : c
      );
      updateAndSave({ userComments: next });
      return next;
    });
  }, [updateAndSave]);

  return {
    viewLevel,
    position,
    likedComments,
    bookmarkedComments,
    userComments,
    setViewLevel,
    setPosition,
    toggleLike,
    toggleBookmark,
    addUserComment,
    removeUserComment,
    editUserComment,
  };
}
