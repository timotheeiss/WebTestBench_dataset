import { DocumentReader } from '@/components/DocumentReader';
import { sampleDocument } from '@/data/document';

const Index = () => {
  return <DocumentReader document={sampleDocument} />;
};

export default Index;
