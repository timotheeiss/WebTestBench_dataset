export interface Comment {
  id: string;
  text: string;
  author: string;
  type: 'system' | 'user';
  likes: number;
  isLiked: boolean;
  isBookmarked: boolean;
  createdAt: string;
}

export interface TextSegment {
  id: string;
  content: string;
  comments?: Comment[];
}

export interface Section {
  id: string;
  title: string;
  summary: string;
  segments: TextSegment[];
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  summary: string;
  sections: Section[];
}

export interface Document {
  id: string;
  title: string;
  author: string;
  summary: string;
  chapters: Chapter[];
}

export const sampleDocument: Document = {
  id: 'doc-1',
  title: 'The Art of Mindful Reading',
  author: 'Eleanor Whitmore',
  summary: 'This comprehensive guide explores the transformative practice of mindful reading—a method that combines ancient contemplative traditions with modern cognitive science. The book presents practical techniques for deeper engagement with texts, improved comprehension, and lasting retention. Through three main chapters, readers learn to cultivate presence, develop critical analysis skills, and integrate insights into daily life. The approach promises not just better reading, but a richer relationship with knowledge itself.',
  chapters: [
    {
      id: 'ch-1',
      number: 1,
      title: 'The Foundation of Presence',
      summary: 'This chapter introduces the core principles of mindful reading, emphasizing the importance of full presence and attention. It covers preparation techniques, environmental considerations, and the fundamental shift from passive consumption to active engagement with text.',
      sections: [
        {
          id: 'sec-1-1',
          title: 'Preparing the Mind',
          summary: 'Techniques for mental preparation before reading.',
          segments: [
            {
              id: 'seg-1-1-1',
              content: 'The journey of mindful reading begins not with the first word on the page, but with the preparation of one\'s mental state.',
              comments: [
                {
                  id: 'com-1',
                  text: 'This echoes the Zen concept of "beginner\'s mind" (shoshin), approaching each text with openness.',
                  author: 'Dr. Sarah Chen',
                  type: 'system',
                  likes: 24,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-1-1-2',
              content: 'Before opening any book, take three deep breaths. Feel your body settle into your chair. Notice the weight of the book in your hands, the texture of its pages. This simple ritual creates a threshold between the noise of daily life and the focused sanctuary of reading.',
              comments: [
                {
                  id: 'com-2',
                  text: 'Research shows that breathing exercises activate the parasympathetic nervous system, optimizing cognitive function.',
                  author: 'Editorial Note',
                  type: 'system',
                  likes: 18,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-1-1-3',
              content: 'Consider your intention. Why are you reading this particular text? What do you hope to discover? Setting a clear intention acts as a compass, guiding your attention through the landscape of words and ideas.'
            }
          ]
        },
        {
          id: 'sec-1-2',
          title: 'Creating Sacred Space',
          summary: 'How environment affects reading quality.',
          segments: [
            {
              id: 'seg-1-2-1',
              content: 'The environment in which we read profoundly shapes our experience. A cluttered desk mirrors a cluttered mind; a serene space invites serene contemplation.',
              comments: [
                {
                  id: 'com-3',
                  text: 'Studies in environmental psychology confirm that physical order reduces cognitive load, freeing mental resources for comprehension.',
                  author: 'Editorial Note',
                  type: 'system',
                  likes: 31,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-1-2-2',
              content: 'Natural light, when available, remains the ideal illumination for reading. Its gentle variation keeps our circadian rhythms aligned and reduces eye strain. When artificial light is necessary, warm tones closer to candlelight create a more inviting atmosphere than harsh fluorescence.'
            },
            {
              id: 'seg-1-2-3',
              content: 'Sound, too, deserves consideration. Some readers thrive in complete silence; others find gentle ambient sounds—rain, distant traffic, soft instrumental music—conducive to concentration. Experiment to discover your optimal soundscape.'
            }
          ]
        }
      ]
    },
    {
      id: 'ch-2',
      number: 2,
      title: 'The Practice of Deep Engagement',
      summary: 'Building upon the foundational principles, this chapter presents specific techniques for engaging deeply with texts. It explores annotation practices, the art of questioning, and methods for wrestling with difficult passages.',
      sections: [
        {
          id: 'sec-2-1',
          title: 'The Art of Annotation',
          summary: 'Marking texts as a form of dialogue.',
          segments: [
            {
              id: 'seg-2-1-1',
              content: 'Annotation transforms reading from a passive reception into an active conversation. When we mark a text, we enter into dialogue with the author, responding, questioning, and building upon their ideas.',
              comments: [
                {
                  id: 'com-4',
                  text: 'Mortimer Adler called this "marking up a book" the highest form of respect for an author\'s work.',
                  author: 'Historical Note',
                  type: 'system',
                  likes: 42,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-2-1-2',
              content: 'Develop your own system of marks. Perhaps a vertical line in the margin for important passages, a question mark for confusion, an exclamation point for surprise. Underline key phrases sparingly—if everything is emphasized, nothing is.'
            },
            {
              id: 'seg-2-1-3',
              content: 'Write in the margins. Summarize paragraphs in your own words. Note connections to other books, to your own experience, to current events. These marginal conversations become treasures upon rereading.',
              comments: [
                {
                  id: 'com-5',
                  text: 'The practice of marginalia dates back to medieval manuscripts and represents a continuous tradition of active reading.',
                  author: 'Historical Note',
                  type: 'system',
                  likes: 15,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            }
          ]
        },
        {
          id: 'sec-2-2',
          title: 'Wrestling with Difficulty',
          summary: 'Approaching challenging texts with persistence.',
          segments: [
            {
              id: 'seg-2-2-1',
              content: 'Difficult texts often yield the greatest rewards. When you encounter a passage that resists understanding, resist the urge to skip ahead. Instead, slow down further.',
              comments: [
                {
                  id: 'com-6',
                  text: 'Cognitive science calls this "desirable difficulty"—the extra effort required to process challenging material leads to deeper encoding in memory.',
                  author: 'Dr. Sarah Chen',
                  type: 'system',
                  likes: 56,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-2-2-2',
              content: 'Read the difficult passage aloud. The act of vocalization engages different neural pathways and often illuminates meaning that silent reading obscures. Hear the rhythm of the prose; let the sounds guide you toward understanding.'
            },
            {
              id: 'seg-2-2-3',
              content: 'Sometimes understanding requires patience. Mark the passage, continue reading, and return later. The context that follows often provides the key that unlocks earlier mysteries. Trust the author; trust your own developing comprehension.'
            }
          ]
        }
      ]
    },
    {
      id: 'ch-3',
      number: 3,
      title: 'Integration and Transformation',
      summary: 'The final chapter addresses how to carry reading beyond the book itself. It covers techniques for retention, methods for applying insights to daily life, and the cultivation of a lifelong reading practice.',
      sections: [
        {
          id: 'sec-3-1',
          title: 'From Page to Life',
          summary: 'Applying reading insights to daily experience.',
          segments: [
            {
              id: 'seg-3-1-1',
              content: 'The true measure of reading is not how many books we finish, but how deeply their wisdom permeates our lives. A single well-read book can transform more than a library merely scanned.',
              comments: [
                {
                  id: 'com-7',
                  text: 'Seneca wrote: "It is not that we have a short time to live, but that we waste a lot of it." The same applies to reading—quality over quantity.',
                  author: 'Historical Note',
                  type: 'system',
                  likes: 89,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-3-1-2',
              content: 'After finishing a significant book, resist immediately beginning another. Instead, spend a day or more with the book\'s ideas. Walk with them, sleep with them, discuss them with friends. Let them settle into your understanding.'
            },
            {
              id: 'seg-3-1-3',
              content: 'Keep a reading journal separate from your annotations. Write about how the book changed your thinking, what questions it raised, what actions it inspired. This reflective practice cements learning and creates a record of your intellectual journey.'
            }
          ]
        },
        {
          id: 'sec-3-2',
          title: 'Building a Practice',
          summary: 'Establishing sustainable reading habits.',
          segments: [
            {
              id: 'seg-3-2-1',
              content: 'Mindful reading, like any contemplative practice, flourishes through consistency rather than intensity. A daily half-hour of focused reading accomplishes more than occasional marathon sessions.',
              comments: [
                {
                  id: 'com-8',
                  text: 'Habit research suggests that linking a new behavior to an existing routine (habit stacking) dramatically increases adherence.',
                  author: 'Dr. Sarah Chen',
                  type: 'system',
                  likes: 37,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            },
            {
              id: 'seg-3-2-2',
              content: 'Choose a consistent time for reading. Morning readers benefit from fresh minds; evening readers enjoy reading as a transition to rest. Neither is superior—what matters is reliability.'
            },
            {
              id: 'seg-3-2-3',
              content: 'Finally, remember that mindful reading is a practice, not a destination. Some days your concentration will wander; some books will fail to engage. Accept these variations with equanimity. Return, always return, to the page with renewed intention and open curiosity.',
              comments: [
                {
                  id: 'com-9',
                  text: 'The Japanese concept of "kaizen" (continuous improvement) applies beautifully here—small, consistent efforts compound over time.',
                  author: 'Editorial Note',
                  type: 'system',
                  likes: 28,
                  isLiked: false,
                  isBookmarked: false,
                  createdAt: '2024-01-15'
                }
              ]
            }
          ]
        }
      ]
    }
  ]
};
