export type ViewLevel = 'summary' | 'chapter' | 'full';

export interface ReadingPosition {
  chapterId: string;
  sectionId?: string;
  segmentId?: string;
}

export interface UserComment {
  id: string;
  segmentId: string;
  text: string;
  createdAt: string;
}

export interface ReadingState {
  viewLevel: ViewLevel;
  position: ReadingPosition;
  likedComments: Set<string>;
  bookmarkedComments: Set<string>;
  userComments: UserComment[];
}
