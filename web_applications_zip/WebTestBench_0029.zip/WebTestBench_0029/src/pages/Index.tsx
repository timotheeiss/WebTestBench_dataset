import { useState } from 'react';
import { useBooks } from '@/hooks/useBooks';
import { Book, ReadingStatus } from '@/types/book';
import { BookCard } from '@/components/BookCard';
import { BookFormModal } from '@/components/BookFormModal';
import { ReviewModal } from '@/components/ReviewModal';
import { ProgressModal } from '@/components/ProgressModal';
import { SearchFilters } from '@/components/SearchFilters';
import { Recommendations } from '@/components/Recommendations';
import { Stats } from '@/components/Stats';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, Library, BookOpen, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const {
    filteredBooks,
    booksByStatus,
    filters,
    setFilters,
    addBook,
    updateBook,
    deleteBook,
    updateProgress,
    changeStatus,
    addReview,
    recommendations,
    stats,
  } = useBooks();

  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('all');
  const [bookFormOpen, setBookFormOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [progressModalOpen, setProgressModalOpen] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const handleAddBook = (bookData: Omit<Book, 'id' | 'dateAdded'>) => {
    addBook(bookData);
    toast({
      title: 'Book Added',
      description: `"${bookData.title}" has been added to your library.`,
    });
  };

  const handleEditBook = (book: Book) => {
    setSelectedBook(book);
    setBookFormOpen(true);
  };

  const handleSaveBook = (bookData: Omit<Book, 'id' | 'dateAdded'>) => {
    if (selectedBook) {
      updateBook(selectedBook.id, bookData);
      toast({
        title: 'Book Updated',
        description: `"${bookData.title}" has been updated.`,
      });
    } else {
      handleAddBook(bookData);
    }
    setSelectedBook(null);
  };

  const handleDeleteBook = (id: string) => {
    const book = filteredBooks.find((b) => b.id === id);
    deleteBook(id);
    toast({
      title: 'Book Removed',
      description: book ? `"${book.title}" has been removed.` : 'Book removed.',
    });
  };

  const handleReview = (book: Book) => {
    setSelectedBook(book);
    setReviewModalOpen(true);
  };

  const handleSaveReview = (id: string, rating: number, review: string) => {
    addReview(id, rating, review);
    toast({
      title: 'Review Saved',
      description: 'Your rating and review have been saved.',
    });
    setSelectedBook(null);
  };

  const handleUpdateProgress = (book: Book) => {
    setSelectedBook(book);
    setProgressModalOpen(true);
  };

  const handleSaveProgress = (id: string, currentPage: number) => {
    updateProgress(id, currentPage);
    const book = filteredBooks.find((b) => b.id === id);
    if (book && currentPage >= book.totalPages) {
      toast({
        title: 'Congratulations!',
        description: `You've finished reading "${book.title}"!`,
      });
    }
    setSelectedBook(null);
  };

  const handleChangeStatus = (id: string, status: ReadingStatus) => {
    changeStatus(id, status);
    const book = filteredBooks.find((b) => b.id === id);
    if (status === 'reading') {
      toast({
        title: 'Started Reading',
        description: book ? `You've started reading "${book.title}".` : 'Book started.',
      });
    } else if (status === 'completed') {
      toast({
        title: 'Book Completed',
        description: book ? `"${book.title}" marked as completed!` : 'Book completed!',
      });
      if (book) {
        setTimeout(() => {
          setSelectedBook({ ...book, status: 'completed' });
          setReviewModalOpen(true);
        }, 500);
      }
    }
  };

  const handleStartRecommended = (id: string) => {
    handleChangeStatus(id, 'reading');
  };

  const getDisplayBooks = () => {
    if (activeTab === 'all') return filteredBooks;
    return filteredBooks.filter((b) => b.status === activeTab);
  };

  const displayBooks = getDisplayBooks();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Library className="w-8 h-8 text-primary" />
              <h1 className="font-serif text-2xl font-bold text-foreground">
                My Reading Library
              </h1>
            </div>
            <Button onClick={() => { setSelectedBook(null); setBookFormOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Book
            </Button>
          </div>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Stats */}
        <Stats {...stats} />

        {/* Recommendations */}
        <Recommendations books={recommendations} onStartReading={handleStartRecommended} />

        {/* Search & Filters */}
        <SearchFilters filters={filters} onFiltersChange={setFilters} />

        {/* Tabs & Book Grid */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-card shadow-card h-auto p-1.5 gap-1">
            <TabsTrigger value="all" className="gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Library className="w-4 h-4" />
              All ({stats.totalBooks})
            </TabsTrigger>
            <TabsTrigger value="reading" className="gap-2 data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
              <BookOpen className="w-4 h-4" />
              Reading ({stats.reading})
            </TabsTrigger>
            <TabsTrigger value="to-read" className="gap-2 data-[state=active]:bg-muted data-[state=active]:text-foreground">
              <Clock className="w-4 h-4" />
              To Read ({stats.toRead})
            </TabsTrigger>
            <TabsTrigger value="completed" className="gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <CheckCircle className="w-4 h-4" />
              Completed ({stats.completed})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {displayBooks.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {displayBooks.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    onEdit={handleEditBook}
                    onUpdateProgress={(id) => handleUpdateProgress(book)}
                    onChangeStatus={handleChangeStatus}
                    onDelete={handleDeleteBook}
                    onReview={handleReview}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Library className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
                <h3 className="font-serif text-xl font-medium text-muted-foreground">
                  No books found
                </h3>
                <p className="text-sm text-muted-foreground mt-2">
                  {filters.search || filters.genre !== 'all' || filters.status !== 'all' || filters.rating !== 'all'
                    ? 'Try adjusting your filters'
                    : 'Add your first book to get started'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Modals */}
      <BookFormModal
        open={bookFormOpen}
        onClose={() => { setBookFormOpen(false); setSelectedBook(null); }}
        onSave={handleSaveBook}
        book={selectedBook || undefined}
      />

      <ReviewModal
        open={reviewModalOpen}
        onClose={() => { setReviewModalOpen(false); setSelectedBook(null); }}
        onSave={handleSaveReview}
        book={selectedBook}
      />

      <ProgressModal
        open={progressModalOpen}
        onClose={() => { setProgressModalOpen(false); setSelectedBook(null); }}
        onSave={handleSaveProgress}
        book={selectedBook}
      />
    </div>
  );
};

export default Index;