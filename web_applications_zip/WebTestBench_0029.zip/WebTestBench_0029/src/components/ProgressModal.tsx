import { useState } from 'react';
import { Book } from '@/types/book';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface ProgressModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (id: string, currentPage: number) => void;
  book: Book | null;
}

export function ProgressModal({ open, onClose, onSave, book }: ProgressModalProps) {
  const [currentPage, setCurrentPage] = useState(book?.currentPage || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (book) {
      onSave(book.id, currentPage);
      onClose();
    }
  };

  const progress = book ? Math.round((currentPage / book.totalPages) * 100) : 0;

  // Reset when modal opens with new book
  if (book && currentPage !== book.currentPage && !open) {
    setCurrentPage(book.currentPage);
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl">
            Update Progress
          </DialogTitle>
        </DialogHeader>

        {book && (
          <>
            <div className="py-2">
              <p className="font-medium">{book.title}</p>
              <p className="text-sm text-muted-foreground">by {book.author}</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Current Page</Label>
                  <span className="text-2xl font-semibold text-accent">{progress}%</span>
                </div>

                <Slider
                  value={[currentPage]}
                  onValueChange={([value]) => setCurrentPage(value)}
                  max={book.totalPages}
                  step={1}
                  className="py-4"
                />

                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min={0}
                    max={book.totalPages}
                    value={currentPage}
                    onChange={(e) => setCurrentPage(Math.min(parseInt(e.target.value) || 0, book.totalPages))}
                    className="w-24"
                  />
                  <span className="text-muted-foreground">of {book.totalPages} pages</span>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit">
                  Update Progress
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
