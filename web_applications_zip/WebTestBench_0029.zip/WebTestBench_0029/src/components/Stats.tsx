import { BookOpen, CheckCircle, Clock, BookMarked, Star, FileText } from 'lucide-react';

interface StatsProps {
  totalBooks: number;
  completed: number;
  reading: number;
  toRead: number;
  totalPagesRead: number;
  avgRating: number;
}

export function Stats({
  totalBooks,
  completed,
  reading,
  toRead,
  totalPagesRead,
  avgRating,
}: StatsProps) {
  const stats = [
    {
      label: 'Total Books',
      value: totalBooks,
      icon: BookMarked,
      color: 'text-foreground',
    },
    {
      label: 'Completed',
      value: completed,
      icon: CheckCircle,
      color: 'text-primary',
    },
    {
      label: 'Reading',
      value: reading,
      icon: BookOpen,
      color: 'text-accent',
    },
    {
      label: 'To Read',
      value: toRead,
      icon: Clock,
      color: 'text-muted-foreground',
    },
    {
      label: 'Pages Read',
      value: totalPagesRead.toLocaleString(),
      icon: FileText,
      color: 'text-foreground',
    },
    {
      label: 'Avg Rating',
      value: avgRating > 0 ? avgRating.toFixed(1) : '—',
      icon: Star,
      color: 'text-gold',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="bg-card rounded-lg p-4 shadow-card text-center"
        >
          <stat.icon className={`w-5 h-5 mx-auto mb-2 ${stat.color}`} />
          <p className="text-2xl font-semibold">{stat.value}</p>
          <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
        </div>
      ))}
    </div>
  );
}
