import { useState } from 'react';
import { Book } from '@/types/book';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { StarRating } from '@/components/StarRating';

interface ReviewModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (id: string, rating: number, review: string) => void;
  book: Book | null;
}

export function ReviewModal({ open, onClose, onSave, book }: ReviewModalProps) {
  const [rating, setRating] = useState(book?.rating || 0);
  const [review, setReview] = useState(book?.review || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (book && rating > 0) {
      onSave(book.id, rating, review);
      onClose();
    }
  };

  // Update state when book changes
  if (book && (rating === 0 && book.rating)) {
    setRating(book.rating);
  }
  if (book && (!review && book.review)) {
    setReview(book.review);
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl">
            Rate & Review
          </DialogTitle>
        </DialogHeader>

        {book && (
          <div className="py-2">
            <p className="font-medium">{book.title}</p>
            <p className="text-sm text-muted-foreground">by {book.author}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label>Your Rating</Label>
            <StarRating
              rating={rating}
              size="lg"
              interactive
              onChange={setRating}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="review">Review (optional)</Label>
            <Textarea
              id="review"
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder="What did you think of this book?"
              rows={4}
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={rating === 0}>
              Save Review
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
