import { Book } from '@/types/book';
import { Progress } from '@/components/ui/progress';
import { StarRating } from '@/components/StarRating';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BookOpen, MoreHorizontal, Calendar, FileText } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface BookCardProps {
  book: Book;
  onEdit: (book: Book) => void;
  onUpdateProgress: (id: string, page: number) => void;
  onChangeStatus: (id: string, status: Book['status']) => void;
  onDelete: (id: string) => void;
  onReview: (book: Book) => void;
}

export function BookCard({
  book,
  onEdit,
  onUpdateProgress,
  onChangeStatus,
  onDelete,
  onReview,
}: BookCardProps) {
  const progress = Math.round((book.currentPage / book.totalPages) * 100);

  const statusColors = {
    'to-read': 'bg-muted text-muted-foreground',
    reading: 'bg-accent/10 text-accent border-accent/20',
    completed: 'bg-primary/10 text-primary border-primary/20',
  };

  const statusLabels = {
    'to-read': 'To Read',
    reading: 'Reading',
    completed: 'Completed',
  };

  return (
    <div className="group relative bg-card rounded-lg shadow-card hover:shadow-hover transition-all duration-300 overflow-hidden animate-fade-in">
      <div className="flex gap-4 p-4">
        {/* Book Cover */}
        <div className="relative flex-shrink-0 w-20 h-28 rounded-md overflow-hidden bg-muted">
          {book.coverUrl ? (
            <img
              src={book.coverUrl}
              alt={book.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <BookOpen className="w-8 h-8 text-muted-foreground/50" />
            </div>
          )}
        </div>

        {/* Book Info */}
        <div className="flex-1 min-w-0 flex flex-col">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="font-serif font-semibold text-foreground truncate leading-tight">
                {book.title}
              </h3>
              <p className="text-sm text-muted-foreground mt-0.5">{book.author}</p>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => onEdit(book)}>
                  Edit Details
                </DropdownMenuItem>
                {book.status === 'to-read' && (
                  <DropdownMenuItem onClick={() => onChangeStatus(book.id, 'reading')}>
                    Start Reading
                  </DropdownMenuItem>
                )}
                {book.status === 'reading' && (
                  <DropdownMenuItem onClick={() => onChangeStatus(book.id, 'completed')}>
                    Mark as Completed
                  </DropdownMenuItem>
                )}
                {book.status === 'completed' && (
                  <DropdownMenuItem onClick={() => onReview(book)}>
                    {book.rating ? 'Edit Review' : 'Add Review'}
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => onDelete(book.id)}
                  className="text-destructive focus:text-destructive"
                >
                  Remove from Library
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="flex items-center gap-2 mt-2">
            <Badge variant="outline" className={cn('text-xs', statusColors[book.status])}>
              {statusLabels[book.status]}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {book.genre}
            </Badge>
          </div>

          {/* Progress or Rating */}
          <div className="mt-auto pt-3">
            {book.status === 'reading' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>{book.currentPage} / {book.totalPages} pages</span>
                </div>
                <Progress value={progress} className="h-1.5" indicatorClassName="bg-accent" />
              </div>
            )}

            {book.status === 'completed' && book.rating && (
              <div className="flex items-center gap-2">
                <StarRating rating={book.rating} size="sm" />
                {book.review && (
                  <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                )}
              </div>
            )}

            {book.status === 'to-read' && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-xs text-accent hover:text-accent hover:bg-accent/10"
                onClick={() => onChangeStatus(book.id, 'reading')}
              >
                <BookOpen className="w-3.5 h-3.5 mr-1" />
                Start Reading
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Dates footer */}
      {(book.startDate || book.finishDate) && (
        <div className="px-4 py-2 bg-muted/30 border-t border-border/50 flex items-center gap-4 text-xs text-muted-foreground">
          {book.startDate && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              Started: {new Date(book.startDate).toLocaleDateString()}
            </span>
          )}
          {book.finishDate && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              Finished: {new Date(book.finishDate).toLocaleDateString()}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
