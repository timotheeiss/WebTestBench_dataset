import { Book } from '@/types/book';
import { Sparkles, BookOpen } from 'lucide-react';
import { StarRating } from '@/components/StarRating';

interface RecommendationsProps {
  books: Book[];
  onStartReading: (id: string) => void;
}

export function Recommendations({ books, onStartReading }: RecommendationsProps) {
  if (books.length === 0) {
    return null;
  }

  return (
    <div className="bg-gradient-to-br from-accent/5 to-primary/5 rounded-xl p-6 border border-accent/10">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-accent" />
        <h2 className="font-serif text-xl font-semibold">Recommended for You</h2>
      </div>
      
      <p className="text-sm text-muted-foreground mb-5">
        Based on your reading history and favorite genres
      </p>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {books.map((book) => (
          <div
            key={book.id}
            className="group bg-card rounded-lg p-4 shadow-card hover:shadow-hover transition-all duration-300 cursor-pointer"
            onClick={() => onStartReading(book.id)}
          >
            <div className="flex gap-3">
              <div className="w-12 h-16 rounded overflow-hidden bg-muted flex-shrink-0">
                {book.coverUrl ? (
                  <img
                    src={book.coverUrl}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-muted-foreground/50" />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-serif font-medium text-sm leading-tight truncate">
                  {book.title}
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">
                  {book.author}
                </p>
                <span className="inline-block mt-2 text-xs text-accent font-medium">
                  {book.genre}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
