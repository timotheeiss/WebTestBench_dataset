export type ReadingStatus = 'to-read' | 'reading' | 'completed';

export interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  coverUrl?: string;
  totalPages: number;
  currentPage: number;
  notes?: string;
  startDate?: string;
  finishDate?: string;
  rating?: number;
  review?: string;
  status: ReadingStatus;
  dateAdded: string;
}

export interface BookFilters {
  search: string;
  genre: string;
  status: ReadingStatus | 'all';
  rating: number | 'all';
}
