import { useState, useCallback, useMemo } from 'react';
import { Book, BookFilters, ReadingStatus } from '@/types/book';
import { initialBooks } from '@/data/books';

export function useBooks() {
  const [books, setBooks] = useState<Book[]>(initialBooks);
  const [filters, setFilters] = useState<BookFilters>({
    search: '',
    genre: 'all',
    status: 'all',
    rating: 'all',
  });

  const addBook = useCallback((book: Omit<Book, 'id' | 'dateAdded'>) => {
    const newBook: Book = {
      ...book,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setBooks((prev) => [newBook, ...prev]);
    return newBook;
  }, []);

  const updateBook = useCallback((id: string, updates: Partial<Book>) => {
    setBooks((prev) =>
      prev.map((book) => (book.id === id ? { ...book, ...updates } : book))
    );
  }, []);

  const deleteBook = useCallback((id: string) => {
    setBooks((prev) => prev.filter((book) => book.id !== id));
  }, []);

  const updateProgress = useCallback((id: string, currentPage: number) => {
    setBooks((prev) =>
      prev.map((book) => {
        if (book.id !== id) return book;
        
        const isCompleted = currentPage >= book.totalPages;
        return {
          ...book,
          currentPage: Math.min(currentPage, book.totalPages),
          status: isCompleted ? 'completed' : book.status === 'to-read' ? 'reading' : book.status,
          startDate: book.startDate || (currentPage > 0 ? new Date().toISOString().split('T')[0] : undefined),
          finishDate: isCompleted && !book.finishDate ? new Date().toISOString().split('T')[0] : book.finishDate,
        };
      })
    );
  }, []);

  const changeStatus = useCallback((id: string, status: ReadingStatus) => {
    setBooks((prev) =>
      prev.map((book) => {
        if (book.id !== id) return book;
        
        const updates: Partial<Book> = { status };
        
        if (status === 'reading' && !book.startDate) {
          updates.startDate = new Date().toISOString().split('T')[0];
        }
        
        if (status === 'completed') {
          updates.currentPage = book.totalPages;
          updates.finishDate = new Date().toISOString().split('T')[0];
          if (!book.startDate) {
            updates.startDate = new Date().toISOString().split('T')[0];
          }
        }
        
        return { ...book, ...updates };
      })
    );
  }, []);

  const addReview = useCallback((id: string, rating: number, review: string) => {
    setBooks((prev) =>
      prev.map((book) =>
        book.id === id ? { ...book, rating, review } : book
      )
    );
  }, []);

  const filteredBooks = useMemo(() => {
    return books.filter((book) => {
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const matchesSearch =
          book.title.toLowerCase().includes(searchLower) ||
          book.author.toLowerCase().includes(searchLower);
        if (!matchesSearch) return false;
      }

      if (filters.genre !== 'all' && book.genre !== filters.genre) {
        return false;
      }

      if (filters.status !== 'all' && book.status !== filters.status) {
        return false;
      }

      if (filters.rating !== 'all' && book.rating !== filters.rating) {
        return false;
      }

      return true;
    });
  }, [books, filters]);

  const booksByStatus = useMemo(() => {
    return {
      'to-read': books.filter((b) => b.status === 'to-read'),
      reading: books.filter((b) => b.status === 'reading'),
      completed: books.filter((b) => b.status === 'completed'),
    };
  }, [books]);

  const recommendations = useMemo(() => {
    const completedBooks = books.filter((b) => b.status === 'completed');
    const highlyRated = completedBooks.filter((b) => b.rating && b.rating >= 4);
    
    // Count genres from highly rated books
    const genreCounts: Record<string, number> = {};
    highlyRated.forEach((book) => {
      genreCounts[book.genre] = (genreCounts[book.genre] || 0) + 1;
    });
    
    // Get top genres
    const topGenres = Object.entries(genreCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3)
      .map(([genre]) => genre);
    
    // Recommend unread books from top genres
    const toReadBooks = books.filter((b) => b.status === 'to-read');
    const recommended = toReadBooks.filter((book) => topGenres.includes(book.genre));
    
    // If not enough recommendations, add other to-read books
    if (recommended.length < 3) {
      const others = toReadBooks.filter((b) => !recommended.includes(b));
      recommended.push(...others.slice(0, 3 - recommended.length));
    }
    
    return recommended.slice(0, 3);
  }, [books]);

  const stats = useMemo(() => {
    const completed = books.filter((b) => b.status === 'completed');
    const totalPages = completed.reduce((sum, b) => sum + b.totalPages, 0);
    const avgRating = completed.length > 0
      ? completed.reduce((sum, b) => sum + (b.rating || 0), 0) / completed.filter(b => b.rating).length
      : 0;
    
    return {
      totalBooks: books.length,
      completed: completed.length,
      reading: books.filter((b) => b.status === 'reading').length,
      toRead: books.filter((b) => b.status === 'to-read').length,
      totalPagesRead: totalPages,
      avgRating: Math.round(avgRating * 10) / 10,
    };
  }, [books]);

  return {
    books,
    filteredBooks,
    booksByStatus,
    filters,
    setFilters,
    addBook,
    updateBook,
    deleteBook,
    updateProgress,
    changeStatus,
    addReview,
    recommendations,
    stats,
  };
}
