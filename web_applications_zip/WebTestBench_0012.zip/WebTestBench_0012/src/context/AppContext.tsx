import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, StudyGroup, MentorInvite, Note, Discussion, Reply, StudySession, RSVP } from "@/types";
import { mockUsers, mockGroups, mockInvites } from "@/data/mockData";

interface AppContextType {
  currentUser: User | null;
  users: User[];
  groups: StudyGroup[];
  invites: MentorInvite[];
  login: (email: string, password: string) => boolean;
  signup: (user: Omit<User, "id" | "joinedAt">) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  createGroup: (group: Omit<StudyGroup, "id" | "createdAt" | "members" | "notes" | "discussions" | "sessions">) => void;
  joinGroup: (groupId: string) => void;
  leaveGroup: (groupId: string) => void;
  addNote: (groupId: string, note: Omit<Note, "id" | "createdAt" | "isPinned" | "isRecommended">) => void;
  togglePinNote: (groupId: string, noteId: string) => void;
  toggleRecommendNote: (groupId: string, noteId: string) => void;
  addDiscussion: (groupId: string, discussion: Omit<Discussion, "id" | "createdAt" | "isPinned" | "replies">) => void;
  addReply: (groupId: string, discussionId: string, content: string) => void;
  togglePinDiscussion: (groupId: string, discussionId: string) => void;
  createSession: (groupId: string, session: Omit<StudySession, "id" | "rsvps">) => void;
  updateRSVP: (groupId: string, sessionId: string, status: RSVP["status"]) => void;
  inviteMentor: (groupId: string, mentorId: string) => void;
  respondToInvite: (inviteId: string, accept: boolean) => void;
  getUserById: (userId: string) => User | undefined;
  getGroupById: (groupId: string) => StudyGroup | undefined;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [groups, setGroups] = useState<StudyGroup[]>(mockGroups);
  const [invites, setInvites] = useState<MentorInvite[]>(mockInvites);

  useEffect(() => {
    const savedUserId = localStorage.getItem("studyhub-user");
    if (savedUserId) {
      const user = users.find((u) => u.id === savedUserId);
      if (user) setCurrentUser(user);
    }
  }, []);

  const login = (email: string, _password: string): boolean => {
    const user = users.find((u) => u.email === email);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem("studyhub-user", user.id);
      return true;
    }
    return false;
  };

  const signup = (userData: Omit<User, "id" | "joinedAt">) => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      joinedAt: new Date(),
    };
    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    localStorage.setItem("studyhub-user", newUser.id);
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("studyhub-user");
  };

  const updateUser = (updates: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updates };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updated : u)));
  };

  const createGroup = (
    groupData: Omit<StudyGroup, "id" | "createdAt" | "members" | "notes" | "discussions" | "sessions">
  ) => {
    if (!currentUser) return;
    const newGroup: StudyGroup = {
      ...groupData,
      id: `group-${Date.now()}`,
      createdAt: new Date(),
      members: [{ userId: currentUser.id, role: "owner", joinedAt: new Date() }],
      notes: [],
      discussions: [],
      sessions: [],
    };
    setGroups((prev) => [...prev, newGroup]);
  };

  const joinGroup = (groupId: string) => {
    if (!currentUser) return;
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id === groupId && !g.members.some((m) => m.userId === currentUser.id)) {
          return {
            ...g,
            members: [...g.members, { userId: currentUser.id, role: "member", joinedAt: new Date() }],
          };
        }
        return g;
      })
    );
  };

  const leaveGroup = (groupId: string) => {
    if (!currentUser) return;
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id === groupId) {
          return {
            ...g,
            members: g.members.filter((m) => m.userId !== currentUser.id),
          };
        }
        return g;
      })
    );
  };

  const addNote = (groupId: string, noteData: Omit<Note, "id" | "createdAt" | "isPinned" | "isRecommended">) => {
    const newNote: Note = {
      ...noteData,
      id: `note-${Date.now()}`,
      createdAt: new Date(),
      isPinned: false,
      isRecommended: false,
    };
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, notes: [...g.notes, newNote] } : g))
    );
  };

  const togglePinNote = (groupId: string, noteId: string) => {
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? { ...g, notes: g.notes.map((n) => (n.id === noteId ? { ...n, isPinned: !n.isPinned } : n)) }
          : g
      )
    );
  };

  const toggleRecommendNote = (groupId: string, noteId: string) => {
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? { ...g, notes: g.notes.map((n) => (n.id === noteId ? { ...n, isRecommended: !n.isRecommended } : n)) }
          : g
      )
    );
  };

  const addDiscussion = (
    groupId: string,
    discussionData: Omit<Discussion, "id" | "createdAt" | "isPinned" | "replies">
  ) => {
    const newDiscussion: Discussion = {
      ...discussionData,
      id: `disc-${Date.now()}`,
      createdAt: new Date(),
      isPinned: false,
      replies: [],
    };
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, discussions: [...g.discussions, newDiscussion] } : g))
    );
  };

  const addReply = (groupId: string, discussionId: string, content: string) => {
    if (!currentUser) return;
    const newReply: Reply = {
      id: `reply-${Date.now()}`,
      content,
      createdBy: currentUser.id,
      createdAt: new Date(),
    };
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? {
              ...g,
              discussions: g.discussions.map((d) =>
                d.id === discussionId ? { ...d, replies: [...d.replies, newReply] } : d
              ),
            }
          : g
      )
    );
  };

  const togglePinDiscussion = (groupId: string, discussionId: string) => {
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? {
              ...g,
              discussions: g.discussions.map((d) =>
                d.id === discussionId ? { ...d, isPinned: !d.isPinned } : d
              ),
            }
          : g
      )
    );
  };

  const createSession = (groupId: string, sessionData: Omit<StudySession, "id" | "rsvps">) => {
    if (!currentUser) return;
    const newSession: StudySession = {
      ...sessionData,
      id: `session-${Date.now()}`,
      rsvps: [{ userId: currentUser.id, status: "attending" }],
    };
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, sessions: [...g.sessions, newSession] } : g))
    );
  };

  const updateRSVP = (groupId: string, sessionId: string, status: RSVP["status"]) => {
    if (!currentUser) return;
    setGroups((prev) =>
      prev.map((g) =>
        g.id === groupId
          ? {
              ...g,
              sessions: g.sessions.map((s) => {
                if (s.id === sessionId) {
                  const existingRsvp = s.rsvps.find((r) => r.userId === currentUser.id);
                  if (existingRsvp) {
                    return {
                      ...s,
                      rsvps: s.rsvps.map((r) => (r.userId === currentUser.id ? { ...r, status } : r)),
                    };
                  }
                  return { ...s, rsvps: [...s.rsvps, { userId: currentUser.id, status }] };
                }
                return s;
              }),
            }
          : g
      )
    );
  };

  const inviteMentor = (groupId: string, mentorId: string) => {
    const newInvite: MentorInvite = {
      id: `invite-${Date.now()}`,
      groupId,
      mentorId,
      status: "pending",
      sentAt: new Date(),
    };
    setInvites((prev) => [...prev, newInvite]);
  };

  const respondToInvite = (inviteId: string, accept: boolean) => {
    setInvites((prev) =>
      prev.map((inv) => (inv.id === inviteId ? { ...inv, status: accept ? "accepted" : "declined" } : inv))
    );
    if (accept) {
      const invite = invites.find((i) => i.id === inviteId);
      if (invite) {
        setGroups((prev) =>
          prev.map((g) =>
            g.id === invite.groupId
              ? { ...g, members: [...g.members, { userId: invite.mentorId, role: "mentor", joinedAt: new Date() }] }
              : g
          )
        );
      }
    }
  };

  const getUserById = (userId: string) => users.find((u) => u.id === userId);
  const getGroupById = (groupId: string) => groups.find((g) => g.id === groupId);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        groups,
        invites,
        login,
        signup,
        logout,
        updateUser,
        createGroup,
        joinGroup,
        leaveGroup,
        addNote,
        togglePinNote,
        toggleRecommendNote,
        addDiscussion,
        addReply,
        togglePinDiscussion,
        createSession,
        updateRSVP,
        inviteMentor,
        respondToInvite,
        getUserById,
        getGroupById,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
