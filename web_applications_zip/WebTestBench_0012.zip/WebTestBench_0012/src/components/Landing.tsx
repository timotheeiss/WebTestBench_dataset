import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, BookOpen, Calendar, Award, ArrowRight, CheckCircle } from "lucide-react";
import { useApp } from "@/context/AppContext";

const features = [
  {
    icon: Users,
    title: "Study Groups",
    description: "Join or create focused groups around any subject",
  },
  {
    icon: BookOpen,
    title: "Shared Notes",
    description: "Organize notes, outlines, and summaries together",
  },
  {
    icon: Calendar,
    title: "Session Scheduling",
    description: "Plan study sessions and track availability",
  },
  {
    icon: Award,
    title: "Mentor Support",
    description: "Connect with advanced students for guidance",
  },
];

const benefits = [
  "Create and join unlimited study groups",
  "Organize notes with labeled sections",
  "Schedule sessions with availability tracking",
  "RSVP system for group coordination",
  "Mentor program for expert guidance",
  "Discussion boards for Q&A",
];

export function Landing() {
  const { currentUser } = useApp();

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero px-4 py-24 text-primary-foreground md:py-32">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50" />
        
        <div className="container relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mx-auto max-w-3xl text-center"
          >
            <Badge className="mb-4 bg-accent text-accent-foreground">
              Collaborative Learning
            </Badge>
            <h1 className="mb-6 text-4xl font-bold tracking-tight md:text-6xl">
              Study Smarter,{" "}
              <span className="text-accent">Together</span>
            </h1>
            <p className="mb-8 text-lg text-primary-foreground/80 md:text-xl">
              Join a community of learners. Create study groups, share notes, 
              schedule sessions, and connect with mentors to achieve your academic goals.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              {currentUser ? (
                <Button size="lg" asChild className="bg-accent text-accent-foreground hover:bg-accent/90">
                  <Link to="/groups">
                    Browse Groups
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              ) : (
                <>
                  <Button size="lg" asChild className="bg-accent text-accent-foreground hover:bg-accent/90">
                    <Link to="/signup">
                      Start Learning
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="border-primary-foreground/20 bg-transparent text-primary-foreground hover:bg-primary-foreground/10">
                    <Link to="/login">Sign In</Link>
                  </Button>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12 text-center"
          >
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">
              Everything You Need to <span className="text-primary">Succeed</span>
            </h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              StudyHub brings together all the tools you need for effective collaborative learning.
            </p>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group rounded-xl border bg-card p-6 shadow-soft transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-muted/50 py-20">
        <div className="container">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="mb-6 text-3xl font-bold md:text-4xl">
                Built for Students, <span className="text-primary">By Students</span>
              </h2>
              <p className="mb-8 text-muted-foreground">
                We understand the challenges of academic life. StudyHub is designed to make 
                collaborative learning seamless and effective.
              </p>
              <ul className="space-y-3">
                {benefits.map((benefit, i) => (
                  <motion.li
                    key={benefit}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-3"
                  >
                    <CheckCircle className="h-5 w-5 shrink-0 text-success" />
                    <span>{benefit}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square rounded-2xl bg-gradient-hero p-8">
                <div className="flex h-full flex-col items-center justify-center text-center text-primary-foreground">
                  <div className="mb-4 text-6xl font-bold">500+</div>
                  <div className="text-lg opacity-80">Active Study Groups</div>
                  <div className="mt-8 grid grid-cols-2 gap-4 text-sm">
                    <div className="rounded-lg bg-primary-foreground/10 p-4">
                      <div className="text-2xl font-bold">2.5k</div>
                      <div className="opacity-80">Students</div>
                    </div>
                    <div className="rounded-lg bg-primary-foreground/10 p-4">
                      <div className="text-2xl font-bold">150+</div>
                      <div className="opacity-80">Mentors</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="rounded-2xl bg-gradient-hero p-8 text-center text-primary-foreground md:p-12"
          >
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">
              Ready to Transform Your Study Routine?
            </h2>
            <p className="mb-8 text-primary-foreground/80">
              Join thousands of students who are already learning smarter together.
            </p>
            {!currentUser && (
              <Button size="lg" asChild className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Link to="/signup">
                  Get Started Free
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2024 StudyHub. Built for collaborative learning.</p>
        </div>
      </footer>
    </div>
  );
}
