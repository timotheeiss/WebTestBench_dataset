import { useState } from "react";
import { motion } from "framer-motion";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, Award, Clock, BookOpen, Bell, Check, X } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { subjects } from "@/data/mockData";
import { StudyTime } from "@/types";
import { Navigate } from "react-router-dom";

const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;
const hours = Array.from({ length: 24 }, (_, i) => i);

export function Profile() {
  const { currentUser, updateUser, invites, respondToInvite, getGroupById } = useApp();
  const [name, setName] = useState(currentUser?.name || "");
  const [bio, setBio] = useState(currentUser?.bio || "");
  const [level, setLevel] = useState(currentUser?.level || "undergraduate");
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(currentUser?.subjects || []);
  const [isMentor, setIsMentor] = useState(currentUser?.isMentor || false);
  const [studyTimes, setStudyTimes] = useState<StudyTime[]>(currentUser?.preferredStudyTimes || []);

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  const pendingInvites = invites.filter(
    (inv) => inv.mentorId === currentUser.id && inv.status === "pending"
  );

  const handleSubjectToggle = (subject: string) => {
    setSelectedSubjects((prev) =>
      prev.includes(subject) ? prev.filter((s) => s !== subject) : [...prev, subject]
    );
  };

  const handleAddStudyTime = (day: typeof days[number]) => {
    setStudyTimes((prev) => [...prev, { day, startHour: 14, endHour: 18 }]);
  };

  const handleRemoveStudyTime = (index: number) => {
    setStudyTimes((prev) => prev.filter((_, i) => i !== index));
  };

  const handleStudyTimeChange = (index: number, field: "startHour" | "endHour", value: number) => {
    setStudyTimes((prev) =>
      prev.map((st, i) => (i === index ? { ...st, [field]: value } : st))
    );
  };

  const handleSave = () => {
    updateUser({
      name,
      bio,
      level: level as typeof currentUser.level,
      subjects: selectedSubjects,
      isMentor,
      preferredStudyTimes: studyTimes,
    });
    toast({ title: "Profile updated", description: "Your changes have been saved." });
  };

  return (
    <div className="container max-w-4xl py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="mb-8 flex items-center gap-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
            <AvatarFallback className="bg-primary text-2xl text-primary-foreground">
              {currentUser.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold">{currentUser.name}</h1>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="capitalize">
                {currentUser.level.replace("-", " ")}
              </Badge>
              {currentUser.isMentor && (
                <Badge className="bg-mentor text-mentor-foreground">
                  <Award className="mr-1 h-3 w-3" />
                  Mentor
                </Badge>
              )}
            </div>
          </div>
        </div>

        <Tabs defaultValue="profile">
          <TabsList className="mb-6">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="availability">Availability</TabsTrigger>
            {pendingInvites.length > 0 && (
              <TabsTrigger value="invites" className="relative">
                Invites
                <Badge className="ml-2 h-5 w-5 rounded-full p-0">{pendingInvites.length}</Badge>
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your personal information and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    placeholder="Tell others about yourself..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Academic Level</Label>
                  <Select value={level} onValueChange={(v) => setLevel(v as typeof level)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high-school">High School</SelectItem>
                      <SelectItem value="undergraduate">Undergraduate</SelectItem>
                      <SelectItem value="graduate">Graduate</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Subjects</Label>
                  <div className="flex flex-wrap gap-2">
                    {subjects.map((subject) => (
                      <Button
                        key={subject}
                        type="button"
                        size="sm"
                        variant={selectedSubjects.includes(subject) ? "default" : "outline"}
                        onClick={() => handleSubjectToggle(subject)}
                        className="h-8"
                      >
                        {subject}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center space-x-2 rounded-lg border bg-muted/30 p-4">
                  <Checkbox
                    id="mentor"
                    checked={isMentor}
                    onCheckedChange={(checked) => setIsMentor(checked as boolean)}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="mentor" className="font-medium">
                      <Award className="mr-1 inline h-4 w-4 text-mentor" />
                      Mentor Status
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Enable to receive group invitations and access mentor features.
                    </p>
                  </div>
                </div>

                <Button onClick={handleSave} className="w-full">
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="availability">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Study Availability
                </CardTitle>
                <CardDescription>Set your preferred study times to help groups find you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  {studyTimes.map((st, index) => (
                    <div key={index} className="flex items-center gap-3 rounded-lg border p-3">
                      <Badge variant="outline" className="w-24 justify-center capitalize">
                        {st.day}
                      </Badge>
                      <Select
                        value={st.startHour.toString()}
                        onValueChange={(v) => handleStudyTimeChange(index, "startHour", parseInt(v))}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {hours.map((h) => (
                            <SelectItem key={h} value={h.toString()}>
                              {h.toString().padStart(2, "0")}:00
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <span className="text-muted-foreground">to</span>
                      <Select
                        value={st.endHour.toString()}
                        onValueChange={(v) => handleStudyTimeChange(index, "endHour", parseInt(v))}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {hours.map((h) => (
                            <SelectItem key={h} value={h.toString()}>
                              {h.toString().padStart(2, "0")}:00
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveStudyTime(index)}
                        className="ml-auto text-destructive"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap gap-2">
                  {days.map((day) => (
                    <Button
                      key={day}
                      variant="outline"
                      size="sm"
                      onClick={() => handleAddStudyTime(day)}
                      className="capitalize"
                    >
                      + {day}
                    </Button>
                  ))}
                </div>

                <Button onClick={handleSave} className="w-full">
                  <Save className="mr-2 h-4 w-4" />
                  Save Availability
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {pendingInvites.length > 0 && (
            <TabsContent value="invites">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Mentor Invitations
                  </CardTitle>
                  <CardDescription>Groups that want you as a mentor</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pendingInvites.map((invite) => {
                    const group = getGroupById(invite.groupId);
                    if (!group) return null;
                    return (
                      <div key={invite.id} className="flex items-center justify-between rounded-lg border p-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                            <BookOpen className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{group.name}</p>
                            <p className="text-sm text-muted-foreground">{group.subject}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => respondToInvite(invite.id, false)}
                          >
                            <X className="mr-1 h-4 w-4" />
                            Decline
                          </Button>
                          <Button size="sm" onClick={() => respondToInvite(invite.id, true)}>
                            <Check className="mr-1 h-4 w-4" />
                            Accept
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </motion.div>
    </div>
  );
}
