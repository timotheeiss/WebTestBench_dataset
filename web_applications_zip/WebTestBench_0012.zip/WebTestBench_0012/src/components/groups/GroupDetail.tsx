import { useState } from "react";
import { useParams, Navigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ArrowLeft,
  BookOpen,
  MessageSquare,
  Calendar,
  Users,
  Plus,
  Pin,
  Star,
  Award,
  Clock,
  Send,
  UserPlus,
  LogOut,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { noteCategories } from "@/data/mockData";
import { format } from "date-fns";
import { RSVP } from "@/types";

export function GroupDetail() {
  const { groupId } = useParams<{ groupId: string }>();
  const {
    currentUser,
    getGroupById,
    getUserById,
    users,
    addNote,
    togglePinNote,
    toggleRecommendNote,
    addDiscussion,
    addReply,
    togglePinDiscussion,
    createSession,
    updateRSVP,
    inviteMentor,
    leaveGroup,
  } = useApp();

  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [noteCategory, setNoteCategory] = useState("");
  const [discTitle, setDiscTitle] = useState("");
  const [discContent, setDiscContent] = useState("");
  const [sessionTitle, setSessionTitle] = useState("");
  const [sessionDesc, setSessionDesc] = useState("");
  const [sessionDate, setSessionDate] = useState("");
  const [sessionStart, setSessionStart] = useState("14:00");
  const [sessionEnd, setSessionEnd] = useState("16:00");
  const [replyContent, setReplyContent] = useState<Record<string, string>>({});
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [discDialogOpen, setDiscDialogOpen] = useState(false);
  const [sessionDialogOpen, setSessionDialogOpen] = useState(false);
  const [mentorDialogOpen, setMentorDialogOpen] = useState(false);

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  const group = getGroupById(groupId || "");
  if (!group) {
    return <Navigate to="/groups" replace />;
  }

  const membership = group.members.find((m) => m.userId === currentUser.id);
  if (!membership) {
    return <Navigate to="/groups" replace />;
  }

  const isOwnerOrMentor = membership.role === "owner" || membership.role === "mentor";
  const availableMentors = users.filter(
    (u) => u.isMentor && !group.members.some((m) => m.userId === u.id)
  );

  const handleAddNote = () => {
    if (!noteTitle || !noteContent || !noteCategory) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    addNote(group.id, {
      title: noteTitle,
      content: noteContent,
      category: noteCategory,
      createdBy: currentUser.id,
    });
    toast({ title: "Note added!" });
    setNoteTitle("");
    setNoteContent("");
    setNoteCategory("");
    setNoteDialogOpen(false);
  };

  const handleAddDiscussion = () => {
    if (!discTitle || !discContent) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    addDiscussion(group.id, {
      title: discTitle,
      content: discContent,
      createdBy: currentUser.id,
    });
    toast({ title: "Discussion started!" });
    setDiscTitle("");
    setDiscContent("");
    setDiscDialogOpen(false);
  };

  const handleAddReply = (discussionId: string) => {
    const content = replyContent[discussionId];
    if (!content) return;
    addReply(group.id, discussionId, content);
    setReplyContent((prev) => ({ ...prev, [discussionId]: "" }));
  };

  const handleCreateSession = () => {
    if (!sessionTitle || !sessionDate) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    createSession(group.id, {
      title: sessionTitle,
      description: sessionDesc,
      date: new Date(sessionDate),
      startTime: sessionStart,
      endTime: sessionEnd,
      createdBy: currentUser.id,
    });
    toast({ title: "Session scheduled!" });
    setSessionTitle("");
    setSessionDesc("");
    setSessionDate("");
    setSessionDialogOpen(false);
  };

  const handleRSVP = (sessionId: string, status: RSVP["status"]) => {
    updateRSVP(group.id, sessionId, status);
    toast({ title: "RSVP updated!" });
  };

  const handleInviteMentor = (mentorId: string) => {
    inviteMentor(group.id, mentorId);
    toast({ title: "Invitation sent!", description: "The mentor will see your request." });
    setMentorDialogOpen(false);
  };

  const handleLeaveGroup = () => {
    leaveGroup(group.id);
    toast({ title: "Left group" });
  };

  const pinnedNotes = group.notes.filter((n) => n.isPinned);
  const recommendedNotes = group.notes.filter((n) => n.isRecommended && !n.isPinned);
  const regularNotes = group.notes.filter((n) => !n.isPinned && !n.isRecommended);
  const sortedNotes = [...pinnedNotes, ...recommendedNotes, ...regularNotes];

  const pinnedDiscussions = group.discussions.filter((d) => d.isPinned);
  const regularDiscussions = group.discussions.filter((d) => !d.isPinned);
  const sortedDiscussions = [...pinnedDiscussions, ...regularDiscussions];

  const upcomingSessions = group.sessions
    .filter((s) => new Date(s.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="container max-w-6xl py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Link
          to="/groups"
          className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to groups
        </Link>

        <div className="mb-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2">
                <Badge variant="secondary">{group.subject}</Badge>
                <Badge variant="outline" className="capitalize">
                  {membership.role}
                </Badge>
              </div>
              <h1 className="text-3xl font-bold">{group.name}</h1>
              <p className="mt-1 text-muted-foreground">{group.description}</p>
            </div>
            <div className="flex gap-2">
              {isOwnerOrMentor && availableMentors.length > 0 && (
                <Dialog open={mentorDialogOpen} onOpenChange={setMentorDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Invite Mentor
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Invite a Mentor</DialogTitle>
                      <DialogDescription>Select a mentor to invite to your group.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 py-4">
                      {availableMentors.map((mentor) => (
                        <div
                          key={mentor.id}
                          className="flex items-center justify-between rounded-lg border p-3"
                        >
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={mentor.avatar} />
                              <AvatarFallback>{mentor.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{mentor.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {mentor.subjects.slice(0, 3).join(", ")}
                              </p>
                            </div>
                          </div>
                          <Button size="sm" onClick={() => handleInviteMentor(mentor.id)}>
                            Invite
                          </Button>
                        </div>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              )}
              {membership.role !== "owner" && (
                <Button variant="outline" size="sm" onClick={handleLeaveGroup}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Leave
                </Button>
              )}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-4">
            <div className="flex -space-x-2">
              {group.members.slice(0, 6).map((m) => {
                const user = getUserById(m.userId);
                return (
                  user && (
                    <Avatar key={m.userId} className="h-8 w-8 border-2 border-background">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback className="text-xs">{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                  )
                );
              })}
            </div>
            <span className="text-sm text-muted-foreground">
              {group.members.length} member{group.members.length !== 1 && "s"}
            </span>
          </div>
        </div>

        <Tabs defaultValue="notes">
          <TabsList className="mb-6 w-full justify-start">
            <TabsTrigger value="notes">
              <BookOpen className="mr-2 h-4 w-4" />
              Notes
            </TabsTrigger>
            <TabsTrigger value="discussions">
              <MessageSquare className="mr-2 h-4 w-4" />
              Discussions
            </TabsTrigger>
            <TabsTrigger value="sessions">
              <Calendar className="mr-2 h-4 w-4" />
              Sessions
            </TabsTrigger>
            <TabsTrigger value="members">
              <Users className="mr-2 h-4 w-4" />
              Members
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notes">
            <div className="mb-4 flex justify-end">
              <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Note
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add a Note</DialogTitle>
                    <DialogDescription>Share notes, summaries, or resources.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Title</Label>
                      <Input
                        placeholder="Note title"
                        value={noteTitle}
                        onChange={(e) => setNoteTitle(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select value={noteCategory} onValueChange={setNoteCategory}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {noteCategories.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Content</Label>
                      <Textarea
                        placeholder="Write your note..."
                        value={noteContent}
                        onChange={(e) => setNoteContent(e.target.value)}
                        rows={5}
                      />
                    </div>
                    <Button onClick={handleAddNote} className="w-full">
                      Add Note
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {sortedNotes.length === 0 ? (
              <Card className="flex flex-col items-center py-12">
                <BookOpen className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 font-medium">No notes yet</h3>
                <p className="text-sm text-muted-foreground">Be the first to share a note!</p>
              </Card>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {sortedNotes.map((note) => {
                  const author = getUserById(note.createdBy);
                  return (
                    <Card key={note.id} className="relative">
                      {note.isPinned && (
                        <Pin className="absolute right-3 top-3 h-4 w-4 text-primary" />
                      )}
                      {note.isRecommended && !note.isPinned && (
                        <Star className="absolute right-3 top-3 h-4 w-4 text-accent" />
                      )}
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{note.category}</Badge>
                        </div>
                        <CardTitle className="text-lg">{note.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4 whitespace-pre-wrap text-sm text-muted-foreground">
                          {note.content}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Avatar className="h-5 w-5">
                              <AvatarImage src={author?.avatar} />
                              <AvatarFallback>{author?.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span>{author?.name}</span>
                            <span>•</span>
                            <span>{format(new Date(note.createdAt), "MMM d")}</span>
                          </div>
                          {isOwnerOrMentor && (
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => togglePinNote(group.id, note.id)}
                              >
                                <Pin className={`h-4 w-4 ${note.isPinned ? "text-primary" : ""}`} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => toggleRecommendNote(group.id, note.id)}
                              >
                                <Star
                                  className={`h-4 w-4 ${note.isRecommended ? "text-accent" : ""}`}
                                />
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="discussions">
            <div className="mb-4 flex justify-end">
              <Dialog open={discDialogOpen} onOpenChange={setDiscDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Start Discussion
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Start a Discussion</DialogTitle>
                    <DialogDescription>Ask questions or start a conversation.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Title</Label>
                      <Input
                        placeholder="Question or topic"
                        value={discTitle}
                        onChange={(e) => setDiscTitle(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Content</Label>
                      <Textarea
                        placeholder="Provide details..."
                        value={discContent}
                        onChange={(e) => setDiscContent(e.target.value)}
                        rows={4}
                      />
                    </div>
                    <Button onClick={handleAddDiscussion} className="w-full">
                      Post Discussion
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {sortedDiscussions.length === 0 ? (
              <Card className="flex flex-col items-center py-12">
                <MessageSquare className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 font-medium">No discussions yet</h3>
                <p className="text-sm text-muted-foreground">Start a conversation!</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {sortedDiscussions.map((disc) => {
                  const author = getUserById(disc.createdBy);
                  return (
                    <Card key={disc.id} className="relative">
                      {disc.isPinned && (
                        <Pin className="absolute right-3 top-3 h-4 w-4 text-primary" />
                      )}
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={author?.avatar} />
                            <AvatarFallback>{author?.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{author?.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(disc.createdAt), "MMM d, h:mm a")}
                            </p>
                          </div>
                          {isOwnerOrMentor && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="ml-auto h-8 w-8"
                              onClick={() => togglePinDiscussion(group.id, disc.id)}
                            >
                              <Pin className={`h-4 w-4 ${disc.isPinned ? "text-primary" : ""}`} />
                            </Button>
                          )}
                        </div>
                        <CardTitle className="text-lg">{disc.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4 whitespace-pre-wrap text-muted-foreground">{disc.content}</p>

                        {disc.replies.length > 0 && (
                          <div className="mb-4 space-y-3 border-l-2 pl-4">
                            {disc.replies.map((reply) => {
                              const replyAuthor = getUserById(reply.createdBy);
                              return (
                                <div key={reply.id} className="text-sm">
                                  <div className="mb-1 flex items-center gap-2">
                                    <Avatar className="h-6 w-6">
                                      <AvatarImage src={replyAuthor?.avatar} />
                                      <AvatarFallback>{replyAuthor?.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <span className="font-medium">{replyAuthor?.name}</span>
                                    <span className="text-xs text-muted-foreground">
                                      {format(new Date(reply.createdAt), "MMM d")}
                                    </span>
                                  </div>
                                  <p className="text-muted-foreground">{reply.content}</p>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        <div className="flex gap-2">
                          <Input
                            placeholder="Write a reply..."
                            value={replyContent[disc.id] || ""}
                            onChange={(e) =>
                              setReplyContent((prev) => ({ ...prev, [disc.id]: e.target.value }))
                            }
                            onKeyDown={(e) => {
                              if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                handleAddReply(disc.id);
                              }
                            }}
                          />
                          <Button
                            size="icon"
                            onClick={() => handleAddReply(disc.id)}
                            disabled={!replyContent[disc.id]}
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="sessions">
            <div className="mb-4 flex justify-end">
              <Dialog open={sessionDialogOpen} onOpenChange={setSessionDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Schedule Session
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Schedule a Study Session</DialogTitle>
                    <DialogDescription>Plan a time for the group to study together.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Title</Label>
                      <Input
                        placeholder="e.g., Exam Review Session"
                        value={sessionTitle}
                        onChange={(e) => setSessionTitle(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description (optional)</Label>
                      <Textarea
                        placeholder="What will you cover?"
                        value={sessionDesc}
                        onChange={(e) => setSessionDesc(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={sessionDate}
                        onChange={(e) => setSessionDate(e.target.value)}
                        min={format(new Date(), "yyyy-MM-dd")}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Start Time</Label>
                        <Input
                          type="time"
                          value={sessionStart}
                          onChange={(e) => setSessionStart(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>End Time</Label>
                        <Input
                          type="time"
                          value={sessionEnd}
                          onChange={(e) => setSessionEnd(e.target.value)}
                        />
                      </div>
                    </div>
                    <Button onClick={handleCreateSession} className="w-full">
                      Schedule Session
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {upcomingSessions.length === 0 ? (
              <Card className="flex flex-col items-center py-12">
                <Calendar className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 font-medium">No upcoming sessions</h3>
                <p className="text-sm text-muted-foreground">Schedule a study session!</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {upcomingSessions.map((session) => {
                  const organizer = getUserById(session.createdBy);
                  const myRsvp = session.rsvps.find((r) => r.userId === currentUser.id);
                  const attendingCount = session.rsvps.filter((r) => r.status === "attending").length;
                  const maybeCount = session.rsvps.filter((r) => r.status === "maybe").length;

                  return (
                    <Card key={session.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{session.title}</CardTitle>
                            {session.description && (
                              <CardDescription className="mt-1">{session.description}</CardDescription>
                            )}
                          </div>
                          <Badge variant="secondary">
                            <Clock className="mr-1 h-3 w-3" />
                            {session.startTime} - {session.endTime}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-4 flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{format(new Date(session.date), "EEEE, MMMM d, yyyy")}</span>
                          <span>•</span>
                          <span>Organized by {organizer?.name}</span>
                        </div>

                        <div className="mb-4 flex items-center gap-4 text-sm">
                          <span className="flex items-center gap-1 text-success">
                            <span className="font-medium">{attendingCount}</span> attending
                          </span>
                          <span className="flex items-center gap-1 text-accent">
                            <span className="font-medium">{maybeCount}</span> maybe
                          </span>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant={myRsvp?.status === "attending" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleRSVP(session.id, "attending")}
                            className={myRsvp?.status === "attending" ? "bg-success hover:bg-success/90" : ""}
                          >
                            Attending
                          </Button>
                          <Button
                            variant={myRsvp?.status === "maybe" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleRSVP(session.id, "maybe")}
                            className={myRsvp?.status === "maybe" ? "bg-accent text-accent-foreground hover:bg-accent/90" : ""}
                          >
                            Maybe
                          </Button>
                          <Button
                            variant={myRsvp?.status === "not-attending" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleRSVP(session.id, "not-attending")}
                            className={myRsvp?.status === "not-attending" ? "bg-destructive hover:bg-destructive/90" : ""}
                          >
                            Can't make it
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="members">
            <div className="grid gap-4 md:grid-cols-2">
              {group.members.map((member) => {
                const user = getUserById(member.userId);
                if (!user) return null;
                return (
                  <Card key={member.userId}>
                    <CardContent className="flex items-center gap-4 p-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{user.name}</p>
                          <Badge
                            variant="outline"
                            className={`capitalize ${
                              member.role === "mentor" ? "border-mentor text-mentor" : ""
                            } ${member.role === "owner" ? "border-primary text-primary" : ""}`}
                          >
                            {member.role === "mentor" && <Award className="mr-1 h-3 w-3" />}
                            {member.role}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {user.subjects.slice(0, 3).join(", ")}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}
