import { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Users, BookOpen, Calendar, Award } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { subjects } from "@/data/mockData";

export function GroupsList() {
  const { currentUser, groups, users, createGroup, joinGroup } = useApp();
  const [search, setSearch] = useState("");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupDesc, setNewGroupDesc] = useState("");
  const [newGroupSubject, setNewGroupSubject] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  const filteredGroups = groups.filter((group) => {
    const matchesSearch =
      group.name.toLowerCase().includes(search.toLowerCase()) ||
      group.description.toLowerCase().includes(search.toLowerCase());
    const matchesSubject = subjectFilter === "all" || group.subject === subjectFilter;
    return matchesSearch && matchesSubject;
  });

  const myGroups = filteredGroups.filter((g) =>
    g.members.some((m) => m.userId === currentUser.id)
  );
  const otherGroups = filteredGroups.filter(
    (g) => !g.members.some((m) => m.userId === currentUser.id)
  );

  const handleCreateGroup = () => {
    if (!newGroupName || !newGroupSubject) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    createGroup({
      name: newGroupName,
      description: newGroupDesc,
      subject: newGroupSubject,
      createdBy: currentUser.id,
    });
    toast({ title: "Group created!", description: "Your study group is ready." });
    setNewGroupName("");
    setNewGroupDesc("");
    setNewGroupSubject("");
    setDialogOpen(false);
  };

  const handleJoinGroup = (groupId: string) => {
    joinGroup(groupId);
    toast({ title: "Joined group!", description: "You're now a member." });
  };

  const GroupCard = ({ group, isMember }: { group: typeof groups[0]; isMember: boolean }) => {
    const memberUsers = group.members
      .slice(0, 4)
      .map((m) => users.find((u) => u.id === m.userId))
      .filter(Boolean);
    const mentorCount = group.members.filter((m) => m.role === "mentor").length;

    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ y: -4 }}
        transition={{ duration: 0.2 }}
      >
        <Card className="h-full overflow-hidden transition-shadow hover:shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <Badge variant="secondary">{group.subject}</Badge>
              {mentorCount > 0 && (
                <Badge className="bg-mentor/10 text-mentor">
                  <Award className="mr-1 h-3 w-3" />
                  {mentorCount} Mentor{mentorCount > 1 ? "s" : ""}
                </Badge>
              )}
            </div>
            <CardTitle className="mt-2 line-clamp-1">{group.name}</CardTitle>
            <CardDescription className="line-clamp-2">{group.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                <span>{group.members.length} members</span>
              </div>
              <div className="flex items-center gap-1">
                <BookOpen className="h-4 w-4" />
                <span>{group.notes.length} notes</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>{group.sessions.length} sessions</span>
              </div>
            </div>

            <div className="mb-4 flex -space-x-2">
              {memberUsers.map(
                (user) =>
                  user && (
                    <Avatar key={user.id} className="h-8 w-8 border-2 border-card">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="text-xs">{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                  )
              )}
              {group.members.length > 4 && (
                <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-card bg-muted text-xs">
                  +{group.members.length - 4}
                </div>
              )}
            </div>

            {isMember ? (
              <Button asChild className="w-full">
                <Link to={`/groups/${group.id}`}>Open Group</Link>
              </Button>
            ) : (
              <Button variant="outline" className="w-full" onClick={() => handleJoinGroup(group.id)}>
                Join Group
              </Button>
            )}
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  return (
    <div className="container py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Study Groups</h1>
            <p className="text-muted-foreground">Find or create your perfect study group</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Group
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create a Study Group</DialogTitle>
                <DialogDescription>
                  Start a new group and invite others to join.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="groupName">Group Name</Label>
                  <Input
                    id="groupName"
                    placeholder="e.g., Calculus Champions"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="groupDesc">Description</Label>
                  <Textarea
                    id="groupDesc"
                    placeholder="What will your group study?"
                    value={newGroupDesc}
                    onChange={(e) => setNewGroupDesc(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Subject</Label>
                  <Select value={newGroupSubject} onValueChange={setNewGroupSubject}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject} value={subject}>
                          {subject}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleCreateGroup} className="w-full">
                  Create Group
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="mb-6 flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search groups..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="All subjects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All subjects</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject} value={subject}>
                  {subject}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {myGroups.length > 0 && (
          <div className="mb-8">
            <h2 className="mb-4 text-xl font-semibold">Your Groups</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {myGroups.map((group) => (
                <GroupCard key={group.id} group={group} isMember={true} />
              ))}
            </div>
          </div>
        )}

        {otherGroups.length > 0 && (
          <div>
            <h2 className="mb-4 text-xl font-semibold">Discover Groups</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {otherGroups.map((group) => (
                <GroupCard key={group.id} group={group} isMember={false} />
              ))}
            </div>
          </div>
        )}

        {filteredGroups.length === 0 && (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-16">
            <BookOpen className="mb-4 h-12 w-12 text-muted-foreground" />
            <h3 className="mb-2 text-lg font-medium">No groups found</h3>
            <p className="mb-4 text-muted-foreground">Try a different search or create your own group.</p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Group
            </Button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
