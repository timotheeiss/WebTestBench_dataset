export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  subjects: string[];
  level: "high-school" | "undergraduate" | "graduate" | "professional";
  preferredStudyTimes: StudyTime[];
  isMentor: boolean;
  joinedAt: Date;
}

export interface StudyTime {
  day: "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday";
  startHour: number;
  endHour: number;
}

export interface StudyGroup {
  id: string;
  name: string;
  description: string;
  subject: string;
  coverImage?: string;
  createdAt: Date;
  createdBy: string;
  members: GroupMember[];
  notes: Note[];
  discussions: Discussion[];
  sessions: StudySession[];
}

export interface GroupMember {
  userId: string;
  role: "owner" | "mentor" | "member";
  joinedAt: Date;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  category: string;
  createdBy: string;
  createdAt: Date;
  isPinned: boolean;
  isRecommended: boolean;
}

export interface Discussion {
  id: string;
  title: string;
  content: string;
  createdBy: string;
  createdAt: Date;
  isPinned: boolean;
  replies: Reply[];
}

export interface Reply {
  id: string;
  content: string;
  createdBy: string;
  createdAt: Date;
}

export interface StudySession {
  id: string;
  title: string;
  description?: string;
  date: Date;
  startTime: string;
  endTime: string;
  createdBy: string;
  rsvps: RSVP[];
}

export interface RSVP {
  userId: string;
  status: "attending" | "maybe" | "not-attending";
}

export interface MentorInvite {
  id: string;
  groupId: string;
  mentorId: string;
  status: "pending" | "accepted" | "declined";
  sentAt: Date;
}
