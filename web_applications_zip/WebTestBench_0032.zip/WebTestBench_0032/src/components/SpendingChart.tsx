import { useMemo } from "react";
import { useBudget } from "@/contexts/BudgetContext";
import { formatCurrency } from "@/data/budgetData";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export const SpendingChart = () => {
  const { categories, primaryCurrency, getTotalSpentByCategory } = useBudget();

  const chartData = useMemo(() => {
    return categories.map((cat) => ({
      name: cat.name,
      icon: cat.icon,
      spent: getTotalSpentByCategory(cat.id),
      budget: cat.monthlyBudget,
      color: cat.color,
    }));
  }, [categories, getTotalSpentByCategory]);

  return (
    <div className="bg-card rounded-xl p-5 shadow-soft border border-border/50">
      <h2 className="text-lg font-semibold text-foreground mb-4">
        Budget vs Spending
      </h2>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            layout="vertical"
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <XAxis
              type="number"
              tickFormatter={(value) =>
                formatCurrency(value, primaryCurrency).replace(/\.\d+/, "")
              }
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <YAxis
              type="category"
              dataKey="icon"
              width={30}
              stroke="hsl(var(--muted-foreground))"
              fontSize={16}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
                      <p className="font-medium text-foreground">{data.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Spent: {formatCurrency(data.spent, primaryCurrency)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Budget: {formatCurrency(data.budget, primaryCurrency)}
                      </p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Bar dataKey="budget" fill="hsl(var(--muted))" radius={[0, 4, 4, 0]} />
            <Bar dataKey="spent" radius={[0, 4, 4, 0]}>
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={
                    entry.spent > entry.budget
                      ? "hsl(var(--destructive))"
                      : entry.color
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
