import { Goal, formatCurrency } from "@/data/budgetData";
import { useBudget } from "@/contexts/BudgetContext";
import { Progress } from "@/components/ui/progress";
import { Target } from "lucide-react";

interface GoalCardProps {
  goal: Goal;
}

export const GoalCard = ({ goal }: GoalCardProps) => {
  const { primaryCurrency } = useBudget();
  const percentage = (goal.currentAmount / goal.targetAmount) * 100;
  const remaining = goal.targetAmount - goal.currentAmount;
  const deadline = new Date(goal.deadline);
  const daysLeft = Math.ceil(
    (deadline.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="bg-card rounded-xl p-5 shadow-soft border border-border/50 hover:shadow-lg transition-all duration-300">
      <div className="flex items-start gap-3 mb-4">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${goal.color}20` }}
        >
          <Target className="w-5 h-5" style={{ color: goal.color }} />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">{goal.name}</h3>
          <p className="text-sm text-muted-foreground">
            {daysLeft > 0 ? `${daysLeft} days left` : "Deadline passed"}
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-medium text-foreground font-mono">
            {formatCurrency(goal.currentAmount, primaryCurrency)}
          </span>
        </div>
        <Progress
          value={percentage}
          className="h-2 [&>div]:gradient-primary"
        />
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Remaining</span>
          <span className="font-medium text-foreground font-mono">
            {formatCurrency(remaining, primaryCurrency)}
          </span>
        </div>
      </div>
    </div>
  );
};
