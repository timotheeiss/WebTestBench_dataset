import { useState, useMemo } from "react";
import { useBudget } from "@/contexts/BudgetContext";
import { formatCurrency, currencySymbols } from "@/data/budgetData";
import { format } from "date-fns";
import { Trash2, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const ExpenseList = () => {
  const {
    expenses,
    categories,
    goals,
    primaryCurrency,
    getExpenseInPrimaryCurrency,
    deleteExpense,
  } = useBudget();

  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [goalFilter, setGoalFilter] = useState<string>("all");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [showFilters, setShowFilters] = useState(false);

  const filteredExpenses = useMemo(() => {
    return expenses.filter((expense) => {
      if (categoryFilter !== "all" && expense.categoryId !== categoryFilter) {
        return false;
      }
      if (goalFilter !== "all") {
        if (goalFilter === "none" && expense.goalId) return false;
        if (goalFilter !== "none" && expense.goalId !== goalFilter) return false;
      }
      if (startDate && new Date(expense.date) < new Date(startDate)) {
        return false;
      }
      if (endDate && new Date(expense.date) > new Date(endDate)) {
        return false;
      }
      return true;
    });
  }, [expenses, categoryFilter, goalFilter, startDate, endDate]);

  const clearFilters = () => {
    setCategoryFilter("all");
    setGoalFilter("all");
    setStartDate("");
    setEndDate("");
  };

  const hasActiveFilters =
    categoryFilter !== "all" ||
    goalFilter !== "all" ||
    startDate !== "" ||
    endDate !== "";

  return (
    <div className="bg-card rounded-xl shadow-soft border border-border/50 overflow-hidden">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Recent Expenses</h2>
        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4 mr-1" />
              Clear
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className={cn(showFilters && "bg-secondary")}
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      {showFilters && (
        <div className="p-4 bg-secondary/50 border-b border-border grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="text-sm text-muted-foreground mb-1 block">Category</label>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="bg-card">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50">
                <SelectItem value="all">All categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">Goal</label>
            <Select value={goalFilter} onValueChange={setGoalFilter}>
              <SelectTrigger className="bg-card">
                <SelectValue placeholder="All goals" />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50">
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="none">No goal</SelectItem>
                {goals.map((goal) => (
                  <SelectItem key={goal.id} value={goal.id}>
                    {goal.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">From</label>
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-card"
            />
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">To</label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-card"
            />
          </div>
        </div>
      )}

      <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
        {filteredExpenses.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            No expenses found matching your filters.
          </div>
        ) : (
          filteredExpenses.map((expense) => {
            const category = categories.find((c) => c.id === expense.categoryId);
            const goal = goals.find((g) => g.id === expense.goalId);
            const convertedAmount = getExpenseInPrimaryCurrency(expense);

            return (
              <div
                key={expense.id}
                className="p-4 flex items-center gap-4 hover:bg-secondary/30 transition-colors group"
              >
                <span className="text-2xl">{category?.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate">
                    {expense.description}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {category?.name}
                    {goal && (
                      <span className="ml-2 px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full">
                        {goal.name}
                      </span>
                    )}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-foreground font-mono">
                    {formatCurrency(convertedAmount, primaryCurrency)}
                  </p>
                  {expense.currency !== primaryCurrency && (
                    <p className="text-xs text-muted-foreground font-mono">
                      {currencySymbols[expense.currency]}
                      {expense.amount.toFixed(2)}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(expense.date), "MMM d, yyyy")}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                  onClick={() => deleteExpense(expense.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
