import { useBudget } from "@/contexts/BudgetContext";
import { currencySymbols, formatCurrency } from "@/data/budgetData";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Wallet } from "lucide-react";

export const Header = () => {
  const { primaryCurrency, setPrimaryCurrency, expenses, getExpenseInPrimaryCurrency } = useBudget();

  const totalSpent = expenses.reduce(
    (sum, e) => sum + getExpenseInPrimaryCurrency(e),
    0
  );

  const currencies = Object.keys(currencySymbols);

  return (
    <header className="border-b border-border bg-card shadow-soft sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center shadow-glow">
              <Wallet className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">BudgetFlow</h1>
              <p className="text-sm text-muted-foreground">Track your finances</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden sm:block text-right">
              <p className="text-sm text-muted-foreground">Total Spent</p>
              <p className="text-lg font-semibold text-foreground font-mono">
                {formatCurrency(totalSpent, primaryCurrency)}
              </p>
            </div>

            <Select value={primaryCurrency} onValueChange={setPrimaryCurrency}>
              <SelectTrigger className="w-[100px] bg-secondary border-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50">
                {currencies.map((currency) => (
                  <SelectItem key={currency} value={currency}>
                    {currencySymbols[currency]} {currency}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </header>
  );
};
