import { useBudget } from "@/contexts/BudgetContext";
import { Category, formatCurrency } from "@/data/budgetData";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface BudgetCategoryCardProps {
  category: Category;
}

export const BudgetCategoryCard = ({ category }: BudgetCategoryCardProps) => {
  const { primaryCurrency, getTotalSpentByCategory } = useBudget();
  const spent = getTotalSpentByCategory(category.id);
  const percentage = Math.min((spent / category.monthlyBudget) * 100, 100);
  const isOverBudget = spent > category.monthlyBudget;

  return (
    <div className="bg-card rounded-xl p-4 shadow-soft border border-border/50 hover:shadow-lg transition-all duration-300">
      <div className="flex items-center gap-3 mb-3">
        <span className="text-2xl">{category.icon}</span>
        <div className="flex-1">
          <h3 className="font-medium text-foreground">{category.name}</h3>
          <p className="text-sm text-muted-foreground">
            {formatCurrency(spent, primaryCurrency)} of{" "}
            {formatCurrency(category.monthlyBudget, primaryCurrency)}
          </p>
        </div>
        <span
          className={cn(
            "text-sm font-medium px-2 py-1 rounded-full",
            isOverBudget
              ? "bg-destructive/10 text-destructive"
              : percentage > 80
              ? "bg-warning/10 text-warning"
              : "bg-success/10 text-success"
          )}
        >
          {percentage.toFixed(0)}%
        </span>
      </div>
      <Progress
        value={percentage}
        className={cn(
          "h-2",
          isOverBudget
            ? "[&>div]:bg-destructive"
            : percentage > 80
            ? "[&>div]:bg-warning"
            : "[&>div]:bg-success"
        )}
      />
    </div>
  );
};
