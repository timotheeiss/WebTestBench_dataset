import { useMemo } from "react";
import { useBudget } from "@/contexts/BudgetContext";
import { formatCurrency } from "@/data/budgetData";
import { format, subDays, eachDayOfInterval } from "date-fns";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export const TrendChart = () => {
  const { expenses, primaryCurrency, getExpenseInPrimaryCurrency } = useBudget();

  const chartData = useMemo(() => {
    const endDate = new Date();
    const startDate = subDays(endDate, 13);
    const days = eachDayOfInterval({ start: startDate, end: endDate });

    return days.map((day) => {
      const dayStr = format(day, "yyyy-MM-dd");
      const dayExpenses = expenses.filter(
        (e) => format(new Date(e.date), "yyyy-MM-dd") === dayStr
      );
      const total = dayExpenses.reduce(
        (sum, e) => sum + getExpenseInPrimaryCurrency(e),
        0
      );

      return {
        date: format(day, "MMM d"),
        amount: total,
      };
    });
  }, [expenses, getExpenseInPrimaryCurrency]);

  return (
    <div className="bg-card rounded-xl p-5 shadow-soft border border-border/50">
      <h2 className="text-lg font-semibold text-foreground mb-4">
        Spending Trend (Last 14 Days)
      </h2>
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor="hsl(var(--primary))"
                  stopOpacity={0.3}
                />
                <stop
                  offset="95%"
                  stopColor="hsl(var(--primary))"
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="date"
              stroke="hsl(var(--muted-foreground))"
              fontSize={11}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke="hsl(var(--muted-foreground))"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) =>
                formatCurrency(value, primaryCurrency).replace(/\.\d+/, "")
              }
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
                      <p className="text-sm text-muted-foreground">
                        {payload[0].payload.date}
                      </p>
                      <p className="font-semibold text-foreground font-mono">
                        {formatCurrency(
                          payload[0].value as number,
                          primaryCurrency
                        )}
                      </p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="amount"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorAmount)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
