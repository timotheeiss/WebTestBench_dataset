// Currency exchange rates (relative to USD)
export const exchangeRates: Record<string, number> = {
  USD: 1,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 149.5,
  CAD: 1.36,
  AUD: 1.53,
  CHF: 0.88,
  MXN: 17.15,
};

export const currencySymbols: Record<string, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  CAD: "C$",
  AUD: "A$",
  CHF: "Fr",
  MXN: "MX$",
};

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  monthlyBudget: number;
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  color: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  currency: string;
  categoryId: string;
  goalId?: string;
  date: string;
}

export const categories: Category[] = [
  { id: "food", name: "Food & Dining", icon: "🍽️", color: "hsl(160, 60%, 40%)", monthlyBudget: 600 },
  { id: "transport", name: "Transportation", icon: "🚗", color: "hsl(200, 70%, 50%)", monthlyBudget: 400 },
  { id: "shopping", name: "Shopping", icon: "🛍️", color: "hsl(35, 90%, 55%)", monthlyBudget: 300 },
  { id: "entertainment", name: "Entertainment", icon: "🎬", color: "hsl(280, 60%, 55%)", monthlyBudget: 200 },
  { id: "utilities", name: "Utilities", icon: "💡", color: "hsl(45, 80%, 50%)", monthlyBudget: 250 },
  { id: "health", name: "Health", icon: "🏥", color: "hsl(0, 70%, 55%)", monthlyBudget: 150 },
  { id: "travel", name: "Travel", icon: "✈️", color: "hsl(190, 70%, 45%)", monthlyBudget: 500 },
  { id: "other", name: "Other", icon: "📦", color: "hsl(220, 15%, 50%)", monthlyBudget: 200 },
];

export const goals: Goal[] = [
  {
    id: "vacation",
    name: "Summer Vacation",
    targetAmount: 3000,
    currentAmount: 1850,
    deadline: "2025-07-01",
    color: "hsl(190, 70%, 45%)",
  },
  {
    id: "emergency",
    name: "Emergency Fund",
    targetAmount: 10000,
    currentAmount: 6500,
    deadline: "2025-12-31",
    color: "hsl(160, 60%, 40%)",
  },
  {
    id: "laptop",
    name: "New Laptop",
    targetAmount: 2000,
    currentAmount: 800,
    deadline: "2025-04-01",
    color: "hsl(280, 60%, 55%)",
  },
];

export const expenses: Expense[] = [
  { id: "1", description: "Grocery shopping", amount: 85.50, currency: "USD", categoryId: "food", date: "2024-12-12" },
  { id: "2", description: "Uber ride", amount: 24.00, currency: "USD", categoryId: "transport", date: "2024-12-11" },
  { id: "3", description: "Netflix subscription", amount: 15.99, currency: "USD", categoryId: "entertainment", date: "2024-12-10" },
  { id: "4", description: "Coffee shop", amount: 12.50, currency: "EUR", categoryId: "food", date: "2024-12-10" },
  { id: "5", description: "Electric bill", amount: 95.00, currency: "USD", categoryId: "utilities", date: "2024-12-09" },
  { id: "6", description: "New shoes", amount: 89.99, currency: "USD", categoryId: "shopping", date: "2024-12-08" },
  { id: "7", description: "Restaurant dinner", amount: 65.00, currency: "USD", categoryId: "food", date: "2024-12-07" },
  { id: "8", description: "Gas station", amount: 45.00, currency: "USD", categoryId: "transport", date: "2024-12-06" },
  { id: "9", description: "Pharmacy", amount: 32.50, currency: "USD", categoryId: "health", date: "2024-12-05" },
  { id: "10", description: "Flight booking", amount: 350.00, currency: "USD", categoryId: "travel", goalId: "vacation", date: "2024-12-04" },
  { id: "11", description: "Movie tickets", amount: 28.00, currency: "USD", categoryId: "entertainment", date: "2024-12-03" },
  { id: "12", description: "Lunch", amount: 18.50, currency: "GBP", categoryId: "food", date: "2024-12-02" },
  { id: "13", description: "Amazon purchase", amount: 67.99, currency: "USD", categoryId: "shopping", date: "2024-12-01" },
  { id: "14", description: "Internet bill", amount: 79.99, currency: "USD", categoryId: "utilities", date: "2024-11-30" },
  { id: "15", description: "Gym membership", amount: 49.99, currency: "USD", categoryId: "health", date: "2024-11-29" },
  { id: "16", description: "Train ticket", amount: 35.00, currency: "EUR", categoryId: "transport", date: "2024-11-28" },
  { id: "17", description: "Groceries", amount: 120.00, currency: "USD", categoryId: "food", date: "2024-11-27" },
  { id: "18", description: "Concert tickets", amount: 85.00, currency: "USD", categoryId: "entertainment", date: "2024-11-26" },
  { id: "19", description: "Hotel deposit", amount: 200.00, currency: "USD", categoryId: "travel", goalId: "vacation", date: "2024-11-25" },
  { id: "20", description: "Clothing", amount: 150.00, currency: "USD", categoryId: "shopping", date: "2024-11-24" },
];

export const convertCurrency = (
  amount: number,
  fromCurrency: string,
  toCurrency: string
): number => {
  const inUsd = amount / exchangeRates[fromCurrency];
  return inUsd * exchangeRates[toCurrency];
};

export const formatCurrency = (amount: number, currency: string): string => {
  const symbol = currencySymbols[currency] || currency;
  return `${symbol}${amount.toFixed(2)}`;
};
