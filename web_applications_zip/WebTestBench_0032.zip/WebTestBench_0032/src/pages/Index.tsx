import { useBudget } from "@/contexts/BudgetContext";
import { formatCurrency } from "@/data/budgetData";
import { Header } from "@/components/Header";
import { StatCard } from "@/components/StatCard";
import { BudgetCategoryCard } from "@/components/BudgetCategoryCard";
import { GoalCard } from "@/components/GoalCard";
import { ExpenseList } from "@/components/ExpenseList";
import { AddExpenseDialog } from "@/components/AddExpenseDialog";
import { SpendingChart } from "@/components/SpendingChart";
import { TrendChart } from "@/components/TrendChart";
import { Wallet, TrendingUp, Target, CreditCard } from "lucide-react";

const Index = () => {
  const {
    categories,
    goals,
    expenses,
    primaryCurrency,
    getExpenseInPrimaryCurrency,
    getTotalSpentByCategory,
  } = useBudget();

  // Calculate stats
  const totalBudget = categories.reduce((sum, c) => sum + c.monthlyBudget, 0);
  const totalSpent = categories.reduce(
    (sum, c) => sum + getTotalSpentByCategory(c.id),
    0
  );
  const remaining = totalBudget - totalSpent;
  const avgPerDay =
    expenses.length > 0
      ? expenses.reduce((sum, e) => sum + getExpenseInPrimaryCurrency(e), 0) /
        14
      : 0;

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Monthly Budget"
            value={formatCurrency(totalBudget, primaryCurrency)}
            icon={<Wallet className="w-5 h-5" />}
          />
          <StatCard
            title="Total Spent"
            value={formatCurrency(totalSpent, primaryCurrency)}
            subtitle={`${((totalSpent / totalBudget) * 100).toFixed(0)}% of budget`}
            trend={totalSpent > totalBudget ? "down" : "neutral"}
            icon={<CreditCard className="w-5 h-5" />}
          />
          <StatCard
            title="Remaining"
            value={formatCurrency(remaining, primaryCurrency)}
            subtitle={remaining < 0 ? "Over budget!" : "Available to spend"}
            trend={remaining < 0 ? "down" : "up"}
            icon={<TrendingUp className="w-5 h-5" />}
          />
          <StatCard
            title="Daily Average"
            value={formatCurrency(avgPerDay, primaryCurrency)}
            subtitle="Last 14 days"
            icon={<Target className="w-5 h-5" />}
          />
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <AddExpenseDialog />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SpendingChart />
          <TrendChart />
        </div>

        {/* Budget Categories */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-4">
            Budget Categories
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {categories.map((category) => (
              <BudgetCategoryCard key={category.id} category={category} />
            ))}
          </div>
        </section>

        {/* Goals */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-4">
            Financial Goals
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {goals.map((goal) => (
              <GoalCard key={goal.id} goal={goal} />
            ))}
          </div>
        </section>

        {/* Expense List */}
        <section>
          <ExpenseList />
        </section>
      </main>
    </div>
  );
};

export default Index;
