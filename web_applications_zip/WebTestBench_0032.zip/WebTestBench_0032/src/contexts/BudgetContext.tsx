import React, { createContext, useContext, useState, ReactNode } from "react";
import {
  categories as initialCategories,
  goals as initialGoals,
  expenses as initialExpenses,
  Category,
  Goal,
  Expense,
  convertCurrency,
} from "@/data/budgetData";

interface BudgetContextType {
  primaryCurrency: string;
  setPrimaryCurrency: (currency: string) => void;
  categories: Category[];
  goals: Goal[];
  expenses: Expense[];
  addExpense: (expense: Omit<Expense, "id">) => void;
  deleteExpense: (id: string) => void;
  addGoal: (goal: Omit<Goal, "id">) => void;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  getExpenseInPrimaryCurrency: (expense: Expense) => number;
  getTotalSpentByCategory: (categoryId: string) => number;
}

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

export const BudgetProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [primaryCurrency, setPrimaryCurrency] = useState("USD");
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [goals, setGoals] = useState<Goal[]>(initialGoals);
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);

  const addExpense = (expense: Omit<Expense, "id">) => {
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString(),
    };
    setExpenses((prev) => [newExpense, ...prev]);
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const addGoal = (goal: Omit<Goal, "id">) => {
    const newGoal: Goal = {
      ...goal,
      id: Date.now().toString(),
    };
    setGoals((prev) => [...prev, newGoal]);
  };

  const updateCategory = (id: string, updates: Partial<Category>) => {
    setCategories((prev) =>
      prev.map((cat) => (cat.id === id ? { ...cat, ...updates } : cat))
    );
  };

  const getExpenseInPrimaryCurrency = (expense: Expense): number => {
    return convertCurrency(expense.amount, expense.currency, primaryCurrency);
  };

  const getTotalSpentByCategory = (categoryId: string): number => {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    return expenses
      .filter(
        (e) =>
          e.categoryId === categoryId &&
          new Date(e.date) >= startOfMonth
      )
      .reduce((sum, e) => sum + getExpenseInPrimaryCurrency(e), 0);
  };

  return (
    <BudgetContext.Provider
      value={{
        primaryCurrency,
        setPrimaryCurrency,
        categories,
        goals,
        expenses,
        addExpense,
        deleteExpense,
        addGoal,
        updateCategory,
        getExpenseInPrimaryCurrency,
        getTotalSpentByCategory,
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
};

export const useBudget = () => {
  const context = useContext(BudgetContext);
  if (context === undefined) {
    throw new Error("useBudget must be used within a BudgetProvider");
  }
  return context;
};
