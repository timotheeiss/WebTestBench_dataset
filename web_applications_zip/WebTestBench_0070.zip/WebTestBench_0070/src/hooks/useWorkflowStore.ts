import { useState, useCallback } from 'react';
import { RuleSet, WorkflowStep, SimulationResult, TabType, FilterState } from '@/types/workflow';
import { defaultRuleSets } from '@/data/defaultRuleSets';

const generateId = () => `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

export function useWorkflowStore() {
  const [ruleSets, setRuleSets] = useState<RuleSet[]>(defaultRuleSets);
  const [selectedRuleSetId, setSelectedRuleSetId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('list');
  const [simulationResults, setSimulationResults] = useState<SimulationResult[]>([]);
  const [filterState, setFilterState] = useState<FilterState>({
    searchQuery: '',
    sortBy: 'date',
    sortOrder: 'desc',
  });

  const selectedRuleSet = ruleSets.find(rs => rs.id === selectedRuleSetId) || null;

  const createRuleSet = useCallback((name: string) => {
    const newRuleSet: RuleSet = {
      id: generateId(),
      name,
      steps: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      hasBeenSaved: false,
    };
    setRuleSets(prev => [...prev, newRuleSet]);
    setSelectedRuleSetId(newRuleSet.id);
    setActiveTab('editor');
    return newRuleSet;
  }, []);

  const updateRuleSetName = useCallback((id: string, name: string) => {
    setRuleSets(prev => prev.map(rs => 
      rs.id === id ? { ...rs, name, updatedAt: new Date() } : rs
    ));
  }, []);

  const deleteRuleSet = useCallback((id: string) => {
    setRuleSets(prev => prev.filter(rs => rs.id !== id));
    if (selectedRuleSetId === id) {
      setSelectedRuleSetId(null);
      setActiveTab('list');
    }
    setSimulationResults(prev => prev.filter(sr => sr.ruleSetId !== id));
  }, [selectedRuleSetId]);

  const addStep = useCallback((ruleSetId: string, stepName: string) => {
    setRuleSets(prev => prev.map(rs => {
      if (rs.id !== ruleSetId) return rs;
      const newStep: WorkflowStep = {
        id: generateId(),
        name: stepName,
        order: rs.steps.length + 1,
      };
      return { ...rs, steps: [...rs.steps, newStep], updatedAt: new Date() };
    }));
  }, []);

  const removeStep = useCallback((ruleSetId: string, stepId: string) => {
    setRuleSets(prev => prev.map(rs => {
      if (rs.id !== ruleSetId) return rs;
      const filteredSteps = rs.steps.filter(s => s.id !== stepId);
      const reorderedSteps = filteredSteps.map((s, idx) => ({ ...s, order: idx + 1 }));
      return { ...rs, steps: reorderedSteps, updatedAt: new Date() };
    }));
  }, []);

  const updateStepName = useCallback((ruleSetId: string, stepId: string, name: string) => {
    setRuleSets(prev => prev.map(rs => {
      if (rs.id !== ruleSetId) return rs;
      const updatedSteps = rs.steps.map(s => s.id === stepId ? { ...s, name } : s);
      return { ...rs, steps: updatedSteps, updatedAt: new Date() };
    }));
  }, []);

  const saveRuleSet = useCallback((ruleSetId: string) => {
    setRuleSets(prev => prev.map(rs => 
      rs.id === ruleSetId ? { ...rs, hasBeenSaved: true, updatedAt: new Date() } : rs
    ));
  }, []);

  const runSimulation = useCallback((ruleSetId: string): SimulationResult | null => {
    const ruleSet = ruleSets.find(rs => rs.id === ruleSetId);
    if (!ruleSet || !ruleSet.hasBeenSaved || ruleSet.steps.length === 0) {
      return null;
    }

    const result: SimulationResult = {
      ruleSetId: ruleSet.id,
      ruleSetName: ruleSet.name,
      steps: [...ruleSet.steps],
      timestamp: new Date(),
      status: 'completed',
    };

    setSimulationResults(prev => [result, ...prev]);
    setActiveTab('simulation');
    return result;
  }, [ruleSets]);

  const canEdit = useCallback((ruleSetId: string) => {
    const ruleSet = ruleSets.find(rs => rs.id === ruleSetId);
    return !!ruleSet;
  }, [ruleSets]);

  const canSimulate = useCallback((ruleSetId: string) => {
    const ruleSet = ruleSets.find(rs => rs.id === ruleSetId);
    return ruleSet?.hasBeenSaved && ruleSet.steps.length > 0;
  }, [ruleSets]);

  const selectRuleSet = useCallback((id: string | null) => {
    setSelectedRuleSetId(id);
  }, []);

  const changeTab = useCallback((tab: TabType) => {
    setActiveTab(tab);
  }, []);

  const updateFilter = useCallback((updates: Partial<FilterState>) => {
    setFilterState(prev => ({ ...prev, ...updates }));
  }, []);

  const getFilteredRuleSets = useCallback(() => {
    let filtered = [...ruleSets];
    
    if (filterState.searchQuery) {
      const query = filterState.searchQuery.toLowerCase();
      filtered = filtered.filter(rs => rs.name.toLowerCase().includes(query));
    }

    filtered.sort((a, b) => {
      if (filterState.sortBy === 'name') {
        return filterState.sortOrder === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      }
      return filterState.sortOrder === 'asc'
        ? a.updatedAt.getTime() - b.updatedAt.getTime()
        : b.updatedAt.getTime() - a.updatedAt.getTime();
    });

    return filtered;
  }, [ruleSets, filterState]);

  return {
    ruleSets,
    selectedRuleSet,
    selectedRuleSetId,
    activeTab,
    simulationResults,
    filterState,
    createRuleSet,
    updateRuleSetName,
    deleteRuleSet,
    addStep,
    removeStep,
    updateStepName,
    saveRuleSet,
    runSimulation,
    canEdit,
    canSimulate,
    selectRuleSet,
    changeTab,
    updateFilter,
    getFilteredRuleSets,
  };
}
