import { RuleSet } from '@/types/workflow';

export const defaultRuleSets: RuleSet[] = [
  {
    id: 'rs-001',
    name: 'Basic Support Flow',
    steps: [
      { id: 'step-1', name: 'Receive Ticket', order: 1 },
      { id: 'step-2', name: 'Categorize Issue', order: 2 },
      { id: 'step-3', name: 'Assign Agent', order: 3 },
      { id: 'step-4', name: 'Reply to Customer', order: 4 },
      { id: 'step-5', name: 'Close Ticket', order: 5 },
    ],
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    hasBeenSaved: true,
  },
  {
    id: 'rs-002',
    name: 'Escalation Process',
    steps: [
      { id: 'step-1', name: 'Initial Review', order: 1 },
      { id: 'step-2', name: 'Escalate to Senior', order: 2 },
      { id: 'step-3', name: 'Manager Approval', order: 3 },
      { id: 'step-4', name: 'Resolution', order: 4 },
    ],
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-22'),
    hasBeenSaved: true,
  },
  {
    id: 'rs-003',
    name: 'Refund Request',
    steps: [
      { id: 'step-1', name: 'Receive Request', order: 1 },
      { id: 'step-2', name: 'Verify Purchase', order: 2 },
      { id: 'step-3', name: 'Process Refund', order: 3 },
      { id: 'step-4', name: 'Confirm to Customer', order: 4 },
    ],
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-02-05'),
    hasBeenSaved: true,
  },
];
