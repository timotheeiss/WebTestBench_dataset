export interface WorkflowStep {
  id: string;
  name: string;
  order: number;
}

export interface RuleSet {
  id: string;
  name: string;
  steps: WorkflowStep[];
  createdAt: Date;
  updatedAt: Date;
  hasBeenSaved: boolean;
}

export interface SimulationResult {
  ruleSetId: string;
  ruleSetName: string;
  steps: WorkflowStep[];
  timestamp: Date;
  status: 'completed' | 'in-progress';
}

export type TabType = 'list' | 'editor' | 'simulation';

export interface FilterState {
  searchQuery: string;
  sortBy: 'name' | 'date';
  sortOrder: 'asc' | 'desc';
}
