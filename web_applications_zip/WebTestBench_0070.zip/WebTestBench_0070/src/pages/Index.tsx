import { useWorkflowStore } from '@/hooks/useWorkflowStore';
import { Header } from '@/components/workflow/Header';
import { TabNavigation } from '@/components/workflow/TabNavigation';
import { RuleSetList } from '@/components/workflow/RuleSetList';
import { StepEditor } from '@/components/workflow/StepEditor';
import { SimulationView } from '@/components/workflow/SimulationView';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const { toast } = useToast();
  const {
    selectedRuleSet,
    selectedRuleSetId,
    activeTab,
    simulationResults,
    filterState,
    createRuleSet,
    updateRuleSetName,
    deleteRuleSet,
    addStep,
    removeStep,
    updateStepName,
    saveRuleSet,
    runSimulation,
    canSimulate,
    selectRuleSet,
    changeTab,
    updateFilter,
    getFilteredRuleSets,
  } = useWorkflowStore();

  const handleEdit = (id: string) => {
    selectRuleSet(id);
    changeTab('editor');
  };

  const handleSimulate = (id: string) => {
    if (!canSimulate(id)) {
      toast({
        title: "Cannot run simulation",
        description: "Save the rule set with at least one step first.",
        variant: "destructive",
      });
      return;
    }
    selectRuleSet(id);
    const result = runSimulation(id);
    if (result) {
      toast({
        title: "Simulation started",
        description: `Running "${result.ruleSetName}" workflow...`,
      });
    }
  };

  const handleSave = (ruleSetId: string) => {
    const ruleSet = getFilteredRuleSets().find(rs => rs.id === ruleSetId);
    if (ruleSet && ruleSet.steps.length === 0) {
      toast({
        title: "Add steps first",
        description: "Add at least one step before saving.",
        variant: "destructive",
      });
      return;
    }
    saveRuleSet(ruleSetId);
    toast({
      title: "Rule set saved",
      description: "You can now run simulations with this rule set.",
    });
  };

  const handleDelete = (id: string) => {
    deleteRuleSet(id);
    toast({
      title: "Rule set deleted",
      description: "The rule set has been removed.",
    });
  };

  return (
    <div className="flex h-screen flex-col bg-background">
      <Header />
      <TabNavigation
        activeTab={activeTab}
        onTabChange={changeTab}
        hasSelection={!!selectedRuleSetId}
        canSimulate={selectedRuleSetId ? canSimulate(selectedRuleSetId) : false}
      />
      
      <main className="flex-1 overflow-hidden">
        {activeTab === 'list' && (
          <RuleSetList
            ruleSets={getFilteredRuleSets()}
            selectedId={selectedRuleSetId}
            filterState={filterState}
            onSelect={selectRuleSet}
            onCreate={createRuleSet}
            onDelete={handleDelete}
            onEdit={handleEdit}
            onSimulate={handleSimulate}
            onFilterChange={updateFilter}
            canSimulate={canSimulate}
          />
        )}
        
        {activeTab === 'editor' && (
          <StepEditor
            ruleSet={selectedRuleSet}
            onUpdateName={updateRuleSetName}
            onAddStep={addStep}
            onRemoveStep={removeStep}
            onUpdateStepName={updateStepName}
            onSave={handleSave}
            onSimulate={handleSimulate}
            canSimulate={selectedRuleSetId ? canSimulate(selectedRuleSetId) : false}
          />
        )}
        
        {activeTab === 'simulation' && (
          <SimulationView results={simulationResults} />
        )}
      </main>
    </div>
  );
};

export default Index;
