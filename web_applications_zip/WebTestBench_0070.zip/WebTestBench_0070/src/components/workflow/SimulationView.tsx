import { useState, useEffect } from 'react';
import { CheckCircle2, Circle, ArrowDown, Clock, FileText } from 'lucide-react';
import { SimulationResult } from '@/types/workflow';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface SimulationViewProps {
  results: SimulationResult[];
}

export function SimulationView({ results }: SimulationViewProps) {
  const [activeResult, setActiveResult] = useState<SimulationResult | null>(results[0] || null);
  const [simulatedStepIndex, setSimulatedStepIndex] = useState(-1);

  useEffect(() => {
    if (activeResult) {
      setSimulatedStepIndex(-1);
      const steps = activeResult.steps;
      
      const timer = setInterval(() => {
        setSimulatedStepIndex(prev => {
          if (prev >= steps.length - 1) {
            clearInterval(timer);
            return prev;
          }
          return prev + 1;
        });
      }, 800);

      return () => clearInterval(timer);
    }
  }, [activeResult]);

  const formatTimestamp = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (results.length === 0) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">No simulations run yet</p>
          <p className="text-sm text-muted-foreground/70 mt-1">
            Save a rule set and run a simulation to see results here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full">
      {/* Sidebar with history */}
      <div className="w-72 border-r border-border overflow-auto">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground">Simulation History</h3>
        </div>
        <div className="p-2">
          {results.map((result, index) => (
            <button
              key={`${result.ruleSetId}-${result.timestamp.getTime()}`}
              onClick={() => setActiveResult(result)}
              className={cn(
                "w-full text-left p-3 rounded-lg transition-colors mb-1",
                activeResult === result
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-muted text-foreground"
              )}
            >
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 flex-shrink-0" />
                <span className="font-medium truncate">{result.ruleSetName}</span>
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                {formatTimestamp(result.timestamp)}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main simulation view */}
      <div className="flex-1 overflow-auto p-6">
        {activeResult && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Simulating: {activeResult.ruleSetName}</span>
                <span className="text-sm font-normal text-muted-foreground">
                  {activeResult.steps.length} steps
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative">
                {/* Simulation query indicator */}
                <div className="mb-6 p-4 bg-accent/20 rounded-lg border border-accent/30 animate-fade-in">
                  <p className="text-sm text-accent-foreground font-medium">
                    📩 Sample Customer Query: "I need help with my order #12345"
                  </p>
                </div>

                {/* Steps flow */}
                <div className="space-y-1">
                  {activeResult.steps.map((step, index) => {
                    const isCompleted = index <= simulatedStepIndex;
                    const isCurrent = index === simulatedStepIndex;
                    
                    return (
                      <div key={step.id}>
                        <div
                          className={cn(
                            "flex items-center gap-4 p-4 rounded-lg transition-all duration-300",
                            isCompleted
                              ? "bg-success/10 border border-success/30"
                              : "bg-muted border border-border",
                            isCurrent && "ring-2 ring-success animate-pulse-soft"
                          )}
                        >
                          <div
                            className={cn(
                              "flex h-8 w-8 items-center justify-center rounded-full transition-all",
                              isCompleted
                                ? "bg-success text-success-foreground"
                                : "bg-muted-foreground/20 text-muted-foreground"
                            )}
                          >
                            {isCompleted ? (
                              <CheckCircle2 className="h-5 w-5" />
                            ) : (
                              <Circle className="h-5 w-5" />
                            )}
                          </div>
                          <div className="flex-1">
                            <p className={cn(
                              "font-medium transition-colors",
                              isCompleted ? "text-foreground" : "text-muted-foreground"
                            )}>
                              Step {step.order}: {step.name}
                            </p>
                            {isCurrent && (
                              <p className="text-sm text-success mt-1 animate-fade-in">
                                Processing...
                              </p>
                            )}
                            {isCompleted && index < simulatedStepIndex && (
                              <p className="text-sm text-muted-foreground mt-1">
                                Completed
                              </p>
                            )}
                          </div>
                        </div>
                        
                        {index < activeResult.steps.length - 1 && (
                          <div className="flex justify-center py-1">
                            <ArrowDown
                              className={cn(
                                "h-5 w-5 transition-colors",
                                index < simulatedStepIndex
                                  ? "text-success"
                                  : "text-muted-foreground/40"
                              )}
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Completion message */}
                {simulatedStepIndex >= activeResult.steps.length - 1 && (
                  <div className="mt-6 p-4 bg-success/10 rounded-lg border border-success/30 animate-fade-in">
                    <p className="text-success font-medium text-center">
                      ✅ Workflow simulation completed successfully!
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
