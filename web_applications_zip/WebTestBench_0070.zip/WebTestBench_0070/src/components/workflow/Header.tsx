import { Workflow } from 'lucide-react';

export function Header() {
  return (
    <header className="border-b border-border bg-card px-6 py-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
          <Workflow className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-foreground">Workflow Builder</h1>
          <p className="text-sm text-muted-foreground">Define and simulate customer service workflows</p>
        </div>
      </div>
    </header>
  );
}
