import { useState } from 'react';
import { Plus, Trash2, GripVertical, Save, Play, ArrowRight, AlertCircle } from 'lucide-react';
import { RuleSet } from '@/types/workflow';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

interface StepEditorProps {
  ruleSet: RuleSet | null;
  onUpdateName: (id: string, name: string) => void;
  onAddStep: (ruleSetId: string, stepName: string) => void;
  onRemoveStep: (ruleSetId: string, stepId: string) => void;
  onUpdateStepName: (ruleSetId: string, stepId: string, name: string) => void;
  onSave: (ruleSetId: string) => void;
  onSimulate: (ruleSetId: string) => void;
  canSimulate: boolean;
}

export function StepEditor({
  ruleSet,
  onUpdateName,
  onAddStep,
  onRemoveStep,
  onUpdateStepName,
  onSave,
  onSimulate,
  canSimulate,
}: StepEditorProps) {
  const [newStepName, setNewStepName] = useState('');

  if (!ruleSet) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">No rule set selected</p>
          <p className="text-sm text-muted-foreground/70 mt-1">Select or create a rule set to edit</p>
        </div>
      </div>
    );
  }

  const handleAddStep = () => {
    if (newStepName.trim()) {
      onAddStep(ruleSet.id, newStepName.trim());
      setNewStepName('');
    }
  };

  const handleSave = () => {
    onSave(ruleSet.id);
  };

  const handleSimulate = () => {
    if (canSimulate) {
      onSimulate(ruleSet.id);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border p-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Rule Set Name</label>
            <Input
              value={ruleSet.name}
              onChange={(e) => onUpdateName(ruleSet.id, e.target.value)}
              className="text-lg font-medium"
            />
          </div>
          <div className="flex items-center gap-2 pt-5">
            <Button onClick={handleSave} variant={ruleSet.hasBeenSaved ? "outline" : "default"}>
              <Save className="mr-2 h-4 w-4" />
              {ruleSet.hasBeenSaved ? 'Saved' : 'Save'}
            </Button>
            <Button
              onClick={handleSimulate}
              disabled={!canSimulate}
              variant="secondary"
              title={!canSimulate ? "Save the rule set with at least one step first" : "Run simulation"}
            >
              <Play className="mr-2 h-4 w-4" />
              Simulate
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {!ruleSet.hasBeenSaved && ruleSet.steps.length > 0 && (
          <Alert className="mb-4 border-warning/50 bg-warning/10">
            <AlertCircle className="h-4 w-4 text-warning" />
            <AlertDescription className="text-warning">
              Save your changes before running a simulation
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Workflow Steps</CardTitle>
          </CardHeader>
          <CardContent>
            {ruleSet.steps.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">
                No steps defined yet. Add your first step below.
              </p>
            ) : (
              <div className="space-y-2">
                {ruleSet.steps.map((step, index) => (
                  <div
                    key={step.id}
                    className="flex items-center gap-3 animate-slide-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <GripVertical className="h-4 w-4" />
                      <span className="text-sm font-medium w-6">{step.order}.</span>
                    </div>
                    <Input
                      value={step.name}
                      onChange={(e) => onUpdateStepName(ruleSet.id, step.id, e.target.value)}
                      className="flex-1"
                    />
                    {index < ruleSet.steps.length - 1 && (
                      <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRemoveStep(ruleSet.id, step.id)}
                      className="text-muted-foreground hover:text-destructive flex-shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="New step name..."
                  value={newStepName}
                  onChange={(e) => setNewStepName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddStep()}
                  className="flex-1"
                />
                <Button onClick={handleAddStep} disabled={!newStepName.trim()}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Step
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
