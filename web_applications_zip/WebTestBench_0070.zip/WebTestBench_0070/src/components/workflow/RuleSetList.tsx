import { useState } from 'react';
import { Plus, Search, ArrowUpDown, Trash2, Edit3, Play, CheckCircle2, Clock } from 'lucide-react';
import { RuleSet, FilterState } from '@/types/workflow';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

interface RuleSetListProps {
  ruleSets: RuleSet[];
  selectedId: string | null;
  filterState: FilterState;
  onSelect: (id: string) => void;
  onCreate: (name: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
  onSimulate: (id: string) => void;
  onFilterChange: (updates: Partial<FilterState>) => void;
  canSimulate: (id: string) => boolean;
}

export function RuleSetList({
  ruleSets,
  selectedId,
  filterState,
  onSelect,
  onCreate,
  onDelete,
  onEdit,
  onSimulate,
  onFilterChange,
  canSimulate,
}: RuleSetListProps) {
  const [newName, setNewName] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleCreate = () => {
    if (newName.trim()) {
      onCreate(newName.trim());
      setNewName('');
      setIsDialogOpen(false);
    }
  };

  const toggleSort = () => {
    if (filterState.sortBy === 'date') {
      onFilterChange({ sortBy: 'name', sortOrder: 'asc' });
    } else {
      onFilterChange({ sortBy: 'date', sortOrder: 'desc' });
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search rule sets..."
            value={filterState.searchQuery}
            onChange={(e) => onFilterChange({ searchQuery: e.target.value })}
            className="pl-10"
          />
        </div>
        <Button variant="outline" size="icon" onClick={toggleSort} title="Toggle sort">
          <ArrowUpDown className="h-4 w-4" />
        </Button>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Rule Set
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Rule Set</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <Input
                placeholder="Enter rule set name..."
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                autoFocus
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={!newName.trim()}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {ruleSets.length === 0 ? (
          <div className="flex h-full items-center justify-center">
            <div className="text-center">
              <p className="text-muted-foreground">No rule sets found</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Create your first rule set to get started</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {ruleSets.map((ruleSet, index) => (
              <Card
                key={ruleSet.id}
                className={cn(
                  "cursor-pointer transition-all hover:shadow-md animate-fade-in",
                  selectedId === ruleSet.id && "ring-2 ring-primary"
                )}
                style={{ animationDelay: `${index * 50}ms` }}
                onClick={() => onSelect(ruleSet.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-foreground truncate">{ruleSet.name}</h3>
                        {ruleSet.hasBeenSaved ? (
                          <CheckCircle2 className="h-4 w-4 text-success flex-shrink-0" />
                        ) : (
                          <Clock className="h-4 w-4 text-warning flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {ruleSet.steps.length} step{ruleSet.steps.length !== 1 ? 's' : ''} • Updated {formatDate(ruleSet.updatedAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 ml-3">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEdit(ruleSet.id);
                        }}
                        title="Edit"
                      >
                        <Edit3 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSimulate(ruleSet.id);
                        }}
                        disabled={!canSimulate(ruleSet.id)}
                        title={canSimulate(ruleSet.id) ? "Run simulation" : "Save rule set first"}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(ruleSet.id);
                        }}
                        className="text-muted-foreground hover:text-destructive"
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
