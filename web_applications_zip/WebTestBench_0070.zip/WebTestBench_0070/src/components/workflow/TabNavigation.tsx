import { List, Edit3, Play } from 'lucide-react';
import { TabType } from '@/types/workflow';
import { cn } from '@/lib/utils';

interface TabNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  hasSelection: boolean;
  canSimulate: boolean;
}

const tabs: { id: TabType; label: string; icon: typeof List }[] = [
  { id: 'list', label: 'Rule Sets', icon: List },
  { id: 'editor', label: 'Editor', icon: Edit3 },
  { id: 'simulation', label: 'Simulation', icon: Play },
];

export function TabNavigation({ activeTab, onTabChange, hasSelection, canSimulate }: TabNavigationProps) {
  const isTabEnabled = (tabId: TabType) => {
    if (tabId === 'list') return true;
    if (tabId === 'editor') return hasSelection;
    if (tabId === 'simulation') return true; // Always show simulation history
    return false;
  };

  return (
    <nav className="border-b border-border bg-card">
      <div className="flex gap-1 px-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const enabled = isTabEnabled(tab.id);
          
          return (
            <button
              key={tab.id}
              onClick={() => enabled && onTabChange(tab.id)}
              disabled={!enabled}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-sm font-medium transition-all relative",
                "border-b-2 -mb-[1px]",
                activeTab === tab.id
                  ? "border-primary text-primary"
                  : enabled
                  ? "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                  : "border-transparent text-muted-foreground/50 cursor-not-allowed"
              )}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
