import { useState, useCallback } from "react";
import { courseData, Pathway } from "@/data/courseData";
import CourseHeader from "@/components/CourseHeader";
import PathwaySelector from "@/components/PathwaySelector";
import StageSection from "@/components/StageSection";

const Index = () => {
  const [selectedPathways, setSelectedPathways] = useState<Set<Pathway>>(new Set());
  const [expandedTopics, setExpandedTopics] = useState<Set<string>>(new Set());

  const handleTogglePathway = useCallback((pathway: Pathway) => {
    setSelectedPathways(prev => {
      const next = new Set(prev);
      if (next.has(pathway)) {
        next.delete(pathway);
      } else {
        next.add(pathway);
      }
      return next;
    });
    // Note: expandedTopics state is preserved - we don't reset it
  }, []);

  const handleToggleExpand = useCallback((topicId: string) => {
    setExpandedTopics(prev => {
      const next = new Set(prev);
      if (next.has(topicId)) {
        next.delete(topicId);
      } else {
        next.add(topicId);
      }
      return next;
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-12 md:py-16">
        <CourseHeader />
        
        <PathwaySelector 
          selectedPathways={selectedPathways}
          onTogglePathway={handleTogglePathway}
        />
        
        <div className="space-y-2">
          {courseData.map((stage) => (
            <StageSection
              key={stage.id}
              stage={stage}
              selectedPathways={selectedPathways}
              expandedTopics={expandedTopics}
              onToggleExpand={handleToggleExpand}
            />
          ))}
        </div>
        
        <footer className="mt-16 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>Course Outline Viewer • Select pathways to highlight relevant content</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
