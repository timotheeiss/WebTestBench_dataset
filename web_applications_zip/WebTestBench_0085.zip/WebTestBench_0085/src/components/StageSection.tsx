import { Stage, Pathway } from "@/data/courseData";
import TopicCard from "./TopicCard";

interface StageSectionProps {
  stage: Stage;
  selectedPathways: Set<Pathway>;
  expandedTopics: Set<string>;
  onToggleExpand: (topicId: string) => void;
}

const stageColors: Record<number, string> = {
  1: "bg-stage-1",
  2: "bg-stage-2",
  3: "bg-stage-3",
  4: "bg-stage-4",
  5: "bg-stage-5",
};

const StageSection = ({ 
  stage, 
  selectedPathways, 
  expandedTopics, 
  onToggleExpand 
}: StageSectionProps) => {
  // Check if any topic in this stage is highlighted
  const hasHighlightedTopics = stage.topics.some(topic => 
    topic.pathways.some(p => selectedPathways.has(p))
  );

  return (
    <div className={`mb-8 animate-fade-in ${hasHighlightedTopics ? '' : selectedPathways.size > 0 ? 'opacity-50' : ''}`}>
      <div className="flex items-center gap-4 mb-5">
        <div className={`
          w-12 h-12 rounded-xl flex items-center justify-center font-display font-bold text-white text-lg
          ${stageColors[stage.id] || 'bg-primary'}
        `}>
          {stage.id}
        </div>
        <div>
          <h3 className="font-display text-xl font-semibold text-foreground">
            {stage.title}
          </h3>
          <p className="text-sm text-muted-foreground">{stage.description}</p>
        </div>
      </div>
      
      <div className="space-y-3 ml-0 md:ml-16">
        {stage.topics.map((topic) => (
          <TopicCard
            key={topic.id}
            topic={topic}
            stageNumber={stage.id}
            selectedPathways={selectedPathways}
            expandedTopics={expandedTopics}
            onToggleExpand={onToggleExpand}
          />
        ))}
      </div>
    </div>
  );
};

export default StageSection;
