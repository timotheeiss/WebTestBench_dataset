import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Topic, Pathway, Resource } from "@/data/courseData";
import { 
  ChevronDown, 
  Clock, 
  Target, 
  Video, 
  FileText, 
  Dumbbell, 
  BookOpen,
  ExternalLink 
} from "lucide-react";

interface TopicCardProps {
  topic: Topic;
  stageNumber: number;
  selectedPathways: Set<Pathway>;
  expandedTopics: Set<string>;
  onToggleExpand: (topicId: string) => void;
}

const resourceIcons = {
  video: Video,
  article: FileText,
  exercise: Dumbbell,
  book: BookOpen,
};

const TopicCard = ({ 
  topic, 
  stageNumber, 
  selectedPathways, 
  expandedTopics,
  onToggleExpand 
}: TopicCardProps) => {
  const isExpanded = expandedTopics.has(topic.id);
  
  // Calculate which pathways this topic is highlighted for
  const highlightedPathways = topic.pathways.filter(p => selectedPathways.has(p));
  const isHighlighted = highlightedPathways.length > 0;
  
  // Build highlight classes based on active pathways
  const highlightClasses = highlightedPathways
    .map(p => `highlight-${p}`)
    .join(' ');

  return (
    <div 
      className={`
        bg-card rounded-lg border transition-all duration-300
        ${highlightClasses}
        ${isHighlighted ? 'border-l-0 shadow-md' : 'hover:shadow-sm'}
      `}
    >
      <button
        onClick={() => onToggleExpand(topic.id)}
        className="w-full p-5 text-left focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary/20 rounded-lg"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="text-xs font-medium text-muted-foreground">
                {stageNumber}.{topic.id.split('-')[1]}
              </span>
              <h4 className="font-semibold text-foreground">{topic.name}</h4>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-3">
              {topic.pathways.map((pathway) => (
                <Badge 
                  key={pathway} 
                  variant="outline"
                  className={`text-xs capitalize
                    ${pathway === 'beginner' ? 'pathway-badge-beginner' : ''}
                    ${pathway === 'intermediate' ? 'pathway-badge-intermediate' : ''}
                    ${pathway === 'advanced' ? 'pathway-badge-advanced' : ''}
                  `}
                >
                  {pathway}
                </Badge>
              ))}
            </div>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {topic.duration}
              </span>
              <span className="flex items-center gap-1">
                <Target className="w-4 h-4" />
                {topic.objectives.length} objectives
              </span>
            </div>
          </div>
          
          <ChevronDown 
            className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${
              isExpanded ? 'rotate-180' : ''
            }`}
          />
        </div>
      </button>
      
      {isExpanded && (
        <div className="px-5 pb-5 animate-fade-in">
          <div className="border-t pt-4 mt-1">
            {/* Objectives */}
            <div className="mb-5">
              <h5 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <Target className="w-4 h-4 text-primary" />
                Learning Objectives
              </h5>
              <ul className="space-y-2">
                {topic.objectives.map((objective, index) => (
                  <li 
                    key={index}
                    className="text-sm text-muted-foreground flex items-start gap-2"
                  >
                    <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      {index + 1}
                    </span>
                    {objective}
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Resources */}
            <div>
              <h5 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-primary" />
                Supplementary Resources
              </h5>
              <div className="grid gap-2">
                {topic.resources.map((resource, index) => {
                  const ResourceIcon = resourceIcons[resource.type];
                  return (
                    <a
                      key={index}
                      href={resource.url}
                      className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-md bg-background">
                          <ResourceIcon className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                            {resource.title}
                          </span>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="capitalize">{resource.type}</span>
                            {resource.duration && (
                              <>
                                <span>•</span>
                                <span>{resource.duration}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TopicCard;
