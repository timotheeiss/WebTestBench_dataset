import { BookMarked, Users, Trophy } from "lucide-react";

const CourseHeader = () => {
  return (
    <header className="text-center mb-12">
      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/5 text-primary text-sm font-medium mb-6">
        <BookMarked className="w-4 h-4" />
        Complete Learning Path
      </div>
      
      <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
        Programming Fundamentals
        <span className="block text-2xl md:text-3xl font-semibold text-muted-foreground mt-2">
          From Zero to Hero
        </span>
      </h1>
      
      <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
        A comprehensive course designed to take you from complete beginner to professional developer. 
        Choose your learning pathway and progress at your own pace.
      </p>
      
      <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-secondary">
            <BookMarked className="w-4 h-4 text-primary" />
          </div>
          <span>5 Stages</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-secondary">
            <Users className="w-4 h-4 text-primary" />
          </div>
          <span>15 Topics</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-secondary">
            <Trophy className="w-4 h-4 text-primary" />
          </div>
          <span>45+ Hours</span>
        </div>
      </div>
    </header>
  );
};

export default CourseHeader;
