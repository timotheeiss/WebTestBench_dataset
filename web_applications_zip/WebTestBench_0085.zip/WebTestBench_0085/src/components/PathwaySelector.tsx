import { Badge } from "@/components/ui/badge";
import { pathwayInfo, Pathway } from "@/data/courseData";
import { GraduationCap, BookOpen, Rocket } from "lucide-react";

interface PathwaySelectorProps {
  selectedPathways: Set<Pathway>;
  onTogglePathway: (pathway: Pathway) => void;
}

const pathwayIcons = {
  beginner: GraduationCap,
  intermediate: BookOpen,
  advanced: Rocket,
};

const PathwaySelector = ({ selectedPathways, onTogglePathway }: PathwaySelectorProps) => {
  return (
    <div className="bg-card rounded-xl shadow-sm border p-6 mb-8">
      <h2 className="font-display text-lg font-semibold mb-4">Select Your Learning Pathways</h2>
      <p className="text-muted-foreground text-sm mb-6">
        Choose one or more pathways to highlight relevant content. Selections are preserved when switching.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(Object.keys(pathwayInfo) as Pathway[]).map((pathway) => {
          const info = pathwayInfo[pathway];
          const Icon = pathwayIcons[pathway];
          const isSelected = selectedPathways.has(pathway);
          
          return (
            <button
              key={pathway}
              onClick={() => onTogglePathway(pathway)}
              className={`
                relative p-5 rounded-lg border-2 text-left transition-all duration-200
                hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2
                ${pathway === 'beginner' ? 'focus:ring-pathway-beginner' : ''}
                ${pathway === 'intermediate' ? 'focus:ring-pathway-intermediate' : ''}
                ${pathway === 'advanced' ? 'focus:ring-pathway-advanced' : ''}
                ${isSelected ? (
                  pathway === 'beginner' 
                    ? 'bg-pathway-beginner-light border-pathway-beginner shadow-sm' 
                    : pathway === 'intermediate'
                    ? 'bg-pathway-intermediate-light border-pathway-intermediate shadow-sm'
                    : 'bg-pathway-advanced-light border-pathway-advanced shadow-sm'
                ) : 'bg-card border-border hover:border-muted-foreground/30'}
              `}
            >
              <div className="flex items-start gap-3">
                <div className={`
                  p-2 rounded-lg
                  ${pathway === 'beginner' ? 'bg-pathway-beginner/10 text-pathway-beginner' : ''}
                  ${pathway === 'intermediate' ? 'bg-pathway-intermediate/10 text-pathway-intermediate' : ''}
                  ${pathway === 'advanced' ? 'bg-pathway-advanced/10 text-pathway-advanced' : ''}
                `}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold">{info.name}</span>
                    {isSelected && (
                      <Badge variant="secondary" className={`text-xs
                        ${pathway === 'beginner' ? 'bg-pathway-beginner text-white' : ''}
                        ${pathway === 'intermediate' ? 'bg-pathway-intermediate text-white' : ''}
                        ${pathway === 'advanced' ? 'bg-pathway-advanced text-white' : ''}
                      `}>
                        Active
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{info.description}</p>
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span>{info.topicsCount} topics</span>
                    <span>~{info.totalDuration}</span>
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default PathwaySelector;
