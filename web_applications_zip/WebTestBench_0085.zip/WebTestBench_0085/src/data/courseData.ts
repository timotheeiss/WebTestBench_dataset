export type Pathway = 'beginner' | 'intermediate' | 'advanced';

export interface Resource {
  title: string;
  type: 'video' | 'article' | 'exercise' | 'book';
  url: string;
  duration?: string;
}

export interface Topic {
  id: string;
  name: string;
  objectives: string[];
  duration: string;
  pathways: Pathway[];
  resources: Resource[];
}

export interface Stage {
  id: number;
  title: string;
  description: string;
  topics: Topic[];
}

export const courseData: Stage[] = [
  {
    id: 1,
    title: "Foundations",
    description: "Build a solid understanding of core concepts",
    topics: [
      {
        id: "1-1",
        name: "Introduction to Programming Concepts",
        objectives: [
          "Understand what programming is and why it matters",
          "Learn about different programming paradigms",
          "Set up your development environment"
        ],
        duration: "2 hours",
        pathways: ['beginner'],
        resources: [
          { title: "What is Programming?", type: "video", url: "#", duration: "15 min" },
          { title: "Setting Up VS Code", type: "article", url: "#" },
          { title: "Hello World Exercise", type: "exercise", url: "#", duration: "30 min" }
        ]
      },
      {
        id: "1-2",
        name: "Variables and Data Types",
        objectives: [
          "Declare and initialize variables",
          "Understand primitive and complex data types",
          "Practice type conversion and coercion"
        ],
        duration: "3 hours",
        pathways: ['beginner', 'intermediate'],
        resources: [
          { title: "Variables Deep Dive", type: "video", url: "#", duration: "25 min" },
          { title: "Type Systems Explained", type: "article", url: "#" },
          { title: "Data Type Challenges", type: "exercise", url: "#", duration: "45 min" }
        ]
      },
      {
        id: "1-3",
        name: "Control Flow",
        objectives: [
          "Write conditional statements (if/else, switch)",
          "Implement loops (for, while, do-while)",
          "Use break and continue effectively"
        ],
        duration: "4 hours",
        pathways: ['beginner', 'intermediate'],
        resources: [
          { title: "Mastering Conditionals", type: "video", url: "#", duration: "20 min" },
          { title: "Loop Patterns", type: "article", url: "#" },
          { title: "Control Flow Puzzles", type: "exercise", url: "#", duration: "1 hour" }
        ]
      }
    ]
  },
  {
    id: 2,
    title: "Core Development",
    description: "Master essential programming techniques",
    topics: [
      {
        id: "2-1",
        name: "Functions and Scope",
        objectives: [
          "Define and invoke functions",
          "Understand scope and closures",
          "Work with higher-order functions"
        ],
        duration: "4 hours",
        pathways: ['beginner', 'intermediate'],
        resources: [
          { title: "Functions Fundamentals", type: "video", url: "#", duration: "30 min" },
          { title: "Closures Demystified", type: "article", url: "#" },
          { title: "Functional Programming Book", type: "book", url: "#" }
        ]
      },
      {
        id: "2-2",
        name: "Object-Oriented Programming",
        objectives: [
          "Create classes and objects",
          "Implement inheritance and polymorphism",
          "Apply encapsulation principles"
        ],
        duration: "6 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "OOP Masterclass", type: "video", url: "#", duration: "45 min" },
          { title: "Design Patterns Introduction", type: "article", url: "#" },
          { title: "OOP Project", type: "exercise", url: "#", duration: "2 hours" }
        ]
      },
      {
        id: "2-3",
        name: "Error Handling",
        objectives: [
          "Use try-catch blocks effectively",
          "Create custom error types",
          "Implement graceful error recovery"
        ],
        duration: "3 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "Error Handling Best Practices", type: "video", url: "#", duration: "20 min" },
          { title: "Building Resilient Apps", type: "article", url: "#" },
          { title: "Debug Challenge", type: "exercise", url: "#", duration: "45 min" }
        ]
      }
    ]
  },
  {
    id: 3,
    title: "Data Structures",
    description: "Learn to organize and manipulate data efficiently",
    topics: [
      {
        id: "3-1",
        name: "Arrays and Lists",
        objectives: [
          "Perform CRUD operations on arrays",
          "Master array methods (map, filter, reduce)",
          "Understand time complexity basics"
        ],
        duration: "4 hours",
        pathways: ['beginner', 'intermediate', 'advanced'],
        resources: [
          { title: "Array Methods Mastery", type: "video", url: "#", duration: "35 min" },
          { title: "Functional Array Operations", type: "article", url: "#" },
          { title: "Array Manipulation Exercises", type: "exercise", url: "#", duration: "1 hour" }
        ]
      },
      {
        id: "3-2",
        name: "Hash Maps and Sets",
        objectives: [
          "Understand hashing concepts",
          "Implement and use Maps and Sets",
          "Solve problems using hash-based structures"
        ],
        duration: "3 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "Hash Tables Explained", type: "video", url: "#", duration: "25 min" },
          { title: "When to Use Maps vs Objects", type: "article", url: "#" },
          { title: "LeetCode Hash Problems", type: "exercise", url: "#", duration: "2 hours" }
        ]
      },
      {
        id: "3-3",
        name: "Trees and Graphs",
        objectives: [
          "Implement binary trees and traversals",
          "Understand graph representations",
          "Apply BFS and DFS algorithms"
        ],
        duration: "8 hours",
        pathways: ['advanced'],
        resources: [
          { title: "Tree Data Structures", type: "video", url: "#", duration: "50 min" },
          { title: "Graph Theory Basics", type: "book", url: "#" },
          { title: "Tree & Graph Challenges", type: "exercise", url: "#", duration: "3 hours" }
        ]
      }
    ]
  },
  {
    id: 4,
    title: "Algorithms",
    description: "Solve problems with proven techniques",
    topics: [
      {
        id: "4-1",
        name: "Searching Algorithms",
        objectives: [
          "Implement linear and binary search",
          "Understand search complexity",
          "Apply search in real-world scenarios"
        ],
        duration: "3 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "Search Algorithms Visualized", type: "video", url: "#", duration: "20 min" },
          { title: "Binary Search Variations", type: "article", url: "#" },
          { title: "Search Problems Set", type: "exercise", url: "#", duration: "1.5 hours" }
        ]
      },
      {
        id: "4-2",
        name: "Sorting Algorithms",
        objectives: [
          "Implement bubble, merge, and quick sort",
          "Analyze and compare sorting efficiency",
          "Choose the right sort for the problem"
        ],
        duration: "5 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "Sorting Visualizations", type: "video", url: "#", duration: "30 min" },
          { title: "Sorting Algorithm Comparison", type: "article", url: "#" },
          { title: "Sorting Challenges", type: "exercise", url: "#", duration: "2 hours" }
        ]
      },
      {
        id: "4-3",
        name: "Dynamic Programming",
        objectives: [
          "Identify DP problem patterns",
          "Apply memoization and tabulation",
          "Solve classic DP problems"
        ],
        duration: "10 hours",
        pathways: ['advanced'],
        resources: [
          { title: "DP Fundamentals", type: "video", url: "#", duration: "1 hour" },
          { title: "DP Problem Patterns", type: "book", url: "#" },
          { title: "DP Problem Set", type: "exercise", url: "#", duration: "4 hours" }
        ]
      }
    ]
  },
  {
    id: 5,
    title: "Professional Skills",
    description: "Prepare for real-world development",
    topics: [
      {
        id: "5-1",
        name: "Version Control with Git",
        objectives: [
          "Master Git fundamentals",
          "Work with branches and merging",
          "Collaborate using GitHub workflows"
        ],
        duration: "4 hours",
        pathways: ['beginner', 'intermediate', 'advanced'],
        resources: [
          { title: "Git Essentials", type: "video", url: "#", duration: "40 min" },
          { title: "GitHub Collaboration Guide", type: "article", url: "#" },
          { title: "Git Simulation Exercise", type: "exercise", url: "#", duration: "1 hour" }
        ]
      },
      {
        id: "5-2",
        name: "Testing and Debugging",
        objectives: [
          "Write unit and integration tests",
          "Use debugging tools effectively",
          "Practice test-driven development"
        ],
        duration: "5 hours",
        pathways: ['intermediate', 'advanced'],
        resources: [
          { title: "Testing Fundamentals", type: "video", url: "#", duration: "35 min" },
          { title: "TDD Workflow Guide", type: "article", url: "#" },
          { title: "Test Writing Exercises", type: "exercise", url: "#", duration: "2 hours" }
        ]
      },
      {
        id: "5-3",
        name: "System Design Basics",
        objectives: [
          "Understand scalability concepts",
          "Design simple distributed systems",
          "Apply architectural patterns"
        ],
        duration: "8 hours",
        pathways: ['advanced'],
        resources: [
          { title: "System Design Primer", type: "video", url: "#", duration: "1 hour" },
          { title: "Designing Data-Intensive Apps", type: "book", url: "#" },
          { title: "Design a URL Shortener", type: "exercise", url: "#", duration: "3 hours" }
        ]
      }
    ]
  }
];

export const pathwayInfo = {
  beginner: {
    name: "Beginner",
    description: "Start your programming journey with fundamental concepts",
    totalDuration: "17 hours",
    topicsCount: 6
  },
  intermediate: {
    name: "Intermediate",
    description: "Deepen your knowledge with advanced techniques",
    totalDuration: "32 hours",
    topicsCount: 10
  },
  advanced: {
    name: "Advanced",
    description: "Master complex algorithms and system design",
    totalDuration: "45 hours",
    topicsCount: 11
  }
};
