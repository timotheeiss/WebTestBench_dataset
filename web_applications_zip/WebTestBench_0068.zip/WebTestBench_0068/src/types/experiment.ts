export type EquipmentType = 'bunsen-burner' | 'beaker' | 'thermometer' | 'condenser' | 'flask' | 'stirrer';

export interface Equipment {
  id: string;
  type: EquipmentType;
  name: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  params: EquipmentParams;
}

export interface EquipmentParams {
  // Bunsen Burner
  flameIntensity?: number; // 0-100
  
  // Beaker/Flask
  liquidVolume?: number; // 0-1000 ml
  liquidTemp?: number; // celsius
  liquidColor?: string;
  
  // Thermometer
  connectedTo?: string; // equipment id
  
  // Condenser
  coolingRate?: number; // 0-100
  
  // Stirrer
  speed?: number; // rpm 0-1000
  isActive?: boolean;
}

export interface ExperimentScene {
  id: string;
  name: string;
  equipment: Equipment[];
  createdAt: number;
  thumbnail?: string;
}

export interface ExperimentInstance {
  id: string;
  name: string;
  scene: ExperimentScene;
  isRunning: boolean;
  elapsedTime: number;
  simulationData: SimulationData;
}

export interface SimulationData {
  temperatures: number[];
  pressures: number[];
  volumes: number[];
  timestamp: number[];
}

export interface EquipmentDefinition {
  type: EquipmentType;
  name: string;
  description: string;
  icon: string;
  defaultParams: EquipmentParams;
}
