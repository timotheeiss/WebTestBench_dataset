import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Equipment, ExperimentScene, ExperimentInstance, SimulationData } from '@/types/experiment';
import { defaultScenes } from '@/data/equipment';

interface LabState {
  // Navigation
  activeTab: 'editor' | 'comparison' | 'history';
  setActiveTab: (tab: 'editor' | 'comparison' | 'history') => void;

  // Editor State
  currentScene: ExperimentScene;
  selectedEquipmentId: string | null;
  isSimulating: boolean;
  
  setCurrentScene: (scene: ExperimentScene) => void;
  addEquipment: (equipment: Equipment) => void;
  updateEquipment: (id: string, updates: Partial<Equipment>) => void;
  removeEquipment: (id: string) => void;
  selectEquipment: (id: string | null) => void;
  setIsSimulating: (value: boolean) => void;
  
  // Comparison Instances
  instances: ExperimentInstance[];
  addInstance: (scene: ExperimentScene) => void;
  removeInstance: (id: string) => void;
  toggleInstance: (id: string) => void;
  updateInstanceData: (id: string, data: Partial<SimulationData>) => void;
  updateInstanceTime: (id: string, time: number) => void;
  
  // Historical Scenes
  savedScenes: ExperimentScene[];
  saveCurrentScene: (name: string) => void;
  loadScene: (id: string) => void;
  deleteScene: (id: string) => void;
}

const createEmptyScene = (): ExperimentScene => ({
  id: uuidv4(),
  name: 'New Experiment',
  equipment: [],
  createdAt: Date.now(),
});

const createEmptySimulationData = (): SimulationData => ({
  temperatures: [],
  pressures: [],
  volumes: [],
  timestamp: [],
});

export const useLabStore = create<LabState>((set, get) => ({
  // Navigation
  activeTab: 'editor',
  setActiveTab: (tab) => set({ activeTab: tab }),

  // Editor State
  currentScene: defaultScenes[0],
  selectedEquipmentId: null,
  isSimulating: false,

  setCurrentScene: (scene) => set({ currentScene: scene, selectedEquipmentId: null }),
  
  addEquipment: (equipment) =>
    set((state) => ({
      currentScene: {
        ...state.currentScene,
        equipment: [...state.currentScene.equipment, equipment],
      },
    })),

  updateEquipment: (id, updates) =>
    set((state) => {
      const updatedEquipment = state.currentScene.equipment.map((eq) =>
        eq.id === id ? { ...eq, ...updates } : eq
      );
      const updatedScene = { ...state.currentScene, equipment: updatedEquipment };
      
      // Sync with running instances
      const updatedInstances = state.instances.map((inst) =>
        inst.scene.id === state.currentScene.id
          ? { ...inst, scene: updatedScene }
          : inst
      );
      
      return {
        currentScene: updatedScene,
        instances: updatedInstances,
      };
    }),

  removeEquipment: (id) =>
    set((state) => ({
      currentScene: {
        ...state.currentScene,
        equipment: state.currentScene.equipment.filter((eq) => eq.id !== id),
      },
      selectedEquipmentId: state.selectedEquipmentId === id ? null : state.selectedEquipmentId,
    })),

  selectEquipment: (id) => set({ selectedEquipmentId: id }),
  
  setIsSimulating: (value) => set({ isSimulating: value }),

  // Comparison Instances
  instances: [],
  
  addInstance: (scene) =>
    set((state) => ({
      instances: [
        ...state.instances,
        {
          id: uuidv4(),
          name: `${scene.name} #${state.instances.filter((i) => i.scene.id === scene.id).length + 1}`,
          scene: JSON.parse(JSON.stringify(scene)),
          isRunning: false,
          elapsedTime: 0,
          simulationData: createEmptySimulationData(),
        },
      ],
    })),

  removeInstance: (id) =>
    set((state) => ({
      instances: state.instances.filter((inst) => inst.id !== id),
    })),

  toggleInstance: (id) =>
    set((state) => ({
      instances: state.instances.map((inst) =>
        inst.id === id ? { ...inst, isRunning: !inst.isRunning } : inst
      ),
    })),

  updateInstanceData: (id, data) =>
    set((state) => ({
      instances: state.instances.map((inst) =>
        inst.id === id
          ? { ...inst, simulationData: { ...inst.simulationData, ...data } }
          : inst
      ),
    })),

  updateInstanceTime: (id, time) =>
    set((state) => ({
      instances: state.instances.map((inst) =>
        inst.id === id ? { ...inst, elapsedTime: time } : inst
      ),
    })),

  // Historical Scenes
  savedScenes: defaultScenes,
  
  saveCurrentScene: (name) =>
    set((state) => {
      const newScene: ExperimentScene = {
        ...state.currentScene,
        id: uuidv4(),
        name,
        createdAt: Date.now(),
      };
      return {
        savedScenes: [newScene, ...state.savedScenes],
      };
    }),

  loadScene: (id) => {
    const scene = get().savedScenes.find((s) => s.id === id);
    if (scene) {
      set({
        currentScene: JSON.parse(JSON.stringify(scene)),
        activeTab: 'editor',
      });
    }
  },

  deleteScene: (id) =>
    set((state) => ({
      savedScenes: state.savedScenes.filter((s) => s.id !== id),
    })),
}));
