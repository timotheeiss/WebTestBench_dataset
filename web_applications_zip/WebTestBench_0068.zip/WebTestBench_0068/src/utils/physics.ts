import { Equipment } from '@/types/experiment';

const HEAT_TRANSFER_RATE = 0.15;
const AMBIENT_TEMP = 22;
const COOLING_FACTOR = 0.02;
const MAX_TEMP = 100;

export function calculateHeatTransfer(
  equipment: Equipment[],
  deltaTime: number
): Equipment[] {
  const updatedEquipment = [...equipment];
  
  // Find heat sources (burners) and their intensities
  const burners = updatedEquipment.filter((eq) => eq.type === 'bunsen-burner');
  
  // Find containers (beakers, flasks)
  const containers = updatedEquipment.filter(
    (eq) => eq.type === 'beaker' || eq.type === 'flask'
  );
  
  // Calculate heat transfer for each container
  containers.forEach((container) => {
    let heatInput = 0;
    
    // Check if container is above a burner (within range)
    burners.forEach((burner) => {
      const dx = Math.abs(container.x - burner.x);
      const dy = container.y - burner.y;
      
      // Container should be above burner (negative dy) and within horizontal range
      if (dy < 0 && dy > -200 && dx < 80) {
        const distance = Math.sqrt(dx * dx + dy * dy);
        const intensity = (burner.params.flameIntensity || 0) / 100;
        const distanceFactor = Math.max(0, 1 - distance / 200);
        heatInput += intensity * distanceFactor * HEAT_TRANSFER_RATE * deltaTime;
      }
    });
    
    // Apply stirrer effect (faster heating when stirred)
    const stirrers = updatedEquipment.filter((eq) => eq.type === 'stirrer');
    stirrers.forEach((stirrer) => {
      const dx = Math.abs(container.x - stirrer.x);
      const dy = container.y - stirrer.y;
      
      if (dy < 0 && dy > -150 && dx < 50 && stirrer.params.isActive) {
        const stirFactor = (stirrer.params.speed || 0) / 1000;
        heatInput *= 1 + stirFactor * 0.3;
      }
    });
    
    // Apply condenser cooling effect
    const condensers = updatedEquipment.filter((eq) => eq.type === 'condenser');
    condensers.forEach((condenser) => {
      const distance = Math.sqrt(
        Math.pow(container.x - condenser.x, 2) + Math.pow(container.y - condenser.y, 2)
      );
      
      if (distance < 200) {
        const coolingRate = (condenser.params.coolingRate || 0) / 100;
        const distanceFactor = Math.max(0, 1 - distance / 200);
        heatInput -= coolingRate * distanceFactor * COOLING_FACTOR * deltaTime;
      }
    });
    
    // Calculate new temperature
    const currentTemp = container.params.liquidTemp || AMBIENT_TEMP;
    const ambientCooling = (currentTemp - AMBIENT_TEMP) * COOLING_FACTOR * deltaTime * 0.1;
    let newTemp = currentTemp + heatInput - ambientCooling;
    
    // Clamp temperature
    newTemp = Math.max(AMBIENT_TEMP - 10, Math.min(MAX_TEMP, newTemp));
    
    // Update container
    const containerIndex = updatedEquipment.findIndex((eq) => eq.id === container.id);
    if (containerIndex !== -1) {
      updatedEquipment[containerIndex] = {
        ...container,
        params: {
          ...container.params,
          liquidTemp: Math.round(newTemp * 10) / 10,
        },
      };
    }
  });
  
  return updatedEquipment;
}

export function calculateBubbleIntensity(temp: number): number {
  if (temp < 50) return 0;
  if (temp >= 100) return 1;
  return (temp - 50) / 50;
}

export function calculateEvaporationRate(temp: number, volume: number): number {
  if (temp < 60) return 0;
  const rate = ((temp - 60) / 40) * 0.5;
  return Math.min(rate, volume * 0.01);
}

export function interpolateColor(temp: number): string {
  // Cold (blue) to hot (red) gradient
  const t = Math.min(1, Math.max(0, (temp - 20) / 80));
  
  if (t < 0.5) {
    // Blue to yellow
    const r = Math.round(0 + t * 2 * 255);
    const g = Math.round(212 + t * 2 * 43);
    const b = Math.round(255 - t * 2 * 155);
    return `rgb(${r}, ${g}, ${b})`;
  } else {
    // Yellow to red
    const t2 = (t - 0.5) * 2;
    const r = Math.round(255);
    const g = Math.round(255 - t2 * 155);
    const b = Math.round(100 - t2 * 100);
    return `rgb(${r}, ${g}, ${b})`;
  }
}
