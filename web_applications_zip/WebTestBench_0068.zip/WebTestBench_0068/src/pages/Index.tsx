import { useLabStore } from '@/store/labStore';
import { Navigation } from '@/components/lab/Navigation';
import { ExperimentEditor } from '@/components/lab/ExperimentEditor';
import { ComparisonView } from '@/components/lab/ComparisonView';
import { HistoryView } from '@/components/lab/HistoryView';
import { AnimatePresence, motion } from 'framer-motion';

const Index = () => {
  const activeTab = useLabStore((state) => state.activeTab);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />
      
      <main className="flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {activeTab === 'editor' && <ExperimentEditor />}
            {activeTab === 'comparison' && <ComparisonView />}
            {activeTab === 'history' && <HistoryView />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Index;
