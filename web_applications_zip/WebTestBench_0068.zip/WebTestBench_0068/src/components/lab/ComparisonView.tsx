import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { Button } from '@/components/ui/button';
import { Play, Pause, Trash2, Plus } from 'lucide-react';
import { calculateHeatTransfer } from '@/utils/physics';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

export function ComparisonView() {
  const instances = useLabStore((state) => state.instances);
  const currentScene = useLabStore((state) => state.currentScene);
  const addInstance = useLabStore((state) => state.addInstance);
  const removeInstance = useLabStore((state) => state.removeInstance);
  const toggleInstance = useLabStore((state) => state.toggleInstance);
  const updateInstanceTime = useLabStore((state) => state.updateInstanceTime);
  const updateInstanceData = useLabStore((state) => state.updateInstanceData);

  // Simulation loop for all running instances
  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);

  useEffect(() => {
    const runningInstances = instances.filter((i) => i.isRunning);
    if (runningInstances.length === 0) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    const simulate = (timestamp: number) => {
      if (lastTimeRef.current === 0) {
        lastTimeRef.current = timestamp;
      }

      const deltaTime = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;

      instances.forEach((instance) => {
        if (!instance.isRunning) return;

        // Update elapsed time
        const newTime = instance.elapsedTime + deltaTime;
        updateInstanceTime(instance.id, newTime);

        // Calculate physics for this instance
        const updatedEquipment = calculateHeatTransfer(instance.scene.equipment, deltaTime);

        // Extract temperature data for charts
        const avgTemp =
          updatedEquipment
            .filter((eq) => eq.type === 'beaker' || eq.type === 'flask')
            .reduce((sum, eq) => sum + (eq.params.liquidTemp || 25), 0) /
          Math.max(
            1,
            updatedEquipment.filter((eq) => eq.type === 'beaker' || eq.type === 'flask').length
          );

        updateInstanceData(instance.id, {
          temperatures: [...instance.simulationData.temperatures.slice(-50), avgTemp],
          timestamp: [...instance.simulationData.timestamp.slice(-50), newTime],
        });
      });

      animationRef.current = requestAnimationFrame(simulate);
    };

    lastTimeRef.current = 0;
    animationRef.current = requestAnimationFrame(simulate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [instances, updateInstanceTime, updateInstanceData]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const chartColors = ['#00d4ff', '#f59e0b', '#22c55e', '#a855f7', '#ef4444'];

  return (
    <div className="h-full p-4">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel p-4 mb-4 flex items-center justify-between"
      >
        <div>
          <h2 className="text-lg font-semibold">Multi-Instance Comparison</h2>
          <p className="text-sm text-muted-foreground">
            Run experiments side by side and compare results
          </p>
        </div>
        <Button onClick={() => addInstance(currentScene)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Current Scene
        </Button>
      </motion.div>

      {instances.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-panel h-[calc(100%-100px)] flex items-center justify-center"
        >
          <div className="text-center">
            <p className="text-lg font-medium text-muted-foreground mb-2">
              No instances to compare
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Add experiments from the editor to compare them side by side
            </p>
            <Button onClick={() => addInstance(currentScene)} variant="outline" className="gap-2">
              <Plus className="w-4 h-4" />
              Add Instance
            </Button>
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {instances.map((instance, index) => {
              const chartData = instance.simulationData.timestamp.map((t, i) => ({
                time: t,
                temp: instance.simulationData.temperatures[i] || 25,
              }));

              return (
                <motion.div
                  key={instance.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="instance-card"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={instance.isRunning ? 'running-indicator' : 'paused-indicator'}
                      />
                      <div>
                        <h3 className="font-medium text-sm">{instance.name}</h3>
                        <p className="text-xs text-muted-foreground">
                          {instance.scene.equipment.length} items
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => toggleInstance(instance.id)}
                      >
                        {instance.isRunning ? (
                          <Pause className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => removeInstance(instance.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Time display */}
                  <div className="mb-4 text-center">
                    <span className="text-2xl font-mono font-bold text-primary">
                      {formatTime(instance.elapsedTime)}
                    </span>
                  </div>

                  {/* Temperature chart */}
                  <div className="h-32 mb-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <XAxis
                          dataKey="time"
                          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                          tickFormatter={(v) => `${Math.floor(v)}s`}
                        />
                        <YAxis
                          domain={[0, 100]}
                          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                          tickFormatter={(v) => `${v}°`}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                          formatter={(value: number) => [`${value.toFixed(1)}°C`, 'Temp']}
                          labelFormatter={(label) => `Time: ${label.toFixed(1)}s`}
                        />
                        <Line
                          type="monotone"
                          dataKey="temp"
                          stroke={chartColors[index % chartColors.length]}
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Current values */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-secondary/50 rounded-lg p-2 text-center">
                      <p className="text-xs text-muted-foreground">Avg Temp</p>
                      <p className="data-value text-sm">
                        {(
                          instance.simulationData.temperatures[
                            instance.simulationData.temperatures.length - 1
                          ] || 25
                        ).toFixed(1)}
                        °C
                      </p>
                    </div>
                    <div className="bg-secondary/50 rounded-lg p-2 text-center">
                      <p className="text-xs text-muted-foreground">Status</p>
                      <p className={`text-sm font-medium ${instance.isRunning ? 'text-lab-green' : 'text-lab-amber'}`}>
                        {instance.isRunning ? 'Running' : 'Paused'}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
