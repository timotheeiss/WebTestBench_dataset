import { motion } from 'framer-motion';
import { Flame, Beaker, FlaskConical, Thermometer, Snowflake, RefreshCw } from 'lucide-react';
import { EquipmentType, Equipment } from '@/types/experiment';
import { calculateBubbleIntensity, interpolateColor } from '@/utils/physics';

interface EquipmentRendererProps {
  equipment: Equipment;
  isSelected?: boolean;
  isSimulating?: boolean;
}

export function EquipmentRenderer({ equipment, isSelected, isSimulating }: EquipmentRendererProps) {
  const { type, params } = equipment;

  const renderEquipment = () => {
    switch (type) {
      case 'bunsen-burner':
        return <BunsenBurner intensity={params.flameIntensity || 0} isSimulating={isSimulating} />;
      case 'beaker':
        return (
          <BeakerComponent
            volume={params.liquidVolume || 0}
            temp={params.liquidTemp || 25}
            color={params.liquidColor || '#00d4ff'}
            isSimulating={isSimulating}
          />
        );
      case 'flask':
        return (
          <FlaskComponent
            volume={params.liquidVolume || 0}
            temp={params.liquidTemp || 25}
            color={params.liquidColor || '#a855f7'}
            isSimulating={isSimulating}
          />
        );
      case 'thermometer':
        return <ThermometerComponent />;
      case 'condenser':
        return <CondenserComponent rate={params.coolingRate || 0} isSimulating={isSimulating} />;
      case 'stirrer':
        return <StirrerComponent speed={params.speed || 0} isActive={params.isActive || false} isSimulating={isSimulating} />;
      default:
        return null;
    }
  };

  return (
    <div
      className={`relative transition-all duration-200 ${
        isSelected ? 'ring-2 ring-primary ring-offset-2 ring-offset-background rounded-lg' : ''
      }`}
    >
      {renderEquipment()}
    </div>
  );
}

function BunsenBurner({ intensity, isSimulating }: { intensity: number; isSimulating?: boolean }) {
  const flameHeight = 20 + (intensity / 100) * 40;
  const flameOpacity = 0.3 + (intensity / 100) * 0.7;

  return (
    <div className="relative w-20 h-32 flex flex-col items-center">
      {/* Flame */}
      {isSimulating && intensity > 0 && (
        <motion.div
          className="absolute -top-2 left-1/2 -translate-x-1/2"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [flameOpacity, flameOpacity * 0.8, flameOpacity],
          }}
          transition={{ duration: 0.3, repeat: Infinity }}
        >
          <div
            className="rounded-full blur-sm"
            style={{
              width: 30 + intensity * 0.2,
              height: flameHeight,
              background: `linear-gradient(to top, 
                hsl(var(--lab-amber)) 0%, 
                hsl(38 92% 60%) 40%, 
                hsl(0 84% 60%) 70%, 
                transparent 100%)`,
              opacity: flameOpacity,
            }}
          />
        </motion.div>
      )}
      
      {/* Burner body */}
      <div className="absolute bottom-0 w-full flex flex-col items-center">
        <div className="w-8 h-4 bg-gradient-to-b from-zinc-600 to-zinc-800 rounded-t" />
        <div className="w-12 h-2 bg-gradient-to-b from-zinc-700 to-zinc-900" />
        <div className="w-16 h-16 bg-gradient-to-b from-zinc-600 via-zinc-700 to-zinc-900 rounded-md flex items-center justify-center">
          <Flame className="w-6 h-6 text-lab-amber opacity-60" />
        </div>
        <div className="w-20 h-3 bg-gradient-to-b from-zinc-800 to-zinc-950 rounded-b" />
      </div>
    </div>
  );
}

function BeakerComponent({
  volume,
  temp,
  color,
  isSimulating,
}: {
  volume: number;
  temp: number;
  color: string;
  isSimulating?: boolean;
}) {
  const fillHeight = (volume / 1000) * 80;
  const bubbleIntensity = isSimulating ? calculateBubbleIntensity(temp) : 0;
  const liquidColor = isSimulating ? interpolateColor(temp) : color;

  return (
    <div className="relative w-24 h-28">
      {/* Beaker body */}
      <div className="absolute inset-0 border-2 border-blue-200/40 rounded-b-lg bg-gradient-to-b from-transparent to-blue-100/5">
        {/* Liquid */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 rounded-b-lg overflow-hidden"
          style={{ height: fillHeight }}
          animate={isSimulating ? { height: fillHeight } : {}}
        >
          <div
            className="absolute inset-0 opacity-60"
            style={{
              background: `linear-gradient(180deg, ${liquidColor}40 0%, ${liquidColor}80 100%)`,
            }}
          />
          
          {/* Bubbles */}
          {bubbleIntensity > 0 && (
            <>
              {[...Array(Math.floor(bubbleIntensity * 8))].map((_, i) => (
                <motion.div
                  key={i}
                  className="bubble"
                  style={{
                    left: `${10 + Math.random() * 80}%`,
                    bottom: 0,
                    width: 3 + Math.random() * 5,
                    height: 3 + Math.random() * 5,
                    animationDelay: `${Math.random() * 2}s`,
                    animationDuration: `${1 + Math.random()}s`,
                  }}
                />
              ))}
            </>
          )}
        </motion.div>
        
        {/* Volume markings */}
        <div className="absolute right-1 top-2 bottom-4 w-px bg-blue-200/20" />
        {[0.25, 0.5, 0.75].map((mark) => (
          <div
            key={mark}
            className="absolute right-0 w-2 h-px bg-blue-200/30"
            style={{ bottom: `${mark * 80}%` }}
          />
        ))}
      </div>
      
      {/* Icon overlay */}
      <Beaker className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-blue-200/20" />
      
      {/* Temperature display */}
      {isSimulating && (
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-mono text-muted-foreground">
          {temp.toFixed(1)}°C
        </div>
      )}
    </div>
  );
}

function FlaskComponent({
  volume,
  temp,
  color,
  isSimulating,
}: {
  volume: number;
  temp: number;
  color: string;
  isSimulating?: boolean;
}) {
  const fillHeight = (volume / 500) * 60;
  const bubbleIntensity = isSimulating ? calculateBubbleIntensity(temp) : 0;
  const liquidColor = isSimulating ? interpolateColor(temp) : color;

  return (
    <div className="relative w-20 h-28">
      {/* Flask neck */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-8 border-2 border-purple-200/40 bg-gradient-to-b from-transparent to-purple-100/5" />
      
      {/* Flask body */}
      <div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-16 border-2 border-purple-200/40 bg-gradient-to-b from-transparent to-purple-100/5"
        style={{
          clipPath: 'polygon(25% 0%, 75% 0%, 100% 100%, 0% 100%)',
        }}
      >
        {/* Liquid */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 overflow-hidden"
          style={{ height: fillHeight }}
        >
          <div
            className="absolute inset-0 opacity-60"
            style={{
              background: `linear-gradient(180deg, ${liquidColor}40 0%, ${liquidColor}80 100%)`,
            }}
          />
          
          {bubbleIntensity > 0 && (
            <>
              {[...Array(Math.floor(bubbleIntensity * 6))].map((_, i) => (
                <motion.div
                  key={i}
                  className="bubble"
                  style={{
                    left: `${20 + Math.random() * 60}%`,
                    bottom: 0,
                    width: 2 + Math.random() * 4,
                    height: 2 + Math.random() * 4,
                    animationDelay: `${Math.random() * 2}s`,
                  }}
                />
              ))}
            </>
          )}
        </motion.div>
      </div>
      
      <FlaskConical className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-purple-200/20" />
      
      {isSimulating && (
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-mono text-muted-foreground">
          {temp.toFixed(1)}°C
        </div>
      )}
    </div>
  );
}

function ThermometerComponent() {
  return (
    <div className="relative w-8 h-32 flex items-center justify-center">
      <div className="w-3 h-28 bg-gradient-to-b from-zinc-700 to-zinc-800 rounded-full relative overflow-hidden">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-5 h-5 bg-red-500 rounded-full" />
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-1 h-20 bg-gradient-to-t from-red-500 to-red-400 rounded-full" />
        
        {/* Scale markings */}
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute left-full ml-0.5 w-1 h-px bg-zinc-400"
            style={{ bottom: `${20 + i * 15}%` }}
          />
        ))}
      </div>
      <Thermometer className="absolute top-0 right-0 w-4 h-4 text-red-400/50" />
    </div>
  );
}

function CondenserComponent({ rate, isSimulating }: { rate: number; isSimulating?: boolean }) {
  return (
    <div className="relative w-32 h-20">
      {/* Condenser tube */}
      <div className="absolute inset-y-2 left-0 right-0 bg-gradient-to-r from-blue-200/10 via-blue-200/20 to-blue-200/10 border border-blue-200/30 rounded-full">
        {/* Cooling coils */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute top-0 bottom-0 w-1 bg-blue-300/30 rounded"
            style={{ left: `${15 + i * 18}%` }}
            animate={
              isSimulating
                ? {
                    opacity: [0.3, 0.6, 0.3],
                  }
                : {}
            }
            transition={{ duration: 1, delay: i * 0.2, repeat: Infinity }}
          />
        ))}
        
        {/* Water droplets */}
        {isSimulating && rate > 50 && (
          <motion.div
            className="absolute right-2 top-1/2 -translate-y-1/2"
            animate={{ opacity: [0, 1, 0], y: [0, 10, 20] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <div className="w-2 h-3 bg-blue-400/60 rounded-full" />
          </motion.div>
        )}
      </div>
      
      <Snowflake className="absolute top-0 right-0 w-4 h-4 text-blue-400/50" />
    </div>
  );
}

function StirrerComponent({ speed, isActive, isSimulating }: { speed: number; isActive: boolean; isSimulating?: boolean }) {
  const rotationSpeed = speed / 100;

  return (
    <div className="relative w-24 h-16">
      {/* Stirrer base */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-20 h-8 bg-gradient-to-b from-zinc-600 to-zinc-800 rounded-lg flex items-center justify-center gap-2">
        {/* Control lights */}
        <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500' : 'bg-zinc-500'}`} />
        <div className="w-6 h-3 bg-zinc-700 rounded" />
      </div>
      
      {/* Magnetic stir bar indicator */}
      {isActive && isSimulating && (
        <motion.div
          className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-2 bg-zinc-400 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 2 / rotationSpeed, repeat: Infinity, ease: 'linear' }}
        />
      )}
      
      <RefreshCw className="absolute top-1 right-1 w-4 h-4 text-green-400/50" />
    </div>
  );
}

export function getEquipmentIcon(type: EquipmentType) {
  switch (type) {
    case 'bunsen-burner':
      return Flame;
    case 'beaker':
      return Beaker;
    case 'flask':
      return FlaskConical;
    case 'thermometer':
      return Thermometer;
    case 'condenser':
      return Snowflake;
    case 'stirrer':
      return RefreshCw;
    default:
      return Beaker;
  }
}
