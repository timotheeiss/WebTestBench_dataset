import { useLabStore } from '@/store/labStore';
import { Equipment } from '@/types/experiment';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, RotateCcw, Maximize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function PropertiesPanel() {
  const selectedId = useLabStore((state) => state.selectedEquipmentId);
  const currentScene = useLabStore((state) => state.currentScene);
  const updateEquipment = useLabStore((state) => state.updateEquipment);
  const removeEquipment = useLabStore((state) => state.removeEquipment);
  const selectEquipment = useLabStore((state) => state.selectEquipment);

  const equipment = currentScene.equipment.find((eq) => eq.id === selectedId);

  if (!equipment) {
    return (
      <div className="glass-panel p-4 h-full flex items-center justify-center">
        <p className="text-muted-foreground text-sm text-center">
          Select equipment to view properties
        </p>
      </div>
    );
  }

  const handleParamChange = (key: string, value: number | boolean | string) => {
    updateEquipment(equipment.id, {
      params: { ...equipment.params, [key]: value },
    });
  };

  const handleTransformChange = (key: keyof Equipment, value: number) => {
    updateEquipment(equipment.id, { [key]: value });
  };

  const handleDelete = () => {
    removeEquipment(equipment.id);
    selectEquipment(null);
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={equipment.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        className="glass-panel p-4 h-full overflow-y-auto scrollbar-thin"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            Properties
          </h3>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={handleDelete}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Equipment Name */}
          <div>
            <Label className="text-xs text-muted-foreground">Name</Label>
            <Input
              value={equipment.name}
              onChange={(e) => updateEquipment(equipment.id, { name: e.target.value })}
              className="mt-1 h-8 text-sm"
            />
          </div>

          {/* Transform Controls */}
          <div className="space-y-4">
            <h4 className="text-xs font-medium text-muted-foreground flex items-center gap-2">
              <RotateCcw className="w-3 h-3" />
              Transform
            </h4>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">Rotation</span>
                <span className="font-mono text-primary">{equipment.rotation}°</span>
              </div>
              <Slider
                value={[equipment.rotation]}
                onValueChange={([v]) => handleTransformChange('rotation', v)}
                min={-180}
                max={180}
                step={5}
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">Scale</span>
                <span className="font-mono text-primary">{equipment.scale.toFixed(1)}x</span>
              </div>
              <Slider
                value={[equipment.scale * 100]}
                onValueChange={([v]) => handleTransformChange('scale', v / 100)}
                min={50}
                max={200}
                step={10}
              />
            </div>
          </div>

          {/* Equipment-specific Parameters */}
          <div className="space-y-4">
            <h4 className="text-xs font-medium text-muted-foreground flex items-center gap-2">
              <Maximize2 className="w-3 h-3" />
              Parameters
            </h4>

            {equipment.type === 'bunsen-burner' && (
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Flame Intensity</span>
                  <span className="font-mono text-lab-amber">{equipment.params.flameIntensity}%</span>
                </div>
                <Slider
                  value={[equipment.params.flameIntensity || 0]}
                  onValueChange={([v]) => handleParamChange('flameIntensity', v)}
                  min={0}
                  max={100}
                  step={5}
                />
              </div>
            )}

            {(equipment.type === 'beaker' || equipment.type === 'flask') && (
              <>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">Volume</span>
                    <span className="font-mono text-primary">
                      {equipment.params.liquidVolume}ml
                    </span>
                  </div>
                  <Slider
                    value={[equipment.params.liquidVolume || 0]}
                    onValueChange={([v]) => handleParamChange('liquidVolume', v)}
                    min={0}
                    max={equipment.type === 'beaker' ? 1000 : 500}
                    step={25}
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">Initial Temp</span>
                    <span className="font-mono text-lab-cyan">
                      {equipment.params.liquidTemp}°C
                    </span>
                  </div>
                  <Slider
                    value={[equipment.params.liquidTemp || 25]}
                    onValueChange={([v]) => handleParamChange('liquidTemp', v)}
                    min={0}
                    max={100}
                    step={1}
                  />
                </div>

                <div>
                  <Label className="text-xs text-muted-foreground">Liquid Color</Label>
                  <div className="flex gap-2 mt-1">
                    <input
                      type="color"
                      value={equipment.params.liquidColor || '#00d4ff'}
                      onChange={(e) => handleParamChange('liquidColor', e.target.value)}
                      className="w-8 h-8 rounded cursor-pointer bg-transparent"
                    />
                    <Input
                      value={equipment.params.liquidColor || '#00d4ff'}
                      onChange={(e) => handleParamChange('liquidColor', e.target.value)}
                      className="flex-1 h-8 text-xs font-mono"
                    />
                  </div>
                </div>
              </>
            )}

            {equipment.type === 'condenser' && (
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Cooling Rate</span>
                  <span className="font-mono text-blue-400">
                    {equipment.params.coolingRate}%
                  </span>
                </div>
                <Slider
                  value={[equipment.params.coolingRate || 0]}
                  onValueChange={([v]) => handleParamChange('coolingRate', v)}
                  min={0}
                  max={100}
                  step={5}
                />
              </div>
            )}

            {equipment.type === 'stirrer' && (
              <>
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-muted-foreground">Active</Label>
                  <Switch
                    checked={equipment.params.isActive || false}
                    onCheckedChange={(v) => handleParamChange('isActive', v)}
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">Speed</span>
                    <span className="font-mono text-lab-green">
                      {equipment.params.speed} RPM
                    </span>
                  </div>
                  <Slider
                    value={[equipment.params.speed || 0]}
                    onValueChange={([v]) => handleParamChange('speed', v)}
                    min={0}
                    max={1000}
                    step={50}
                  />
                </div>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
