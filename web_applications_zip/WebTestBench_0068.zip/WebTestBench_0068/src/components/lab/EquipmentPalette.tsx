import { motion } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { equipmentDefinitions } from '@/data/equipment';
import { Equipment } from '@/types/experiment';
import { v4 as uuidv4 } from 'uuid';
import { getEquipmentIcon } from './EquipmentRenderer';

export function EquipmentPalette() {
  const addEquipment = useLabStore((state) => state.addEquipment);

  const handleAddEquipment = (def: typeof equipmentDefinitions[0]) => {
    const newEquipment: Equipment = {
      id: uuidv4(),
      type: def.type,
      name: def.name,
      x: 300 + Math.random() * 200,
      y: 300 + Math.random() * 100,
      rotation: 0,
      scale: 1,
      params: { ...def.defaultParams },
    };
    addEquipment(newEquipment);
  };

  return (
    <div className="glass-panel p-4 h-full">
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
        Equipment
      </h3>
      
      <div className="space-y-2">
        {equipmentDefinitions.map((def, index) => {
          const Icon = getEquipmentIcon(def.type);
          
          return (
            <motion.button
              key={def.type}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => handleAddEquipment(def)}
              className="equipment-card w-full flex items-center gap-3 text-left group"
            >
              <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{def.name}</p>
                <p className="text-xs text-muted-foreground truncate">{def.description}</p>
              </div>
            </motion.button>
          );
        })}
      </div>
      
      <div className="mt-6 pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground text-center">
          Click to add equipment to the canvas
        </p>
      </div>
    </div>
  );
}
