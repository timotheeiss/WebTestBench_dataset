import { useState } from 'react';
import { motion } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Play, Pause, Save, RotateCcw, Plus, Layers } from 'lucide-react';
import { EquipmentPalette } from './EquipmentPalette';
import { PropertiesPanel } from './PropertiesPanel';
import { ExperimentCanvas } from './ExperimentCanvas';
import { v4 as uuidv4 } from 'uuid';

export function ExperimentEditor() {
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [sceneName, setSceneName] = useState('');
  
  const currentScene = useLabStore((state) => state.currentScene);
  const isSimulating = useLabStore((state) => state.isSimulating);
  const setIsSimulating = useLabStore((state) => state.setIsSimulating);
  const saveCurrentScene = useLabStore((state) => state.saveCurrentScene);
  const setCurrentScene = useLabStore((state) => state.setCurrentScene);
  const addInstance = useLabStore((state) => state.addInstance);

  const handleSave = () => {
    if (sceneName.trim()) {
      saveCurrentScene(sceneName.trim());
      setSceneName('');
      setSaveDialogOpen(false);
    }
  };

  const handleReset = () => {
    setIsSimulating(false);
    // Reset temperatures to initial values
    const resetEquipment = currentScene.equipment.map((eq) => {
      if (eq.type === 'beaker' || eq.type === 'flask') {
        return {
          ...eq,
          params: { ...eq.params, liquidTemp: 25 },
        };
      }
      return eq;
    });
    setCurrentScene({ ...currentScene, equipment: resetEquipment });
  };

  const handleNewScene = () => {
    setIsSimulating(false);
    setCurrentScene({
      id: uuidv4(),
      name: 'New Experiment',
      equipment: [],
      createdAt: Date.now(),
    });
  };

  const handleAddToComparison = () => {
    addInstance(currentScene);
  };

  return (
    <div className="h-full flex gap-4 p-4">
      {/* Left Panel - Equipment Palette */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-64 flex-shrink-0"
      >
        <EquipmentPalette />
      </motion.div>

      {/* Center - Canvas and Controls */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Toolbar */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-3 flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleNewScene}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              New
            </Button>

            <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2">
                  <Save className="w-4 h-4" />
                  Save
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Save Experiment</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <Input
                    placeholder="Experiment name..."
                    value={sceneName}
                    onChange={(e) => setSceneName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                  />
                  <Button onClick={handleSave} className="w-full">
                    Save Experiment
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleAddToComparison}
              className="gap-2"
            >
              <Layers className="w-4 h-4" />
              Add to Comparison
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReset}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </Button>

            <Button
              variant={isSimulating ? 'destructive' : 'default'}
              size="sm"
              onClick={() => setIsSimulating(!isSimulating)}
              className="gap-2 min-w-[120px]"
            >
              {isSimulating ? (
                <>
                  <Pause className="w-4 h-4" />
                  Stop
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Simulate
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Canvas */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex-1 glass-panel p-2"
        >
          <ExperimentCanvas />
        </motion.div>

        {/* Scene info */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel px-4 py-2 flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium">{currentScene.name}</span>
            <span className="text-xs text-muted-foreground">
              {currentScene.equipment.length} items
            </span>
          </div>
          <span className="text-xs text-muted-foreground">
            ID: {currentScene.id.slice(0, 8)}
          </span>
        </motion.div>
      </div>

      {/* Right Panel - Properties */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-64 flex-shrink-0"
      >
        <PropertiesPanel />
      </motion.div>
    </div>
  );
}
