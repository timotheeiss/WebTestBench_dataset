import { useRef, useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { EquipmentRenderer } from './EquipmentRenderer';
import { calculateHeatTransfer } from '@/utils/physics';
import { Equipment } from '@/types/experiment';

interface DragState {
  id: string;
  startX: number;
  startY: number;
  offsetX: number;
  offsetY: number;
}

export function ExperimentCanvas() {
  const canvasRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  
  const currentScene = useLabStore((state) => state.currentScene);
  const selectedEquipmentId = useLabStore((state) => state.selectedEquipmentId);
  const isSimulating = useLabStore((state) => state.isSimulating);
  const updateEquipment = useLabStore((state) => state.updateEquipment);
  const selectEquipment = useLabStore((state) => state.selectEquipment);
  const setCurrentScene = useLabStore((state) => state.setCurrentScene);
  
  const [dragState, setDragState] = useState<DragState | null>(null);

  // Physics simulation loop
  useEffect(() => {
    if (!isSimulating) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    const simulate = (timestamp: number) => {
      if (lastTimeRef.current === 0) {
        lastTimeRef.current = timestamp;
      }
      
      const deltaTime = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;

      // Calculate physics
      const updatedEquipment = calculateHeatTransfer(currentScene.equipment, deltaTime);
      
      // Update scene with new equipment states
      setCurrentScene({
        ...currentScene,
        equipment: updatedEquipment,
      });

      animationRef.current = requestAnimationFrame(simulate);
    };

    lastTimeRef.current = 0;
    animationRef.current = requestAnimationFrame(simulate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isSimulating, currentScene, setCurrentScene]);

  const handleMouseDown = useCallback((e: React.MouseEvent, equipment: Equipment) => {
    e.stopPropagation();
    selectEquipment(equipment.id);
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    setDragState({
      id: equipment.id,
      startX: equipment.x,
      startY: equipment.y,
      offsetX: e.clientX - rect.left - equipment.x,
      offsetY: e.clientY - rect.top - equipment.y,
    });
  }, [selectEquipment]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragState || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const newX = Math.max(0, Math.min(rect.width - 100, e.clientX - rect.left - dragState.offsetX));
    const newY = Math.max(0, Math.min(rect.height - 100, e.clientY - rect.top - dragState.offsetY));

    updateEquipment(dragState.id, { x: newX, y: newY });
  }, [dragState, updateEquipment]);

  const handleMouseUp = useCallback(() => {
    setDragState(null);
  }, []);

  const handleCanvasClick = useCallback((e: React.MouseEvent) => {
    if (e.target === canvasRef.current) {
      selectEquipment(null);
    }
  }, [selectEquipment]);

  return (
    <div
      ref={canvasRef}
      className="relative w-full h-full bg-canvas-bg canvas-grid overflow-hidden rounded-xl"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onClick={handleCanvasClick}
    >
      {/* Grid overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/30 pointer-events-none" />
      
      {/* Equipment */}
      {currentScene.equipment.map((equipment) => (
        <motion.div
          key={equipment.id}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          style={{
            position: 'absolute',
            left: equipment.x,
            top: equipment.y,
            transform: `rotate(${equipment.rotation}deg) scale(${equipment.scale})`,
            transformOrigin: 'center center',
            cursor: dragState?.id === equipment.id ? 'grabbing' : 'grab',
            zIndex: selectedEquipmentId === equipment.id ? 10 : 1,
          }}
          onMouseDown={(e) => handleMouseDown(e, equipment)}
        >
          <EquipmentRenderer
            equipment={equipment}
            isSelected={selectedEquipmentId === equipment.id}
            isSimulating={isSimulating}
          />
        </motion.div>
      ))}

      {/* Empty state */}
      {currentScene.equipment.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <p className="text-lg font-medium mb-2">Empty Canvas</p>
            <p className="text-sm">Add equipment from the palette to begin</p>
          </div>
        </div>
      )}

      {/* Simulation indicator */}
      {isSimulating && (
        <div className="absolute top-4 right-4 flex items-center gap-2 glass-panel px-3 py-1.5">
          <div className="running-indicator" />
          <span className="text-xs font-medium text-lab-green">Simulating</span>
        </div>
      )}
    </div>
  );
}
