import { motion } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { FlaskConical, Layers, History, Beaker } from 'lucide-react';

export function Navigation() {
  const activeTab = useLabStore((state) => state.activeTab);
  const setActiveTab = useLabStore((state) => state.setActiveTab);

  const tabs = [
    { id: 'editor' as const, label: 'Experiment Editor', icon: FlaskConical },
    { id: 'comparison' as const, label: 'Multi-Instance Comparison', icon: Layers },
    { id: 'history' as const, label: 'Historical Scenarios', icon: History },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel mx-4 mt-4 flex items-center justify-between px-4"
    >
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <Beaker className="w-6 h-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-lg font-semibold tracking-tight">LabSim</h1>
          <p className="text-xs text-muted-foreground">Interactive Lab Platform</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav className="flex items-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`nav-tab flex items-center gap-2 ${isActive ? 'active' : ''}`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-primary' : ''}`} />
              <span className="hidden md:inline">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Status indicator */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-lab-green animate-pulse" />
        <span className="text-xs text-muted-foreground hidden sm:inline">System Ready</span>
      </div>
    </motion.header>
  );
}
