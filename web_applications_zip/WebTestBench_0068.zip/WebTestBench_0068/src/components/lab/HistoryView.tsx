import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore } from '@/store/labStore';
import { Button } from '@/components/ui/button';
import { Trash2, FolderOpen, Clock, Beaker } from 'lucide-react';
import { format } from 'date-fns';

export function HistoryView() {
  const savedScenes = useLabStore((state) => state.savedScenes);
  const loadScene = useLabStore((state) => state.loadScene);
  const deleteScene = useLabStore((state) => state.deleteScene);
  const setActiveTab = useLabStore((state) => state.setActiveTab);

  const handleLoad = (id: string) => {
    loadScene(id);
    setActiveTab('editor');
  };

  return (
    <div className="h-full p-4">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel p-4 mb-4"
      >
        <h2 className="text-lg font-semibold">Historical Scenarios</h2>
        <p className="text-sm text-muted-foreground">
          Load and manage your saved experiment configurations
        </p>
      </motion.div>

      {savedScenes.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-panel h-[calc(100%-100px)] flex items-center justify-center"
        >
          <div className="text-center">
            <FolderOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-medium text-muted-foreground mb-2">
              No saved scenarios
            </p>
            <p className="text-sm text-muted-foreground">
              Save experiments from the editor to view them here
            </p>
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          <AnimatePresence>
            {savedScenes.map((scene, index) => (
              <motion.div
                key={scene.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.05 }}
                className="scenario-card group"
                onClick={() => handleLoad(scene.id)}
              >
                {/* Preview area */}
                <div className="h-32 bg-canvas-bg rounded-lg mb-3 relative overflow-hidden canvas-grid">
                  {/* Mini equipment preview */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    {scene.equipment.length > 0 ? (
                      <div className="flex items-center gap-1 flex-wrap justify-center p-2">
                        {scene.equipment.slice(0, 6).map((eq) => (
                          <div
                            key={eq.id}
                            className="w-8 h-8 bg-secondary rounded flex items-center justify-center"
                          >
                            <Beaker className="w-4 h-4 text-primary" />
                          </div>
                        ))}
                        {scene.equipment.length > 6 && (
                          <div className="w-8 h-8 bg-secondary/50 rounded flex items-center justify-center text-xs text-muted-foreground">
                            +{scene.equipment.length - 6}
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground">Empty scene</p>
                    )}
                  </div>

                  {/* Delete button (shows on hover) */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity bg-destructive/80 hover:bg-destructive text-destructive-foreground"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteScene(scene.id);
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>

                {/* Info */}
                <div>
                  <h3 className="font-medium text-sm truncate mb-1">{scene.name}</h3>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Beaker className="w-3 h-3" />
                      <span>{scene.equipment.length} items</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{format(scene.createdAt, 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
