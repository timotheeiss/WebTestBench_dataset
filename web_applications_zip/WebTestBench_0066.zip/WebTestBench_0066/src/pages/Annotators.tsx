import { Layout } from '@/components/Layout';
import { AnnotatorStats } from '@/components/AnnotatorStats';
import { StatCard } from '@/components/StatCard';
import { annotators, annotationTasks } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Users, 
  Trophy, 
  AlertTriangle, 
  TrendingUp,
  ClipboardCheck
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Annotators() {
  const totalTasks = annotators.reduce((acc, a) => acc + a.completedTasks, 0);
  const totalFlagged = annotators.reduce((acc, a) => acc + a.flaggedCount, 0);
  const avgAgreement = annotators.reduce((acc, a) => acc + a.agreementRate, 0) / annotators.length;
  
  const topPerformer = [...annotators].sort((a, b) => b.agreementRate - a.agreementRate)[0];

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Annotators</h1>
          <p className="text-muted-foreground">Performance metrics and statistics for all annotators</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Annotators"
            value={annotators.length}
            icon={<Users className="h-6 w-6" />}
            variant="info"
          />
          <StatCard
            title="Total Completed"
            value={totalTasks}
            subtitle="Annotations"
            icon={<ClipboardCheck className="h-6 w-6" />}
            variant="success"
          />
          <StatCard
            title="Avg Agreement Rate"
            value={`${avgAgreement.toFixed(1)}%`}
            icon={<TrendingUp className="h-6 w-6" />}
            variant="default"
          />
          <StatCard
            title="Total Flagged"
            value={totalFlagged}
            subtitle="Annotations"
            icon={<AlertTriangle className="h-6 w-6" />}
            variant="warning"
          />
        </div>

        {/* Top Performer */}
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="h-6 w-6 text-warning" />
            <h2 className="text-lg font-semibold text-foreground">Top Performer</h2>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-info flex items-center justify-center text-info-foreground text-xl font-bold">
              {topPerformer.avatar}
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground">{topPerformer.name}</h3>
              <div className="flex items-center gap-3 mt-1">
                <Badge variant="successMuted">{topPerformer.agreementRate}% Agreement</Badge>
                <span className="text-sm text-muted-foreground">{topPerformer.completedTasks} tasks completed</span>
              </div>
            </div>
          </div>
        </div>

        {/* All Annotators Table */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="p-4 border-b border-border flex items-center gap-2">
            <Users className="h-5 w-5 text-muted-foreground" />
            <h3 className="font-semibold text-foreground">All Annotators</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left p-4 font-medium text-muted-foreground">Annotator</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Completed Tasks</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Agreement Rate</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Flagged</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {annotators.map((annotator, index) => (
                  <tr 
                    key={annotator.id} 
                    className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors animate-fade-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-info flex items-center justify-center text-info-foreground font-medium">
                          {annotator.avatar}
                        </div>
                        <span className="font-medium text-foreground">{annotator.name}</span>
                      </div>
                    </td>
                    <td className="p-4 text-foreground">{annotator.completedTasks}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-3 min-w-[150px]">
                        <Progress 
                          value={annotator.agreementRate} 
                          className="h-2 flex-1"
                        />
                        <span className={cn(
                          'text-sm font-semibold min-w-[50px]',
                          annotator.agreementRate >= 90 ? 'text-success' : 
                          annotator.agreementRate >= 80 ? 'text-foreground' : 'text-warning'
                        )}>
                          {annotator.agreementRate}%
                        </span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge 
                        variant={annotator.flaggedCount > 10 ? 'warningMuted' : 'secondary'}
                      >
                        {annotator.flaggedCount}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <Badge 
                        variant={annotator.agreementRate >= 85 ? 'successMuted' : 'warningMuted'}
                      >
                        {annotator.agreementRate >= 85 ? 'Good Standing' : 'Needs Review'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Inconsistency Ranking */}
        <div className="grid gap-6 lg:grid-cols-2">
          <AnnotatorStats 
            annotators={annotators} 
            title="Highest Agreement Rates"
          />
          <AnnotatorStats 
            annotators={annotators} 
            title="Lowest Agreement Rates"
            showInconsistent
          />
        </div>
      </div>
    </Layout>
  );
}
