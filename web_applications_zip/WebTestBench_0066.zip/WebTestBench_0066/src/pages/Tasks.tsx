import { useState } from 'react';
import { Layout } from '@/components/Layout';
import { TaskTable } from '@/components/TaskTable';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { annotationTasks, AnnotationStatus } from '@/data/mockData';
import { Search, Filter } from 'lucide-react';
import { cn } from '@/lib/utils';

const statusFilters: { value: AnnotationStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All Tasks' },
  { value: 'pending', label: 'Pending' },
  { value: 'approved', label: 'Approved' },
  { value: 'flagged', label: 'Flagged' },
];

export default function Tasks() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<AnnotationStatus | 'all'>('all');

  const filteredTasks = annotationTasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusCount = (status: AnnotationStatus | 'all') => {
    if (status === 'all') return annotationTasks.length;
    return annotationTasks.filter(t => t.status === status).length;
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Annotation Tasks</h1>
            <p className="text-muted-foreground">Review and manage all annotation tasks</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex gap-2 flex-wrap">
            {statusFilters.map((filter) => (
              <Button
                key={filter.value}
                variant={statusFilter === filter.value ? 'default' : 'outline'}
                size="sm"
                onClick={() => setStatusFilter(filter.value)}
                className="gap-2"
              >
                {filter.label}
                <Badge 
                  variant={statusFilter === filter.value ? 'secondary' : 'outline'}
                  className={cn(
                    'ml-1 px-1.5 py-0 text-xs',
                    statusFilter === filter.value && 'bg-primary-foreground/20 text-primary-foreground'
                  )}
                >
                  {getStatusCount(filter.value)}
                </Badge>
              </Button>
            ))}
          </div>
        </div>

        {/* Tasks Table */}
        {filteredTasks.length > 0 ? (
          <TaskTable tasks={filteredTasks} />
        ) : (
          <div className="rounded-xl border border-border bg-card p-12 text-center">
            <Filter className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No tasks found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or filter criteria
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
