import { Layout } from '@/components/Layout';
import { StatCard } from '@/components/StatCard';
import { TaskTable } from '@/components/TaskTable';
import { AnnotatorStats } from '@/components/AnnotatorStats';
import { 
  annotationTasks, 
  annotators, 
  calculateDisagreementRate,
  getTasksByStatus,
} from '@/data/mockData';
import { 
  ClipboardCheck, 
  AlertTriangle, 
  Clock, 
  TrendingDown 
} from 'lucide-react';

const Index = () => {
  const disagreementRate = calculateDisagreementRate(annotationTasks);
  const flaggedTasks = getTasksByStatus('flagged');
  const pendingTasks = getTasksByStatus('pending');
  const approvedTasks = getTasksByStatus('approved');
  
  // Get annotators sorted by inconsistency (lowest agreement rate first)
  const inconsistentAnnotators = [...annotators]
    .sort((a, b) => a.agreementRate - b.agreementRate)
    .slice(0, 3);

  const recentTasks = [...annotationTasks]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Overview of annotation review metrics and tasks</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Tasks"
            value={annotationTasks.length}
            subtitle={`${approvedTasks.length} approved`}
            icon={<ClipboardCheck className="h-6 w-6" />}
            variant="info"
          />
          <StatCard
            title="Pending Review"
            value={pendingTasks.length}
            subtitle="Awaiting review"
            icon={<Clock className="h-6 w-6" />}
            variant="default"
          />
          <StatCard
            title="Flagged Items"
            value={flaggedTasks.length}
            subtitle="Need attention"
            icon={<AlertTriangle className="h-6 w-6" />}
            variant="warning"
          />
          <StatCard
            title="Disagreement Rate"
            value={`${disagreementRate.toFixed(1)}%`}
            subtitle="Cross-annotator"
            icon={<TrendingDown className="h-6 w-6" />}
            variant="success"
            trend={{ value: 2.3, isPositive: true }}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Recent Tasks */}
          <div className="lg:col-span-2">
            <TaskTable tasks={recentTasks} showViewAll />
          </div>

          {/* Annotator Stats */}
          <div>
            <AnnotatorStats 
              annotators={inconsistentAnnotators} 
              title="Lowest Agreement Rates"
              showInconsistent
            />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Index;
