import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { AnnotationComparison } from '@/components/AnnotationComparison';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { annotationTasks, AnnotationTask } from '@/data/mockData';
import { 
  ArrowLeft, 
  CheckCircle, 
  Flag, 
  FileText, 
  Calendar,
  MessageSquare
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

function getStatusBadgeVariant(status: AnnotationTask['status']) {
  switch (status) {
    case 'approved':
      return 'success';
    case 'flagged':
      return 'warning';
    case 'pending':
    default:
      return 'secondary';
  }
}

export default function TaskDetail() {
  const { taskId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const task = annotationTasks.find(t => t.id === taskId);
  const [status, setStatus] = useState<AnnotationTask['status']>(task?.status || 'pending');
  const [reviewNotes, setReviewNotes] = useState(task?.reviewNotes || '');

  if (!task) {
    return (
      <Layout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold text-foreground mb-4">Task not found</h1>
          <Button asChild>
            <Link to="/tasks">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Tasks
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const handleApprove = () => {
    setStatus('approved');
    toast({
      title: "Task Approved",
      description: "The annotation task has been marked as approved.",
    });
  };

  const handleFlag = () => {
    setStatus('flagged');
    toast({
      title: "Task Flagged",
      description: "The annotation task has been flagged for review.",
      variant: "destructive",
    });
  };

  // Find adjacent tasks for navigation
  const currentIndex = annotationTasks.findIndex(t => t.id === taskId);
  const prevTask = currentIndex > 0 ? annotationTasks[currentIndex - 1] : null;
  const nextTask = currentIndex < annotationTasks.length - 1 ? annotationTasks[currentIndex + 1] : null;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link to="/tasks">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-2xl font-bold text-foreground truncate">{task.title}</h1>
              <Badge variant={getStatusBadgeVariant(status)} className="capitalize">
                {status}
              </Badge>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
              <span className="flex items-center gap-1">
                <FileText className="h-4 w-4" />
                {task.dataType}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {new Date(task.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>

        {/* Content Preview */}
        <div className="rounded-xl border border-border bg-card p-6">
          <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <FileText className="h-5 w-5 text-muted-foreground" />
            Content to Annotate
          </h3>
          <div className="rounded-lg bg-muted p-4">
            <p className="text-foreground leading-relaxed">{task.content}</p>
          </div>
        </div>

        {/* Annotations Comparison */}
        <div className="rounded-xl border border-border bg-card p-6">
          <AnnotationComparison annotations={task.annotations} />
        </div>

        {/* Review Actions */}
        <div className="rounded-xl border border-border bg-card p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-muted-foreground" />
            Review Notes
          </h3>
          
          <Textarea
            placeholder="Add notes about this annotation task..."
            value={reviewNotes}
            onChange={(e) => setReviewNotes(e.target.value)}
            className="min-h-[100px] mb-4"
          />

          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              variant="success" 
              onClick={handleApprove}
              disabled={status === 'approved'}
              className="flex-1 sm:flex-none"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Approve
            </Button>
            <Button 
              variant="warningOutline" 
              onClick={handleFlag}
              disabled={status === 'flagged'}
              className="flex-1 sm:flex-none"
            >
              <Flag className="h-4 w-4 mr-2" />
              Flag for Review
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          {prevTask ? (
            <Button variant="outline" asChild>
              <Link to={`/tasks/${prevTask.id}`}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous Task
              </Link>
            </Button>
          ) : (
            <div />
          )}
          
          {nextTask && (
            <Button variant="outline" asChild>
              <Link to={`/tasks/${nextTask.id}`}>
                Next Task
                <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
              </Link>
            </Button>
          )}
        </div>
      </div>
    </Layout>
  );
}
