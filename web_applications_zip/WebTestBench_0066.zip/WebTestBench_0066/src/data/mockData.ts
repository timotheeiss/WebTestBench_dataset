export type AnnotationStatus = 'pending' | 'approved' | 'flagged';

export interface Annotator {
  id: string;
  name: string;
  avatar: string;
  completedTasks: number;
  agreementRate: number;
  flaggedCount: number;
}

export interface Annotation {
  annotatorId: string;
  label: string;
  confidence: number;
  timestamp: string;
  notes?: string;
}

export interface AnnotationTask {
  id: string;
  title: string;
  dataType: 'text' | 'image' | 'audio';
  content: string;
  annotations: Annotation[];
  status: AnnotationStatus;
  reviewNotes?: string;
  createdAt: string;
  reviewedAt?: string;
}

export const annotators: Annotator[] = [
  {
    id: 'ann-1',
    name: 'Sarah Chen',
    avatar: 'SC',
    completedTasks: 245,
    agreementRate: 94.2,
    flaggedCount: 3,
  },
  {
    id: 'ann-2',
    name: 'Marcus Johnson',
    avatar: 'MJ',
    completedTasks: 198,
    agreementRate: 87.5,
    flaggedCount: 12,
  },
  {
    id: 'ann-3',
    name: 'Elena Rodriguez',
    avatar: 'ER',
    completedTasks: 312,
    agreementRate: 96.8,
    flaggedCount: 2,
  },
  {
    id: 'ann-4',
    name: 'James Wilson',
    avatar: 'JW',
    completedTasks: 156,
    agreementRate: 78.3,
    flaggedCount: 18,
  },
  {
    id: 'ann-5',
    name: 'Aisha Patel',
    avatar: 'AP',
    completedTasks: 287,
    agreementRate: 91.7,
    flaggedCount: 7,
  },
];

export const annotationTasks: AnnotationTask[] = [
  {
    id: 'task-001',
    title: 'Customer Support Intent Classification',
    dataType: 'text',
    content: 'I need to cancel my subscription and get a refund for the last month. The service has been terrible.',
    annotations: [
      { annotatorId: 'ann-1', label: 'Cancellation Request', confidence: 0.95, timestamp: '2024-01-15T10:30:00Z' },
      { annotatorId: 'ann-2', label: 'Refund Request', confidence: 0.88, timestamp: '2024-01-15T11:15:00Z' },
      { annotatorId: 'ann-3', label: 'Cancellation Request', confidence: 0.92, timestamp: '2024-01-15T12:00:00Z' },
    ],
    status: 'pending',
    createdAt: '2024-01-15T09:00:00Z',
  },
  {
    id: 'task-002',
    title: 'Product Review Sentiment',
    dataType: 'text',
    content: 'This laptop exceeded my expectations! The battery life is incredible and the screen is beautiful.',
    annotations: [
      { annotatorId: 'ann-1', label: 'Positive', confidence: 0.98, timestamp: '2024-01-15T14:30:00Z' },
      { annotatorId: 'ann-4', label: 'Positive', confidence: 0.96, timestamp: '2024-01-15T15:00:00Z' },
      { annotatorId: 'ann-5', label: 'Positive', confidence: 0.99, timestamp: '2024-01-15T15:30:00Z' },
    ],
    status: 'approved',
    createdAt: '2024-01-15T13:00:00Z',
    reviewedAt: '2024-01-16T09:00:00Z',
  },
  {
    id: 'task-003',
    title: 'Medical Entity Extraction',
    dataType: 'text',
    content: 'Patient presents with chronic migraine headaches and has been prescribed sumatriptan 50mg.',
    annotations: [
      { annotatorId: 'ann-2', label: 'Condition: Migraine', confidence: 0.85, timestamp: '2024-01-16T10:00:00Z', notes: 'Also identified medication' },
      { annotatorId: 'ann-3', label: 'Medication: Sumatriptan', confidence: 0.92, timestamp: '2024-01-16T10:30:00Z' },
      { annotatorId: 'ann-4', label: 'Symptom: Headache', confidence: 0.72, timestamp: '2024-01-16T11:00:00Z' },
    ],
    status: 'flagged',
    reviewNotes: 'Significant disagreement between annotators on primary entity type',
    createdAt: '2024-01-16T08:00:00Z',
    reviewedAt: '2024-01-16T14:00:00Z',
  },
  {
    id: 'task-004',
    title: 'Spam Detection Classification',
    dataType: 'text',
    content: 'CONGRATULATIONS! You have won $1,000,000! Click here to claim your prize now!!!',
    annotations: [
      { annotatorId: 'ann-1', label: 'Spam', confidence: 1.0, timestamp: '2024-01-17T09:00:00Z' },
      { annotatorId: 'ann-5', label: 'Spam', confidence: 0.99, timestamp: '2024-01-17T09:30:00Z' },
    ],
    status: 'approved',
    createdAt: '2024-01-17T08:00:00Z',
    reviewedAt: '2024-01-17T10:00:00Z',
  },
  {
    id: 'task-005',
    title: 'News Article Topic Classification',
    dataType: 'text',
    content: 'The Federal Reserve announced a 0.25% interest rate hike today, citing continued inflation concerns.',
    annotations: [
      { annotatorId: 'ann-2', label: 'Finance', confidence: 0.94, timestamp: '2024-01-17T11:00:00Z' },
      { annotatorId: 'ann-3', label: 'Economics', confidence: 0.91, timestamp: '2024-01-17T11:30:00Z' },
      { annotatorId: 'ann-4', label: 'Politics', confidence: 0.78, timestamp: '2024-01-17T12:00:00Z' },
    ],
    status: 'pending',
    createdAt: '2024-01-17T10:00:00Z',
  },
  {
    id: 'task-006',
    title: 'Social Media Post Toxicity',
    dataType: 'text',
    content: 'I completely disagree with your opinion on this matter. Your argument lacks any factual basis.',
    annotations: [
      { annotatorId: 'ann-1', label: 'Not Toxic', confidence: 0.82, timestamp: '2024-01-18T09:00:00Z' },
      { annotatorId: 'ann-4', label: 'Mildly Toxic', confidence: 0.65, timestamp: '2024-01-18T09:30:00Z' },
      { annotatorId: 'ann-5', label: 'Not Toxic', confidence: 0.88, timestamp: '2024-01-18T10:00:00Z' },
    ],
    status: 'flagged',
    reviewNotes: 'Edge case - disagreement on toxicity threshold',
    createdAt: '2024-01-18T08:00:00Z',
    reviewedAt: '2024-01-18T11:00:00Z',
  },
  {
    id: 'task-007',
    title: 'E-commerce Product Category',
    dataType: 'text',
    content: 'Wireless Bluetooth headphones with active noise cancellation, 30-hour battery life, foldable design',
    annotations: [
      { annotatorId: 'ann-2', label: 'Electronics > Audio', confidence: 0.97, timestamp: '2024-01-18T13:00:00Z' },
      { annotatorId: 'ann-3', label: 'Electronics > Audio', confidence: 0.95, timestamp: '2024-01-18T13:30:00Z' },
    ],
    status: 'approved',
    createdAt: '2024-01-18T12:00:00Z',
    reviewedAt: '2024-01-18T14:00:00Z',
  },
  {
    id: 'task-008',
    title: 'Resume Skill Extraction',
    dataType: 'text',
    content: 'Experienced in Python, JavaScript, and machine learning. Led a team of 5 engineers for 3 years.',
    annotations: [
      { annotatorId: 'ann-1', label: 'Technical Skills', confidence: 0.89, timestamp: '2024-01-19T10:00:00Z' },
      { annotatorId: 'ann-5', label: 'Technical Skills', confidence: 0.91, timestamp: '2024-01-19T10:30:00Z' },
      { annotatorId: 'ann-3', label: 'Leadership Experience', confidence: 0.87, timestamp: '2024-01-19T11:00:00Z' },
    ],
    status: 'pending',
    createdAt: '2024-01-19T09:00:00Z',
  },
  {
    id: 'task-009',
    title: 'Legal Document Clause Type',
    dataType: 'text',
    content: 'Either party may terminate this agreement with 30 days written notice to the other party.',
    annotations: [
      { annotatorId: 'ann-2', label: 'Termination Clause', confidence: 0.96, timestamp: '2024-01-19T14:00:00Z' },
      { annotatorId: 'ann-4', label: 'Termination Clause', confidence: 0.93, timestamp: '2024-01-19T14:30:00Z' },
    ],
    status: 'approved',
    createdAt: '2024-01-19T13:00:00Z',
    reviewedAt: '2024-01-19T15:00:00Z',
  },
  {
    id: 'task-010',
    title: 'Restaurant Review Aspect Sentiment',
    dataType: 'text',
    content: 'The food was amazing but the service was incredibly slow. We waited 45 minutes for our appetizers.',
    annotations: [
      { annotatorId: 'ann-1', label: 'Mixed Sentiment', confidence: 0.90, timestamp: '2024-01-20T10:00:00Z' },
      { annotatorId: 'ann-3', label: 'Negative (Service)', confidence: 0.85, timestamp: '2024-01-20T10:30:00Z' },
      { annotatorId: 'ann-5', label: 'Mixed Sentiment', confidence: 0.88, timestamp: '2024-01-20T11:00:00Z' },
    ],
    status: 'pending',
    createdAt: '2024-01-20T09:00:00Z',
  },
];

export function getAnnotatorById(id: string): Annotator | undefined {
  return annotators.find(a => a.id === id);
}

export function calculateDisagreementRate(tasks: AnnotationTask[]): number {
  const tasksWithMultipleAnnotations = tasks.filter(t => t.annotations.length > 1);
  if (tasksWithMultipleAnnotations.length === 0) return 0;
  
  const disagreements = tasksWithMultipleAnnotations.filter(task => {
    const labels = task.annotations.map(a => a.label);
    return new Set(labels).size > 1;
  });
  
  return (disagreements.length / tasksWithMultipleAnnotations.length) * 100;
}

export function getTasksByStatus(status: AnnotationStatus): AnnotationTask[] {
  return annotationTasks.filter(t => t.status === status);
}

export function getAnnotatorInconsistencyRanking(): Annotator[] {
  return [...annotators].sort((a, b) => a.agreementRate - b.agreementRate);
}
