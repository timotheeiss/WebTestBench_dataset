import { Annotation, getAnnotatorById } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AnnotationComparisonProps {
  annotations: Annotation[];
  highlightDifferences?: boolean;
}

export function AnnotationComparison({ annotations, highlightDifferences = true }: AnnotationComparisonProps) {
  const allLabels = annotations.map(a => a.label);
  const uniqueLabels = new Set(allLabels);
  const hasDisagreement = uniqueLabels.size > 1;

  // Find the most common label
  const labelCounts = allLabels.reduce((acc, label) => {
    acc[label] = (acc[label] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const maxCount = Math.max(...Object.values(labelCounts));
  const majorityLabel = Object.entries(labelCounts).find(([_, count]) => count === maxCount)?.[0];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground">Annotations ({annotations.length})</h3>
        {hasDisagreement && highlightDifferences && (
          <Badge variant="warningMuted">
            Disagreement Detected
          </Badge>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {annotations.map((annotation, index) => {
          const annotator = getAnnotatorById(annotation.annotatorId);
          const isDifferent = highlightDifferences && hasDisagreement && annotation.label !== majorityLabel;

          return (
            <div
              key={index}
              className={cn(
                'rounded-lg border p-4 transition-all animate-fade-in',
                isDifferent 
                  ? 'border-warning bg-warning-muted' 
                  : 'border-border bg-card hover:border-muted-foreground/50'
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="h-10 w-10 rounded-full bg-info flex items-center justify-center text-info-foreground font-medium text-sm shrink-0">
                  {annotator?.avatar || '??'}
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-foreground truncate">{annotator?.name || 'Unknown'}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(annotation.timestamp).toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: 'numeric',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Label</p>
                  <Badge 
                    variant={isDifferent ? 'warning' : 'default'}
                    className="text-sm"
                  >
                    {annotation.label}
                  </Badge>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground mb-1">Confidence</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                      <div 
                        className={cn(
                          'h-full rounded-full transition-all',
                          annotation.confidence >= 0.9 ? 'bg-success' :
                          annotation.confidence >= 0.7 ? 'bg-info' : 'bg-warning'
                        )}
                        style={{ width: `${annotation.confidence * 100}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium text-foreground">
                      {Math.round(annotation.confidence * 100)}%
                    </span>
                  </div>
                </div>

                {annotation.notes && (
                  <div className="flex items-start gap-2 pt-2 border-t border-border">
                    <MessageSquare className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <p className="text-sm text-muted-foreground">{annotation.notes}</p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
