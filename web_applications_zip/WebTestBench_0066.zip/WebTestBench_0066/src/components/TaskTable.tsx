import { Link } from 'react-router-dom';
import { ChevronRight, FileText } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { AnnotationTask, getAnnotatorById } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface TaskTableProps {
  tasks: AnnotationTask[];
  showViewAll?: boolean;
}

function getStatusBadgeVariant(status: AnnotationTask['status']) {
  switch (status) {
    case 'approved':
      return 'successMuted';
    case 'flagged':
      return 'warningMuted';
    case 'pending':
    default:
      return 'secondary';
  }
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function TaskTable({ tasks, showViewAll = false }: TaskTableProps) {
  const calculateAgreement = (task: AnnotationTask) => {
    if (task.annotations.length < 2) return 100;
    const labels = task.annotations.map(a => a.label);
    const uniqueLabels = new Set(labels);
    if (uniqueLabels.size === 1) return 100;
    
    // Calculate percentage of most common label
    const labelCounts = labels.reduce((acc, label) => {
      acc[label] = (acc[label] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const maxCount = Math.max(...Object.values(labelCounts));
    return Math.round((maxCount / labels.length) * 100);
  };

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-semibold text-foreground">Annotation Tasks</h3>
        </div>
        {showViewAll && (
          <Button variant="ghost" size="sm" asChild>
            <Link to="/tasks">View all <ChevronRight className="h-4 w-4" /></Link>
          </Button>
        )}
      </div>
      
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Task</TableHead>
            <TableHead className="hidden sm:table-cell">Annotators</TableHead>
            <TableHead className="hidden md:table-cell">Agreement</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden sm:table-cell">Date</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tasks.map((task, index) => {
            const agreement = calculateAgreement(task);
            const annotatorNames = task.annotations
              .map(a => getAnnotatorById(a.annotatorId)?.name || 'Unknown')
              .slice(0, 2);
            const remainingCount = task.annotations.length - 2;

            return (
              <TableRow 
                key={task.id} 
                className="animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <TableCell>
                  <div className="space-y-1">
                    <p className="font-medium text-foreground line-clamp-1">{task.title}</p>
                    <p className="text-sm text-muted-foreground line-clamp-1 max-w-[200px] md:max-w-[300px]">
                      {task.content}
                    </p>
                  </div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <div className="flex -space-x-2">
                    {task.annotations.slice(0, 3).map((annotation, i) => {
                      const annotator = getAnnotatorById(annotation.annotatorId);
                      return (
                        <div
                          key={i}
                          className="h-8 w-8 rounded-full bg-secondary border-2 border-card flex items-center justify-center text-xs font-medium text-secondary-foreground"
                          title={annotator?.name}
                        >
                          {annotator?.avatar || '??'}
                        </div>
                      );
                    })}
                    {task.annotations.length > 3 && (
                      <div className="h-8 w-8 rounded-full bg-muted border-2 border-card flex items-center justify-center text-xs font-medium text-muted-foreground">
                        +{task.annotations.length - 3}
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <div className={cn(
                    'font-medium',
                    agreement >= 90 ? 'text-success' : agreement >= 70 ? 'text-warning' : 'text-destructive'
                  )}>
                    {agreement}%
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={getStatusBadgeVariant(task.status)} className="capitalize">
                    {task.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                  {formatDate(task.createdAt)}
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="icon" asChild>
                    <Link to={`/tasks/${task.id}`}>
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
