import { Users, TrendingUp, TrendingDown } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Annotator } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface AnnotatorStatsProps {
  annotators: Annotator[];
  title?: string;
  showInconsistent?: boolean;
}

export function AnnotatorStats({ annotators, title = 'Annotator Performance', showInconsistent = false }: AnnotatorStatsProps) {
  const sortedAnnotators = showInconsistent
    ? [...annotators].sort((a, b) => a.agreementRate - b.agreementRate)
    : [...annotators].sort((a, b) => b.agreementRate - a.agreementRate);

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="p-4 border-b border-border flex items-center gap-2">
        <Users className="h-5 w-5 text-muted-foreground" />
        <h3 className="font-semibold text-foreground">{title}</h3>
      </div>
      
      <div className="p-4 space-y-4">
        {sortedAnnotators.map((annotator, index) => (
          <div 
            key={annotator.id} 
            className="flex items-center gap-4 animate-slide-in-right"
            style={{ animationDelay: `${index * 75}ms` }}
          >
            <div className="h-10 w-10 rounded-full bg-info flex items-center justify-center text-info-foreground font-medium text-sm shrink-0">
              {annotator.avatar}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium text-foreground truncate">{annotator.name}</span>
                <div className="flex items-center gap-1">
                  {annotator.agreementRate >= 90 ? (
                    <TrendingUp className="h-4 w-4 text-success" />
                  ) : annotator.agreementRate < 80 ? (
                    <TrendingDown className="h-4 w-4 text-warning" />
                  ) : null}
                  <span className={cn(
                    'text-sm font-semibold',
                    annotator.agreementRate >= 90 ? 'text-success' : 
                    annotator.agreementRate >= 80 ? 'text-foreground' : 'text-warning'
                  )}>
                    {annotator.agreementRate}%
                  </span>
                </div>
              </div>
              
              <Progress 
                value={annotator.agreementRate} 
                className="h-2"
              />
              
              <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                <span>{annotator.completedTasks} tasks</span>
                <span>{annotator.flaggedCount} flagged</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
