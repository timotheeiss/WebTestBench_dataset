import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'info';
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export function StatCard({ title, value, subtitle, icon, variant = 'default', trend }: StatCardProps) {
  const gradientClasses = {
    default: 'stat-card-gradient',
    success: 'success-gradient',
    warning: 'warning-gradient',
    info: 'info-gradient',
  };

  return (
    <div className="rounded-xl border border-border bg-card p-6 transition-all hover:shadow-lg animate-fade-in">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold text-foreground">{value}</p>
          {subtitle && (
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          )}
          {trend && (
            <div className={cn(
              'inline-flex items-center gap-1 text-sm font-medium',
              trend.isPositive ? 'text-success' : 'text-warning'
            )}>
              <span>{trend.isPositive ? '↑' : '↓'}</span>
              <span>{Math.abs(trend.value)}% from last week</span>
            </div>
          )}
        </div>
        <div className={cn(
          'flex h-12 w-12 items-center justify-center rounded-lg text-primary-foreground',
          gradientClasses[variant]
        )}>
          {icon}
        </div>
      </div>
    </div>
  );
}
