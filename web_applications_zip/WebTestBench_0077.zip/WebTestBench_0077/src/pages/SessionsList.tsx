import React, { useState } from 'react';
import { useInventory } from '@/context/InventoryContext';
import { SessionCard } from '@/components/SessionCard';
import { CreateSessionDialog } from '@/components/CreateSessionDialog';
import { Button } from '@/components/ui/button';
import { SessionStatus } from '@/types/inventory';
import { cn } from '@/lib/utils';

const statusFilters: { value: SessionStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All Sessions' },
  { value: 'draft', label: 'Draft' },
  { value: 'pending_approval', label: 'Pending Approval' },
  { value: 'approved', label: 'Approved' },
  { value: 'completed', label: 'Completed' },
];

const SessionsList: React.FC = () => {
  const { sessions } = useInventory();
  const [filter, setFilter] = useState<SessionStatus | 'all'>('all');

  const filteredSessions = filter === 'all'
    ? sessions
    : sessions.filter(s => s.status === filter);

  return (
    <div className="page-container">
      <div className="page-header flex items-center justify-between">
        <div>
          <h1 className="page-title">Counting Sessions</h1>
          <p className="page-description">Manage and track your inventory counts</p>
        </div>
        <CreateSessionDialog />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-6">
        {statusFilters.map(status => (
          <Button
            key={status.value}
            variant={filter === status.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(status.value)}
            className={cn(
              'transition-all',
              filter === status.value && 'shadow-sm'
            )}
          >
            {status.label}
            <span className="ml-1.5 text-xs opacity-70">
              ({status.value === 'all'
                ? sessions.length
                : sessions.filter(s => s.status === status.value).length})
            </span>
          </Button>
        ))}
      </div>

      {/* Sessions Grid */}
      {filteredSessions.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No sessions found for this filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSessions.map(session => (
            <SessionCard key={session.id} session={session} />
          ))}
        </div>
      )}
    </div>
  );
};

export default SessionsList;
