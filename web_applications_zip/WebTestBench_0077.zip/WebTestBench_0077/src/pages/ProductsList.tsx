import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { Card } from '@/components/ui/card';

const ProductsList: React.FC = () => {
  const { products } = useInventory();

  const categories = [...new Set(products.map(p => p.category))];

  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Products</h1>
        <p className="page-description">View all products available for inventory counting</p>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Product Name</th>
                <th>SKU</th>
                <th>Category</th>
                <th className="text-right">Expected Quantity</th>
              </tr>
            </thead>
            <tbody>
              {products.map(product => (
                <tr key={product.id}>
                  <td className="font-medium">{product.name}</td>
                  <td className="text-muted-foreground font-mono text-sm">{product.sku}</td>
                  <td>
                    <span className="inline-flex items-center px-2 py-1 rounded-md bg-muted text-xs font-medium">
                      {product.category}
                    </span>
                  </td>
                  <td className="text-right font-medium">{product.expectedQuantity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Category Summary */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold mb-4">By Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {categories.map(category => {
            const categoryProducts = products.filter(p => p.category === category);
            const totalQuantity = categoryProducts.reduce((sum, p) => sum + p.expectedQuantity, 0);

            return (
              <Card key={category} className="p-4">
                <h3 className="font-medium mb-1">{category}</h3>
                <p className="text-2xl font-bold">{categoryProducts.length}</p>
                <p className="text-sm text-muted-foreground">
                  {totalQuantity} total units expected
                </p>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProductsList;
