import React, { useState, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useInventory } from '@/context/InventoryContext';
import { ProductCountTable } from '@/components/ProductCountTable';
import { VarianceReportView } from '@/components/VarianceReportView';
import { StatusBadge } from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  ArrowLeft,
  Calendar,
  MapPin,
  FileCheck,
  Send,
  CheckCircle,
  XCircle,
  Lock,
  Info,
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const SessionDetail: React.FC = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const {
    getSession,
    updateProductCount,
    submitForApproval,
    approveSession,
    rejectSession,
    finalizeSession,
    canGenerateReport,
    generateVarianceReport,
    updateSessionNotes,
  } = useInventory();

  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showFinalizeDialog, setShowFinalizeDialog] = useState(false);

  const session = getSession(sessionId || '');
  const report = useMemo(
    () => (sessionId && canGenerateReport(sessionId) ? generateVarianceReport(sessionId) : null),
    [sessionId, canGenerateReport, generateVarianceReport]
  );

  if (!session) {
    return (
      <div className="page-container text-center py-12">
        <h2 className="text-xl font-semibold mb-2">Session not found</h2>
        <p className="text-muted-foreground mb-4">
          The counting session you're looking for doesn't exist.
        </p>
        <Button asChild>
          <Link to="/sessions">Back to Sessions</Link>
        </Button>
      </div>
    );
  }

  const isReadOnly = session.status !== 'draft';
  const allCounted = session.products.every(p => p.countedQuantity !== null);
  const countedProducts = session.products.filter(p => p.countedQuantity !== null).length;

  const handleSubmit = () => {
    if (submitForApproval(session.id)) {
      toast.success('Session submitted for approval');
      setShowSubmitDialog(false);
    } else {
      toast.error('Failed to submit. Ensure all products are counted.');
    }
  };

  const handleApprove = () => {
    approveSession(session.id, 'Current User');
    toast.success('Session approved');
    setShowApproveDialog(false);
  };

  const handleReject = () => {
    rejectSession(session.id);
    toast.info('Session rejected and returned to draft');
    setShowRejectDialog(false);
  };

  const handleFinalize = () => {
    finalizeSession(session.id);
    toast.success('Session finalized. Inventory records updated.');
    setShowFinalizeDialog(false);
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="mb-6">
        <Button
          variant="ghost"
          size="sm"
          asChild
          className="mb-4 -ml-2"
        >
          <Link to="/sessions">
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Sessions
          </Link>
        </Button>

        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{session.name}</h1>
              <StatusBadge status={session.status} />
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4" />
                {session.location}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                Created {format(new Date(session.createdAt), 'MMM d, yyyy')}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2">
            {session.status === 'draft' && allCounted && (
              <Button onClick={() => setShowSubmitDialog(true)}>
                <Send className="mr-2 h-4 w-4" />
                Submit for Approval
              </Button>
            )}
            {session.status === 'pending_approval' && (
              <>
                <Button
                  variant="outline"
                  onClick={() => setShowRejectDialog(true)}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject
                </Button>
                <Button onClick={() => setShowApproveDialog(true)}>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approve
                </Button>
              </>
            )}
            {session.status === 'approved' && (
              <Button onClick={() => setShowFinalizeDialog(true)}>
                <FileCheck className="mr-2 h-4 w-4" />
                Finalize & Update Inventory
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Read-only notice */}
      {isReadOnly && session.status !== 'completed' && (
        <div className="flex items-center gap-3 p-4 bg-muted rounded-lg mb-6">
          <Lock className="h-5 w-5 text-muted-foreground" />
          <div>
            <p className="font-medium">This session is read-only</p>
            <p className="text-sm text-muted-foreground">
              {session.status === 'pending_approval' && 'This session is pending approval and cannot be modified.'}
              {session.status === 'approved' && 'This session has been approved. Finalize it to update inventory records.'}
            </p>
          </div>
        </div>
      )}

      {session.status === 'completed' && (
        <div className="flex items-center gap-3 p-4 bg-info/10 border border-info/30 rounded-lg mb-6">
          <CheckCircle className="h-5 w-5 text-info" />
          <div>
            <p className="font-medium text-info">Session Completed</p>
            <p className="text-sm text-muted-foreground">
              Finalized on {format(new Date(session.completedAt!), 'MMMM d, yyyy h:mm a')}
              {session.approvedBy && ` • Approved by ${session.approvedBy}`}
            </p>
          </div>
        </div>
      )}

      {/* Content Tabs */}
      <Tabs defaultValue="count" className="space-y-6">
        <TabsList>
          <TabsTrigger value="count">Product Count</TabsTrigger>
          <TabsTrigger value="report" disabled={!report}>
            Variance Report
            {!allCounted && (
              <Info className="ml-1.5 h-3.5 w-3.5 text-muted-foreground" />
            )}
          </TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
        </TabsList>

        <TabsContent value="count" className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              {countedProducts} of {session.products.length} products counted
            </p>
            {!allCounted && session.status === 'draft' && (
              <p className="text-sm text-warning">
                Complete all counts to generate variance report
              </p>
            )}
          </div>
          <ProductCountTable
            products={session.products}
            onUpdateCount={(productId, count) =>
              updateProductCount(session.id, productId, count)
            }
            readonly={isReadOnly}
          />
        </TabsContent>

        <TabsContent value="report">
          {report ? (
            <VarianceReportView report={report} />
          ) : (
            <Card className="p-8 text-center">
              <Info className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">Report not available</h3>
              <p className="text-sm text-muted-foreground">
                Complete counting all products to generate the variance report.
              </p>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="details" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Session Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Session ID
                  </label>
                  <p className="font-mono text-sm">{session.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Location
                  </label>
                  <p>{session.location}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Created At
                  </label>
                  <p>{format(new Date(session.createdAt), 'MMMM d, yyyy h:mm a')}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Last Updated
                  </label>
                  <p>{format(new Date(session.updatedAt), 'MMMM d, yyyy h:mm a')}</p>
                </div>
                {session.submittedAt && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">
                      Submitted At
                    </label>
                    <p>{format(new Date(session.submittedAt), 'MMMM d, yyyy h:mm a')}</p>
                  </div>
                )}
                {session.approvedAt && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">
                      Approved At
                    </label>
                    <p>
                      {format(new Date(session.approvedAt), 'MMMM d, yyyy h:mm a')}
                      {session.approvedBy && ` by ${session.approvedBy}`}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={session.notes || ''}
                onChange={e => updateSessionNotes(session.id, e.target.value)}
                placeholder="Add notes about this counting session..."
                className="min-h-[100px]"
                disabled={isReadOnly}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit for Approval</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to submit this counting session for approval?
              Once submitted, you won't be able to modify the counts.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit}>Submit</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Approve Session</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to approve this counting session?
              After approval, it can be finalized to update inventory records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleApprove}>Approve</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject Session</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this counting session?
              It will be returned to draft status for further modifications.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleReject} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Reject
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showFinalizeDialog} onOpenChange={setShowFinalizeDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Finalize Session</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to finalize this counting session?
              This will update the inventory records with the counted quantities.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleFinalize}>
              Finalize & Update Inventory
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default SessionDetail;
