import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { SessionCard } from '@/components/SessionCard';
import { CreateSessionDialog } from '@/components/CreateSessionDialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ClipboardList, CheckCircle, Clock, FileCheck } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { sessions } = useInventory();

  const stats = {
    total: sessions.length,
    draft: sessions.filter(s => s.status === 'draft').length,
    pending: sessions.filter(s => s.status === 'pending_approval').length,
    approved: sessions.filter(s => s.status === 'approved').length,
    completed: sessions.filter(s => s.status === 'completed').length,
  };

  const recentSessions = sessions.slice(0, 6);

  return (
    <div className="page-container">
      <div className="page-header flex items-center justify-between">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-description">Overview of your inventory counting sessions</p>
        </div>
        <CreateSessionDialog />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Sessions
            </CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.total}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Progress
            </CardTitle>
            <Clock className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.draft + stats.pending}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.draft} draft, {stats.pending} pending
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Approved
            </CardTitle>
            <FileCheck className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.approved}</p>
            <p className="text-xs text-muted-foreground mt-1">Ready to finalize</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Completed
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.completed}</p>
            <p className="text-xs text-muted-foreground mt-1">Inventory updated</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sessions */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Recent Sessions</h2>
        {recentSessions.length === 0 ? (
          <Card className="p-8 text-center">
            <ClipboardList className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-medium mb-2">No counting sessions yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Create your first counting session to get started
            </p>
            <CreateSessionDialog />
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentSessions.map(session => (
              <SessionCard key={session.id} session={session} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
