import { Product, CountingSession, CountedProduct } from '@/types/inventory';

export const products: Product[] = [
  { id: 'p1', name: 'Wireless Mouse', sku: 'WM-001', category: 'Electronics', expectedQuantity: 150 },
  { id: 'p2', name: 'Mechanical Keyboard', sku: 'MK-002', category: 'Electronics', expectedQuantity: 80 },
  { id: 'p3', name: 'USB-C Hub', sku: 'UH-003', category: 'Electronics', expectedQuantity: 200 },
  { id: 'p4', name: 'Monitor Stand', sku: 'MS-004', category: 'Furniture', expectedQuantity: 45 },
  { id: 'p5', name: 'Desk Lamp', sku: 'DL-005', category: 'Furniture', expectedQuantity: 60 },
  { id: 'p6', name: 'Webcam HD', sku: 'WC-006', category: 'Electronics', expectedQuantity: 120 },
  { id: 'p7', name: 'Office Chair', sku: 'OC-007', category: 'Furniture', expectedQuantity: 30 },
  { id: 'p8', name: 'Notebook Pack', sku: 'NP-008', category: 'Supplies', expectedQuantity: 500 },
  { id: 'p9', name: 'Pen Set', sku: 'PS-009', category: 'Supplies', expectedQuantity: 300 },
  { id: 'p10', name: 'Headphones', sku: 'HP-010', category: 'Electronics', expectedQuantity: 90 },
];

const createCountedProduct = (product: Product, countedQuantity: number | null): CountedProduct => {
  const variance = countedQuantity !== null ? countedQuantity - product.expectedQuantity : null;
  const variancePercentage = countedQuantity !== null && product.expectedQuantity > 0
    ? ((variance ?? 0) / product.expectedQuantity) * 100
    : null;
  
  return {
    ...product,
    countedQuantity,
    variance,
    variancePercentage,
  };
};

export const initialSessions: CountingSession[] = [
  {
    id: 'session-1',
    name: 'Q1 2026 Warehouse A Count',
    location: 'Warehouse A',
    createdAt: '2026-01-05T09:00:00Z',
    updatedAt: '2026-01-10T14:30:00Z',
    status: 'completed',
    completedAt: '2026-01-10T14:30:00Z',
    approvedAt: '2026-01-09T16:00:00Z',
    approvedBy: 'John Manager',
    products: [
      createCountedProduct(products[0], 148),
      createCountedProduct(products[1], 80),
      createCountedProduct(products[2], 195),
      createCountedProduct(products[3], 45),
      createCountedProduct(products[4], 62),
    ],
    notes: 'Annual Q1 inventory count completed successfully.',
  },
  {
    id: 'session-2',
    name: 'Electronics Section Audit',
    location: 'Warehouse B - Section E',
    createdAt: '2026-01-08T10:00:00Z',
    updatedAt: '2026-01-11T11:00:00Z',
    status: 'approved',
    submittedAt: '2026-01-10T15:00:00Z',
    approvedAt: '2026-01-11T11:00:00Z',
    approvedBy: 'Sarah Director',
    products: [
      createCountedProduct(products[0], 152),
      createCountedProduct(products[1], 78),
      createCountedProduct(products[5], 118),
      createCountedProduct(products[9], 88),
    ],
    notes: 'Electronics section monthly audit.',
  },
  {
    id: 'session-3',
    name: 'Office Supplies Check',
    location: 'Main Office Storage',
    createdAt: '2026-01-10T08:00:00Z',
    updatedAt: '2026-01-11T09:30:00Z',
    status: 'pending_approval',
    submittedAt: '2026-01-11T09:30:00Z',
    products: [
      createCountedProduct(products[7], 485),
      createCountedProduct(products[8], 310),
    ],
    notes: 'Monthly supplies inventory check.',
  },
  {
    id: 'session-4',
    name: 'Furniture Inventory Count',
    location: 'Warehouse C',
    createdAt: '2026-01-11T14:00:00Z',
    updatedAt: '2026-01-11T14:00:00Z',
    status: 'draft',
    products: [
      createCountedProduct(products[3], null),
      createCountedProduct(products[4], 58),
      createCountedProduct(products[6], null),
    ],
    notes: 'In progress - furniture section.',
  },
];
