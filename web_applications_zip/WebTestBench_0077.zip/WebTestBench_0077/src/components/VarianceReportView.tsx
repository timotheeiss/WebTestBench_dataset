import React from 'react';
import { VarianceReport } from '@/types/inventory';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { AlertTriangle, CheckCircle, TrendingDown, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

interface VarianceReportViewProps {
  report: VarianceReport;
}

export const VarianceReportView: React.FC<VarianceReportViewProps> = ({ report }) => {
  const surplusItems = report.items.filter(i => i.varianceType === 'surplus');
  const shortageItems = report.items.filter(i => i.varianceType === 'shortage');
  const accurateItems = report.items.filter(i => i.varianceType === 'none');

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Variance Report</h2>
          <p className="text-sm text-muted-foreground">
            Generated on {format(new Date(report.generatedAt), 'MMMM d, yyyy h:mm a')}
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{report.totalProducts}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Products with Variance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={cn(
              'text-2xl font-bold',
              report.productsWithVariance > 0 ? 'text-warning' : 'text-success'
            )}>
              {report.productsWithVariance}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Expected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{report.totalExpectedValue}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Net Variance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={cn(
              'text-2xl font-bold',
              report.totalVariance > 0 && 'text-variance-positive',
              report.totalVariance < 0 && 'text-variance-negative'
            )}>
              {report.totalVariance > 0 ? '+' : ''}{report.totalVariance}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Variance Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Shortages */}
        <Card className="border-destructive/30">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-destructive" />
              <CardTitle className="text-base">Shortages ({shortageItems.length})</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {shortageItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No shortages detected</p>
            ) : (
              shortageItems.map(item => (
                <div
                  key={item.product.id}
                  className="flex items-center justify-between py-2 border-b last:border-0"
                >
                  <div>
                    <p className="text-sm font-medium">{item.product.name}</p>
                    <p className="text-xs text-muted-foreground">{item.product.sku}</p>
                  </div>
                  <span className="text-sm font-medium text-destructive">
                    {item.product.variance}
                  </span>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Surpluses */}
        <Card className="border-success/30">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-success" />
              <CardTitle className="text-base">Surpluses ({surplusItems.length})</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {surplusItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No surpluses detected</p>
            ) : (
              surplusItems.map(item => (
                <div
                  key={item.product.id}
                  className="flex items-center justify-between py-2 border-b last:border-0"
                >
                  <div>
                    <p className="text-sm font-medium">{item.product.name}</p>
                    <p className="text-xs text-muted-foreground">{item.product.sku}</p>
                  </div>
                  <span className="text-sm font-medium text-success">
                    +{item.product.variance}
                  </span>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Accurate */}
        <Card className="border-info/30">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-info" />
              <CardTitle className="text-base">Accurate ({accurateItems.length})</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {accurateItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No accurate counts</p>
            ) : (
              accurateItems.map(item => (
                <div
                  key={item.product.id}
                  className="flex items-center justify-between py-2 border-b last:border-0"
                >
                  <div>
                    <p className="text-sm font-medium">{item.product.name}</p>
                    <p className="text-xs text-muted-foreground">{item.product.sku}</p>
                  </div>
                  <span className="text-sm font-medium text-muted-foreground">
                    {item.product.countedQuantity}
                  </span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Warning if there are variances */}
      {report.productsWithVariance > 0 && (
        <div className="flex items-start gap-3 p-4 bg-warning/10 border border-warning/30 rounded-lg">
          <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-warning">Review Required</p>
            <p className="text-sm text-muted-foreground mt-1">
              This count has {report.productsWithVariance} product(s) with variances. 
              Please review the discrepancies before submitting for approval.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
