import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { StatusBadge } from '@/components/StatusBadge';
import { CountingSession } from '@/types/inventory';
import { Calendar, MapPin, Package, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface SessionCardProps {
  session: CountingSession;
}

export const SessionCard: React.FC<SessionCardProps> = ({ session }) => {
  const countedProducts = session.products.filter(p => p.countedQuantity !== null).length;
  const totalProducts = session.products.length;
  const progress = totalProducts > 0 ? (countedProducts / totalProducts) * 100 : 0;

  return (
    <Link to={`/sessions/${session.id}`}>
      <Card className="group cursor-pointer transition-all hover:shadow-md hover:border-primary/30">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1 flex-1 min-w-0">
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
                {session.name}
              </h3>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 flex-shrink-0" />
                <span className="truncate">{session.location}</span>
              </div>
            </div>
            <StatusBadge status={session.status} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Package className="h-3.5 w-3.5" />
              <span>{countedProducts} / {totalProducts} counted</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Calendar className="h-3.5 w-3.5" />
              <span>{format(new Date(session.updatedAt), 'MMM d, yyyy')}</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div 
                className="h-full rounded-full bg-primary transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              {progress === 100 ? 'All products counted' : `${Math.round(progress)}% complete`}
            </p>
          </div>

          <div className="flex items-center justify-end text-sm text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
            View details
            <ArrowRight className="ml-1 h-4 w-4" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};
