import React from 'react';
import { CountedProduct } from '@/types/inventory';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface ProductCountTableProps {
  products: CountedProduct[];
  onUpdateCount: (productId: string, count: number | null) => void;
  readonly?: boolean;
}

export const ProductCountTable: React.FC<ProductCountTableProps> = ({
  products,
  onUpdateCount,
  readonly = false,
}) => {
  const handleCountChange = (productId: string, value: string) => {
    if (value === '') {
      onUpdateCount(productId, null);
    } else {
      const count = parseInt(value, 10);
      if (!isNaN(count) && count >= 0) {
        onUpdateCount(productId, count);
      }
    }
  };

  const formatVariance = (variance: number | null) => {
    if (variance === null) return '—';
    if (variance === 0) return '0';
    return variance > 0 ? `+${variance}` : variance.toString();
  };

  const formatPercentage = (percentage: number | null) => {
    if (percentage === null) return '—';
    if (percentage === 0) return '0%';
    const formatted = percentage.toFixed(1);
    return percentage > 0 ? `+${formatted}%` : `${formatted}%`;
  };

  return (
    <div className="border rounded-lg overflow-hidden bg-card">
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              <th className="min-w-[200px]">Product</th>
              <th className="min-w-[100px]">SKU</th>
              <th className="min-w-[100px]">Category</th>
              <th className="min-w-[120px] text-right">Expected Qty</th>
              <th className="min-w-[140px] text-right">Counted Qty</th>
              <th className="min-w-[100px] text-right">Variance</th>
              <th className="min-w-[100px] text-right">Variance %</th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id}>
                <td className="font-medium">{product.name}</td>
                <td className="text-muted-foreground">{product.sku}</td>
                <td className="text-muted-foreground">{product.category}</td>
                <td className="text-right font-medium">{product.expectedQuantity}</td>
                <td className="text-right">
                  {readonly ? (
                    <span className="font-medium">
                      {product.countedQuantity ?? '—'}
                    </span>
                  ) : (
                    <Input
                      type="number"
                      min="0"
                      value={product.countedQuantity ?? ''}
                      onChange={e => handleCountChange(product.id, e.target.value)}
                      className="w-24 ml-auto text-right"
                      placeholder="—"
                    />
                  )}
                </td>
                <td className={cn(
                  'text-right font-medium',
                  product.variance !== null && product.variance > 0 && 'variance-positive',
                  product.variance !== null && product.variance < 0 && 'variance-negative'
                )}>
                  {formatVariance(product.variance)}
                </td>
                <td className={cn(
                  'text-right text-sm',
                  product.variancePercentage !== null && product.variancePercentage > 0 && 'variance-positive',
                  product.variancePercentage !== null && product.variancePercentage < 0 && 'variance-negative'
                )}>
                  {formatPercentage(product.variancePercentage)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
