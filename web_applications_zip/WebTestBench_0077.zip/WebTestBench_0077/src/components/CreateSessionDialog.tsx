import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useInventory } from '@/context/InventoryContext';
import { Plus } from 'lucide-react';
import { toast } from 'sonner';

export const CreateSessionDialog: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const { products, createSession } = useInventory();
  const navigate = useNavigate();

  const handleCreate = () => {
    if (!name.trim()) {
      toast.error('Please enter a session name');
      return;
    }
    if (!location.trim()) {
      toast.error('Please enter a location');
      return;
    }
    if (selectedProducts.length === 0) {
      toast.error('Please select at least one product');
      return;
    }

    const session = createSession(name.trim(), location.trim(), selectedProducts);
    toast.success('Counting session created successfully');
    setOpen(false);
    setName('');
    setLocation('');
    setSelectedProducts([]);
    navigate(`/sessions/${session.id}`);
  };

  const toggleProduct = (productId: string) => {
    setSelectedProducts(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const toggleAll = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(products.map(p => p.id));
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Session
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Create Counting Session</DialogTitle>
          <DialogDescription>
            Set up a new inventory counting session by selecting the products to count.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4 flex-1 overflow-hidden flex flex-col">
          <div className="space-y-2">
            <Label htmlFor="session-name">Session Name</Label>
            <Input
              id="session-name"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g., Q1 2026 Warehouse Count"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="e.g., Warehouse A"
            />
          </div>

          <div className="space-y-2 flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center justify-between">
              <Label>Select Products</Label>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleAll}
                className="text-xs"
              >
                {selectedProducts.length === products.length ? 'Deselect All' : 'Select All'}
              </Button>
            </div>
            <div className="border rounded-lg overflow-y-auto flex-1 min-h-0">
              <div className="divide-y">
                {products.map(product => (
                  <label
                    key={product.id}
                    className="flex items-center gap-3 px-3 py-2.5 hover:bg-muted/50 cursor-pointer"
                  >
                    <Checkbox
                      checked={selectedProducts.includes(product.id)}
                      onCheckedChange={() => toggleProduct(product.id)}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{product.name}</p>
                      <p className="text-xs text-muted-foreground">
                        SKU: {product.sku} • Expected: {product.expectedQuantity}
                      </p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              {selectedProducts.length} of {products.length} products selected
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleCreate}>
            Create Session
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
