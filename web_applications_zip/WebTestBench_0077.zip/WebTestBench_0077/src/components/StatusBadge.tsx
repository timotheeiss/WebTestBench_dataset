import { SessionStatus } from '@/types/inventory';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface StatusBadgeProps {
  status: SessionStatus;
  className?: string;
}

const statusConfig: Record<SessionStatus, { label: string; className: string }> = {
  draft: {
    label: 'Draft',
    className: 'bg-muted text-muted-foreground hover:bg-muted',
  },
  pending_approval: {
    label: 'Pending Approval',
    className: 'bg-warning/15 text-warning border-warning/30 hover:bg-warning/20',
  },
  approved: {
    label: 'Approved',
    className: 'bg-success/15 text-success border-success/30 hover:bg-success/20',
  },
  completed: {
    label: 'Completed',
    className: 'bg-info/15 text-info border-info/30 hover:bg-info/20',
  },
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const config = statusConfig[status];

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'font-medium border',
        config.className,
        className
      )}
    >
      {config.label}
    </Badge>
  );
};
