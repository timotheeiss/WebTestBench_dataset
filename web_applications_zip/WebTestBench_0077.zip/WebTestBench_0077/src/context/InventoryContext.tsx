import React, { createContext, useContext, useState, useCallback } from 'react';
import { CountingSession, CountedProduct, SessionStatus, Product, VarianceReport } from '@/types/inventory';
import { initialSessions, products } from '@/data/mockData';

interface InventoryContextType {
  sessions: CountingSession[];
  products: Product[];
  createSession: (name: string, location: string, selectedProductIds: string[]) => CountingSession;
  updateProductCount: (sessionId: string, productId: string, count: number | null) => void;
  submitForApproval: (sessionId: string) => boolean;
  approveSession: (sessionId: string, approverName: string) => void;
  rejectSession: (sessionId: string) => void;
  finalizeSession: (sessionId: string) => void;
  getSession: (sessionId: string) => CountingSession | undefined;
  generateVarianceReport: (sessionId: string) => VarianceReport | null;
  canGenerateReport: (sessionId: string) => boolean;
  updateSessionNotes: (sessionId: string, notes: string) => void;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sessions, setSessions] = useState<CountingSession[]>(initialSessions);

  const createSession = useCallback((name: string, location: string, selectedProductIds: string[]): CountingSession => {
    const selectedProducts = products
      .filter(p => selectedProductIds.includes(p.id))
      .map(p => ({
        ...p,
        countedQuantity: null,
        variance: null,
        variancePercentage: null,
      }));

    const newSession: CountingSession = {
      id: `session-${Date.now()}`,
      name,
      location,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'draft',
      products: selectedProducts,
    };

    setSessions(prev => [newSession, ...prev]);
    return newSession;
  }, []);

  const updateProductCount = useCallback((sessionId: string, productId: string, count: number | null) => {
    setSessions(prev => prev.map(session => {
      if (session.id !== sessionId || session.status !== 'draft') return session;

      const updatedProducts = session.products.map(product => {
        if (product.id !== productId) return product;

        const variance = count !== null ? count - product.expectedQuantity : null;
        const variancePercentage = count !== null && product.expectedQuantity > 0
          ? (variance! / product.expectedQuantity) * 100
          : null;

        return {
          ...product,
          countedQuantity: count,
          variance,
          variancePercentage,
        };
      });

      return {
        ...session,
        products: updatedProducts,
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  const canGenerateReport = useCallback((sessionId: string): boolean => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return false;
    return session.products.every(p => p.countedQuantity !== null);
  }, [sessions]);

  const submitForApproval = useCallback((sessionId: string): boolean => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session || session.status !== 'draft') return false;
    if (!session.products.every(p => p.countedQuantity !== null)) return false;

    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId) return s;
      return {
        ...s,
        status: 'pending_approval' as SessionStatus,
        submittedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }));
    return true;
  }, [sessions]);

  const approveSession = useCallback((sessionId: string, approverName: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId || s.status !== 'pending_approval') return s;
      return {
        ...s,
        status: 'approved' as SessionStatus,
        approvedAt: new Date().toISOString(),
        approvedBy: approverName,
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  const rejectSession = useCallback((sessionId: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId || s.status !== 'pending_approval') return s;
      return {
        ...s,
        status: 'draft' as SessionStatus,
        submittedAt: undefined,
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  const finalizeSession = useCallback((sessionId: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId || s.status !== 'approved') return s;
      return {
        ...s,
        status: 'completed' as SessionStatus,
        completedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  const getSession = useCallback((sessionId: string) => {
    return sessions.find(s => s.id === sessionId);
  }, [sessions]);

  const generateVarianceReport = useCallback((sessionId: string): VarianceReport | null => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session || !canGenerateReport(sessionId)) return null;

    const items = session.products.map(product => ({
      product,
      varianceType: product.variance === 0 
        ? 'none' as const
        : product.variance! > 0 
          ? 'surplus' as const 
          : 'shortage' as const,
    }));

    const productsWithVariance = items.filter(i => i.varianceType !== 'none').length;
    const totalExpected = session.products.reduce((sum, p) => sum + p.expectedQuantity, 0);
    const totalCounted = session.products.reduce((sum, p) => sum + (p.countedQuantity ?? 0), 0);

    return {
      sessionId: session.id,
      sessionName: session.name,
      generatedAt: new Date().toISOString(),
      totalProducts: session.products.length,
      productsWithVariance,
      totalExpectedValue: totalExpected,
      totalCountedValue: totalCounted,
      totalVariance: totalCounted - totalExpected,
      items,
    };
  }, [sessions, canGenerateReport]);

  const updateSessionNotes = useCallback((sessionId: string, notes: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId || s.status !== 'draft') return s;
      return {
        ...s,
        notes,
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  return (
    <InventoryContext.Provider value={{
      sessions,
      products,
      createSession,
      updateProductCount,
      submitForApproval,
      approveSession,
      rejectSession,
      finalizeSession,
      getSession,
      generateVarianceReport,
      canGenerateReport,
      updateSessionNotes,
    }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};
