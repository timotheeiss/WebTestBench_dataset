export type SessionStatus = 'draft' | 'pending_approval' | 'approved' | 'completed';

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  expectedQuantity: number;
}

export interface CountedProduct extends Product {
  countedQuantity: number | null;
  variance: number | null;
  variancePercentage: number | null;
}

export interface CountingSession {
  id: string;
  name: string;
  location: string;
  createdAt: string;
  updatedAt: string;
  status: SessionStatus;
  products: CountedProduct[];
  notes?: string;
  submittedAt?: string;
  approvedAt?: string;
  approvedBy?: string;
  completedAt?: string;
}

export interface VarianceReport {
  sessionId: string;
  sessionName: string;
  generatedAt: string;
  totalProducts: number;
  productsWithVariance: number;
  totalExpectedValue: number;
  totalCountedValue: number;
  totalVariance: number;
  items: VarianceReportItem[];
}

export interface VarianceReportItem {
  product: CountedProduct;
  varianceType: 'surplus' | 'shortage' | 'none';
}
