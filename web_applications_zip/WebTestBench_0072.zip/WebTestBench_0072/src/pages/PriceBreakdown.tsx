import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/context/SubscriptionContext';
import { Header } from '@/components/Header';
import { StepIndicator, STEPS } from '@/components/StepIndicator';
import { Button } from '@/components/ui/button';
import { CATEGORY_INFO } from '@/data/modules';
import { ArrowLeft, ArrowRight, Check, Users, Calendar, Tag, Receipt } from 'lucide-react';
import { cn } from '@/lib/utils';

const PriceBreakdown: React.FC = () => {
  const navigate = useNavigate();
  const {
    seats,
    seatsConfirmed,
    billingCycle,
    getSelectedModules,
    getPriceBreakdown,
  } = useSubscription();

  const selectedModules = getSelectedModules();
  const breakdown = getPriceBreakdown();

  if (!seatsConfirmed || selectedModules.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <StepIndicator steps={STEPS} currentStep={1} />
          <div className="max-w-2xl mx-auto text-center py-20">
            <h2 className="text-2xl font-display font-bold text-foreground mb-4">
              No Configuration Found
            </h2>
            <p className="text-muted-foreground mb-8">
              Please configure your subscription first by selecting modules and confirming your seat count.
            </p>
            <Button onClick={() => navigate('/')} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Go to Configuration
            </Button>
          </div>
        </main>
      </div>
    );
  }

  const groupedModules = selectedModules.reduce((acc, module) => {
    if (!acc[module.category]) acc[module.category] = [];
    acc[module.category].push(module);
    return acc;
  }, {} as Record<string, typeof selectedModules>);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <StepIndicator steps={STEPS} currentStep={1} />

        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10 animate-slide-up">
            <h1 className="text-3xl font-display font-bold text-foreground mb-3">
              Price Breakdown
            </h1>
            <p className="text-lg text-muted-foreground">
              Review your configuration and pricing details before checkout
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="card-elevated p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Team Size</div>
                <div className="font-semibold">{seats} seats</div>
              </div>
            </div>
            <div className="card-elevated p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-accent" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Billing</div>
                <div className="font-semibold capitalize">{billingCycle}</div>
              </div>
            </div>
            <div className="card-elevated p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
                <Tag className="w-5 h-5 text-success" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Modules</div>
                <div className="font-semibold">{selectedModules.length} selected</div>
              </div>
            </div>
          </div>

          {/* Module Breakdown by Category */}
          <div className="card-elevated-lg p-6 mb-8 animate-slide-up">
            <h2 className="text-lg font-semibold text-foreground mb-6 flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              Module Details
            </h2>

            {Object.entries(groupedModules).map(([category, modules]) => {
              const catInfo = CATEGORY_INFO[category as keyof typeof CATEGORY_INFO];
              return (
                <div key={category} className="mb-6 last:mb-0">
                  <div className="flex items-center gap-2 mb-3">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: catInfo.color }}
                    />
                    <h3 className="font-medium text-foreground">{catInfo.name}</h3>
                  </div>
                  <div className="space-y-3 pl-4">
                    {modules.map((module) => {
                      const moduleBreakdown = breakdown.modules.find(
                        (m) => m.module.id === module.id
                      );
                      return (
                        <div
                          key={module.id}
                          className="flex justify-between items-center py-2 border-b border-border/50 last:border-0"
                        >
                          <div className="flex items-center gap-3">
                            <Check className="w-4 h-4 text-accent" />
                            <div>
                              <div className="font-medium">{module.name}</div>
                              <div className="text-sm text-muted-foreground">
                                ${module.basePrice}/seat × {seats} seats
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">
                              ${moduleBreakdown?.monthlyPrice.toFixed(2)}/mo
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pricing Summary */}
          <div className="card-elevated-lg p-6 mb-8 animate-slide-up">
            <h2 className="text-lg font-semibold text-foreground mb-6">Pricing Summary</h2>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium">${breakdown.subtotal.toFixed(2)}/mo</span>
              </div>

              {breakdown.seatDiscount > 0 && (
                <div className="flex justify-between text-accent">
                  <span className="flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    Volume Discount ({breakdown.seatDiscount}%)
                  </span>
                  <span>-${breakdown.seatDiscountAmount.toFixed(2)}</span>
                </div>
              )}

              {breakdown.annualDiscount > 0 && (
                <div className="flex justify-between text-accent">
                  <span className="flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    Annual Discount ({breakdown.annualDiscount}%)
                  </span>
                  <span>-${breakdown.annualDiscountAmount.toFixed(2)}</span>
                </div>
              )}

              <div className="border-t border-border pt-4 mt-4">
                <div className="flex justify-between items-baseline">
                  <span className="text-lg font-semibold">Total</span>
                  <div className="text-right">
                    <div className="price-highlight text-foreground">
                      ${breakdown.total.toFixed(2)}/mo
                    </div>
                    {billingCycle === 'annual' && (
                      <div className="text-sm text-muted-foreground">
                        ${breakdown.totalAnnual.toFixed(2)} billed annually
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between">
            <Button variant="outline" onClick={() => navigate('/')} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Configure
            </Button>
            <Button onClick={() => navigate('/checkout')} className="btn-gradient gap-2" size="lg">
              Proceed to Checkout
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PriceBreakdown;
