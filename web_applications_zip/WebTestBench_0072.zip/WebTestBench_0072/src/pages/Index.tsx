import React from 'react';
import { CategorySection } from '@/components/CategorySection';
import { SeatsConfigurator } from '@/components/SeatsConfigurator';
import { BillingCycleSelector } from '@/components/BillingCycleSelector';
import { ConfigSummary } from '@/components/ConfigSummary';
import { StepIndicator, STEPS } from '@/components/StepIndicator';
import { Header } from '@/components/Header';
import { ModuleCategory } from '@/data/modules';

const CATEGORIES: ModuleCategory[] = ['sales', 'operations', 'analytics'];

const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <StepIndicator steps={STEPS} currentStep={0} />

        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10 animate-slide-up">
            <h1 className="text-4xl font-display font-bold text-foreground mb-3">
              Build Your Perfect Software Suite
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Select the modules you need, configure your team size, and get instant pricing. 
              All modules work seamlessly together.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Module Selection */}
            <div className="lg:col-span-2 space-y-10">
              {CATEGORIES.map((category) => (
                <CategorySection key={category} category={category} />
              ))}
            </div>

            {/* Right: Configuration Panel */}
            <div className="space-y-6">
              <SeatsConfigurator />
              <BillingCycleSelector />
              <ConfigSummary />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
