import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/context/SubscriptionContext';
import { Header } from '@/components/Header';
import { StepIndicator, STEPS } from '@/components/StepIndicator';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CATEGORY_INFO } from '@/data/modules';
import { 
  ArrowLeft, 
  CreditCard, 
  Lock, 
  Check, 
  Building2, 
  Mail, 
  User,
  FileText,
  Download,
  CheckCircle2
} from 'lucide-react';
import { cn } from '@/lib/utils';

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const {
    seats,
    seatsConfirmed,
    billingCycle,
    getSelectedModules,
    getPriceBreakdown,
    reset,
  } = useSubscription();

  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    email: '',
    fullName: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
  });

  const selectedModules = getSelectedModules();
  const breakdown = getPriceBreakdown();

  const handleInputChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    setIsComplete(true);
  };

  const handleNewSubscription = () => {
    reset();
    navigate('/');
  };

  if (!seatsConfirmed || selectedModules.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <StepIndicator steps={STEPS} currentStep={2} />
          <div className="max-w-2xl mx-auto text-center py-20">
            <h2 className="text-2xl font-display font-bold text-foreground mb-4">
              No Configuration Found
            </h2>
            <p className="text-muted-foreground mb-8">
              Please configure your subscription first.
            </p>
            <Button onClick={() => navigate('/')} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Go to Configuration
            </Button>
          </div>
        </main>
      </div>
    );
  }

  if (isComplete) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <StepIndicator steps={STEPS} currentStep={2} />
          
          <div className="max-w-2xl mx-auto text-center py-12 animate-scale-in">
            <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-success" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground mb-3">
              Subscription Activated!
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Thank you for your purchase. Your subscription is now active and ready to use.
            </p>

            {/* Invoice Summary */}
            <div className="card-elevated-lg p-6 text-left mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Invoice Summary
                </h2>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="w-4 h-4" />
                  Download PDF
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                <div>
                  <div className="text-muted-foreground">Invoice Number</div>
                  <div className="font-medium">INV-{Date.now().toString().slice(-8)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Date</div>
                  <div className="font-medium">{new Date().toLocaleDateString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Company</div>
                  <div className="font-medium">{formData.companyName || 'Your Company'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Billing Cycle</div>
                  <div className="font-medium capitalize">{billingCycle}</div>
                </div>
              </div>

              <div className="border-t border-border pt-4 space-y-2">
                {selectedModules.map((module) => {
                  const mod = breakdown.modules.find((m) => m.module.id === module.id);
                  return (
                    <div key={module.id} className="flex justify-between text-sm">
                      <span>{module.name} × {seats} seats</span>
                      <span>${mod?.monthlyPrice.toFixed(2)}/mo</span>
                    </div>
                  );
                })}
              </div>

              <div className="border-t border-border mt-4 pt-4">
                {breakdown.seatDiscount > 0 && (
                  <div className="flex justify-between text-sm text-accent">
                    <span>Volume Discount</span>
                    <span>-${breakdown.seatDiscountAmount.toFixed(2)}</span>
                  </div>
                )}
                {breakdown.annualDiscount > 0 && (
                  <div className="flex justify-between text-sm text-accent">
                    <span>Annual Discount</span>
                    <span>-${breakdown.annualDiscountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold mt-3">
                  <span>Total</span>
                  <span>
                    ${breakdown.total.toFixed(2)}/mo
                    {billingCycle === 'annual' && (
                      <span className="font-normal text-sm text-muted-foreground ml-2">
                        (${breakdown.totalAnnual.toFixed(2)}/year)
                      </span>
                    )}
                  </span>
                </div>
              </div>
            </div>

            <Button onClick={handleNewSubscription} className="btn-gradient">
              Start New Configuration
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <StepIndicator steps={STEPS} currentStep={2} />

        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10 animate-slide-up">
            <h1 className="text-3xl font-display font-bold text-foreground mb-3">
              Complete Your Purchase
            </h1>
            <p className="text-lg text-muted-foreground">
              Enter your payment details to activate your subscription
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Checkout Form */}
            <div className="lg:col-span-3">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Company Details */}
                <div className="card-elevated p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Building2 className="w-5 h-5" />
                    Company Details
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="companyName">Company Name</Label>
                      <Input
                        id="companyName"
                        placeholder="Acme Corporation"
                        value={formData.companyName}
                        onChange={handleInputChange('companyName')}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fullName">Full Name</Label>
                        <Input
                          id="fullName"
                          placeholder="John Doe"
                          value={formData.fullName}
                          onChange={handleInputChange('fullName')}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="john@acme.com"
                          value={formData.email}
                          onChange={handleInputChange('email')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment Details */}
                <div className="card-elevated p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <CreditCard className="w-5 h-5" />
                    Payment Details
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        placeholder="4242 4242 4242 4242"
                        value={formData.cardNumber}
                        onChange={handleInputChange('cardNumber')}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input
                          id="expiry"
                          placeholder="MM/YY"
                          value={formData.expiry}
                          onChange={handleInputChange('expiry')}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          type="password"
                          placeholder="•••"
                          maxLength={4}
                          value={formData.cvv}
                          onChange={handleInputChange('cvv')}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                    <Lock className="w-4 h-4" />
                    Your payment is secured with 256-bit SSL encryption
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate('/breakdown')}
                    className="gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </Button>
                  <Button
                    type="submit"
                    className="btn-gradient gap-2 min-w-[200px]"
                    size="lg"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        Pay ${billingCycle === 'annual' ? breakdown.totalAnnual.toFixed(2) : breakdown.total.toFixed(2)}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-2">
              <div className="card-elevated-lg p-6 sticky top-24">
                <h2 className="text-lg font-semibold mb-6">Order Summary</h2>

                <div className="space-y-3 mb-6">
                  {selectedModules.map((module) => {
                    const catInfo = CATEGORY_INFO[module.category];
                    return (
                      <div key={module.id} className="flex items-center gap-3">
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: catInfo.color }}
                        />
                        <span className="flex-1 text-sm">{module.name}</span>
                        <Check className="w-4 h-4 text-accent" />
                      </div>
                    );
                  })}
                </div>

                <div className="border-t border-border pt-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{seats} seats</span>
                    <span>${breakdown.subtotal.toFixed(2)}/mo</span>
                  </div>
                  {breakdown.seatDiscount > 0 && (
                    <div className="flex justify-between text-accent">
                      <span>Volume discount</span>
                      <span>-${breakdown.seatDiscountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  {breakdown.annualDiscount > 0 && (
                    <div className="flex justify-between text-accent">
                      <span>Annual discount</span>
                      <span>-${breakdown.annualDiscountAmount.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="border-t border-border mt-4 pt-4">
                  <div className="flex justify-between items-baseline">
                    <span className="font-semibold">Total</span>
                    <div className="text-right">
                      <div className="price-highlight">${breakdown.total.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">
                        {billingCycle === 'monthly' ? '/month' : '/month (billed annually)'}
                      </div>
                    </div>
                  </div>
                  {billingCycle === 'annual' && (
                    <div className="text-sm text-muted-foreground mt-2 text-right">
                      ${breakdown.totalAnnual.toFixed(2)} charged today
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Checkout;
