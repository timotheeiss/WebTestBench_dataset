import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { Module, MODULES, getSeatDiscount, ANNUAL_DISCOUNT_PERCENT } from '@/data/modules';

export type BillingCycle = 'monthly' | 'annual';

interface SubscriptionState {
  selectedModuleIds: string[];
  seats: number;
  seatsConfirmed: boolean;
  billingCycle: BillingCycle;
}

interface PriceBreakdown {
  modules: { module: Module; monthlyPrice: number; totalPrice: number }[];
  subtotal: number;
  seatDiscount: number;
  seatDiscountAmount: number;
  annualDiscount: number;
  annualDiscountAmount: number;
  totalMonthly: number;
  totalAnnual: number;
  total: number;
  perSeatMonthly: number;
}

interface SubscriptionContextType extends SubscriptionState {
  toggleModule: (moduleId: string) => void;
  setSeats: (seats: number) => void;
  confirmSeats: () => void;
  resetSeatsConfirmation: () => void;
  setBillingCycle: (cycle: BillingCycle) => void;
  getSelectedModules: () => Module[];
  getPriceBreakdown: () => PriceBreakdown;
  isModuleSelected: (moduleId: string) => boolean;
  canSelectBillingCycle: boolean;
  reset: () => void;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

const initialState: SubscriptionState = {
  selectedModuleIds: [],
  seats: 1,
  seatsConfirmed: false,
  billingCycle: 'monthly',
};

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<SubscriptionState>(initialState);

  const toggleModule = useCallback((moduleId: string) => {
    setState((prev) => ({
      ...prev,
      selectedModuleIds: prev.selectedModuleIds.includes(moduleId)
        ? prev.selectedModuleIds.filter((id) => id !== moduleId)
        : [...prev.selectedModuleIds, moduleId],
    }));
  }, []);

  const setSeats = useCallback((seats: number) => {
    setState((prev) => ({
      ...prev,
      seats: Math.max(1, Math.min(500, seats)),
      seatsConfirmed: false, // Reset confirmation when seats change
    }));
  }, []);

  const confirmSeats = useCallback(() => {
    setState((prev) => ({ ...prev, seatsConfirmed: true }));
  }, []);

  const resetSeatsConfirmation = useCallback(() => {
    setState((prev) => ({ ...prev, seatsConfirmed: false }));
  }, []);

  const setBillingCycle = useCallback((billingCycle: BillingCycle) => {
    setState((prev) => ({ ...prev, billingCycle }));
  }, []);

  const getSelectedModules = useCallback((): Module[] => {
    return MODULES.filter((m) => state.selectedModuleIds.includes(m.id));
  }, [state.selectedModuleIds]);

  const isModuleSelected = useCallback(
    (moduleId: string): boolean => {
      return state.selectedModuleIds.includes(moduleId);
    },
    [state.selectedModuleIds]
  );

  const getPriceBreakdown = useCallback((): PriceBreakdown => {
    const selectedModules = getSelectedModules();
    const seatDiscount = getSeatDiscount(state.seats);
    const annualDiscount = state.billingCycle === 'annual' ? ANNUAL_DISCOUNT_PERCENT : 0;

    const modules = selectedModules.map((module) => {
      const monthlyPrice = module.basePrice * state.seats;
      let totalPrice = monthlyPrice;

      // Apply seat discount
      totalPrice = totalPrice * (1 - seatDiscount / 100);

      // Apply annual discount if applicable
      if (state.billingCycle === 'annual') {
        totalPrice = totalPrice * (1 - annualDiscount / 100);
      }

      return { module, monthlyPrice, totalPrice };
    });

    const subtotal = modules.reduce((sum, m) => sum + m.monthlyPrice, 0);
    const seatDiscountAmount = subtotal * (seatDiscount / 100);
    const afterSeatDiscount = subtotal - seatDiscountAmount;
    const annualDiscountAmount = state.billingCycle === 'annual' ? afterSeatDiscount * (annualDiscount / 100) : 0;
    const total = afterSeatDiscount - annualDiscountAmount;
    const totalMonthly = total;
    const totalAnnual = total * 12;
    const perSeatMonthly = state.seats > 0 ? total / state.seats : 0;

    return {
      modules,
      subtotal,
      seatDiscount,
      seatDiscountAmount,
      annualDiscount,
      annualDiscountAmount,
      totalMonthly,
      totalAnnual,
      total,
      perSeatMonthly,
    };
  }, [state.seats, state.billingCycle, getSelectedModules]);

  const reset = useCallback(() => {
    setState(initialState);
  }, []);

  const canSelectBillingCycle = state.seatsConfirmed;

  const value = useMemo(
    () => ({
      ...state,
      toggleModule,
      setSeats,
      confirmSeats,
      resetSeatsConfirmation,
      setBillingCycle,
      getSelectedModules,
      getPriceBreakdown,
      isModuleSelected,
      canSelectBillingCycle,
      reset,
    }),
    [
      state,
      toggleModule,
      setSeats,
      confirmSeats,
      resetSeatsConfirmation,
      setBillingCycle,
      getSelectedModules,
      getPriceBreakdown,
      isModuleSelected,
      canSelectBillingCycle,
      reset,
    ]
  );

  return <SubscriptionContext.Provider value={value}>{children}</SubscriptionContext.Provider>;
};

export const useSubscription = (): SubscriptionContextType => {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};
