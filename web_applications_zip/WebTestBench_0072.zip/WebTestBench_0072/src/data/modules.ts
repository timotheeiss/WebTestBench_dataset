export type ModuleCategory = 'sales' | 'operations' | 'analytics';

export interface Module {
  id: string;
  name: string;
  description: string;
  category: ModuleCategory;
  basePrice: number; // monthly price
  icon: string;
  popular?: boolean;
  features: string[];
}

export interface PricingTier {
  minSeats: number;
  maxSeats: number;
  discountPercent: number;
}

export const MODULES: Module[] = [
  // Sales Modules
  {
    id: 'crm',
    name: 'CRM Suite',
    description: 'Complete customer relationship management with lead tracking and pipeline visualization.',
    category: 'sales',
    basePrice: 29,
    icon: 'Users',
    popular: true,
    features: ['Contact management', 'Deal pipeline', 'Email integration', 'Activity tracking'],
  },
  {
    id: 'lead-gen',
    name: 'Lead Generation',
    description: 'Automated lead capture and qualification with smart scoring algorithms.',
    category: 'sales',
    basePrice: 19,
    icon: 'Target',
    features: ['Lead scoring', 'Form builder', 'Landing pages', 'A/B testing'],
  },
  {
    id: 'sales-automation',
    name: 'Sales Automation',
    description: 'Streamline your sales process with automated workflows and sequences.',
    category: 'sales',
    basePrice: 35,
    icon: 'Zap',
    features: ['Email sequences', 'Task automation', 'Follow-up reminders', 'Template library'],
  },
  {
    id: 'quotes',
    name: 'Quotes & Proposals',
    description: 'Create professional quotes and proposals with e-signature capabilities.',
    category: 'sales',
    basePrice: 15,
    icon: 'FileText',
    features: ['Quote templates', 'E-signatures', 'Approval workflows', 'Version control'],
  },

  // Operations Modules
  {
    id: 'project-mgmt',
    name: 'Project Management',
    description: 'Plan, execute, and track projects with Gantt charts and resource allocation.',
    category: 'operations',
    basePrice: 25,
    icon: 'Kanban',
    popular: true,
    features: ['Gantt charts', 'Task dependencies', 'Resource planning', 'Time tracking'],
  },
  {
    id: 'inventory',
    name: 'Inventory Control',
    description: 'Real-time inventory tracking with automated reorder points and warehouse management.',
    category: 'operations',
    basePrice: 22,
    icon: 'Package',
    features: ['Stock tracking', 'Reorder alerts', 'Multi-warehouse', 'Barcode scanning'],
  },
  {
    id: 'workflow',
    name: 'Workflow Builder',
    description: 'Design and automate complex business workflows with a visual drag-and-drop editor.',
    category: 'operations',
    basePrice: 30,
    icon: 'GitBranch',
    features: ['Visual editor', 'Conditional logic', 'Integrations', 'Approval chains'],
  },
  {
    id: 'docs',
    name: 'Document Management',
    description: 'Centralized document storage with version control and collaboration tools.',
    category: 'operations',
    basePrice: 12,
    icon: 'FolderOpen',
    features: ['Cloud storage', 'Version history', 'Sharing controls', 'Full-text search'],
  },

  // Analytics Modules
  {
    id: 'dashboards',
    name: 'Custom Dashboards',
    description: 'Build interactive dashboards with drag-and-drop widgets and real-time data.',
    category: 'analytics',
    basePrice: 28,
    icon: 'LayoutDashboard',
    popular: true,
    features: ['Drag-and-drop', 'Real-time updates', 'Custom widgets', 'Data exports'],
  },
  {
    id: 'reporting',
    name: 'Advanced Reporting',
    description: 'Generate detailed reports with scheduling, custom filters, and automated delivery.',
    category: 'analytics',
    basePrice: 20,
    icon: 'BarChart3',
    features: ['Report builder', 'Scheduled reports', 'Multiple formats', 'Email delivery'],
  },
  {
    id: 'forecasting',
    name: 'AI Forecasting',
    description: 'Predictive analytics powered by machine learning for sales and demand forecasting.',
    category: 'analytics',
    basePrice: 45,
    icon: 'TrendingUp',
    features: ['ML predictions', 'Trend analysis', 'Scenario planning', 'Accuracy tracking'],
  },
  {
    id: 'bi-connect',
    name: 'BI Connectors',
    description: 'Connect to popular BI tools like Tableau, Power BI, and Looker.',
    category: 'analytics',
    basePrice: 18,
    icon: 'Link',
    features: ['Tableau', 'Power BI', 'Looker', 'Custom APIs'],
  },
];

export const CATEGORY_INFO: Record<ModuleCategory, { name: string; description: string; color: string }> = {
  sales: {
    name: 'Sales',
    description: 'Grow revenue with powerful sales tools',
    color: 'hsl(220 70% 45%)',
  },
  operations: {
    name: 'Operations',
    description: 'Streamline your business processes',
    color: 'hsl(280 60% 50%)',
  },
  analytics: {
    name: 'Analytics',
    description: 'Make data-driven decisions',
    color: 'hsl(168 80% 38%)',
  },
};

export const SEAT_PRICING_TIERS: PricingTier[] = [
  { minSeats: 1, maxSeats: 5, discountPercent: 0 },
  { minSeats: 6, maxSeats: 15, discountPercent: 10 },
  { minSeats: 16, maxSeats: 50, discountPercent: 15 },
  { minSeats: 51, maxSeats: 100, discountPercent: 20 },
  { minSeats: 101, maxSeats: Infinity, discountPercent: 25 },
];

export const ANNUAL_DISCOUNT_PERCENT = 20;

export const getModulesByCategory = (category: ModuleCategory): Module[] => {
  return MODULES.filter((m) => m.category === category);
};

export const getSeatDiscount = (seats: number): number => {
  const tier = SEAT_PRICING_TIERS.find((t) => seats >= t.minSeats && seats <= t.maxSeats);
  return tier?.discountPercent || 0;
};
