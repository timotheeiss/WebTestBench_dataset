import React from 'react';
import { ModuleCategory, getModulesByCategory, CATEGORY_INFO } from '@/data/modules';
import { ModuleCard } from './ModuleCard';
import { useSubscription } from '@/context/SubscriptionContext';

interface CategorySectionProps {
  category: ModuleCategory;
}

export const CategorySection: React.FC<CategorySectionProps> = ({ category }) => {
  const { toggleModule, isModuleSelected } = useSubscription();
  const modules = getModulesByCategory(category);
  const categoryInfo = CATEGORY_INFO[category];

  return (
    <section className="animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div
          className="w-1 h-8 rounded-full"
          style={{ backgroundColor: categoryInfo.color }}
        />
        <div>
          <h2 className="text-xl font-display font-semibold text-foreground">{categoryInfo.name}</h2>
          <p className="text-sm text-muted-foreground">{categoryInfo.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {modules.map((module) => (
          <ModuleCard
            key={module.id}
            module={module}
            selected={isModuleSelected(module.id)}
            onToggle={() => toggleModule(module.id)}
          />
        ))}
      </div>
    </section>
  );
};
