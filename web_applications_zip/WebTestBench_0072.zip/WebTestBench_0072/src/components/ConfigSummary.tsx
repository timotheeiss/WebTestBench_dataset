import React from 'react';
import { useSubscription } from '@/context/SubscriptionContext';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, ShoppingCart, AlertCircle } from 'lucide-react';

export const ConfigSummary: React.FC = () => {
  const navigate = useNavigate();
  const {
    selectedModuleIds,
    seats,
    seatsConfirmed,
    billingCycle,
    getPriceBreakdown,
    canSelectBillingCycle,
  } = useSubscription();

  const breakdown = getPriceBreakdown();
  const hasModules = selectedModuleIds.length > 0;
  const isReady = hasModules && seatsConfirmed;

  return (
    <div className="card-elevated-lg p-6 sticky top-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
          <ShoppingCart className="w-5 h-5 text-accent" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Configuration Summary</h3>
          <p className="text-sm text-muted-foreground">{selectedModuleIds.length} module{selectedModuleIds.length !== 1 ? 's' : ''} selected</p>
        </div>
      </div>

      {!hasModules ? (
        <div className="flex items-center gap-3 p-4 bg-muted rounded-lg mb-6">
          <AlertCircle className="w-5 h-5 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Select at least one module to continue</p>
        </div>
      ) : !seatsConfirmed ? (
        <div className="flex items-center gap-3 p-4 bg-muted rounded-lg mb-6">
          <AlertCircle className="w-5 h-5 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Confirm your seat count to see pricing</p>
        </div>
      ) : (
        <div className="space-y-4 mb-6 animate-fade-in">
          {/* Module costs */}
          <div className="space-y-2">
            {breakdown.modules.map(({ module, monthlyPrice }) => (
              <div key={module.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{module.name}</span>
                <span className="font-medium">${monthlyPrice.toFixed(2)}</span>
              </div>
            ))}
          </div>

          <div className="border-t border-border pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal ({seats} seats)</span>
              <span className="font-medium">${breakdown.subtotal.toFixed(2)}</span>
            </div>

            {breakdown.seatDiscount > 0 && (
              <div className="flex justify-between text-sm text-accent">
                <span>Volume discount ({breakdown.seatDiscount}%)</span>
                <span>-${breakdown.seatDiscountAmount.toFixed(2)}</span>
              </div>
            )}

            {breakdown.annualDiscount > 0 && (
              <div className="flex justify-between text-sm text-accent">
                <span>Annual discount ({breakdown.annualDiscount}%)</span>
                <span>-${breakdown.annualDiscountAmount.toFixed(2)}</span>
              </div>
            )}
          </div>

          <div className="border-t border-border pt-4">
            <div className="flex justify-between items-baseline">
              <span className="font-medium">Total</span>
              <div className="text-right">
                <div className="price-highlight text-foreground">${breakdown.total.toFixed(2)}</div>
                <div className="text-sm text-muted-foreground">
                  {billingCycle === 'monthly' ? '/month' : '/month (billed annually)'}
                </div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              ${breakdown.perSeatMonthly.toFixed(2)}/seat/month
            </div>
          </div>
        </div>
      )}

      <Button
        onClick={() => navigate('/breakdown')}
        disabled={!isReady}
        className="w-full btn-gradient gap-2"
        size="lg"
      >
        View Price Breakdown
        <ArrowRight className="w-4 h-4" />
      </Button>
    </div>
  );
};
