import React from 'react';
import { useSubscription } from '@/context/SubscriptionContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Check, Pencil } from 'lucide-react';
import { getSeatDiscount, SEAT_PRICING_TIERS } from '@/data/modules';
import { cn } from '@/lib/utils';

export const SeatsConfigurator: React.FC = () => {
  const { seats, setSeats, seatsConfirmed, confirmSeats, resetSeatsConfirmation } = useSubscription();
  const currentDiscount = getSeatDiscount(seats);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value)) {
      setSeats(value);
    }
  };

  const incrementSeats = (amount: number) => {
    setSeats(seats + amount);
  };

  return (
    <div className="card-elevated p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Users className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Number of Seats</h3>
          <p className="text-sm text-muted-foreground">How many users will need access?</p>
        </div>
      </div>

      {seatsConfirmed ? (
        <div className="flex items-center justify-between bg-accent/10 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
              <Check className="w-4 h-4 text-accent-foreground" />
            </div>
            <div>
              <span className="font-semibold text-foreground">{seats} seats</span>
              {currentDiscount > 0 && (
                <span className="ml-2 text-sm text-accent">({currentDiscount}% volume discount)</span>
              )}
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={resetSeatsConfirmation} className="gap-2">
            <Pencil className="w-4 h-4" />
            Edit
          </Button>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-3 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => incrementSeats(-1)}
              disabled={seats <= 1}
            >
              -
            </Button>
            <Input
              type="number"
              value={seats}
              onChange={handleInputChange}
              className="w-24 text-center font-semibold"
              min={1}
              max={500}
            />
            <Button variant="outline" size="sm" onClick={() => incrementSeats(1)}>
              +
            </Button>
            <div className="flex gap-2 ml-4">
              {[5, 10, 25, 50].map((preset) => (
                <Button
                  key={preset}
                  variant={seats === preset ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSeats(preset)}
                  className="min-w-[3rem]"
                >
                  {preset}
                </Button>
              ))}
            </div>
          </div>

          {/* Volume discount tiers */}
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {SEAT_PRICING_TIERS.map((tier, idx) => {
              const isActive = seats >= tier.minSeats && seats <= tier.maxSeats;
              const maxLabel = tier.maxSeats === Infinity ? '+' : `-${tier.maxSeats}`;
              return (
                <div
                  key={idx}
                  className={cn(
                    'flex-shrink-0 px-3 py-2 rounded-lg border text-sm transition-all',
                    isActive
                      ? 'border-accent bg-accent/10 text-accent'
                      : 'border-border text-muted-foreground'
                  )}
                >
                  <div className="font-medium">
                    {tier.minSeats}{maxLabel} seats
                  </div>
                  <div className="text-xs">
                    {tier.discountPercent > 0 ? `${tier.discountPercent}% off` : 'Standard'}
                  </div>
                </div>
              );
            })}
          </div>

          <Button onClick={confirmSeats} className="w-full btn-gradient">
            Confirm {seats} Seat{seats !== 1 ? 's' : ''}
            {currentDiscount > 0 && ` (${currentDiscount}% discount)`}
          </Button>
        </>
      )}
    </div>
  );
};
