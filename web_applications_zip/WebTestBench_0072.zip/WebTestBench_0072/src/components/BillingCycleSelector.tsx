import React from 'react';
import { useSubscription } from '@/context/SubscriptionContext';
import { ANNUAL_DISCOUNT_PERCENT } from '@/data/modules';
import { cn } from '@/lib/utils';
import { Calendar, CalendarDays, Lock, Sparkles } from 'lucide-react';

export const BillingCycleSelector: React.FC = () => {
  const { billingCycle, setBillingCycle, canSelectBillingCycle } = useSubscription();

  if (!canSelectBillingCycle) {
    return (
      <div className="card-elevated p-6 opacity-75">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
            <Lock className="w-5 h-5 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Billing Cycle</h3>
            <p className="text-sm text-muted-foreground">Confirm seat count first to unlock billing options</p>
          </div>
        </div>
        <div className="flex gap-3">
          <div className="flex-1 p-4 rounded-lg border-2 border-dashed border-border bg-muted/50">
            <div className="text-muted-foreground text-sm text-center">Monthly</div>
          </div>
          <div className="flex-1 p-4 rounded-lg border-2 border-dashed border-border bg-muted/50">
            <div className="text-muted-foreground text-sm text-center">Annual</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card-elevated p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <CalendarDays className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Billing Cycle</h3>
          <p className="text-sm text-muted-foreground">Choose how you'd like to be billed</p>
        </div>
      </div>

      <div className="flex gap-3">
        <button
          onClick={() => setBillingCycle('monthly')}
          className={cn(
            'flex-1 p-4 rounded-lg border-2 transition-all duration-200',
            billingCycle === 'monthly'
              ? 'border-primary bg-primary/5'
              : 'border-border hover:border-muted-foreground/50'
          )}
        >
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4" />
            <span className="font-semibold">Monthly</span>
          </div>
          <p className="text-sm text-muted-foreground">Flexible, pay as you go</p>
        </button>

        <button
          onClick={() => setBillingCycle('annual')}
          className={cn(
            'flex-1 p-4 rounded-lg border-2 transition-all duration-200 relative',
            billingCycle === 'annual'
              ? 'border-accent bg-accent/5'
              : 'border-border hover:border-muted-foreground/50'
          )}
        >
          <div className="absolute -top-2 right-4 flex items-center gap-1 px-2 py-0.5 bg-accent text-accent-foreground text-xs font-medium rounded-full">
            <Sparkles className="w-3 h-3" />
            Save {ANNUAL_DISCOUNT_PERCENT}%
          </div>
          <div className="flex items-center gap-2 mb-2">
            <CalendarDays className="w-4 h-4" />
            <span className="font-semibold">Annual</span>
          </div>
          <p className="text-sm text-muted-foreground">Best value, billed yearly</p>
        </button>
      </div>
    </div>
  );
};
