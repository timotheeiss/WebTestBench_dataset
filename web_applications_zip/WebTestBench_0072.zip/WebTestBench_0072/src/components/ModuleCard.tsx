import React from 'react';
import { Module } from '@/data/modules';
import { Check, Users, Target, Zap, FileText, Kanban, Package, GitBranch, FolderOpen, LayoutDashboard, BarChart3, TrendingUp, Link } from 'lucide-react';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ElementType> = {
  Users,
  Target,
  Zap,
  FileText,
  Kanban,
  Package,
  GitBranch,
  FolderOpen,
  LayoutDashboard,
  BarChart3,
  TrendingUp,
  Link,
};

interface ModuleCardProps {
  module: Module;
  selected: boolean;
  onToggle: () => void;
}

export const ModuleCard: React.FC<ModuleCardProps> = ({ module, selected, onToggle }) => {
  const IconComponent = iconMap[module.icon] || Users;

  return (
    <div
      className={cn('module-card group relative', selected && 'selected')}
      onClick={onToggle}
      role="checkbox"
      aria-checked={selected}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onToggle();
        }
      }}
    >
      {/* Selection indicator */}
      <div
        className={cn(
          'absolute top-3 right-3 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200',
          selected
            ? 'bg-accent border-accent text-accent-foreground'
            : 'border-border bg-background group-hover:border-muted-foreground/50'
        )}
      >
        {selected && <Check className="w-4 h-4" />}
      </div>

      {/* Popular badge */}
      {module.popular && (
        <span className="absolute -top-2 left-4 px-2 py-0.5 bg-primary text-primary-foreground text-xs font-medium rounded-full">
          Popular
        </span>
      )}

      <div className="flex items-start gap-4 pr-8">
        <div
          className={cn(
            'w-12 h-12 rounded-lg flex items-center justify-center transition-colors duration-200',
            selected ? 'bg-accent/20 text-accent' : 'bg-muted text-muted-foreground'
          )}
        >
          <IconComponent className="w-6 h-6" />
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground mb-1">{module.name}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{module.description}</p>

          <div className="flex items-baseline gap-1">
            <span className="text-lg font-bold text-foreground">${module.basePrice}</span>
            <span className="text-sm text-muted-foreground">/seat/mo</span>
          </div>
        </div>
      </div>

      {/* Feature list on hover */}
      <div className="mt-4 pt-4 border-t border-border/50">
        <ul className="grid grid-cols-2 gap-1">
          {module.features.slice(0, 4).map((feature, idx) => (
            <li key={idx} className="text-xs text-muted-foreground flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-accent" />
              {feature}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
