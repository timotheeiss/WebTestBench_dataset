import { Info, AlertTriangle, Lightbulb, Link as LinkIcon } from "lucide-react";
import { DocContent as DocContentType } from "@/data/documentation";
import { cn } from "@/lib/utils";

interface DocContentProps {
  content: DocContentType;
  sectionSlug: string;
}

export function DocContent({ content, sectionSlug }: DocContentProps) {
  const renderContent = () => {
    switch (content.type) {
      case "heading":
        const headingId = `${sectionSlug}-${content.id}`;
        return (
          <h2 id={headingId} className="group flex items-center gap-2 text-2xl font-semibold text-foreground mt-8 mb-4 scroll-mt-24">
            {content.text}
            <a
              href={`#${headingId}`}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label={`Link to ${content.text}`}
            >
              <LinkIcon className="h-4 w-4 text-muted-foreground hover:text-primary" />
            </a>
          </h2>
        );

      case "paragraph":
        return (
          <p className="mb-4 leading-relaxed text-foreground/90">{content.text}</p>
        );

      case "list":
        return (
          <ul className="mb-4 pl-6 list-disc space-y-2">
            {content.items?.map((item, index) => (
              <li key={index} className="text-foreground/90">
                {item}
              </li>
            ))}
          </ul>
        );

      case "code":
        return (
          <pre className="bg-doc-code-bg p-4 rounded-lg overflow-x-auto mb-4 text-sm">
            <code className="font-mono text-foreground/90">{content.text}</code>
          </pre>
        );

      case "note":
        const noteStyles = {
          info: {
            bg: "bg-primary/10 border-primary/30",
            icon: <Info className="h-5 w-5 text-primary" />,
          },
          warning: {
            bg: "bg-warning/10 border-warning/30",
            icon: <AlertTriangle className="h-5 w-5 text-warning" />,
          },
          tip: {
            bg: "bg-success/10 border-success/30",
            icon: <Lightbulb className="h-5 w-5 text-success" />,
          },
        };
        const style = noteStyles[content.noteType || "info"];
        return (
          <div
            className={cn(
              "flex items-start gap-3 p-4 rounded-lg border mb-4",
              style.bg
            )}
          >
            {style.icon}
            <p className="text-foreground/90">{content.text}</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="animate-fade-in" key={content.id}>
      {renderContent()}
    </div>
  );
}
