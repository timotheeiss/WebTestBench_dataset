import { useState, useEffect } from "react";
import { Search, X, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Scenario, searchDocumentation, scenarios } from "@/data/documentation";
import { cn } from "@/lib/utils";

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  scenario: Scenario;
  onNavigate: (sectionSlug: string) => void;
}

export function SearchDialog({
  open,
  onOpenChange,
  scenario,
  onNavigate,
}: SearchDialogProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<ReturnType<typeof searchDocumentation>>([]);

  useEffect(() => {
    if (query.length >= 2) {
      const searchResults = searchDocumentation(query, scenario);
      setResults(searchResults);
    } else {
      setResults([]);
    }
  }, [query, scenario]);

  useEffect(() => {
    if (!open) {
      setQuery("");
      setResults([]);
    }
  }, [open]);

  const handleResultClick = (sectionSlug: string) => {
    onNavigate(sectionSlug);
    onOpenChange(false);
  };

  const highlightMatch = (text: string, query: string) => {
    const lowerText = text.toLowerCase();
    const lowerQuery = query.toLowerCase();
    const index = lowerText.indexOf(lowerQuery);
    
    if (index === -1) return text;
    
    const before = text.slice(0, index);
    const match = text.slice(index, index + query.length);
    const after = text.slice(index + query.length);
    
    return (
      <>
        {before}
        <mark className="bg-primary/30 text-foreground rounded px-0.5">{match}</mark>
        {after}
      </>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] bg-card border-border p-0 gap-0">
        <DialogHeader className="p-4 pb-0">
          <DialogTitle className="sr-only">Search Documentation</DialogTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={`Search in ${scenarios.find((s) => s.value === scenario)?.label} documentation...`}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 pr-10 bg-background border-border"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </DialogHeader>
        
        <div className="max-h-[400px] overflow-y-auto p-4">
          {query.length < 2 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              Type at least 2 characters to search
            </p>
          ) : results.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              No results found for "{query}"
            </p>
          ) : (
            <div className="space-y-2">
              {results.map((result, index) => (
                <button
                  key={`${result.section.id}-${result.content.id}-${index}`}
                  onClick={() => handleResultClick(result.section.slug)}
                  className="w-full text-left p-3 rounded-lg hover:bg-accent transition-colors group"
                >
                  <div className="flex items-start gap-3">
                    <FileText className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                        {result.section.title}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {highlightMatch(result.matchText, query)}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        
        <div className="border-t border-border p-3 text-xs text-muted-foreground flex items-center justify-between">
          <span>Press ESC to close</span>
          <span>{results.length} result{results.length !== 1 ? "s" : ""}</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
