import { Search, ArrowLeftRight, Download, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScenarioSelector } from "./ScenarioSelector";
import { Scenario } from "@/data/documentation";

interface HeaderProps {
  scenario: Scenario;
  onScenarioChange: (scenario: Scenario) => void;
  onSearchOpen: () => void;
  onCompareOpen: () => void;
  onExportPDF: () => void;
}

export function Header({
  scenario,
  onScenarioChange,
  onSearchOpen,
  onCompareOpen,
  onExportPDF,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 border-b border-border">
      <div className="container max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-primary">
            <BookOpen className="h-6 w-6" />
            <span className="font-semibold text-lg text-foreground">ProductDocs</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ScenarioSelector value={scenario} onChange={onScenarioChange} />

          <Button
            variant="outline"
            size="sm"
            onClick={onSearchOpen}
            className="hidden sm:flex items-center gap-2 text-muted-foreground"
          >
            <Search className="h-4 w-4" />
            <span>Search...</span>
            <kbd className="hidden md:inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium">
              ⌘K
            </kbd>
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={onSearchOpen}
            className="sm:hidden"
          >
            <Search className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onCompareOpen}
            className="hidden sm:flex items-center gap-2"
          >
            <ArrowLeftRight className="h-4 w-4" />
            Compare
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={onCompareOpen}
            className="sm:hidden"
          >
            <ArrowLeftRight className="h-4 w-4" />
          </Button>

          <Button
            variant="default"
            size="sm"
            onClick={onExportPDF}
            className="hidden sm:flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export PDF
          </Button>

          <Button
            variant="default"
            size="icon"
            onClick={onExportPDF}
            className="sm:hidden"
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
