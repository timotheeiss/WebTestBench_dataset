import { DocSection as DocSectionType } from "@/data/documentation";
import { DocContent } from "./DocContent";

interface DocSectionProps {
  section: DocSectionType;
}

export function DocSection({ section }: DocSectionProps) {
  return (
    <section
      id={section.slug}
      className="border-b border-doc-section-border pb-8 mb-8 last:border-b-0 animate-fade-in"
    >
      {section.content.map((content) => (
        <DocContent
          key={content.id}
          content={content}
          sectionSlug={section.slug}
        />
      ))}
    </section>
  );
}
