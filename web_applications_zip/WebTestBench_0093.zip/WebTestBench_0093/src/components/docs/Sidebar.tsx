import { DocSection } from "@/data/documentation";
import { cn } from "@/lib/utils";

interface SidebarProps {
  sections: DocSection[];
  activeSection: string;
  onSectionClick: (slug: string) => void;
}

export function Sidebar({ sections, activeSection, onSectionClick }: SidebarProps) {
  return (
    <nav className="sticky top-24 space-y-1">
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
        Documentation
      </h3>
      {sections.map((section) => (
        <button
          key={section.id}
          onClick={() => onSectionClick(section.slug)}
          className={cn(
            "w-full text-left px-3 py-2 rounded-md text-sm transition-colors",
            activeSection === section.slug
              ? "bg-primary text-primary-foreground font-medium"
              : "text-foreground/70 hover:bg-doc-nav-hover hover:text-foreground"
          )}
        >
          {section.title}
        </button>
      ))}
    </nav>
  );
}
