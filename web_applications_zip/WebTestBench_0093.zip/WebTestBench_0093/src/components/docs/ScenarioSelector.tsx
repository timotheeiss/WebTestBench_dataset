import { ChevronDown, Home, Building2, Building } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Scenario, scenarios } from "@/data/documentation";

interface ScenarioSelectorProps {
  value: Scenario;
  onChange: (value: Scenario) => void;
}

const scenarioIcons: Record<Scenario, React.ReactNode> = {
  home: <Home className="h-4 w-4" />,
  business: <Building2 className="h-4 w-4" />,
  enterprise: <Building className="h-4 w-4" />,
};

export function ScenarioSelector({ value, onChange }: ScenarioSelectorProps) {
  return (
    <Select value={value} onValueChange={(v) => onChange(v as Scenario)}>
      <SelectTrigger className="w-[200px] bg-card border-border">
        <SelectValue>
          <div className="flex items-center gap-2">
            {scenarioIcons[value]}
            <span>{scenarios.find((s) => s.value === value)?.label}</span>
          </div>
        </SelectValue>
      </SelectTrigger>
      <SelectContent className="bg-popover border-border">
        {scenarios.map((scenario) => (
          <SelectItem key={scenario.value} value={scenario.value}>
            <div className="flex items-center gap-2">
              {scenarioIcons[scenario.value]}
              <div className="flex flex-col">
                <span className="font-medium">{scenario.label}</span>
                <span className="text-xs text-muted-foreground">
                  {scenario.description}
                </span>
              </div>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
