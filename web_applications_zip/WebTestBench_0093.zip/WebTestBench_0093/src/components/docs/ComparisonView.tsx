import { useState, useRef } from "react";
import { ArrowLeftRight, Download, X, Plus, Minus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Scenario, scenarios, getScenarioDifferences, DocContent } from "@/data/documentation";
import { cn } from "@/lib/utils";

interface ComparisonViewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentScenario: Scenario;
}

export function ComparisonView({
  open,
  onOpenChange,
  currentScenario,
}: ComparisonViewProps) {
  const [scenario1, setScenario1] = useState<Scenario>(currentScenario);
  const [scenario2, setScenario2] = useState<Scenario>(
    scenarios.find((s) => s.value !== currentScenario)?.value || "business"
  );
  const contentRef = useRef<HTMLDivElement>(null);

  const differences = getScenarioDifferences(scenario1, scenario2);

  const renderContentPreview = (content: DocContent) => {
    switch (content.type) {
      case "heading":
        return <span className="font-semibold">{content.text}</span>;
      case "paragraph":
        return <span>{content.text}</span>;
      case "list":
        return (
          <ul className="list-disc pl-4 text-sm">
            {content.items?.slice(0, 3).map((item, i) => (
              <li key={i}>{item}</li>
            ))}
            {(content.items?.length || 0) > 3 && (
              <li className="text-muted-foreground">
                ...and {(content.items?.length || 0) - 3} more items
              </li>
            )}
          </ul>
        );
      case "code":
        return (
          <pre className="text-xs bg-doc-code-bg p-2 rounded overflow-x-auto">
            <code>{content.text?.slice(0, 100)}...</code>
          </pre>
        );
      case "note":
        return (
          <span className="text-sm italic">
            [{content.noteType}] {content.text}
          </span>
        );
      default:
        return null;
    }
  };

  const handleExportPDF = async () => {
    if (!contentRef.current) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const scenario1Label = scenarios.find((s) => s.value === scenario1)?.label;
    const scenario2Label = scenarios.find((s) => s.value === scenario2)?.label;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Comparison: ${scenario1Label} vs ${scenario2Label}</title>
          <style>
            body { font-family: system-ui, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
            h1 { font-size: 24px; margin-bottom: 8px; }
            h2 { font-size: 18px; margin-top: 24px; margin-bottom: 12px; color: #374151; }
            .subtitle { color: #6b7280; margin-bottom: 24px; }
            .diff-item { padding: 12px; margin-bottom: 8px; border-radius: 6px; border-left: 4px solid; }
            .added { background: #ecfdf5; border-color: #10b981; }
            .removed { background: #fef2f2; border-color: #ef4444; }
            .section-title { font-weight: 600; margin-bottom: 4px; }
            .content { font-size: 14px; color: #4b5563; }
            .legend { display: flex; gap: 16px; margin-bottom: 24px; font-size: 14px; }
            .legend-item { display: flex; align-items: center; gap: 6px; }
            .legend-dot { width: 12px; height: 12px; border-radius: 50%; }
            .legend-added { background: #10b981; }
            .legend-removed { background: #ef4444; }
            @media print { body { padding: 20px; } }
          </style>
        </head>
        <body>
          <h1>Documentation Comparison</h1>
          <p class="subtitle">${scenario1Label} vs ${scenario2Label}</p>
          <div class="legend">
            <div class="legend-item"><div class="legend-dot legend-added"></div> Only in ${scenario2Label}</div>
            <div class="legend-item"><div class="legend-dot legend-removed"></div> Only in ${scenario1Label}</div>
          </div>
          ${Array.from(
            new Set(differences.map((d) => d.sectionTitle))
          )
            .map((sectionTitle) => {
              const sectionDiffs = differences.filter(
                (d) => d.sectionTitle === sectionTitle
              );
              return `
                <h2>${sectionTitle}</h2>
                ${sectionDiffs
                  .map((diff) => {
                    const content = diff.scenario1Content || diff.scenario2Content;
                    const contentText = content?.text || content?.items?.join(", ") || "";
                    return `
                      <div class="diff-item ${diff.type}">
                        <div class="section-title">${diff.type === "added" ? "Added in" : "Only in"} ${diff.type === "added" ? scenario2Label : scenario1Label}</div>
                        <div class="content">${contentText}</div>
                      </div>
                    `;
                  })
                  .join("")}
              `;
            })
            .join("")}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.print();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] bg-card border-border max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5 text-primary" />
            Compare Scenarios
          </DialogTitle>
        </DialogHeader>

        <div className="flex items-center gap-4 py-4 flex-shrink-0">
          <Select value={scenario1} onValueChange={(v) => setScenario1(v as Scenario)}>
            <SelectTrigger className="w-[180px] bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              {scenarios.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />

          <Select value={scenario2} onValueChange={(v) => setScenario2(v as Scenario)}>
            <SelectTrigger className="w-[180px] bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              {scenarios.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            size="sm"
            onClick={handleExportPDF}
            className="ml-auto"
          >
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>

        <div className="flex gap-4 text-sm mb-4 flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-comparison-added" />
            <span className="text-muted-foreground">
              Only in {scenarios.find((s) => s.value === scenario2)?.label}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-comparison-removed" />
            <span className="text-muted-foreground">
              Only in {scenarios.find((s) => s.value === scenario1)?.label}
            </span>
          </div>
        </div>

        <div
          ref={contentRef}
          className="flex-1 overflow-y-auto space-y-4 pr-2"
        >
          {differences.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No differences found between these scenarios.
            </p>
          ) : (
            Object.entries(
              differences.reduce((acc, diff) => {
                if (!acc[diff.sectionTitle]) acc[diff.sectionTitle] = [];
                acc[diff.sectionTitle].push(diff);
                return acc;
              }, {} as Record<string, typeof differences>)
            ).map(([sectionTitle, sectionDiffs]) => (
              <div key={sectionTitle} className="border border-border rounded-lg overflow-hidden">
                <div className="bg-muted px-4 py-2 font-medium text-sm">
                  {sectionTitle}
                </div>
                <div className="divide-y divide-border">
                  {sectionDiffs.map((diff, index) => (
                    <div
                      key={`${diff.contentId}-${index}`}
                      className={cn(
                        "px-4 py-3 text-sm",
                        diff.type === "added" && "comparison-added",
                        diff.type === "removed" && "comparison-removed"
                      )}
                    >
                      <div className="flex items-start gap-2">
                        {diff.type === "added" ? (
                          <Plus className="h-4 w-4 text-comparison-added shrink-0 mt-0.5" />
                        ) : (
                          <Minus className="h-4 w-4 text-comparison-removed shrink-0 mt-0.5" />
                        )}
                        <div className="flex-1">
                          {renderContentPreview(
                            diff.scenario1Content || diff.scenario2Content!
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
