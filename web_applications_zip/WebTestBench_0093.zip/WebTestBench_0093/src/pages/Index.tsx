import { useState, useEffect, useCallback, useRef } from "react";
import { Header } from "@/components/docs/Header";
import { Sidebar } from "@/components/docs/Sidebar";
import { DocSection } from "@/components/docs/DocSection";
import { SearchDialog } from "@/components/docs/SearchDialog";
import { ComparisonView } from "@/components/docs/ComparisonView";
import {
  Scenario,
  getFilteredDocumentation,
  scenarios,
} from "@/data/documentation";

const Index = () => {
  const [currentScenario, setCurrentScenario] = useState<Scenario>("home");
  const [activeSection, setActiveSection] = useState<string>("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const mainContentRef = useRef<HTMLDivElement>(null);

  const filteredDocs = getFilteredDocumentation(currentScenario);

  // Set initial active section
  useEffect(() => {
    if (filteredDocs.length > 0 && !activeSection) {
      setActiveSection(filteredDocs[0].slug);
    }
  }, [filteredDocs, activeSection]);

  // Update active section when scenario changes
  useEffect(() => {
    if (filteredDocs.length > 0) {
      const currentSectionExists = filteredDocs.some(
        (s) => s.slug === activeSection
      );
      if (!currentSectionExists) {
        setActiveSection(filteredDocs[0].slug);
      }
    }
  }, [currentScenario, filteredDocs, activeSection]);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Intersection observer for active section
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: "-100px 0px -70% 0px" }
    );

    const sections = document.querySelectorAll("section[id]");
    sections.forEach((section) => observer.observe(section));

    return () => {
      sections.forEach((section) => observer.unobserve(section));
    };
  }, [filteredDocs]);

  const handleSectionClick = useCallback((slug: string) => {
    const element = document.getElementById(slug);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setActiveSection(slug);
    }
  }, []);

  const handleNavigateFromSearch = useCallback((sectionSlug: string) => {
    handleSectionClick(sectionSlug);
  }, [handleSectionClick]);

  const handleExportPDF = useCallback(() => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const scenarioLabel = scenarios.find((s) => s.value === currentScenario)?.label;

    let contentHtml = "";
    filteredDocs.forEach((section) => {
      contentHtml += `<h1 style="font-size: 24px; margin-top: 32px; margin-bottom: 16px; color: #1f2937; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">${section.title}</h1>`;
      section.content.forEach((content) => {
        switch (content.type) {
          case "heading":
            contentHtml += `<h2 style="font-size: 18px; margin-top: 24px; margin-bottom: 12px; color: #374151;">${content.text}</h2>`;
            break;
          case "paragraph":
            contentHtml += `<p style="margin-bottom: 12px; line-height: 1.6; color: #4b5563;">${content.text}</p>`;
            break;
          case "list":
            contentHtml += `<ul style="margin-bottom: 12px; padding-left: 24px;">`;
            content.items?.forEach((item) => {
              contentHtml += `<li style="margin-bottom: 6px; color: #4b5563;">${item}</li>`;
            });
            contentHtml += `</ul>`;
            break;
          case "code":
            contentHtml += `<pre style="background: #f3f4f6; padding: 16px; border-radius: 8px; overflow-x: auto; margin-bottom: 12px; font-family: monospace; font-size: 13px;">${content.text}</pre>`;
            break;
          case "note":
            const bgColor = content.noteType === "warning" ? "#fef3c7" : content.noteType === "tip" ? "#d1fae5" : "#dbeafe";
            const borderColor = content.noteType === "warning" ? "#f59e0b" : content.noteType === "tip" ? "#10b981" : "#3b82f6";
            contentHtml += `<div style="background: ${bgColor}; border-left: 4px solid ${borderColor}; padding: 12px 16px; margin-bottom: 12px; border-radius: 4px;">${content.text}</div>`;
            break;
        }
      });
    });

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Documentation - ${scenarioLabel}</title>
          <style>
            body {
              font-family: system-ui, -apple-system, sans-serif;
              max-width: 800px;
              margin: 0 auto;
              padding: 40px;
              color: #1f2937;
            }
            .header {
              margin-bottom: 32px;
              padding-bottom: 16px;
              border-bottom: 2px solid #e5e7eb;
            }
            .header h1 {
              font-size: 28px;
              margin-bottom: 4px;
            }
            .header p {
              color: #6b7280;
              font-size: 14px;
            }
            @media print {
              body { padding: 20px; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Product Documentation</h1>
            <p>Scenario: ${scenarioLabel} | Generated: ${new Date().toLocaleDateString()}</p>
          </div>
          ${contentHtml}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.print();
  }, [currentScenario, filteredDocs]);

  return (
    <div className="min-h-screen bg-background">
      <Header
        scenario={currentScenario}
        onScenarioChange={setCurrentScenario}
        onSearchOpen={() => setSearchOpen(true)}
        onCompareOpen={() => setCompareOpen(true)}
        onExportPDF={handleExportPDF}
      />

      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <aside className="hidden lg:block w-64 shrink-0">
            <Sidebar
              sections={filteredDocs}
              activeSection={activeSection}
              onSectionClick={handleSectionClick}
            />
          </aside>

          {/* Main Content */}
          <main ref={mainContentRef} className="flex-1 min-w-0 doc-prose">
            {/* Scenario Badge */}
            <div className="mb-8 p-4 bg-doc-highlight-bg rounded-lg border border-primary/20">
              <p className="text-sm text-foreground">
                <span className="font-medium">Currently viewing:</span>{" "}
                {scenarios.find((s) => s.value === currentScenario)?.label} documentation
                <span className="text-muted-foreground">
                  {" "}— {scenarios.find((s) => s.value === currentScenario)?.description}
                </span>
              </p>
            </div>

            {/* Documentation Sections */}
            {filteredDocs.map((section) => (
              <DocSection key={section.id} section={section} />
            ))}

            {filteredDocs.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  No documentation available for this scenario.
                </p>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Search Dialog */}
      <SearchDialog
        open={searchOpen}
        onOpenChange={setSearchOpen}
        scenario={currentScenario}
        onNavigate={handleNavigateFromSearch}
      />

      {/* Comparison View */}
      <ComparisonView
        open={compareOpen}
        onOpenChange={setCompareOpen}
        currentScenario={currentScenario}
      />
    </div>
  );
};

export default Index;
