export type Scenario = "home" | "business" | "enterprise";

export interface DocSection {
  id: string;
  title: string;
  slug: string;
  scenarios: Scenario[];
  content: DocContent[];
}

export interface DocContent {
  id: string;
  type: "heading" | "paragraph" | "list" | "code" | "note";
  text?: string;
  items?: string[];
  language?: string;
  noteType?: "info" | "warning" | "tip";
  scenarios?: Scenario[]; // If specified, only show for these scenarios
}

export const scenarios: { value: Scenario; label: string; description: string }[] = [
  { value: "home", label: "Home Use", description: "Personal and family usage" },
  { value: "business", label: "Business Use", description: "Small to medium businesses" },
  { value: "enterprise", label: "Enterprise", description: "Large organizations" },
];

export const documentation: DocSection[] = [
  {
    id: "getting-started",
    title: "Getting Started",
    slug: "getting-started",
    scenarios: ["home", "business", "enterprise"],
    content: [
      { id: "gs-1", type: "heading", text: "Getting Started" },
      { id: "gs-2", type: "paragraph", text: "Welcome to our product documentation. This guide will help you set up and start using the product quickly and efficiently." },
      { id: "gs-3", type: "heading", text: "System Requirements" },
      {
        id: "gs-4",
        type: "list",
        items: ["Operating System: Windows 10+, macOS 11+, or Linux (Ubuntu 20.04+)", "RAM: 4GB minimum (8GB recommended)", "Storage: 500MB available space"],
        scenarios: ["home"],
      },
      {
        id: "gs-5",
        type: "list",
        items: ["Operating System: Windows 10+ Pro, macOS 11+, or Linux Server", "RAM: 8GB minimum (16GB recommended)", "Storage: 2GB available space", "Network: Stable internet connection for cloud sync"],
        scenarios: ["business"],
      },
      {
        id: "gs-6",
        type: "list",
        items: ["Operating System: Windows Server 2019+, RHEL 8+, or Ubuntu Server 20.04+", "RAM: 32GB minimum", "Storage: 50GB SSD (scalable)", "Network: Dedicated network infrastructure", "Security: SSL certificates required"],
        scenarios: ["enterprise"],
      },
      { id: "gs-7", type: "heading", text: "Installation" },
      { id: "gs-8", type: "paragraph", text: "Download the installer from our website and follow the setup wizard.", scenarios: ["home"] },
      { id: "gs-9", type: "paragraph", text: "Contact your IT administrator for the deployment package and follow corporate installation guidelines.", scenarios: ["business", "enterprise"] },
      {
        id: "gs-10",
        type: "code",
        text: "# Quick install command\ncurl -sSL https://install.example.com | bash",
        language: "bash",
        scenarios: ["home"],
      },
      {
        id: "gs-11",
        type: "code",
        text: "# Enterprise deployment\ndocker pull example/product:enterprise\ndocker-compose up -d",
        language: "bash",
        scenarios: ["enterprise"],
      },
      {
        id: "gs-12",
        type: "note",
        text: "For home users, the free tier includes all basic features.",
        noteType: "tip",
        scenarios: ["home"],
      },
      {
        id: "gs-13",
        type: "note",
        text: "Business licenses require activation. Contact sales@example.com for licensing.",
        noteType: "info",
        scenarios: ["business"],
      },
      {
        id: "gs-14",
        type: "note",
        text: "Enterprise deployments require a dedicated onboarding session. Schedule with your account manager.",
        noteType: "warning",
        scenarios: ["enterprise"],
      },
    ],
  },
  {
    id: "configuration",
    title: "Configuration",
    slug: "configuration",
    scenarios: ["home", "business", "enterprise"],
    content: [
      { id: "cfg-1", type: "heading", text: "Configuration" },
      { id: "cfg-2", type: "paragraph", text: "Configure the product to match your specific needs and environment." },
      { id: "cfg-3", type: "heading", text: "Basic Settings" },
      {
        id: "cfg-4",
        type: "list",
        items: ["Language and region preferences", "Notification settings", "Theme and appearance", "Auto-update preferences"],
        scenarios: ["home"],
      },
      {
        id: "cfg-5",
        type: "list",
        items: ["Organization profile setup", "Team member management", "Permission levels", "Branding customization", "Integration settings"],
        scenarios: ["business"],
      },
      {
        id: "cfg-6",
        type: "list",
        items: ["Multi-tenant configuration", "SSO/SAML integration", "Active Directory sync", "Compliance settings (GDPR, HIPAA)", "Audit logging configuration", "Custom API endpoints"],
        scenarios: ["enterprise"],
      },
      { id: "cfg-7", type: "heading", text: "Network Configuration", scenarios: ["business", "enterprise"] },
      {
        id: "cfg-8",
        type: "paragraph",
        text: "Configure proxy settings and firewall rules for secure connectivity.",
        scenarios: ["business", "enterprise"],
      },
      {
        id: "cfg-9",
        type: "code",
        text: '# config.yaml\nnetwork:\n  proxy: "http://proxy.company.com:8080"\n  allowed_domains:\n    - "*.example.com"\n    - "api.example.com"',
        language: "yaml",
        scenarios: ["business", "enterprise"],
      },
      { id: "cfg-10", type: "heading", text: "High Availability Setup", scenarios: ["enterprise"] },
      {
        id: "cfg-11",
        type: "paragraph",
        text: "Enterprise deployments support clustering for high availability and load balancing.",
        scenarios: ["enterprise"],
      },
      {
        id: "cfg-12",
        type: "code",
        text: '# cluster-config.yaml\ncluster:\n  nodes: 3\n  load_balancer: "nginx"\n  failover: automatic\n  health_check_interval: 30s',
        language: "yaml",
        scenarios: ["enterprise"],
      },
    ],
  },
  {
    id: "troubleshooting",
    title: "Troubleshooting",
    slug: "troubleshooting",
    scenarios: ["home", "business", "enterprise"],
    content: [
      { id: "ts-1", type: "heading", text: "Troubleshooting" },
      { id: "ts-2", type: "paragraph", text: "Common issues and their solutions to help you resolve problems quickly." },
      { id: "ts-3", type: "heading", text: "Connection Issues" },
      {
        id: "ts-4",
        type: "list",
        items: ["Check your internet connection", "Verify the server is reachable", "Restart the application", "Clear local cache"],
        scenarios: ["home"],
      },
      {
        id: "ts-5",
        type: "list",
        items: ["Verify corporate proxy settings", "Check firewall rules", "Validate SSL certificates", "Review network logs", "Contact IT support for network issues"],
        scenarios: ["business", "enterprise"],
      },
      { id: "ts-6", type: "heading", text: "Performance Issues" },
      {
        id: "ts-7",
        type: "paragraph",
        text: "If the application runs slowly, try closing other applications and restarting.",
        scenarios: ["home"],
      },
      {
        id: "ts-8",
        type: "paragraph",
        text: "Monitor system resources and consider scaling infrastructure. Check database query performance and optimize indexes.",
        scenarios: ["business", "enterprise"],
      },
      {
        id: "ts-9",
        type: "code",
        text: "# Check system resources\ntop -c\n\n# View application logs\ntail -f /var/log/app/error.log",
        language: "bash",
        scenarios: ["enterprise"],
      },
      { id: "ts-10", type: "heading", text: "Getting Help" },
      {
        id: "ts-11",
        type: "note",
        text: "For home users, visit our community forum at community.example.com",
        noteType: "tip",
        scenarios: ["home"],
      },
      {
        id: "ts-12",
        type: "note",
        text: "Business customers have access to email support: support@example.com (24-48h response)",
        noteType: "info",
        scenarios: ["business"],
      },
      {
        id: "ts-13",
        type: "note",
        text: "Enterprise customers have 24/7 phone support: +1-800-555-0199 and a dedicated support portal.",
        noteType: "info",
        scenarios: ["enterprise"],
      },
    ],
  },
  {
    id: "advanced-features",
    title: "Advanced Features",
    slug: "advanced-features",
    scenarios: ["business", "enterprise"],
    content: [
      { id: "af-1", type: "heading", text: "Advanced Features" },
      { id: "af-2", type: "paragraph", text: "Explore powerful features designed for professional and enterprise use cases." },
      { id: "af-3", type: "heading", text: "API Integration" },
      {
        id: "af-4",
        type: "paragraph",
        text: "Connect with third-party services using our REST API. Rate limits apply based on your plan.",
        scenarios: ["business"],
      },
      {
        id: "af-5",
        type: "paragraph",
        text: "Full API access with custom rate limits, webhooks, and GraphQL support for enterprise integrations.",
        scenarios: ["enterprise"],
      },
      {
        id: "af-6",
        type: "code",
        text: '// API Example\nconst response = await fetch("https://api.example.com/v2/data", {\n  headers: { "Authorization": `Bearer ${API_KEY}` }\n});\nconst data = await response.json();',
        language: "javascript",
      },
      { id: "af-7", type: "heading", text: "Automation & Workflows", scenarios: ["business", "enterprise"] },
      {
        id: "af-8",
        type: "list",
        items: ["Scheduled tasks and reports", "Email notifications", "Basic workflow automation"],
        scenarios: ["business"],
      },
      {
        id: "af-9",
        type: "list",
        items: ["Advanced workflow builder", "Custom triggers and actions", "Integration with CI/CD pipelines", "Scripting support (Python, JavaScript)", "Event-driven architecture"],
        scenarios: ["enterprise"],
      },
      { id: "af-10", type: "heading", text: "Analytics & Reporting", scenarios: ["enterprise"] },
      {
        id: "af-11",
        type: "paragraph",
        text: "Enterprise customers have access to advanced analytics dashboards, custom reports, and data export capabilities.",
        scenarios: ["enterprise"],
      },
      {
        id: "af-12",
        type: "list",
        items: ["Real-time analytics dashboard", "Custom report builder", "Data warehouse integration", "Predictive analytics (AI-powered)", "Compliance reporting"],
        scenarios: ["enterprise"],
      },
    ],
  },
  {
    id: "security",
    title: "Security",
    slug: "security",
    scenarios: ["business", "enterprise"],
    content: [
      { id: "sec-1", type: "heading", text: "Security" },
      { id: "sec-2", type: "paragraph", text: "Security features and best practices to protect your data." },
      { id: "sec-3", type: "heading", text: "Authentication" },
      {
        id: "sec-4",
        type: "list",
        items: ["Two-factor authentication (2FA)", "Password policies", "Session management", "IP allowlisting"],
        scenarios: ["business"],
      },
      {
        id: "sec-5",
        type: "list",
        items: ["SSO/SAML 2.0 integration", "LDAP/Active Directory sync", "Multi-factor authentication (MFA)", "Certificate-based authentication", "Zero-trust security model"],
        scenarios: ["enterprise"],
      },
      { id: "sec-6", type: "heading", text: "Data Protection" },
      {
        id: "sec-7",
        type: "paragraph",
        text: "All data is encrypted at rest using AES-256 and in transit using TLS 1.3.",
      },
      {
        id: "sec-8",
        type: "list",
        items: ["Encryption at rest (AES-256)", "Encryption in transit (TLS 1.3)", "Regular security audits", "Data backup and recovery"],
        scenarios: ["business"],
      },
      {
        id: "sec-9",
        type: "list",
        items: ["Customer-managed encryption keys (BYOK)", "Hardware security modules (HSM)", "Data residency controls", "Automated threat detection", "Penetration testing reports available"],
        scenarios: ["enterprise"],
      },
      { id: "sec-10", type: "heading", text: "Compliance", scenarios: ["enterprise"] },
      {
        id: "sec-11",
        type: "note",
        text: "Enterprise tier includes SOC 2 Type II, ISO 27001, GDPR, and HIPAA compliance certifications.",
        noteType: "info",
        scenarios: ["enterprise"],
      },
    ],
  },
  {
    id: "backup-recovery",
    title: "Backup & Recovery",
    slug: "backup-recovery",
    scenarios: ["home", "business", "enterprise"],
    content: [
      { id: "br-1", type: "heading", text: "Backup & Recovery" },
      { id: "br-2", type: "paragraph", text: "Protect your data with comprehensive backup and recovery options." },
      { id: "br-3", type: "heading", text: "Backup Options" },
      {
        id: "br-4",
        type: "list",
        items: ["Local backup to external drive", "Cloud sync (5GB free)", "Manual export to file"],
        scenarios: ["home"],
      },
      {
        id: "br-5",
        type: "list",
        items: ["Automated daily backups", "Cloud storage (100GB included)", "Version history (30 days)", "Cross-region replication"],
        scenarios: ["business"],
      },
      {
        id: "br-6",
        type: "list",
        items: ["Real-time continuous backup", "Unlimited cloud storage", "Version history (unlimited)", "Multi-region disaster recovery", "Point-in-time recovery", "Bare-metal restore capability"],
        scenarios: ["enterprise"],
      },
      { id: "br-7", type: "heading", text: "Recovery Procedures" },
      {
        id: "br-8",
        type: "paragraph",
        text: "To restore from backup, go to Settings > Backup > Restore and select your backup file.",
        scenarios: ["home"],
      },
      {
        id: "br-9",
        type: "paragraph",
        text: "Business administrators can initiate recovery from the admin console. Recovery typically completes within 1-4 hours.",
        scenarios: ["business"],
      },
      {
        id: "br-10",
        type: "paragraph",
        text: "Enterprise recovery is managed through the disaster recovery portal. Our SLA guarantees 99.99% uptime with RTO of 15 minutes.",
        scenarios: ["enterprise"],
      },
      {
        id: "br-11",
        type: "note",
        text: "Enterprise customers receive dedicated support during recovery operations.",
        noteType: "tip",
        scenarios: ["enterprise"],
      },
    ],
  },
];

export function getFilteredDocumentation(scenario: Scenario): DocSection[] {
  return documentation
    .filter((section) => section.scenarios.includes(scenario))
    .map((section) => ({
      ...section,
      content: section.content.filter(
        (content) => !content.scenarios || content.scenarios.includes(scenario)
      ),
    }));
}

export function getScenarioDifferences(scenario1: Scenario, scenario2: Scenario) {
  const differences: {
    sectionId: string;
    sectionTitle: string;
    type: "added" | "removed" | "changed";
    contentId: string;
    scenario1Content?: DocContent;
    scenario2Content?: DocContent;
  }[] = [];

  documentation.forEach((section) => {
    const inScenario1 = section.scenarios.includes(scenario1);
    const inScenario2 = section.scenarios.includes(scenario2);

    if (inScenario1 && !inScenario2) {
      section.content.forEach((content) => {
        if (!content.scenarios || content.scenarios.includes(scenario1)) {
          differences.push({
            sectionId: section.id,
            sectionTitle: section.title,
            type: "removed",
            contentId: content.id,
            scenario1Content: content,
          });
        }
      });
    } else if (!inScenario1 && inScenario2) {
      section.content.forEach((content) => {
        if (!content.scenarios || content.scenarios.includes(scenario2)) {
          differences.push({
            sectionId: section.id,
            sectionTitle: section.title,
            type: "added",
            contentId: content.id,
            scenario2Content: content,
          });
        }
      });
    } else if (inScenario1 && inScenario2) {
      section.content.forEach((content) => {
        const inContent1 = !content.scenarios || content.scenarios.includes(scenario1);
        const inContent2 = !content.scenarios || content.scenarios.includes(scenario2);

        if (inContent1 && !inContent2) {
          differences.push({
            sectionId: section.id,
            sectionTitle: section.title,
            type: "removed",
            contentId: content.id,
            scenario1Content: content,
          });
        } else if (!inContent1 && inContent2) {
          differences.push({
            sectionId: section.id,
            sectionTitle: section.title,
            type: "added",
            contentId: content.id,
            scenario2Content: content,
          });
        }
      });
    }
  });

  return differences;
}

export function searchDocumentation(query: string, scenario: Scenario): { section: DocSection; content: DocContent; matchText: string }[] {
  const results: { section: DocSection; content: DocContent; matchText: string }[] = [];
  const lowerQuery = query.toLowerCase();
  const filteredDocs = getFilteredDocumentation(scenario);

  filteredDocs.forEach((section) => {
    section.content.forEach((content) => {
      let matchText = "";
      
      if (content.text && content.text.toLowerCase().includes(lowerQuery)) {
        matchText = content.text;
      } else if (content.items) {
        const matchingItem = content.items.find((item) => item.toLowerCase().includes(lowerQuery));
        if (matchingItem) {
          matchText = matchingItem;
        }
      }

      if (matchText) {
        results.push({ section, content, matchText });
      }
    });
  });

  return results;
}
