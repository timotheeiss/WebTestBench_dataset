export const sampleContracts = [
  {
    name: "TechVentures SaaS Agreement",
    text: `SOFTWARE AS A SERVICE AGREEMENT

1. Payment Terms
Client shall pay Provider a monthly subscription fee of $2,500 USD, due on the first day of each month. Late payments shall incur a penalty of 1.5% per month. All fees are non-refundable unless otherwise stated in this agreement.

2. Confidentiality
Both parties agree to maintain strict confidentiality of all proprietary information shared during the term of this agreement. Confidential information includes, but is not limited to, business strategies, customer data, technical specifications, and trade secrets. This obligation survives termination for a period of 3 years.

3. Termination
Either party may terminate this agreement with 30 days written notice. Provider may terminate immediately if Client fails to make payment within 15 days of the due date. Upon termination, Client shall lose access to all services and data export must be completed within 14 days.

4. Limitation of Liability
In no event shall Provider be liable for any indirect, incidental, special, or consequential damages. Provider's total liability shall not exceed the fees paid by Client in the 12 months preceding the claim. This limitation applies regardless of the theory of liability.

5. Intellectual Property
All intellectual property developed by Provider remains the sole property of Provider. Client retains ownership of their data but grants Provider a limited license to process such data for service delivery purposes.

6. Dispute Resolution
Any disputes arising from this agreement shall be resolved through binding arbitration in San Francisco, California. The arbitration shall be conducted under AAA Commercial Arbitration Rules.`
  },
  {
    name: "GlobalCorp Enterprise License",
    text: `ENTERPRISE SOFTWARE LICENSE AGREEMENT

1. Payment and Fees
Licensee agrees to pay an annual license fee of $150,000 USD, payable in quarterly installments of $37,500. Payment is due within 30 days of invoice date. Failure to pay within 60 days constitutes a material breach.

2. Confidentiality Agreement
Licensee acknowledges that the Software and all related documentation constitute confidential and proprietary information of Licensor. Licensee shall protect such information using the same degree of care used to protect its own confidential information, but in no event less than reasonable care. This obligation extends for 5 years post-termination.

3. Term and Termination
This agreement has an initial term of 3 years with automatic annual renewals. Either party may terminate for cause with 60 days written notice. Licensor may terminate immediately for any unauthorized use or breach of confidentiality. Licensee must destroy all copies upon termination.

4. Liability and Warranties
LICENSOR PROVIDES THE SOFTWARE "AS IS" WITHOUT WARRANTY OF ANY KIND. Licensor's maximum liability is limited to direct damages not exceeding the license fees paid in the current year. Neither party shall be liable for lost profits, data, or business opportunities.

5. Indemnification
Licensor shall indemnify and hold harmless Licensee against any third-party claims alleging that the Software infringes any patent or copyright. Licensee shall indemnify Licensor against claims arising from Licensee's use of the Software.

6. Intellectual Property Rights
The Software, including all modifications and derivative works, remains the exclusive property of Licensor. Licensee receives only a limited, non-exclusive, non-transferable license to use the Software.

7. Governing Law and Jurisdiction
This agreement shall be governed by the laws of Delaware. Any legal proceedings shall be conducted in the federal or state courts of Delaware. Both parties consent to personal jurisdiction in such courts.`
  },
  {
    name: "StartupX Consulting Agreement",
    text: `CONSULTING SERVICES AGREEMENT

1. Compensation Terms
Consultant shall be compensated at a rate of $200 per hour for all services rendered. Invoices shall be submitted monthly and payment is due within 15 days. Expenses over $100 require prior written approval. Travel expenses shall be reimbursed at cost.

2. Confidentiality Obligations
Consultant agrees to maintain the confidentiality of all Client information and trade secrets. This includes business plans, financial information, customer lists, and technical data. Consultant shall not disclose such information to any third party without written consent. Confidentiality obligations survive for 2 years after termination.

3. Termination Rights
Either party may terminate this agreement at any time with 14 days written notice. Client may terminate immediately for cause, including breach of confidentiality. Upon termination, Consultant shall return all Client materials and deliver all work product completed to date.

4. Limitation of Liability Clause
Consultant's liability shall be limited to the fees paid under this agreement in the 6 months prior to any claim. In no event shall Consultant be liable for consequential, punitive, or special damages. Client acknowledges that services are advisory in nature.

5. Indemnification Provisions
Client shall indemnify Consultant against any claims arising from Client's use of deliverables. Consultant shall indemnify Client against claims of third-party intellectual property infringement related to Consultant's pre-existing materials.

6. Work Product and IP
All work product created by Consultant specifically for Client shall be owned by Client upon full payment. Consultant retains rights to general knowledge, skills, and pre-existing materials.

7. Dispute Resolution Process
Disputes shall first be addressed through good-faith negotiation. If unresolved within 30 days, disputes shall be submitted to mediation. If mediation fails, the matter shall proceed to arbitration in New York under JAMS rules.`
  }
];
