export type ClauseType = 
  | 'payment'
  | 'confidentiality'
  | 'termination'
  | 'liability'
  | 'indemnification'
  | 'dispute'
  | 'intellectual'
  | 'general';

export interface Clause {
  id: string;
  type: ClauseType;
  title: string;
  content: string;
  contractId: string;
  contractName: string;
}

export interface Contract {
  id: string;
  name: string;
  text: string;
  clauses: Clause[];
}

export interface ClauseGroup {
  type: ClauseType;
  clauses: Clause[];
}

const clausePatterns: Record<ClauseType, RegExp[]> = {
  payment: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:payment|compensation|fees|pricing|invoic|billing)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:shall pay|payment terms|payment schedule)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  confidentiality: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:confidential|non-disclosure|proprietary|trade secret)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:nda|confidentiality agreement)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  termination: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:termination|term and termination|cancellation)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:may terminate|right to terminate|termination for cause)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  liability: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:limitation of liability|liability|damages|warranty disclaimer)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:shall not be liable|no liability|limit.*liability)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  indemnification: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:indemnif|hold harmless|defend and indemnify)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  dispute: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:dispute resolution|arbitration|mediation|governing law|jurisdiction)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:legal proceedings|court|venue)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  intellectual: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:intellectual property|ip rights|copyright|trademark|patent)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
    /(?:^|\n)(?:\d+\.?\s*)?(?:ownership of work|work product|deliverables ownership)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
  general: [
    /(?:^|\n)(?:\d+\.?\s*)?(?:general provisions|miscellaneous|entire agreement|amendment|waiver|severability|notices)[^\n]*(?:\n(?![A-Z\d])[^\n]*)*/gi,
  ],
};

export const clauseTypeLabels: Record<ClauseType, string> = {
  payment: 'Payment Terms',
  confidentiality: 'Confidentiality',
  termination: 'Termination',
  liability: 'Liability',
  indemnification: 'Indemnification',
  dispute: 'Dispute Resolution',
  intellectual: 'Intellectual Property',
  general: 'General Provisions',
};

export function detectClauses(contract: { id: string; name: string; text: string }): Clause[] {
  const clauses: Clause[] = [];
  const usedRanges: { start: number; end: number }[] = [];

  const isOverlapping = (start: number, end: number): boolean => {
    return usedRanges.some(range => 
      (start >= range.start && start < range.end) ||
      (end > range.start && end <= range.end) ||
      (start <= range.start && end >= range.end)
    );
  };

  for (const [type, patterns] of Object.entries(clausePatterns) as [ClauseType, RegExp[]][]) {
    for (const pattern of patterns) {
      const regex = new RegExp(pattern.source, pattern.flags);
      let match;
      
      while ((match = regex.exec(contract.text)) !== null) {
        const start = match.index;
        const end = start + match[0].length;
        
        if (!isOverlapping(start, end) && match[0].trim().length > 20) {
          usedRanges.push({ start, end });
          
          const content = match[0].trim();
          const firstLine = content.split('\n')[0];
          const title = firstLine.length > 60 
            ? firstLine.substring(0, 60) + '...' 
            : firstLine;

          clauses.push({
            id: `${contract.id}-${type}-${clauses.length}`,
            type,
            title: title.replace(/^\d+\.?\s*/, ''),
            content,
            contractId: contract.id,
            contractName: contract.name,
          });
        }
      }
    }
  }

  return clauses.sort((a, b) => {
    const typeOrder = Object.keys(clausePatterns);
    return typeOrder.indexOf(a.type) - typeOrder.indexOf(b.type);
  });
}

export function groupClausesByType(contracts: Contract[]): ClauseGroup[] {
  const groups: Map<ClauseType, Clause[]> = new Map();

  for (const contract of contracts) {
    for (const clause of contract.clauses) {
      const existing = groups.get(clause.type) || [];
      existing.push(clause);
      groups.set(clause.type, existing);
    }
  }

  return Array.from(groups.entries()).map(([type, clauses]) => ({
    type,
    clauses,
  }));
}

export function computeDiff(text1: string, text2: string): { word: string; type: 'match' | 'different' | 'missing' }[][] {
  const words1 = text1.toLowerCase().split(/\s+/);
  const words2 = text2.toLowerCase().split(/\s+/);
  const originalWords1 = text1.split(/\s+/);
  const originalWords2 = text2.split(/\s+/);

  const result1: { word: string; type: 'match' | 'different' | 'missing' }[] = [];
  const result2: { word: string; type: 'match' | 'different' | 'missing' }[] = [];

  const set2 = new Set(words2);
  const set1 = new Set(words1);

  for (let i = 0; i < originalWords1.length; i++) {
    if (set2.has(words1[i])) {
      result1.push({ word: originalWords1[i], type: 'match' });
    } else {
      result1.push({ word: originalWords1[i], type: 'different' });
    }
  }

  for (let i = 0; i < originalWords2.length; i++) {
    if (set1.has(words2[i])) {
      result2.push({ word: originalWords2[i], type: 'match' });
    } else {
      result2.push({ word: originalWords2[i], type: 'different' });
    }
  }

  return [result1, result2];
}

export function summarizeClause(content: string, maxLength: number = 150): string {
  const cleaned = content.replace(/\s+/g, ' ').trim();
  if (cleaned.length <= maxLength) return cleaned;
  return cleaned.substring(0, maxLength).trim() + '...';
}
