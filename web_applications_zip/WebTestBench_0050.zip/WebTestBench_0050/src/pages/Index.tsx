import { useState, useCallback } from "react";
import { ContractInput } from "@/components/ContractInput";
import { ComparisonView } from "@/components/ComparisonView";
import { Contract, detectClauses } from "@/lib/clauseDetection";
import { Scale, FileText, GitCompare } from "lucide-react";

const Index = () => {
  const [contracts, setContracts] = useState<Contract[]>([]);

  const addContract = useCallback((name: string, text: string) => {
    const id = `contract-${Date.now()}`;
    const newContract: Contract = {
      id,
      name,
      text,
      clauses: detectClauses({ id, name, text }),
    };
    setContracts((prev) => [...prev, newContract]);
  }, []);

  const removeContract = useCallback((id: string) => {
    setContracts((prev) => prev.filter((c) => c.id !== id));
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-primary text-primary-foreground">
              <Scale className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">ClauseCompare</h1>
              <p className="text-sm text-muted-foreground">
                Smart contract clause detection & comparison
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Stats Bar */}
          {contracts.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in">
              <div className="flex items-center gap-3 p-4 bg-card border border-border/50 rounded-lg shadow-sm">
                <FileText className="h-8 w-8 text-primary/70" />
                <div>
                  <p className="text-2xl font-bold">{contracts.length}</p>
                  <p className="text-xs text-muted-foreground">Contracts</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-card border border-border/50 rounded-lg shadow-sm">
                <GitCompare className="h-8 w-8 text-primary/70" />
                <div>
                  <p className="text-2xl font-bold">
                    {contracts.reduce((sum, c) => sum + c.clauses.length, 0)}
                  </p>
                  <p className="text-xs text-muted-foreground">Clauses Detected</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-card border border-border/50 rounded-lg shadow-sm col-span-2">
                <div className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">Detected types: </span>
                  {Array.from(new Set(contracts.flatMap((c) => c.clauses.map((cl) => cl.type)))).join(", ") || "None"}
                </div>
              </div>
            </div>
          )}

          {/* Contract Input */}
          <ContractInput
            onAddContract={addContract}
            contracts={contracts.map((c) => ({ id: c.id, name: c.name }))}
            onRemoveContract={removeContract}
          />

          {/* Comparison View */}
          <ComparisonView contracts={contracts} />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16">
        <div className="container max-w-7xl mx-auto px-4 py-6">
          <p className="text-center text-sm text-muted-foreground">
            ClauseCompare — Analyze and compare contract clauses with ease
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
