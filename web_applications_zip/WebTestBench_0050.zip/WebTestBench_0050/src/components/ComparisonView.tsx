import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ClauseCard } from "./ClauseCard";
import { ClauseFilter } from "./ClauseFilter";
import {
  ClauseGroup,
  ClauseType,
  clauseTypeLabels,
  computeDiff,
  Contract,
  groupClausesByType,
} from "@/lib/clauseDetection";
import { Columns3, Eye, EyeOff, GitCompare, Layers } from "lucide-react";

interface ComparisonViewProps {
  contracts: Contract[];
}

const typeToClass: Record<ClauseType, string> = {
  payment: "clause-badge-payment",
  confidentiality: "clause-badge-confidentiality",
  termination: "clause-badge-termination",
  liability: "clause-badge-liability",
  indemnification: "clause-badge-indemnification",
  dispute: "clause-badge-dispute",
  intellectual: "clause-badge-intellectual",
  general: "clause-badge-general",
};

export function ComparisonView({ contracts }: ComparisonViewProps) {
  const [selectedTypes, setSelectedTypes] = useState<ClauseType[]>([]);
  const [showFullText, setShowFullText] = useState(false);
  const [showDiffs, setShowDiffs] = useState(true);

  const clauseGroups = useMemo(() => groupClausesByType(contracts), [contracts]);

  const availableTypes = useMemo(
    () => clauseGroups.map((g) => g.type),
    [clauseGroups]
  );

  const filteredGroups = useMemo(() => {
    if (selectedTypes.length === 0) return clauseGroups;
    return clauseGroups.filter((g) => selectedTypes.includes(g.type));
  }, [clauseGroups, selectedTypes]);

  const toggleType = (type: ClauseType) => {
    setSelectedTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const getDiffHighlights = (group: ClauseGroup, clauseIndex: number) => {
    if (!showDiffs || group.clauses.length < 2) return undefined;
    
    const clause = group.clauses[clauseIndex];
    const otherClauses = group.clauses.filter((_, i) => i !== clauseIndex);
    
    if (otherClauses.length === 0) return undefined;
    
    // Compare with first other clause for simplicity
    const [result] = computeDiff(clause.content, otherClauses[0].content);
    return result;
  };

  if (contracts.length === 0) {
    return (
      <Card className="border-dashed border-2 border-border bg-muted/20">
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <Layers className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground mb-2">
            No contracts to compare
          </h3>
          <p className="text-sm text-muted-foreground/70 max-w-md">
            Add at least one contract using the form above to see clause detection and comparison features.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <ClauseFilter
          availableTypes={availableTypes}
          selectedTypes={selectedTypes}
          onToggleType={toggleType}
          onClearFilters={() => setSelectedTypes([])}
        />
        
        <div className="flex items-center gap-6 p-4 bg-card border border-border/50 rounded-lg shadow-sm">
          <div className="flex items-center gap-2">
            <Switch
              id="full-text"
              checked={showFullText}
              onCheckedChange={setShowFullText}
            />
            <Label htmlFor="full-text" className="text-sm cursor-pointer flex items-center gap-1.5">
              {showFullText ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              Full text
            </Label>
          </div>
          
          <div className="flex items-center gap-2">
            <Switch
              id="show-diffs"
              checked={showDiffs}
              onCheckedChange={setShowDiffs}
            />
            <Label htmlFor="show-diffs" className="text-sm cursor-pointer flex items-center gap-1.5">
              <GitCompare className="h-4 w-4" />
              Highlight differences
            </Label>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {filteredGroups.map((group) => (
          <Card key={group.type} className="border-border/50 shadow-sm overflow-hidden">
            <CardHeader className="bg-muted/30 border-b border-border/50 py-4">
              <div className="flex items-center gap-3">
                <Columns3 className="h-5 w-5 text-muted-foreground" />
                <CardTitle className="text-base font-semibold">
                  {clauseTypeLabels[group.type]}
                </CardTitle>
                <Badge variant="secondary" className="ml-auto">
                  {group.clauses.length} clause{group.clauses.length !== 1 ? 's' : ''}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div
                className="grid gap-4"
                style={{
                  gridTemplateColumns: `repeat(${Math.min(group.clauses.length, 3)}, minmax(0, 1fr))`,
                }}
              >
                {group.clauses.map((clause, idx) => (
                  <div key={clause.id} className="animate-slide-in-right" style={{ animationDelay: `${idx * 50}ms` }}>
                    <ClauseCard
                      clause={clause}
                      diffHighlights={getDiffHighlights(group, idx)}
                      showFullText={showFullText}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredGroups.length === 0 && (
        <Card className="border-dashed border-2 border-border bg-muted/20">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-sm text-muted-foreground">
              No clauses found matching your filter criteria.
            </p>
            <Button
              variant="link"
              onClick={() => setSelectedTypes([])}
              className="mt-2"
            >
              Clear filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
