import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clause, ClauseType, clauseTypeLabels, summarizeClause } from "@/lib/clauseDetection";
import { ChevronDown, ChevronUp, FileText } from "lucide-react";

interface ClauseCardProps {
  clause: Clause;
  diffHighlights?: { word: string; type: 'match' | 'different' | 'missing' }[];
  showFullText: boolean;
}

const typeToClass: Record<ClauseType, string> = {
  payment: "clause-badge-payment",
  confidentiality: "clause-badge-confidentiality",
  termination: "clause-badge-termination",
  liability: "clause-badge-liability",
  indemnification: "clause-badge-indemnification",
  dispute: "clause-badge-dispute",
  intellectual: "clause-badge-intellectual",
  general: "clause-badge-general",
};

export function ClauseCard({ clause, diffHighlights, showFullText }: ClauseCardProps) {
  const [expanded, setExpanded] = useState(false);
  const displayFull = showFullText || expanded;

  const renderContent = () => {
    if (diffHighlights) {
      return (
        <p className="text-sm leading-relaxed font-mono">
          {diffHighlights.map((item, i) => (
            <span
              key={i}
              className={
                item.type === 'match'
                  ? ''
                  : item.type === 'different'
                  ? 'diff-highlight-different'
                  : 'diff-highlight-missing'
              }
            >
              {item.word}{' '}
            </span>
          ))}
        </p>
      );
    }

    return (
      <p className="text-sm leading-relaxed font-mono whitespace-pre-wrap">
        {displayFull ? clause.content : summarizeClause(clause.content, 200)}
      </p>
    );
  };

  return (
    <Card className="border-border/50 bg-card hover:border-border transition-colors duration-200 h-full flex flex-col">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <span className="text-sm font-medium truncate">{clause.contractName}</span>
          </div>
          <Badge variant="outline" className={`flex-shrink-0 text-xs ${typeToClass[clause.type]}`}>
            {clauseTypeLabels[clause.type]}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="px-4 pb-4 pt-2 flex-1 flex flex-col">
        <div className="flex-1 overflow-hidden">
          {renderContent()}
        </div>
        {!showFullText && clause.content.length > 200 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className="mt-2 w-full text-xs text-muted-foreground hover:text-foreground"
          >
            {expanded ? (
              <>
                <ChevronUp className="h-3 w-3 mr-1" />
                Show less
              </>
            ) : (
              <>
                <ChevronDown className="h-3 w-3 mr-1" />
                Show full text
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
