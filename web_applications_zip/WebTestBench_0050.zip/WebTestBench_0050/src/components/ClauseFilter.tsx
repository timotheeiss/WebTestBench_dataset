import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ClauseType, clauseTypeLabels } from "@/lib/clauseDetection";
import { Filter, X } from "lucide-react";

interface ClauseFilterProps {
  availableTypes: ClauseType[];
  selectedTypes: ClauseType[];
  onToggleType: (type: ClauseType) => void;
  onClearFilters: () => void;
}

const typeToClass: Record<ClauseType, string> = {
  payment: "clause-badge-payment",
  confidentiality: "clause-badge-confidentiality",
  termination: "clause-badge-termination",
  liability: "clause-badge-liability",
  indemnification: "clause-badge-indemnification",
  dispute: "clause-badge-dispute",
  intellectual: "clause-badge-intellectual",
  general: "clause-badge-general",
};

export function ClauseFilter({
  availableTypes,
  selectedTypes,
  onToggleType,
  onClearFilters,
}: ClauseFilterProps) {
  const isSelected = (type: ClauseType) => selectedTypes.includes(type);

  return (
    <div className="flex flex-wrap items-center gap-2 p-4 bg-card border border-border/50 rounded-lg shadow-sm">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mr-2">
        <Filter className="h-4 w-4" />
        <span className="font-medium">Filter by clause:</span>
      </div>
      
      {availableTypes.map((type) => (
        <Badge
          key={type}
          variant="outline"
          className={`cursor-pointer transition-all duration-200 ${
            isSelected(type) || selectedTypes.length === 0
              ? typeToClass[type]
              : "bg-muted/30 text-muted-foreground border-border opacity-50"
          }`}
          onClick={() => onToggleType(type)}
        >
          {clauseTypeLabels[type]}
          {isSelected(type) && <X className="h-3 w-3 ml-1" />}
        </Badge>
      ))}

      {selectedTypes.length > 0 && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearFilters}
          className="text-xs text-muted-foreground ml-2"
        >
          Clear all
        </Button>
      )}
    </div>
  );
}
