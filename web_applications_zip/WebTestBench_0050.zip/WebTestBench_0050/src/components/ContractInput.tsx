import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, FileText, Trash2, Upload } from "lucide-react";
import { sampleContracts } from "@/lib/sampleContracts";

interface ContractInputProps {
  onAddContract: (name: string, text: string) => void;
  contracts: { id: string; name: string }[];
  onRemoveContract: (id: string) => void;
}

export function ContractInput({ onAddContract, contracts, onRemoveContract }: ContractInputProps) {
  const [name, setName] = useState("");
  const [text, setText] = useState("");

  const handleSubmit = () => {
    if (name.trim() && text.trim()) {
      onAddContract(name.trim(), text.trim());
      setName("");
      setText("");
    }
  };

  const loadSample = (index: number) => {
    const sample = sampleContracts[index];
    if (sample) {
      setName(sample.name);
      setText(sample.text);
    }
  };

  return (
    <Card className="border-border/50 bg-card shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <FileText className="h-5 w-5 text-primary" />
          Add Contract
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Input
            placeholder="Contract name (e.g., Vendor Agreement A)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="bg-background"
          />
        </div>
        <div>
          <Textarea
            placeholder="Paste the full contract text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="min-h-[200px] font-mono text-sm bg-background resize-y"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleSubmit} disabled={!name.trim() || !text.trim()}>
            <Plus className="h-4 w-4 mr-2" />
            Add Contract
          </Button>
          <div className="flex items-center gap-2 ml-auto">
            <span className="text-xs text-muted-foreground">Load sample:</span>
            {sampleContracts.map((sample, i) => (
              <Button
                key={i}
                variant="outline"
                size="sm"
                onClick={() => loadSample(i)}
                className="text-xs"
              >
                <Upload className="h-3 w-3 mr-1" />
                {sample.name.split(' ')[0]}
              </Button>
            ))}
          </div>
        </div>

        {contracts.length > 0 && (
          <div className="pt-4 border-t border-border">
            <h4 className="text-sm font-medium text-muted-foreground mb-2">
              Added Contracts ({contracts.length})
            </h4>
            <div className="space-y-2">
              {contracts.map((contract) => (
                <div
                  key={contract.id}
                  className="flex items-center justify-between p-2 bg-muted/50 rounded-md animate-fade-in"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{contract.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveContract(contract.id)}
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
