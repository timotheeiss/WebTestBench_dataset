import { useState } from 'react';
import { Task, Status, TeamMember } from '@/types/kanban';
import { TaskCard } from './TaskCard';
import { Plus, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface KanbanColumnProps {
  id: Status;
  title: string;
  tasks: Task[];
  teamMembers: TeamMember[];
  onTaskClick: (task: Task) => void;
  onAddTask: (status: Status) => void;
  onDragStart: (e: React.DragEvent, taskId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, status: Status) => void;
}

const columnColors: Record<Status, string> = {
  'todo': 'border-t-muted-foreground/50',
  'in-progress': 'border-t-primary',
  'review': 'border-t-warning',
  'done': 'border-t-success',
};

const columnBg: Record<Status, string> = {
  'todo': 'bg-column-todo',
  'in-progress': 'bg-column-progress',
  'review': 'bg-column-review',
  'done': 'bg-column-done',
};

export function KanbanColumn({
  id,
  title,
  tasks,
  teamMembers,
  onTaskClick,
  onAddTask,
  onDragStart,
  onDragOver,
  onDrop,
}: KanbanColumnProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
    onDragOver(e);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    setIsDragOver(false);
    onDrop(e, id);
  };

  const getTeamMember = (assigneeId: string | null) => {
    if (!assigneeId) return undefined;
    return teamMembers.find(m => m.id === assigneeId);
  };

  return (
    <div
      className={cn(
        "flex flex-col min-w-[300px] max-w-[300px] rounded-xl border-t-2 transition-all duration-200",
        columnColors[id],
        columnBg[id],
        isDragOver && "ring-2 ring-primary/30 bg-primary/5"
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="flex items-center justify-between p-4 pb-2">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-sm text-foreground">{title}</h3>
          <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
            {tasks.length}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-foreground"
            onClick={() => onAddTask(id)}
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-foreground"
          >
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2 min-h-[200px]">
        {tasks.map((task, index) => (
          <div 
            key={task.id} 
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <TaskCard
              task={task}
              teamMember={getTeamMember(task.assigneeId)}
              onClick={() => onTaskClick(task)}
              onDragStart={onDragStart}
            />
          </div>
        ))}
        {tasks.length === 0 && (
          <div className="flex items-center justify-center h-24 text-muted-foreground text-sm border border-dashed border-border/50 rounded-lg">
            No tasks yet
          </div>
        )}
      </div>
    </div>
  );
}
