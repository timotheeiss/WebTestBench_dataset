import { useState } from 'react';
import { Task, TeamMember, Priority, Status } from '@/types/kanban';
import { format } from 'date-fns';
import { Calendar, User, Flag, Tag, MessageSquare, X, Trash2, Send } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';

interface TaskDetailModalProps {
  task: Task | null;
  teamMembers: TeamMember[];
  open: boolean;
  onClose: () => void;
  onUpdate: (taskId: string, updates: Partial<Task>) => void;
  onDelete: (taskId: string) => void;
  onAddNote: (taskId: string, content: string, authorId: string) => void;
}

export function TaskDetailModal({
  task,
  teamMembers,
  open,
  onClose,
  onUpdate,
  onDelete,
  onAddNote,
}: TaskDetailModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [newNote, setNewNote] = useState('');

  if (!task) return null;

  const assignee = teamMembers.find(m => m.id === task.assigneeId);

  const handleSaveEdit = () => {
    onUpdate(task.id, {
      title: editedTitle,
      description: editedDescription,
    });
    setIsEditing(false);
  };

  const handleStartEdit = () => {
    setEditedTitle(task.title);
    setEditedDescription(task.description);
    setIsEditing(true);
  };

  const handleAddNote = () => {
    if (newNote.trim()) {
      onAddNote(task.id, newNote.trim(), 'user-1'); // Default to first user
      setNewNote('');
    }
  };

  const priorityStyles = {
    low: 'text-priority-low',
    medium: 'text-priority-medium',
    high: 'text-priority-high',
  };

  const statusLabels: Record<Status, string> = {
    'todo': 'To Do',
    'in-progress': 'In Progress',
    'review': 'Review',
    'done': 'Done',
  };

  const getNotesAuthor = (authorId: string) => {
    return teamMembers.find(m => m.id === authorId);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col bg-card border-border">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-start justify-between gap-4">
            {isEditing ? (
              <Input
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
                className="text-lg font-semibold bg-secondary border-border"
              />
            ) : (
              <DialogTitle className="text-xl font-semibold text-foreground pr-8">
                {task.title}
              </DialogTitle>
            )}
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 pr-2">
          {/* Meta info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Assignee</span>
              </div>
              <Select
                value={task.assigneeId || 'unassigned'}
                onValueChange={(value) => onUpdate(task.id, { 
                  assigneeId: value === 'unassigned' ? null : value 
                })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue>
                    {assignee ? (
                      <div className="flex items-center gap-2">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={assignee.avatar} />
                          <AvatarFallback className="text-[8px]">
                            {assignee.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <span>{assignee.name}</span>
                      </div>
                    ) : (
                      'Unassigned'
                    )}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="unassigned">Unassigned</SelectItem>
                  {teamMembers.map(member => (
                    <SelectItem key={member.id} value={member.id}>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={member.avatar} />
                          <AvatarFallback className="text-[8px]">
                            {member.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <span>{member.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Flag className={cn("h-4 w-4", priorityStyles[task.priority])} />
                <span className="text-muted-foreground">Priority</span>
              </div>
              <Select
                value={task.priority}
                onValueChange={(value: Priority) => onUpdate(task.id, { priority: value })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Due Date</span>
              </div>
              <Input
                type="date"
                value={task.dueDate ? format(task.dueDate, 'yyyy-MM-dd') : ''}
                onChange={(e) => onUpdate(task.id, { 
                  dueDate: e.target.value ? new Date(e.target.value) : null 
                })}
                className="bg-secondary border-border"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Tag className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Status</span>
              </div>
              <Select
                value={task.status}
                onValueChange={(value: Status) => onUpdate(task.id, { status: value })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator className="bg-border" />

          {/* Description */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-foreground">Description</h4>
              {!isEditing && (
                <Button variant="ghost" size="sm" onClick={handleStartEdit}>
                  Edit
                </Button>
              )}
            </div>
            {isEditing ? (
              <div className="space-y-2">
                <Textarea
                  value={editedDescription}
                  onChange={(e) => setEditedDescription(e.target.value)}
                  className="min-h-[100px] bg-secondary border-border"
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleSaveEdit}>Save</Button>
                  <Button size="sm" variant="ghost" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground leading-relaxed">
                {task.description || 'No description provided.'}
              </p>
            )}
          </div>

          {/* Tags */}
          {task.tags.length > 0 && (
            <>
              <Separator className="bg-border" />
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-foreground">Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {task.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="bg-secondary text-secondary-foreground">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}

          <Separator className="bg-border" />

          {/* Notes */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              <h4 className="text-sm font-medium text-foreground">
                Notes & Updates ({task.notes.length})
              </h4>
            </div>

            <div className="flex gap-2">
              <Input
                placeholder="Add a note or status update..."
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                className="bg-secondary border-border"
              />
              <Button size="icon" onClick={handleAddNote} disabled={!newNote.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-3 max-h-[200px] overflow-y-auto">
              {task.notes.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No notes yet. Add the first one above.
                </p>
              ) : (
                task.notes.map(note => {
                  const author = getNotesAuthor(note.authorId);
                  return (
                    <div key={note.id} className="flex gap-3 p-3 rounded-lg bg-secondary/50">
                      <Avatar className="h-7 w-7 flex-shrink-0">
                        <AvatarImage src={author?.avatar} />
                        <AvatarFallback className="text-[10px]">
                          {author?.name.split(' ').map(n => n[0]).join('') || '?'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-foreground">
                            {author?.name || 'Unknown'}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {format(note.createdAt, 'MMM d, h:mm a')}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{note.content}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        <div className="flex-shrink-0 pt-4 border-t border-border">
          <div className="flex items-center justify-between">
            <Button 
              variant="destructive" 
              size="sm"
              onClick={() => {
                onDelete(task.id);
                onClose();
              }}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Task
            </Button>
            <div className="text-xs text-muted-foreground">
              Created {format(task.createdAt, 'MMM d, yyyy')}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
