import { Task, TeamMember } from '@/types/kanban';
import { Calendar, MessageSquare, GripVertical } from 'lucide-react';
import { format, isPast, isToday } from 'date-fns';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface TaskCardProps {
  task: Task;
  teamMember: TeamMember | undefined;
  onClick: () => void;
  onDragStart: (e: React.DragEvent, taskId: string) => void;
}

export function TaskCard({ task, teamMember, onClick, onDragStart }: TaskCardProps) {
  const isOverdue = task.dueDate && isPast(task.dueDate) && task.status !== 'done';
  const isDueToday = task.dueDate && isToday(task.dueDate);

  const priorityStyles = {
    low: 'bg-priority-low/10 text-priority-low border-priority-low/30',
    medium: 'bg-priority-medium/10 text-priority-medium border-priority-medium/30',
    high: 'bg-priority-high/10 text-priority-high border-priority-high/30',
  };

  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, task.id)}
      onClick={onClick}
      className={cn(
        "group relative p-4 rounded-lg cursor-pointer transition-all duration-200",
        "bg-card hover:bg-card/80 border border-border/50 hover:border-primary/30",
        "hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-0.5",
        "animate-fade-in"
      )}
    >
      <div className="absolute left-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-50 transition-opacity cursor-grab">
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </div>

      <div className="flex items-start justify-between gap-2 mb-3">
        <h4 className="font-medium text-foreground text-sm leading-tight line-clamp-2">
          {task.title}
        </h4>
        <Badge 
          variant="outline" 
          className={cn("text-[10px] px-1.5 py-0 shrink-0 capitalize", priorityStyles[task.priority])}
        >
          {task.priority}
        </Badge>
      </div>

      {task.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {task.tags.slice(0, 2).map(tag => (
            <span 
              key={tag} 
              className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground"
            >
              {tag}
            </span>
          ))}
          {task.tags.length > 2 && (
            <span className="text-[10px] text-muted-foreground">
              +{task.tags.length - 2}
            </span>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mt-auto">
        <div className="flex items-center gap-2">
          {teamMember && (
            <Avatar className="h-6 w-6 border border-border">
              <AvatarImage src={teamMember.avatar} alt={teamMember.name} />
              <AvatarFallback className="text-[10px] bg-secondary">
                {teamMember.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
          )}
          {task.notes.length > 0 && (
            <div className="flex items-center gap-1 text-muted-foreground">
              <MessageSquare className="h-3 w-3" />
              <span className="text-[10px]">{task.notes.length}</span>
            </div>
          )}
        </div>

        {task.dueDate && (
          <div className={cn(
            "flex items-center gap-1 text-[10px]",
            isOverdue && "text-destructive",
            isDueToday && !isOverdue && "text-warning",
            !isOverdue && !isDueToday && "text-muted-foreground"
          )}>
            <Calendar className="h-3 w-3" />
            <span>{format(task.dueDate, 'MMM d')}</span>
          </div>
        )}
      </div>
    </div>
  );
}
