import { TeamMember, Status } from '@/types/kanban';
import { Search, X, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface FilterBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedAssignee: string | null;
  onAssigneeChange: (assigneeId: string | null) => void;
  selectedStatus: Status | null;
  onStatusChange: (status: Status | null) => void;
  teamMembers: TeamMember[];
}

export function FilterBar({
  searchQuery,
  onSearchChange,
  selectedAssignee,
  onAssigneeChange,
  selectedStatus,
  onStatusChange,
  teamMembers,
}: FilterBarProps) {
  const statuses: { value: Status; label: string }[] = [
    { value: 'todo', label: 'To Do' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'review', label: 'Review' },
    { value: 'done', label: 'Done' },
  ];

  const hasFilters = searchQuery || selectedAssignee || selectedStatus;

  const clearFilters = () => {
    onSearchChange('');
    onAssigneeChange(null);
    onStatusChange(null);
  };

  return (
    <div className="flex flex-wrap items-center gap-4 p-4 bg-card/50 backdrop-blur-sm rounded-xl border border-border/50">
      <div className="relative flex-1 min-w-[200px] max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search tasks..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10 bg-secondary border-border"
        />
      </div>

      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Filter by:</span>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground">Team:</span>
        <div className="flex items-center gap-1">
          {teamMembers.map(member => (
            <button
              key={member.id}
              onClick={() => onAssigneeChange(
                selectedAssignee === member.id ? null : member.id
              )}
              className={cn(
                "relative transition-all duration-200",
                selectedAssignee === member.id 
                  ? "ring-2 ring-primary ring-offset-2 ring-offset-background rounded-full" 
                  : "opacity-60 hover:opacity-100"
              )}
              title={member.name}
            >
              <Avatar className="h-8 w-8 border border-border">
                <AvatarImage src={member.avatar} alt={member.name} />
                <AvatarFallback className="text-[10px] bg-secondary">
                  {member.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground">Status:</span>
        <div className="flex items-center gap-1">
          {statuses.map(status => (
            <Badge
              key={status.value}
              variant={selectedStatus === status.value ? "default" : "outline"}
              className={cn(
                "cursor-pointer transition-all duration-200",
                selectedStatus === status.value 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-secondary"
              )}
              onClick={() => onStatusChange(
                selectedStatus === status.value ? null : status.value
              )}
            >
              {status.label}
            </Badge>
          ))}
        </div>
      </div>

      {hasFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={clearFilters}
          className="text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4 mr-1" />
          Clear
        </Button>
      )}
    </div>
  );
}
