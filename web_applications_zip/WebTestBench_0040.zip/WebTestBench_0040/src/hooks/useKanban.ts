import { useState, useCallback } from 'react';
import { Task, Status, Note } from '@/types/kanban';
import { initialTasks } from '@/data/initialData';

export function useKanban() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);

  const getTasksByStatus = useCallback((status: Status): Task[] => {
    return tasks.filter(task => task.status === status);
  }, [tasks]);

  const addTask = useCallback((task: Omit<Task, 'id' | 'createdAt' | 'notes'>) => {
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}`,
      createdAt: new Date(),
      notes: [],
    };
    setTasks(prev => [...prev, newTask]);
    return newTask;
  }, []);

  const updateTask = useCallback((taskId: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, ...updates } : task
    ));
  }, []);

  const deleteTask = useCallback((taskId: string) => {
    setTasks(prev => prev.filter(task => task.id !== taskId));
  }, []);

  const moveTask = useCallback((taskId: string, newStatus: Status) => {
    setTasks(prev => prev.map(task =>
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  }, []);

  const addNote = useCallback((taskId: string, content: string, authorId: string) => {
    const newNote: Note = {
      id: `note-${Date.now()}`,
      content,
      authorId,
      createdAt: new Date(),
    };
    setTasks(prev => prev.map(task =>
      task.id === taskId 
        ? { ...task, notes: [...task.notes, newNote] }
        : task
    ));
  }, []);

  const getTaskById = useCallback((taskId: string): Task | undefined => {
    return tasks.find(task => task.id === taskId);
  }, [tasks]);

  return {
    tasks,
    getTasksByStatus,
    addTask,
    updateTask,
    deleteTask,
    moveTask,
    addNote,
    getTaskById,
  };
}
