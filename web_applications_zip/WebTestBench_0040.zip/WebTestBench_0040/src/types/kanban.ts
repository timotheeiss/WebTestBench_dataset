export type Priority = 'low' | 'medium' | 'high';
export type Status = 'todo' | 'in-progress' | 'review' | 'done';

export interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
}

export interface Note {
  id: string;
  content: string;
  authorId: string;
  createdAt: Date;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: Status;
  priority: Priority;
  assigneeId: string | null;
  dueDate: Date | null;
  notes: Note[];
  createdAt: Date;
  tags: string[];
}

export interface Column {
  id: Status;
  title: string;
  tasks: Task[];
}
