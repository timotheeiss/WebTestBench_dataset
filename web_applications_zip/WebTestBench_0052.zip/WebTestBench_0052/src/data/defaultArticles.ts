import { Article } from '@/types/article';

export const defaultArticles: Article[] = [
  {
    id: '1',
    title: 'The Art of Slow Living',
    content: `In a world that constantly demands our attention, the philosophy of slow living offers a refreshing counterpoint. It's not about doing everything at a snail's pace, but rather about being present and intentional with our time.

The movement emerged as a response to the burnout culture that has become increasingly prevalent in modern society. When we slow down, we create space for deeper connections, more meaningful work, and a greater appreciation for the simple moments that make up our days.

Consider your morning routine. Do you rush through it, already thinking about the tasks ahead? Or do you take time to savor your coffee, notice the light streaming through your window, and set a calm intention for the day?

Slow living isn't a luxury—it's a practice that can transform how we experience each moment of our lives.`,
    status: 'published',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    publishedAt: new Date('2024-01-15'),
    versions: [],
  },
  {
    id: '2',
    title: 'Rediscovering the Joy of Handwritten Letters',
    content: `There's something irreplaceable about receiving a handwritten letter. In an age of instant digital communication, the deliberate act of putting pen to paper carries a weight that emails and text messages simply cannot replicate.

When someone takes the time to write by hand, they're offering more than words—they're giving a piece of their time, their attention, and often, a small window into their daily life through the imperfections of their handwriting.

I recently started a correspondence with an old friend who moved abroad. Each letter takes about a week to arrive, and that anticipation has become part of the joy. We write differently than we text; we're more thoughtful, more descriptive, more present in our storytelling.`,
    status: 'published',
    createdAt: new Date('2024-02-20'),
    updatedAt: new Date('2024-02-22'),
    publishedAt: new Date('2024-02-22'),
    versions: [],
  },
  {
    id: '3',
    title: 'Notes on Building a Reading Habit',
    content: `I've been trying to read more this year. Here are some observations:

- Starting small works better than ambitious goals. Five pages is better than zero.
- Physical books help me stay focused compared to e-readers.
- Reading before bed has become a pleasant ritual.
- Having multiple books going at once keeps things interesting.

Still figuring out how to make time on busy days. Maybe audiobooks during commutes?`,
    status: 'draft',
    createdAt: new Date('2024-03-10'),
    updatedAt: new Date('2024-03-12'),
    versions: [
      {
        id: 'v3-1',
        title: 'Reading Habit Ideas',
        content: `Some initial thoughts on reading more:
- Start small
- Physical books vs e-readers?`,
        createdAt: new Date('2024-03-10'),
        note: 'Initial brainstorm',
      },
    ],
  },
  {
    id: '4',
    title: 'The Case for Walking Meetings',
    content: `What if we took our meetings outside? Walking meetings have been gaining popularity, and for good reason.

The benefits extend beyond just physical health. Walking side by side removes the formality of facing each other across a table. Conversations flow more naturally. The change of scenery can spark creative thinking.

Of course, not every meeting suits this format. Complex discussions requiring documents or large groups don't work well. But for one-on-ones, brainstorming sessions, or check-ins, a walk around the block might be exactly what your meeting needs.`,
    status: 'draft',
    createdAt: new Date('2024-03-18'),
    updatedAt: new Date('2024-03-18'),
    versions: [],
  },
];
