import { useState } from 'react';
import { useArticleContext } from '@/contexts/ArticleContext';
import { ArticleList } from '@/components/ArticleList';
import { ArticleEditor } from '@/components/ArticleEditor';
import { ArticleViewer } from '@/components/ArticleViewer';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PenLine, FileText, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

type View = 'dashboard' | 'new' | 'edit' | 'view';

export default function Index() {
  const { getDrafts, getPublished, getArticle, createDraft, updateArticle, publishArticle, deleteArticle, saveVersion, rollbackToVersion, addVersionNote } = useArticleContext();
  const [view, setView] = useState<View>('dashboard');
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('drafts');

  const drafts = getDrafts();
  const published = getPublished();

  const handleNewArticle = () => {
    setView('new');
  };

  const handleEditArticle = (id: string) => {
    setSelectedArticleId(id);
    setView('edit');
  };

  const handleViewArticle = (id: string) => {
    setSelectedArticleId(id);
    setView('view');
  };

  const handleBackToDashboard = () => {
    setView('dashboard');
    setSelectedArticleId(null);
  };

  const handleSaveNewDraft = (data: { title: string; content: string }) => {
    const article = createDraft(data);
    setSelectedArticleId(article.id);
    setView('edit');
    toast.success('Draft saved');
  };

  const handleUpdateDraft = (data: { title: string; content: string }) => {
    if (selectedArticleId) {
      updateArticle(selectedArticleId, data);
      toast.success('Draft updated');
    }
  };

  const handlePublish = (id?: string) => {
    const articleId = id || selectedArticleId;
    if (articleId) {
      publishArticle(articleId);
      toast.success('Article published!');
      setView('dashboard');
      setSelectedArticleId(null);
      setActiveTab('published');
    }
  };

  const handleDelete = (id: string) => {
    deleteArticle(id);
    toast.success('Draft deleted');
  };

  // Render article viewer
  if (view === 'view' && selectedArticleId) {
    const article = getArticle(selectedArticleId);
    if (!article) return null;
    return <ArticleViewer article={article} onBack={handleBackToDashboard} />;
  }

  // Render article editor
  if (view === 'new') {
    return (
      <ArticleEditor
        isNew
        onSave={handleSaveNewDraft}
        onPublish={() => {}}
        onBack={handleBackToDashboard}
      />
    );
  }

  if (view === 'edit' && selectedArticleId) {
    const article = getArticle(selectedArticleId);
    if (!article) return null;
    return (
      <ArticleEditor
        article={article}
        onSave={handleUpdateDraft}
        onPublish={() => handlePublish()}
        onBack={handleBackToDashboard}
        onSaveVersion={(note) => saveVersion(selectedArticleId, note)}
        onRollback={(version) => rollbackToVersion(selectedArticleId, version)}
        onAddVersionNote={(versionId, note) => addVersionNote(selectedArticleId, versionId, note)}
      />
    );
  }

  // Render dashboard
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-6 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="font-display text-2xl font-semibold text-foreground">
              My Articles
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Write, edit, and publish your stories
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Button onClick={handleNewArticle} size="lg" className="gap-2">
              <PenLine className="h-5 w-5" />
              New Article
            </Button>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-8 bg-secondary/50">
            <TabsTrigger value="drafts" className="gap-2 data-[state=active]:bg-card">
              <FileText className="h-4 w-4" />
              Drafts
              {drafts.length > 0 && (
                <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-accent/20 text-accent-foreground">
                  {drafts.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="published" className="gap-2 data-[state=active]:bg-card">
              <Send className="h-4 w-4" />
              Published
              {published.length > 0 && (
                <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-primary/20 text-primary">
                  {published.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          <AnimatePresence mode="wait">
            <TabsContent value="drafts" className="mt-0">
              <ArticleList
                articles={drafts}
                emptyMessage="No drafts yet. Start writing your first article!"
                onEdit={handleEditArticle}
                onPublish={handlePublish}
                onDelete={handleDelete}
              />
            </TabsContent>

            <TabsContent value="published" className="mt-0">
              <ArticleList
                articles={published}
                emptyMessage="No published articles yet. Publish a draft to see it here."
                onView={handleViewArticle}
              />
            </TabsContent>
          </AnimatePresence>
        </Tabs>
      </main>
    </div>
  );
}
