export interface ArticleVersion {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  note?: string;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  status: 'draft' | 'published';
  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date;
  versions: ArticleVersion[];
}

export type ArticleFormData = Pick<Article, 'title' | 'content'>;
