export interface DiffSegment {
  type: 'unchanged' | 'added' | 'removed';
  text: string;
}

export interface DiffResult {
  title: DiffSegment[];
  content: DiffSegment[];
}

// Simple word-level diff algorithm
function diffWords(oldText: string, newText: string): DiffSegment[] {
  const oldWords = oldText.split(/(\s+)/);
  const newWords = newText.split(/(\s+)/);
  
  const result: DiffSegment[] = [];
  
  // Use LCS (Longest Common Subsequence) approach for better diffs
  const lcs = computeLCS(oldWords, newWords);
  
  let oldIdx = 0;
  let newIdx = 0;
  let lcsIdx = 0;
  
  while (oldIdx < oldWords.length || newIdx < newWords.length) {
    if (lcsIdx < lcs.length && oldIdx < oldWords.length && newIdx < newWords.length) {
      // Process removals
      while (oldIdx < oldWords.length && oldWords[oldIdx] !== lcs[lcsIdx]) {
        result.push({ type: 'removed', text: oldWords[oldIdx] });
        oldIdx++;
      }
      
      // Process additions
      while (newIdx < newWords.length && newWords[newIdx] !== lcs[lcsIdx]) {
        result.push({ type: 'added', text: newWords[newIdx] });
        newIdx++;
      }
      
      // Process common element
      if (oldIdx < oldWords.length && newIdx < newWords.length && 
          oldWords[oldIdx] === lcs[lcsIdx] && newWords[newIdx] === lcs[lcsIdx]) {
        result.push({ type: 'unchanged', text: oldWords[oldIdx] });
        oldIdx++;
        newIdx++;
        lcsIdx++;
      }
    } else {
      // Process remaining removals
      while (oldIdx < oldWords.length) {
        result.push({ type: 'removed', text: oldWords[oldIdx] });
        oldIdx++;
      }
      
      // Process remaining additions
      while (newIdx < newWords.length) {
        result.push({ type: 'added', text: newWords[newIdx] });
        newIdx++;
      }
    }
  }
  
  // Merge consecutive segments of the same type
  return mergeSegments(result);
}

function computeLCS(arr1: string[], arr2: string[]): string[] {
  const m = arr1.length;
  const n = arr2.length;
  const dp: number[][] = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
  
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (arr1[i - 1] === arr2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }
  
  // Backtrack to find LCS
  const lcs: string[] = [];
  let i = m, j = n;
  while (i > 0 && j > 0) {
    if (arr1[i - 1] === arr2[j - 1]) {
      lcs.unshift(arr1[i - 1]);
      i--;
      j--;
    } else if (dp[i - 1][j] > dp[i][j - 1]) {
      i--;
    } else {
      j--;
    }
  }
  
  return lcs;
}

function mergeSegments(segments: DiffSegment[]): DiffSegment[] {
  if (segments.length === 0) return [];
  
  const merged: DiffSegment[] = [];
  let current = { ...segments[0] };
  
  for (let i = 1; i < segments.length; i++) {
    if (segments[i].type === current.type) {
      current.text += segments[i].text;
    } else {
      merged.push(current);
      current = { ...segments[i] };
    }
  }
  merged.push(current);
  
  return merged;
}

export function computeDiff(oldVersion: { title: string; content: string }, newVersion: { title: string; content: string }): DiffResult {
  return {
    title: diffWords(oldVersion.title, newVersion.title),
    content: diffWords(oldVersion.content, newVersion.content),
  };
}

export function hasChanges(diff: DiffResult): boolean {
  const titleChanged = diff.title.some(s => s.type !== 'unchanged');
  const contentChanged = diff.content.some(s => s.type !== 'unchanged');
  return titleChanged || contentChanged;
}
