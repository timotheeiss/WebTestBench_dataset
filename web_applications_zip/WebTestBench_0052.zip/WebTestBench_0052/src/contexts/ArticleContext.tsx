import React, { createContext, useContext, ReactNode } from 'react';
import { useArticles } from '@/hooks/useArticles';

type ArticleContextType = ReturnType<typeof useArticles>;

const ArticleContext = createContext<ArticleContextType | undefined>(undefined);

export function ArticleProvider({ children }: { children: ReactNode }) {
  const articles = useArticles();
  return (
    <ArticleContext.Provider value={articles}>
      {children}
    </ArticleContext.Provider>
  );
}

export function useArticleContext() {
  const context = useContext(ArticleContext);
  if (context === undefined) {
    throw new Error('useArticleContext must be used within an ArticleProvider');
  }
  return context;
}
