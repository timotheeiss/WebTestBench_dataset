import { useState } from 'react';
import { ArticleVersion } from '@/types/article';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { History, RotateCcw, Eye, GitCompare, MessageSquare, X } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { computeDiff, DiffSegment, hasChanges } from '@/lib/diffUtils';
import { cn } from '@/lib/utils';

interface VersionHistoryProps {
  versions: ArticleVersion[];
  currentTitle: string;
  currentContent: string;
  onRollback: (version: ArticleVersion) => void;
  onAddNote: (versionId: string, note: string) => void;
}

function DiffView({ segments }: { segments: DiffSegment[] }) {
  return (
    <span>
      {segments.map((segment, idx) => (
        <span
          key={idx}
          className={cn(
            segment.type === 'added' && 'bg-green-500/20 text-green-700 dark:text-green-400',
            segment.type === 'removed' && 'bg-red-500/20 text-red-700 dark:text-red-400 line-through',
          )}
        >
          {segment.text}
        </span>
      ))}
    </span>
  );
}

export function VersionHistory({ versions, currentTitle, currentContent, onRollback, onAddNote }: VersionHistoryProps) {
  const [selectedVersion, setSelectedVersion] = useState<ArticleVersion | null>(null);
  const [compareVersion, setCompareVersion] = useState<ArticleVersion | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [noteVersion, setNoteVersion] = useState<ArticleVersion | null>(null);
  const [noteText, setNoteText] = useState('');

  const handleCompareWithCurrent = (version: ArticleVersion) => {
    setSelectedVersion(version);
    setCompareVersion(null);
    setShowComparison(true);
  };

  const handleCompareVersions = (v1: ArticleVersion, v2: ArticleVersion) => {
    setSelectedVersion(v1);
    setCompareVersion(v2);
    setShowComparison(true);
  };

  const handleAddNote = (version: ArticleVersion) => {
    setNoteVersion(version);
    setNoteText(version.note || '');
    setNoteDialogOpen(true);
  };

  const saveNote = () => {
    if (noteVersion) {
      onAddNote(noteVersion.id, noteText);
      setNoteDialogOpen(false);
      setNoteVersion(null);
      setNoteText('');
    }
  };

  const getDiff = () => {
    if (!selectedVersion) return null;
    
    const oldVersion = { title: selectedVersion.title, content: selectedVersion.content };
    const newVersion = compareVersion 
      ? { title: compareVersion.title, content: compareVersion.content }
      : { title: currentTitle, content: currentContent };
    
    return computeDiff(oldVersion, newVersion);
  };

  const diff = showComparison ? getDiff() : null;

  if (versions.length === 0) {
    return (
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <History className="h-4 w-4" />
            History
          </Button>
        </SheetTrigger>
        <SheetContent className="w-[400px] sm:w-[540px]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Version History
            </SheetTitle>
          </SheetHeader>
          <div className="flex items-center justify-center h-[50vh] text-muted-foreground">
            No versions saved yet. Save a version to start tracking changes.
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <>
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <History className="h-4 w-4" />
            History
            <span className="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-muted">
              {versions.length}
            </span>
          </Button>
        </SheetTrigger>
        <SheetContent className="w-[400px] sm:w-[600px]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Version History
            </SheetTitle>
          </SheetHeader>

          <ScrollArea className="h-[calc(100vh-8rem)] mt-6 pr-4">
            <div className="space-y-3">
              <AnimatePresence>
                {versions.map((version, index) => (
                  <motion.div
                    key={version.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ delay: index * 0.05 }}
                    className="p-4 rounded-lg border border-border bg-card hover:bg-card/80 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-sm truncate max-w-[280px]">
                          {version.title || 'Untitled'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(version.createdAt, 'MMM d, yyyy · h:mm a')}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">
                        v{versions.length - index}
                      </span>
                    </div>

                    {version.note && (
                      <div className="mb-3 p-2 rounded bg-accent/10 border border-accent/20">
                        <p className="text-xs text-accent-foreground italic">
                          "{version.note}"
                        </p>
                      </div>
                    )}

                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                      {version.content.substring(0, 150)}...
                    </p>

                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs gap-1"
                        onClick={() => handleCompareWithCurrent(version)}
                      >
                        <GitCompare className="h-3 w-3" />
                        Compare
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs gap-1"
                        onClick={() => onRollback(version)}
                      >
                        <RotateCcw className="h-3 w-3" />
                        Rollback
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs gap-1"
                        onClick={() => handleAddNote(version)}
                      >
                        <MessageSquare className="h-3 w-3" />
                        {version.note ? 'Edit Note' : 'Add Note'}
                      </Button>
                    </div>

                    {index < versions.length - 1 && (
                      <div className="mt-3 pt-3 border-t border-border/50">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 text-xs gap-1 text-muted-foreground"
                          onClick={() => handleCompareVersions(versions[index + 1], version)}
                        >
                          <Eye className="h-3 w-3" />
                          Compare with v{versions.length - index - 1}
                        </Button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {/* Comparison Dialog */}
      <Dialog open={showComparison} onOpenChange={setShowComparison}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GitCompare className="h-5 w-5" />
              {compareVersion ? (
                <>Comparing v{versions.findIndex(v => v.id === selectedVersion?.id) !== -1 ? versions.length - versions.findIndex(v => v.id === selectedVersion?.id) : '?'} → v{versions.findIndex(v => v.id === compareVersion?.id) !== -1 ? versions.length - versions.findIndex(v => v.id === compareVersion?.id) : '?'}</>
              ) : (
                <>Comparing with Current</>
              )}
            </DialogTitle>
          </DialogHeader>

          {diff && (
            <ScrollArea className="h-[60vh] pr-4">
              <div className="space-y-6">
                {/* Title Diff */}
                <div>
                  <h3 className="text-sm font-medium mb-2 text-muted-foreground">Title</h3>
                  <div className="p-3 rounded-lg bg-muted/50 font-medium">
                    <DiffView segments={diff.title} />
                  </div>
                </div>

                {/* Content Diff */}
                <div>
                  <h3 className="text-sm font-medium mb-2 text-muted-foreground">Content</h3>
                  <div className="p-4 rounded-lg bg-muted/50 whitespace-pre-wrap text-sm leading-relaxed">
                    <DiffView segments={diff.content} />
                  </div>
                </div>

                {/* Legend */}
                <div className="flex items-center gap-4 text-xs text-muted-foreground pt-4 border-t border-border">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded bg-green-500/20 border border-green-500/40" />
                    Added
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded bg-red-500/20 border border-red-500/40" />
                    Removed
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowComparison(false)}>
              Close
            </Button>
            {selectedVersion && !compareVersion && (
              <Button onClick={() => { onRollback(selectedVersion); setShowComparison(false); }}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Rollback to this version
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Note Dialog */}
      <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Version Note</DialogTitle>
          </DialogHeader>
          <Textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Add a note to describe this version (e.g., 'Added introduction paragraph')"
            className="min-h-[100px]"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setNoteDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveNote}>
              Save Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
