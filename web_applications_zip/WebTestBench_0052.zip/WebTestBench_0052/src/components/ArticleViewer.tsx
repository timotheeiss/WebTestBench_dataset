import { Article } from '@/types/article';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

interface ArticleViewerProps {
  article: Article;
  onBack: () => void;
}

export function ArticleViewer({ article, onBack }: ArticleViewerProps) {
  const displayDate = article.publishedAt || article.updatedAt;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-background"
    >
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={onBack} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to articles
          </Button>
        </div>
      </header>

      {/* Article Content */}
      <main className="max-w-3xl mx-auto px-4 py-12">
        <article>
          <header className="mb-12 text-center">
            <h1 className="article-title text-foreground mb-4">
              {article.title}
            </h1>
            <time className="text-muted-foreground text-sm">
              {format(displayDate, 'MMMM d, yyyy')}
            </time>
          </header>

          <div className="article-content text-foreground/90 space-y-6">
            {article.content.split('\n\n').map((paragraph, index) => (
              <motion.p
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                {paragraph}
              </motion.p>
            ))}
          </div>
        </article>
      </main>
    </motion.div>
  );
}
