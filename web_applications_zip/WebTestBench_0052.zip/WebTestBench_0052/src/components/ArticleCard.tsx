import { Article } from '@/types/article';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { Pencil, Eye, Send, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface ArticleCardProps {
  article: Article;
  onEdit?: () => void;
  onView?: () => void;
  onPublish?: () => void;
  onDelete?: () => void;
}

export function ArticleCard({ article, onEdit, onView, onPublish, onDelete }: ArticleCardProps) {
  const isDraft = article.status === 'draft';
  const displayDate = isDraft ? article.updatedAt : article.publishedAt || article.updatedAt;
  const dateLabel = isDraft ? 'Last edited' : 'Published';

  const excerpt = article.content.slice(0, 150) + (article.content.length > 150 ? '...' : '');

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="p-6 bg-card shadow-card card-hover border-border/50 group">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-display text-xl font-semibold text-foreground truncate">
              {article.title || 'Untitled'}
            </h3>
          </div>
          <Badge
            variant={isDraft ? 'outline' : 'default'}
            className={isDraft ? 'border-accent text-accent shrink-0' : 'shrink-0'}
          >
            {isDraft ? 'Draft' : 'Published'}
          </Badge>
        </div>

        <p className="text-muted-foreground font-body text-sm leading-relaxed mb-4 line-clamp-2">
          {excerpt}
        </p>

        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {dateLabel} {format(displayDate, 'MMM d, yyyy')}
          </span>

          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {isDraft ? (
              <>
                <Button variant="ghost" size="sm" onClick={onEdit}>
                  <Pencil className="h-4 w-4" />
                  Edit
                </Button>
                <Button variant="publish" size="sm" onClick={onPublish}>
                  <Send className="h-4 w-4" />
                  Publish
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={onDelete}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button variant="ghost" size="sm" onClick={onView}>
                <Eye className="h-4 w-4" />
                Read
              </Button>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
