import { ArticleCard } from './ArticleCard';
import { Article } from '@/types/article';
import { motion } from 'framer-motion';
import { FileText } from 'lucide-react';

interface ArticleListProps {
  articles: Article[];
  emptyMessage: string;
  onEdit?: (id: string) => void;
  onView?: (id: string) => void;
  onPublish?: (id: string) => void;
  onDelete?: (id: string) => void;
}

export function ArticleList({ articles, emptyMessage, onEdit, onView, onPublish, onDelete }: ArticleListProps) {
  if (articles.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center py-20 text-center"
      >
        <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4">
          <FileText className="w-8 h-8 text-muted-foreground" />
        </div>
        <p className="text-muted-foreground font-body text-lg">
          {emptyMessage}
        </p>
      </motion.div>
    );
  }

  return (
    <div className="grid gap-4">
      {articles.map((article, index) => (
        <motion.div
          key={article.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <ArticleCard
            article={article}
            onEdit={onEdit ? () => onEdit(article.id) : undefined}
            onView={onView ? () => onView(article.id) : undefined}
            onPublish={onPublish ? () => onPublish(article.id) : undefined}
            onDelete={onDelete ? () => onDelete(article.id) : undefined}
          />
        </motion.div>
      ))}
    </div>
  );
}
