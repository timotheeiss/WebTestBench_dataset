import { useState, useEffect } from 'react';
import { Article, ArticleFormData } from '@/types/article';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { VersionHistory } from '@/components/VersionHistory';
import { ArrowLeft, Save, Send, Bookmark } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface ArticleEditorProps {
  article?: Article;
  onSave: (data: ArticleFormData) => void;
  onPublish?: () => void;
  onBack: () => void;
  onSaveVersion?: (note?: string) => void;
  onRollback?: (version: { title: string; content: string }) => void;
  onAddVersionNote?: (versionId: string, note: string) => void;
  isNew?: boolean;
}

export function ArticleEditor({ 
  article, 
  onSave, 
  onPublish, 
  onBack, 
  onSaveVersion,
  onRollback,
  onAddVersionNote,
  isNew = false 
}: ArticleEditorProps) {
  const [title, setTitle] = useState(article?.title || '');
  const [content, setContent] = useState(article?.content || '');
  const [hasChanges, setHasChanges] = useState(false);
  const [saveVersionDialogOpen, setSaveVersionDialogOpen] = useState(false);
  const [versionNote, setVersionNote] = useState('');

  useEffect(() => {
    if (article) {
      setTitle(article.title);
      setContent(article.content);
    }
  }, [article]);

  useEffect(() => {
    const originalTitle = article?.title || '';
    const originalContent = article?.content || '';
    setHasChanges(title !== originalTitle || content !== originalContent);
  }, [title, content, article]);

  const handleSave = () => {
    onSave({ title, content });
    setHasChanges(false);
  };

  const handleSaveVersion = () => {
    if (hasChanges) {
      onSave({ title, content });
    }
    if (onSaveVersion) {
      onSaveVersion(versionNote || undefined);
      toast.success('Version saved');
    }
    setSaveVersionDialogOpen(false);
    setVersionNote('');
  };

  const handleRollback = (version: { title: string; content: string }) => {
    setTitle(version.title);
    setContent(version.content);
    if (onRollback) {
      onRollback(version);
    }
    toast.success('Rolled back to selected version');
  };

  const canPublish = title.trim().length > 0 && content.trim().length > 0;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-background"
    >
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          <div className="flex items-center gap-2">
            {article && !isNew && (
              <>
                <VersionHistory
                  versions={article.versions || []}
                  currentTitle={title}
                  currentContent={content}
                  onRollback={handleRollback}
                  onAddNote={(versionId, note) => onAddVersionNote?.(versionId, note)}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSaveVersionDialogOpen(true)}
                  className="gap-2"
                >
                  <Bookmark className="h-4 w-4" />
                  Save Version
                </Button>
              </>
            )}

            <Button
              variant="outline"
              onClick={handleSave}
              disabled={!hasChanges && !isNew}
              className="gap-2"
            >
              <Save className="h-4 w-4" />
              Save Draft
            </Button>

            {onPublish && (
              <Button
                variant="publish"
                onClick={() => {
                  if (hasChanges || isNew) {
                    onSave({ title, content });
                  }
                  onPublish();
                }}
                disabled={!canPublish}
                className="gap-2"
              >
                <Send className="h-4 w-4" />
                Publish
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Editor */}
      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="space-y-8">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Article title..."
            className="border-none text-3xl md:text-4xl font-display font-semibold bg-transparent placeholder:text-muted-foreground/50 focus-visible:ring-0 px-0 h-auto py-2"
          />

          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Start writing your article..."
            className="border-none min-h-[60vh] text-lg font-body leading-relaxed bg-transparent placeholder:text-muted-foreground/50 focus-visible:ring-0 px-0 resize-none"
          />
        </div>
      </main>

      {/* Save Version Dialog */}
      <Dialog open={saveVersionDialogOpen} onOpenChange={setSaveVersionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Version</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Save the current state as a version snapshot. You can optionally add a note to describe this version.
          </p>
          <Textarea
            value={versionNote}
            onChange={(e) => setVersionNote(e.target.value)}
            placeholder="Optional: Describe what changed (e.g., 'Rewrote introduction')"
            className="min-h-[80px]"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveVersionDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveVersion}>
              <Bookmark className="h-4 w-4 mr-2" />
              Save Version
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
