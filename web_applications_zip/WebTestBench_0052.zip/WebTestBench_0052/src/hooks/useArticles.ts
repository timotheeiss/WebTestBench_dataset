import { useState, useCallback } from 'react';
import { Article, ArticleFormData, ArticleVersion } from '@/types/article';
import { defaultArticles } from '@/data/defaultArticles';

export function useArticles() {
  const [articles, setArticles] = useState<Article[]>(defaultArticles);

  const getDrafts = useCallback(() => {
    return articles.filter((a) => a.status === 'draft').sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }, [articles]);

  const getPublished = useCallback(() => {
    return articles.filter((a) => a.status === 'published').sort((a, b) => {
      const dateA = a.publishedAt?.getTime() || 0;
      const dateB = b.publishedAt?.getTime() || 0;
      return dateB - dateA;
    });
  }, [articles]);

  const getArticle = useCallback((id: string) => {
    return articles.find((a) => a.id === id);
  }, [articles]);

  const createDraft = useCallback((data: ArticleFormData) => {
    const now = new Date();
    const newArticle: Article = {
      id: crypto.randomUUID(),
      ...data,
      status: 'draft',
      createdAt: now,
      updatedAt: now,
      versions: [],
    };
    setArticles((prev) => [...prev, newArticle]);
    return newArticle;
  }, []);

  const updateArticle = useCallback((id: string, data: Partial<ArticleFormData>) => {
    setArticles((prev) =>
      prev.map((a) =>
        a.id === id
          ? { ...a, ...data, updatedAt: new Date() }
          : a
      )
    );
  }, []);

  const saveVersion = useCallback((id: string, note?: string) => {
    setArticles((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const newVersion: ArticleVersion = {
            id: crypto.randomUUID(),
            title: a.title,
            content: a.content,
            createdAt: new Date(),
            note,
          };
          return {
            ...a,
            versions: [newVersion, ...a.versions],
          };
        }
        return a;
      })
    );
  }, []);

  const rollbackToVersion = useCallback((articleId: string, version: { title: string; content: string }) => {
    setArticles((prev) =>
      prev.map((a) =>
        a.id === articleId
          ? {
              ...a,
              title: version.title,
              content: version.content,
              updatedAt: new Date(),
            }
          : a
      )
    );
  }, []);

  const addVersionNote = useCallback((articleId: string, versionId: string, note: string) => {
    setArticles((prev) =>
      prev.map((a) => {
        if (a.id === articleId) {
          return {
            ...a,
            versions: a.versions.map((v) =>
              v.id === versionId ? { ...v, note } : v
            ),
          };
        }
        return a;
      })
    );
  }, []);

  const publishArticle = useCallback((id: string) => {
    const now = new Date();
    setArticles((prev) =>
      prev.map((a) =>
        a.id === id
          ? { ...a, status: 'published', publishedAt: now, updatedAt: now }
          : a
      )
    );
  }, []);

  const deleteArticle = useCallback((id: string) => {
    setArticles((prev) => prev.filter((a) => a.id !== id));
  }, []);

  return {
    articles,
    getDrafts,
    getPublished,
    getArticle,
    createDraft,
    updateArticle,
    saveVersion,
    rollbackToVersion,
    addVersionNote,
    publishArticle,
    deleteArticle,
  };
}
