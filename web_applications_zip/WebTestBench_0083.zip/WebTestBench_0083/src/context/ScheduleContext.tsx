import React, { createContext, useContext, useState, useCallback } from 'react';
import {
  Employee,
  Shift,
  ScheduleTemplate,
  PublishedSchedule,
  initialEmployees,
  initialTemplates,
  initialPublishedSchedules,
  ShiftType,
  SHIFT_TIMES,
} from '@/data/initialData';

interface ScheduleContextType {
  employees: Employee[];
  currentShifts: Shift[];
  templates: ScheduleTemplate[];
  publishedSchedules: PublishedSchedule[];
  currentWeekStart: Date;
  
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  updateEmployee: (id: string, updates: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  
  addShift: (employeeId: string, day: number, type: ShiftType) => void;
  removeShift: (shiftId: string) => void;
  clearSchedule: () => void;
  
  saveTemplate: (name: string) => void;
  loadTemplate: (templateId: string) => void;
  deleteTemplate: (templateId: string) => void;
  
  publishSchedule: () => void;
  setCurrentWeekStart: (date: Date) => void;
}

const ScheduleContext = createContext<ScheduleContextType | undefined>(undefined);

export function ScheduleProvider({ children }: { children: React.ReactNode }) {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [currentShifts, setCurrentShifts] = useState<Shift[]>([]);
  const [templates, setTemplates] = useState<ScheduleTemplate[]>(initialTemplates);
  const [publishedSchedules, setPublishedSchedules] = useState<PublishedSchedule[]>(initialPublishedSchedules);
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(() => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    const diff = today.getDate() - dayOfWeek;
    return new Date(today.setDate(diff));
  });

  const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const addEmployee = useCallback((employee: Omit<Employee, 'id'>) => {
    setEmployees(prev => [...prev, { ...employee, id: generateId() }]);
  }, []);

  const updateEmployee = useCallback((id: string, updates: Partial<Employee>) => {
    setEmployees(prev => prev.map(emp => emp.id === id ? { ...emp, ...updates } : emp));
  }, []);

  const deleteEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
    setCurrentShifts(prev => prev.filter(shift => shift.employeeId !== id));
  }, []);

  const addShift = useCallback((employeeId: string, day: number, type: ShiftType) => {
    const times = SHIFT_TIMES[type];
    const newShift: Shift = {
      id: generateId(),
      employeeId,
      day,
      type,
      startTime: times.start,
      endTime: times.end,
    };
    setCurrentShifts(prev => [...prev, newShift]);
  }, []);

  const removeShift = useCallback((shiftId: string) => {
    setCurrentShifts(prev => prev.filter(shift => shift.id !== shiftId));
  }, []);

  const clearSchedule = useCallback(() => {
    setCurrentShifts([]);
  }, []);

  const saveTemplate = useCallback((name: string) => {
    const template: ScheduleTemplate = {
      id: generateId(),
      name,
      createdAt: new Date().toISOString(),
      shifts: currentShifts.map(({ id, ...rest }) => rest),
    };
    setTemplates(prev => [...prev, template]);
  }, [currentShifts]);

  const loadTemplate = useCallback((templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      const shifts: Shift[] = template.shifts.map(shift => ({
        ...shift,
        id: generateId(),
      }));
      setCurrentShifts(shifts);
    }
  }, [templates]);

  const deleteTemplate = useCallback((templateId: string) => {
    setTemplates(prev => prev.filter(t => t.id !== templateId));
  }, []);

  const publishSchedule = useCallback(() => {
    const published: PublishedSchedule = {
      id: generateId(),
      weekStart: currentWeekStart.toISOString().split('T')[0],
      publishedAt: new Date().toISOString(),
      shifts: [...currentShifts],
    };
    setPublishedSchedules(prev => [...prev, published]);
  }, [currentShifts, currentWeekStart]);

  return (
    <ScheduleContext.Provider
      value={{
        employees,
        currentShifts,
        templates,
        publishedSchedules,
        currentWeekStart,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        addShift,
        removeShift,
        clearSchedule,
        saveTemplate,
        loadTemplate,
        deleteTemplate,
        publishSchedule,
        setCurrentWeekStart,
      }}
    >
      {children}
    </ScheduleContext.Provider>
  );
}

export function useSchedule() {
  const context = useContext(ScheduleContext);
  if (!context) {
    throw new Error('useSchedule must be used within a ScheduleProvider');
  }
  return context;
}
