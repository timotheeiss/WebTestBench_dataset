import { useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { EmployeeCard } from '@/components/employees/EmployeeCard';
import { EmployeeDialog } from '@/components/employees/EmployeeDialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useSchedule } from '@/context/ScheduleContext';
import { Employee } from '@/data/initialData';
import { Plus, Search } from 'lucide-react';
import { toast } from 'sonner';

export default function EmployeesPage() {
  const { employees, addEmployee, updateEmployee, deleteEmployee } = useSchedule();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEmployees = employees.filter(
    (emp) =>
      emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    deleteEmployee(id);
    toast.success('Employee deleted');
  };

  const handleSave = (data: Omit<Employee, 'id'> | Employee) => {
    if ('id' in data) {
      updateEmployee(data.id, data);
      toast.success('Employee updated');
    } else {
      addEmployee(data);
      toast.success('Employee added');
    }
    setEditingEmployee(null);
  };

  const handleOpenNew = () => {
    setEditingEmployee(null);
    setDialogOpen(true);
  };

  return (
    <AppLayout>
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Employees</h1>
            <p className="text-muted-foreground">
              Manage employee profiles and their skills.
            </p>
          </div>
          <Button onClick={handleOpenNew}>
            <Plus className="w-4 h-4 mr-2" />
            Add Employee
          </Button>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, role, or skill..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {filteredEmployees.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">
              {searchQuery ? 'No employees match your search.' : 'No employees added yet.'}
            </p>
            {!searchQuery && (
              <Button onClick={handleOpenNew}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Employee
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEmployees.map((employee) => (
              <EmployeeCard
                key={employee.id}
                employee={employee}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}

        <EmployeeDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          employee={editingEmployee}
          onSave={handleSave}
        />
      </div>
    </AppLayout>
  );
}
