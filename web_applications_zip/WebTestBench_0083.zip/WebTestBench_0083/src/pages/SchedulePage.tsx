import { AppLayout } from '@/components/layout/AppLayout';
import { ScheduleGrid } from '@/components/schedule/ScheduleGrid';
import { ScheduleActions } from '@/components/schedule/ScheduleActions';

export default function SchedulePage() {
  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">Schedule</h1>
          <p className="text-muted-foreground">
            Create and manage weekly employee shift schedules.
          </p>
        </div>

        <ScheduleActions />
        <ScheduleGrid />
      </div>
    </AppLayout>
  );
}
