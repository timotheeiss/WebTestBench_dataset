import { useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useSchedule } from '@/context/ScheduleContext';
import { PublishedSchedule, SHORT_DAYS, SHIFT_TIMES } from '@/data/initialData';
import { History, Calendar, ChevronRight, Clock, User } from 'lucide-react';
import { format, addDays } from 'date-fns';

export default function PublishedPage() {
  const { publishedSchedules, employees } = useSchedule();
  const [selectedSchedule, setSelectedSchedule] = useState<PublishedSchedule | null>(null);

  const getEmployeeById = (id: string) => employees.find((e) => e.id === id);

  const sortedSchedules = [...publishedSchedules].sort(
    (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  if (selectedSchedule) {
    const weekStart = new Date(selectedSchedule.weekStart);

    return (
      <AppLayout>
        <div className="p-8">
          <div className="mb-6">
            <Button variant="ghost" onClick={() => setSelectedSchedule(null)} className="mb-4">
              ← Back to History
            </Button>
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Week of {format(weekStart, 'MMMM d, yyyy')}
            </h1>
            <p className="text-muted-foreground">
              Published on {format(new Date(selectedSchedule.publishedAt), 'MMMM d, yyyy at h:mm a')}
            </p>
          </div>

          <Card>
            <CardContent className="p-0">
              {/* Header */}
              <div className="grid grid-cols-8 border-b border-border">
                <div className="p-4 bg-muted/50 font-medium text-muted-foreground">
                  Employee
                </div>
                {SHORT_DAYS.map((day, index) => (
                  <div key={day} className="p-4 bg-muted/50 text-center border-l border-border">
                    <div className="font-medium text-foreground">{day}</div>
                    <div className="text-xs text-muted-foreground">
                      {format(addDays(weekStart, index), 'MMM d')}
                    </div>
                  </div>
                ))}
              </div>

              {/* Shifts by Employee */}
              {employees.map((employee) => {
                const employeeShifts = selectedSchedule.shifts.filter(
                  (s) => s.employeeId === employee.id
                );
                if (employeeShifts.length === 0) return null;

                return (
                  <div key={employee.id} className="grid grid-cols-8 border-b border-border last:border-b-0">
                    <div className="p-4 flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full ${employee.color} flex items-center justify-center text-white font-medium text-sm`}>
                        {employee.avatar}
                      </div>
                      <div>
                        <div className="font-medium text-sm">{employee.name}</div>
                        <div className="text-xs text-muted-foreground">{employee.role}</div>
                      </div>
                    </div>

                    {SHORT_DAYS.map((_, dayIndex) => {
                      const dayShifts = employeeShifts.filter((s) => s.day === dayIndex);
                      return (
                        <div key={dayIndex} className="p-2 border-l border-border min-h-[80px]">
                          {dayShifts.map((shift) => {
                            const times = SHIFT_TIMES[shift.type];
                            return (
                              <div
                                key={shift.id}
                                className={`rounded-lg p-2 text-sm mb-1 shift-${shift.type}`}
                              >
                                <div className="font-medium text-xs">{times.label}</div>
                                <div className="text-[10px] opacity-80">
                                  {shift.startTime} - {shift.endTime}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Summary */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{selectedSchedule.shifts.length}</p>
                  <p className="text-sm text-muted-foreground">Total Shifts</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                  <User className="w-6 h-6 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-bold">
                    {new Set(selectedSchedule.shifts.map((s) => s.employeeId)).size}
                  </p>
                  <p className="text-sm text-muted-foreground">Employees Scheduled</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <p className="text-2xl font-bold">
                    {new Set(selectedSchedule.shifts.map((s) => s.day)).size}
                  </p>
                  <p className="text-sm text-muted-foreground">Days Covered</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">Published Schedules</h1>
          <p className="text-muted-foreground">
            View previously published schedules and their details.
          </p>
        </div>

        {sortedSchedules.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <History className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground mb-4">No schedules published yet.</p>
            <p className="text-sm text-muted-foreground">
              Create a schedule and publish it to see it here.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {sortedSchedules.map((schedule) => (
              <Card
                key={schedule.id}
                className="cursor-pointer hover:border-primary/50 hover:shadow-md transition-all animate-fade-in"
                onClick={() => setSelectedSchedule(schedule)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-success" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">
                          Week of {format(new Date(schedule.weekStart), 'MMMM d, yyyy')}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {schedule.shifts.length} shifts •{' '}
                          {new Set(schedule.shifts.map((s) => s.employeeId)).size} employees
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium">Published</p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(schedule.publishedAt), 'MMM d, h:mm a')}
                        </p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
