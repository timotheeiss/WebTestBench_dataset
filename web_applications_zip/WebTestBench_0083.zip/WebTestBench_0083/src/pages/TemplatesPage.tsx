import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useSchedule } from '@/context/ScheduleContext';
import { FileText, Trash2, Upload, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export default function TemplatesPage() {
  const { templates, deleteTemplate, loadTemplate } = useSchedule();
  const navigate = useNavigate();

  const handleLoad = (templateId: string) => {
    loadTemplate(templateId);
    toast.success('Template loaded to schedule');
    navigate('/schedule');
  };

  const handleDelete = (templateId: string) => {
    deleteTemplate(templateId);
    toast.success('Template deleted');
  };

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">Templates</h1>
          <p className="text-muted-foreground">
            Save common schedule patterns as templates for quick reuse.
          </p>
        </div>

        {templates.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground mb-4">No templates saved yet.</p>
            <p className="text-sm text-muted-foreground">
              Create a schedule and save it as a template to reuse later.
            </p>
            <Button variant="outline" className="mt-4" onClick={() => navigate('/schedule')}>
              <Calendar className="w-4 h-4 mr-2" />
              Go to Schedule
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((template) => (
              <Card key={template.id} className="hover:shadow-md transition-shadow animate-fade-in">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(template.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <h3 className="font-semibold text-lg mb-1">{template.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {template.shifts.length} shifts • Created{' '}
                    {format(new Date(template.createdAt), 'MMM d, yyyy')}
                  </p>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleLoad(template.id)}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Load
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
