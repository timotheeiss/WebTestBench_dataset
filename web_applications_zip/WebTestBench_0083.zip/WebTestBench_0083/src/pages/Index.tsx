import { AppLayout } from '@/components/layout/AppLayout';
import { useSchedule } from '@/context/ScheduleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Calendar, FileText, History, ArrowRight, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';

export default function Index() {
  const { employees, currentShifts, templates, publishedSchedules, currentWeekStart } = useSchedule();

  const stats = [
    { label: 'Employees', value: employees.length, icon: Users, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Current Shifts', value: currentShifts.length, icon: Clock, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { label: 'Templates', value: templates.length, icon: FileText, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Published', value: publishedSchedules.length, icon: History, color: 'text-rose-500', bg: 'bg-rose-50' },
  ];

  const quickActions = [
    { label: 'Create Schedule', description: 'Build weekly schedules by assigning shifts', path: '/schedule', icon: Calendar },
    { label: 'Manage Employees', description: 'Add and edit employee profiles and skills', path: '/employees', icon: Users },
    { label: 'View Templates', description: 'Load or manage your saved templates', path: '/templates', icon: FileText },
    { label: 'Published History', description: 'View previously published schedules', path: '/published', icon: History },
  ];

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back! Here's an overview of your scheduling system.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label} className="border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Current Week Banner */}
        <Card className="mb-8 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-primary font-medium mb-1">Current Week</p>
                <p className="text-xl font-semibold">
                  Week of {format(currentWeekStart, 'MMMM d, yyyy')}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {currentShifts.length} shifts scheduled for this week
                </p>
              </div>
              <Link
                to="/schedule"
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                Open Schedule
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quickActions.map((action) => (
              <Link key={action.path} to={action.path}>
                <Card className="hover:border-primary/50 hover:shadow-md transition-all cursor-pointer group">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <action.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1 group-hover:text-primary transition-colors">
                          {action.label}
                        </h3>
                        <p className="text-sm text-muted-foreground">{action.description}</p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        {publishedSchedules.length > 0 && (
          <div className="mt-8">
            <h2 className="text-lg font-semibold mb-4">Recent Publications</h2>
            <Card>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {publishedSchedules.slice(-3).reverse().map((pub) => (
                    <div key={pub.id} className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
                          <History className="w-5 h-5 text-success" />
                        </div>
                        <div>
                          <p className="font-medium">Week of {format(new Date(pub.weekStart), 'MMM d, yyyy')}</p>
                          <p className="text-sm text-muted-foreground">
                            {pub.shifts.length} shifts • Published {format(new Date(pub.publishedAt), 'MMM d, h:mm a')}
                          </p>
                        </div>
                      </div>
                      <Link
                        to="/published"
                        className="text-sm text-primary hover:underline"
                      >
                        View
                      </Link>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
