import { Employee, SKILL_COLORS } from '@/data/initialData';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2 } from 'lucide-react';

interface EmployeeCardProps {
  employee: Employee;
  onEdit: (employee: Employee) => void;
  onDelete: (id: string) => void;
}

export function EmployeeCard({ employee, onEdit, onDelete }: EmployeeCardProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-5 animate-fade-in hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-full ${employee.color} flex items-center justify-center text-white font-semibold text-lg`}>
            {employee.avatar}
          </div>
          <div>
            <h3 className="font-semibold text-lg">{employee.name}</h3>
            <p className="text-muted-foreground">{employee.role}</p>
          </div>
        </div>
        
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" onClick={() => onEdit(employee)}>
            <Pencil className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(employee.id)}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-2">Skills</p>
        <div className="flex flex-wrap gap-2">
          {employee.skills.map((skill) => (
            <span
              key={skill}
              className={`skill-badge ${SKILL_COLORS[skill] || 'bg-muted text-muted-foreground'}`}
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
