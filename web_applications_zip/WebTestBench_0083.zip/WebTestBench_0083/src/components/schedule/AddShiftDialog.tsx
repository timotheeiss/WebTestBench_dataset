import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useSchedule } from '@/context/ScheduleContext';
import { SHIFT_TIMES, DAYS, ShiftType } from '@/data/initialData';
import { Sun, Cloud, Sunset, Moon } from 'lucide-react';

interface AddShiftDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employeeId: string;
  day: number;
}

const shiftIcons: Record<ShiftType, typeof Sun> = {
  morning: Sun,
  afternoon: Cloud,
  evening: Sunset,
  night: Moon,
};

export function AddShiftDialog({ open, onOpenChange, employeeId, day }: AddShiftDialogProps) {
  const { addShift, employees } = useSchedule();
  const employee = employees.find((e) => e.id === employeeId);

  const handleAddShift = (type: ShiftType) => {
    addShift(employeeId, day, type);
    onOpenChange(false);
  };

  if (!employee) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Shift</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <div className="flex items-center gap-3 mb-6 p-3 bg-muted rounded-lg">
            <div className={`w-10 h-10 rounded-full ${employee.color} flex items-center justify-center text-white font-medium`}>
              {employee.avatar}
            </div>
            <div>
              <div className="font-medium">{employee.name}</div>
              <div className="text-sm text-muted-foreground">{DAYS[day]}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {(Object.keys(SHIFT_TIMES) as ShiftType[]).map((type) => {
              const Icon = shiftIcons[type];
              const times = SHIFT_TIMES[type];
              
              return (
                <Button
                  key={type}
                  variant="outline"
                  className="h-auto p-4 flex flex-col items-center gap-2 hover:border-primary hover:bg-primary/5"
                  onClick={() => handleAddShift(type)}
                >
                  <Icon className="w-6 h-6" />
                  <div className="text-sm font-medium capitalize">{times.label}</div>
                  <div className="text-xs text-muted-foreground">
                    {times.start} - {times.end}
                  </div>
                </Button>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
