import { useState } from 'react';
import { useSchedule } from '@/context/ScheduleContext';
import { SHORT_DAYS, SHIFT_TIMES, ShiftType } from '@/data/initialData';
import { ShiftCard } from './ShiftCard';
import { AddShiftDialog } from './AddShiftDialog';
import { Plus } from 'lucide-react';
import { format, addDays } from 'date-fns';

export function ScheduleGrid() {
  const { employees, currentShifts, currentWeekStart } = useSchedule();
  const [selectedCell, setSelectedCell] = useState<{ employeeId: string; day: number } | null>(null);

  const getShiftsForCell = (employeeId: string, day: number) => {
    return currentShifts.filter(
      (shift) => shift.employeeId === employeeId && shift.day === day
    );
  };

  const getDayDate = (dayIndex: number) => {
    return addDays(currentWeekStart, dayIndex);
  };

  return (
    <>
      <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
        {/* Header */}
        <div className="grid grid-cols-8 border-b border-border">
          <div className="p-4 bg-muted/50 font-medium text-muted-foreground">
            Employee
          </div>
          {SHORT_DAYS.map((day, index) => (
            <div key={day} className="p-4 bg-muted/50 text-center border-l border-border">
              <div className="font-medium text-foreground">{day}</div>
              <div className="text-xs text-muted-foreground">
                {format(getDayDate(index), 'MMM d')}
              </div>
            </div>
          ))}
        </div>

        {/* Body */}
        {employees.map((employee) => (
          <div key={employee.id} className="grid grid-cols-8 border-b border-border last:border-b-0">
            {/* Employee Cell */}
            <div className="p-4 flex items-center gap-3 bg-card">
              <div className={`w-10 h-10 rounded-full ${employee.color} flex items-center justify-center text-white font-medium text-sm`}>
                {employee.avatar}
              </div>
              <div>
                <div className="font-medium text-sm">{employee.name}</div>
                <div className="text-xs text-muted-foreground">{employee.role}</div>
              </div>
            </div>

            {/* Day Cells */}
            {SHORT_DAYS.map((_, dayIndex) => {
              const shifts = getShiftsForCell(employee.id, dayIndex);
              return (
                <div
                  key={dayIndex}
                  className="schedule-cell border-l border-border relative group"
                >
                  <div className="space-y-1.5">
                    {shifts.map((shift) => (
                      <ShiftCard key={shift.id} shift={shift} />
                    ))}
                  </div>
                  
                  <button
                    onClick={() => setSelectedCell({ employeeId: employee.id, day: dayIndex })}
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-accent/50"
                  >
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Plus className="w-4 h-4 text-primary" />
                    </div>
                  </button>
                </div>
              );
            })}
          </div>
        ))}

        {employees.length === 0 && (
          <div className="p-12 text-center text-muted-foreground">
            <p>No employees added yet. Add employees to start scheduling.</p>
          </div>
        )}
      </div>

      <AddShiftDialog
        open={selectedCell !== null}
        onOpenChange={(open) => !open && setSelectedCell(null)}
        employeeId={selectedCell?.employeeId || ''}
        day={selectedCell?.day || 0}
      />
    </>
  );
}
