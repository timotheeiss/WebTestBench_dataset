import { Shift, SHIFT_TIMES } from '@/data/initialData';
import { useSchedule } from '@/context/ScheduleContext';
import { X } from 'lucide-react';

interface ShiftCardProps {
  shift: Shift;
  readonly?: boolean;
}

export function ShiftCard({ shift, readonly = false }: ShiftCardProps) {
  const { removeShift } = useSchedule();
  const times = SHIFT_TIMES[shift.type];

  const typeClasses: Record<string, string> = {
    morning: 'shift-morning',
    afternoon: 'shift-afternoon',
    evening: 'shift-evening',
    night: 'shift-night',
  };

  return (
    <div className={`shift-card ${typeClasses[shift.type]} animate-scale-in relative group`}>
      <div className="text-xs font-semibold">{times.label}</div>
      <div className="text-[10px] opacity-80">
        {shift.startTime} - {shift.endTime}
      </div>
      
      {!readonly && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            removeShift(shift.id);
          }}
          className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
}
