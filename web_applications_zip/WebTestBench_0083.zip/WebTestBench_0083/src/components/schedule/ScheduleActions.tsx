import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useSchedule } from '@/context/ScheduleContext';
import { Save, Upload, Trash2, Send, ChevronLeft, ChevronRight } from 'lucide-react';
import { format, addWeeks, subWeeks } from 'date-fns';
import { toast } from 'sonner';

export function ScheduleActions() {
  const {
    currentShifts,
    templates,
    currentWeekStart,
    setCurrentWeekStart,
    saveTemplate,
    loadTemplate,
    clearSchedule,
    publishSchedule,
  } = useSchedule();

  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [templateName, setTemplateName] = useState('');

  const handleSaveTemplate = () => {
    if (!templateName.trim()) {
      toast.error('Please enter a template name');
      return;
    }
    saveTemplate(templateName);
    setTemplateName('');
    setSaveDialogOpen(false);
    toast.success('Template saved successfully');
  };

  const handleLoadTemplate = (templateId: string) => {
    loadTemplate(templateId);
    setLoadDialogOpen(false);
    toast.success('Template loaded');
  };

  const handleClear = () => {
    clearSchedule();
    toast.success('Schedule cleared');
  };

  const handlePublish = () => {
    if (currentShifts.length === 0) {
      toast.error('No shifts to publish');
      return;
    }
    publishSchedule();
    toast.success('Schedule published successfully!');
  };

  const handlePrevWeek = () => {
    setCurrentWeekStart(subWeeks(currentWeekStart, 1));
  };

  const handleNextWeek = () => {
    setCurrentWeekStart(addWeeks(currentWeekStart, 1));
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-card border border-border rounded-lg p-1">
            <Button variant="ghost" size="icon" onClick={handlePrevWeek}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <div className="px-3 py-1 min-w-[180px] text-center">
              <span className="font-medium">
                Week of {format(currentWeekStart, 'MMM d, yyyy')}
              </span>
            </div>
            <Button variant="ghost" size="icon" onClick={handleNextWeek}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          
          <span className="text-sm text-muted-foreground">
            {currentShifts.length} shift{currentShifts.length !== 1 ? 's' : ''} scheduled
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setLoadDialogOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Load Template
          </Button>
          <Button variant="outline" size="sm" onClick={() => setSaveDialogOpen(true)}>
            <Save className="w-4 h-4 mr-2" />
            Save Template
          </Button>
          <Button variant="outline" size="sm" onClick={handleClear} className="text-destructive hover:text-destructive">
            <Trash2 className="w-4 h-4 mr-2" />
            Clear
          </Button>
          <Button size="sm" onClick={handlePublish} className="bg-success hover:bg-success/90">
            <Send className="w-4 h-4 mr-2" />
            Publish
          </Button>
        </div>
      </div>

      {/* Save Template Dialog */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save as Template</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="templateName">Template Name</Label>
            <Input
              id="templateName"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="e.g., Summer Schedule"
              className="mt-2"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveTemplate}>Save Template</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Load Template Dialog */}
      <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Load Template</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-2 max-h-[300px] overflow-auto">
            {templates.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No templates saved yet
              </p>
            ) : (
              templates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => handleLoadTemplate(template.id)}
                  className="w-full p-4 text-left rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all"
                >
                  <div className="font-medium">{template.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {template.shifts.length} shifts • Created{' '}
                    {format(new Date(template.createdAt), 'MMM d, yyyy')}
                  </div>
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
