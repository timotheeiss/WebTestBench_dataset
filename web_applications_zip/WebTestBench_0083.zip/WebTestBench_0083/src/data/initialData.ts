export type ShiftType = 'morning' | 'afternoon' | 'evening' | 'night';

export interface Employee {
  id: string;
  name: string;
  role: string;
  skills: string[];
  avatar: string;
  color: string;
}

export interface Shift {
  id: string;
  employeeId: string;
  day: number; // 0-6 (Sun-Sat)
  type: ShiftType;
  startTime: string;
  endTime: string;
}

export interface ScheduleTemplate {
  id: string;
  name: string;
  shifts: Omit<Shift, 'id'>[];
  createdAt: string;
}

export interface PublishedSchedule {
  id: string;
  weekStart: string;
  publishedAt: string;
  shifts: Shift[];
}

export const SHIFT_TIMES: Record<ShiftType, { start: string; end: string; label: string }> = {
  morning: { start: '06:00', end: '14:00', label: 'Morning' },
  afternoon: { start: '14:00', end: '22:00', label: 'Afternoon' },
  evening: { start: '18:00', end: '02:00', label: 'Evening' },
  night: { start: '22:00', end: '06:00', label: 'Night' },
};

export const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const SHORT_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const SKILL_COLORS: Record<string, string> = {
  'Cashier': 'bg-blue-100 text-blue-700',
  'Inventory': 'bg-green-100 text-green-700',
  'Customer Service': 'bg-purple-100 text-purple-700',
  'Management': 'bg-orange-100 text-orange-700',
  'Barista': 'bg-amber-100 text-amber-700',
  'Kitchen': 'bg-red-100 text-red-700',
  'Cleaning': 'bg-teal-100 text-teal-700',
  'Security': 'bg-slate-100 text-slate-700',
};

export const initialEmployees: Employee[] = [
  {
    id: 'emp-1',
    name: 'Sarah Johnson',
    role: 'Shift Lead',
    skills: ['Management', 'Customer Service', 'Cashier'],
    avatar: 'SJ',
    color: 'bg-indigo-500',
  },
  {
    id: 'emp-2',
    name: 'Marcus Chen',
    role: 'Barista',
    skills: ['Barista', 'Cashier', 'Inventory'],
    avatar: 'MC',
    color: 'bg-emerald-500',
  },
  {
    id: 'emp-3',
    name: 'Emily Rodriguez',
    role: 'Server',
    skills: ['Customer Service', 'Kitchen', 'Cleaning'],
    avatar: 'ER',
    color: 'bg-rose-500',
  },
  {
    id: 'emp-4',
    name: 'James Wilson',
    role: 'Cook',
    skills: ['Kitchen', 'Inventory'],
    avatar: 'JW',
    color: 'bg-amber-500',
  },
  {
    id: 'emp-5',
    name: 'Aisha Patel',
    role: 'Cashier',
    skills: ['Cashier', 'Customer Service'],
    avatar: 'AP',
    color: 'bg-cyan-500',
  },
];

export const initialTemplates: ScheduleTemplate[] = [
  {
    id: 'template-1',
    name: 'Standard Week',
    createdAt: '2024-01-15T10:00:00Z',
    shifts: [
      { employeeId: 'emp-1', day: 1, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-1', day: 2, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-1', day: 3, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-2', day: 1, type: 'afternoon', startTime: '14:00', endTime: '22:00' },
      { employeeId: 'emp-2', day: 2, type: 'afternoon', startTime: '14:00', endTime: '22:00' },
      { employeeId: 'emp-3', day: 4, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-3', day: 5, type: 'morning', startTime: '06:00', endTime: '14:00' },
    ],
  },
  {
    id: 'template-2',
    name: 'Weekend Coverage',
    createdAt: '2024-01-20T14:30:00Z',
    shifts: [
      { employeeId: 'emp-4', day: 6, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-5', day: 6, type: 'afternoon', startTime: '14:00', endTime: '22:00' },
      { employeeId: 'emp-4', day: 0, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { employeeId: 'emp-5', day: 0, type: 'afternoon', startTime: '14:00', endTime: '22:00' },
    ],
  },
];

export const initialPublishedSchedules: PublishedSchedule[] = [
  {
    id: 'pub-1',
    weekStart: '2024-12-16',
    publishedAt: '2024-12-14T09:00:00Z',
    shifts: [
      { id: 's1', employeeId: 'emp-1', day: 1, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { id: 's2', employeeId: 'emp-2', day: 1, type: 'afternoon', startTime: '14:00', endTime: '22:00' },
      { id: 's3', employeeId: 'emp-3', day: 2, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { id: 's4', employeeId: 'emp-1', day: 3, type: 'morning', startTime: '06:00', endTime: '14:00' },
      { id: 's5', employeeId: 'emp-4', day: 4, type: 'evening', startTime: '18:00', endTime: '02:00' },
    ],
  },
];
