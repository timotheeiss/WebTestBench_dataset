export type ExceptionStatus = 'pending' | 'approved' | 'expired' | 'expiring';

export interface PolicyException {
  id: string;
  entity: string;
  policyRule: string;
  reason: string;
  approver: string;
  expirationDate: Date;
  status: ExceptionStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type OperationType = 'create' | 'update' | 'delete' | 'status_change';

export interface OperationLog {
  id: string;
  exceptionId: string;
  operationType: OperationType;
  operator: string;
  timestamp: Date;
  changes: string;
  entityName: string;
}
