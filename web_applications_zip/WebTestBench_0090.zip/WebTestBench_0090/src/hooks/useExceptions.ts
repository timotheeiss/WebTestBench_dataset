import { useState, useCallback, useEffect } from 'react';
import { PolicyException, OperationLog, ExceptionStatus, OperationType } from '@/types/exception';
import { initialExceptions, initialLogs } from '@/data/initialData';
import { differenceInDays, isPast } from 'date-fns';

const EXPIRING_THRESHOLD_DAYS = 7;

export function useExceptions() {
  const [exceptions, setExceptions] = useState<PolicyException[]>(initialExceptions);
  const [logs, setLogs] = useState<OperationLog[]>(initialLogs);
  const [expiringAlerts, setExpiringAlerts] = useState<PolicyException[]>([]);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const addLog = useCallback((
    exceptionId: string,
    operationType: OperationType,
    changes: string,
    entityName: string
  ) => {
    const newLog: OperationLog = {
      id: generateId(),
      exceptionId,
      operationType,
      operator: 'Current User',
      timestamp: new Date(),
      changes,
      entityName,
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  const calculateStatus = useCallback((exception: PolicyException): ExceptionStatus => {
    if (isPast(exception.expirationDate)) {
      return 'expired';
    }
    const daysUntilExpiry = differenceInDays(exception.expirationDate, new Date());
    if (daysUntilExpiry <= EXPIRING_THRESHOLD_DAYS) {
      return 'expiring';
    }
    return exception.status === 'pending' ? 'pending' : 'approved';
  }, []);

  useEffect(() => {
    const updatedExceptions = exceptions.map(exc => {
      const newStatus = calculateStatus(exc);
      if (newStatus !== exc.status) {
        if (newStatus === 'expired' && exc.status !== 'expired') {
          addLog(exc.id, 'status_change', 'Status automatically changed to Expired', exc.entity);
        } else if (newStatus === 'expiring' && exc.status !== 'expiring') {
          addLog(exc.id, 'status_change', 'Status changed to Pending Expiry (within 7 days)', exc.entity);
        }
        return { ...exc, status: newStatus, updatedAt: new Date() };
      }
      return exc;
    });

    const hasChanges = updatedExceptions.some(
      (exc, i) => exc.status !== exceptions[i].status
    );
    if (hasChanges) {
      setExceptions(updatedExceptions);
    }

    const expiring = updatedExceptions.filter(exc => exc.status === 'expiring');
    setExpiringAlerts(expiring);
  }, [exceptions, calculateStatus, addLog]);

  const addException = useCallback((data: Omit<PolicyException, 'id' | 'status' | 'createdAt' | 'updatedAt'>) => {
    const newException: PolicyException = {
      ...data,
      id: generateId(),
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setExceptions(prev => [...prev, newException]);
    addLog(newException.id, 'create', `Created new exception for ${data.entity}`, data.entity);
    return newException;
  }, [addLog]);

  const updateException = useCallback((id: string, data: Partial<PolicyException>) => {
    setExceptions(prev => prev.map(exc => {
      if (exc.id === id) {
        const changes = Object.entries(data)
          .filter(([key, value]) => exc[key as keyof PolicyException] !== value)
          .map(([key, value]) => `${key}: ${value}`)
          .join(', ');
        addLog(id, 'update', `Updated: ${changes}`, exc.entity);
        return { ...exc, ...data, updatedAt: new Date() };
      }
      return exc;
    }));
  }, [addLog]);

  const deleteException = useCallback((id: string) => {
    const exception = exceptions.find(exc => exc.id === id);
    if (exception) {
      addLog(id, 'delete', `Deleted exception for ${exception.entity}`, exception.entity);
      setExceptions(prev => prev.filter(exc => exc.id !== id));
    }
  }, [exceptions, addLog]);

  const approveException = useCallback((id: string) => {
    setExceptions(prev => prev.map(exc => {
      if (exc.id === id && exc.status === 'pending') {
        addLog(id, 'status_change', 'Status changed from Pending to Approved', exc.entity);
        return { ...exc, status: 'approved' as ExceptionStatus, updatedAt: new Date() };
      }
      return exc;
    }));
  }, [addLog]);

  const activeExceptions = exceptions.filter(exc => exc.status !== 'expired');
  const expiredExceptions = exceptions.filter(exc => exc.status === 'expired');

  const filterLogsByType = useCallback((type: OperationType | 'all') => {
    if (type === 'all') return logs;
    return logs.filter(log => log.operationType === type);
  }, [logs]);

  const dismissAlert = useCallback((id: string) => {
    setExpiringAlerts(prev => prev.filter(exc => exc.id !== id));
  }, []);

  return {
    exceptions,
    activeExceptions,
    expiredExceptions,
    logs,
    expiringAlerts,
    addException,
    updateException,
    deleteException,
    approveException,
    filterLogsByType,
    dismissAlert,
  };
}
