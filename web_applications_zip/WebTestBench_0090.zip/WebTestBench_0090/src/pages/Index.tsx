import { useState } from 'react';
import { useExceptions } from '@/hooks/useExceptions';
import { PolicyException } from '@/types/exception';
import { ExceptionCard } from '@/components/ExceptionCard';
import { ExceptionForm } from '@/components/ExceptionForm';
import { OperationLogList } from '@/components/OperationLogList';
import { ExpiryAlertBanner } from '@/components/ExpiryAlertBanner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, Shield, Archive, ClipboardList } from 'lucide-react';

const Index = () => {
  const {
    activeExceptions,
    expiredExceptions,
    logs,
    expiringAlerts,
    addException,
    updateException,
    deleteException,
    approveException,
    filterLogsByType,
    dismissAlert,
  } = useExceptions();

  const [formOpen, setFormOpen] = useState(false);
  const [editingException, setEditingException] = useState<PolicyException | null>(null);

  const handleEdit = (exception: PolicyException) => {
    setEditingException(exception);
    setFormOpen(true);
  };

  const handleFormSubmit = (data: Omit<PolicyException, 'id' | 'status' | 'createdAt' | 'updatedAt'>) => {
    if (editingException) {
      updateException(editingException.id, data);
      setEditingException(null);
    } else {
      addException(data);
    }
  };

  const handleFormClose = (open: boolean) => {
    setFormOpen(open);
    if (!open) setEditingException(null);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-card border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Policy Exception Manager</h1>
                <p className="text-sm text-muted-foreground">Track and manage policy exceptions</p>
              </div>
            </div>
            <Button onClick={() => setFormOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New Exception
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <ExpiryAlertBanner exceptions={expiringAlerts} onDismiss={dismissAlert} />

        <Tabs defaultValue="active" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="active" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Active ({activeExceptions.length})
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Archive className="w-4 h-4" />
              History ({expiredExceptions.length})
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <ClipboardList className="w-4 h-4" />
              Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {activeExceptions.length === 0 ? (
              <div className="text-center py-12 bg-card rounded-lg border">
                <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No active exceptions</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first policy exception to get started.
                </p>
                <Button onClick={() => setFormOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Exception
                </Button>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeExceptions.map((exception) => (
                  <ExceptionCard
                    key={exception.id}
                    exception={exception}
                    onEdit={handleEdit}
                    onDelete={deleteException}
                    onApprove={approveException}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            {expiredExceptions.length === 0 ? (
              <div className="text-center py-12 bg-card rounded-lg border">
                <Archive className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No expired exceptions</h3>
                <p className="text-muted-foreground">
                  Expired exceptions will appear here automatically.
                </p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {expiredExceptions.map((exception) => (
                  <ExceptionCard
                    key={exception.id}
                    exception={exception}
                    onEdit={handleEdit}
                    onDelete={deleteException}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="logs">
            <OperationLogList logs={logs} filterLogsByType={filterLogsByType} />
          </TabsContent>
        </Tabs>
      </main>

      {/* Form Dialog */}
      <ExceptionForm
        open={formOpen}
        onOpenChange={handleFormClose}
        onSubmit={handleFormSubmit}
        initialData={editingException || undefined}
        mode={editingException ? 'edit' : 'create'}
      />
    </div>
  );
};

export default Index;
