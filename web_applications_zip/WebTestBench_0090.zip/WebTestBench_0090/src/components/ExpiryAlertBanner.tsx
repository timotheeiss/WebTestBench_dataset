import { PolicyException } from '@/types/exception';
import { AlertTriangle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { differenceInDays, format } from 'date-fns';

interface ExpiryAlertBannerProps {
  exceptions: PolicyException[];
  onDismiss: (id: string) => void;
}

export function ExpiryAlertBanner({ exceptions, onDismiss }: ExpiryAlertBannerProps) {
  if (exceptions.length === 0) return null;

  return (
    <div className="space-y-2 mb-6 animate-slide-up">
      {exceptions.map((exception) => {
        const daysLeft = differenceInDays(exception.expirationDate, new Date());
        
        return (
          <div
            key={exception.id}
            className="flex items-center gap-3 p-4 rounded-lg bg-status-expiring-bg border border-status-expiring/30"
          >
            <AlertTriangle className="w-5 h-5 text-status-expiring shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-status-expiring-foreground">
                Exception expiring soon
              </p>
              <p className="text-sm text-status-expiring-foreground/80">
                <span className="font-medium">{exception.entity}</span> expires in{' '}
                <span className="font-medium">{daysLeft} day{daysLeft !== 1 ? 's' : ''}</span>{' '}
                ({format(exception.expirationDate, 'MMM d, yyyy')})
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDismiss(exception.id)}
              className="shrink-0 text-status-expiring-foreground hover:bg-status-expiring/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        );
      })}
    </div>
  );
}
