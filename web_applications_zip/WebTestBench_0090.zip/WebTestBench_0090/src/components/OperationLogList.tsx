import { useState } from 'react';
import { OperationLog, OperationType } from '@/types/exception';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { Plus, Pencil, Trash2, RefreshCw, Filter } from 'lucide-react';
import { cn } from '@/lib/utils';

interface OperationLogListProps {
  logs: OperationLog[];
  filterLogsByType: (type: OperationType | 'all') => OperationLog[];
}

const operationConfig: Record<OperationType, { icon: typeof Plus; label: string; className: string }> = {
  create: {
    icon: Plus,
    label: 'Created',
    className: 'bg-status-approved-bg text-status-approved-foreground',
  },
  update: {
    icon: Pencil,
    label: 'Updated',
    className: 'bg-primary/10 text-primary',
  },
  delete: {
    icon: Trash2,
    label: 'Deleted',
    className: 'bg-status-expired-bg text-status-expired-foreground',
  },
  status_change: {
    icon: RefreshCw,
    label: 'Status Changed',
    className: 'bg-status-pending-bg text-status-pending-foreground',
  },
};

const filterOptions: { value: OperationType | 'all'; label: string }[] = [
  { value: 'all', label: 'All Operations' },
  { value: 'create', label: 'Created' },
  { value: 'update', label: 'Updated' },
  { value: 'delete', label: 'Deleted' },
  { value: 'status_change', label: 'Status Changes' },
];

export function OperationLogList({ filterLogsByType }: OperationLogListProps) {
  const [activeFilter, setActiveFilter] = useState<OperationType | 'all'>('all');
  const filteredLogs = filterLogsByType(activeFilter);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-muted-foreground" />
        {filterOptions.map((option) => (
          <Button
            key={option.value}
            variant={activeFilter === option.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveFilter(option.value)}
            className="text-xs"
          >
            {option.label}
          </Button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredLogs.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              No operation logs found for this filter.
            </CardContent>
          </Card>
        ) : (
          filteredLogs.map((log) => {
            const config = operationConfig[log.operationType];
            const Icon = config.icon;

            return (
              <Card key={log.id} className="animate-fade-in">
                <CardContent className="py-4">
                  <div className="flex items-start gap-4">
                    <div
                      className={cn(
                        'p-2 rounded-lg shrink-0',
                        config.className
                      )}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{log.entityName}</span>
                        <span className={cn('text-xs px-2 py-0.5 rounded-full', config.className)}>
                          {config.label}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{log.changes}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span>by {log.operator}</span>
                        <span>{format(log.timestamp, 'MMM d, yyyy h:mm a')}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
