import { useState } from 'react';
import { PolicyException } from '@/types/exception';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ExceptionFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: Omit<PolicyException, 'id' | 'status' | 'createdAt' | 'updatedAt'>) => void;
  initialData?: PolicyException;
  mode: 'create' | 'edit';
}

export function ExceptionForm({ open, onOpenChange, onSubmit, initialData, mode }: ExceptionFormProps) {
  const [entity, setEntity] = useState(initialData?.entity || '');
  const [policyRule, setPolicyRule] = useState(initialData?.policyRule || '');
  const [reason, setReason] = useState(initialData?.reason || '');
  const [approver, setApprover] = useState(initialData?.approver || '');
  const [expirationDate, setExpirationDate] = useState<Date | undefined>(
    initialData?.expirationDate || undefined
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entity || !policyRule || !reason || !approver || !expirationDate) return;

    onSubmit({
      entity,
      policyRule,
      reason,
      approver,
      expirationDate,
    });

    if (mode === 'create') {
      setEntity('');
      setPolicyRule('');
      setReason('');
      setApprover('');
      setExpirationDate(undefined);
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-card">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            {mode === 'create' ? 'Add New Exception' : 'Edit Exception'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="entity">Applicable Entity</Label>
            <Input
              id="entity"
              placeholder="e.g., Project Name or Person"
              value={entity}
              onChange={(e) => setEntity(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="policyRule">Exempted Policy Rule</Label>
            <Input
              id="policyRule"
              placeholder="e.g., Data Retention Policy"
              value={policyRule}
              onChange={(e) => setPolicyRule(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Exception</Label>
            <Textarea
              id="reason"
              placeholder="Describe why this exception is needed..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="approver">Approver</Label>
            <Input
              id="approver"
              placeholder="Name of the approver"
              value={approver}
              onChange={(e) => setApprover(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Expiration Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !expirationDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {expirationDate ? format(expirationDate, 'PPP') : 'Select date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={expirationDate}
                  onSelect={setExpirationDate}
                  initialFocus
                  className="pointer-events-auto"
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {mode === 'create' ? 'Create Exception' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
