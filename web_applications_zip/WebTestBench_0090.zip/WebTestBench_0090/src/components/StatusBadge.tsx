import { ExceptionStatus } from '@/types/exception';
import { cn } from '@/lib/utils';
import { Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

interface StatusBadgeProps {
  status: ExceptionStatus;
  className?: string;
}

const statusConfig = {
  pending: {
    label: 'Pending Approval',
    icon: Clock,
    className: 'bg-status-pending-bg text-status-pending-foreground border-status-pending/30',
  },
  approved: {
    label: 'Approved',
    icon: CheckCircle,
    className: 'bg-status-approved-bg text-status-approved-foreground border-status-approved/30',
  },
  expired: {
    label: 'Expired',
    icon: XCircle,
    className: 'bg-status-expired-bg text-status-expired-foreground border-status-expired/30',
  },
  expiring: {
    label: 'Pending Expiry',
    icon: AlertTriangle,
    className: 'bg-status-expiring-bg text-status-expiring-foreground border-status-expiring/30',
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border',
        config.className,
        status === 'expiring' && 'animate-pulse-subtle',
        className
      )}
    >
      <Icon className="w-3.5 h-3.5" />
      {config.label}
    </span>
  );
}
