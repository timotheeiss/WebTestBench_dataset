import { PolicyException } from '@/types/exception';
import { StatusBadge } from './StatusBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Pencil, Trash2, CheckCircle, Calendar, User, FileText } from 'lucide-react';
import { format } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface ExceptionCardProps {
  exception: PolicyException;
  onEdit: (exception: PolicyException) => void;
  onDelete: (id: string) => void;
  onApprove?: (id: string) => void;
}

export function ExceptionCard({ exception, onEdit, onDelete, onApprove }: ExceptionCardProps) {
  return (
    <Card className="animate-fade-in hover:shadow-md transition-shadow duration-200 bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg truncate">{exception.entity}</h3>
            <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              {exception.policyRule}
            </p>
          </div>
          <StatusBadge status={exception.status} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-foreground/80 leading-relaxed">{exception.reason}</p>
        
        <div className="flex items-center gap-6 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <User className="w-4 h-4" />
            {exception.approver}
          </span>
          <span className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            Expires {format(exception.expirationDate, 'MMM d, yyyy')}
          </span>
        </div>

        <div className="flex items-center gap-2 pt-2 border-t">
          {exception.status === 'pending' && onApprove && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onApprove(exception.id)}
              className="text-status-approved hover:bg-status-approved-bg"
            >
              <CheckCircle className="w-4 h-4 mr-1.5" />
              Approve
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => onEdit(exception)}>
            <Pencil className="w-4 h-4 mr-1.5" />
            Edit
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="text-destructive hover:bg-destructive/10">
                <Trash2 className="w-4 h-4 mr-1.5" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Exception</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this exception for "{exception.entity}"? 
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => onDelete(exception.id)}
                  className="bg-destructive hover:bg-destructive/90"
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
