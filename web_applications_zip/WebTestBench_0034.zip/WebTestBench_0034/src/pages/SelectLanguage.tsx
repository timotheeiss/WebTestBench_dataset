import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useUser } from "@/contexts/UserContext";
import { languages } from "@/data/languages";
import { ArrowRight, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function SelectLanguage() {
  const navigate = useNavigate();
  const { user, selectLanguage } = useUser();
  const [selected, setSelected] = useState<string | null>(user?.selectedLanguage || null);

  const handleContinue = () => {
    if (!selected) {
      toast.error("Please select a language to continue");
      return;
    }
    selectLanguage(selected);
    toast.success(`Great choice! Let's learn ${languages.find(l => l.id === selected)?.name}!`);
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <div className="absolute inset-0 bg-gradient-hero opacity-5" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      
      <div className="w-full max-w-2xl relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">
            Which language do you want to learn?
          </h1>
          <p className="text-muted-foreground">
            Choose your first language. You can always add more later!
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          {languages.map((language) => (
            <Card
              key={language.id}
              variant="interactive"
              className={`p-6 cursor-pointer transition-all duration-300 ${
                selected === language.id
                  ? "ring-2 ring-primary bg-primary/5 scale-[1.02]"
                  : "hover:bg-secondary/50"
              }`}
              onClick={() => setSelected(language.id)}
            >
              <div className="flex items-center gap-4">
                <span className="text-5xl">{language.flag}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-lg">{language.name}</h3>
                    <span className="text-sm text-muted-foreground">
                      {language.nativeName}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {language.description}
                  </p>
                </div>
                {selected === language.id && (
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center animate-celebrate">
                    <Check className="w-5 h-5 text-primary-foreground" />
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>

        <div className="flex justify-center">
          <Button
            size="xl"
            variant="hero"
            onClick={handleContinue}
            disabled={!selected}
            className="min-w-[200px]"
          >
            Continue
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}