import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { useUser } from "@/contexts/UserContext";
import { courses, Question } from "@/data/courses";
import { languages } from "@/data/languages";
import {
  X,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Lightbulb,
  Trophy,
  Star,
} from "lucide-react";
import { toast } from "sonner";

export default function Lesson() {
  const navigate = useNavigate();
  const { languageId, lessonId } = useParams<{ languageId: string; lessonId: string }>();
  const { user, updateProgress, addXP } = useUser();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const course = languageId ? courses[languageId] : null;
  const lesson = course?.levels
    .flatMap((l) => l.lessons)
    .find((l) => l.id === lessonId);
  const language = languages.find((l) => l.id === languageId);

  useEffect(() => {
    if (!user) {
      navigate("/login");
    } else if (!lesson) {
      navigate("/dashboard");
    }
  }, [user, lesson, navigate]);

  if (!lesson || !language) return null;

  const currentQuestion = lesson.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex) / lesson.questions.length) * 100;

  const checkAnswer = () => {
    const correct =
      selectedAnswer.toLowerCase().trim() ===
      currentQuestion.correctAnswer.toLowerCase().trim();
    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      setScore((prev) => prev + 1);
    }
  };

  const nextQuestion = () => {
    setShowResult(false);
    setSelectedAnswer("");
    setShowHint(false);

    if (currentQuestionIndex < lesson.questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      // Lesson complete
      const finalScore = Math.round(
        ((score + (isCorrect ? 1 : 0)) / lesson.questions.length) * 100
      );
      const completed = finalScore >= 60;
      
      updateProgress(languageId!, lessonId!, finalScore, completed);
      
      if (completed) {
        addXP(finalScore);
      }
      
      setIsComplete(true);
    }
  };

  const handleExit = () => {
    navigate("/dashboard");
  };

  const renderQuestion = (question: Question) => {
    switch (question.type) {
      case "multiple-choice":
        return (
          <div className="space-y-3">
            {question.options?.map((option) => (
              <button
                key={option}
                onClick={() => !showResult && setSelectedAnswer(option)}
                disabled={showResult}
                className={`w-full p-4 rounded-xl border-2 text-left font-medium transition-all duration-200 ${
                  showResult
                    ? option === question.correctAnswer
                      ? "border-success bg-success/10 text-success"
                      : option === selectedAnswer
                      ? "border-destructive bg-destructive/10 text-destructive"
                      : "border-border bg-background"
                    : selectedAnswer === option
                    ? "border-primary bg-primary/10 text-primary scale-[1.02]"
                    : "border-border bg-background hover:border-primary/50 hover:bg-secondary/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span>{option}</span>
                  {showResult && option === question.correctAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-success" />
                  )}
                  {showResult &&
                    option === selectedAnswer &&
                    option !== question.correctAnswer && (
                      <XCircle className="w-5 h-5 text-destructive" />
                    )}
                </div>
              </button>
            ))}
          </div>
        );

      case "fill-blank":
      case "translation":
        return (
          <div className="space-y-4">
            <Input
              type="text"
              placeholder={
                question.type === "fill-blank"
                  ? "Type the missing word..."
                  : "Type your translation..."
              }
              value={selectedAnswer}
              onChange={(e) => setSelectedAnswer(e.target.value)}
              disabled={showResult}
              className={`h-14 text-lg text-center ${
                showResult
                  ? isCorrect
                    ? "border-success bg-success/10"
                    : "border-destructive bg-destructive/10"
                  : ""
              }`}
              onKeyDown={(e) => {
                if (e.key === "Enter" && selectedAnswer && !showResult) {
                  checkAnswer();
                }
              }}
            />
            {showResult && !isCorrect && (
              <p className="text-center text-sm">
                Correct answer:{" "}
                <span className="font-bold text-success">
                  {question.correctAnswer}
                </span>
              </p>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (isComplete) {
    const finalScore = Math.round((score / lesson.questions.length) * 100);
    const passed = finalScore >= 60;

    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card variant="elevated" className="max-w-md w-full text-center overflow-hidden">
          <div
            className={`py-8 ${
              passed ? "bg-gradient-hero" : "bg-gradient-warm"
            }`}
          >
            <div className="w-20 h-20 mx-auto bg-primary-foreground/20 rounded-full flex items-center justify-center mb-4 animate-celebrate">
              {passed ? (
                <Trophy className="w-10 h-10 text-primary-foreground" />
              ) : (
                <Star className="w-10 h-10 text-primary-foreground" />
              )}
            </div>
            <h1 className="text-2xl font-bold text-primary-foreground">
              {passed ? "Lesson Complete!" : "Keep Practicing!"}
            </h1>
          </div>
          <CardContent className="p-8">
            <div className="mb-6">
              <div className="text-5xl font-bold text-foreground mb-2">
                {finalScore}%
              </div>
              <p className="text-muted-foreground">
                You got {score} out of {lesson.questions.length} correct
              </p>
            </div>

            {passed && (
              <div className="flex items-center justify-center gap-2 text-primary mb-6">
                <Star className="w-5 h-5 fill-current" />
                <span className="font-medium">+{finalScore} XP earned!</span>
              </div>
            )}

            <div className="space-y-3">
              <Button
                variant="hero"
                size="lg"
                className="w-full"
                onClick={() => navigate("/dashboard")}
              >
                Continue Learning
              </Button>
              {!passed && (
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full"
                  onClick={() => {
                    setCurrentQuestionIndex(0);
                    setScore(0);
                    setIsComplete(false);
                    setSelectedAnswer("");
                    setShowResult(false);
                  }}
                >
                  Try Again
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={handleExit}>
              <X className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <Progress value={progress} className="h-2" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-4xl">{language.flag}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-6 py-8 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center max-w-2xl mx-auto w-full">
          {/* Question Type Badge */}
          <div className="mb-6">
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-sm font-medium">
              {currentQuestion.type === "multiple-choice" && "Multiple Choice"}
              {currentQuestion.type === "fill-blank" && "Fill in the Blank"}
              {currentQuestion.type === "translation" && "Translation"}
            </span>
          </div>

          {/* Question */}
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
            {currentQuestion.question}
          </h2>

          {/* Answer Options */}
          <div className="w-full mb-8">{renderQuestion(currentQuestion)}</div>

          {/* Hint Button */}
          {currentQuestion.hint && !showResult && !showHint && (
            <Button
              variant="ghost"
              onClick={() => setShowHint(true)}
              className="mb-4"
            >
              <Lightbulb className="w-4 h-4 mr-2" />
              Show hint
            </Button>
          )}

          {/* Hint */}
          {showHint && currentQuestion.hint && (
            <div className="mb-6 p-4 bg-warning/10 border border-warning/30 rounded-xl text-center">
              <p className="text-sm">
                <span className="font-medium">Hint:</span> {currentQuestion.hint}
              </p>
            </div>
          )}

          {/* Result Feedback */}
          {showResult && (
            <div
              className={`w-full p-4 rounded-xl mb-6 text-center ${
                isCorrect
                  ? "bg-success/10 border border-success/30"
                  : "bg-destructive/10 border border-destructive/30"
              } animate-celebrate`}
            >
              <div className="flex items-center justify-center gap-2">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="w-6 h-6 text-success" />
                    <span className="font-bold text-success">Correct!</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-6 h-6 text-destructive" />
                    <span className="font-bold text-destructive">
                      Not quite right
                    </span>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Action Button */}
          <Button
            variant={showResult ? "hero" : "default"}
            size="lg"
            className="min-w-[200px]"
            disabled={!selectedAnswer && !showResult}
            onClick={showResult ? nextQuestion : checkAnswer}
          >
            {showResult ? (
              <>
                {currentQuestionIndex < lesson.questions.length - 1
                  ? "Continue"
                  : "Finish"}
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            ) : (
              "Check Answer"
            )}
          </Button>
        </div>

        {/* Progress Info */}
        <div className="text-center text-sm text-muted-foreground mt-8">
          Question {currentQuestionIndex + 1} of {lesson.questions.length}
        </div>
      </main>
    </div>
  );
}