import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useUser } from "@/contexts/UserContext";
import { GraduationCap, Sparkles, Target, Trophy } from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();
  const { isAuthenticated } = useUser();

  const features = [
    {
      icon: GraduationCap,
      title: "Structured Learning",
      description: "Follow a clear path from beginner to advanced",
    },
    {
      icon: Target,
      title: "Interactive Exercises",
      description: "Practice with quizzes, translations, and fill-in-the-blanks",
    },
    {
      icon: Trophy,
      title: "Track Progress",
      description: "See your scores and celebrate your achievements",
    },
    {
      icon: Sparkles,
      title: "Instant Feedback",
      description: "Learn from your mistakes with immediate corrections",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-5" />
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        
        <nav className="container mx-auto px-6 py-6 flex justify-between items-center relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-hero rounded-xl flex items-center justify-center shadow-card">
              <GraduationCap className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">LinguaLearn</span>
          </div>
          
          {isAuthenticated ? (
            <Button onClick={() => navigate("/dashboard")} variant="hero">
              Go to Dashboard
            </Button>
          ) : (
            <div className="flex gap-3">
              <Button variant="ghost" onClick={() => navigate("/login")}>
                Log in
              </Button>
              <Button variant="hero" onClick={() => navigate("/register")}>
                Get Started
              </Button>
            </div>
          )}
        </nav>

        <div className="container mx-auto px-6 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              Start learning today — it's free!
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
              Learn a new language{" "}
              <span className="text-gradient">the fun way</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Master Spanish, French, Japanese, or German with bite-sized lessons, 
              interactive exercises, and personalized progress tracking.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="xl"
                variant="hero"
                onClick={() => navigate(isAuthenticated ? "/dashboard" : "/register")}
              >
                Start Learning Free
              </Button>
              <Button
                size="xl"
                variant="outline"
                onClick={() => navigate("/login")}
              >
                I have an account
              </Button>
            </div>

            {/* Language flags */}
            <div className="flex justify-center gap-6 mt-12">
              {["🇪🇸", "🇫🇷", "🇯🇵", "🇩🇪"].map((flag, i) => (
                <div
                  key={i}
                  className="text-4xl animate-float"
                  style={{ animationDelay: `${i * 0.2}s` }}
                >
                  {flag}
                </div>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Why choose LinguaLearn?
          </h2>
          <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
            Our proven approach makes language learning effective and enjoyable
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div
                key={i}
                className="bg-card rounded-2xl p-6 shadow-soft hover:shadow-card transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-gradient-hero rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="bg-gradient-hero rounded-3xl p-10 md:p-16 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(255,255,255,0.2),_transparent_50%)]" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
                Ready to become multilingual?
              </h2>
              <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
                Join thousands of learners who are already on their journey to fluency.
              </p>
              <Button
                size="xl"
                variant="accent"
                onClick={() => navigate(isAuthenticated ? "/dashboard" : "/register")}
              >
                Start Learning Now
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-6 text-center text-muted-foreground text-sm">
          <p>© 2024 LinguaLearn. Made with ❤️ for language lovers.</p>
        </div>
      </footer>
    </div>
  );
}