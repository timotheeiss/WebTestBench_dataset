import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useUser } from "@/contexts/UserContext";
import { languages } from "@/data/languages";
import { courses } from "@/data/courses";
import {
  GraduationCap,
  Trophy,
  Flame,
  Star,
  BookOpen,
  Lock,
  CheckCircle2,
  ChevronRight,
  Settings,
  LogOut,
} from "lucide-react";
import { useEffect } from "react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, logout, getLessonProgress } = useUser();

  useEffect(() => {
    if (!user) {
      navigate("/login");
    } else if (!user.selectedLanguage) {
      navigate("/select-language");
    }
  }, [user, navigate]);

  if (!user || !user.selectedLanguage) return null;

  const currentLanguage = languages.find((l) => l.id === user.selectedLanguage);
  const course = courses[user.selectedLanguage];

  const getTotalLessons = () => {
    return course.levels.reduce((acc, level) => acc + level.lessons.length, 0);
  };

  const getCompletedLessons = () => {
    const progress = user.progress[user.selectedLanguage] || [];
    return progress.filter((p) => p.completed).length;
  };

  const isLessonUnlocked = (levelIndex: number, lessonIndex: number): boolean => {
    if (levelIndex === 0 && lessonIndex === 0) return true;
    
    const progress = user.progress[user.selectedLanguage] || [];
    
    // Check if previous lesson is completed
    if (lessonIndex > 0) {
      const prevLessonId = course.levels[levelIndex].lessons[lessonIndex - 1].id;
      return progress.some((p) => p.lessonId === prevLessonId && p.completed);
    }
    
    // First lesson of a new level - check if previous level's last lesson is done
    if (levelIndex > 0) {
      const prevLevel = course.levels[levelIndex - 1];
      const lastLessonId = prevLevel.lessons[prevLevel.lessons.length - 1].id;
      return progress.some((p) => p.lessonId === lastLessonId && p.completed);
    }
    
    return true;
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const overallProgress = Math.round((getCompletedLessons() / getTotalLessons()) * 100);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-hero rounded-xl flex items-center justify-center shadow-soft">
              <GraduationCap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold">LinguaLearn</span>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-sm">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-warning/10 text-warning rounded-full font-medium">
                <Flame className="w-4 h-4" />
                <span>{user.streak} day streak</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-full font-medium">
                <Star className="w-4 h-4" />
                <span>{user.totalXP} XP</span>
              </div>
            </div>

            <Button variant="ghost" size="icon" onClick={() => navigate("/select-language")}>
              <Settings className="w-5 h-5" />
            </Button>
            
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-10">
          <div className="flex items-center gap-4 mb-6">
            <span className="text-5xl">{currentLanguage?.flag}</span>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">
                Welcome back, {user.name}!
              </h1>
              <p className="text-muted-foreground">
                Continue learning {currentLanguage?.name}
              </p>
            </div>
          </div>

          {/* Progress Overview Card */}
          <Card variant="elevated" className="bg-gradient-hero text-primary-foreground overflow-hidden">
            <CardContent className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row md:items-center gap-6">
                <div className="flex-1">
                  <h2 className="text-lg font-semibold opacity-90 mb-2">Course Progress</h2>
                  <div className="flex items-end gap-3 mb-4">
                    <span className="text-5xl font-bold">{overallProgress}%</span>
                    <span className="text-primary-foreground/70 pb-2">
                      {getCompletedLessons()} of {getTotalLessons()} lessons
                    </span>
                  </div>
                  <div className="bg-primary-foreground/20 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-primary-foreground rounded-full transition-all duration-500"
                      style={{ width: `${overallProgress}%` }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Trophy className="w-16 h-16 opacity-30" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Levels & Lessons */}
        <div className="space-y-8">
          {course.levels.map((level, levelIndex) => {
            const levelLessons = level.lessons;
            const completedInLevel = levelLessons.filter((lesson) => {
              const progress = getLessonProgress(user.selectedLanguage!, lesson.id);
              return progress?.completed;
            }).length;
            const levelProgress = Math.round((completedInLevel / levelLessons.length) * 100);

            return (
              <div key={level.id}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center font-bold text-lg">
                      {levelIndex + 1}
                    </div>
                    <div>
                      <h2 className="font-bold text-lg">{level.name}</h2>
                      <p className="text-sm text-muted-foreground">{level.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">
                      {completedInLevel}/{levelLessons.length}
                    </span>
                    <div className="w-24">
                      <Progress value={levelProgress} />
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {level.lessons.map((lesson, lessonIndex) => {
                    const progress = getLessonProgress(user.selectedLanguage!, lesson.id);
                    const isUnlocked = isLessonUnlocked(levelIndex, lessonIndex);
                    const isCompleted = progress?.completed;
                    const score = progress?.score || 0;

                    return (
                      <Card
                        key={lesson.id}
                        variant={isUnlocked ? "interactive" : "flat"}
                        className={`relative overflow-hidden ${
                          !isUnlocked ? "opacity-60 cursor-not-allowed" : ""
                        } ${isCompleted ? "border-success/30 bg-success/5" : ""}`}
                        onClick={() => {
                          if (isUnlocked) {
                            navigate(`/lesson/${user.selectedLanguage}/${lesson.id}`);
                          }
                        }}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                                  isCompleted
                                    ? "bg-success text-success-foreground"
                                    : isUnlocked
                                    ? "bg-primary/10 text-primary"
                                    : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {isCompleted ? (
                                  <CheckCircle2 className="w-5 h-5" />
                                ) : isUnlocked ? (
                                  <BookOpen className="w-4 h-4" />
                                ) : (
                                  <Lock className="w-4 h-4" />
                                )}
                              </div>
                              <CardTitle className="text-base">{lesson.title}</CardTitle>
                            </div>
                            {isUnlocked && (
                              <ChevronRight className="w-5 h-5 text-muted-foreground" />
                            )}
                          </div>
                          <CardDescription className="mt-2">
                            {lesson.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">
                              {lesson.questions.length} questions
                            </span>
                            {isCompleted && (
                              <span className="font-medium text-success">
                                Score: {score}%
                              </span>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}