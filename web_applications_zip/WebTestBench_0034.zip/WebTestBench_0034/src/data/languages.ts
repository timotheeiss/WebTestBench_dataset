export interface Language {
  id: string;
  name: string;
  nativeName: string;
  flag: string;
  description: string;
}

export const languages: Language[] = [
  {
    id: "spanish",
    name: "Spanish",
    nativeName: "Español",
    flag: "🇪🇸",
    description: "Spoken by 500+ million people worldwide",
  },
  {
    id: "french",
    name: "French",
    nativeName: "Français",
    flag: "🇫🇷",
    description: "The language of love and diplomacy",
  },
  {
    id: "japanese",
    name: "Japanese",
    nativeName: "日本語",
    flag: "🇯🇵",
    description: "Rich culture and modern innovation",
  },
  {
    id: "german",
    name: "German",
    nativeName: "Deutsch",
    flag: "🇩🇪",
    description: "Language of science and engineering",
  },
];
