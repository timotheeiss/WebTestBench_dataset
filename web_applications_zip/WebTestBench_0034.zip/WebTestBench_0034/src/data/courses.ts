export type QuestionType = "multiple-choice" | "fill-blank" | "translation";

export interface Question {
  id: string;
  type: QuestionType;
  question: string;
  options?: string[];
  correctAnswer: string;
  hint?: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

export interface Level {
  id: string;
  name: string;
  description: string;
  lessons: Lesson[];
}

export interface Course {
  languageId: string;
  levels: Level[];
}

export const courses: Record<string, Course> = {
  spanish: {
    languageId: "spanish",
    levels: [
      {
        id: "beginner",
        name: "Beginner",
        description: "Start your Spanish journey",
        lessons: [
          {
            id: "greetings",
            title: "Greetings",
            description: "Learn basic Spanish greetings",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "How do you say 'Hello' in Spanish?",
                options: ["Hola", "Adiós", "Gracias", "Por favor"],
                correctAnswer: "Hola",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Good morning'",
                correctAnswer: "Buenos días",
                hint: "Think about 'good' and 'days'",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "Complete: 'Buenas ___' (Good night)",
                correctAnswer: "noches",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "What does 'Adiós' mean?",
                options: ["Hello", "Goodbye", "Please", "Thank you"],
                correctAnswer: "Goodbye",
              },
            ],
          },
          {
            id: "numbers",
            title: "Numbers 1-10",
            description: "Count in Spanish",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "What is 'five' in Spanish?",
                options: ["Cuatro", "Cinco", "Seis", "Siete"],
                correctAnswer: "Cinco",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate the number: 'Tres'",
                correctAnswer: "Three",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "One, two, ___: Uno, dos, tres",
                correctAnswer: "three",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "Which is 'Diez'?",
                options: ["8", "9", "10", "7"],
                correctAnswer: "10",
              },
            ],
          },
          {
            id: "colors",
            title: "Colors",
            description: "Learn color vocabulary",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "What color is 'Rojo'?",
                options: ["Blue", "Green", "Red", "Yellow"],
                correctAnswer: "Red",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Azul'",
                correctAnswer: "Blue",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "The sky is ___: El cielo es azul",
                correctAnswer: "blue",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "'Verde' means:",
                options: ["Yellow", "Green", "Orange", "Purple"],
                correctAnswer: "Green",
              },
            ],
          },
        ],
      },
      {
        id: "elementary",
        name: "Elementary",
        description: "Build your foundation",
        lessons: [
          {
            id: "family",
            title: "Family Members",
            description: "Talk about your family",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "How do you say 'mother' in Spanish?",
                options: ["Padre", "Madre", "Hermano", "Hermana"],
                correctAnswer: "Madre",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'My father'",
                correctAnswer: "Mi padre",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "My sister: Mi ___",
                correctAnswer: "hermana",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "'Abuelo' means:",
                options: ["Uncle", "Grandfather", "Cousin", "Brother"],
                correctAnswer: "Grandfather",
              },
            ],
          },
          {
            id: "food",
            title: "Food & Drinks",
            description: "Order at a restaurant",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "What is 'water' in Spanish?",
                options: ["Leche", "Jugo", "Agua", "Café"],
                correctAnswer: "Agua",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Pan'",
                correctAnswer: "Bread",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "I want coffee: Quiero ___",
                correctAnswer: "café",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "'Manzana' is a:",
                options: ["Vegetable", "Fruit", "Drink", "Meat"],
                correctAnswer: "Fruit",
              },
            ],
          },
        ],
      },
    ],
  },
  french: {
    languageId: "french",
    levels: [
      {
        id: "beginner",
        name: "Beginner",
        description: "Start your French journey",
        lessons: [
          {
            id: "greetings",
            title: "Greetings",
            description: "Learn basic French greetings",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "How do you say 'Hello' in French?",
                options: ["Bonjour", "Au revoir", "Merci", "S'il vous plaît"],
                correctAnswer: "Bonjour",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Good evening'",
                correctAnswer: "Bonsoir",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "Goodbye: Au ___",
                correctAnswer: "revoir",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "What does 'Merci' mean?",
                options: ["Hello", "Goodbye", "Please", "Thank you"],
                correctAnswer: "Thank you",
              },
            ],
          },
          {
            id: "numbers",
            title: "Numbers 1-10",
            description: "Count in French",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "What is 'three' in French?",
                options: ["Deux", "Trois", "Quatre", "Cinq"],
                correctAnswer: "Trois",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Sept'",
                correctAnswer: "Seven",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "One, two: Un, ___",
                correctAnswer: "deux",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "Which is 'Dix'?",
                options: ["8", "9", "10", "6"],
                correctAnswer: "10",
              },
            ],
          },
        ],
      },
    ],
  },
  japanese: {
    languageId: "japanese",
    levels: [
      {
        id: "beginner",
        name: "Beginner",
        description: "Start your Japanese journey",
        lessons: [
          {
            id: "greetings",
            title: "Greetings",
            description: "Learn basic Japanese greetings",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "How do you say 'Hello' in Japanese?",
                options: ["Konnichiwa", "Sayonara", "Arigatou", "Sumimasen"],
                correctAnswer: "Konnichiwa",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Thank you'",
                correctAnswer: "Arigatou",
                hint: "A very common expression",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "Good morning: Ohayou ___",
                correctAnswer: "gozaimasu",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "What does 'Sayonara' mean?",
                options: ["Hello", "Goodbye", "Please", "Sorry"],
                correctAnswer: "Goodbye",
              },
            ],
          },
        ],
      },
    ],
  },
  german: {
    languageId: "german",
    levels: [
      {
        id: "beginner",
        name: "Beginner",
        description: "Start your German journey",
        lessons: [
          {
            id: "greetings",
            title: "Greetings",
            description: "Learn basic German greetings",
            questions: [
              {
                id: "q1",
                type: "multiple-choice",
                question: "How do you say 'Hello' in German?",
                options: ["Hallo", "Tschüss", "Danke", "Bitte"],
                correctAnswer: "Hallo",
              },
              {
                id: "q2",
                type: "translation",
                question: "Translate: 'Good morning'",
                correctAnswer: "Guten Morgen",
              },
              {
                id: "q3",
                type: "fill-blank",
                question: "Good day: Guten ___",
                correctAnswer: "Tag",
              },
              {
                id: "q4",
                type: "multiple-choice",
                question: "What does 'Danke' mean?",
                options: ["Hello", "Goodbye", "Please", "Thank you"],
                correctAnswer: "Thank you",
              },
            ],
          },
        ],
      },
    ],
  },
};
