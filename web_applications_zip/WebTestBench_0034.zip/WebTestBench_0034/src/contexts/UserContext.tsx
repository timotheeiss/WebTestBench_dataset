import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface UserProgress {
  lessonId: string;
  completed: boolean;
  score: number;
  answeredQuestions: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  selectedLanguage: string | null;
  progress: Record<string, UserProgress[]>;
  totalXP: number;
  streak: number;
  createdAt: string;
}

interface UserContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  selectLanguage: (languageId: string) => void;
  updateProgress: (languageId: string, lessonId: string, score: number, completed: boolean) => void;
  getLessonProgress: (languageId: string, lessonId: string) => UserProgress | undefined;
  addXP: (amount: number) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const STORAGE_KEY = "lingualearn_user";
const USERS_KEY = "lingualearn_users";

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem(STORAGE_KEY);
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const saveUser = (userData: User) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
    setUser(userData);
    
    // Also update in users list
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "{}");
    users[userData.email] = { ...userData };
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  };

  const register = (name: string, email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "{}");
    
    if (users[email]) {
      return false; // User already exists
    }

    const newUser: User = {
      id: crypto.randomUUID(),
      name,
      email,
      selectedLanguage: null,
      progress: {},
      totalXP: 0,
      streak: 1,
      createdAt: new Date().toISOString(),
    };

    users[email] = { ...newUser, password };
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    saveUser(newUser);
    return true;
  };

  const login = (email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "{}");
    const userData = users[email];

    if (userData && userData.password === password) {
      const { password: _, ...userWithoutPassword } = userData;
      saveUser(userWithoutPassword);
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  };

  const selectLanguage = (languageId: string) => {
    if (user) {
      const updatedUser = { ...user, selectedLanguage: languageId };
      if (!updatedUser.progress[languageId]) {
        updatedUser.progress[languageId] = [];
      }
      saveUser(updatedUser);
    }
  };

  const updateProgress = (languageId: string, lessonId: string, score: number, completed: boolean) => {
    if (user) {
      const updatedUser = { ...user };
      if (!updatedUser.progress[languageId]) {
        updatedUser.progress[languageId] = [];
      }

      const existingIndex = updatedUser.progress[languageId].findIndex(
        (p) => p.lessonId === lessonId
      );

      if (existingIndex >= 0) {
        const existing = updatedUser.progress[languageId][existingIndex];
        updatedUser.progress[languageId][existingIndex] = {
          ...existing,
          score: Math.max(existing.score, score),
          completed: existing.completed || completed,
        };
      } else {
        updatedUser.progress[languageId].push({
          lessonId,
          completed,
          score,
          answeredQuestions: [],
        });
      }

      saveUser(updatedUser);
    }
  };

  const getLessonProgress = (languageId: string, lessonId: string): UserProgress | undefined => {
    if (!user || !user.progress[languageId]) return undefined;
    return user.progress[languageId].find((p) => p.lessonId === lessonId);
  };

  const addXP = (amount: number) => {
    if (user) {
      const updatedUser = { ...user, totalXP: user.totalXP + amount };
      saveUser(updatedUser);
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        selectLanguage,
        updateProgress,
        getLessonProgress,
        addXP,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
