import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Paper, FilterState, SortOption, SortDirection } from '@/types/paper';
import { papers as allPapers, minYear, maxYear } from '@/data/papers';

interface PapersContextType {
  papers: Paper[];
  filteredPapers: Paper[];
  favorites: string[];
  filter: FilterState;
  sortBy: SortOption;
  sortDirection: SortDirection;
  
  toggleFavorite: (paperId: string) => void;
  isFavorite: (paperId: string) => boolean;
  clearFavorites: () => void;
  getFavoritePapers: () => Paper[];
  
  setFilter: (filter: Partial<FilterState>) => void;
  resetFilter: () => void;
  setSort: (sortBy: SortOption, direction?: SortDirection) => void;
  
  getPaperById: (id: string) => Paper | undefined;
}

const defaultFilter: FilterState = {
  yearRange: [minYear, maxYear],
  conferences: [],
  searchQuery: '',
};

const PapersContext = createContext<PapersContextType | undefined>(undefined);

export function PapersProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [filter, setFilterState] = useState<FilterState>(defaultFilter);
  const [sortBy, setSortBy] = useState<SortOption>('citations');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const toggleFavorite = useCallback((paperId: string) => {
    setFavorites(prev => 
      prev.includes(paperId) 
        ? prev.filter(id => id !== paperId)
        : [...prev, paperId]
    );
  }, []);

  const isFavorite = useCallback((paperId: string) => {
    return favorites.includes(paperId);
  }, [favorites]);

  const clearFavorites = useCallback(() => {
    setFavorites([]);
  }, []);

  const getFavoritePapers = useCallback(() => {
    return allPapers.filter(p => favorites.includes(p.id));
  }, [favorites]);

  const setFilter = useCallback((newFilter: Partial<FilterState>) => {
    setFilterState(prev => ({ ...prev, ...newFilter }));
  }, []);

  const resetFilter = useCallback(() => {
    setFilterState(defaultFilter);
  }, []);

  const setSort = useCallback((newSortBy: SortOption, direction?: SortDirection) => {
    if (newSortBy === sortBy && !direction) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortDirection(direction || 'desc');
    }
  }, [sortBy]);

  const getPaperById = useCallback((id: string) => {
    return allPapers.find(p => p.id === id);
  }, []);

  const filteredPapers = React.useMemo(() => {
    let result = [...allPapers];

    // Apply search filter
    if (filter.searchQuery) {
      const query = filter.searchQuery.toLowerCase();
      result = result.filter(p => 
        p.title.toLowerCase().includes(query) ||
        p.authors.some(a => a.toLowerCase().includes(query)) ||
        p.keywords.some(k => k.toLowerCase().includes(query)) ||
        p.abstract.toLowerCase().includes(query)
      );
    }

    // Apply year range filter
    result = result.filter(p => 
      p.year >= filter.yearRange[0] && p.year <= filter.yearRange[1]
    );

    // Apply conference filter
    if (filter.conferences.length > 0) {
      result = result.filter(p => filter.conferences.includes(p.conference));
    }

    // Apply sorting
    result.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'citations':
          comparison = a.citationCount - b.citationCount;
          break;
        case 'year':
          comparison = a.year - b.year;
          break;
        case 'impactFactor':
          comparison = a.impactFactor - b.impactFactor;
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [filter, sortBy, sortDirection]);

  return (
    <PapersContext.Provider value={{
      papers: allPapers,
      filteredPapers,
      favorites,
      filter,
      sortBy,
      sortDirection,
      toggleFavorite,
      isFavorite,
      clearFavorites,
      getFavoritePapers,
      setFilter,
      resetFilter,
      setSort,
      getPaperById,
    }}>
      {children}
    </PapersContext.Provider>
  );
}

export function usePapers() {
  const context = useContext(PapersContext);
  if (!context) {
    throw new Error('usePapers must be used within a PapersProvider');
  }
  return context;
}
