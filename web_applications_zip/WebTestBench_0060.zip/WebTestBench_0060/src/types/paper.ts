export interface Paper {
  id: string;
  title: string;
  authors: string[];
  conference: string;
  year: number;
  abstract: string;
  citationCount: number;
  impactFactor: number;
  citationHistory: CitationDataPoint[];
  keywords: string[];
  doi: string;
}

export interface CitationDataPoint {
  year: number;
  citations: number;
  cumulativeCitations: number;
}

export type SortOption = 'citations' | 'year' | 'impactFactor' | 'title';
export type SortDirection = 'asc' | 'desc';

export interface FilterState {
  yearRange: [number, number];
  conferences: string[];
  searchQuery: string;
}

export interface ChartViewState {
  timeRange: 'all' | '5years' | '3years' | '1year';
  chartType: 'line' | 'bar' | 'area';
  showCumulative: boolean;
}
