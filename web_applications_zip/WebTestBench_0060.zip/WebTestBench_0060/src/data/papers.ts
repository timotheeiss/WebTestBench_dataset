import { Paper } from '@/types/paper';

function generateCitationHistory(startYear: number, totalCitations: number): { year: number; citations: number; cumulativeCitations: number }[] {
  const currentYear = 2024;
  const years = currentYear - startYear + 1;
  const history: { year: number; citations: number; cumulativeCitations: number }[] = [];
  
  // Generate a realistic citation curve (low initially, peak, then gradual decline)
  let cumulative = 0;
  const peakYear = startYear + Math.floor(years * 0.3);
  
  for (let year = startYear; year <= currentYear; year++) {
    const yearsSinceStart = year - startYear;
    const yearsToPeak = peakYear - startYear;
    
    let weight: number;
    if (year <= peakYear) {
      weight = Math.pow(yearsSinceStart / yearsToPeak, 1.5);
    } else {
      const decay = (year - peakYear) / (currentYear - peakYear);
      weight = 1 - (decay * 0.4);
    }
    
    const baseCitations = Math.floor((totalCitations / years) * weight * (0.7 + Math.random() * 0.6));
    const citations = Math.max(0, baseCitations);
    cumulative += citations;
    
    history.push({ year, citations, cumulativeCitations: cumulative });
  }
  
  // Normalize to match total citations
  const factor = totalCitations / cumulative;
  let runningTotal = 0;
  return history.map(h => {
    const normalized = Math.round(h.citations * factor);
    runningTotal += normalized;
    return { year: h.year, citations: normalized, cumulativeCitations: runningTotal };
  });
}

export const papers: Paper[] = [
  {
    id: '1',
    title: 'Attention Is All You Need',
    authors: ['Ashish Vaswani', 'Noam Shazeer', 'Niki Parmar', 'Jakob Uszkoreit', 'Llion Jones', 'Aidan N. Gomez', 'Łukasz Kaiser', 'Illia Polosukhin'],
    conference: 'NeurIPS',
    year: 2017,
    abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks that include an encoder and a decoder. The best performing models also connect the encoder and decoder through an attention mechanism. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely.',
    citationCount: 98500,
    impactFactor: 9.8,
    citationHistory: generateCitationHistory(2017, 98500),
    keywords: ['transformer', 'attention', 'neural networks', 'NLP'],
    doi: '10.48550/arXiv.1706.03762'
  },
  {
    id: '2',
    title: 'BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding',
    authors: ['Jacob Devlin', 'Ming-Wei Chang', 'Kenton Lee', 'Kristina Toutanova'],
    conference: 'NAACL',
    year: 2019,
    abstract: 'We introduce a new language representation model called BERT, which stands for Bidirectional Encoder Representations from Transformers. Unlike recent language representation models, BERT is designed to pre-train deep bidirectional representations from unlabeled text by jointly conditioning on both left and right context in all layers.',
    citationCount: 72400,
    impactFactor: 8.9,
    citationHistory: generateCitationHistory(2019, 72400),
    keywords: ['BERT', 'pre-training', 'transformers', 'NLP'],
    doi: '10.18653/v1/N19-1423'
  },
  {
    id: '3',
    title: 'Deep Residual Learning for Image Recognition',
    authors: ['Kaiming He', 'Xiangyu Zhang', 'Shaoqing Ren', 'Jian Sun'],
    conference: 'CVPR',
    year: 2016,
    abstract: 'Deeper neural networks are more difficult to train. We present a residual learning framework to ease the training of networks that are substantially deeper than those used previously. We explicitly reformulate the layers as learning residual functions with reference to the layer inputs, instead of learning unreferenced functions.',
    citationCount: 156200,
    impactFactor: 10.2,
    citationHistory: generateCitationHistory(2016, 156200),
    keywords: ['ResNet', 'deep learning', 'computer vision', 'image recognition'],
    doi: '10.1109/CVPR.2016.90'
  },
  {
    id: '4',
    title: 'ImageNet Classification with Deep Convolutional Neural Networks',
    authors: ['Alex Krizhevsky', 'Ilya Sutskever', 'Geoffrey E. Hinton'],
    conference: 'NeurIPS',
    year: 2012,
    abstract: 'We trained a large, deep convolutional neural network to classify the 1.2 million high-resolution images in the ImageNet LSVRC-2010 contest into the 1000 different classes. On the test data, we achieved top-1 and top-5 error rates of 37.5% and 17.0%, respectively, which is considerably better than the previous state-of-the-art.',
    citationCount: 123800,
    impactFactor: 9.5,
    citationHistory: generateCitationHistory(2012, 123800),
    keywords: ['AlexNet', 'CNN', 'ImageNet', 'deep learning'],
    doi: '10.1145/3065386'
  },
  {
    id: '5',
    title: 'Generative Adversarial Nets',
    authors: ['Ian Goodfellow', 'Jean Pouget-Abadie', 'Mehdi Mirza', 'Bing Xu', 'David Warde-Farley', 'Sherjil Ozair', 'Aaron Courville', 'Yoshua Bengio'],
    conference: 'NeurIPS',
    year: 2014,
    abstract: 'We propose a new framework for estimating generative models via an adversarial process, in which we simultaneously train two models: a generative model G that captures the data distribution, and a discriminative model D that estimates the probability that a sample came from the training data rather than G.',
    citationCount: 58900,
    impactFactor: 9.1,
    citationHistory: generateCitationHistory(2014, 58900),
    keywords: ['GAN', 'generative models', 'adversarial training', 'deep learning'],
    doi: '10.5555/2969033.2969125'
  },
  {
    id: '6',
    title: 'GPT-4 Technical Report',
    authors: ['OpenAI'],
    conference: 'arXiv',
    year: 2023,
    abstract: 'We report the development of GPT-4, a large-scale, multimodal model which can accept image and text inputs and produce text outputs. While less capable than humans in many real-world scenarios, GPT-4 exhibits human-level performance on various professional and academic benchmarks.',
    citationCount: 4200,
    impactFactor: 7.8,
    citationHistory: generateCitationHistory(2023, 4200),
    keywords: ['GPT-4', 'large language models', 'multimodal', 'AI'],
    doi: '10.48550/arXiv.2303.08774'
  },
  {
    id: '7',
    title: 'Language Models are Few-Shot Learners',
    authors: ['Tom Brown', 'Benjamin Mann', 'Nick Ryder', 'Melanie Subbiah', 'Jared Kaplan', 'Prafulla Dhariwal', 'Arvind Neelakantan'],
    conference: 'NeurIPS',
    year: 2020,
    abstract: 'Recent work has demonstrated substantial gains on many NLP tasks and benchmarks by pre-training on a large corpus of text followed by fine-tuning on a specific task. We show that scaling up language models greatly improves task-agnostic, few-shot performance.',
    citationCount: 28600,
    impactFactor: 9.3,
    citationHistory: generateCitationHistory(2020, 28600),
    keywords: ['GPT-3', 'few-shot learning', 'language models', 'NLP'],
    doi: '10.5555/3495724.3495883'
  },
  {
    id: '8',
    title: 'Dropout: A Simple Way to Prevent Neural Networks from Overfitting',
    authors: ['Nitish Srivastava', 'Geoffrey Hinton', 'Alex Krizhevsky', 'Ilya Sutskever', 'Ruslan Salakhutdinov'],
    conference: 'JMLR',
    year: 2014,
    abstract: 'Deep neural nets with a large number of parameters are very powerful machine learning systems. However, overfitting is a serious problem in such networks. We propose dropout, a technique for addressing this problem by randomly dropping units during training.',
    citationCount: 45200,
    impactFactor: 8.7,
    citationHistory: generateCitationHistory(2014, 45200),
    keywords: ['dropout', 'regularization', 'overfitting', 'neural networks'],
    doi: '10.5555/2627435.2670313'
  },
  {
    id: '9',
    title: 'Adam: A Method for Stochastic Optimization',
    authors: ['Diederik P. Kingma', 'Jimmy Ba'],
    conference: 'ICLR',
    year: 2015,
    abstract: 'We introduce Adam, an algorithm for first-order gradient-based optimization of stochastic objective functions, based on adaptive estimates of lower-order moments. The method is straightforward to implement, is computationally efficient, has little memory requirements, and is well suited for problems with large data or parameters.',
    citationCount: 189500,
    impactFactor: 10.5,
    citationHistory: generateCitationHistory(2015, 189500),
    keywords: ['Adam', 'optimization', 'deep learning', 'gradient descent'],
    doi: '10.48550/arXiv.1412.6980'
  },
  {
    id: '10',
    title: 'Batch Normalization: Accelerating Deep Network Training',
    authors: ['Sergey Ioffe', 'Christian Szegedy'],
    conference: 'ICML',
    year: 2015,
    abstract: 'Training Deep Neural Networks is complicated by the fact that the distribution of each layer\'s inputs changes during training. We refer to this phenomenon as internal covariate shift, and address the problem by normalizing layer inputs. Applied to a state-of-the-art image classification model, Batch Normalization achieves the same accuracy with 14 times fewer training steps.',
    citationCount: 52800,
    impactFactor: 9.0,
    citationHistory: generateCitationHistory(2015, 52800),
    keywords: ['batch normalization', 'training', 'deep learning', 'neural networks'],
    doi: '10.5555/3045118.3045167'
  },
  {
    id: '11',
    title: 'U-Net: Convolutional Networks for Biomedical Image Segmentation',
    authors: ['Olaf Ronneberger', 'Philipp Fischer', 'Thomas Brox'],
    conference: 'MICCAI',
    year: 2015,
    abstract: 'There is large consent that successful training of deep networks requires many thousand annotated training samples. We present a network and training strategy that relies on the strong use of data augmentation to use the available annotated samples more efficiently.',
    citationCount: 67300,
    impactFactor: 8.5,
    citationHistory: generateCitationHistory(2015, 67300),
    keywords: ['U-Net', 'image segmentation', 'biomedical', 'CNN'],
    doi: '10.1007/978-3-319-24574-4_28'
  },
  {
    id: '12',
    title: 'Very Deep Convolutional Networks for Large-Scale Image Recognition',
    authors: ['Karen Simonyan', 'Andrew Zisserman'],
    conference: 'ICLR',
    year: 2015,
    abstract: 'In this work we investigate the effect of the convolutional network depth on its accuracy in the large-scale image recognition setting. Our main contribution is a thorough evaluation of networks of increasing depth using an architecture with very small convolution filters.',
    citationCount: 98700,
    impactFactor: 9.4,
    citationHistory: generateCitationHistory(2015, 98700),
    keywords: ['VGGNet', 'CNN', 'image recognition', 'deep learning'],
    doi: '10.48550/arXiv.1409.1556'
  },
  {
    id: '13',
    title: 'Diffusion Models Beat GANs on Image Synthesis',
    authors: ['Prafulla Dhariwal', 'Alexander Nichol'],
    conference: 'NeurIPS',
    year: 2021,
    abstract: 'We show that diffusion models can achieve image sample quality superior to the current state-of-the-art generative models. We achieve this by finding a better architecture through a series of ablations, and by using classifier guidance to trade off diversity for fidelity.',
    citationCount: 8900,
    impactFactor: 8.2,
    citationHistory: generateCitationHistory(2021, 8900),
    keywords: ['diffusion models', 'image synthesis', 'generative models', 'GANs'],
    doi: '10.5555/3540261.3541169'
  },
  {
    id: '14',
    title: 'ViT: An Image is Worth 16x16 Words',
    authors: ['Alexey Dosovitskiy', 'Lucas Beyer', 'Alexander Kolesnikov', 'Dirk Weissenborn', 'Xiaohua Zhai'],
    conference: 'ICLR',
    year: 2021,
    abstract: 'While the Transformer architecture has become the de-facto standard for natural language processing tasks, its applications to computer vision remain limited. We show that this reliance on CNNs is not necessary and a pure transformer applied directly to sequences of image patches can perform very well on image classification tasks.',
    citationCount: 25600,
    impactFactor: 9.1,
    citationHistory: generateCitationHistory(2021, 25600),
    keywords: ['Vision Transformer', 'ViT', 'image classification', 'transformers'],
    doi: '10.48550/arXiv.2010.11929'
  },
  {
    id: '15',
    title: 'CLIP: Learning Transferable Visual Models From Natural Language Supervision',
    authors: ['Alec Radford', 'Jong Wook Kim', 'Chris Hallacy', 'Aditya Ramesh', 'Gabriel Goh', 'Sandhini Agarwal'],
    conference: 'ICML',
    year: 2021,
    abstract: 'State-of-the-art computer vision systems are trained to predict a fixed set of predetermined object categories. This restricted form of supervision limits their generality and usability. We demonstrate that the simple pre-training task of predicting which caption goes with which image is an efficient and scalable way to learn SOTA image representations from scratch.',
    citationCount: 18200,
    impactFactor: 8.8,
    citationHistory: generateCitationHistory(2021, 18200),
    keywords: ['CLIP', 'multimodal', 'vision-language', 'transfer learning'],
    doi: '10.48550/arXiv.2103.00020'
  },
  {
    id: '16',
    title: 'LLaMA: Open and Efficient Foundation Language Models',
    authors: ['Hugo Touvron', 'Thibaut Lavril', 'Gautier Izacard', 'Xavier Martinet', 'Marie-Anne Lachaux'],
    conference: 'arXiv',
    year: 2023,
    abstract: 'We introduce LLaMA, a collection of foundation language models ranging from 7B to 65B parameters. We train our models on trillions of tokens, and show that it is possible to train state-of-the-art models using publicly available datasets exclusively.',
    citationCount: 6800,
    impactFactor: 8.0,
    citationHistory: generateCitationHistory(2023, 6800),
    keywords: ['LLaMA', 'language models', 'open source', 'foundation models'],
    doi: '10.48550/arXiv.2302.13971'
  }
];

export const conferences = [...new Set(papers.map(p => p.conference))].sort();
export const years = [...new Set(papers.map(p => p.year))].sort((a, b) => b - a);
export const minYear = Math.min(...papers.map(p => p.year));
export const maxYear = Math.max(...papers.map(p => p.year));
