import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { usePapers } from '@/context/PapersContext';
import { Header } from '@/components/Header';
import { ComparisonPanel } from '@/components/ComparisonPanel';
import { CitationChart } from '@/components/CitationChart';
import { EmptyState } from '@/components/EmptyState';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Star, 
  Users, 
  Calendar, 
  BookOpen, 
  TrendingUp,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { cn } from '@/lib/utils';

const PaperDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getPaperById, toggleFavorite, isFavorite } = usePapers();
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const paper = getPaperById(id || '');
  const favorite = paper ? isFavorite(paper.id) : false;

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  const handleCopyDOI = async () => {
    if (paper?.doi) {
      await navigator.clipboard.writeText(paper.doi);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!paper) {
    return (
      <div className="min-h-screen bg-background">
        <Header 
          isPanelOpen={isPanelOpen} 
          onTogglePanel={() => setIsPanelOpen(!isPanelOpen)} 
        />
        <main className="container mx-auto px-4 py-12">
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground mb-8"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to papers
          </Link>
          <EmptyState type="no-data" />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header 
        isPanelOpen={isPanelOpen} 
        onTogglePanel={() => setIsPanelOpen(!isPanelOpen)} 
      />
      
      <main className={`transition-all duration-300 ${isPanelOpen ? 'mr-96' : ''}`}>
        <div className="container mx-auto px-4 py-6">
          {/* Back Link */}
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6 group"
          >
            <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to papers
          </Link>

          {/* Paper Header */}
          <header className="mb-8 animate-fade-in">
            <div className="flex items-start justify-between gap-4 mb-4">
              <h1 className="font-serif text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-tight text-balance">
                {paper.title}
              </h1>
              <Button
                variant="outline"
                size="lg"
                onClick={() => toggleFavorite(paper.id)}
                className={cn(
                  "flex-shrink-0 transition-all duration-200",
                  favorite && "border-favorite text-favorite hover:text-favorite/80"
                )}
              >
                <Star className={cn("h-5 w-5 mr-2", favorite && "fill-current")} />
                {favorite ? 'In Comparison' : 'Add to Compare'}
              </Button>
            </div>

            {/* Authors */}
            <div className="flex items-center gap-2 text-muted-foreground mb-4">
              <Users className="h-4 w-4 flex-shrink-0" />
              <p className="text-sm md:text-base">
                {paper.authors.join(', ')}
              </p>
            </div>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-4">
              <Badge variant="default" className="bg-primary text-primary-foreground text-sm">
                {paper.conference}
              </Badge>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Calendar className="h-4 w-4" />
                <span>{paper.year}</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <BookOpen className="h-4 w-4" />
                <span>{formatNumber(paper.citationCount)} citations</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-accent font-medium">
                <TrendingUp className="h-4 w-4" />
                <span>Impact Factor: {paper.impactFactor.toFixed(1)}</span>
              </div>
            </div>
          </header>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Citation Chart */}
              <section className="animate-slide-in" style={{ animationDelay: '100ms' }}>
                <CitationChart paper={paper} />
              </section>

              {/* Abstract */}
              <section 
                className="bg-card rounded-lg border border-border p-6 animate-slide-in"
                style={{ animationDelay: '200ms' }}
              >
                <h2 className="font-serif text-xl font-semibold text-foreground mb-4">Abstract</h2>
                <p className="text-muted-foreground leading-relaxed">
                  {paper.abstract}
                </p>
              </section>
            </div>

            {/* Sidebar Info */}
            <aside className="space-y-6">
              {/* Keywords */}
              <section 
                className="bg-card rounded-lg border border-border p-5 animate-slide-in"
                style={{ animationDelay: '150ms' }}
              >
                <h3 className="font-serif text-lg font-semibold text-foreground mb-3">Keywords</h3>
                <div className="flex flex-wrap gap-2">
                  {paper.keywords.map(keyword => (
                    <Badge key={keyword} variant="secondary" className="text-sm">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </section>

              {/* DOI / Links */}
              <section 
                className="bg-card rounded-lg border border-border p-5 animate-slide-in"
                style={{ animationDelay: '200ms' }}
              >
                <h3 className="font-serif text-lg font-semibold text-foreground mb-3">Reference</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 p-3 bg-muted rounded-md">
                    <code className="text-xs text-muted-foreground truncate flex-1">
                      {paper.doi}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 flex-shrink-0"
                      onClick={handleCopyDOI}
                    >
                      {copied ? (
                        <Check className="h-3.5 w-3.5 text-accent" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => window.open(`https://doi.org/${paper.doi}`, '_blank')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Source
                  </Button>
                </div>
              </section>

              {/* Stats Summary */}
              <section 
                className="bg-card rounded-lg border border-border p-5 animate-slide-in"
                style={{ animationDelay: '250ms' }}
              >
                <h3 className="font-serif text-lg font-semibold text-foreground mb-4">Quick Stats</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground text-sm">Total Citations</span>
                    <span className="font-semibold text-foreground">{formatNumber(paper.citationCount)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground text-sm">Years Since Publication</span>
                    <span className="font-semibold text-foreground">{2024 - paper.year}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground text-sm">Avg Citations/Year</span>
                    <span className="font-semibold text-accent">
                      {Math.round(paper.citationCount / (2024 - paper.year + 1))}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground text-sm">Impact Factor</span>
                    <span className="font-semibold text-foreground">{paper.impactFactor.toFixed(2)}</span>
                  </div>
                </div>
              </section>
            </aside>
          </div>
        </div>
      </main>

      {/* Comparison Panel */}
      {isPanelOpen && (
        <div 
          className="fixed inset-0 bg-foreground/20 z-30 lg:hidden"
          onClick={() => setIsPanelOpen(false)}
        />
      )}
      
      <ComparisonPanel 
        isOpen={isPanelOpen} 
        onClose={() => setIsPanelOpen(false)} 
      />
    </div>
  );
};

export default PaperDetail;
