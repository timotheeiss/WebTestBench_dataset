import { useState } from 'react';
import { usePapers } from '@/context/PapersContext';
import { Header } from '@/components/Header';
import { FilterPanel } from '@/components/FilterPanel';
import { PaperCard } from '@/components/PaperCard';
import { ComparisonPanel } from '@/components/ComparisonPanel';
import { EmptyState } from '@/components/EmptyState';

const Index = () => {
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const { filteredPapers, resetFilter } = usePapers();

  return (
    <div className="min-h-screen bg-background">
      <Header 
        isPanelOpen={isPanelOpen} 
        onTogglePanel={() => setIsPanelOpen(!isPanelOpen)} 
      />
      
      <main className={`transition-all duration-300 ${isPanelOpen ? 'mr-96' : ''}`}>
        <div className="container mx-auto px-4 py-6">
          {/* Hero Section */}
          <section className="mb-8 text-center">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-3">
              Explore Academic Research
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Browse influential papers, analyze citation trends, and compare research impact 
              across conferences and years.
            </p>
          </section>

          <div className="grid lg:grid-cols-[300px_1fr] gap-6">
            {/* Sidebar with Filters */}
            <aside className="lg:sticky lg:top-20 lg:self-start">
              <FilterPanel />
            </aside>

            {/* Paper List */}
            <section>
              {filteredPapers.length === 0 ? (
                <EmptyState type="no-results" onReset={resetFilter} />
              ) : (
                <div className="space-y-4">
                  {filteredPapers.map((paper, index) => (
                    <div 
                      key={paper.id} 
                      style={{ animationDelay: `${index * 50}ms` }}
                      className="animate-slide-in"
                    >
                      <PaperCard paper={paper} />
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        </div>
      </main>

      {/* Comparison Panel Overlay */}
      {isPanelOpen && (
        <div 
          className="fixed inset-0 bg-foreground/20 z-30 lg:hidden"
          onClick={() => setIsPanelOpen(false)}
        />
      )}
      
      <ComparisonPanel 
        isOpen={isPanelOpen} 
        onClose={() => setIsPanelOpen(false)} 
      />
    </div>
  );
};

export default Index;
