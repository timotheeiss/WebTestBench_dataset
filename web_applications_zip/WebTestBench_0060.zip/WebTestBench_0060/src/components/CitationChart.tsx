import { useState } from 'react';
import { Paper, ChartViewState } from '@/types/paper';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  AreaChart, 
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend,
  Brush
} from 'recharts';
import { TrendingUp, BarChart3, Activity, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface CitationChartProps {
  paper: Paper;
}

export function CitationChart({ paper }: CitationChartProps) {
  const [viewState, setViewState] = useState<ChartViewState>({
    timeRange: 'all',
    chartType: 'area',
    showCumulative: false,
  });

  const [zoomDomain, setZoomDomain] = useState<{ start: number; end: number } | null>(null);

  const currentYear = 2024;
  
  const getFilteredData = () => {
    let data = paper.citationHistory;
    
    switch (viewState.timeRange) {
      case '1year':
        data = data.filter(d => d.year >= currentYear - 1);
        break;
      case '3years':
        data = data.filter(d => d.year >= currentYear - 3);
        break;
      case '5years':
        data = data.filter(d => d.year >= currentYear - 5);
        break;
    }
    
    return data;
  };

  const data = getFilteredData();
  const dataKey = viewState.showCumulative ? 'cumulativeCitations' : 'citations';

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  const handleZoomIn = () => {
    if (data.length < 3) return;
    const mid = Math.floor(data.length / 2);
    const range = Math.floor(data.length / 4);
    setZoomDomain({
      start: Math.max(0, mid - range),
      end: Math.min(data.length - 1, mid + range),
    });
  };

  const handleZoomOut = () => {
    setZoomDomain(null);
  };

  const handleReset = () => {
    setZoomDomain(null);
    setViewState({
      timeRange: 'all',
      chartType: 'area',
      showCumulative: false,
    });
  };

  const renderChart = () => {
    const commonProps = {
      data: zoomDomain 
        ? data.slice(zoomDomain.start, zoomDomain.end + 1) 
        : data,
      margin: { top: 10, right: 30, left: 10, bottom: 0 },
    };

    const commonAxisProps = {
      xAxis: (
        <XAxis 
          dataKey="year" 
          tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={{ stroke: 'hsl(var(--border))' }}
          tickLine={{ stroke: 'hsl(var(--border))' }}
        />
      ),
      yAxis: (
        <YAxis 
          tickFormatter={formatNumber}
          tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={{ stroke: 'hsl(var(--border))' }}
          tickLine={{ stroke: 'hsl(var(--border))' }}
        />
      ),
      grid: <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />,
      tooltip: (
        <Tooltip
          contentStyle={{
            backgroundColor: 'hsl(var(--popover))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px',
            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
          }}
          labelStyle={{ color: 'hsl(var(--foreground))', fontWeight: 500 }}
          formatter={(value: number) => [
            formatNumber(value),
            viewState.showCumulative ? 'Cumulative Citations' : 'Citations'
          ]}
        />
      ),
      brush: !zoomDomain && data.length > 5 && (
        <Brush 
          dataKey="year" 
          height={30} 
          stroke="hsl(var(--accent))"
          fill="hsl(var(--muted))"
        />
      ),
    };

    switch (viewState.chartType) {
      case 'line':
        return (
          <LineChart {...commonProps}>
            {commonAxisProps.grid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            <Line 
              type="monotone" 
              dataKey={dataKey}
              stroke="hsl(var(--chart-primary))"
              strokeWidth={2.5}
              dot={{ fill: 'hsl(var(--chart-primary))', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6, fill: 'hsl(var(--chart-primary))' }}
            />
            {commonAxisProps.brush}
          </LineChart>
        );
      case 'bar':
        return (
          <BarChart {...commonProps}>
            {commonAxisProps.grid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            <Bar 
              dataKey={dataKey}
              fill="hsl(var(--chart-primary))"
              radius={[4, 4, 0, 0]}
            />
            {commonAxisProps.brush}
          </BarChart>
        );
      case 'area':
      default:
        return (
          <AreaChart {...commonProps}>
            <defs>
              <linearGradient id="colorCitations" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--chart-primary))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--chart-primary))" stopOpacity={0}/>
              </linearGradient>
            </defs>
            {commonAxisProps.grid}
            {commonAxisProps.xAxis}
            {commonAxisProps.yAxis}
            {commonAxisProps.tooltip}
            <Area 
              type="monotone" 
              dataKey={dataKey}
              stroke="hsl(var(--chart-primary))"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorCitations)"
            />
            {commonAxisProps.brush}
          </AreaChart>
        );
    }
  };

  // Edge case: no data
  if (!paper.citationHistory || paper.citationHistory.length === 0) {
    return (
      <div className="bg-card rounded-lg border border-border p-8">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <BarChart3 className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-serif text-lg font-medium text-foreground mb-2">
            No citation data available
          </h3>
          <p className="text-sm text-muted-foreground max-w-[300px]">
            Citation history for this paper has not been recorded yet.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <h3 className="font-serif text-lg font-semibold text-foreground">Citation Trends</h3>
          <Badge variant="secondary" className="font-mono text-xs">
            {paper.year} - {currentYear}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handleZoomIn}
            disabled={!!zoomDomain || data.length < 3}
            className="h-8 w-8"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleZoomOut}
            disabled={!zoomDomain}
            className="h-8 w-8"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleReset}
            className="h-8 w-8"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Time Range Tabs */}
      <div className="flex flex-wrap items-center gap-4">
        <Tabs 
          value={viewState.timeRange} 
          onValueChange={(v) => setViewState(prev => ({ ...prev, timeRange: v as ChartViewState['timeRange'] }))}
        >
          <TabsList className="h-9">
            <TabsTrigger value="all" className="text-xs">All Time</TabsTrigger>
            <TabsTrigger value="5years" className="text-xs">5 Years</TabsTrigger>
            <TabsTrigger value="3years" className="text-xs">3 Years</TabsTrigger>
            <TabsTrigger value="1year" className="text-xs">1 Year</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-1 border border-border rounded-lg p-1">
          <Button
            variant={viewState.chartType === 'area' ? 'secondary' : 'ghost'}
            size="sm"
            className="h-7 px-2"
            onClick={() => setViewState(prev => ({ ...prev, chartType: 'area' }))}
          >
            <Activity className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant={viewState.chartType === 'line' ? 'secondary' : 'ghost'}
            size="sm"
            className="h-7 px-2"
            onClick={() => setViewState(prev => ({ ...prev, chartType: 'line' }))}
          >
            <TrendingUp className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant={viewState.chartType === 'bar' ? 'secondary' : 'ghost'}
            size="sm"
            className="h-7 px-2"
            onClick={() => setViewState(prev => ({ ...prev, chartType: 'bar' }))}
          >
            <BarChart3 className="h-3.5 w-3.5" />
          </Button>
        </div>

        <Button
          variant={viewState.showCumulative ? 'secondary' : 'outline'}
          size="sm"
          className="h-9"
          onClick={() => setViewState(prev => ({ ...prev, showCumulative: !prev.showCumulative }))}
        >
          {viewState.showCumulative ? 'Cumulative' : 'Per Year'}
        </Button>
      </div>

      {/* Chart */}
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
        <div className="text-center">
          <p className="text-2xl font-serif font-bold text-foreground">
            {formatNumber(paper.citationCount)}
          </p>
          <p className="text-xs text-muted-foreground">Total Citations</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-serif font-bold text-accent">
            {Math.round(paper.citationCount / (currentYear - paper.year + 1))}
          </p>
          <p className="text-xs text-muted-foreground">Avg per Year</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-serif font-bold text-foreground">
            {paper.impactFactor.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">Impact Factor</p>
        </div>
      </div>
    </div>
  );
}
