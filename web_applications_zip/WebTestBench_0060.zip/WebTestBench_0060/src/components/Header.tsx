import { usePapers } from '@/context/PapersContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Star, PanelRightOpen, PanelRightClose } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HeaderProps {
  isPanelOpen: boolean;
  onTogglePanel: () => void;
}

export function Header({ isPanelOpen, onTogglePanel }: HeaderProps) {
  const { favorites } = usePapers();

  return (
    <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center group-hover:bg-accent transition-colors">
              <BookOpen className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-serif text-xl font-bold text-foreground">ScholarScope</h1>
              <p className="text-xs text-muted-foreground">Academic Paper Explorer</p>
            </div>
          </Link>

          <Button
            variant="outline"
            onClick={onTogglePanel}
            className="relative"
          >
            {isPanelOpen ? (
              <PanelRightClose className="h-4 w-4 mr-2" />
            ) : (
              <PanelRightOpen className="h-4 w-4 mr-2" />
            )}
            <Star className="h-4 w-4 mr-1" />
            Comparison
            {favorites.length > 0 && (
              <Badge 
                variant="default" 
                className="ml-2 h-5 min-w-[20px] px-1.5 bg-accent text-accent-foreground text-xs"
              >
                {favorites.length}
              </Badge>
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
