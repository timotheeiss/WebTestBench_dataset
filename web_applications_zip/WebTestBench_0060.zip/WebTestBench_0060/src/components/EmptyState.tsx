import { FileSearch, SearchX } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  type: 'no-results' | 'no-data';
  onReset?: () => void;
}

export function EmptyState({ type, onReset }: EmptyStateProps) {
  if (type === 'no-results') {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
        <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
          <SearchX className="h-10 w-10 text-muted-foreground" />
        </div>
        <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
          No papers found
        </h3>
        <p className="text-muted-foreground max-w-md mb-6">
          We couldn't find any papers matching your search criteria. 
          Try adjusting your filters or search terms.
        </p>
        {onReset && (
          <Button onClick={onReset} variant="outline">
            Clear all filters
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
        <FileSearch className="h-10 w-10 text-muted-foreground" />
      </div>
      <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
        No data available
      </h3>
      <p className="text-muted-foreground max-w-md">
        The requested data is not available at this time. Please try again later.
      </p>
    </div>
  );
}
