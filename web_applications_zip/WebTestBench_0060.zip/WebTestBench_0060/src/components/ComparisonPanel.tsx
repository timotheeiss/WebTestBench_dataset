import { usePapers } from '@/context/PapersContext';
import { Paper } from '@/types/paper';
import { X, BarChart3, Trash2, FileText, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Cell 
} from 'recharts';

const chartColors = [
  'hsl(175, 65%, 40%)',
  'hsl(220, 60%, 50%)',
  'hsl(280, 60%, 55%)',
  'hsl(45, 90%, 50%)',
  'hsl(340, 65%, 50%)',
  'hsl(120, 50%, 45%)',
];

interface ComparisonPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ComparisonPanel({ isOpen, onClose }: ComparisonPanelProps) {
  const { getFavoritePapers, toggleFavorite, clearFavorites } = usePapers();
  const favoritePapers = getFavoritePapers();

  const chartData = favoritePapers.map((paper, index) => ({
    name: paper.title.length > 20 ? paper.title.substring(0, 20) + '...' : paper.title,
    fullName: paper.title,
    citations: paper.citationCount,
    impactFactor: paper.impactFactor,
    color: chartColors[index % chartColors.length],
  }));

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}k`;
    }
    return num.toString();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed right-0 top-0 h-full w-96 bg-card border-l border-border shadow-lg z-40 animate-slide-in flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Star className="h-5 w-5 text-favorite fill-current" />
          <h2 className="font-serif text-lg font-semibold">Comparison Panel</h2>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {favoritePapers.length === 0 ? (
            <EmptyState />
          ) : (
            <>
              {/* Chart */}
              <div className="bg-secondary/50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <BarChart3 className="h-4 w-4 text-accent" />
                  <span className="text-sm font-medium">Citation Comparison</span>
                </div>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 10 }}>
                      <XAxis 
                        type="number" 
                        tickFormatter={formatNumber}
                        tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                      />
                      <YAxis 
                        type="category" 
                        dataKey="name" 
                        width={80}
                        tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-popover border border-border rounded-md p-2 shadow-lg">
                                <p className="text-xs font-medium text-foreground line-clamp-2">{data.fullName}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {formatNumber(data.citations)} citations
                                </p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="citations" radius={[0, 4, 4, 0]}>
                        {chartData.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Paper List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    {favoritePapers.length} paper{favoritePapers.length !== 1 ? 's' : ''}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearFavorites}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5 mr-1" />
                    Clear all
                  </Button>
                </div>

                {favoritePapers.map((paper, index) => (
                  <ComparisonPaperItem 
                    key={paper.id} 
                    paper={paper} 
                    color={chartColors[index % chartColors.length]}
                    onRemove={() => toggleFavorite(paper.id)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

function ComparisonPaperItem({ 
  paper, 
  color, 
  onRemove 
}: { 
  paper: Paper; 
  color: string;
  onRemove: () => void;
}) {
  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  return (
    <div className="group flex items-start gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
      <div 
        className="w-1 h-full min-h-[40px] rounded-full flex-shrink-0"
        style={{ backgroundColor: color }}
      />
      <div className="flex-1 min-w-0">
        <Link 
          to={`/paper/${paper.id}`}
          className="text-sm font-medium text-foreground hover:text-accent transition-colors line-clamp-2"
        >
          {paper.title}
        </Link>
        <div className="flex items-center gap-2 mt-1">
          <Badge variant="outline" className="text-xs">
            {paper.conference} {paper.year}
          </Badge>
          <span className="text-xs text-muted-foreground">
            {formatNumber(paper.citationCount)} citations
          </span>
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
        onClick={onRemove}
      >
        <X className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <FileText className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="font-serif text-lg font-medium text-foreground mb-2">
        No papers selected
      </h3>
      <p className="text-sm text-muted-foreground max-w-[250px]">
        Click the star icon on any paper to add it here for comparison.
      </p>
    </div>
  );
}
