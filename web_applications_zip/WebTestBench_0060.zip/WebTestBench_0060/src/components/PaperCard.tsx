import { Paper } from '@/types/paper';
import { usePapers } from '@/context/PapersContext';
import { Star, Users, Calendar, BookOpen, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface PaperCardProps {
  paper: Paper;
  showAbstract?: boolean;
}

export function PaperCard({ paper, showAbstract = true }: PaperCardProps) {
  const { toggleFavorite, isFavorite } = usePapers();
  const favorite = isFavorite(paper.id);

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  return (
    <article className="group relative bg-card rounded-lg border border-border p-5 shadow-card transition-all duration-300 hover:shadow-card-hover hover:border-accent/30 animate-fade-in">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <Link 
            to={`/paper/${paper.id}`}
            className="block"
          >
            <h3 className="font-serif text-lg font-semibold text-foreground leading-tight hover:text-accent transition-colors line-clamp-2">
              {paper.title}
            </h3>
          </Link>
          
          <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
            <Users className="h-3.5 w-3.5 flex-shrink-0" />
            <span className="truncate">
              {paper.authors.slice(0, 3).join(', ')}
              {paper.authors.length > 3 && ` +${paper.authors.length - 3} more`}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 mt-3">
            <Badge variant="secondary" className="font-medium">
              {paper.conference}
            </Badge>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Calendar className="h-3.5 w-3.5" />
              <span>{paper.year}</span>
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <BookOpen className="h-3.5 w-3.5" />
              <span>{formatNumber(paper.citationCount)} citations</span>
            </div>
            <div className="flex items-center gap-1 text-sm text-accent">
              <TrendingUp className="h-3.5 w-3.5" />
              <span>IF: {paper.impactFactor.toFixed(1)}</span>
            </div>
          </div>

          {showAbstract && (
            <p className="mt-3 text-sm text-muted-foreground line-clamp-2 leading-relaxed">
              {paper.abstract}
            </p>
          )}

          <div className="flex flex-wrap gap-1.5 mt-3">
            {paper.keywords.slice(0, 4).map(keyword => (
              <Badge 
                key={keyword} 
                variant="outline" 
                className="text-xs font-normal"
              >
                {keyword}
              </Badge>
            ))}
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(paper.id);
          }}
          className={cn(
            "flex-shrink-0 h-9 w-9 transition-all duration-200",
            favorite 
              ? "text-favorite hover:text-favorite/80" 
              : "text-muted-foreground hover:text-favorite"
          )}
          aria-label={favorite ? "Remove from comparison" : "Add to comparison"}
        >
          <Star className={cn("h-5 w-5", favorite && "fill-current")} />
        </Button>
      </div>
    </article>
  );
}
