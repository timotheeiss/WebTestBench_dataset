import { usePapers } from '@/context/PapersContext';
import { conferences, minYear, maxYear } from '@/data/papers';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X, SlidersHorizontal, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { SortOption } from '@/types/paper';
import { cn } from '@/lib/utils';

const sortOptions: { value: SortOption; label: string }[] = [
  { value: 'citations', label: 'Citations' },
  { value: 'year', label: 'Year' },
  { value: 'impactFactor', label: 'Impact Factor' },
  { value: 'title', label: 'Title' },
];

export function FilterPanel() {
  const { 
    filter, 
    setFilter, 
    resetFilter, 
    sortBy, 
    sortDirection, 
    setSort,
    filteredPapers 
  } = usePapers();

  const hasActiveFilters = 
    filter.searchQuery || 
    filter.conferences.length > 0 || 
    filter.yearRange[0] !== minYear || 
    filter.yearRange[1] !== maxYear;

  const toggleConference = (conference: string) => {
    const newConferences = filter.conferences.includes(conference)
      ? filter.conferences.filter(c => c !== conference)
      : [...filter.conferences, conference];
    setFilter({ conferences: newConferences });
  };

  return (
    <div className="bg-card rounded-lg border border-border p-4 shadow-card space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search papers, authors, keywords..."
          value={filter.searchQuery}
          onChange={(e) => setFilter({ searchQuery: e.target.value })}
          className="pl-9 pr-9"
        />
        {filter.searchQuery && (
          <button
            onClick={() => setFilter({ searchQuery: '' })}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Year Range */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">Year Range</span>
          <span className="text-sm text-muted-foreground">
            {filter.yearRange[0]} - {filter.yearRange[1]}
          </span>
        </div>
        <Slider
          value={filter.yearRange}
          min={minYear}
          max={maxYear}
          step={1}
          onValueChange={(value) => setFilter({ yearRange: value as [number, number] })}
          className="mt-2"
        />
      </div>

      {/* Conferences */}
      <div className="space-y-2">
        <span className="text-sm font-medium text-foreground">Conferences</span>
        <div className="flex flex-wrap gap-1.5">
          {conferences.map(conf => (
            <Badge
              key={conf}
              variant={filter.conferences.includes(conf) ? "default" : "outline"}
              className={cn(
                "cursor-pointer transition-all",
                filter.conferences.includes(conf) 
                  ? "bg-accent text-accent-foreground hover:bg-accent/90" 
                  : "hover:bg-secondary"
              )}
              onClick={() => toggleConference(conf)}
            >
              {conf}
            </Badge>
          ))}
        </div>
      </div>

      {/* Sort */}
      <div className="flex items-center gap-2">
        <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
        <Select
          value={sortBy}
          onValueChange={(value) => setSort(value as SortOption)}
        >
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant="outline"
          size="icon"
          onClick={() => setSort(sortBy)}
          className="flex-shrink-0"
        >
          {sortDirection === 'desc' ? (
            <ArrowDown className="h-4 w-4" />
          ) : (
            <ArrowUp className="h-4 w-4" />
          )}
        </Button>
      </div>

      {/* Results & Reset */}
      <div className="flex items-center justify-between pt-2 border-t border-border">
        <span className="text-sm text-muted-foreground">
          {filteredPapers.length} paper{filteredPapers.length !== 1 ? 's' : ''} found
        </span>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={resetFilter}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-3 w-3 mr-1" />
            Clear filters
          </Button>
        )}
      </div>
    </div>
  );
}
