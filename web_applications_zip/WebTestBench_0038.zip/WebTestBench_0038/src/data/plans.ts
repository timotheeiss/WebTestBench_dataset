export interface PlanFeature {
  name: string;
  free: boolean | string;
  pro: boolean | string;
  enterprise: boolean | string;
}

export type BillingPeriod = 'monthly' | 'quarterly' | 'annual';

export interface PlanPricing {
  monthly: number;
  quarterly: number;
  annual: number;
}

export interface Plan {
  id: string;
  name: string;
  description: string;
  pricing: PlanPricing;
  popular?: boolean;
  features: string[];
  cta: string;
}

export const billingPeriodLabels: Record<BillingPeriod, string> = {
  monthly: 'Monthly',
  quarterly: 'Quarterly',
  annual: 'Annual',
};

export const billingPeriodMonths: Record<BillingPeriod, number> = {
  monthly: 1,
  quarterly: 3,
  annual: 12,
};

export const plans: Plan[] = [
  {
    id: 'free',
    name: 'Free',
    description: 'Perfect for getting started and exploring the platform.',
    pricing: {
      monthly: 0,
      quarterly: 0,
      annual: 0,
    },
    features: [
      'Up to 3 projects',
      '1 GB storage',
      'Community support',
      'Basic analytics',
      'API access (100 req/day)',
    ],
    cta: 'Get Started',
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'Best for professionals and growing teams.',
    pricing: {
      monthly: 29,
      quarterly: 79, // ~9% savings
      annual: 290, // ~17% savings
    },
    popular: true,
    features: [
      'Unlimited projects',
      '50 GB storage',
      'Priority support',
      'Advanced analytics',
      'API access (10,000 req/day)',
      'Custom integrations',
      'Team collaboration',
    ],
    cta: 'Start Free Trial',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For organizations that need advanced security and control.',
    pricing: {
      monthly: 99,
      quarterly: 269, // ~9% savings
      annual: 990, // ~17% savings
    },
    features: [
      'Everything in Pro',
      'Unlimited storage',
      'Dedicated support',
      'Custom analytics',
      'Unlimited API access',
      'SSO & SAML',
      'Audit logs',
      'SLA guarantee',
      'Custom contracts',
    ],
    cta: 'Contact Sales',
  },
];

export function calculateSavings(plan: Plan, period: BillingPeriod): number {
  if (period === 'monthly' || plan.pricing.monthly === 0) return 0;
  const monthlyTotal = plan.pricing.monthly * billingPeriodMonths[period];
  const periodPrice = plan.pricing[period];
  return Math.round(((monthlyTotal - periodPrice) / monthlyTotal) * 100);
}

export function getMonthlyEquivalent(plan: Plan, period: BillingPeriod): number {
  if (plan.pricing[period] === 0) return 0;
  return Math.round((plan.pricing[period] / billingPeriodMonths[period]) * 100) / 100;
}

export const featureComparison: PlanFeature[] = [
  { name: 'Projects', free: '3', pro: 'Unlimited', enterprise: 'Unlimited' },
  { name: 'Storage', free: '1 GB', pro: '50 GB', enterprise: 'Unlimited' },
  { name: 'API Requests', free: '100/day', pro: '10,000/day', enterprise: 'Unlimited' },
  { name: 'Team Members', free: '1', pro: '10', enterprise: 'Unlimited' },
  { name: 'Analytics', free: 'Basic', pro: 'Advanced', enterprise: 'Custom' },
  { name: 'Support', free: 'Community', pro: 'Priority', enterprise: 'Dedicated' },
  { name: 'Custom Integrations', free: false, pro: true, enterprise: true },
  { name: 'SSO & SAML', free: false, pro: false, enterprise: true },
  { name: 'Audit Logs', free: false, pro: false, enterprise: true },
  { name: 'SLA Guarantee', free: false, pro: false, enterprise: true },
];
