import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { PricingCard } from '@/components/PricingCard';
import { FeatureComparisonTable } from '@/components/FeatureComparisonTable';
import { plans, BillingPeriod, billingPeriodLabels } from '@/data/plans';
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function Pricing() {
  const { user, subscription } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState<string | null>(null);
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod>('monthly');

  const handleSelectPlan = async (planId: string) => {
    if (!user) {
      navigate('/signup', { state: { selectedPlan: planId, billingPeriod } });
      return;
    }

    if (planId === 'enterprise') {
      toast({
        title: 'Contact Sales',
        description: 'Our team will reach out to discuss your enterprise needs.',
      });
      return;
    }

    navigate('/checkout', { state: { planId, billingPeriod } });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12 animate-slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Simple, transparent pricing
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose the plan that's right for you. All plans include a 14-day free trial.
            </p>
          </div>

          {/* Billing Period Toggle */}
          <div className="flex justify-center mb-12 animate-slide-up" style={{ animationDelay: '50ms' }}>
            <div className="inline-flex items-center bg-muted/50 rounded-full p-1 border border-border">
              {(Object.keys(billingPeriodLabels) as BillingPeriod[]).map((period) => (
                <button
                  key={period}
                  onClick={() => setBillingPeriod(period)}
                  className={cn(
                    'relative px-6 py-2 text-sm font-medium rounded-full transition-all duration-300',
                    billingPeriod === period
                      ? 'bg-primary text-primary-foreground shadow-md'
                      : 'text-muted-foreground hover:text-foreground'
                  )}
                >
                  {billingPeriodLabels[period]}
                  {period === 'annual' && (
                    <span className="ml-2 text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
                      Best Value
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-24">
            {plans.map((plan, index) => (
              <div
                key={plan.id}
                className="animate-slide-up"
                style={{ animationDelay: `${(index + 1) * 100}ms` }}
              >
                <PricingCard
                  plan={plan}
                  billingPeriod={billingPeriod}
                  onSelect={handleSelectPlan}
                  isCurrentPlan={subscription?.planId === plan.id}
                  isLoading={isLoading === plan.id}
                />
              </div>
            ))}
          </div>

          {/* Feature Comparison */}
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-foreground text-center mb-8">
              Compare all features
            </h2>
            <div className="bg-card rounded-2xl border border-border shadow-card overflow-hidden">
              <FeatureComparisonTable />
            </div>
          </div>

          {/* FAQ or Trust Section */}
          <div className="mt-24 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Trusted by 10,000+ teams worldwide
            </h2>
            <p className="text-muted-foreground">
              From startups to Fortune 500 companies, teams rely on FlowSync every day.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
