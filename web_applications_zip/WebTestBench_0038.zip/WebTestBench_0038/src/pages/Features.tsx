import { Link } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import {
  Zap,
  Shield,
  BarChart3,
  Users,
  Sparkles,
  Globe,
  Lock,
  Layers,
  RefreshCw,
  Cpu,
  ArrowRight,
} from 'lucide-react';

const mainFeatures = [
  {
    icon: Zap,
    title: 'Real-time Collaboration',
    description:
      'Work together seamlessly with real-time updates, live cursors, and instant sync across all devices. Never miss a beat when working with your team.',
    highlights: ['Live presence indicators', 'Instant sync', 'Conflict resolution'],
  },
  {
    icon: Sparkles,
    title: 'AI-Powered Automation',
    description:
      'Let our AI handle repetitive tasks while you focus on what matters. Smart suggestions, automated workflows, and predictive analytics built right in.',
    highlights: ['Smart task suggestions', 'Automated workflows', 'Predictive insights'],
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description:
      'Gain deep insights into your team\'s productivity with customizable dashboards, detailed reports, and actionable recommendations.',
    highlights: ['Custom dashboards', 'Team metrics', 'Export reports'],
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description:
      'Bank-grade security with end-to-end encryption, SSO integration, and compliance with major security standards including SOC 2 and GDPR.',
    highlights: ['End-to-end encryption', 'SSO & SAML', 'Audit logs'],
  },
];

const additionalFeatures = [
  { icon: Lock, title: 'Role-based Access', description: 'Fine-grained permissions for teams' },
  { icon: Layers, title: 'Version History', description: 'Track and restore any change' },
  { icon: RefreshCw, title: 'Auto-backup', description: 'Continuous data protection' },
  { icon: Globe, title: 'Global CDN', description: 'Fast access from anywhere' },
  { icon: Cpu, title: 'API Access', description: 'Build custom integrations' },
  { icon: Users, title: 'Team Workspaces', description: 'Organize projects by team' },
];

export default function Features() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-20 animate-slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Powerful features for
              <span className="text-gradient block">modern teams</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to streamline your workflow and boost productivity.
            </p>
          </div>

          {/* Main Features */}
          <div className="space-y-24 mb-24">
            {mainFeatures.map((feature, index) => (
              <div
                key={feature.title}
                className={`flex flex-col ${
                  index % 2 === 1 ? 'md:flex-row-reverse' : 'md:flex-row'
                } items-center gap-12`}
              >
                <div className="flex-1">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                    <feature.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                    {feature.title}
                  </h2>
                  <p className="text-muted-foreground mb-6 text-lg">
                    {feature.description}
                  </p>
                  <ul className="space-y-2">
                    {feature.highlights.map((highlight) => (
                      <li key={highlight} className="flex items-center gap-2 text-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex-1">
                  <div className="aspect-video rounded-2xl bg-gradient-card border border-border shadow-glow flex items-center justify-center">
                    <feature.icon className="w-20 h-20 text-primary/30" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Features Grid */}
          <div className="mb-24">
            <h2 className="text-2xl font-bold text-foreground text-center mb-12">
              And so much more...
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {additionalFeatures.map((feature) => (
                <div
                  key={feature.title}
                  className="p-6 rounded-xl bg-card border border-border hover:border-primary/50 transition-all duration-300"
                >
                  <feature.icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Ready to get started?
            </h2>
            <p className="text-muted-foreground mb-8">
              Try FlowSync free for 14 days. No credit card required.
            </p>
            <Button variant="hero" size="lg" asChild>
              <Link to="/signup">
                Start Free Trial
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
