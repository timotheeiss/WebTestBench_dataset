import { useState } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { plans, BillingPeriod, billingPeriodLabels, billingPeriodMonths, calculateSavings, getMonthlyEquivalent } from '@/data/plans';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Navbar } from '@/components/Navbar';
import { CreditCard, Lock, Check, Loader2, ArrowLeft } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function Checkout() {
  const { user, subscribe } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as { planId?: string; billingPeriod?: BillingPeriod } | null;
  const planId = state?.planId;
  const billingPeriod: BillingPeriod = state?.billingPeriod || 'monthly';

  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiry: '',
    cvc: '',
    name: '',
  });

  const plan = plans.find((p) => p.id === planId);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!plan || plan.id === 'free') {
    return <Navigate to="/pricing" replace />;
  }

  const price = plan.pricing[billingPeriod];
  const savings = calculateSavings(plan, billingPeriod);
  const monthlyEquivalent = getMonthlyEquivalent(plan, billingPeriod);
  const periodMonths = billingPeriodMonths[billingPeriod];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.cardNumber || !formData.expiry || !formData.cvc || !formData.name) {
      toast({
        title: 'Error',
        description: 'Please fill in all payment details.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      await subscribe(plan.id, billingPeriod);
      toast({
        title: 'Success!',
        description: `You're now subscribed to the ${plan.name} plan.`,
      });
      navigate('/account');
    } catch (error) {
      toast({
        title: 'Payment failed',
        description: 'Please check your payment details and try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-32 pb-20 px-4">
        <div className="max-w-2xl mx-auto">
          <Button
            variant="ghost"
            className="mb-8"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Order Summary */}
            <div className="bg-card rounded-2xl border border-border shadow-card p-6 h-fit animate-slide-up">
              <h2 className="text-lg font-semibold text-foreground mb-4">Order Summary</h2>
              
              <div className="p-4 rounded-xl bg-secondary/50 mb-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-foreground">{plan.name} Plan</h3>
                    <p className="text-sm text-muted-foreground">
                      Billed {billingPeriodLabels[billingPeriod].toLowerCase()}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-bold text-foreground">${price}</span>
                    {savings > 0 && (
                      <span className="block text-xs text-primary">Save {savings}%</span>
                    )}
                  </div>
                </div>
                {billingPeriod !== 'monthly' && (
                  <p className="text-xs text-muted-foreground">
                    ${monthlyEquivalent}/mo equivalent • Billed every {periodMonths} months
                  </p>
                )}
              </div>

              <div className="space-y-2 mb-4">
                {plan.features.slice(0, 5).map((feature) => (
                  <div key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Check className="w-4 h-4 text-primary" />
                    {feature}
                  </div>
                ))}
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Total today</span>
                  <span className="text-2xl font-bold text-foreground">${price}</span>
                </div>
                {plan.id === 'pro' && (
                  <p className="text-xs text-primary mt-2">
                    Includes 14-day free trial
                  </p>
                )}
              </div>
            </div>

            {/* Payment Form */}
            <div className="bg-card rounded-2xl border border-border shadow-card p-6 animate-slide-up" style={{ animationDelay: '100ms' }}>
              <div className="flex items-center gap-2 mb-6">
                <Lock className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">Secure checkout</span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Cardholder Name</Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="cardNumber"
                      placeholder="4242 4242 4242 4242"
                      className="pl-10"
                      maxLength={19}
                      value={formData.cardNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, cardNumber: formatCardNumber(e.target.value) })
                      }
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiry">Expiry</Label>
                    <Input
                      id="expiry"
                      placeholder="MM/YY"
                      maxLength={5}
                      value={formData.expiry}
                      onChange={(e) =>
                        setFormData({ ...formData, expiry: formatExpiry(e.target.value) })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvc">CVC</Label>
                    <Input
                      id="cvc"
                      placeholder="123"
                      maxLength={4}
                      value={formData.cvc}
                      onChange={(e) =>
                        setFormData({ ...formData, cvc: e.target.value.replace(/\D/g, '') })
                      }
                    />
                  </div>
                </div>

                <Button type="submit" variant="hero" className="w-full" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Pay $${price}`
                  )}
                </Button>
              </form>

              <p className="mt-4 text-xs text-muted-foreground text-center">
                Your payment is secured with 256-bit SSL encryption.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
