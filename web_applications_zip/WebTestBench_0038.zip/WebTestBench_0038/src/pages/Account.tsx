import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { plans, BillingPeriod, billingPeriodLabels } from '@/data/plans';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  User,
  CreditCard,
  Calendar,
  AlertTriangle,
  Check,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function Account() {
  const { user, subscription, getCurrentPlan, changePlan, cancelSubscription, reactivateSubscription } = useAuth();
  const navigate = useNavigate();
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showChangePlanDialog, setShowChangePlanDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedNewPlan, setSelectedNewPlan] = useState<string | null>(null);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const currentPlan = getCurrentPlan();
  const currentBillingPeriod: BillingPeriod = subscription?.billingPeriod || 'monthly';
  const currentPrice = currentPlan?.pricing[currentBillingPeriod] || 0;

  const handleChangePlan = async () => {
    if (!selectedNewPlan) return;

    if (selectedNewPlan === 'enterprise') {
      toast({
        title: 'Contact Sales',
        description: 'Our team will reach out to discuss your enterprise needs.',
      });
      setShowChangePlanDialog(false);
      return;
    }

    if (selectedNewPlan !== 'free' && subscription?.planId === 'free') {
      setShowChangePlanDialog(false);
      navigate('/checkout', { state: { planId: selectedNewPlan, billingPeriod: currentBillingPeriod } });
      return;
    }

    setIsLoading(true);
    try {
      await changePlan(selectedNewPlan);
      toast({
        title: 'Plan updated!',
        description: `You've switched to the ${plans.find(p => p.id === selectedNewPlan)?.name} plan.`,
      });
      setShowChangePlanDialog(false);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to change plan. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    setIsLoading(true);
    try {
      await cancelSubscription();
      toast({
        title: 'Subscription cancelled',
        description: 'Your subscription will end at the current billing period.',
      });
      setShowCancelDialog(false);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to cancel subscription. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleReactivate = async () => {
    setIsLoading(true);
    try {
      await reactivateSubscription();
      toast({
        title: 'Subscription reactivated!',
        description: 'Your subscription will continue as normal.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to reactivate subscription.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getPeriodLabel = (period: BillingPeriod) => {
    return period === 'monthly' ? 'mo' : period === 'quarterly' ? 'qtr' : 'yr';
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-32 pb-20 px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-foreground mb-8">Account</h1>

          {/* Profile Section */}
          <div className="bg-card rounded-2xl border border-border shadow-card p-6 mb-6 animate-slide-up">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                <User className="w-7 h-7 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-semibold text-foreground">{user.name}</h2>
                <p className="text-muted-foreground">{user.email}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Member since {format(user.createdAt, 'MMMM yyyy')}
                </p>
              </div>
            </div>
          </div>

          {/* Subscription Section */}
          <div className="bg-card rounded-2xl border border-border shadow-card p-6 mb-6 animate-slide-up" style={{ animationDelay: '100ms' }}>
            <h2 className="text-lg font-semibold text-foreground mb-6">Subscription</h2>

            {subscription && currentPlan && (
              <>
                <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50 mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${
                      subscription.cancelAtPeriodEnd ? 'bg-destructive' : 'bg-success'
                    }`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-foreground">{currentPlan.name} Plan</span>
                        {subscription.status === 'trial' && (
                          <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                            Trial
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        ${currentPrice}/{getPeriodLabel(currentBillingPeriod)}
                        <span className="ml-2 text-xs">({billingPeriodLabels[currentBillingPeriod]})</span>
                      </p>
                    </div>
                  </div>
                  {currentPlan.id !== 'free' && (
                    <Button variant="outline" size="sm" onClick={() => setShowChangePlanDialog(true)}>
                      Change Plan
                    </Button>
                  )}
                </div>

                {subscription.cancelAtPeriodEnd && (
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/20 mb-6">
                    <AlertTriangle className="w-5 h-5 text-destructive" />
                    <div className="flex-1">
                      <p className="text-sm text-foreground">
                        Your subscription will end on {format(subscription.currentPeriodEnd, 'MMMM d, yyyy')}
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleReactivate} disabled={isLoading}>
                      Reactivate
                    </Button>
                  </div>
                )}

                {/* Billing Info */}
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Calendar className="w-5 h-5" />
                    <span className="text-sm">
                      {subscription.cancelAtPeriodEnd
                        ? `Access ends ${format(subscription.currentPeriodEnd, 'MMMM d, yyyy')}`
                        : `Next billing date: ${format(subscription.currentPeriodEnd, 'MMMM d, yyyy')}`}
                    </span>
                  </div>
                  {currentPlan.id !== 'free' && !subscription.cancelAtPeriodEnd && (
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <CreditCard className="w-5 h-5" />
                      <span className="text-sm">•••• •••• •••• 4242</span>
                    </div>
                  )}
                </div>

                {/* Actions */}
                {currentPlan.id !== 'free' && !subscription.cancelAtPeriodEnd && (
                  <div className="mt-6 pt-6 border-t border-border">
                    <Button
                      variant="ghost"
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => setShowCancelDialog(true)}
                    >
                      Cancel subscription
                    </Button>
                  </div>
                )}

                {currentPlan.id === 'free' && (
                  <div className="mt-6">
                    <Button variant="hero" onClick={() => navigate('/pricing')}>
                      Upgrade to Pro
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Plan Features */}
          {currentPlan && (
            <div className="bg-card rounded-2xl border border-border shadow-card p-6 animate-slide-up" style={{ animationDelay: '200ms' }}>
              <h2 className="text-lg font-semibold text-foreground mb-4">Your Plan Features</h2>
              <ul className="grid md:grid-cols-2 gap-3">
                {currentPlan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Check className="w-4 h-4 text-primary" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </main>

      {/* Cancel Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>Cancel subscription?</DialogTitle>
            <DialogDescription>
              Your subscription will remain active until {subscription && format(subscription.currentPeriodEnd, 'MMMM d, yyyy')}. 
              After that, you'll be downgraded to the Free plan.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowCancelDialog(false)}>
              Keep subscription
            </Button>
            <Button variant="destructive" onClick={handleCancelSubscription} disabled={isLoading}>
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Cancel subscription'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Plan Dialog */}
      <Dialog open={showChangePlanDialog} onOpenChange={setShowChangePlanDialog}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle>Change your plan</DialogTitle>
            <DialogDescription>
              Select a new plan for your account.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-3 py-4">
            {plans.map((plan) => {
              const planPrice = plan.pricing[currentBillingPeriod];
              return (
                <button
                  key={plan.id}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    selectedNewPlan === plan.id
                      ? 'border-primary bg-primary/10'
                      : plan.id === subscription?.planId
                      ? 'border-border bg-secondary/30 opacity-50 cursor-not-allowed'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => plan.id !== subscription?.planId && setSelectedNewPlan(plan.id)}
                  disabled={plan.id === subscription?.planId}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-semibold text-foreground">{plan.name}</span>
                      {plan.id === subscription?.planId && (
                        <span className="ml-2 text-xs text-muted-foreground">(current)</span>
                      )}
                    </div>
                    <span className="font-semibold text-foreground">
                      ${planPrice}/{getPeriodLabel(currentBillingPeriod)}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowChangePlanDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="hero"
              onClick={handleChangePlan}
              disabled={!selectedNewPlan || isLoading}
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirm change'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
