import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Plan, plans, BillingPeriod, billingPeriodMonths } from '@/data/plans';

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface Subscription {
  planId: string;
  billingPeriod: BillingPeriod;
  status: 'active' | 'cancelled' | 'trial';
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
}

interface AuthContextType {
  user: User | null;
  subscription: Subscription | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  subscribe: (planId: string, billingPeriod?: BillingPeriod) => Promise<void>;
  changePlan: (planId: string) => Promise<void>;
  cancelSubscription: () => Promise<void>;
  reactivateSubscription: () => Promise<void>;
  getCurrentPlan: () => Plan | undefined;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = 'flowsync_auth';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const data = JSON.parse(stored);
        setUser({
          ...data.user,
          createdAt: new Date(data.user.createdAt),
        });
        if (data.subscription) {
          setSubscription({
            ...data.subscription,
            billingPeriod: data.subscription.billingPeriod || 'monthly',
            currentPeriodStart: new Date(data.subscription.currentPeriodStart),
            currentPeriodEnd: new Date(data.subscription.currentPeriodEnd),
          });
        }
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setIsLoading(false);
  }, []);

  const saveToStorage = (userData: User | null, subData: Subscription | null) => {
    if (userData) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ user: userData, subscription: subData }));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const login = async (email: string, password: string) => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name: email.split('@')[0],
      createdAt: new Date(),
    };
    
    setUser(newUser);
    saveToStorage(newUser, subscription);
  };

  const signup = async (name: string, email: string, password: string) => {
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name,
      createdAt: new Date(),
    };
    
    // New users start with free plan
    const freeSub: Subscription = {
      planId: 'free',
      billingPeriod: 'monthly',
      status: 'active',
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      cancelAtPeriodEnd: false,
    };
    
    setUser(newUser);
    setSubscription(freeSub);
    saveToStorage(newUser, freeSub);
  };

  const logout = () => {
    setUser(null);
    setSubscription(null);
    saveToStorage(null, null);
  };

  const subscribe = async (planId: string, billingPeriod: BillingPeriod = 'monthly') => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    const periodDays = billingPeriodMonths[billingPeriod] * 30;
    
    const newSub: Subscription = {
      planId,
      billingPeriod,
      status: planId === 'pro' ? 'trial' : 'active',
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + periodDays * 24 * 60 * 60 * 1000),
      cancelAtPeriodEnd: false,
    };
    
    setSubscription(newSub);
    saveToStorage(user, newSub);
  };

  const changePlan = async (planId: string) => {
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    const newSub: Subscription = {
      ...subscription!,
      planId,
      status: 'active',
      cancelAtPeriodEnd: false,
    };
    
    setSubscription(newSub);
    saveToStorage(user, newSub);
  };

  const cancelSubscription = async () => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    const updatedSub: Subscription = {
      ...subscription!,
      cancelAtPeriodEnd: true,
    };
    
    setSubscription(updatedSub);
    saveToStorage(user, updatedSub);
  };

  const reactivateSubscription = async () => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    const updatedSub: Subscription = {
      ...subscription!,
      cancelAtPeriodEnd: false,
    };
    
    setSubscription(updatedSub);
    saveToStorage(user, updatedSub);
  };

  const getCurrentPlan = () => {
    if (!subscription) return undefined;
    return plans.find((p) => p.id === subscription.planId);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        subscription,
        isLoading,
        login,
        signup,
        logout,
        subscribe,
        changePlan,
        cancelSubscription,
        reactivateSubscription,
        getCurrentPlan,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
