import { Check } from 'lucide-react';
import { Plan, BillingPeriod, calculateSavings, getMonthlyEquivalent, billingPeriodMonths } from '@/data/plans';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PricingCardProps {
  plan: Plan;
  billingPeriod: BillingPeriod;
  onSelect: (planId: string) => void;
  isCurrentPlan?: boolean;
  isLoading?: boolean;
}

export function PricingCard({ plan, billingPeriod, onSelect, isCurrentPlan, isLoading }: PricingCardProps) {
  const price = plan.pricing[billingPeriod];
  const savings = calculateSavings(plan, billingPeriod);
  const monthlyEquivalent = getMonthlyEquivalent(plan, billingPeriod);
  const periodMonths = billingPeriodMonths[billingPeriod];

  return (
    <div
      className={cn(
        'relative rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1',
        plan.popular
          ? 'bg-gradient-card border-2 border-primary shadow-glow'
          : 'bg-card border border-border shadow-card'
      )}
    >
      {plan.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="bg-gradient-primary text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full">
            Most Popular
          </span>
        </div>
      )}

      {savings > 0 && (
        <div className="absolute -top-3 right-4">
          <span className="bg-accent text-accent-foreground text-xs font-semibold px-3 py-1 rounded-full">
            Save {savings}%
          </span>
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-xl font-bold text-foreground mb-2">{plan.name}</h3>
        <p className="text-sm text-muted-foreground">{plan.description}</p>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-bold text-foreground">${price}</span>
          <span className="text-muted-foreground">
            /{billingPeriod === 'monthly' ? 'mo' : billingPeriod === 'quarterly' ? 'qtr' : 'yr'}
          </span>
        </div>
        {billingPeriod !== 'monthly' && price > 0 && (
          <p className="text-sm text-muted-foreground mt-1">
            ${monthlyEquivalent}/mo equivalent
          </p>
        )}
        {billingPeriod !== 'monthly' && price > 0 && (
          <p className="text-xs text-primary mt-1">
            Billed ${price} every {periodMonths} months
          </p>
        )}
      </div>

      <Button
        variant={plan.popular ? 'hero' : 'outline'}
        className="w-full mb-6"
        onClick={() => onSelect(plan.id)}
        disabled={isCurrentPlan || isLoading}
      >
        {isLoading ? 'Processing...' : isCurrentPlan ? 'Current Plan' : plan.cta}
      </Button>

      <ul className="space-y-3">
        {plan.features.map((feature) => (
          <li key={feature} className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Check className="w-3 h-3 text-primary" />
            </div>
            <span className="text-sm text-muted-foreground">{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
