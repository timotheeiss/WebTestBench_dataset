import { Check, X } from 'lucide-react';
import { featureComparison } from '@/data/plans';

export function FeatureComparisonTable() {
  const renderValue = (value: boolean | string) => {
    if (typeof value === 'boolean') {
      return value ? (
        <Check className="w-5 h-5 text-primary mx-auto" />
      ) : (
        <X className="w-5 h-5 text-muted-foreground/40 mx-auto" />
      );
    }
    return <span className="text-sm text-foreground">{value}</span>;
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-4 px-4 text-muted-foreground font-medium">Feature</th>
            <th className="text-center py-4 px-4 text-foreground font-semibold">Free</th>
            <th className="text-center py-4 px-4">
              <span className="text-gradient font-semibold">Pro</span>
            </th>
            <th className="text-center py-4 px-4 text-foreground font-semibold">Enterprise</th>
          </tr>
        </thead>
        <tbody>
          {featureComparison.map((feature, index) => (
            <tr
              key={feature.name}
              className={index % 2 === 0 ? 'bg-secondary/20' : ''}
            >
              <td className="py-4 px-4 text-sm text-foreground">{feature.name}</td>
              <td className="py-4 px-4 text-center">{renderValue(feature.free)}</td>
              <td className="py-4 px-4 text-center">{renderValue(feature.pro)}</td>
              <td className="py-4 px-4 text-center">{renderValue(feature.enterprise)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
