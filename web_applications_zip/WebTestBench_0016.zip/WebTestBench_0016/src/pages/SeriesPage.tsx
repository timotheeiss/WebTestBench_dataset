import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, BookOpen } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { PostCard } from '@/components/PostCard';
import { Button } from '@/components/ui/button';
import { posts, series } from '@/data/posts';

const SeriesPage = () => {
  const { seriesId } = useParams<{ seriesId: string }>();
  const currentSeries = series.find((s) => s.id === seriesId);
  const seriesPosts = posts
    .filter((post) => post.series === seriesId)
    .sort((a, b) => new Date(a.publishedAt).getTime() - new Date(b.publishedAt).getTime());

  if (!currentSeries) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-display text-4xl font-semibold mb-4">Series Not Found</h1>
            <p className="text-muted-foreground mb-6">This series doesn't exist.</p>
            <Link to="/series">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                View All Series
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero */}
        <section className="hero-gradient py-16">
          <div className="container mx-auto px-4">
            <Link
              to="/series"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              All series
            </Link>

            <div className="max-w-2xl">
              <div className="flex items-center gap-2 text-primary mb-4">
                <BookOpen className="h-6 w-6" />
                <span className="font-medium">Series • {seriesPosts.length} articles</span>
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-semibold mb-4">
                {currentSeries.name}
              </h1>
              <p className="text-lg text-muted-foreground">
                {currentSeries.description}
              </p>
            </div>
          </div>
        </section>

        {/* Posts List */}
        <section className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            {seriesPosts.length === 0 ? (
              <p className="text-center text-muted-foreground py-12">
                No articles in this series yet. Check back soon!
              </p>
            ) : (
              <div className="space-y-6">
                {seriesPosts.map((post, index) => (
                  <div key={post.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-display font-semibold">
                        {index + 1}
                      </div>
                      {index < seriesPosts.length - 1 && (
                        <div className="w-0.5 flex-1 bg-border mt-2" />
                      )}
                    </div>
                    <div className="flex-1 pb-6">
                      <PostCard post={post} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default SeriesPage;