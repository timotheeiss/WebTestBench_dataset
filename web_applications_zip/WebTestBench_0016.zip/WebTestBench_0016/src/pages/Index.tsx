import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { PostCard } from '@/components/PostCard';
import { CategorySection } from '@/components/CategorySection';
import { SeriesSection } from '@/components/SeriesSection';
import { TagCloud } from '@/components/TagCloud';
import { posts } from '@/data/posts';

const Index = () => {
  const featuredPosts = posts.filter((post) => post.featured);
  const recentPosts = posts
    .slice()
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
    .filter((post) => !post.featured)
    .slice(0, 6);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <section className="hero-gradient py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-semibold mb-4 animate-fade-in-up">
                Stories from the <span className="text-gradient">Heart</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                Travel adventures, kitchen experiments, and lessons learned along the way.
              </p>
            </div>
            <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              {featuredPosts.map((post) => (
                <PostCard key={post.id} post={post} featured />
              ))}
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4">
          <CategorySection />
          <section className="py-12">
            <h2 className="font-display text-2xl font-semibold mb-6">Recent Stories</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </section>
          <SeriesSection />
          <TagCloud />
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Index;