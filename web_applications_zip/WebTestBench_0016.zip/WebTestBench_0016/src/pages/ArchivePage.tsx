import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Calendar } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { posts } from '@/data/posts';
import { format, parseISO } from 'date-fns';

const ArchivePage = () => {
  // Group posts by year and month
  const archive = useMemo(() => {
    const grouped: Record<string, Record<string, typeof posts>> = {};

    posts.forEach((post) => {
      const date = parseISO(post.publishedAt);
      const year = format(date, 'yyyy');
      const month = format(date, 'MMMM');

      if (!grouped[year]) grouped[year] = {};
      if (!grouped[year][month]) grouped[year][month] = [];
      grouped[year][month].push(post);
    });

    // Sort by date within each month
    Object.keys(grouped).forEach((year) => {
      Object.keys(grouped[year]).forEach((month) => {
        grouped[year][month].sort(
          (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
        );
      });
    });

    return grouped;
  }, []);

  const sortedYears = Object.keys(archive).sort((a, b) => parseInt(b) - parseInt(a));

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero */}
        <section className="hero-gradient py-16">
          <div className="container mx-auto px-4">
            <Link
              to="/"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to home
            </Link>

            <div className="max-w-2xl">
              <div className="flex items-center gap-2 text-primary mb-4">
                <Calendar className="h-6 w-6" />
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-semibold mb-4">
                Archive
              </h1>
              <p className="text-lg text-muted-foreground">
                Browse all {posts.length} articles by date.
              </p>
            </div>
          </div>
        </section>

        {/* Archive Content */}
        <section className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto space-y-12">
            {sortedYears.map((year) => (
              <div key={year}>
                <h2 className="font-display text-3xl font-semibold mb-8 text-gradient">
                  {year}
                </h2>
                <div className="space-y-8">
                  {Object.entries(archive[year])
                    .sort((a, b) => {
                      const monthOrder = [
                        'December', 'November', 'October', 'September',
                        'August', 'July', 'June', 'May',
                        'April', 'March', 'February', 'January'
                      ];
                      return monthOrder.indexOf(a[0]) - monthOrder.indexOf(b[0]);
                    })
                    .map(([month, monthPosts]) => (
                      <div key={month}>
                        <h3 className="font-display text-xl font-medium text-muted-foreground mb-4">
                          {month}
                        </h3>
                        <div className="space-y-4">
                          {monthPosts.map((post) => (
                            <Link
                              key={post.id}
                              to={`/post/${post.slug}`}
                              className="group flex items-start gap-4 p-4 rounded-lg hover:bg-card transition-colors"
                            >
                              <div className="flex-shrink-0 w-16 text-sm text-muted-foreground">
                                {format(parseISO(post.publishedAt), 'MMM d')}
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium group-hover:text-primary transition-colors line-clamp-1">
                                  {post.title}
                                </h4>
                                <p className="text-sm text-muted-foreground line-clamp-1 mt-1">
                                  {post.excerpt}
                                </p>
                              </div>
                              <div className="flex-shrink-0 text-sm text-muted-foreground">
                                {post.readTime} min
                              </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ArchivePage;