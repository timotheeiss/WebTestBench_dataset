import { Link } from 'react-router-dom';
import { ArrowLeft, BookOpen } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { series, posts } from '@/data/posts';

const AllSeriesPage = () => {
  const getSeriesPostCount = (seriesId: string) => {
    return posts.filter((post) => post.series === seriesId).length;
  };

  const getSeriesPreviewImage = (seriesId: string) => {
    const seriesPost = posts.find((post) => post.series === seriesId);
    return seriesPost?.coverImage;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero */}
        <section className="hero-gradient py-16">
          <div className="container mx-auto px-4">
            <Link
              to="/"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to home
            </Link>

            <div className="max-w-2xl">
              <div className="flex items-center gap-2 text-primary mb-4">
                <BookOpen className="h-6 w-6" />
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-semibold mb-4">
                All Series
              </h1>
              <p className="text-lg text-muted-foreground">
                Deep dives and multi-part explorations on topics I love.
              </p>
            </div>
          </div>
        </section>

        {/* Series Grid */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {series.map((s) => (
              <Link
                key={s.id}
                to={`/series/${s.id}`}
                className="group overflow-hidden rounded-xl bg-card shadow-card transition-card hover:shadow-card-hover"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={getSeriesPreviewImage(s.id)}
                    alt={s.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="inline-flex items-center gap-1 text-sm text-primary-foreground/80">
                      <BookOpen className="h-4 w-4" />
                      {getSeriesPostCount(s.id)} articles
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h2 className="font-display text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {s.name}
                  </h2>
                  <p className="text-muted-foreground text-sm">
                    {s.description}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default AllSeriesPage;