import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, User, Share2 } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { LikeButton } from '@/components/LikeButton';
import { Comments } from '@/components/Comments';
import { RelatedPosts } from '@/components/RelatedPosts';
import { posts, categories, series } from '@/data/posts';
import { format } from 'date-fns';
import { toast } from '@/hooks/use-toast';

const PostPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const post = posts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-display text-4xl font-semibold mb-4">Post Not Found</h1>
            <p className="text-muted-foreground mb-6">The article you're looking for doesn't exist.</p>
            <Link to="/">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const category = categories.find((c) => c.id === post.category);
  const postSeries = series.find((s) => s.id === post.series);

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: post.title,
        text: post.excerpt,
        url: window.location.href,
      });
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: 'Link copied!',
        description: 'Share this article with your friends.',
      });
    }
  };

  // Convert markdown-like content to HTML-like structure
  const renderContent = (content: string) => {
    return content.split('\n\n').map((paragraph, index) => {
      // Headers
      if (paragraph.startsWith('## ')) {
        return <h2 key={index}>{paragraph.replace('## ', '')}</h2>;
      }
      if (paragraph.startsWith('### ')) {
        return <h3 key={index}>{paragraph.replace('### ', '')}</h3>;
      }
      // Blockquotes
      if (paragraph.startsWith('> ')) {
        return <blockquote key={index}>{paragraph.replace('> ', '')}</blockquote>;
      }
      // Lists
      if (paragraph.includes('\n- ') || paragraph.startsWith('- ')) {
        const items = paragraph.split('\n').filter(line => line.startsWith('- '));
        return (
          <ul key={index}>
            {items.map((item, i) => (
              <li key={i}>{item.replace('- ', '').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/<strong>(.*?)<\/strong>/g, (_, text) => text)}</li>
            ))}
          </ul>
        );
      }
      if (paragraph.match(/^\d+\./)) {
        const items = paragraph.split('\n').filter(line => line.match(/^\d+\./));
        return (
          <ol key={index}>
            {items.map((item, i) => (
              <li key={i}>{item.replace(/^\d+\.\s*/, '')}</li>
            ))}
          </ol>
        );
      }
      // Regular paragraphs
      return <p key={index}>{paragraph}</p>;
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Image */}
        <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
          <img
            src={post.coverImage}
            alt={post.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>

        <article className="container mx-auto px-4 -mt-32 relative">
          <div className="max-w-3xl mx-auto">
            {/* Meta */}
            <div className="mb-6 animate-fade-in">
              <Link
                to="/"
                className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to home
              </Link>

              <div className="flex flex-wrap items-center gap-2 mb-4">
                <Link to={`/category/${post.category}`}>
                  <Badge variant="secondary" className="bg-primary text-primary-foreground">
                    {category?.icon} {category?.name}
                  </Badge>
                </Link>
                {postSeries && (
                  <Link to={`/series/${post.series}`}>
                    <Badge variant="outline" className="hover:bg-primary/10">
                      Part of: {postSeries.name}
                    </Badge>
                  </Link>
                )}
              </div>
            </div>

            {/* Title */}
            <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold mb-6 animate-fade-in-up">
              {post.title}
            </h1>

            {/* Author & Meta */}
            <div className="flex flex-wrap items-center gap-4 mb-8 pb-8 border-b border-border animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center gap-3">
                <img
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center gap-1 font-medium">
                    <User className="h-4 w-4 text-muted-foreground" />
                    {post.author.name}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {format(new Date(post.publishedAt), 'MMMM d, yyyy')}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {post.readTime} min read
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="article-content mb-8 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              {renderContent(post.content)}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-8">
              {post.tags.map((tag) => (
                <Link key={tag} to={`/search?tag=${encodeURIComponent(tag)}`}>
                  <Badge variant="outline" className="hover:bg-primary/10 hover:border-primary">
                    #{tag}
                  </Badge>
                </Link>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4 py-6 border-t border-b border-border">
              <LikeButton initialLikes={post.likes} postId={post.id} />
              <Button variant="outline" onClick={handleShare}>
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>

            {/* Comments */}
            <Comments postId={post.id} />

            {/* Related Posts */}
            <RelatedPosts currentPost={post} />
          </div>
        </article>
      </main>

      <Footer />
    </div>
  );
};

export default PostPage;