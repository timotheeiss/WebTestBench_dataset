export type Category = 'travel' | 'recipes' | 'self-improvement';

export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: Category;
  tags: string[];
  series?: string;
  author: {
    name: string;
    avatar: string;
  };
  publishedAt: string;
  readTime: number;
  featured: boolean;
  likes: number;
}

export interface Comment {
  id: string;
  postId: string;
  author: string;
  content: string;
  createdAt: string;
}

export const categories: { id: Category; name: string; description: string; icon: string }[] = [
  {
    id: 'travel',
    name: 'Travel Stories',
    description: 'Adventures from around the world',
    icon: '✈️',
  },
  {
    id: 'recipes',
    name: 'Recipes',
    description: 'Delicious dishes from my kitchen',
    icon: '🍳',
  },
  {
    id: 'self-improvement',
    name: 'Self Improvement',
    description: 'Tips for a better life',
    icon: '🌱',
  },
];

export const series: { id: string; name: string; description: string }[] = [
  {
    id: 'southeast-asia-adventure',
    name: 'Southeast Asia Adventure',
    description: 'A month-long journey through Thailand, Vietnam, and Cambodia',
  },
  {
    id: 'italian-kitchen',
    name: 'Italian Kitchen Essentials',
    description: 'Master the fundamentals of Italian cooking',
  },
  {
    id: 'morning-rituals',
    name: 'Morning Rituals',
    description: 'Building a morning routine that transforms your day',
  },
];

export const posts: Post[] = [
  {
    id: '1',
    title: 'Sunrise Over Angkor Wat: A Journey Through Time',
    slug: 'sunrise-over-angkor-wat',
    excerpt: 'Waking up at 4 AM seemed impossible until I witnessed the most breathtaking sunrise of my life over the ancient temples of Cambodia.',
    content: `There's something magical about standing in complete darkness, surrounded by strangers from every corner of the world, all waiting for the same moment. The air was thick with anticipation and the sweet scent of lotus flowers from the nearby pond.

## The Early Morning Rush

Getting to Angkor Wat before sunrise requires dedication. My alarm went off at 3:45 AM, and despite every fiber of my being wanting to stay in the comfortable hotel bed, I forced myself up. The tuk-tuk driver was already waiting outside, his weathered face breaking into a knowing smile.

"First time?" he asked. I nodded, clutching my camera bag.

The drive through Siem Reap's empty streets felt surreal. No tourists, no vendors, just the occasional stray dog and the distant sound of monks beginning their morning prayers.

## Finding the Perfect Spot

We arrived at the temple complex around 4:30 AM. Even at this hour, crowds were forming near the famous reflecting pools. I wandered further, past the main group, finding a quiet spot near a crumbling stone lion.

> "In Cambodia, we say the sunrise at Angkor is like watching the gods wake up."

The sky began its transformation slowly at first—deep purple giving way to hints of orange and pink. Then, as if someone had turned on a cosmic light switch, the sun crested the temple's iconic towers.

## The Magic Moment

What struck me most wasn't just the visual spectacle—though it was undeniably stunning. It was the collective gasp from hundreds of people, the simultaneous clicking of cameras, the profound silence that followed.

For those fifteen minutes, watching the ancient stones turn from grey to gold, I understood why millions make this pilgrimage every year. It's not just about photography or checking off a bucket list item. It's about connecting with something ancient and eternal.

### Tips for Your Visit

1. Book tickets the day before at the official ticket center
2. Bring a flashlight—it's genuinely dark before sunrise
3. Dress respectfully (shoulders and knees covered)
4. Stay after the crowds leave; the temples are peaceful around 7 AM

The temples of Angkor have stood for nearly a thousand years, witnessing countless sunrises. Being there, even for just one, felt like being part of something much larger than myself.`,
    coverImage: 'https://images.unsplash.com/photo-1508804185872-d7badad00f7d?w=1200&h=800&fit=crop',
    category: 'travel',
    tags: ['Cambodia', 'Temples', 'Photography', 'Southeast Asia'],
    series: 'southeast-asia-adventure',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-03-15',
    readTime: 8,
    featured: true,
    likes: 234,
  },
  {
    id: '2',
    title: 'The Perfect Homemade Pasta: A Labor of Love',
    slug: 'perfect-homemade-pasta',
    excerpt: 'After years of trial and error, I finally cracked the code to restaurant-quality fresh pasta at home. Here\'s everything I learned.',
    content: `There's a reason Italian nonnas have been making pasta by hand for generations—nothing compares to the silky, tender texture of fresh pasta. After countless failed attempts and flour-covered kitchens, I'm sharing the technique that finally worked.

## The Foundation: Ingredients

Fresh pasta requires just four ingredients, but quality matters:

- **00 flour** (400g): This finely ground Italian flour creates the silkiest texture
- **Eggs** (4 large): Room temperature, ideally from pasture-raised hens
- **Olive oil** (1 tbsp): Extra virgin, for richness
- **Salt** (1 tsp): Fine sea salt

## The Technique

Making pasta is as much about feel as it is about following steps. Here's the process that transformed my pasta game:

### Step 1: The Well Method

Create a mound of flour on a clean wooden surface (I use a large cutting board). Make a deep well in the center—think volcano crater. Crack your eggs into the well and add the oil and salt.

### Step 2: The Slow Incorporation

Using a fork, begin whisking the eggs while slowly incorporating flour from the inner walls of the well. This is where patience pays off. Rush it, and you'll have a scrambled mess.

### Step 3: The Knead

Once a shaggy dough forms, switch to kneading with your hands. This takes 8-10 minutes—put on some music and enjoy the process. The dough should become smooth and spring back when poked.

> "Good pasta dough should feel like your earlobe—smooth and slightly elastic."

### Step 4: The Rest

Wrap the dough in plastic and let it rest for 30 minutes. This allows the gluten to relax, making rolling easier.

## Rolling and Cutting

Whether you use a machine or a rolling pin, the key is gradual thinning. Start at the widest setting and work down. For fettuccine, I stop at setting 5 on my Atlas machine.

### Common Mistakes to Avoid

1. Adding flour to wet dough too quickly
2. Not resting the dough long enough
3. Rolling pasta too thin for the sauce you're pairing it with
4. Cooking in insufficient water

## The Payoff

Fresh pasta cooks in just 2-3 minutes. Toss it with browned butter and sage, or a simple tomato sauce, and you'll understand why this extra effort is worthwhile.

The flour on your countertop, the ache in your arms from kneading, the anticipation as the pot boils—these are the moments that make cooking more than just preparing food. It's a meditation, a tradition, a gift you give yourself and those you love.`,
    coverImage: 'https://images.unsplash.com/photo-1556761223-4c4282c73f77?w=1200&h=800&fit=crop',
    category: 'recipes',
    tags: ['Italian', 'Pasta', 'From Scratch', 'Comfort Food'],
    series: 'italian-kitchen',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-03-10',
    readTime: 12,
    featured: true,
    likes: 456,
  },
  {
    id: '3',
    title: 'The 5 AM Club: My 30-Day Experiment',
    slug: '5am-club-experiment',
    excerpt: 'I committed to waking up at 5 AM for a month. Here\'s what happened to my productivity, creativity, and sanity.',
    content: `Like many people, I'd read about successful CEOs and their ungodly wake-up times. Tim Cook rises at 3:45 AM. Michelle Obama starts at 4:30 AM. I could barely manage 7:30 AM. So I decided to conduct an experiment.

## The Setup

The rules were simple:
- Wake up at 5:00 AM every day for 30 days
- No snooze button
- Use the extra time for personal development (reading, exercise, writing)
- Be in bed by 9:30 PM

## Week One: The Struggle

I won't sugarcoat it—the first week was brutal. My body had spent 30 years expecting to wake up around 7 AM. Suddenly demanding it perform two hours earlier felt like asking a fish to climb a tree.

**Day 1:** Alarm goes off. I stare at the ceiling in disbelief that humans actually do this voluntarily.

**Day 3:** Fell asleep at my desk at 2 PM. Drank more coffee than medically advisable.

**Day 5:** Accidentally went to bed at 8 PM. Woke up at 4 AM feeling like a superhero.

## Week Two: The Adjustment

Something shifted in week two. My body started cooperating. I began waking up 5 minutes before my alarm, which felt like a small miracle.

> "The morning hour has gold in its mouth." — Benjamin Franklin

I started a morning routine:
1. 5:00 - Wake, hydrate, light stretching
2. 5:20 - Meditation (started with 10 minutes)
3. 5:35 - Journal writing
4. 6:00 - Exercise
5. 6:45 - Shower and prepare for the day

## Week Three: The Revelation

By week three, I noticed changes beyond just my schedule:

- **Creativity peaked in early morning:** My best writing happened before 7 AM
- **Decision fatigue decreased:** Making choices early meant fewer mental battles later
- **Evenings became sacred:** No more "I'll do it tomorrow"—tomorrow started at 5 AM

## Week Four: The New Normal

The final week felt natural. I actually looked forward to mornings. The quiet hours before the world wakes up became my favorite part of the day.

### What I Accomplished

In those 60 extra hours (2 hours × 30 days):
- Read 4 books
- Wrote 15,000 words
- Established a consistent exercise habit
- Finished a online course I'd been putting off for months

## Would I Recommend It?

Yes, with caveats. The 5 AM lifestyle isn't for everyone. If you're a natural night owl, forcing an early wake-up might work against your biology. But if you've always wanted more hours in your day, it's worth trying.

The early morning belongs to you—no emails, no notifications, no obligations. It's a space for becoming the person you want to be, one quiet hour at a time.`,
    coverImage: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=1200&h=800&fit=crop',
    category: 'self-improvement',
    tags: ['Productivity', 'Morning Routine', 'Habits', 'Lifestyle'],
    series: 'morning-rituals',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-03-05',
    readTime: 10,
    featured: false,
    likes: 189,
  },
  {
    id: '4',
    title: 'Street Food Adventures in Bangkok',
    slug: 'street-food-bangkok',
    excerpt: 'From midnight pad thai to mysterious skewers, my guide to navigating Bangkok\'s legendary street food scene.',
    content: `Bangkok's street food isn't just about eating—it's about surrendering to chaos and trusting that the tiny plastic stool, the wok flames licking the night air, and the grandmother who's been cooking since before you were born will deliver something extraordinary.

## Finding the Best Stalls

The tourist areas around Khao San Road have their charm, but the real magic happens in the neighborhoods where locals eat. Here are my favorite spots:

### Yaowarat (Chinatown)

After dark, this street transforms into one of the world's greatest open-air food courts. Must-tries:
- Charcoal-grilled seafood at T&K Seafood
- Rolled noodles with pork at Nai Ek
- The legendary crab omelets at Lek & Rut

### Victory Monument

Office workers flood this area for lunch, which means fast turnover and incredibly fresh food. The boat noodle alley is essential—each bowl costs about 15 baht (less than 50 cents), but you'll need several to feel satisfied.

## The Rules of Street Food

After weeks of eating from carts and stalls, I developed some guidelines:

1. **Follow the crowds:** If locals are lining up, join them
2. **Check the turnover:** Busy stalls = fresh ingredients
3. **Watch for cleanliness:** Not sterile, but organized
4. **Start slow:** Let your stomach adjust before diving deep

> "In Bangkok, the best restaurants have no walls."

## My Top 5 Dishes

After dozens of meals and one minor food-related incident (let's not discuss the mystery skewer), here are my absolute favorites:

### 1. Pad Krapao Moo Kai Dao
Holy basil pork with a crispy fried egg—the unofficial national dish. Order it "pet mak" (very spicy) for the authentic experience.

### 2. Som Tam
Green papaya salad that hits every note: sour, sweet, spicy, salty. The mortar and pestle version is always best.

### 3. Khao Man Gai
Deceptively simple chicken and rice that showcases the Thai genius for extracting maximum flavor from minimum ingredients.

### 4. Mango Sticky Rice
When mangoes are in season (March-May), this dessert becomes transcendent.

### 5. Boat Noodles
Rich, porky, slightly intense—these small bowls pack an enormous flavor punch.

## Practical Tips

- Carry small bills (20 and 50 baht notes)
- Learn basic Thai numbers for ordering
- Embrace the heat—both temperature and spice
- Bring tissues (napkins are rare)

Bangkok taught me that the best meals aren't always the fanciest. Sometimes they're served on a plastic plate, under fluorescent lights, surrounded by the beautiful chaos of a city that never stops eating.`,
    coverImage: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=1200&h=800&fit=crop',
    category: 'travel',
    tags: ['Thailand', 'Street Food', 'Bangkok', 'Southeast Asia'],
    series: 'southeast-asia-adventure',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-02-28',
    readTime: 9,
    featured: false,
    likes: 312,
  },
  {
    id: '5',
    title: 'Classic Tiramisu: No-Bake Italian Perfection',
    slug: 'classic-tiramisu',
    excerpt: 'This authentic tiramisu recipe uses traditional mascarpone and espresso for a dessert that rivals any Italian trattoria.',
    content: `Tiramisu means "pick me up" in Italian, and this coffee-soaked, creamy layered dessert truly delivers. After learning this recipe from a chef in Verona, I've made it for every special occasion since.

## Ingredients

**For the Mascarpone Cream:**
- 6 egg yolks
- 150g sugar
- 500g mascarpone cheese (room temperature)
- 300ml heavy cream

**For Assembly:**
- 400ml strong espresso (cooled)
- 2 tbsp Marsala wine (or rum)
- 200g savoiardi (ladyfinger cookies)
- Unsweetened cocoa powder

## The Secret to Great Tiramisu

The difference between good and extraordinary tiramisu comes down to three things:

1. **Quality mascarpone:** Don't substitute with cream cheese
2. **Proper coffee:** Use real espresso, not instant
3. **Resting time:** 24 hours minimum in the fridge

## Instructions

### Step 1: The Sabayon

Whisk egg yolks and sugar over a double boiler until pale and thick—about 10 minutes. The mixture should triple in volume and form ribbons when dropped from the whisk.

> "A proper sabayon takes patience. Rush it, and you'll taste the difference."

### Step 2: Incorporate Mascarpone

Let the sabayon cool slightly, then fold in mascarpone. Work gently to keep the air you've created.

### Step 3: Whip the Cream

In a separate bowl, whip heavy cream to soft peaks. Fold into the mascarpone mixture in three additions.

### Step 4: Prepare the Coffee Bath

Combine cooled espresso with Marsala. The liquid should be room temperature—hot coffee will dissolve the cookies, cold won't penetrate properly.

### Step 5: Layer

Working quickly:
1. Dip each ladyfinger for exactly 2 seconds per side
2. Arrange in a single layer in your dish
3. Spread half the cream mixture
4. Repeat for second layer
5. Finish with remaining cream

### Step 6: The Wait

Cover and refrigerate for at least 24 hours. I know it's difficult, but this resting period allows the flavors to meld and the texture to set properly.

## Serving

Dust generously with cocoa powder just before serving. The contrast of bitter cocoa against sweet cream is essential.

## Variations

- **Strawberry Tiramisu:** Replace coffee with strawberry puree
- **Chocolate Tiramisu:** Add melted chocolate to the cream
- **Pistachio Tiramisu:** Layer with pistachio cream

But honestly? Master the classic first. There's a reason it's endured for generations.`,
    coverImage: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=1200&h=800&fit=crop',
    category: 'recipes',
    tags: ['Italian', 'Dessert', 'No-Bake', 'Coffee'],
    series: 'italian-kitchen',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-02-20',
    readTime: 15,
    featured: false,
    likes: 287,
  },
  {
    id: '6',
    title: 'Digital Minimalism: Reclaiming My Attention',
    slug: 'digital-minimalism',
    excerpt: 'How I reduced my screen time by 70% and rediscovered the joy of boredom.',
    content: `My phone told me I was averaging 6 hours of screen time per day. Six hours. That's 42 hours a week—more than a full-time job—spent scrolling, tapping, and refreshing. Something had to change.

## The Wake-Up Call

It started innocently. I'd reach for my phone first thing in the morning, before my eyes fully focused. I'd check it during conversations, while walking, even in the bathroom. The device had become an extension of my hand.

But the real wake-up call came during a dinner with friends. Looking around the table, I realized everyone was on their phones. We were physically together but mentally elsewhere.

## The 30-Day Digital Declutter

Inspired by Cal Newport's "Digital Minimalism," I designed my own experiment:

### Week 1: The Audit

Before making changes, I tracked everything:
- Which apps consumed the most time
- When I reached for my phone
- What triggered the behavior

The results were illuminating. Social media accounted for 60% of my usage. I wasn't connecting; I was consuming.

### Week 2: The Purge

I removed all social apps from my phone. Not deleted the accounts—just removed the easy access. If I wanted to check Instagram, I had to use a computer browser.

> "The goal isn't to quit technology. It's to make technology serve your life, not consume it."

### Week 3: The Replacement

Empty time needs filling. I replaced scrolling with:
- Morning pages (handwritten journaling)
- Actual books (remember those?)
- Walking without podcasts
- Calling friends instead of texting

### Week 4: The Refinement

I reintroduced select tools with strict boundaries:
- Phone stays out of bedroom
- No screens before 8 AM or after 9 PM
- Social media limited to 30 minutes on Sundays

## What I Discovered

### Boredom is Valuable

We've lost the ability to be bored. But boredom is where creativity lives. My best ideas now come during boring moments I used to fill with scrolling.

### Relationships Improved

Without the crutch of texting, I started calling people. Those conversations were richer, deeper, and more satisfying.

### Focus Returned

My attention span, which had shrunk to goldfish levels, began recovering. I could read for an hour without checking my phone.

## The Numbers

After 30 days:
- Screen time: 6 hours → 1.8 hours (70% reduction)
- Books read: 0.5/month → 4/month
- Deep work sessions: 2/week → 5/week
- Anxiety levels: Noticeably lower

## Maintaining the Change

Six months later, I've held most of these boundaries. The phone is a tool again, not a compulsion. I still check email and messages, but on my schedule, not at the app's demand.

The irony isn't lost on me—you're reading this on a screen. Technology itself isn't the enemy. The enemy is unconscious use, the zombie scrolling that steals our most precious resource: attention.

Take back your attention. Your life is waiting.`,
    coverImage: 'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200&h=800&fit=crop',
    category: 'self-improvement',
    tags: ['Digital Wellness', 'Minimalism', 'Focus', 'Lifestyle'],
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-02-15',
    readTime: 11,
    featured: false,
    likes: 423,
  },
  {
    id: '7',
    title: 'Ha Long Bay by Kayak: Beyond the Tourist Trail',
    slug: 'ha-long-bay-kayak',
    excerpt: 'Escaping the cruise ship crowds to discover hidden lagoons and floating villages in Vietnam\'s iconic bay.',
    content: `Everyone visits Ha Long Bay. The limestone karsts rising from emerald waters are iconic, appearing in countless movies and travel brochures. But most tourists experience it from the deck of a crowded cruise ship. I wanted something different.

## Choosing a Different Path

Instead of the typical overnight cruise, I opted for a three-day kayaking expedition. It was harder, less comfortable, and infinitely more rewarding.

Our small group of eight met in Hai Phong and transferred to Cat Ba Island, the largest island in the bay. From there, we'd paddle through Lan Ha Bay—Ha Long's less-visited neighbor.

## Day One: Learning the Basics

The first morning was humbling. Kayaking looks easy until you're fighting a headwind with burning shoulders. Our guide, Minh, had been paddling these waters since childhood. He made it look effortless.

> "The bay teaches patience. Fight the water, and you lose. Move with it, and it takes you where you need to go."

By afternoon, my strokes improved. We reached our first hidden lagoon—a perfect circle of water surrounded by towering cliffs, accessible only through a narrow cave at low tide.

## Day Two: The Floating Village

The highlight was visiting Cua Van, one of the oldest floating villages in the bay. About 300 people live here, their homes bobbing gently on the water. Children paddled to school in tiny boats.

We stayed for lunch with a local family. The grandmother had never left the bay. Her entire world was this community of floating homes, fishing nets, and endless water.

### What We Learned

- Traditional fishing techniques still used daily
- How houses are built to withstand storms
- The impact of tourism on traditional lifestyles

## Day Three: The Secret Cave

Minh saved the best for last. After an hour of paddling through a maze of islands, we reached a hidden cave entrance. Inside, the ceiling soared 50 feet, covered in stalactites that sparkled in our headlamp beams.

In a small chamber at the back, Minh turned off all lights. Complete darkness. Complete silence. Just the drip of water and the sound of our breathing.

## Practical Information

**When to go:** September-November (dry season, calm waters)

**Fitness level:** Moderate—you'll paddle 4-6 hours daily

**What to bring:**
- Waterproof bags for electronics
- Sun protection (the glare is intense)
- Water shoes for cave exploration

**Cost:** Approximately $200-300 for a three-day guided expedition

## The Takeaway

Ha Long Bay's magic isn't found on cruise ship decks with buffet dinners. It's in the quiet moments—paddling through morning mist, sharing tea with fishing families, watching the sunset paint the karsts gold.

Travel slow. Paddle your own boat. The effort reveals what comfort conceals.`,
    coverImage: 'https://images.unsplash.com/photo-1528127269322-539801943592?w=1200&h=800&fit=crop',
    category: 'travel',
    tags: ['Vietnam', 'Kayaking', 'Adventure', 'Southeast Asia'],
    series: 'southeast-asia-adventure',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-02-10',
    readTime: 10,
    featured: false,
    likes: 198,
  },
  {
    id: '8',
    title: 'The Art of Journaling: Writing Your Way to Clarity',
    slug: 'art-of-journaling',
    excerpt: 'How a simple notebook became my therapist, planner, and creative playground.',
    content: `I've kept a journal for five years now. Not consistently—there are gaps of weeks, sometimes months. But the practice has become essential to how I process life, make decisions, and understand myself.

## Why Journal?

We think thousands of thoughts daily. Most vanish before we can examine them. Writing forces the mind to slow down, to articulate what's swirling in the background.

Benefits I've experienced:
- **Emotional processing:** Problems that seemed overwhelming became manageable once written
- **Pattern recognition:** Rereading entries reveals repeating themes and behaviors
- **Memory preservation:** Moments I'd have forgotten are captured forever
- **Decision clarity:** Writing pros and cons crystallizes choices

## Finding Your Format

There's no single correct way to journal. Over five years, I've experimented with many approaches:

### Morning Pages

Three pages of stream-of-consciousness writing first thing in the morning. No editing, no judgment. Just getting thoughts on paper before the day begins.

> "Morning pages don't have to be good. They just have to be done."

### Bullet Journaling

A structured approach combining task lists, habit tracking, and reflection. Great for productivity-focused periods, but sometimes too rigid for emotional processing.

### Gratitude Journaling

Three things you're grateful for each day. Simple but transformative when practiced consistently.

### Prompt-Based Journaling

Using questions to spark reflection:
- What am I avoiding?
- What would I do if I couldn't fail?
- What does my ideal day look like?

## My Current Practice

After years of experimentation, here's what works for me:

**Morning:** 10 minutes of free writing (half a page to a full page)

**Evening:** Brief notes on the day—what happened, how I felt, what I learned

**Weekly:** Longer reflection on patterns, goals, and intentions

**Monthly:** Review and highlights

## Overcoming Common Obstacles

### "I don't have time"

Start with five minutes. Set a timer. Write until it beeps. Five minutes is enough to make a difference.

### "I don't know what to write"

Start with the obvious: "I don't know what to write. The weather is grey. I'm feeling tired because..." And keep going. The interesting stuff emerges after the surface thoughts clear.

### "What if someone reads it?"

Keep your journal private. Lock it away if needed. You can't be honest if you're editing for an audience.

### "My handwriting is terrible"

Type instead. Or embrace terrible handwriting. It's for you, not a penmanship contest.

## The Compound Effect

One journal entry seems insignificant. But over months and years, those entries compound into something remarkable—a map of who you've been and who you're becoming.

Last month, I reread entries from three years ago. The person writing them felt like a stranger. The growth became visible only in retrospect.

Start today. Grab any notebook. Write one sentence about how you feel right now. That's it. You've begun.

The blank page isn't intimidating once you fill it with your thoughts. And those thoughts, examined and recorded, become the foundation for a more intentional life.`,
    coverImage: 'https://images.unsplash.com/photo-1517842645767-c639042777db?w=1200&h=800&fit=crop',
    category: 'self-improvement',
    tags: ['Journaling', 'Writing', 'Mindfulness', 'Self-Reflection'],
    series: 'morning-rituals',
    author: {
      name: 'Maya Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    publishedAt: '2024-01-25',
    readTime: 9,
    featured: false,
    likes: 345,
  },
];

export const initialComments: Comment[] = [
  {
    id: 'c1',
    postId: '1',
    author: 'TravelLover88',
    content: 'This brought back so many memories! I visited Angkor Wat last year and the sunrise was magical. Your tip about staying after the crowds leave is spot on.',
    createdAt: '2024-03-16',
  },
  {
    id: 'c2',
    postId: '1',
    author: 'PhotoJunkie',
    content: 'What camera settings did you use for the sunrise shots? Trying to plan my own trip!',
    createdAt: '2024-03-17',
  },
  {
    id: 'c3',
    postId: '2',
    author: 'HomeChef_Marco',
    content: 'Finally tried this recipe last weekend. The tip about the dough feeling like an earlobe was surprisingly helpful! My pasta turned out amazing.',
    createdAt: '2024-03-12',
  },
  {
    id: 'c4',
    postId: '3',
    author: 'NightOwl_Sarah',
    content: 'As someone who naturally wakes up at 10 AM, this terrifies me. But also inspires me to try...',
    createdAt: '2024-03-06',
  },
];
