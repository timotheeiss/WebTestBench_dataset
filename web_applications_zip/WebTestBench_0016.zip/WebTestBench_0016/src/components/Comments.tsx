import { useState } from 'react';
import { MessageCircle, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Comment, initialComments } from '@/data/posts';
import { format } from 'date-fns';
import { toast } from '@/hooks/use-toast';

interface CommentsProps {
  postId: string;
}

export function Comments({ postId }: CommentsProps) {
  const [comments, setComments] = useState<Comment[]>(
    initialComments.filter((c) => c.postId === postId)
  );
  const [author, setAuthor] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !content.trim()) {
      toast({
        title: 'Please fill in all fields',
        variant: 'destructive',
      });
      return;
    }

    const newComment: Comment = {
      id: `c${Date.now()}`,
      postId,
      author: author.trim(),
      content: content.trim(),
      createdAt: new Date().toISOString().split('T')[0],
    };

    setComments([...comments, newComment]);
    setAuthor('');
    setContent('');
    toast({
      title: 'Comment posted!',
      description: 'Thanks for joining the conversation.',
    });
  };

  return (
    <section className="mt-12 pt-12 border-t border-border">
      <h3 className="font-display text-2xl font-semibold mb-6 flex items-center gap-2">
        <MessageCircle className="h-6 w-6 text-primary" />
        Comments ({comments.length})
      </h3>

      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="mb-8 p-6 bg-card rounded-xl border border-border">
        <h4 className="font-display text-lg font-medium mb-4">Leave a comment</h4>
        <div className="space-y-4">
          <Input
            placeholder="Your name"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            className="bg-background"
          />
          <Textarea
            placeholder="Share your thoughts..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            className="bg-background resize-none"
          />
          <Button type="submit" className="w-full sm:w-auto">
            <Send className="h-4 w-4 mr-2" />
            Post Comment
          </Button>
        </div>
      </form>

      {/* Comments List */}
      <div className="space-y-6">
        {comments.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No comments yet. Be the first to share your thoughts!
          </p>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="p-5 bg-card rounded-xl border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-foreground">{comment.author}</span>
                <span className="text-sm text-muted-foreground">
                  {format(new Date(comment.createdAt), 'MMM d, yyyy')}
                </span>
              </div>
              <p className="text-muted-foreground">{comment.content}</p>
            </div>
          ))
        )}
      </div>
    </section>
  );
}