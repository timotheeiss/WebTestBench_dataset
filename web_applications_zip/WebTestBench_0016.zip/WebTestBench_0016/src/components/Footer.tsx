import { Link } from 'react-router-dom';
import { categories } from '@/data/posts';

export function Footer() {
  return (
    <footer className="border-t border-border bg-card mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link to="/" className="inline-block">
              <span className="font-display text-2xl font-semibold text-gradient">
                Wandering Words
              </span>
            </Link>
            <p className="mt-4 text-muted-foreground max-w-md">
              A personal blog sharing travel stories from around the world, detailed recipes from my kitchen, 
              and self-improvement guides for a better life.
            </p>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-display text-lg font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link
                    to={`/category/${category.id}`}
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    {category.icon} {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-display text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/archive" className="text-muted-foreground hover:text-primary transition-colors">
                  Archive
                </Link>
              </li>
              <li>
                <Link to="/search" className="text-muted-foreground hover:text-primary transition-colors">
                  Search
                </Link>
              </li>
              <li>
                <Link to="/series" className="text-muted-foreground hover:text-primary transition-colors">
                  Series
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Wandering Words. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Made with ❤️ for storytellers everywhere
          </p>
        </div>
      </div>
    </footer>
  );
}