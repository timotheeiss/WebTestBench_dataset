import { Link } from 'react-router-dom';
import { Calendar, Clock, Heart } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Post, categories } from '@/data/posts';
import { format } from 'date-fns';

interface PostCardProps {
  post: Post;
  featured?: boolean;
}

export function PostCard({ post, featured = false }: PostCardProps) {
  const category = categories.find((c) => c.id === post.category);

  if (featured) {
    return (
      <article className="group relative overflow-hidden rounded-xl transition-card shadow-card hover:shadow-card-hover">
        <Link to={`/post/${post.slug}`} className="block">
          <div className="relative aspect-[16/9] md:aspect-[21/9] overflow-hidden">
            <img
              src={post.coverImage}
              alt={post.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/40 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="secondary" className="bg-primary text-primary-foreground">
                  {category?.icon} {category?.name}
                </Badge>
                {post.series && (
                  <Badge variant="outline" className="border-primary-foreground/30 text-primary-foreground/90">
                    Series
                  </Badge>
                )}
              </div>
              <h2 className="font-display text-2xl md:text-4xl font-semibold text-primary-foreground mb-3 line-clamp-2">
                {post.title}
              </h2>
              <p className="text-primary-foreground/80 mb-4 line-clamp-2 max-w-2xl">
                {post.excerpt}
              </p>
              <div className="flex items-center gap-4 text-sm text-primary-foreground/70">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {format(new Date(post.publishedAt), 'MMM d, yyyy')}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {post.readTime} min read
                </span>
                <span className="flex items-center gap-1">
                  <Heart className="h-4 w-4" />
                  {post.likes}
                </span>
              </div>
            </div>
          </div>
        </Link>
      </article>
    );
  }

  return (
    <article className="group bg-card rounded-xl overflow-hidden transition-card shadow-card hover:shadow-card-hover">
      <Link to={`/post/${post.slug}`} className="block">
        <div className="relative aspect-[16/10] overflow-hidden">
          <img
            src={post.coverImage}
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-4 left-4">
            <Badge variant="secondary" className="bg-background/90 text-foreground backdrop-blur-sm">
              {category?.icon} {category?.name}
            </Badge>
          </div>
        </div>
        <div className="p-5">
          <h3 className="font-display text-xl font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {post.title}
          </h3>
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                {format(new Date(post.publishedAt), 'MMM d')}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                {post.readTime} min
              </span>
            </div>
            <span className="flex items-center gap-1">
              <Heart className="h-3.5 w-3.5" />
              {post.likes}
            </span>
          </div>
        </div>
      </Link>
    </article>
  );
}