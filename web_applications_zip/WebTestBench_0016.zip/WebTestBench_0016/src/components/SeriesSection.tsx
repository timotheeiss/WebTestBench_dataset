import { Link } from 'react-router-dom';
import { BookOpen, ArrowRight } from 'lucide-react';
import { series, posts } from '@/data/posts';

export function SeriesSection() {
  const getSeriesPostCount = (seriesId: string) => {
    return posts.filter((post) => post.series === seriesId).length;
  };

  return (
    <section className="py-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl font-semibold">Featured Series</h2>
        <Link
          to="/series"
          className="text-sm font-medium text-primary hover:underline inline-flex items-center"
        >
          View all series
          <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {series.map((s) => (
          <Link
            key={s.id}
            to={`/series/${s.id}`}
            className="group p-6 hero-gradient rounded-xl border border-border transition-card hover:border-primary/50 hover:shadow-card"
          >
            <div className="flex items-center gap-2 text-primary mb-3">
              <BookOpen className="h-5 w-5" />
              <span className="text-sm font-medium">
                {getSeriesPostCount(s.id)} articles
              </span>
            </div>
            <h3 className="font-display text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
              {s.name}
            </h3>
            <p className="text-muted-foreground text-sm line-clamp-2">
              {s.description}
            </p>
          </Link>
        ))}
      </div>
    </section>
  );
}