import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { categories } from '@/data/posts';

export function CategorySection() {
  return (
    <section className="py-12">
      <h2 className="font-display text-2xl font-semibold mb-6">Explore Topics</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {categories.map((category) => (
          <Link
            key={category.id}
            to={`/category/${category.id}`}
            className="group p-6 bg-card rounded-xl border border-border transition-card hover:border-primary/50 hover:shadow-card"
          >
            <div className="text-4xl mb-4">{category.icon}</div>
            <h3 className="font-display text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
              {category.name}
            </h3>
            <p className="text-muted-foreground text-sm mb-4">
              {category.description}
            </p>
            <span className="inline-flex items-center text-sm font-medium text-primary">
              Browse articles
              <ArrowRight className="h-4 w-4 ml-1 transition-transform group-hover:translate-x-1" />
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}