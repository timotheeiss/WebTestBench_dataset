import { useState } from 'react';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

interface LikeButtonProps {
  initialLikes: number;
  postId: string;
}

export function LikeButton({ initialLikes, postId }: LikeButtonProps) {
  const [likes, setLikes] = useState(initialLikes);
  const [hasLiked, setHasLiked] = useState(false);

  const handleLike = () => {
    if (hasLiked) {
      setLikes(likes - 1);
      setHasLiked(false);
    } else {
      setLikes(likes + 1);
      setHasLiked(true);
      toast({
        title: '❤️ Thanks for the love!',
        description: 'Your appreciation means the world.',
      });
    }
  };

  return (
    <Button
      variant={hasLiked ? 'default' : 'outline'}
      size="lg"
      onClick={handleLike}
      className={`gap-2 transition-all ${
        hasLiked 
          ? 'bg-primary text-primary-foreground' 
          : 'hover:border-primary hover:text-primary'
      }`}
    >
      <Heart className={`h-5 w-5 ${hasLiked ? 'fill-current' : ''}`} />
      <span>{likes}</span>
    </Button>
  );
}