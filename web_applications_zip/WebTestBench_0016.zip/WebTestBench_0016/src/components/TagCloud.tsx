import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { posts } from '@/data/posts';

export function TagCloud() {
  // Get all unique tags with their counts
  const tagCounts = posts.reduce<Record<string, number>>((acc, post) => {
    post.tags.forEach((tag) => {
      acc[tag] = (acc[tag] || 0) + 1;
    });
    return acc;
  }, {});

  const sortedTags = Object.entries(tagCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12);

  return (
    <section className="py-12">
      <h2 className="font-display text-2xl font-semibold mb-6">Popular Tags</h2>
      <div className="flex flex-wrap gap-2">
        {sortedTags.map(([tag, count]) => (
          <Link key={tag} to={`/search?tag=${encodeURIComponent(tag)}`}>
            <Badge
              variant="outline"
              className="px-3 py-1.5 text-sm font-normal hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors cursor-pointer"
            >
              {tag} ({count})
            </Badge>
          </Link>
        ))}
      </div>
    </section>
  );
}