import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Post, posts as allPosts } from '@/data/posts';
import { PostCard } from './PostCard';

interface RelatedPostsProps {
  currentPost: Post;
}

export function RelatedPosts({ currentPost }: RelatedPostsProps) {
  // Find related posts based on category, tags, or series
  const relatedPosts = allPosts
    .filter((post) => post.id !== currentPost.id)
    .map((post) => {
      let score = 0;
      
      // Same category
      if (post.category === currentPost.category) score += 3;
      
      // Same series
      if (post.series && post.series === currentPost.series) score += 5;
      
      // Shared tags
      const sharedTags = post.tags.filter((tag) => currentPost.tags.includes(tag));
      score += sharedTags.length * 2;

      return { post, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(({ post }) => post);

  if (relatedPosts.length === 0) return null;

  return (
    <section className="mt-12 pt-12 border-t border-border">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display text-2xl font-semibold">You might also enjoy</h3>
        <Link
          to={`/category/${currentPost.category}`}
          className="text-sm font-medium text-primary hover:underline inline-flex items-center"
        >
          More in this category
          <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {relatedPosts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </section>
  );
}