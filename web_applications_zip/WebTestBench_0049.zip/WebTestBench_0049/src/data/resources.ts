export type ResourceType = 'room' | 'projector' | 'workstation';

export interface Resource {
  id: string;
  name: string;
  type: ResourceType;
  description: string;
  capacity?: number;
  location: string;
  amenities?: string[];
}

export interface Reservation {
  id: string;
  resourceId: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  createdAt: string;
}

export const resources: Resource[] = [
  {
    id: 'room-1',
    name: 'Skyline Conference Room',
    type: 'room',
    description: 'Large conference room with panoramic city views',
    capacity: 20,
    location: 'Floor 12, East Wing',
    amenities: ['Video conferencing', 'Whiteboard', 'TV Display'],
  },
  {
    id: 'room-2',
    name: 'Focus Pod A',
    type: 'room',
    description: 'Small meeting room for focused discussions',
    capacity: 4,
    location: 'Floor 8, North Wing',
    amenities: ['Whiteboard', 'Phone'],
  },
  {
    id: 'room-3',
    name: 'Innovation Lab',
    type: 'room',
    description: 'Creative space for brainstorming sessions',
    capacity: 12,
    location: 'Floor 5, Creative Hub',
    amenities: ['Smart Board', 'Video conferencing', 'Standing desks'],
  },
  {
    id: 'projector-1',
    name: 'Epson Pro 4K',
    type: 'projector',
    description: 'High-resolution 4K projector for presentations',
    location: 'Equipment Room, Floor 3',
  },
  {
    id: 'projector-2',
    name: 'Portable Mini Projector',
    type: 'projector',
    description: 'Compact projector for small team meetings',
    location: 'Equipment Room, Floor 3',
  },
  {
    id: 'workstation-1',
    name: 'Design Station Alpha',
    type: 'workstation',
    description: 'High-performance workstation with dual monitors',
    location: 'Floor 7, Design Area',
    amenities: ['32GB RAM', 'Graphics Tablet', 'Dual 4K Monitors'],
  },
  {
    id: 'workstation-2',
    name: 'Developer Hub 1',
    type: 'workstation',
    description: 'Ergonomic standing desk with powerful hardware',
    location: 'Floor 6, Tech Zone',
    amenities: ['Standing Desk', 'Triple Monitor', 'Mechanical Keyboard'],
  },
  {
    id: 'workstation-3',
    name: 'Quiet Corner Desk',
    type: 'workstation',
    description: 'Secluded workspace for focused individual work',
    location: 'Floor 4, Library Area',
    amenities: ['Noise-canceling booth', 'Ergonomic chair'],
  },
];

export const initialReservations: Reservation[] = [
  {
    id: 'res-1',
    resourceId: 'room-1',
    title: 'Q4 Planning Meeting',
    date: '2025-12-15',
    startTime: '10:00',
    endTime: '12:00',
    createdAt: '2025-12-10T09:00:00Z',
  },
  {
    id: 'res-2',
    resourceId: 'projector-1',
    title: 'Client Presentation Setup',
    date: '2025-12-14',
    startTime: '14:00',
    endTime: '16:00',
    createdAt: '2025-12-11T14:30:00Z',
  },
];
