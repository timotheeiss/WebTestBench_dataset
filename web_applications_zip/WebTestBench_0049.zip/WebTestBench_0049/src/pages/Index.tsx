import { useState, useMemo } from 'react';
import { resources, initialReservations, Resource, ResourceType, Reservation } from '@/data/resources';
import { ResourceCard } from '@/components/ResourceCard';
import { ResourceFilter } from '@/components/ResourceFilter';
import { ReservationForm } from '@/components/ReservationForm';
import { ReservationList } from '@/components/ReservationList';
import { CalendarCheck, Building2 } from 'lucide-react';

const Index = () => {
  const [selectedType, setSelectedType] = useState<ResourceType | 'all'>('all');
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [reservations, setReservations] = useState<Reservation[]>(initialReservations);

  const filteredResources = useMemo(() => {
    if (selectedType === 'all') return resources;
    return resources.filter((r) => r.type === selectedType);
  }, [selectedType]);

  const handleResourceSelect = (resource: Resource) => {
    setSelectedResource(resource);
  };

  const handleReservationSubmit = (reservation: Omit<Reservation, 'id' | 'createdAt'>) => {
    const newReservation: Reservation = {
      ...reservation,
      id: `res-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setReservations((prev) => [...prev, newReservation]);
    setSelectedResource(null);
  };

  const handleCancelReservation = (id: string) => {
    setReservations((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Building2 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Office Resources</h1>
              <p className="text-sm text-muted-foreground">Book rooms, equipment & workstations</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Resources Section */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-4">Available Resources</h2>
              <ResourceFilter selectedType={selectedType} onTypeChange={setSelectedType} />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {filteredResources.map((resource) => (
                <ResourceCard
                  key={resource.id}
                  resource={resource}
                  isSelected={selectedResource?.id === resource.id}
                  onSelect={handleResourceSelect}
                />
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Reservation Form */}
            <div className="bg-card border border-border rounded-xl p-6 shadow-card">
              <div className="flex items-center gap-2 mb-6">
                <CalendarCheck className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">
                  {selectedResource ? 'Make Reservation' : 'Select a Resource'}
                </h2>
              </div>

              {selectedResource ? (
                <ReservationForm
                  resource={selectedResource}
                  onSubmit={handleReservationSubmit}
                  onCancel={() => setSelectedResource(null)}
                />
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p className="text-sm">
                    Click on a resource card to start booking.
                  </p>
                </div>
              )}
            </div>

            {/* Reservations List */}
            <div className="bg-card border border-border rounded-xl p-6 shadow-card">
              <h2 className="text-lg font-semibold text-foreground mb-4">
                Your Reservations
              </h2>
              <ReservationList
                reservations={reservations}
                resources={resources}
                onCancel={handleCancelReservation}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
