import { useState } from 'react';
import { Resource, Reservation } from '@/data/resources';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { CalendarIcon, Clock, Bookmark } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface ReservationFormProps {
  resource: Resource;
  onSubmit: (reservation: Omit<Reservation, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export function ReservationForm({ resource, onSubmit, onCancel }: ReservationFormProps) {
  const [date, setDate] = useState<Date>();
  const [title, setTitle] = useState('');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!date) {
      toast({
        title: 'Please select a date',
        variant: 'destructive',
      });
      return;
    }

    if (!title.trim()) {
      toast({
        title: 'Please enter a title',
        variant: 'destructive',
      });
      return;
    }

    if (startTime >= endTime) {
      toast({
        title: 'End time must be after start time',
        variant: 'destructive',
      });
      return;
    }

    onSubmit({
      resourceId: resource.id,
      title: title.trim(),
      date: format(date, 'yyyy-MM-dd'),
      startTime,
      endTime,
    });

    toast({
      title: 'Reservation created!',
      description: `${resource.name} booked for ${format(date, 'MMM d, yyyy')}`,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
      <div className="p-4 rounded-lg bg-secondary/50 border border-border">
        <h3 className="font-semibold text-foreground mb-1">{resource.name}</h3>
        <p className="text-sm text-muted-foreground">{resource.location}</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title" className="text-sm font-medium flex items-center gap-2">
          <Bookmark className="h-4 w-4 text-muted-foreground" />
          Purpose / Title
        </Label>
        <Input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g., Team standup, Client presentation"
          className="h-11"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium flex items-center gap-2">
          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          Date
        </Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                'w-full justify-start text-left font-normal h-11',
                !date && 'text-muted-foreground'
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, 'PPP') : 'Select a date'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              initialFocus
              disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
              className="pointer-events-auto"
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startTime" className="text-sm font-medium flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            Start Time
          </Label>
          <Input
            id="startTime"
            type="time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            className="h-11"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="endTime" className="text-sm font-medium">
            End Time
          </Label>
          <Input
            id="endTime"
            type="time"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            className="h-11"
          />
        </div>
      </div>

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
        <Button type="submit" className="flex-1">
          Reserve
        </Button>
      </div>
    </form>
  );
}
