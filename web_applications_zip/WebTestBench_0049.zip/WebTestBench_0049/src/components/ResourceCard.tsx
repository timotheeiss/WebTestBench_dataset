import { Resource, ResourceType } from '@/data/resources';
import { cn } from '@/lib/utils';
import { Users, MapPin, Monitor, Video, Laptop } from 'lucide-react';

interface ResourceCardProps {
  resource: Resource;
  isSelected: boolean;
  onSelect: (resource: Resource) => void;
}

const typeIcons: Record<ResourceType, React.ReactNode> = {
  room: <Users className="h-5 w-5" />,
  projector: <Video className="h-5 w-5" />,
  workstation: <Laptop className="h-5 w-5" />,
};

const typeLabels: Record<ResourceType, string> = {
  room: 'Meeting Room',
  projector: 'Projector',
  workstation: 'Workstation',
};

export function ResourceCard({ resource, isSelected, onSelect }: ResourceCardProps) {
  return (
    <button
      onClick={() => onSelect(resource)}
      className={cn(
        'w-full text-left p-4 rounded-lg border-2 transition-all duration-200',
        'hover:shadow-card-hover hover:-translate-y-0.5',
        'focus:outline-none focus:ring-2 focus:ring-primary/20',
        isSelected
          ? 'border-primary bg-primary/5 shadow-card'
          : 'border-border bg-card hover:border-primary/30'
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            'p-2.5 rounded-lg',
            resource.type === 'room' && 'bg-room/10 text-room',
            resource.type === 'projector' && 'bg-projector/10 text-projector',
            resource.type === 'workstation' && 'bg-workstation/10 text-workstation'
          )}
        >
          {typeIcons[resource.type]}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-foreground truncate">{resource.name}</h3>
          </div>
          <span
            className={cn(
              'inline-block text-xs font-medium px-2 py-0.5 rounded-full mb-2',
              resource.type === 'room' && 'bg-room/10 text-room',
              resource.type === 'projector' && 'bg-projector/10 text-projector',
              resource.type === 'workstation' && 'bg-workstation/10 text-workstation'
            )}
          >
            {typeLabels[resource.type]}
          </span>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {resource.description}
          </p>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              {resource.location}
            </span>
            {resource.capacity && (
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                {resource.capacity} people
              </span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}
