import { Reservation, Resource } from '@/data/resources';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { format, parseISO, isAfter, isBefore, startOfDay } from 'date-fns';
import { Calendar, Clock, Trash2, MapPin } from 'lucide-react';

interface ReservationListProps {
  reservations: Reservation[];
  resources: Resource[];
  onCancel: (id: string) => void;
}

export function ReservationList({ reservations, resources, onCancel }: ReservationListProps) {
  const today = startOfDay(new Date());
  
  const upcomingReservations = reservations
    .filter((res) => {
      const resDate = parseISO(res.date);
      return isAfter(resDate, today) || format(resDate, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
    })
    .sort((a, b) => {
      const dateA = parseISO(a.date);
      const dateB = parseISO(b.date);
      if (dateA.getTime() !== dateB.getTime()) {
        return dateA.getTime() - dateB.getTime();
      }
      return a.startTime.localeCompare(b.startTime);
    });

  const getResource = (resourceId: string) => 
    resources.find((r) => r.id === resourceId);

  if (upcomingReservations.length === 0) {
    return (
      <div className="text-center py-12 px-4">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary flex items-center justify-center">
          <Calendar className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No upcoming reservations</h3>
        <p className="text-sm text-muted-foreground">
          Select a resource and make a reservation to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {upcomingReservations.map((reservation, index) => {
        const resource = getResource(reservation.resourceId);
        if (!resource) return null;

        return (
          <div
            key={reservation.id}
            className="p-4 rounded-lg border border-border bg-card shadow-soft animate-slide-up"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-foreground truncate mb-1">
                  {reservation.title}
                </h4>
                <p className="text-sm text-muted-foreground mb-2">{resource.name}</p>
                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {format(parseISO(reservation.date), 'MMM d, yyyy')}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {reservation.startTime} - {reservation.endTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {resource.location}
                  </span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onCancel(reservation.id)}
                className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 shrink-0"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
