import { ResourceType } from '@/data/resources';
import { cn } from '@/lib/utils';
import { Users, Video, Laptop, LayoutGrid } from 'lucide-react';

interface ResourceFilterProps {
  selectedType: ResourceType | 'all';
  onTypeChange: (type: ResourceType | 'all') => void;
}

const filters: { type: ResourceType | 'all'; label: string; icon: React.ReactNode }[] = [
  { type: 'all', label: 'All', icon: <LayoutGrid className="h-4 w-4" /> },
  { type: 'room', label: 'Rooms', icon: <Users className="h-4 w-4" /> },
  { type: 'projector', label: 'Projectors', icon: <Video className="h-4 w-4" /> },
  { type: 'workstation', label: 'Workstations', icon: <Laptop className="h-4 w-4" /> },
];

export function ResourceFilter({ selectedType, onTypeChange }: ResourceFilterProps) {
  return (
    <div className="flex gap-2 flex-wrap">
      {filters.map((filter) => (
        <button
          key={filter.type}
          onClick={() => onTypeChange(filter.type)}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200',
            'focus:outline-none focus:ring-2 focus:ring-primary/20',
            selectedType === filter.type
              ? 'bg-primary text-primary-foreground shadow-soft'
              : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
          )}
        >
          {filter.icon}
          {filter.label}
        </button>
      ))}
    </div>
  );
}
