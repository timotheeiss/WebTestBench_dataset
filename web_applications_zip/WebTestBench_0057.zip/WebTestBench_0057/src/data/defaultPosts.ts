import { InterviewPost } from '@/types/interview';

export const defaultPosts: InterviewPost[] = [
  {
    id: 'post-1',
    companyType: 'Big Tech',
    companyName: 'Google',
    position: 'Senior Software Engineer',
    interviewDate: '2025-12-15',
    rounds: [
      {
        id: 'round-1-1',
        roundNumber: 1,
        roundType: 'Phone Screen',
        questions: [
          {
            id: 'q-1-1-1',
            question: 'Tell me about yourself and your experience with distributed systems.',
            answer: 'I discussed my 5 years of experience building microservices at scale.'
          },
          {
            id: 'q-1-1-2',
            question: 'Design a URL shortening service like bit.ly.',
            answer: 'Covered hash generation, database design, and caching strategies.'
          }
        ]
      },
      {
        id: 'round-1-2',
        roundNumber: 2,
        roundType: 'Technical Interview',
        questions: [
          {
            id: 'q-1-2-1',
            question: 'Implement an LRU cache with O(1) operations.',
            answer: 'Used HashMap with doubly linked list approach.'
          },
          {
            id: 'q-1-2-2',
            question: 'Find the median of two sorted arrays.',
            answer: 'Binary search solution with O(log(min(m,n))) complexity.'
          }
        ]
      },
      {
        id: 'round-1-3',
        roundNumber: 3,
        roundType: 'System Design',
        questions: [
          {
            id: 'q-1-3-1',
            question: 'Design Google Maps navigation system.',
            answer: 'Discussed graph algorithms, real-time traffic, and tile rendering.'
          }
        ]
      }
    ],
    reflection: 'The interviews were challenging but fair. The interviewers were very supportive and gave helpful hints when I got stuck. I recommend practicing system design extensively and being prepared to discuss trade-offs.',
    outcome: 'offer',
    difficulty: 5,
    createdAt: '2025-12-20T10:30:00Z',
    authorName: 'Alex Chen'
  },
  {
    id: 'post-2',
    companyType: 'Startup',
    companyName: 'Stripe',
    position: 'Backend Engineer',
    interviewDate: '2025-11-28',
    rounds: [
      {
        id: 'round-2-1',
        roundNumber: 1,
        roundType: 'Coding Challenge',
        questions: [
          {
            id: 'q-2-1-1',
            question: 'Implement a rate limiter for API endpoints.',
            answer: 'Used sliding window algorithm with Redis-like data structure.'
          }
        ]
      },
      {
        id: 'round-2-2',
        roundNumber: 2,
        roundType: 'Technical Interview',
        questions: [
          {
            id: 'q-2-2-1',
            question: 'How would you design a payment processing system?',
            answer: 'Covered idempotency, transaction handling, and failure recovery.'
          },
          {
            id: 'q-2-2-2',
            question: 'Explain database transactions and ACID properties.',
            answer: 'Deep dive into isolation levels and their trade-offs.'
          }
        ]
      }
    ],
    reflection: 'Stripe has a very practical interview process. They focus on real-world problems that you would actually encounter. The coding challenge was take-home which gave me time to think deeply about the solution.',
    outcome: 'pending',
    difficulty: 4,
    createdAt: '2025-12-05T14:20:00Z',
    authorName: 'Sarah Johnson'
  },
  {
    id: 'post-3',
    companyType: 'Finance',
    companyName: 'Goldman Sachs',
    position: 'Quantitative Developer',
    interviewDate: '2025-10-10',
    rounds: [
      {
        id: 'round-3-1',
        roundNumber: 1,
        roundType: 'Technical Screen',
        questions: [
          {
            id: 'q-3-1-1',
            question: 'Implement a thread-safe singleton pattern.',
            answer: 'Discussed double-checked locking and initialization-on-demand holder idiom.'
          },
          {
            id: 'q-3-1-2',
            question: 'What is the time complexity of quicksort and when does it perform worst?',
            answer: 'O(n log n) average, O(n²) worst case with already sorted arrays.'
          }
        ]
      },
      {
        id: 'round-3-2',
        roundNumber: 2,
        roundType: 'Behavioral',
        questions: [
          {
            id: 'q-3-2-1',
            question: 'Tell me about a time you had to meet a tight deadline.',
            answer: 'Shared experience from a critical trading system migration project.'
          }
        ]
      }
    ],
    reflection: 'The process was rigorous and tested both technical skills and problem-solving under pressure. They value attention to detail and the ability to explain complex concepts clearly.',
    outcome: 'rejected',
    difficulty: 4,
    createdAt: '2025-10-25T09:15:00Z',
    authorName: 'Michael Park'
  }
];
