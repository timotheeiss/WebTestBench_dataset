export interface InterviewQuestion {
  id: string;
  question: string;
  answer?: string;
}

export interface InterviewRound {
  id: string;
  roundNumber: number;
  roundType: string;
  questions: InterviewQuestion[];
}

export interface InterviewPost {
  id: string;
  companyType: string;
  companyName: string;
  position: string;
  interviewDate: string;
  rounds: InterviewRound[];
  reflection: string;
  outcome: 'offer' | 'rejected' | 'pending' | 'withdrew';
  difficulty: 1 | 2 | 3 | 4 | 5;
  createdAt: string;
  authorName: string;
}

export interface FavoriteQuestion {
  questionId: string;
  postId: string;
  question: string;
  companyName: string;
  position: string;
  roundType: string;
}

export type TabType = 'create' | 'browse' | 'favorites';

export interface PostFormData {
  companyType: string;
  companyName: string;
  position: string;
  interviewDate: string;
  rounds: InterviewRound[];
  reflection: string;
  outcome: 'offer' | 'rejected' | 'pending' | 'withdrew';
  difficulty: 1 | 2 | 3 | 4 | 5;
  authorName: string;
}
