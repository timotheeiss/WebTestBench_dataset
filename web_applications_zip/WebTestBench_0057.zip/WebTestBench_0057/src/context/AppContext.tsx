import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { InterviewPost, FavoriteQuestion, TabType, PostFormData, InterviewRound } from '@/types/interview';
import { defaultPosts } from '@/data/defaultPosts';

interface AppContextType {
  posts: InterviewPost[];
  favorites: FavoriteQuestion[];
  activeTab: TabType;
  draftForm: Partial<PostFormData> | null;
  setActiveTab: (tab: TabType) => void;
  addPost: (post: PostFormData) => void;
  toggleFavorite: (questionId: string, postId: string) => void;
  isFavorited: (questionId: string) => boolean;
  saveDraft: (draft: Partial<PostFormData>) => void;
  clearDraft: () => void;
  favoritesCount: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const FAVORITES_STORAGE_KEY = 'interview-favorites';
const DRAFT_STORAGE_KEY = 'interview-draft';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [posts, setPosts] = useState<InterviewPost[]>(defaultPosts);
  const [favorites, setFavorites] = useState<FavoriteQuestion[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('browse');
  const [draftForm, setDraftForm] = useState<Partial<PostFormData> | null>(null);

  // Load favorites from localStorage on mount
  useEffect(() => {
    const storedFavorites = localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (storedFavorites) {
      try {
        setFavorites(JSON.parse(storedFavorites));
      } catch (e) {
        console.error('Failed to parse favorites:', e);
      }
    }

    const storedDraft = localStorage.getItem(DRAFT_STORAGE_KEY);
    if (storedDraft) {
      try {
        setDraftForm(JSON.parse(storedDraft));
      } catch (e) {
        console.error('Failed to parse draft:', e);
      }
    }
  }, []);

  // Save favorites to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const addPost = useCallback((postData: PostFormData) => {
    const newPost: InterviewPost = {
      ...postData,
      id: `post-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setPosts(prev => [newPost, ...prev]);
    clearDraft();
  }, []);

  const toggleFavorite = useCallback((questionId: string, postId: string) => {
    setFavorites(prev => {
      const existingIndex = prev.findIndex(f => f.questionId === questionId);
      
      if (existingIndex >= 0) {
        return prev.filter((_, i) => i !== existingIndex);
      }

      // Find the question details from posts
      const post = posts.find(p => p.id === postId);
      if (!post) return prev;

      let questionData: { question: string; roundType: string } | null = null;
      for (const round of post.rounds) {
        const q = round.questions.find(q => q.id === questionId);
        if (q) {
          questionData = { question: q.question, roundType: round.roundType };
          break;
        }
      }

      if (!questionData) return prev;

      const newFavorite: FavoriteQuestion = {
        questionId,
        postId,
        question: questionData.question,
        companyName: post.companyName,
        position: post.position,
        roundType: questionData.roundType,
      };

      return [...prev, newFavorite];
    });
  }, [posts]);

  const isFavorited = useCallback((questionId: string) => {
    return favorites.some(f => f.questionId === questionId);
  }, [favorites]);

  const saveDraft = useCallback((draft: Partial<PostFormData>) => {
    setDraftForm(draft);
    localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draft));
  }, []);

  const clearDraft = useCallback(() => {
    setDraftForm(null);
    localStorage.removeItem(DRAFT_STORAGE_KEY);
  }, []);

  return (
    <AppContext.Provider
      value={{
        posts,
        favorites,
        activeTab,
        draftForm,
        setActiveTab,
        addPost,
        toggleFavorite,
        isFavorited,
        saveDraft,
        clearDraft,
        favoritesCount: favorites.length,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
