import { PenSquare, BookOpen, Heart } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { TabType } from '@/types/interview';
import { cn } from '@/lib/utils';

const tabs: { id: TabType; label: string; icon: React.ElementType }[] = [
  { id: 'create', label: 'Create Post', icon: PenSquare },
  { id: 'browse', label: 'Browse Posts', icon: BookOpen },
  { id: 'favorites', label: 'My Favorites', icon: Heart },
];

export function TabNavigation() {
  const { activeTab, setActiveTab, favoritesCount } = useApp();

  return (
    <nav className="border-b border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'relative flex items-center gap-2 px-5 py-4 text-sm font-medium transition-all',
                  'hover:text-primary',
                  isActive
                    ? 'text-primary'
                    : 'text-muted-foreground'
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
                {tab.id === 'favorites' && favoritesCount > 0 && (
                  <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1.5 text-xs font-semibold text-accent-foreground">
                    {favoritesCount}
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
