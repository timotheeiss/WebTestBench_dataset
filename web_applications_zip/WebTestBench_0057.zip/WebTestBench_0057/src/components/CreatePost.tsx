import { useState, useEffect } from 'react';
import { Plus, Trash2, AlertCircle, CheckCircle } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { PostFormData, InterviewRound, InterviewQuestion } from '@/types/interview';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

const companyTypes = ['Big Tech', 'Startup', 'Finance', 'Consulting', 'Healthcare', 'E-commerce', 'Other'];
const roundTypes = ['Phone Screen', 'Technical Interview', 'Coding Challenge', 'System Design', 'Behavioral', 'HR Interview', 'Panel Interview', 'Take-home Assignment'];
const outcomes: { value: PostFormData['outcome']; label: string }[] = [
  { value: 'offer', label: 'Received Offer' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'pending', label: 'Still Pending' },
  { value: 'withdrew', label: 'Withdrew Application' },
];

interface ValidationErrors {
  companyType?: string;
  companyName?: string;
  position?: string;
  interviewDate?: string;
  authorName?: string;
  rounds?: string;
  reflection?: string;
}

export function CreatePost() {
  const { addPost, draftForm, saveDraft, setActiveTab } = useApp();
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [showSuccess, setShowSuccess] = useState(false);

  const createEmptyRound = (roundNumber: number): InterviewRound => ({
    id: `round-${Date.now()}-${roundNumber}`,
    roundNumber,
    roundType: '',
    questions: [createEmptyQuestion()],
  });

  const createEmptyQuestion = (): InterviewQuestion => ({
    id: `q-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    question: '',
    answer: '',
  });

  const [form, setForm] = useState<Partial<PostFormData>>(() => {
    if (draftForm) return draftForm;
    return {
      companyType: '',
      companyName: '',
      position: '',
      interviewDate: '',
      rounds: [createEmptyRound(1)],
      reflection: '',
      outcome: 'pending',
      difficulty: 3,
      authorName: '',
    };
  });

  // Auto-save draft on form changes
  useEffect(() => {
    const timer = setTimeout(() => {
      saveDraft(form);
    }, 500);
    return () => clearTimeout(timer);
  }, [form, saveDraft]);

  const validateForm = (): boolean => {
    const newErrors: ValidationErrors = {};

    if (!form.companyType) newErrors.companyType = 'Please select a company type';
    if (!form.companyName?.trim()) newErrors.companyName = 'Company name is required';
    if (!form.position?.trim()) newErrors.position = 'Position is required';
    if (!form.interviewDate) newErrors.interviewDate = 'Interview date is required';
    if (!form.authorName?.trim()) newErrors.authorName = 'Your name is required';
    if (!form.reflection?.trim()) newErrors.reflection = 'Please share your reflection';

    const hasValidRound = form.rounds?.some(
      (round) =>
        round.roundType &&
        round.questions.some((q) => q.question.trim())
    );
    if (!hasValidRound) {
      newErrors.rounds = 'Add at least one round with a question';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    // Clean up rounds - remove empty questions
    const cleanedRounds = form.rounds?.map((round) => ({
      ...round,
      questions: round.questions.filter((q) => q.question.trim()),
    })).filter((round) => round.questions.length > 0) || [];

    addPost({
      ...form,
      rounds: cleanedRounds,
    } as PostFormData);

    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setActiveTab('browse');
    }, 2000);
  };

  const updateRound = (roundIndex: number, updates: Partial<InterviewRound>) => {
    setForm((prev) => ({
      ...prev,
      rounds: prev.rounds?.map((round, i) =>
        i === roundIndex ? { ...round, ...updates } : round
      ),
    }));
  };

  const addRound = () => {
    setForm((prev) => ({
      ...prev,
      rounds: [...(prev.rounds || []), createEmptyRound((prev.rounds?.length || 0) + 1)],
    }));
  };

  const removeRound = (roundIndex: number) => {
    setForm((prev) => ({
      ...prev,
      rounds: prev.rounds?.filter((_, i) => i !== roundIndex).map((r, i) => ({
        ...r,
        roundNumber: i + 1,
      })),
    }));
  };

  const updateQuestion = (
    roundIndex: number,
    questionIndex: number,
    updates: Partial<InterviewQuestion>
  ) => {
    setForm((prev) => ({
      ...prev,
      rounds: prev.rounds?.map((round, ri) =>
        ri === roundIndex
          ? {
              ...round,
              questions: round.questions.map((q, qi) =>
                qi === questionIndex ? { ...q, ...updates } : q
              ),
            }
          : round
      ),
    }));
  };

  const addQuestion = (roundIndex: number) => {
    setForm((prev) => ({
      ...prev,
      rounds: prev.rounds?.map((round, i) =>
        i === roundIndex
          ? { ...round, questions: [...round.questions, createEmptyQuestion()] }
          : round
      ),
    }));
  };

  const removeQuestion = (roundIndex: number, questionIndex: number) => {
    setForm((prev) => ({
      ...prev,
      rounds: prev.rounds?.map((round, i) =>
        i === roundIndex
          ? { ...round, questions: round.questions.filter((_, qi) => qi !== questionIndex) }
          : round
      ),
    }));
  };

  if (showSuccess) {
    return (
      <div className="flex min-h-[400px] flex-col items-center justify-center animate-scale-in">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-success/10">
          <CheckCircle className="h-8 w-8 text-success" />
        </div>
        <h2 className="font-heading text-2xl font-semibold text-foreground">
          Post Published!
        </h2>
        <p className="text-muted-foreground">
          Your interview experience has been shared.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-2xl space-y-8 animate-fade-in">
      <div>
        <h2 className="font-heading text-2xl font-semibold text-foreground">
          Share Your Interview Experience
        </h2>
        <p className="mt-1 text-muted-foreground">
          Help others prepare by sharing what you learned
        </p>
      </div>

      {/* Basic Info Section */}
      <div className="space-y-4 rounded-lg border border-border bg-card p-6">
        <h3 className="font-medium text-foreground">Basic Information</h3>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="authorName">Your Name *</Label>
            <Input
              id="authorName"
              value={form.authorName || ''}
              onChange={(e) => setForm({ ...form, authorName: e.target.value })}
              placeholder="John Doe"
              className={cn(errors.authorName && 'border-destructive')}
            />
            {errors.authorName && (
              <p className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" /> {errors.authorName}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyType">Company Type *</Label>
            <Select
              value={form.companyType}
              onValueChange={(value) => setForm({ ...form, companyType: value })}
            >
              <SelectTrigger className={cn(errors.companyType && 'border-destructive')}>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {companyTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.companyType && (
              <p className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" /> {errors.companyType}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyName">Company Name *</Label>
            <Input
              id="companyName"
              value={form.companyName || ''}
              onChange={(e) => setForm({ ...form, companyName: e.target.value })}
              placeholder="e.g., Google"
              className={cn(errors.companyName && 'border-destructive')}
            />
            {errors.companyName && (
              <p className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" /> {errors.companyName}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="position">Position *</Label>
            <Input
              id="position"
              value={form.position || ''}
              onChange={(e) => setForm({ ...form, position: e.target.value })}
              placeholder="e.g., Software Engineer"
              className={cn(errors.position && 'border-destructive')}
            />
            {errors.position && (
              <p className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" /> {errors.position}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="interviewDate">Interview Date *</Label>
            <Input
              id="interviewDate"
              type="date"
              value={form.interviewDate || ''}
              onChange={(e) => setForm({ ...form, interviewDate: e.target.value })}
              className={cn(errors.interviewDate && 'border-destructive')}
            />
            {errors.interviewDate && (
              <p className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" /> {errors.interviewDate}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="outcome">Outcome</Label>
            <Select
              value={form.outcome}
              onValueChange={(value) => setForm({ ...form, outcome: value as PostFormData['outcome'] })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select outcome" />
              </SelectTrigger>
              <SelectContent>
                {outcomes.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Difficulty Level</Label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setForm({ ...form, difficulty: level as 1 | 2 | 3 | 4 | 5 })}
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-lg border text-sm font-medium transition-colors',
                  form.difficulty === level
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border bg-card hover:bg-muted'
                )}
              >
                {level}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">1 = Easy, 5 = Very Difficult</p>
        </div>
      </div>

      {/* Interview Rounds Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-foreground">Interview Rounds</h3>
          <Button type="button" variant="outline" size="sm" onClick={addRound}>
            <Plus className="mr-1 h-4 w-4" /> Add Round
          </Button>
        </div>

        {errors.rounds && (
          <p className="flex items-center gap-1 text-sm text-destructive">
            <AlertCircle className="h-3 w-3" /> {errors.rounds}
          </p>
        )}

        {form.rounds?.map((round, roundIndex) => (
          <div
            key={round.id}
            className="space-y-4 rounded-lg border border-border bg-card p-6"
          >
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-foreground">Round {round.roundNumber}</h4>
              {(form.rounds?.length || 0) > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeRound(roundIndex)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="space-y-2">
              <Label>Round Type</Label>
              <Select
                value={round.roundType}
                onValueChange={(value) => updateRound(roundIndex, { roundType: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select round type" />
                </SelectTrigger>
                <SelectContent>
                  {roundTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label>Questions</Label>
              {round.questions.map((question, questionIndex) => (
                <div key={question.id} className="space-y-2 rounded-md border border-border p-3">
                  <div className="flex gap-2">
                    <Input
                      value={question.question}
                      onChange={(e) =>
                        updateQuestion(roundIndex, questionIndex, {
                          question: e.target.value,
                        })
                      }
                      placeholder="Enter the interview question"
                    />
                    {round.questions.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeQuestion(roundIndex, questionIndex)}
                        className="flex-shrink-0 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <Textarea
                    value={question.answer || ''}
                    onChange={(e) =>
                      updateQuestion(roundIndex, questionIndex, {
                        answer: e.target.value,
                      })
                    }
                    placeholder="Your answer or approach (optional)"
                    rows={2}
                  />
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addQuestion(roundIndex)}
              >
                <Plus className="mr-1 h-4 w-4" /> Add Question
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Reflection Section */}
      <div className="space-y-4 rounded-lg border border-border bg-card p-6">
        <h3 className="font-medium text-foreground">Personal Reflection *</h3>
        <Textarea
          value={form.reflection || ''}
          onChange={(e) => setForm({ ...form, reflection: e.target.value })}
          placeholder="Share your overall experience, what you learned, and any advice for others..."
          rows={4}
          className={cn(errors.reflection && 'border-destructive')}
        />
        {errors.reflection && (
          <p className="flex items-center gap-1 text-sm text-destructive">
            <AlertCircle className="h-3 w-3" /> {errors.reflection}
          </p>
        )}
      </div>

      <Button type="submit" size="lg" className="w-full">
        Publish Your Experience
      </Button>
    </form>
  );
}
