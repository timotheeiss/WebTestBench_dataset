import { useState, useMemo } from 'react';
import { Search, FileX, Filter } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { PostCard } from './PostCard';
import { EmptyState } from './EmptyState';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

const companyTypes = ['All', 'Big Tech', 'Startup', 'Finance', 'Consulting', 'Healthcare', 'E-commerce', 'Other'];
const outcomes = ['All', 'Offer Received', 'Rejected', 'Still Pending', 'Withdrew'];

const outcomeMap: Record<string, string> = {
  'Offer Received': 'offer',
  'Rejected': 'rejected',
  'Still Pending': 'pending',
  'Withdrew': 'withdrew',
};

export function BrowsePosts() {
  const { posts, setActiveTab } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [companyTypeFilter, setCompanyTypeFilter] = useState('All');
  const [outcomeFilter, setOutcomeFilter] = useState('All');

  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      const matchesSearch =
        searchQuery === '' ||
        post.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.rounds.some((round) =>
          round.questions.some((q) =>
            q.question.toLowerCase().includes(searchQuery.toLowerCase())
          )
        );

      const matchesCompanyType =
        companyTypeFilter === 'All' || post.companyType === companyTypeFilter;

      const matchesOutcome =
        outcomeFilter === 'All' || post.outcome === outcomeMap[outcomeFilter];

      return matchesSearch && matchesCompanyType && matchesOutcome;
    });
  }, [posts, searchQuery, companyTypeFilter, outcomeFilter]);

  const hasActiveFilters = searchQuery || companyTypeFilter !== 'All' || outcomeFilter !== 'All';

  const clearFilters = () => {
    setSearchQuery('');
    setCompanyTypeFilter('All');
    setOutcomeFilter('All');
  };

  if (posts.length === 0) {
    return (
      <EmptyState
        icon={FileX}
        title="No Interview Experiences Yet"
        description="Be the first to share your interview experience and help others prepare for their journey."
        action={
          <Button onClick={() => setActiveTab('create')}>
            Share Your Experience
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="font-heading text-2xl font-semibold text-foreground">
          Browse Experiences
        </h2>
        <p className="mt-1 text-muted-foreground">
          {posts.length} interview {posts.length === 1 ? 'story' : 'stories'} shared
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 rounded-lg border border-border bg-card p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search companies, positions, or questions..."
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          <Select value={companyTypeFilter} onValueChange={setCompanyTypeFilter}>
            <SelectTrigger className="w-[140px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {companyTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {outcomes.map((outcome) => (
                <SelectItem key={outcome} value={outcome}>
                  {outcome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Results */}
      {filteredPosts.length === 0 ? (
        <EmptyState
          icon={Search}
          title="No Matching Results"
          description="Try adjusting your search or filters to find what you're looking for."
          action={
            hasActiveFilters && (
              <Button variant="outline" onClick={clearFilters}>
                Clear Filters
              </Button>
            )
          }
        />
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
}
