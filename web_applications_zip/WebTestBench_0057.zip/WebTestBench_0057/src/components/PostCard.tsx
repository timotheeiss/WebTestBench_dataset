import { Building2, Calendar, Star, ChevronDown, ChevronUp, Heart } from 'lucide-react';
import { useState } from 'react';
import { InterviewPost } from '@/types/interview';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface PostCardProps {
  post: InterviewPost;
}

const outcomeLabels: Record<InterviewPost['outcome'], { label: string; variant: 'default' | 'success' | 'destructive' | 'secondary' }> = {
  offer: { label: 'Offer Received', variant: 'success' },
  rejected: { label: 'Rejected', variant: 'destructive' },
  pending: { label: 'Pending', variant: 'secondary' },
  withdrew: { label: 'Withdrew', variant: 'default' },
};

export function PostCard({ post }: PostCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { toggleFavorite, isFavorited } = useApp();

  const outcomeInfo = outcomeLabels[post.outcome];
  const formattedDate = new Date(post.interviewDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <article className="overflow-hidden rounded-lg border border-border bg-card shadow-card transition-shadow hover:shadow-card-hover animate-slide-up">
      <div className="p-6">
        {/* Header */}
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                {post.companyType}
              </Badge>
              <Badge variant={outcomeInfo.variant} className="text-xs">
                {outcomeInfo.label}
              </Badge>
            </div>
            <h3 className="font-heading text-xl font-semibold text-foreground">
              {post.companyName}
            </h3>
            <p className="text-sm text-muted-foreground">{post.position}</p>
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={cn(
                  'h-4 w-4',
                  i < post.difficulty ? 'fill-accent text-accent' : 'fill-muted text-muted'
                )}
              />
            ))}
          </div>
        </div>

        {/* Meta info */}
        <div className="mb-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Building2 className="h-4 w-4" />
            {post.rounds.length} round{post.rounds.length !== 1 ? 's' : ''}
          </span>
          <span className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4" />
            {formattedDate}
          </span>
          <span>By {post.authorName}</span>
        </div>

        {/* Expand/Collapse button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full justify-between"
        >
          <span>{isExpanded ? 'Hide Details' : 'Show Interview Details'}</span>
          {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>

      {/* Expanded content */}
      {isExpanded && (
        <div className="border-t border-border bg-secondary/30 px-6 py-4">
          {/* Interview rounds */}
          <div className="space-y-4">
            {post.rounds.map((round) => (
              <div key={round.id}>
                <h4 className="mb-2 font-medium text-foreground">
                  Round {round.roundNumber}: {round.roundType}
                </h4>
                <ul className="space-y-3">
                  {round.questions.map((q) => {
                    const favorited = isFavorited(q.id);
                    return (
                      <li
                        key={q.id}
                        className="rounded-md border border-border bg-card p-3"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{q.question}</p>
                            {q.answer && (
                              <p className="mt-1 text-sm text-muted-foreground">
                                {q.answer}
                              </p>
                            )}
                          </div>
                          <button
                            onClick={() => toggleFavorite(q.id, post.id)}
                            className={cn(
                              'flex-shrink-0 rounded-full p-2 transition-colors',
                              favorited
                                ? 'bg-accent/10 text-accent hover:bg-accent/20'
                                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                            )}
                            title={favorited ? 'Remove from favorites' : 'Add to favorites'}
                          >
                            <Heart
                              className={cn('h-4 w-4', favorited && 'fill-current')}
                            />
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>

          {/* Reflection */}
          {post.reflection && (
            <div className="mt-4 border-t border-border pt-4">
              <h4 className="mb-2 font-medium text-foreground">Personal Reflection</h4>
              <p className="text-sm text-muted-foreground">{post.reflection}</p>
            </div>
          )}
        </div>
      )}
    </article>
  );
}
