import { Heart, Trash2, Building2, Briefcase } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { EmptyState } from './EmptyState';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function MyFavorites() {
  const { favorites, toggleFavorite, setActiveTab } = useApp();

  if (favorites.length === 0) {
    return (
      <EmptyState
        icon={Heart}
        title="No Favorites Yet"
        description="Browse interview experiences and save questions you find helpful for easy reference later."
        action={
          <Button onClick={() => setActiveTab('browse')}>
            Browse Experiences
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="font-heading text-2xl font-semibold text-foreground">
          My Saved Questions
        </h2>
        <p className="mt-1 text-muted-foreground">
          {favorites.length} question{favorites.length !== 1 ? 's' : ''} saved for later review
        </p>
      </div>

      <div className="space-y-3">
        {favorites.map((fav) => (
          <div
            key={fav.questionId}
            className="group rounded-lg border border-border bg-card p-4 shadow-card transition-shadow hover:shadow-card-hover animate-slide-up"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <p className="font-medium text-foreground">{fav.question}</p>
                <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5" />
                    {fav.companyName}
                  </span>
                  <span className="text-border">•</span>
                  <span className="flex items-center gap-1">
                    <Briefcase className="h-3.5 w-3.5" />
                    {fav.position}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {fav.roundType}
                  </Badge>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => toggleFavorite(fav.questionId, fav.postId)}
                className="flex-shrink-0 text-accent hover:bg-accent/10 hover:text-accent"
                title="Remove from favorites"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
