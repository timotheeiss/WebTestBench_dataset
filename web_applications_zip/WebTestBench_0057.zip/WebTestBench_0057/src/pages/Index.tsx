import { AppProvider, useApp } from '@/context/AppContext';
import { Header } from '@/components/Header';
import { TabNavigation } from '@/components/TabNavigation';
import { CreatePost } from '@/components/CreatePost';
import { BrowsePosts } from '@/components/BrowsePosts';
import { MyFavorites } from '@/components/MyFavorites';

function MainContent() {
  const { activeTab } = useApp();

  return (
    <main className="container mx-auto px-4 py-8">
      {activeTab === 'create' && <CreatePost />}
      {activeTab === 'browse' && <BrowsePosts />}
      {activeTab === 'favorites' && <MyFavorites />}
    </main>
  );
}

const Index = () => {
  return (
    <AppProvider>
      <div className="min-h-screen bg-background">
        <Header />
        <TabNavigation />
        <MainContent />
      </div>
    </AppProvider>
  );
};

export default Index;
