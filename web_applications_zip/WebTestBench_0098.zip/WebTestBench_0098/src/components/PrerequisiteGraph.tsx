import { useMemo } from 'react';
import { DependencyGraph } from '@/utils/prerequisiteAnalysis';

interface PrerequisiteGraphProps {
  graph: DependencyGraph;
}

interface NodePosition {
  id: string;
  x: number;
  y: number;
  code: string;
  name: string;
  isCompleted?: boolean;
  isEnrolled?: boolean;
  isCurrent?: boolean;
}

export function PrerequisiteGraph({ graph }: PrerequisiteGraphProps) {
  const { positions, width, height } = useMemo(() => {
    if (graph.nodes.length === 0) {
      return { positions: [], width: 400, height: 200 };
    }

    // Group nodes by level
    const levelGroups = new Map<number, typeof graph.nodes>();
    for (const node of graph.nodes) {
      const level = node.level;
      if (!levelGroups.has(level)) {
        levelGroups.set(level, []);
      }
      levelGroups.get(level)!.push(node);
    }

    const levels = Array.from(levelGroups.keys()).sort((a, b) => b - a);
    const nodeWidth = 140;
    const nodeHeight = 60;
    const horizontalGap = 40;
    const verticalGap = 80;

    const maxNodesInLevel = Math.max(...levels.map(l => levelGroups.get(l)!.length));
    const calculatedWidth = Math.max(400, maxNodesInLevel * (nodeWidth + horizontalGap) + 80);
    const calculatedHeight = Math.max(200, levels.length * (nodeHeight + verticalGap) + 80);

    const nodePositions: NodePosition[] = [];

    levels.forEach((level, levelIndex) => {
      const nodesAtLevel = levelGroups.get(level)!;
      const levelWidth = nodesAtLevel.length * (nodeWidth + horizontalGap) - horizontalGap;
      const startX = (calculatedWidth - levelWidth) / 2;

      nodesAtLevel.forEach((node, nodeIndex) => {
        nodePositions.push({
          id: node.id,
          x: startX + nodeIndex * (nodeWidth + horizontalGap) + nodeWidth / 2,
          y: 40 + levelIndex * (nodeHeight + verticalGap) + nodeHeight / 2,
          code: node.code,
          name: node.name,
          isCompleted: node.isCompleted,
          isEnrolled: node.isEnrolled,
          isCurrent: node.isCurrent,
        });
      });
    });

    return { positions: nodePositions, width: calculatedWidth, height: calculatedHeight };
  }, [graph]);

  const positionMap = useMemo(() => 
    new Map(positions.map(p => [p.id, p])),
    [positions]
  );

  if (graph.nodes.length === 0) {
    return (
      <div className="flex items-center justify-center h-32 text-muted-foreground">
        No prerequisites or dependents
      </div>
    );
  }

  return (
    <div className="overflow-auto rounded-lg border border-border bg-muted/30">
      <svg 
        width={width} 
        height={height} 
        className="min-w-full"
        style={{ minHeight: height }}
      >
        <defs>
          <marker
            id="arrowhead"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon
              points="0 0, 10 3.5, 0 7"
              fill="hsl(var(--muted-foreground))"
            />
          </marker>
          <marker
            id="arrowhead-cycle"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon
              points="0 0, 10 3.5, 0 7"
              fill="hsl(var(--destructive))"
            />
          </marker>
        </defs>

        {/* Edges */}
        {graph.edges.map((edge, i) => {
          const from = positionMap.get(edge.from);
          const to = positionMap.get(edge.to);
          if (!from || !to) return null;

          const isCycleEdge = graph.cycleNodes.includes(edge.from) && graph.cycleNodes.includes(edge.to);

          // Calculate control points for curved edges
          const midX = (from.x + to.x) / 2;
          const midY = (from.y + to.y) / 2;
          const dx = to.x - from.x;
          const dy = to.y - from.y;
          const len = Math.sqrt(dx * dx + dy * dy);
          
          // Offset control point perpendicular to the line
          const offsetX = 0;
          const offsetY = 0;
          
          const path = `M ${from.x} ${from.y + 30} Q ${midX + offsetX} ${midY + offsetY} ${to.x} ${to.y - 30}`;

          return (
            <path
              key={i}
              d={path}
              fill="none"
              stroke={isCycleEdge ? 'hsl(var(--destructive))' : 'hsl(var(--muted-foreground))'}
              strokeWidth={isCycleEdge ? 2 : 1.5}
              strokeDasharray={isCycleEdge ? '5,5' : 'none'}
              markerEnd={isCycleEdge ? 'url(#arrowhead-cycle)' : 'url(#arrowhead)'}
              opacity={0.6}
            />
          );
        })}

        {/* Nodes */}
        {positions.map((pos) => {
          const isCycle = graph.cycleNodes.includes(pos.id);
          
          let fillColor = 'hsl(var(--card))';
          let strokeColor = 'hsl(var(--border))';
          let textColor = 'hsl(var(--card-foreground))';
          
          if (isCycle) {
            strokeColor = 'hsl(var(--destructive))';
          } else if (pos.isCurrent) {
            fillColor = 'hsl(var(--primary))';
            textColor = 'hsl(var(--primary-foreground))';
            strokeColor = 'hsl(var(--primary))';
          } else if (pos.isCompleted) {
            fillColor = 'hsl(var(--success) / 0.15)';
            strokeColor = 'hsl(var(--success))';
          } else if (pos.isEnrolled) {
            fillColor = 'hsl(var(--secondary) / 0.15)';
            strokeColor = 'hsl(var(--secondary))';
          }

          return (
            <g key={pos.id}>
              <rect
                x={pos.x - 70}
                y={pos.y - 30}
                width={140}
                height={60}
                rx={8}
                fill={fillColor}
                stroke={strokeColor}
                strokeWidth={isCycle ? 2 : 1.5}
                strokeDasharray={isCycle ? '5,5' : 'none'}
                className="drop-shadow-sm"
              />
              <text
                x={pos.x}
                y={pos.y - 6}
                textAnchor="middle"
                fill={pos.isCurrent ? textColor : 'hsl(var(--foreground))'}
                className="text-xs font-semibold font-display"
              >
                {pos.code}
              </text>
              <text
                x={pos.x}
                y={pos.y + 10}
                textAnchor="middle"
                fill={pos.isCurrent ? 'hsl(var(--primary-foreground) / 0.8)' : 'hsl(var(--muted-foreground))'}
                className="text-[10px]"
              >
                {pos.name.length > 18 ? pos.name.substring(0, 16) + '...' : pos.name}
              </text>
              
              {/* Status indicators */}
              {pos.isCompleted && !pos.isCurrent && (
                <circle
                  cx={pos.x + 60}
                  cy={pos.y - 20}
                  r={8}
                  fill="hsl(var(--success))"
                />
              )}
              {pos.isEnrolled && !pos.isCurrent && (
                <circle
                  cx={pos.x + 60}
                  cy={pos.y - 20}
                  r={8}
                  fill="hsl(var(--secondary))"
                />
              )}
            </g>
          );
        })}
      </svg>
      
      {/* Legend */}
      <div className="flex flex-wrap gap-4 p-3 border-t border-border bg-card/50">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="w-3 h-3 rounded-sm bg-primary" />
          <span>Current Course</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="w-3 h-3 rounded-sm border-2 border-success bg-success/15" />
          <span>Completed</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="w-3 h-3 rounded-sm border-2 border-secondary bg-secondary/15" />
          <span>Enrolled</span>
        </div>
        {graph.hasCycle && (
          <div className="flex items-center gap-2 text-xs text-destructive">
            <div className="w-3 h-3 rounded-sm border-2 border-destructive border-dashed" />
            <span>Cyclic Dependency</span>
          </div>
        )}
      </div>
    </div>
  );
}
