import { Course } from '@/data/courses';
import { DependencyGraph } from '@/utils/prerequisiteAnalysis';
import { EnrollmentWarning } from '@/utils/conflictDetection';
import { PrerequisiteGraph } from './PrerequisiteGraph';
import { WarningList } from './WarningBadge';
import { Button } from '@/components/ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription 
} from '@/components/ui/dialog';
import { 
  X, 
  Clock, 
  Users, 
  BookOpen, 
  User, 
  Building,
  Check,
  Plus,
  Minus,
  AlertTriangle
} from 'lucide-react';
import { formatSchedule } from '@/utils/conflictDetection';
import { cn } from '@/lib/utils';

interface CourseDetailProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
  isEnrolled: boolean;
  isCompleted: boolean;
  canEnroll: boolean;
  warnings: EnrollmentWarning[];
  dependencyGraph: DependencyGraph | null;
  onEnroll: () => void;
  onDrop: () => void;
  onMarkCompleted: () => void;
  onUnmarkCompleted: () => void;
}

export function CourseDetail({
  course,
  isOpen,
  onClose,
  isEnrolled,
  isCompleted,
  canEnroll,
  warnings,
  dependencyGraph,
  onEnroll,
  onDrop,
  onMarkCompleted,
  onUnmarkCompleted,
}: CourseDetailProps) {
  if (!course) return null;

  const seatPercentage = (course.availableSeats / course.totalSeats) * 100;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto p-0">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-gradient-primary text-primary-foreground p-6">
          <DialogHeader>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-medium opacity-80">{course.department}</span>
                  <span 
                    className={cn(
                      'text-xs px-2 py-0.5 rounded-full bg-white/20',
                      course.level === 'Introductory' && 'bg-success/30',
                      course.level === 'Intermediate' && 'bg-warning/30',
                      course.level === 'Advanced' && 'bg-destructive/30'
                    )}
                  >
                    {course.level}
                  </span>
                </div>
                <DialogTitle className="text-2xl font-display">
                  {course.code}: {course.name}
                </DialogTitle>
                <DialogDescription className="text-primary-foreground/80 mt-2">
                  {course.description}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          {/* Quick stats */}
          <div className="flex flex-wrap gap-4 mt-4">
            <div className="flex items-center gap-2 text-sm">
              <BookOpen className="w-4 h-4" />
              <span>{course.credits} credits</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <User className="w-4 h-4" />
              <span>{course.instructor}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4" />
              <span>{formatSchedule(course.schedule)}</span>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Status and Actions */}
          <div className="flex flex-wrap items-center gap-4">
            {isCompleted ? (
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-success/10 text-success">
                <Check className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            ) : isEnrolled ? (
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/10 text-primary">
                <BookOpen className="w-5 h-5" />
                <span className="font-medium">Currently Enrolled</span>
              </div>
            ) : null}

            <div className="flex gap-2 ml-auto">
              {isCompleted ? (
                <Button variant="outline" onClick={onUnmarkCompleted}>
                  <Minus className="w-4 h-4 mr-2" />
                  Remove Completion
                </Button>
              ) : (
                <Button variant="outline" onClick={onMarkCompleted}>
                  <Check className="w-4 h-4 mr-2" />
                  Mark as Completed
                </Button>
              )}
              
              {isEnrolled ? (
                <Button variant="destructive" onClick={onDrop}>
                  <Minus className="w-4 h-4 mr-2" />
                  Drop Course
                </Button>
              ) : (
                <Button 
                  onClick={onEnroll} 
                  disabled={!canEnroll}
                  className="bg-gradient-primary hover:opacity-90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Enroll
                </Button>
              )}
            </div>
          </div>

          {/* Warnings */}
          {warnings.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Enrollment Warnings
              </h3>
              <WarningList warnings={warnings} />
            </div>
          )}

          {/* Seat Availability */}
          <div className="p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span>Seat Availability</span>
              </div>
              <span 
                className={cn(
                  'text-sm font-semibold',
                  course.availableSeats === 0 && 'text-destructive',
                  course.availableSeats <= 5 && course.availableSeats > 0 && 'text-warning',
                  course.availableSeats > 5 && 'text-success'
                )}
              >
                {course.availableSeats} / {course.totalSeats} seats available
              </span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn(
                  'h-full rounded-full transition-all duration-500',
                  course.availableSeats === 0 && 'bg-destructive',
                  course.availableSeats <= 5 && course.availableSeats > 0 && 'bg-warning',
                  course.availableSeats > 5 && 'bg-success'
                )}
                style={{ width: `${seatPercentage}%` }}
              />
            </div>
          </div>

          {/* Prerequisite Graph */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">
              Prerequisite & Dependency Chain
            </h3>
            {dependencyGraph && (
              <PrerequisiteGraph graph={dependencyGraph} />
            )}
          </div>

          {/* Additional Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Building className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">Department</span>
              </div>
              <p className="text-sm text-muted-foreground">{course.department}</p>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <User className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">Instructor</span>
              </div>
              <p className="text-sm text-muted-foreground">{course.instructor}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
