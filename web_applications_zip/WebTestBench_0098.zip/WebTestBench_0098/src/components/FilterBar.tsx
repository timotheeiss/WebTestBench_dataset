import { cn } from '@/lib/utils';
import { Building, Layers, Filter } from 'lucide-react';

interface FilterBarProps {
  departments: string[];
  levels: string[];
  selectedDepartment: string | null;
  selectedLevel: string | null;
  onDepartmentChange: (dept: string | null) => void;
  onLevelChange: (level: string | null) => void;
}

export function FilterBar({
  departments,
  levels,
  selectedDepartment,
  selectedLevel,
  onDepartmentChange,
  onLevelChange,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap gap-4 p-4 bg-card rounded-xl border border-border">
      {/* Department Filter */}
      <div className="flex items-center gap-2">
        <Building className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm font-medium text-muted-foreground">Department:</span>
        <div className="flex flex-wrap gap-1">
          <button
            onClick={() => onDepartmentChange(null)}
            className={cn(
              'px-3 py-1 rounded-full text-xs font-medium transition-colors',
              selectedDepartment === null
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            )}
          >
            All
          </button>
          {departments.map(dept => (
            <button
              key={dept}
              onClick={() => onDepartmentChange(dept)}
              className={cn(
                'px-3 py-1 rounded-full text-xs font-medium transition-colors',
                selectedDepartment === dept
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              )}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>

      <div className="h-6 w-px bg-border" />

      {/* Level Filter */}
      <div className="flex items-center gap-2">
        <Layers className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm font-medium text-muted-foreground">Level:</span>
        <div className="flex flex-wrap gap-1">
          <button
            onClick={() => onLevelChange(null)}
            className={cn(
              'px-3 py-1 rounded-full text-xs font-medium transition-colors',
              selectedLevel === null
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            )}
          >
            All
          </button>
          {levels.map(level => (
            <button
              key={level}
              onClick={() => onLevelChange(level)}
              className={cn(
                'px-3 py-1 rounded-full text-xs font-medium transition-colors',
                selectedLevel === level
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
            )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
