import { AlertTriangle, XCircle, AlertCircle, Clock, Users } from 'lucide-react';
import { EnrollmentWarning } from '@/utils/conflictDetection';
import { cn } from '@/lib/utils';

interface WarningBadgeProps {
  warning: EnrollmentWarning;
  compact?: boolean;
}

const iconMap = {
  time_conflict: Clock,
  unmet_prerequisite: AlertCircle,
  cycle_detected: AlertTriangle,
  no_seats: XCircle,
  low_seats: Users,
};

export function WarningBadge({ warning, compact = false }: WarningBadgeProps) {
  const Icon = iconMap[warning.type];
  
  if (compact) {
    return (
      <div
        className={cn(
          'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium',
          warning.severity === 'error' 
            ? 'bg-destructive/10 text-destructive' 
            : 'bg-warning/10 text-warning'
        )}
      >
        <Icon className="w-3 h-3" />
        <span className="capitalize">{warning.type.replace('_', ' ')}</span>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex items-start gap-3 p-3 rounded-lg',
        warning.severity === 'error' 
          ? 'bg-destructive/10 border border-destructive/20' 
          : 'bg-warning/10 border border-warning/20'
      )}
    >
      <Icon 
        className={cn(
          'w-5 h-5 mt-0.5 flex-shrink-0',
          warning.severity === 'error' ? 'text-destructive' : 'text-warning'
        )} 
      />
      <div className="flex-1 min-w-0">
        <p 
          className={cn(
            'text-sm font-medium',
            warning.severity === 'error' ? 'text-destructive' : 'text-warning'
          )}
        >
          {warning.message}
        </p>
        {warning.relatedCourses && warning.relatedCourses.length > 0 && (
          <p className="text-xs text-muted-foreground mt-1">
            Related: {warning.relatedCourses.map(c => c.code).join(', ')}
          </p>
        )}
      </div>
    </div>
  );
}

interface WarningListProps {
  warnings: EnrollmentWarning[];
}

export function WarningList({ warnings }: WarningListProps) {
  if (warnings.length === 0) return null;

  return (
    <div className="space-y-2">
      {warnings.map((warning, index) => (
        <WarningBadge key={index} warning={warning} />
      ))}
    </div>
  );
}
