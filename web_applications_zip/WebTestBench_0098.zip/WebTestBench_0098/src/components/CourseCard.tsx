import { Course } from '@/data/courses';
import { cn } from '@/lib/utils';
import { Clock, Users, BookOpen, Check, AlertTriangle } from 'lucide-react';
import { formatSchedule } from '@/utils/conflictDetection';
import { EnrollmentWarning } from '@/utils/conflictDetection';
import { WarningBadge } from './WarningBadge';

interface CourseCardProps {
  course: Course;
  isEnrolled: boolean;
  isCompleted: boolean;
  warnings: EnrollmentWarning[];
  onClick: () => void;
}

export function CourseCard({ course, isEnrolled, isCompleted, warnings, onClick }: CourseCardProps) {
  const hasErrors = warnings.some(w => w.severity === 'error');
  const hasWarnings = warnings.some(w => w.severity === 'warning');
  const seatPercentage = (course.availableSeats / course.totalSeats) * 100;

  return (
    <div
      onClick={onClick}
      className={cn(
        'group relative bg-card rounded-xl border border-border p-5 cursor-pointer transition-all duration-300',
        'hover:shadow-card-hover hover:-translate-y-1',
        isEnrolled && 'ring-2 ring-primary ring-offset-2 ring-offset-background',
        isCompleted && 'bg-success/5 border-success/30'
      )}
    >
      {/* Status badges */}
      <div className="absolute top-4 right-4 flex gap-2">
        {isCompleted && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-success/10 text-success text-xs font-medium">
            <Check className="w-3 h-3" />
            Completed
          </div>
        )}
        {isEnrolled && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
            <BookOpen className="w-3 h-3" />
            Enrolled
          </div>
        )}
      </div>

      {/* Course code and name */}
      <div className="mb-3">
        <div className="text-xs font-medium text-muted-foreground mb-1">
          {course.department}
        </div>
        <h3 className="font-display text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
          {course.code}
        </h3>
        <p className="text-sm text-muted-foreground mt-0.5">
          {course.name}
        </p>
      </div>

      {/* Meta info */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <BookOpen className="w-3.5 h-3.5" />
          <span>{course.credits} credits</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="w-3.5 h-3.5" />
          <span>{formatSchedule(course.schedule)}</span>
        </div>
      </div>

      {/* Seat availability */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Users className="w-3.5 h-3.5" />
            <span>
              {course.availableSeats} / {course.totalSeats} seats
            </span>
          </div>
          <span 
            className={cn(
              'text-xs font-medium',
              course.availableSeats === 0 && 'text-destructive',
              course.availableSeats <= 5 && course.availableSeats > 0 && 'text-warning',
              course.availableSeats > 5 && 'text-success'
            )}
          >
            {course.availableSeats === 0 ? 'Full' : 
             course.availableSeats <= 5 ? 'Low' : 'Available'}
          </span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div 
            className={cn(
              'h-full rounded-full transition-all duration-500',
              course.availableSeats === 0 && 'bg-destructive',
              course.availableSeats <= 5 && course.availableSeats > 0 && 'bg-warning',
              course.availableSeats > 5 && 'bg-success'
            )}
            style={{ width: `${seatPercentage}%` }}
          />
        </div>
      </div>

      {/* Prerequisites */}
      {course.prerequisites.length > 0 && (
        <div className="text-xs text-muted-foreground mb-3">
          <span className="font-medium">Prerequisites: </span>
          {course.prerequisites.join(', ').toUpperCase()}
        </div>
      )}

      {/* Warnings */}
      {(hasErrors || hasWarnings) && (
        <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-border">
          {warnings.slice(0, 2).map((warning, i) => (
            <WarningBadge key={i} warning={warning} compact />
          ))}
          {warnings.length > 2 && (
            <span className="text-xs text-muted-foreground">
              +{warnings.length - 2} more
            </span>
          )}
        </div>
      )}

      {/* Level badge */}
      <div 
        className={cn(
          'absolute bottom-4 right-4 text-[10px] font-medium px-2 py-0.5 rounded-full',
          course.level === 'Introductory' && 'bg-success/10 text-success',
          course.level === 'Intermediate' && 'bg-warning/10 text-warning',
          course.level === 'Advanced' && 'bg-destructive/10 text-destructive'
        )}
      >
        {course.level}
      </div>
    </div>
  );
}
