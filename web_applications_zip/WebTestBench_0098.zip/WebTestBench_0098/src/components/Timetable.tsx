import { Course, TimeSlot } from '@/data/courses';
import { cn } from '@/lib/utils';
import { X, GraduationCap } from 'lucide-react';

interface TimetableProps {
  enrolledCourses: Course[];
  onDropCourse: (courseId: string) => void;
  totalCredits: number;
}

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] as const;
const HOURS = Array.from({ length: 10 }, (_, i) => i + 8); // 8:00 to 17:00

const COLORS = [
  'bg-primary/80 text-primary-foreground border-primary',
  'bg-secondary/80 text-secondary-foreground border-secondary',
  'bg-success/80 text-success-foreground border-success',
  'bg-violet-500/80 text-white border-violet-500',
  'bg-rose-500/80 text-white border-rose-500',
  'bg-cyan-500/80 text-white border-cyan-500',
  'bg-orange-500/80 text-white border-orange-500',
];

function timeToRow(time: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  return (hours - 8) * 2 + (minutes >= 30 ? 1 : 0);
}

function getSlotStyle(slot: TimeSlot) {
  const startRow = timeToRow(slot.startTime);
  const endRow = timeToRow(slot.endTime);
  const dayIndex = DAYS.indexOf(slot.day);

  return {
    gridColumn: dayIndex + 2,
    gridRow: `${startRow + 2} / ${endRow + 2}`,
  };
}

export function Timetable({ enrolledCourses, onDropCourse, totalCredits }: TimetableProps) {
  // Create color mapping for courses
  const courseColors = new Map<string, string>();
  enrolledCourses.forEach((course, index) => {
    courseColors.set(course.id, COLORS[index % COLORS.length]);
  });

  return (
    <div className="bg-card rounded-xl border border-border shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-primary p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary-foreground">
            <GraduationCap className="w-5 h-5" />
            <h2 className="text-lg font-display font-semibold">My Timetable</h2>
          </div>
          <div className="text-sm text-primary-foreground/80">
            <span className="font-semibold">{totalCredits}</span> credits
          </div>
        </div>
      </div>

      {/* Timetable Grid */}
      <div className="p-4 overflow-x-auto">
        {enrolledCourses.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <GraduationCap className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No courses enrolled yet</p>
            <p className="text-xs mt-1">Select a course to add it to your timetable</p>
          </div>
        ) : (
          <div 
            className="grid gap-px bg-border rounded-lg overflow-hidden"
            style={{
              gridTemplateColumns: '60px repeat(5, minmax(100px, 1fr))',
              gridTemplateRows: `40px repeat(${HOURS.length * 2}, 24px)`,
            }}
          >
            {/* Header row */}
            <div className="bg-muted" />
            {DAYS.map(day => (
              <div 
                key={day} 
                className="bg-muted flex items-center justify-center text-sm font-medium text-muted-foreground"
              >
                {day}
              </div>
            ))}

            {/* Time slots */}
            {HOURS.map(hour => (
              <>
                <div 
                  key={`time-${hour}`}
                  className="bg-background text-xs text-muted-foreground flex items-start justify-end pr-2 pt-0.5"
                  style={{ gridRow: `span 2` }}
                >
                  {hour}:00
                </div>
                {DAYS.map(day => (
                  <>
                    <div key={`${day}-${hour}-1`} className="bg-background border-t border-dashed border-border/50" />
                  </>
                ))}
                {DAYS.map(day => (
                  <div key={`${day}-${hour}-2`} className="bg-background" />
                ))}
              </>
            ))}

            {/* Course blocks */}
            {enrolledCourses.flatMap(course =>
              course.schedule.map((slot, slotIndex) => (
                <div
                  key={`${course.id}-${slotIndex}`}
                  className={cn(
                    'rounded-md p-1.5 m-0.5 flex flex-col justify-between group cursor-pointer transition-all hover:scale-[1.02] border-l-2',
                    courseColors.get(course.id)
                  )}
                  style={getSlotStyle(slot)}
                >
                  <div className="min-w-0">
                    <div className="text-[10px] font-semibold truncate">{course.code}</div>
                    <div className="text-[9px] opacity-80 truncate">{course.name}</div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDropCourse(course.id);
                    }}
                    className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-full p-0.5"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Enrolled courses list */}
      {enrolledCourses.length > 0 && (
        <div className="border-t border-border p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Enrolled Courses</h3>
          <div className="flex flex-wrap gap-2">
            {enrolledCourses.map(course => (
              <div
                key={course.id}
                className={cn(
                  'inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border-l-2',
                  courseColors.get(course.id)
                )}
              >
                <span>{course.code}</span>
                <span className="opacity-70">({course.credits}cr)</span>
                <button
                  onClick={() => onDropCourse(course.id)}
                  className="ml-1 opacity-60 hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
