import { useState, useCallback, useMemo } from 'react';
import { Course, courses as initialCourses } from '@/data/courses';
import { getEnrollmentWarnings, EnrollmentWarning } from '@/utils/conflictDetection';
import { buildDependencyGraph } from '@/utils/prerequisiteAnalysis';

export function useEnrollment() {
  const [courses, setCourses] = useState<Course[]>(initialCourses);
  const [enrolledCourseIds, setEnrolledCourseIds] = useState<string[]>([]);
const [completedCourseIds, setCompletedCourseIds] = useState<string[]>([
    'cs101', 'math101', 'math201' // Pre-completed courses for demo
  ]);

  const enrolledCourses = useMemo(() => 
    courses.filter(c => enrolledCourseIds.includes(c.id)),
    [courses, enrolledCourseIds]
  );

  const totalCredits = useMemo(() => 
    enrolledCourses.reduce((sum, c) => sum + c.credits, 0),
    [enrolledCourses]
  );

  const getWarningsForCourse = useCallback((course: Course) => {
    const graph = buildDependencyGraph(
      course.id,
      courses,
      completedCourseIds,
      enrolledCourseIds
    );
    
    return getEnrollmentWarnings(
      course,
      enrolledCourses,
      completedCourseIds,
      courses,
      graph.hasCycle
    );
  }, [courses, enrolledCourseIds, completedCourseIds, enrolledCourses]);

  const canEnroll = useCallback((course: Course): boolean => {
    if (enrolledCourseIds.includes(course.id)) return false;
    const warnings = getWarningsForCourse(course);
    return !warnings.some(w => w.severity === 'error');
  }, [enrolledCourseIds, getWarningsForCourse]);

  const enroll = useCallback((courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    if (!course || !canEnroll(course)) return false;

    setEnrolledCourseIds(prev => [...prev, courseId]);
    setCourses(prev => prev.map(c => 
      c.id === courseId 
        ? { ...c, availableSeats: c.availableSeats - 1 }
        : c
    ));
    return true;
  }, [courses, canEnroll]);

  const drop = useCallback((courseId: string) => {
    if (!enrolledCourseIds.includes(courseId)) return false;

    setEnrolledCourseIds(prev => prev.filter(id => id !== courseId));
    setCourses(prev => prev.map(c => 
      c.id === courseId 
        ? { ...c, availableSeats: c.availableSeats + 1 }
        : c
    ));
    return true;
  }, [enrolledCourseIds]);

  const markCompleted = useCallback((courseId: string) => {
    if (!completedCourseIds.includes(courseId)) {
      setCompletedCourseIds(prev => [...prev, courseId]);
    }
  }, [completedCourseIds]);

  const unmarkCompleted = useCallback((courseId: string) => {
    setCompletedCourseIds(prev => prev.filter(id => id !== courseId));
  }, []);

  const isEnrolled = useCallback((courseId: string) => 
    enrolledCourseIds.includes(courseId),
    [enrolledCourseIds]
  );

  const isCompleted = useCallback((courseId: string) => 
    completedCourseIds.includes(courseId),
    [completedCourseIds]
  );

  const getDependencyGraph = useCallback((courseId: string) => 
    buildDependencyGraph(
      courseId,
      courses,
      completedCourseIds,
      enrolledCourseIds
    ),
    [courses, completedCourseIds, enrolledCourseIds]
  );

  return {
    courses,
    enrolledCourses,
    enrolledCourseIds,
    completedCourseIds,
    totalCredits,
    enroll,
    drop,
    canEnroll,
    isEnrolled,
    isCompleted,
    markCompleted,
    unmarkCompleted,
    getWarningsForCourse,
    getDependencyGraph,
  };
}
