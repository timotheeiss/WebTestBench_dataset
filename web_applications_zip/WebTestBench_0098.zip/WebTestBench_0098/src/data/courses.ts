export interface TimeSlot {
  day: 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri';
  startTime: string;
  endTime: string;
}

export interface Course {
  id: string;
  code: string;
  name: string;
  credits: number;
  totalSeats: number;
  availableSeats: number;
  instructor: string;
  description: string;
  schedule: TimeSlot[];
  prerequisites: string[]; // Course IDs
  department: string;
  level: 'Introductory' | 'Intermediate' | 'Advanced';
}

export const courses: Course[] = [
  {
    id: 'cs101',
    code: 'CS 101',
    name: 'Introduction to Computer Science',
    credits: 3,
    totalSeats: 120,
    availableSeats: 45,
    instructor: 'Dr. Sarah Chen',
    description: 'Fundamental concepts of computer science including problem-solving, algorithms, data representation, and an introduction to programming using Python.',
    schedule: [
      { day: 'Mon', startTime: '09:00', endTime: '10:30' },
      { day: 'Wed', startTime: '09:00', endTime: '10:30' },
    ],
    prerequisites: [],
    department: 'Computer Science',
    level: 'Introductory',
  },
  {
    id: 'cs201',
    code: 'CS 201',
    name: 'Data Structures',
    credits: 4,
    totalSeats: 80,
    availableSeats: 12,
    instructor: 'Prof. Michael Torres',
    description: 'Study of fundamental data structures including arrays, linked lists, stacks, queues, trees, and graphs. Analysis of algorithms for manipulating these structures.',
    schedule: [
      { day: 'Tue', startTime: '11:00', endTime: '12:30' },
      { day: 'Thu', startTime: '11:00', endTime: '12:30' },
    ],
    prerequisites: ['cs101'],
    department: 'Computer Science',
    level: 'Intermediate',
  },
  {
    id: 'cs301',
    code: 'CS 301',
    name: 'Algorithms',
    credits: 4,
    totalSeats: 60,
    availableSeats: 8,
    instructor: 'Dr. Emily Watson',
    description: 'Design and analysis of algorithms. Topics include divide-and-conquer, dynamic programming, greedy algorithms, graph algorithms, and NP-completeness.',
    schedule: [
      { day: 'Mon', startTime: '14:00', endTime: '15:30' },
      { day: 'Wed', startTime: '14:00', endTime: '15:30' },
    ],
    prerequisites: ['cs201', 'math201'],
    department: 'Computer Science',
    level: 'Advanced',
  },
  {
    id: 'cs302',
    code: 'CS 302',
    name: 'Database Systems',
    credits: 3,
    totalSeats: 70,
    availableSeats: 23,
    instructor: 'Prof. James Liu',
    description: 'Introduction to database management systems, relational model, SQL, database design, transaction processing, and query optimization.',
    schedule: [
      { day: 'Tue', startTime: '14:00', endTime: '15:30' },
      { day: 'Thu', startTime: '14:00', endTime: '15:30' },
    ],
    prerequisites: ['cs201'],
    department: 'Computer Science',
    level: 'Intermediate',
  },
  {
    id: 'cs401',
    code: 'CS 401',
    name: 'Machine Learning',
    credits: 4,
    totalSeats: 50,
    availableSeats: 3,
    instructor: 'Dr. Priya Sharma',
    description: 'Introduction to machine learning algorithms including supervised and unsupervised learning, neural networks, and deep learning fundamentals.',
    schedule: [
      { day: 'Mon', startTime: '11:00', endTime: '12:30' },
      { day: 'Wed', startTime: '11:00', endTime: '12:30' },
    ],
    prerequisites: ['cs301', 'math301'],
    department: 'Computer Science',
    level: 'Advanced',
  },
  {
    id: 'cs402',
    code: 'CS 402',
    name: 'Distributed Systems',
    credits: 3,
    totalSeats: 45,
    availableSeats: 15,
    instructor: 'Prof. Robert Kim',
    description: 'Principles of distributed computing, consistency models, fault tolerance, distributed storage, and large-scale system design.',
    schedule: [
      { day: 'Fri', startTime: '09:00', endTime: '12:00' },
    ],
    prerequisites: ['cs301', 'cs302'],
    department: 'Computer Science',
    level: 'Advanced',
  },
  {
    id: 'math101',
    code: 'MATH 101',
    name: 'Calculus I',
    credits: 4,
    totalSeats: 150,
    availableSeats: 67,
    instructor: 'Dr. Anna Martinez',
    description: 'Introduction to differential calculus including limits, derivatives, and applications to optimization and related rates problems.',
    schedule: [
      { day: 'Mon', startTime: '10:00', endTime: '11:00' },
      { day: 'Wed', startTime: '10:00', endTime: '11:00' },
      { day: 'Fri', startTime: '10:00', endTime: '11:00' },
    ],
    prerequisites: [],
    department: 'Mathematics',
    level: 'Introductory',
  },
  {
    id: 'math201',
    code: 'MATH 201',
    name: 'Linear Algebra',
    credits: 3,
    totalSeats: 100,
    availableSeats: 34,
    instructor: 'Prof. David Park',
    description: 'Vector spaces, linear transformations, matrices, determinants, eigenvalues and eigenvectors, with applications.',
    schedule: [
      { day: 'Tue', startTime: '09:00', endTime: '10:30' },
      { day: 'Thu', startTime: '09:00', endTime: '10:30' },
    ],
    prerequisites: ['math101'],
    department: 'Mathematics',
    level: 'Intermediate',
  },
  {
    id: 'math301',
    code: 'MATH 301',
    name: 'Probability & Statistics',
    credits: 3,
    totalSeats: 80,
    availableSeats: 28,
    instructor: 'Dr. Lisa Thompson',
    description: 'Probability theory, random variables, distributions, statistical inference, hypothesis testing, and regression analysis.',
    schedule: [
      { day: 'Mon', startTime: '16:00', endTime: '17:30' },
      { day: 'Wed', startTime: '16:00', endTime: '17:30' },
    ],
    prerequisites: ['math201'],
    department: 'Mathematics',
    level: 'Advanced',
  },
  {
    id: 'phys101',
    code: 'PHYS 101',
    name: 'Physics I: Mechanics',
    credits: 4,
    totalSeats: 120,
    availableSeats: 52,
    instructor: 'Prof. Richard Brown',
    description: 'Classical mechanics including kinematics, Newton\'s laws, work and energy, momentum, rotational motion, and oscillations.',
    schedule: [
      { day: 'Tue', startTime: '16:00', endTime: '17:30' },
      { day: 'Thu', startTime: '16:00', endTime: '17:30' },
    ],
    prerequisites: ['math101'],
    department: 'Physics',
    level: 'Introductory',
  },
  {
    id: 'cs205',
    code: 'CS 205',
    name: 'Computer Architecture',
    credits: 3,
    totalSeats: 65,
    availableSeats: 0,
    instructor: 'Dr. Kevin Zhang',
    description: 'Digital logic, computer organization, instruction set architecture, memory hierarchy, and parallel processing fundamentals.',
    schedule: [
      { day: 'Mon', startTime: '09:00', endTime: '10:30' },
      { day: 'Wed', startTime: '09:00', endTime: '10:30' },
    ],
    prerequisites: ['cs101'],
    department: 'Computer Science',
    level: 'Intermediate',
  },
  {
    id: 'cs310',
    code: 'CS 310',
    name: 'Operating Systems',
    credits: 4,
    totalSeats: 55,
    availableSeats: 7,
    instructor: 'Prof. Jennifer Adams',
    description: 'Process management, memory management, file systems, I/O systems, and introduction to concurrent programming.',
    schedule: [
      { day: 'Tue', startTime: '09:00', endTime: '10:30' },
      { day: 'Thu', startTime: '09:00', endTime: '10:30' },
    ],
    prerequisites: ['cs205', 'cs201'],
    department: 'Computer Science',
    level: 'Advanced',
  },
];

// Example of cyclic dependency for testing (in real data, this would be an error)
export const coursesWithCycle: Course[] = [
  ...courses,
  {
    id: 'cs999',
    code: 'CS 999',
    name: 'Advanced Topics (Cyclic Test)',
    credits: 3,
    totalSeats: 30,
    availableSeats: 30,
    instructor: 'Test Instructor',
    description: 'This course has a cyclic prerequisite for testing purposes.',
    schedule: [
      { day: 'Fri', startTime: '14:00', endTime: '17:00' },
    ],
    prerequisites: ['cs998'],
    department: 'Computer Science',
    level: 'Advanced',
  },
  {
    id: 'cs998',
    code: 'CS 998',
    name: 'Special Topics (Cyclic Test)',
    credits: 3,
    totalSeats: 30,
    availableSeats: 30,
    instructor: 'Test Instructor',
    description: 'This course creates a cycle with CS 999.',
    schedule: [
      { day: 'Fri', startTime: '14:00', endTime: '17:00' },
    ],
    prerequisites: ['cs999'],
    department: 'Computer Science',
    level: 'Advanced',
  },
];
