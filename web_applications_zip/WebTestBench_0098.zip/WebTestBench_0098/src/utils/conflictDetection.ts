import { Course, TimeSlot } from '@/data/courses';

export interface TimeConflict {
  course1: Course;
  course2: Course;
  conflictingSlots: { slot1: TimeSlot; slot2: TimeSlot }[];
}

export interface EnrollmentWarning {
  type: 'time_conflict' | 'unmet_prerequisite' | 'cycle_detected' | 'no_seats' | 'low_seats';
  message: string;
  severity: 'error' | 'warning';
  relatedCourses?: Course[];
}

function timeToMinutes(time: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

function slotsOverlap(slot1: TimeSlot, slot2: TimeSlot): boolean {
  if (slot1.day !== slot2.day) return false;
  
  const start1 = timeToMinutes(slot1.startTime);
  const end1 = timeToMinutes(slot1.endTime);
  const start2 = timeToMinutes(slot2.startTime);
  const end2 = timeToMinutes(slot2.endTime);

  return start1 < end2 && start2 < end1;
}

export function detectTimeConflicts(
  courseToEnroll: Course,
  enrolledCourses: Course[]
): TimeConflict[] {
  const conflicts: TimeConflict[] = [];

  for (const enrolled of enrolledCourses) {
    if (enrolled.id === courseToEnroll.id) continue;

    const conflictingSlots: { slot1: TimeSlot; slot2: TimeSlot }[] = [];

    for (const slot1 of courseToEnroll.schedule) {
      for (const slot2 of enrolled.schedule) {
        if (slotsOverlap(slot1, slot2)) {
          conflictingSlots.push({ slot1, slot2 });
        }
      }
    }

    if (conflictingSlots.length > 0) {
      conflicts.push({
        course1: courseToEnroll,
        course2: enrolled,
        conflictingSlots,
      });
    }
  }

  return conflicts;
}

export function getEnrollmentWarnings(
  course: Course,
  enrolledCourses: Course[],
  completedCourses: string[],
  allCourses: Course[],
  hasCycle: boolean
): EnrollmentWarning[] {
  const warnings: EnrollmentWarning[] = [];

  // Check for no seats
  if (course.availableSeats === 0) {
    warnings.push({
      type: 'no_seats',
      message: 'No seats available for enrollment',
      severity: 'error',
    });
  } else if (course.availableSeats <= 5) {
    warnings.push({
      type: 'low_seats',
      message: `Only ${course.availableSeats} seat${course.availableSeats === 1 ? '' : 's'} remaining`,
      severity: 'warning',
    });
  }

  // Check for cycle
  if (hasCycle) {
    warnings.push({
      type: 'cycle_detected',
      message: 'Cyclic prerequisite dependency detected',
      severity: 'error',
    });
  }

  // Check for unmet prerequisites
  const courseMap = new Map(allCourses.map(c => [c.id, c]));
  const unmetPrereqs: Course[] = [];
  
  for (const prereqId of course.prerequisites) {
    if (!completedCourses.includes(prereqId)) {
      const prereqCourse = courseMap.get(prereqId);
      if (prereqCourse) {
        unmetPrereqs.push(prereqCourse);
      }
    }
  }

  if (unmetPrereqs.length > 0) {
    warnings.push({
      type: 'unmet_prerequisite',
      message: `Missing prerequisites: ${unmetPrereqs.map(c => c.code).join(', ')}`,
      severity: 'error',
      relatedCourses: unmetPrereqs,
    });
  }

  // Check for time conflicts
  const timeConflicts = detectTimeConflicts(course, enrolledCourses);
  if (timeConflicts.length > 0) {
    for (const conflict of timeConflicts) {
      warnings.push({
        type: 'time_conflict',
        message: `Time conflict with ${conflict.course2.code}`,
        severity: 'error',
        relatedCourses: [conflict.course2],
      });
    }
  }

  return warnings;
}

export function formatTimeSlot(slot: TimeSlot): string {
  return `${slot.day} ${slot.startTime}-${slot.endTime}`;
}

export function formatSchedule(schedule: TimeSlot[]): string {
  return schedule.map(formatTimeSlot).join(', ');
}
