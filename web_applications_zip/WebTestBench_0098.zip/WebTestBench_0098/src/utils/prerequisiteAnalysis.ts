import { Course } from '@/data/courses';

export interface DependencyNode {
  id: string;
  code: string;
  name: string;
  level: number;
  isCompleted?: boolean;
  isEnrolled?: boolean;
  isCurrent?: boolean;
}

export interface DependencyEdge {
  from: string;
  to: string;
}

export interface DependencyGraph {
  nodes: DependencyNode[];
  edges: DependencyEdge[];
  hasCycle: boolean;
  cycleNodes: string[];
}

export function buildDependencyGraph(
  courseId: string,
  allCourses: Course[],
  completedCourses: string[] = [],
  enrolledCourses: string[] = []
): DependencyGraph {
  const courseMap = new Map(allCourses.map(c => [c.id, c]));
  const nodes: DependencyNode[] = [];
  const edges: DependencyEdge[] = [];
  const visited = new Set<string>();
  const nodeMap = new Map<string, DependencyNode>();

  // Build prerequisite chain (ancestors)
  function addPrerequisites(id: string, level: number, path: string[] = []): boolean {
    if (path.includes(id)) {
      // Cycle detected
      return true;
    }

    const course = courseMap.get(id);
    if (!course) return false;

    if (!visited.has(id)) {
      visited.add(id);
      const node: DependencyNode = {
        id: course.id,
        code: course.code,
        name: course.name,
        level,
        isCompleted: completedCourses.includes(id),
        isEnrolled: enrolledCourses.includes(id),
        isCurrent: id === courseId,
      };
      nodes.push(node);
      nodeMap.set(id, node);
    }

    let hasCycle = false;
    for (const prereqId of course.prerequisites) {
      edges.push({ from: prereqId, to: id });
      const prereqCycle = addPrerequisites(prereqId, level + 1, [...path, id]);
      if (prereqCycle) hasCycle = true;
    }

    return hasCycle;
  }

  // Build dependent chain (descendants)
  function addDependents(id: string, level: number) {
    const dependentCourses = allCourses.filter(c => c.prerequisites.includes(id));
    
    for (const dep of dependentCourses) {
      if (!visited.has(dep.id)) {
        visited.add(dep.id);
        const node: DependencyNode = {
          id: dep.id,
          code: dep.code,
          name: dep.name,
          level,
          isCompleted: completedCourses.includes(dep.id),
          isEnrolled: enrolledCourses.includes(dep.id),
          isCurrent: dep.id === courseId,
        };
        nodes.push(node);
        nodeMap.set(dep.id, node);
      }
      edges.push({ from: id, to: dep.id });
      addDependents(dep.id, level - 1);
    }
  }

  const hasCycle = addPrerequisites(courseId, 0);
  addDependents(courseId, -1);

  // Find cycle nodes if cycle exists
  const cycleNodes: string[] = [];
  if (hasCycle) {
    const course = courseMap.get(courseId);
    if (course) {
      const detectCycleNodes = (id: string, path: string[]): string[] => {
        if (path.includes(id)) {
          const cycleStart = path.indexOf(id);
          return path.slice(cycleStart);
        }
        const c = courseMap.get(id);
        if (!c) return [];
        for (const prereqId of c.prerequisites) {
          const result = detectCycleNodes(prereqId, [...path, id]);
          if (result.length > 0) return result;
        }
        return [];
      };
      cycleNodes.push(...detectCycleNodes(courseId, []));
    }
  }

  return { nodes, edges, hasCycle, cycleNodes };
}

export function getUnmetPrerequisites(
  courseId: string,
  allCourses: Course[],
  completedCourses: string[],
  enrolledCourses: string[]
): Course[] {
  const courseMap = new Map(allCourses.map(c => [c.id, c]));
  const course = courseMap.get(courseId);
  if (!course) return [];

  const unmet: Course[] = [];
  
  function checkPrereqs(prereqIds: string[]) {
    for (const prereqId of prereqIds) {
      if (!completedCourses.includes(prereqId)) {
        const prereqCourse = courseMap.get(prereqId);
        if (prereqCourse && !unmet.find(c => c.id === prereqId)) {
          unmet.push(prereqCourse);
        }
      }
    }
  }

  checkPrereqs(course.prerequisites);
  return unmet;
}

export function getAllPrerequisites(
  courseId: string,
  allCourses: Course[]
): string[] {
  const courseMap = new Map(allCourses.map(c => [c.id, c]));
  const prereqs = new Set<string>();
  const visited = new Set<string>();

  function collect(id: string) {
    if (visited.has(id)) return;
    visited.add(id);
    
    const course = courseMap.get(id);
    if (!course) return;

    for (const prereqId of course.prerequisites) {
      prereqs.add(prereqId);
      collect(prereqId);
    }
  }

  collect(courseId);
  return Array.from(prereqs);
}
