import { useState, useMemo } from 'react';
import { useEnrollment } from '@/hooks/useEnrollment';
import { Header } from '@/components/Header';
import { FilterBar } from '@/components/FilterBar';
import { CourseCard } from '@/components/CourseCard';
import { CourseDetail } from '@/components/CourseDetail';
import { Timetable } from '@/components/Timetable';
import { Course } from '@/data/courses';
import { BookOpen, Calendar } from 'lucide-react';

const Index = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [showTimetable, setShowTimetable] = useState(true);

  const {
    courses,
    enrolledCourses,
    totalCredits,
    enroll,
    drop,
    canEnroll,
    isEnrolled,
    isCompleted,
    markCompleted,
    unmarkCompleted,
    getWarningsForCourse,
    getDependencyGraph,
  } = useEnrollment();

  // Extract unique departments and levels
  const departments = useMemo(() => 
    [...new Set(courses.map(c => c.department))].sort(),
    [courses]
  );

  const levels = useMemo(() => 
    ['Introductory', 'Intermediate', 'Advanced'],
    []
  );

  // Filter courses
  const filteredCourses = useMemo(() => {
    return courses.filter(course => {
      const matchesSearch = searchQuery === '' || 
        course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.instructor.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesDepartment = selectedDepartment === null || 
        course.department === selectedDepartment;
      
      const matchesLevel = selectedLevel === null || 
        course.level === selectedLevel;

      return matchesSearch && matchesDepartment && matchesLevel;
    });
  }, [courses, searchQuery, selectedDepartment, selectedLevel]);

  // Get warnings and graph for selected course
  const selectedCourseWarnings = useMemo(() => 
    selectedCourse ? getWarningsForCourse(selectedCourse) : [],
    [selectedCourse, getWarningsForCourse]
  );

  const selectedCourseGraph = useMemo(() => 
    selectedCourse ? getDependencyGraph(selectedCourse.id) : null,
    [selectedCourse, getDependencyGraph]
  );

  const handleEnroll = () => {
    if (selectedCourse) {
      enroll(selectedCourse.id);
      // Refresh course to get updated seat count
      const updated = courses.find(c => c.id === selectedCourse.id);
      if (updated) setSelectedCourse(updated);
    }
  };

  const handleDrop = () => {
    if (selectedCourse) {
      drop(selectedCourse.id);
      const updated = courses.find(c => c.id === selectedCourse.id);
      if (updated) setSelectedCourse(updated);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        totalCredits={totalCredits}
        enrolledCount={enrolledCourses.length}
      />

      <main className="container mx-auto px-6 py-8">
        {/* Hero Section */}
        <div className="mb-8 animate-fade-in">
          <h2 className="text-3xl font-display font-bold text-foreground mb-2">
            Course Catalog
          </h2>
          <p className="text-muted-foreground">
            Browse courses, check prerequisites, and build your perfect schedule
          </p>
        </div>

        <div className="flex gap-8">
          {/* Main Content */}
          <div className="flex-1 min-w-0 space-y-6">
            {/* Filters */}
            <FilterBar
              departments={departments}
              levels={levels}
              selectedDepartment={selectedDepartment}
              selectedLevel={selectedLevel}
              onDepartmentChange={setSelectedDepartment}
              onLevelChange={setSelectedLevel}
            />

            {/* Course Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredCourses.map((course, index) => (
                <div 
                  key={course.id}
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <CourseCard
                    course={course}
                    isEnrolled={isEnrolled(course.id)}
                    isCompleted={isCompleted(course.id)}
                    warnings={getWarningsForCourse(course)}
                    onClick={() => setSelectedCourse(course)}
                  />
                </div>
              ))}
            </div>

            {filteredCourses.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-30" />
                <p>No courses found matching your criteria</p>
              </div>
            )}
          </div>

          {/* Sidebar - Timetable */}
          <div className="hidden xl:block w-96 flex-shrink-0">
            <div className="sticky top-24">
              <Timetable
                enrolledCourses={enrolledCourses}
                onDropCourse={drop}
                totalCredits={totalCredits}
              />
            </div>
          </div>
        </div>

        {/* Mobile Timetable Toggle */}
        <div className="xl:hidden fixed bottom-6 right-6 z-40">
          <button
            onClick={() => setShowTimetable(!showTimetable)}
            className="w-14 h-14 rounded-full bg-gradient-primary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center"
          >
            <Calendar className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Timetable Sheet */}
        {showTimetable && (
          <div className="xl:hidden fixed inset-x-0 bottom-0 z-30 p-4 bg-background border-t border-border animate-slide-in-right">
            <Timetable
              enrolledCourses={enrolledCourses}
              onDropCourse={drop}
              totalCredits={totalCredits}
            />
          </div>
        )}
      </main>

      {/* Course Detail Modal */}
      <CourseDetail
        course={selectedCourse}
        isOpen={selectedCourse !== null}
        onClose={() => setSelectedCourse(null)}
        isEnrolled={selectedCourse ? isEnrolled(selectedCourse.id) : false}
        isCompleted={selectedCourse ? isCompleted(selectedCourse.id) : false}
        canEnroll={selectedCourse ? canEnroll(selectedCourse) : false}
        warnings={selectedCourseWarnings}
        dependencyGraph={selectedCourseGraph}
        onEnroll={handleEnroll}
        onDrop={handleDrop}
        onMarkCompleted={() => selectedCourse && markCompleted(selectedCourse.id)}
        onUnmarkCompleted={() => selectedCourse && unmarkCompleted(selectedCourse.id)}
      />
    </div>
  );
};

export default Index;
