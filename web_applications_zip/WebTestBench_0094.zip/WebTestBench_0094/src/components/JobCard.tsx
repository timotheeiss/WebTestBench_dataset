import { Job } from '@/data/jobs';
import { MapPin, Briefcase, Clock, DollarSign } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

interface JobCardProps {
  job: Job;
  isSelected: boolean;
  onToggleSelect: (jobId: string) => void;
}

const JobCard = ({ job, isSelected, onToggleSelect }: JobCardProps) => {
  const getTypeBadgeClass = (type: string) => {
    switch (type) {
      case 'full-time':
        return 'job-badge-full-time';
      case 'part-time':
        return 'job-badge-part-time';
      case 'contract':
        return 'job-badge-contract';
      default:
        return '';
    }
  };

  const formatType = (type: string) => {
    return type
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('-');
  };

  return (
    <div className={`job-card animate-fade-in ${isSelected ? 'ring-2 ring-primary' : ''}`}>
      <div className="flex items-start gap-4">
        <div className="flex items-center gap-3">
          <Checkbox
            checked={isSelected}
            onCheckedChange={() => onToggleSelect(job.id)}
            className="mt-1"
          />
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center text-2xl">
            {job.logo}
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-semibold text-foreground hover:text-primary transition-colors cursor-pointer">
                {job.title}
              </h3>
              <p className="text-muted-foreground font-medium">{job.company}</p>
            </div>
            <span className={`job-badge ${getTypeBadgeClass(job.type)}`}>
              {formatType(job.type)}
            </span>
          </div>

          <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
            {job.description}
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <MapPin size={16} className="text-primary" />
              {job.location}
            </span>
            <span className="flex items-center gap-1.5">
              <DollarSign size={16} className="text-success" />
              {job.salary}
            </span>
            <span className="flex items-center gap-1.5">
              <Briefcase size={16} className="text-warning" />
              {job.experience}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock size={16} className="text-muted-foreground" />
              {new Date(job.postedDate).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
              })}
            </span>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {job.requirements.slice(0, 4).map((req) => (
              <span
                key={req}
                className="px-2.5 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-md"
              >
                {req}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
