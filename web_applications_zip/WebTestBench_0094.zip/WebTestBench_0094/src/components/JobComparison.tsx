import { X, Scale, MapPin, DollarSign, Briefcase, Clock, Building } from 'lucide-react';
import { Job } from '@/data/jobs';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface JobComparisonProps {
  selectedJobs: Job[];
  onClearSelection: () => void;
  onRemoveJob: (jobId: string) => void;
}

const JobComparison = ({
  selectedJobs,
  onClearSelection,
  onRemoveJob,
}: JobComparisonProps) => {
  if (selectedJobs.length === 0) return null;

  const formatType = (type: string) => {
    return type
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('-');
  };

  const getTypeBadgeClass = (type: string) => {
    switch (type) {
      case 'full-time':
        return 'job-badge-full-time';
      case 'part-time':
        return 'job-badge-part-time';
      case 'contract':
        return 'job-badge-contract';
      default:
        return '';
    }
  };

  const getSalaryColor = (job: Job, allJobs: Job[]) => {
    const maxSalary = Math.max(...allJobs.map((j) => j.salaryMax));
    if (job.salaryMax === maxSalary) return 'text-success font-semibold';
    return '';
  };

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
      <div className="glass-panel p-4 flex items-center gap-4 shadow-xl">
        <div className="flex items-center gap-2">
          <Scale size={20} className="text-primary" />
          <span className="font-semibold">
            {selectedJobs.length} job{selectedJobs.length > 1 ? 's' : ''} selected
          </span>
        </div>

        <div className="flex items-center gap-2">
          {selectedJobs.slice(0, 3).map((job) => (
            <div
              key={job.id}
              className="flex items-center gap-1.5 px-2 py-1 bg-secondary rounded-lg text-sm"
            >
              <span>{job.logo}</span>
              <span className="max-w-[100px] truncate">{job.title}</span>
              <button
                onClick={() => onRemoveJob(job.id)}
                className="text-muted-foreground hover:text-destructive transition-colors"
              >
                <X size={14} />
              </button>
            </div>
          ))}
          {selectedJobs.length > 3 && (
            <span className="text-sm text-muted-foreground">
              +{selectedJobs.length - 3} more
            </span>
          )}
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button className="btn-hero" disabled={selectedJobs.length < 2}>
              <Scale size={16} className="mr-2" />
              Compare
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl max-h-[85vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Scale className="text-primary" />
                Job Comparison
              </DialogTitle>
            </DialogHeader>

            <div className="mt-4 overflow-x-auto">
              <table className="comparison-table">
                <thead>
                  <tr>
                    <th className="sticky left-0 bg-secondary z-10 min-w-[120px]">
                      Attribute
                    </th>
                    {selectedJobs.map((job) => (
                      <th key={job.id} className="min-w-[200px]">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{job.logo}</span>
                          <div>
                            <div className="font-semibold">{job.title}</div>
                            <div className="text-xs font-normal text-muted-foreground">
                              {job.company}
                            </div>
                          </div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <Building size={16} className="text-muted-foreground" />
                        Company
                      </div>
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>{job.company}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <MapPin size={16} className="text-primary" />
                        Location
                      </div>
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>{job.location}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <Briefcase size={16} className="text-warning" />
                        Job Type
                      </div>
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>
                        <span className={`job-badge ${getTypeBadgeClass(job.type)}`}>
                          {formatType(job.type)}
                        </span>
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <DollarSign size={16} className="text-success" />
                        Salary
                      </div>
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id} className={getSalaryColor(job, selectedJobs)}>
                        {job.salary}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <Clock size={16} className="text-muted-foreground" />
                        Experience
                      </div>
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>{job.experience}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      Requirements
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>
                        <div className="flex flex-wrap gap-1">
                          {job.requirements.map((req) => (
                            <span
                              key={req}
                              className="px-2 py-0.5 text-xs bg-secondary rounded-md"
                            >
                              {req}
                            </span>
                          ))}
                        </div>
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="sticky left-0 bg-card z-10 font-medium">
                      Posted
                    </td>
                    {selectedJobs.map((job) => (
                      <td key={job.id}>
                        {new Date(job.postedDate).toLocaleDateString('en-US', {
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </DialogContent>
        </Dialog>

        <Button variant="ghost" size="sm" onClick={onClearSelection}>
          <X size={16} className="mr-1" />
          Clear
        </Button>
      </div>
    </div>
  );
};

export default JobComparison;
