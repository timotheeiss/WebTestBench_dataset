import { Search, MapPin, Briefcase, Save, X } from 'lucide-react';
import { locations, jobTypes } from '@/data/jobs';
import { SearchFilters as FiltersType } from '@/hooks/useJobSearch';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useState } from 'react';

interface SearchFiltersProps {
  filters: FiltersType;
  onUpdateFilters: (filters: Partial<FiltersType>) => void;
  onSearch: () => void;
  onSaveSearch: (name: string) => void;
  onReset: () => void;
  resultsCount: number;
}

const SearchFilters = ({
  filters,
  onUpdateFilters,
  onSearch,
  onSaveSearch,
  onReset,
  resultsCount,
}: SearchFiltersProps) => {
  const [searchName, setSearchName] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleSave = () => {
    if (searchName.trim()) {
      onSaveSearch(searchName.trim());
      setSearchName('');
      setDialogOpen(false);
    }
  };

  const formatType = (type: string) => {
    return type
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('-');
  };

  const hasActiveFilters = filters.query || filters.jobType || filters.location;

  return (
    <div className="glass-panel p-6 animate-slide-up">
      <div className="flex flex-col gap-4">
        {/* Search Input */}
        <div className="relative">
          <Search
            size={20}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <input
            type="text"
            placeholder="Search jobs, companies, or keywords..."
            value={filters.query}
            onChange={(e) => onUpdateFilters({ query: e.target.value })}
            onKeyDown={(e) => e.key === 'Enter' && onSearch()}
            className="search-input pl-12"
          />
        </div>

        {/* Filters Row */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Briefcase size={18} className="text-muted-foreground" />
            <Select
              value={filters.jobType || "all"}
              onValueChange={(value) => onUpdateFilters({ jobType: value === "all" ? "" : value })}
            >
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Job Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {jobTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {formatType(type)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <MapPin size={18} className="text-muted-foreground" />
            <Select
              value={filters.location || "all"}
              onValueChange={(value) => onUpdateFilters({ location: value === "all" ? "" : value })}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                {locations.map((location) => (
                  <SelectItem key={location} value={location}>
                    {location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={onSearch} className="btn-hero">
            <Search size={18} className="mr-2" />
            Search
          </Button>

          {hasActiveFilters && (
            <Button variant="ghost" onClick={onReset} className="text-muted-foreground">
              <X size={18} className="mr-1" />
              Clear
            </Button>
          )}

          <div className="flex-1" />

          {hasActiveFilters && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Save size={16} />
                  Save Search
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Save This Search</DialogTitle>
                </DialogHeader>
                <div className="py-4">
                  <Label htmlFor="search-name">Search Name</Label>
                  <Input
                    id="search-name"
                    placeholder='e.g., "Remote Tech Jobs"'
                    value={searchName}
                    onChange={(e) => setSearchName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                    className="mt-2"
                  />
                  <p className="mt-3 text-sm text-muted-foreground">
                    Current filters:{' '}
                    {[
                      filters.query && `"${filters.query}"`,
                      filters.jobType && formatType(filters.jobType),
                      filters.location,
                    ]
                      .filter(Boolean)
                      .join(', ') || 'None'}
                  </p>
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button variant="ghost">Cancel</Button>
                  </DialogClose>
                  <Button onClick={handleSave} disabled={!searchName.trim()}>
                    Save Search
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Results Count */}
        <div className="text-sm text-muted-foreground">
          Showing <span className="font-semibold text-foreground">{resultsCount}</span> jobs
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;
