import { History, Trash2, X, RotateCcw } from 'lucide-react';
import { SearchHistoryItem } from '@/hooks/useJobSearch';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface SearchHistoryProps {
  history: SearchHistoryItem[];
  onApplySearch: (item: SearchHistoryItem) => void;
  onDeleteItem: (id: string) => void;
  onClearAll: () => void;
}

const SearchHistory = ({
  history,
  onApplySearch,
  onDeleteItem,
  onClearAll,
}: SearchHistoryProps) => {
  const formatType = (type: string) => {
    if (!type) return '';
    return type
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('-');
  };

  const formatFilters = (item: SearchHistoryItem) => {
    const parts = [
      item.filters.query && `"${item.filters.query}"`,
      item.filters.jobType && formatType(item.filters.jobType),
      item.filters.location,
    ].filter(Boolean);
    return parts.join(' • ') || 'All jobs';
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" className="gap-2 relative">
          <History size={18} />
          History
          {history.length > 0 && (
            <span className="absolute -top-2 -right-2 w-5 h-5 bg-muted text-muted-foreground text-xs font-bold rounded-full flex items-center justify-center">
              {history.length}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2">
              <History className="text-primary" size={20} />
              Search History
            </SheetTitle>
            {history.length > 0 && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                    <Trash2 size={16} className="mr-1" />
                    Clear All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Clear Search History?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete all your search history. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={onClearAll} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Clear All
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </SheetHeader>

        <div className="mt-6 space-y-2">
          {history.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <History size={48} className="mx-auto mb-4 opacity-30" />
              <p className="font-medium">No search history</p>
              <p className="text-sm mt-1">
                Your recent searches will appear here
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="group flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:border-primary/30 hover:bg-secondary/50 transition-all duration-200 cursor-pointer"
                onClick={() => onApplySearch(item)}
              >
                <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center">
                  <RotateCcw size={14} className="text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {formatFilters(item)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {item.resultsCount} results • {formatTime(item.timestamp)}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteItem(item.id);
                  }}
                  className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                >
                  <X size={14} />
                </Button>
              </div>
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default SearchHistory;
