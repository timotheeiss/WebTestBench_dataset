import { Bookmark, Trash2, Search } from 'lucide-react';
import { SavedSearch } from '@/hooks/useJobSearch';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

interface SavedSearchesProps {
  savedSearches: SavedSearch[];
  onLoadSearch: (search: SavedSearch) => void;
  onDeleteSearch: (id: string) => void;
}

const SavedSearches = ({
  savedSearches,
  onLoadSearch,
  onDeleteSearch,
}: SavedSearchesProps) => {
  const formatType = (type: string) => {
    if (!type) return '';
    return type
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('-');
  };

  const formatFilters = (search: SavedSearch) => {
    const parts = [
      search.filters.query && `"${search.filters.query}"`,
      search.filters.jobType && formatType(search.filters.jobType),
      search.filters.location,
    ].filter(Boolean);
    return parts.join(' • ') || 'All jobs';
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" className="gap-2 relative">
          <Bookmark size={18} />
          Saved Searches
          {savedSearches.length > 0 && (
            <span className="absolute -top-2 -right-2 w-5 h-5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center justify-center">
              {savedSearches.length}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Bookmark className="text-primary" size={20} />
            Saved Searches
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-3">
          {savedSearches.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Bookmark size={48} className="mx-auto mb-4 opacity-30" />
              <p className="font-medium">No saved searches yet</p>
              <p className="text-sm mt-1">
                Save your filter combinations for quick access
              </p>
            </div>
          ) : (
            savedSearches.map((search) => (
              <div
                key={search.id}
                className="group flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:shadow-md transition-all duration-200"
              >
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground truncate">
                    {search.name}
                  </h4>
                  <p className="text-sm text-muted-foreground mt-0.5 truncate">
                    {formatFilters(search)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Saved {new Date(search.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onLoadSearch(search)}
                    className="h-8 px-3"
                  >
                    <Search size={14} className="mr-1" />
                    Apply
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDeleteSearch(search.id)}
                    className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default SavedSearches;
