import { useState, useMemo, useCallback } from 'react';
import { jobs, Job } from '@/data/jobs';

export interface SearchFilters {
  query: string;
  jobType: string;
  location: string;
}

export interface SavedSearch {
  id: string;
  name: string;
  filters: SearchFilters;
  createdAt: string;
}

export interface SearchHistoryItem {
  id: string;
  filters: SearchFilters;
  timestamp: string;
  resultsCount: number;
}

const SAVED_SEARCHES_KEY = 'job-board-saved-searches';
const SEARCH_HISTORY_KEY = 'job-board-search-history';
const MAX_HISTORY_ITEMS = 10;

export const useJobSearch = () => {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    jobType: '',
    location: '',
  });

  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>(() => {
    const stored = localStorage.getItem(SAVED_SEARCHES_KEY);
    return stored ? JSON.parse(stored) : [];
  });

  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>(() => {
    const stored = localStorage.getItem(SEARCH_HISTORY_KEY);
    return stored ? JSON.parse(stored) : [];
  });

  const [selectedJobIds, setSelectedJobIds] = useState<Set<string>>(new Set());

  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      const matchesQuery =
        !filters.query ||
        job.title.toLowerCase().includes(filters.query.toLowerCase()) ||
        job.company.toLowerCase().includes(filters.query.toLowerCase()) ||
        job.description.toLowerCase().includes(filters.query.toLowerCase());

      const matchesType = !filters.jobType || job.type === filters.jobType;
      const matchesLocation = !filters.location || job.location === filters.location;

      return matchesQuery && matchesType && matchesLocation;
    });
  }, [filters]);

  const selectedJobs = useMemo(() => {
    return jobs.filter((job) => selectedJobIds.has(job.id));
  }, [selectedJobIds]);

  const updateFilters = useCallback((newFilters: Partial<SearchFilters>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  }, []);

  const performSearch = useCallback(() => {
    const hasActiveFilters = filters.query || filters.jobType || filters.location;
    if (!hasActiveFilters) return;

    const historyItem: SearchHistoryItem = {
      id: Date.now().toString(),
      filters: { ...filters },
      timestamp: new Date().toISOString(),
      resultsCount: filteredJobs.length,
    };

    setSearchHistory((prev) => {
      const isDuplicate = prev.some(
        (item) =>
          item.filters.query === filters.query &&
          item.filters.jobType === filters.jobType &&
          item.filters.location === filters.location
      );

      if (isDuplicate) return prev;

      const updated = [historyItem, ...prev].slice(0, MAX_HISTORY_ITEMS);
      localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updated));
      return updated;
    });
  }, [filters, filteredJobs.length]);

  const saveSearch = useCallback(
    (name: string) => {
      const newSearch: SavedSearch = {
        id: Date.now().toString(),
        name,
        filters: { ...filters },
        createdAt: new Date().toISOString(),
      };

      setSavedSearches((prev) => {
        const updated = [...prev, newSearch];
        localStorage.setItem(SAVED_SEARCHES_KEY, JSON.stringify(updated));
        return updated;
      });
    },
    [filters]
  );

  const loadSavedSearch = useCallback((search: SavedSearch) => {
    setFilters(search.filters);
  }, []);

  const deleteSavedSearch = useCallback((id: string) => {
    setSavedSearches((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      localStorage.setItem(SAVED_SEARCHES_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const applyHistorySearch = useCallback((item: SearchHistoryItem) => {
    setFilters(item.filters);
  }, []);

  const deleteHistoryItem = useCallback((id: string) => {
    setSearchHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setSearchHistory([]);
    localStorage.removeItem(SEARCH_HISTORY_KEY);
  }, []);

  const toggleJobSelection = useCallback((jobId: string) => {
    setSelectedJobIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(jobId)) {
        updated.delete(jobId);
      } else {
        updated.add(jobId);
      }
      return updated;
    });
  }, []);

  const clearJobSelection = useCallback(() => {
    setSelectedJobIds(new Set());
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({ query: '', jobType: '', location: '' });
  }, []);

  return {
    filters,
    updateFilters,
    filteredJobs,
    savedSearches,
    saveSearch,
    loadSavedSearch,
    deleteSavedSearch,
    searchHistory,
    performSearch,
    applyHistorySearch,
    deleteHistoryItem,
    clearHistory,
    selectedJobIds,
    selectedJobs,
    toggleJobSelection,
    clearJobSelection,
    resetFilters,
  };
};
