export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract';
  salary: string;
  salaryMin: number;
  salaryMax: number;
  experience: string;
  description: string;
  requirements: string[];
  postedDate: string;
  logo: string;
}

export const jobs: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Developer',
    company: 'TechCorp Inc.',
    location: 'San Francisco',
    type: 'full-time',
    salary: '$120,000 - $160,000',
    salaryMin: 120000,
    salaryMax: 160000,
    experience: '5+ years',
    description: 'Join our team to build cutting-edge web applications using React and TypeScript.',
    requirements: ['React', 'TypeScript', 'CSS', 'Git'],
    postedDate: '2024-01-10',
    logo: '🏢'
  },
  {
    id: '2',
    title: 'Marketing Manager',
    company: 'BrandBoost Agency',
    location: 'New York',
    type: 'full-time',
    salary: '$85,000 - $110,000',
    salaryMin: 85000,
    salaryMax: 110000,
    experience: '3-5 years',
    description: 'Lead marketing campaigns and drive brand awareness for Fortune 500 clients.',
    requirements: ['Digital Marketing', 'SEO', 'Analytics', 'Team Leadership'],
    postedDate: '2024-01-12',
    logo: '📊'
  },
  {
    id: '3',
    title: 'UX Designer',
    company: 'DesignHub',
    location: 'Los Angeles',
    type: 'contract',
    salary: '$70/hour',
    salaryMin: 140000,
    salaryMax: 145000,
    experience: '2-4 years',
    description: 'Create intuitive user experiences for mobile and web applications.',
    requirements: ['Figma', 'User Research', 'Prototyping', 'Design Systems'],
    postedDate: '2024-01-08',
    logo: '🎨'
  },
  {
    id: '4',
    title: 'Data Analyst',
    company: 'DataDriven Co.',
    location: 'Chicago',
    type: 'full-time',
    salary: '$75,000 - $95,000',
    salaryMin: 75000,
    salaryMax: 95000,
    experience: '2+ years',
    description: 'Analyze complex datasets and provide actionable insights to stakeholders.',
    requirements: ['SQL', 'Python', 'Tableau', 'Statistics'],
    postedDate: '2024-01-14',
    logo: '📈'
  },
  {
    id: '5',
    title: 'Part-time Content Writer',
    company: 'ContentKing',
    location: 'Remote',
    type: 'part-time',
    salary: '$35/hour',
    salaryMin: 35000,
    salaryMax: 45000,
    experience: '1-2 years',
    description: 'Write engaging blog posts and articles for various tech clients.',
    requirements: ['SEO Writing', 'Research', 'CMS', 'Editing'],
    postedDate: '2024-01-11',
    logo: '✍️'
  },
  {
    id: '6',
    title: 'DevOps Engineer',
    company: 'CloudScale',
    location: 'Seattle',
    type: 'full-time',
    salary: '$130,000 - $170,000',
    salaryMin: 130000,
    salaryMax: 170000,
    experience: '4+ years',
    description: 'Build and maintain CI/CD pipelines and cloud infrastructure.',
    requirements: ['AWS', 'Kubernetes', 'Docker', 'Terraform'],
    postedDate: '2024-01-09',
    logo: '☁️'
  },
  {
    id: '7',
    title: 'Product Manager',
    company: 'InnovateTech',
    location: 'Austin',
    type: 'full-time',
    salary: '$110,000 - $140,000',
    salaryMin: 110000,
    salaryMax: 140000,
    experience: '5+ years',
    description: 'Drive product strategy and roadmap for our SaaS platform.',
    requirements: ['Product Strategy', 'Agile', 'User Stories', 'Analytics'],
    postedDate: '2024-01-13',
    logo: '🚀'
  },
  {
    id: '8',
    title: 'HR Coordinator',
    company: 'PeopleFirst',
    location: 'Boston',
    type: 'part-time',
    salary: '$28/hour',
    salaryMin: 28000,
    salaryMax: 35000,
    experience: '1-3 years',
    description: 'Support HR operations including recruiting and onboarding.',
    requirements: ['HRIS', 'Recruiting', 'Communication', 'Organization'],
    postedDate: '2024-01-07',
    logo: '👥'
  },
  {
    id: '9',
    title: 'Backend Developer',
    company: 'APIFirst',
    location: 'San Francisco',
    type: 'contract',
    salary: '$85/hour',
    salaryMin: 170000,
    salaryMax: 176000,
    experience: '4-6 years',
    description: 'Design and implement scalable REST APIs and microservices.',
    requirements: ['Node.js', 'PostgreSQL', 'Redis', 'GraphQL'],
    postedDate: '2024-01-10',
    logo: '⚙️'
  },
  {
    id: '10',
    title: 'Sales Representative',
    company: 'GrowthMax',
    location: 'Denver',
    type: 'full-time',
    salary: '$55,000 + Commission',
    salaryMin: 55000,
    salaryMax: 120000,
    experience: '1-3 years',
    description: 'Drive B2B sales and build lasting client relationships.',
    requirements: ['CRM', 'Cold Calling', 'Negotiation', 'Presentation'],
    postedDate: '2024-01-12',
    logo: '💼'
  },
  {
    id: '11',
    title: 'Mobile Developer',
    company: 'AppWorks',
    location: 'New York',
    type: 'full-time',
    salary: '$100,000 - $130,000',
    salaryMin: 100000,
    salaryMax: 130000,
    experience: '3+ years',
    description: 'Build cross-platform mobile applications using React Native.',
    requirements: ['React Native', 'iOS', 'Android', 'JavaScript'],
    postedDate: '2024-01-14',
    logo: '📱'
  },
  {
    id: '12',
    title: 'Graphic Designer',
    company: 'CreativeStudio',
    location: 'Los Angeles',
    type: 'part-time',
    salary: '$40/hour',
    salaryMin: 40000,
    salaryMax: 50000,
    experience: '2+ years',
    description: 'Create stunning visual designs for print and digital media.',
    requirements: ['Photoshop', 'Illustrator', 'InDesign', 'Branding'],
    postedDate: '2024-01-06',
    logo: '🖼️'
  },
  {
    id: '13',
    title: 'Financial Analyst',
    company: 'CapitalGroup',
    location: 'Chicago',
    type: 'full-time',
    salary: '$80,000 - $100,000',
    salaryMin: 80000,
    salaryMax: 100000,
    experience: '2-4 years',
    description: 'Perform financial modeling and investment analysis.',
    requirements: ['Excel', 'Financial Modeling', 'Bloomberg', 'CFA'],
    postedDate: '2024-01-11',
    logo: '💰'
  },
  {
    id: '14',
    title: 'Customer Success Manager',
    company: 'SaaSly',
    location: 'Remote',
    type: 'full-time',
    salary: '$70,000 - $90,000',
    salaryMin: 70000,
    salaryMax: 90000,
    experience: '2-3 years',
    description: 'Ensure customer satisfaction and drive product adoption.',
    requirements: ['Customer Service', 'SaaS', 'Onboarding', 'Retention'],
    postedDate: '2024-01-13',
    logo: '🤝'
  },
  {
    id: '15',
    title: 'QA Engineer',
    company: 'QualityFirst',
    location: 'Austin',
    type: 'contract',
    salary: '$60/hour',
    salaryMin: 120000,
    salaryMax: 124000,
    experience: '3+ years',
    description: 'Design and execute test plans for web applications.',
    requirements: ['Selenium', 'Jest', 'API Testing', 'Test Automation'],
    postedDate: '2024-01-08',
    logo: '🔍'
  },
  {
    id: '16',
    title: 'Machine Learning Engineer',
    company: 'AI Dynamics',
    location: 'Seattle',
    type: 'full-time',
    salary: '$150,000 - $200,000',
    salaryMin: 150000,
    salaryMax: 200000,
    experience: '5+ years',
    description: 'Develop and deploy ML models for production systems.',
    requirements: ['Python', 'TensorFlow', 'PyTorch', 'MLOps'],
    postedDate: '2024-01-14',
    logo: '🤖'
  }
];

export const locations = [...new Set(jobs.map(job => job.location))];
export const jobTypes = ['full-time', 'part-time', 'contract'] as const;
