import { useJobSearch } from '@/hooks/useJobSearch';
import JobCard from '@/components/JobCard';
import SearchFilters from '@/components/SearchFilters';
import SavedSearches from '@/components/SavedSearches';
import SearchHistory from '@/components/SearchHistory';
import JobComparison from '@/components/JobComparison';
import { Briefcase, Sparkles } from 'lucide-react';

const Index = () => {
  const {
    filters,
    updateFilters,
    filteredJobs,
    savedSearches,
    saveSearch,
    loadSavedSearch,
    deleteSavedSearch,
    searchHistory,
    performSearch,
    applyHistorySearch,
    deleteHistoryItem,
    clearHistory,
    selectedJobIds,
    selectedJobs,
    toggleJobSelection,
    clearJobSelection,
    resetFilters,
  } = useJobSearch();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/5 to-transparent" />
        <div className="relative container mx-auto px-4 py-12">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                <Briefcase size={24} className="text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-display font-bold text-foreground">
                  JobBoard
                </h1>
                <p className="text-sm text-muted-foreground">
                  Find your dream job
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <SearchHistory
                history={searchHistory}
                onApplySearch={applyHistorySearch}
                onDeleteItem={deleteHistoryItem}
                onClearAll={clearHistory}
              />
              <SavedSearches
                savedSearches={savedSearches}
                onLoadSearch={loadSavedSearch}
                onDeleteSearch={deleteSavedSearch}
              />
            </div>
          </div>

          {/* Hero Text */}
          <div className="mt-10 max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground leading-tight">
              Discover{' '}
              <span className="text-gradient">Amazing Opportunities</span>
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Browse through hundreds of job listings from top companies. Filter by type, location, and save your favorite searches.
            </p>
          </div>

          {/* Stats */}
          <div className="mt-8 flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-primary" />
              <span className="text-sm font-medium">
                <span className="text-foreground font-bold">16</span>{' '}
                <span className="text-muted-foreground">active jobs</span>
              </span>
            </div>
            <div className="w-1 h-4 bg-border rounded-full" />
            <span className="text-sm text-muted-foreground">
              Updated daily
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 pb-32">
        {/* Search Filters */}
        <div className="-mt-2">
          <SearchFilters
            filters={filters}
            onUpdateFilters={updateFilters}
            onSearch={performSearch}
            onSaveSearch={saveSearch}
            onReset={resetFilters}
            resultsCount={filteredJobs.length}
          />
        </div>

        {/* Job Listings */}
        <div className="mt-8 grid gap-4">
          {filteredJobs.length === 0 ? (
            <div className="text-center py-16">
              <Briefcase size={64} className="mx-auto mb-4 text-muted-foreground/30" />
              <h3 className="text-xl font-semibold text-foreground">
                No jobs found
              </h3>
              <p className="mt-2 text-muted-foreground">
                Try adjusting your filters or search terms
              </p>
            </div>
          ) : (
            filteredJobs.map((job, index) => (
              <div
                key={job.id}
                style={{ animationDelay: `${index * 50}ms` }}
                className="animate-slide-up"
              >
                <JobCard
                  job={job}
                  isSelected={selectedJobIds.has(job.id)}
                  onToggleSelect={toggleJobSelection}
                />
              </div>
            ))
          )}
        </div>
      </main>

      {/* Comparison Bar */}
      <JobComparison
        selectedJobs={selectedJobs}
        onClearSelection={clearJobSelection}
        onRemoveJob={toggleJobSelection}
      />
    </div>
  );
};

export default Index;
