import { useState } from "react";
import { StoreProvider } from "@/context/StoreContext";
import { Header } from "@/components/Header";
import { ProductsTab } from "@/components/ProductsTab";
import { CartTab } from "@/components/CartTab";
import { RecordsTab } from "@/components/RecordsTab";
import { Toaster } from "@/components/ui/toaster";

type Tab = "products" | "cart" | "records";

function StoreContent() {
  const [activeTab, setActiveTab] = useState<Tab>("products");

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="container mx-auto px-4 py-8">
        {activeTab === "products" && <ProductsTab />}
        {activeTab === "cart" && <CartTab />}
        {activeTab === "records" && <RecordsTab />}
      </main>
    </div>
  );
}

const Index = () => {
  return (
    <StoreProvider>
      <StoreContent />
      <Toaster />
    </StoreProvider>
  );
};

export default Index;
