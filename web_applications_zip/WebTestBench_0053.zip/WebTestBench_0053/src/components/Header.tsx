import { Coins, ShoppingBag, Gift, ClipboardList } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { Badge } from "@/components/ui/badge";

type Tab = "products" | "cart" | "records";

interface HeaderProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function Header({ activeTab, onTabChange }: HeaderProps) {
  const { points, cart } = useStore();
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const tabs = [
    { id: "products" as Tab, label: "Products", icon: Gift },
    { id: "cart" as Tab, label: "Redemption Cart", icon: ShoppingBag },
    { id: "records" as Tab, label: "My Records", icon: ClipboardList },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-card/80 backdrop-blur-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
              <Gift className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold text-foreground">
                Rewards Store
              </h1>
              <p className="text-xs text-muted-foreground">
                Redeem your hard-earned points
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-full bg-gradient-to-r from-points/10 to-points/5 px-4 py-2">
            <Coins className="h-5 w-5 text-points" />
            <span className="font-display text-lg font-bold text-points">
              {points.toLocaleString()}
            </span>
            <span className="text-sm text-muted-foreground">pts</span>
          </div>
        </div>

        <nav className="flex gap-1 pb-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`relative flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
                {tab.id === "cart" && cartItemCount > 0 && (
                  <Badge
                    variant="default"
                    className="ml-1 h-5 min-w-[20px] rounded-full bg-accent px-1.5 text-xs text-accent-foreground"
                  >
                    {cartItemCount}
                  </Badge>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-primary" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
