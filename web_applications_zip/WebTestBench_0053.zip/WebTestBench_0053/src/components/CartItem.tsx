import { Minus, Plus, Trash2 } from "lucide-react";
import { CartItem as CartItemType } from "@/data/merchandise";
import { useStore } from "@/context/StoreContext";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

interface CartItemProps {
  item: CartItemType;
  isSelected: boolean;
  onSelectChange: (checked: boolean) => void;
  onRequestDelete: () => void;
}

export function CartItem({
  item,
  isSelected,
  onSelectChange,
  onRequestDelete,
}: CartItemProps) {
  const { updateCartItemQuantity, products, points } = useStore();
  const { product, quantity } = item;

  const currentProduct = products.find((p) => p.id === product.id);
  const maxStock = currentProduct?.stock ?? 0;
  const itemTotal = product.points * quantity;
  const insufficientPoints = itemTotal > points;

  return (
    <div className="flex gap-4 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-muted/30">
      <Checkbox
        checked={isSelected}
        onCheckedChange={onSelectChange}
        className="mt-1"
      />

      <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-lg bg-muted">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover"
        />
      </div>

      <div className="flex flex-1 flex-col justify-between">
        <div>
          <h3 className="font-display font-semibold text-foreground">
            {product.name}
          </h3>
          <p className="text-sm text-muted-foreground">{product.category}</p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={() => updateCartItemQuantity(product.id, quantity - 1)}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <span className="w-8 text-center font-medium">{quantity}</span>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={() => updateCartItemQuantity(product.id, quantity + 1)}
            disabled={quantity >= maxStock}
          >
            <Plus className="h-3 w-3" />
          </Button>
          {quantity >= maxStock && (
            <span className="text-xs text-warning">Max</span>
          )}
        </div>
      </div>

      <div className="flex flex-col items-end justify-between">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
          onClick={onRequestDelete}
        >
          <Trash2 className="h-4 w-4" />
        </Button>

        <div className="text-right">
          <div
            className={`font-display text-lg font-bold ${
              insufficientPoints ? "text-destructive" : "text-points"
            }`}
          >
            {itemTotal.toLocaleString()}
          </div>
          <span className="text-xs text-muted-foreground">
            {product.points.toLocaleString()} × {quantity}
          </span>
        </div>
      </div>
    </div>
  );
}
