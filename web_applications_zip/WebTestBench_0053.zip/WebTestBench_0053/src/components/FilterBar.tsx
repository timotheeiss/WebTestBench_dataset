import { Filter, ArrowUpDown, TrendingUp, ArrowDown, ArrowUp } from "lucide-react";
import { categories, Category } from "@/data/merchandise";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type SortOption = "popularity" | "points-low" | "points-high";

interface FilterBarProps {
  selectedCategory: Category;
  onCategoryChange: (category: Category) => void;
  sortOption: SortOption;
  onSortChange: (sort: SortOption) => void;
  totalProducts: number;
}

export function FilterBar({
  selectedCategory,
  onCategoryChange,
  sortOption,
  onSortChange,
  totalProducts,
}: FilterBarProps) {
  const sortOptions = [
    { value: "popularity", label: "Most Popular", icon: TrendingUp },
    { value: "points-low", label: "Points: Low to High", icon: ArrowUp },
    { value: "points-high", label: "Points: High to Low", icon: ArrowDown },
  ] as const;

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-wrap items-center gap-2">
        <Filter className="h-4 w-4 text-muted-foreground" />
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => onCategoryChange(category)}
            className="h-8 text-xs"
          >
            {category}
          </Button>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <span className="text-sm text-muted-foreground">
          {totalProducts} items
        </span>
        <Select
          value={sortOption}
          onValueChange={(value) => onSortChange(value as SortOption)}
        >
          <SelectTrigger className="w-[180px] h-9">
            <ArrowUpDown className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map((option) => {
              const Icon = option.icon;
              return (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    {option.label}
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
