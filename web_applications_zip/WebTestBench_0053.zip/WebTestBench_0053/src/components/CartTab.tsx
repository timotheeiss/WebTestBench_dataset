import { useState } from "react";
import { ShoppingBag, Trash2, Gift, AlertCircle } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { CartItem } from "@/components/CartItem";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";

export function CartTab() {
  const { cart, points, removeFromCart, removeMultipleFromCart, redeemCart, getCartTotal } =
    useStore();
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [redeemDialogOpen, setRedeemDialogOpen] = useState(false);

  const cartTotal = getCartTotal();
  const hasInsufficientPoints = cartTotal > points;
  const allSelected =
    cart.length > 0 && selectedItems.size === cart.length;
  const someSelected = selectedItems.size > 0;

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(new Set(cart.map((item) => item.product.id)));
    } else {
      setSelectedItems(new Set());
    }
  };

  const handleItemSelect = (productId: string, checked: boolean) => {
    const newSelected = new Set(selectedItems);
    if (checked) {
      newSelected.add(productId);
    } else {
      newSelected.delete(productId);
    }
    setSelectedItems(newSelected);
  };

  const handleRequestDelete = (productId: string) => {
    setItemToDelete(productId);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (itemToDelete) {
      removeFromCart(itemToDelete);
      selectedItems.delete(itemToDelete);
      setSelectedItems(new Set(selectedItems));
      toast({
        title: "Item Removed",
        description: "The item has been removed from your cart.",
      });
    }
    setItemToDelete(null);
    setDeleteDialogOpen(false);
  };

  const handleDeleteSelected = () => {
    removeMultipleFromCart(Array.from(selectedItems));
    setSelectedItems(new Set());
    setDeleteDialogOpen(false);
    toast({
      title: "Items Removed",
      description: `${selectedItems.size} items have been removed from your cart.`,
    });
  };

  const handleConfirmRedeem = () => {
    const result = redeemCart();
    setRedeemDialogOpen(false);

    if (result.success) {
      setSelectedItems(new Set());
      toast({
        title: "🎉 Redemption Successful!",
        description: "Your items are on their way!",
      });
    } else {
      toast({
        variant: "destructive",
        title: "Redemption Failed",
        description: result.message,
      });
    }
  };

  if (cart.length === 0) {
    return (
      <div className="animate-fade-in flex flex-col items-center justify-center py-20 text-center">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <ShoppingBag className="h-8 w-8 text-muted-foreground" />
        </div>
        <h2 className="font-display text-xl font-semibold text-foreground">
          Your cart is empty
        </h2>
        <p className="mt-2 text-muted-foreground">
          Browse products and add items to your cart to redeem them.
        </p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6">
      {/* Batch Actions */}
      <div className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
        <div className="flex items-center gap-3">
          <Checkbox
            checked={allSelected}
            onCheckedChange={handleSelectAll}
            aria-label="Select all items"
          />
          <span className="text-sm text-muted-foreground">
            {someSelected
              ? `${selectedItems.size} of ${cart.length} selected`
              : "Select all"}
          </span>
        </div>
        {someSelected && (
          <Button
            variant="outline"
            size="sm"
            className="gap-2 text-destructive hover:bg-destructive hover:text-destructive-foreground"
            onClick={() => {
              setItemToDelete(null);
              setDeleteDialogOpen(true);
            }}
          >
            <Trash2 className="h-4 w-4" />
            Delete Selected ({selectedItems.size})
          </Button>
        )}
      </div>

      {/* Cart Items */}
      <div className="space-y-3">
        {cart.map((item) => (
          <CartItem
            key={item.product.id}
            item={item}
            isSelected={selectedItems.has(item.product.id)}
            onSelectChange={(checked) =>
              handleItemSelect(item.product.id, checked)
            }
            onRequestDelete={() => handleRequestDelete(item.product.id)}
          />
        ))}
      </div>

      {/* Summary */}
      <div className="rounded-lg border border-border bg-card p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Total Points</p>
            <div className="flex items-baseline gap-2">
              <span
                className={`font-display text-3xl font-bold ${
                  hasInsufficientPoints ? "text-destructive" : "text-points"
                }`}
              >
                {cartTotal.toLocaleString()}
              </span>
              <span className="text-muted-foreground">pts</span>
            </div>
            {hasInsufficientPoints && (
              <div className="mt-1 flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                <span>
                  You need {(cartTotal - points).toLocaleString()} more points
                </span>
              </div>
            )}
          </div>

          <Button
            size="lg"
            className="gap-2"
            disabled={hasInsufficientPoints || cart.length === 0}
            onClick={() => setRedeemDialogOpen(true)}
          >
            <Gift className="h-5 w-5" />
            Redeem All Items
          </Button>
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-border pt-4 text-sm">
          <span className="text-muted-foreground">Your Balance</span>
          <span className="font-medium text-foreground">
            {points.toLocaleString()} pts
          </span>
        </div>
        <div className="mt-2 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">After Redemption</span>
          <span
            className={`font-medium ${
              hasInsufficientPoints ? "text-destructive" : "text-success"
            }`}
          >
            {(points - cartTotal).toLocaleString()} pts
          </span>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {itemToDelete ? "Remove Item?" : "Remove Selected Items?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {itemToDelete
                ? "This item will be removed from your cart. You can add it again later."
                : `${selectedItems.size} item(s) will be removed from your cart. You can add them again later.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={itemToDelete ? handleConfirmDelete : handleDeleteSelected}
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Redeem Confirmation Dialog */}
      <AlertDialog open={redeemDialogOpen} onOpenChange={setRedeemDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Redemption</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to redeem {cart.length} item(s) for{" "}
              <span className="font-semibold text-points">
                {cartTotal.toLocaleString()} points
              </span>
              . Your remaining balance will be{" "}
              <span className="font-semibold">
                {(points - cartTotal).toLocaleString()} points
              </span>
              .
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmRedeem}>
              Confirm Redemption
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
