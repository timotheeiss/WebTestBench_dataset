import { useMemo, useState } from "react";
import { useStore } from "@/context/StoreContext";
import { Category } from "@/data/merchandise";
import { ProductCard } from "@/components/ProductCard";
import { FilterBar, SortOption } from "@/components/FilterBar";

export function ProductsTab() {
  const { products } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [sortOption, setSortOption] = useState<SortOption>("popularity");

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = [...products];

    // Filter by category
    if (selectedCategory !== "All") {
      filtered = filtered.filter(
        (product) => product.category === selectedCategory
      );
    }

    // Sort
    switch (sortOption) {
      case "popularity":
        filtered.sort((a, b) => b.popularity - a.popularity);
        break;
      case "points-low":
        filtered.sort((a, b) => a.points - b.points);
        break;
      case "points-high":
        filtered.sort((a, b) => b.points - a.points);
        break;
    }

    return filtered;
  }, [products, selectedCategory, sortOption]);

  return (
    <div className="animate-fade-in space-y-6">
      <FilterBar
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        sortOption={sortOption}
        onSortChange={setSortOption}
        totalProducts={filteredAndSortedProducts.length}
      />

      {filteredAndSortedProducts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-muted-foreground">
            No products found in this category.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredAndSortedProducts.map((product, index) => (
            <div
              key={product.id}
              className="animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
