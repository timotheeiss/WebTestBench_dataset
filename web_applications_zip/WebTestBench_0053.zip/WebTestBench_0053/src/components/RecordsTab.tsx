import { ClipboardList, Package, Calendar } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export function RecordsTab() {
  const { redemptionHistory } = useStore();

  if (redemptionHistory.length === 0) {
    return (
      <div className="animate-fade-in flex flex-col items-center justify-center py-20 text-center">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <ClipboardList className="h-8 w-8 text-muted-foreground" />
        </div>
        <h2 className="font-display text-xl font-semibold text-foreground">
          No redemption history
        </h2>
        <p className="mt-2 text-muted-foreground">
          Your past redemptions will appear here after you redeem items.
        </p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold text-foreground">
          Redemption History
        </h2>
        <Badge variant="secondary">{redemptionHistory.length} orders</Badge>
      </div>

      <div className="space-y-4">
        {redemptionHistory.map((record, index) => (
          <div
            key={record.id}
            className="animate-slide-up rounded-lg border border-border bg-card p-5 shadow-card"
            style={{ animationDelay: `${index * 75}ms` }}
          >
            <div className="mb-4 flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <Package className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-display font-semibold text-foreground">
                    Order #{record.id.slice(-8).toUpperCase()}
                  </p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {format(record.redeemedAt, "MMM d, yyyy 'at' h:mm a")}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-display text-lg font-bold text-points">
                  -{record.totalPoints.toLocaleString()}
                </span>
                <span className="ml-1 text-sm text-muted-foreground">pts</span>
              </div>
            </div>

            <div className="space-y-2 border-t border-border pt-4">
              {record.items.map((item, itemIndex) => (
                <div
                  key={itemIndex}
                  className="flex items-center justify-between text-sm"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-foreground">{item.name}</span>
                    {item.quantity > 1 && (
                      <Badge variant="outline" className="text-xs">
                        ×{item.quantity}
                      </Badge>
                    )}
                  </div>
                  <span className="text-muted-foreground">
                    {(item.points * item.quantity).toLocaleString()} pts
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
