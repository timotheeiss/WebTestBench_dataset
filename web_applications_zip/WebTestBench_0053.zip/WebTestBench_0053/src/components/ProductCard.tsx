import { ShoppingCart, Check, AlertTriangle } from "lucide-react";
import { Product } from "@/data/merchandise";
import { useStore } from "@/context/StoreContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, isInCart, points } = useStore();
  const inCart = isInCart(product.id);
  const outOfStock = product.stock === 0;
  const insufficientPoints = product.points > points;

  const handleAddToCart = () => {
    if (outOfStock) {
      toast({
        variant: "destructive",
        title: "Out of Stock",
        description: `${product.name} is currently unavailable.`,
      });
      return;
    }
    addToCart(product);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-all duration-300 hover:shadow-card-hover">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
        {outOfStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm">
            <Badge variant="secondary" className="gap-1 text-muted-foreground">
              <AlertTriangle className="h-3 w-3" />
              Out of Stock
            </Badge>
          </div>
        )}
        <Badge className="absolute left-3 top-3 bg-secondary text-secondary-foreground">
          {product.category}
        </Badge>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-4">
        <h3 className="font-display text-base font-semibold text-foreground line-clamp-1">
          {product.name}
        </h3>
        <p className="mt-1 flex-1 text-sm text-muted-foreground line-clamp-2">
          {product.description}
        </p>

        <div className="mt-4 flex items-end justify-between">
          <div>
            <div className="flex items-baseline gap-1">
              <span
                className={`font-display text-xl font-bold ${
                  insufficientPoints ? "text-muted-foreground" : "text-points"
                }`}
              >
                {product.points.toLocaleString()}
              </span>
              <span className="text-xs text-muted-foreground">pts</span>
            </div>
            {insufficientPoints && !outOfStock && (
              <p className="text-xs text-destructive">
                Need {(product.points - points).toLocaleString()} more
              </p>
            )}
            {!outOfStock && product.stock <= 5 && (
              <p className="text-xs text-warning">Only {product.stock} left</p>
            )}
          </div>

          <Button
            size="sm"
            onClick={handleAddToCart}
            disabled={outOfStock}
            variant={inCart ? "secondary" : "default"}
            className="gap-1.5"
          >
            {inCart ? (
              <>
                <Check className="h-4 w-4" />
                In Cart
              </>
            ) : (
              <>
                <ShoppingCart className="h-4 w-4" />
                Add
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
