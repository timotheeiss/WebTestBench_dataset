export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  points: number;
  category: string;
  stock: number;
  popularity: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface RedemptionRecord {
  id: string;
  items: { name: string; quantity: number; points: number }[];
  totalPoints: number;
  redeemedAt: Date;
}

export const categories = [
  "All",
  "Electronics",
  "Apparel",
  "Accessories",
  "Home & Office",
  "Wellness",
] as const;

export type Category = (typeof categories)[number];

export const products: Product[] = [
  {
    id: "1",
    name: "Wireless Earbuds Pro",
    description: "Premium noise-cancelling earbuds with 24-hour battery life and crystal-clear audio quality.",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop",
    points: 2500,
    category: "Electronics",
    stock: 15,
    popularity: 95,
  },
  {
    id: "2",
    name: "Company Logo Hoodie",
    description: "Soft cotton blend hoodie featuring our embroidered company logo. Perfect for casual Fridays.",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&h=400&fit=crop",
    points: 800,
    category: "Apparel",
    stock: 42,
    popularity: 88,
  },
  {
    id: "3",
    name: "Smart Water Bottle",
    description: "Temperature-tracking bottle that reminds you to stay hydrated throughout the day.",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop",
    points: 450,
    category: "Wellness",
    stock: 28,
    popularity: 72,
  },
  {
    id: "4",
    name: "Leather Laptop Sleeve",
    description: "Genuine leather sleeve fits up to 15\" laptops. Elegant protection for your device.",
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=400&fit=crop",
    points: 1200,
    category: "Accessories",
    stock: 20,
    popularity: 85,
  },
  {
    id: "5",
    name: "Ergonomic Desk Lamp",
    description: "Adjustable LED lamp with multiple brightness levels and color temperatures.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    points: 650,
    category: "Home & Office",
    stock: 35,
    popularity: 78,
  },
  {
    id: "6",
    name: "Portable Charger 20000mAh",
    description: "High-capacity power bank with fast charging. Keep all your devices powered on the go.",
    image: "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&h=400&fit=crop",
    points: 900,
    category: "Electronics",
    stock: 0,
    popularity: 92,
  },
  {
    id: "7",
    name: "Yoga Mat Premium",
    description: "Non-slip eco-friendly yoga mat with alignment lines and carrying strap.",
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop",
    points: 350,
    category: "Wellness",
    stock: 18,
    popularity: 65,
  },
  {
    id: "8",
    name: "Wireless Keyboard & Mouse",
    description: "Sleek wireless combo with quiet keys and precision tracking. Perfect for productivity.",
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400&h=400&fit=crop",
    points: 1100,
    category: "Electronics",
    stock: 12,
    popularity: 82,
  },
  {
    id: "9",
    name: "Executive Backpack",
    description: "Water-resistant backpack with laptop compartment, USB charging port, and anti-theft design.",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop",
    points: 1500,
    category: "Accessories",
    stock: 8,
    popularity: 90,
  },
  {
    id: "10",
    name: "Desktop Plant Set",
    description: "Set of 3 low-maintenance succulents in modern ceramic pots. Brighten up your workspace.",
    image: "https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?w=400&h=400&fit=crop",
    points: 280,
    category: "Home & Office",
    stock: 25,
    popularity: 70,
  },
  {
    id: "11",
    name: "Company Polo Shirt",
    description: "Breathable performance polo with subtle company branding. Business casual essential.",
    image: "https://images.unsplash.com/photo-1625910513413-5fc42e2c9dc8?w=400&h=400&fit=crop",
    points: 500,
    category: "Apparel",
    stock: 55,
    popularity: 75,
  },
  {
    id: "12",
    name: "Bluetooth Speaker",
    description: "Compact waterproof speaker with 360° sound and 12-hour playtime.",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop",
    points: 750,
    category: "Electronics",
    stock: 22,
    popularity: 86,
  },
];

export const initialUserPoints = 5000;
