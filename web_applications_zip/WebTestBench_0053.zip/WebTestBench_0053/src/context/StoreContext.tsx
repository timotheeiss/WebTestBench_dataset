import React, { createContext, useContext, useState, useCallback } from "react";
import {
  Product,
  CartItem,
  RedemptionRecord,
  products as initialProducts,
  initialUserPoints,
} from "@/data/merchandise";

interface StoreContextType {
  products: Product[];
  cart: CartItem[];
  points: number;
  redemptionHistory: RedemptionRecord[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartItemQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  removeMultipleFromCart: (productIds: string[]) => void;
  redeemCart: () => { success: boolean; message: string };
  getCartTotal: () => number;
  isInCart: (productId: string) => boolean;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [points, setPoints] = useState(initialUserPoints);
  const [redemptionHistory, setRedemptionHistory] = useState<RedemptionRecord[]>([
    {
      id: "demo-1",
      items: [
        { name: "Company Logo Hoodie", quantity: 1, points: 800 },
        { name: "Smart Water Bottle", quantity: 2, points: 450 },
      ],
      totalPoints: 1700,
      redeemedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    },
  ]);

  const addToCart = useCallback((product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  }, []);

  const updateCartItemQuantity = useCallback(
    (productId: string, quantity: number) => {
      if (quantity <= 0) {
        removeFromCart(productId);
        return;
      }
      setCart((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
    },
    [removeFromCart]
  );

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const removeMultipleFromCart = useCallback((productIds: string[]) => {
    setCart((prev) =>
      prev.filter((item) => !productIds.includes(item.product.id))
    );
  }, []);

  const getCartTotal = useCallback(() => {
    return cart.reduce(
      (sum, item) => sum + item.product.points * item.quantity,
      0
    );
  }, [cart]);

  const isInCart = useCallback(
    (productId: string) => {
      return cart.some((item) => item.product.id === productId);
    },
    [cart]
  );

  const redeemCart = useCallback(() => {
    const total = getCartTotal();

    if (cart.length === 0) {
      return { success: false, message: "Your cart is empty." };
    }

    if (total > points) {
      return {
        success: false,
        message: `Insufficient points. You need ${total - points} more points.`,
      };
    }

    // Check stock for all items
    for (const item of cart) {
      const currentProduct = products.find((p) => p.id === item.product.id);
      if (!currentProduct || currentProduct.stock < item.quantity) {
        return {
          success: false,
          message: `"${item.product.name}" has insufficient stock.`,
        };
      }
    }

    // Create redemption record
    const record: RedemptionRecord = {
      id: `redemption-${Date.now()}`,
      items: cart.map((item) => ({
        name: item.product.name,
        quantity: item.quantity,
        points: item.product.points,
      })),
      totalPoints: total,
      redeemedAt: new Date(),
    };

    // Update stock
    setProducts((prev) =>
      prev.map((product) => {
        const cartItem = cart.find((item) => item.product.id === product.id);
        if (cartItem) {
          return { ...product, stock: product.stock - cartItem.quantity };
        }
        return product;
      })
    );

    // Deduct points and update history
    setPoints((prev) => prev - total);
    setRedemptionHistory((prev) => [record, ...prev]);
    clearCart();

    return { success: true, message: "Redemption successful!" };
  }, [cart, points, products, getCartTotal, clearCart]);

  return (
    <StoreContext.Provider
      value={{
        products,
        cart,
        points,
        redemptionHistory,
        addToCart,
        removeFromCart,
        updateCartItemQuantity,
        clearCart,
        removeMultipleFromCart,
        redeemCart,
        getCartTotal,
        isInCart,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  return context;
}
