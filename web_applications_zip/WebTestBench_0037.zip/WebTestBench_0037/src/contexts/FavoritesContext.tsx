import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface FavoritesContextType {
  favorites: string[];
  addFavorite: (petId: string) => void;
  removeFavorite: (petId: string) => void;
  isFavorite: (petId: string) => boolean;
  toggleFavorite: (petId: string) => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

const STORAGE_KEY = 'pawfect-favorites';

export const FavoritesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const addFavorite = (petId: string) => {
    setFavorites(prev => [...prev, petId]);
  };

  const removeFavorite = (petId: string) => {
    setFavorites(prev => prev.filter(id => id !== petId));
  };

  const isFavorite = (petId: string) => {
    return favorites.includes(petId);
  };

  const toggleFavorite = (petId: string) => {
    if (isFavorite(petId)) {
      removeFavorite(petId);
    } else {
      addFavorite(petId);
    }
  };

  return (
    <FavoritesContext.Provider value={{ favorites, addFavorite, removeFavorite, isFavorite, toggleFavorite }}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
