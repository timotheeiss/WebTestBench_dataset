export type Species = 'dog' | 'cat' | 'rabbit' | 'bird';
export type Size = 'small' | 'medium' | 'large';
export type AgeGroup = 'baby' | 'young' | 'adult' | 'senior';

export interface Pet {
  id: string;
  name: string;
  species: Species;
  breed: string;
  age: number;
  ageGroup: AgeGroup;
  size: Size;
  gender: 'male' | 'female';
  goodWithKids: boolean;
  goodWithPets: boolean;
  description: string;
  photos: string[];
  shelterId: string;
  shelterName: string;
  location: string;
  listedAt: Date;
  personality: string[];
  vaccinated: boolean;
  neutered: boolean;
}

export interface Shelter {
  id: string;
  name: string;
  location: string;
  phone: string;
  email: string;
}

export const shelters: Shelter[] = [
  {
    id: 'shelter-1',
    name: 'Happy Tails Rescue',
    location: 'Portland, OR',
    phone: '(503) 555-0123',
    email: 'adopt@happytails.org'
  },
  {
    id: 'shelter-2',
    name: 'Second Chance Animal Haven',
    location: 'Seattle, WA',
    phone: '(206) 555-0456',
    email: 'info@secondchancehaven.org'
  },
  {
    id: 'shelter-3',
    name: 'Furry Friends Forever',
    location: 'San Francisco, CA',
    phone: '(415) 555-0789',
    email: 'hello@furryfriendsforever.org'
  }
];

export const pets: Pet[] = [
  {
    id: 'pet-1',
    name: 'Luna',
    species: 'dog',
    breed: 'Golden Retriever Mix',
    age: 3,
    ageGroup: 'adult',
    size: 'large',
    gender: 'female',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Luna is the sweetest girl you\'ll ever meet! She loves belly rubs, playing fetch, and cuddling on the couch. She\'s fully trained and walks beautifully on a leash. Luna would thrive in an active family who can give her lots of love and outdoor adventures.',
    photos: [
      'https://images.unsplash.com/photo-1552053831-71594a27632d?w=600',
      'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600'
    ],
    shelterId: 'shelter-1',
    shelterName: 'Happy Tails Rescue',
    location: 'Portland, OR',
    listedAt: new Date('2024-11-15'),
    personality: ['Friendly', 'Playful', 'Gentle'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-2',
    name: 'Oliver',
    species: 'cat',
    breed: 'Orange Tabby',
    age: 2,
    ageGroup: 'young',
    size: 'medium',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Oliver is a charming orange tabby with the most expressive eyes. He loves to chirp at birds through the window and will follow you around the house. He\'s very social and gets along great with other cats.',
    photos: [
      'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=600',
      'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=600'
    ],
    shelterId: 'shelter-2',
    shelterName: 'Second Chance Animal Haven',
    location: 'Seattle, WA',
    listedAt: new Date('2024-11-20'),
    personality: ['Curious', 'Affectionate', 'Social'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-3',
    name: 'Max',
    species: 'dog',
    breed: 'Border Collie',
    age: 1,
    ageGroup: 'young',
    size: 'medium',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: false,
    description: 'Max is an incredibly smart and energetic Border Collie who loves to learn new tricks. He needs an active owner who can provide mental stimulation and plenty of exercise. He would do best as the only pet in the home.',
    photos: [
      'https://images.unsplash.com/photo-1503256207526-0d5d80fa2f47?w=600',
      'https://images.unsplash.com/photo-1477884213360-7e9d7dcc1e48?w=600'
    ],
    shelterId: 'shelter-1',
    shelterName: 'Happy Tails Rescue',
    location: 'Portland, OR',
    listedAt: new Date('2024-12-01'),
    personality: ['Intelligent', 'Energetic', 'Loyal'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-4',
    name: 'Whiskers',
    species: 'cat',
    breed: 'Siamese Mix',
    age: 5,
    ageGroup: 'adult',
    size: 'medium',
    gender: 'female',
    goodWithKids: false,
    goodWithPets: true,
    description: 'Whiskers is a beautiful Siamese mix with striking blue eyes. She\'s a bit shy at first but warms up quickly. She prefers a quiet home without young children but loves the company of other calm cats.',
    photos: [
      'https://images.unsplash.com/photo-1592194996308-7b43878e84a6?w=600',
      'https://images.unsplash.com/photo-1478098711619-5ab0b478d6e6?w=600'
    ],
    shelterId: 'shelter-3',
    shelterName: 'Furry Friends Forever',
    location: 'San Francisco, CA',
    listedAt: new Date('2024-10-28'),
    personality: ['Calm', 'Independent', 'Elegant'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-5',
    name: 'Biscuit',
    species: 'rabbit',
    breed: 'Holland Lop',
    age: 1,
    ageGroup: 'young',
    size: 'small',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Biscuit is an adorable Holland Lop with the floppiest ears! He loves to hop around and explore. He\'s litter trained and enjoys being petted. Perfect for families looking for a gentle, interactive pet.',
    photos: [
      'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=600',
      'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=600'
    ],
    shelterId: 'shelter-2',
    shelterName: 'Second Chance Animal Haven',
    location: 'Seattle, WA',
    listedAt: new Date('2024-11-25'),
    personality: ['Gentle', 'Curious', 'Friendly'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-6',
    name: 'Duke',
    species: 'dog',
    breed: 'German Shepherd',
    age: 7,
    ageGroup: 'senior',
    size: 'large',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Duke is a gentle giant who has spent his life as a family dog. His previous owner passed away, and he\'s looking for a loving home to spend his golden years. He\'s calm, well-trained, and loves car rides.',
    photos: [
      'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=600',
      'https://images.unsplash.com/photo-1568572933382-74d440642117?w=600'
    ],
    shelterId: 'shelter-1',
    shelterName: 'Happy Tails Rescue',
    location: 'Portland, OR',
    listedAt: new Date('2024-12-05'),
    personality: ['Calm', 'Loyal', 'Gentle'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-7',
    name: 'Mochi',
    species: 'cat',
    breed: 'Scottish Fold',
    age: 0.5,
    ageGroup: 'baby',
    size: 'small',
    gender: 'female',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Mochi is an irresistible Scottish Fold kitten with adorable folded ears. She\'s playful, loves to chase toys, and purrs constantly. She would love a home with another young cat to play with.',
    photos: [
      'https://images.unsplash.com/photo-1574158622682-e40e69881006?w=600',
      'https://images.unsplash.com/photo-1495360010541-f48722b34f7d?w=600'
    ],
    shelterId: 'shelter-3',
    shelterName: 'Furry Friends Forever',
    location: 'San Francisco, CA',
    listedAt: new Date('2024-12-10'),
    personality: ['Playful', 'Sweet', 'Cuddly'],
    vaccinated: true,
    neutered: false
  },
  {
    id: 'pet-8',
    name: 'Sunny',
    species: 'bird',
    breed: 'Cockatiel',
    age: 2,
    ageGroup: 'young',
    size: 'small',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: false,
    description: 'Sunny is a cheerful cockatiel who loves to whistle and sing! He can mimic simple tunes and enjoys sitting on shoulders. He needs a home without cats or other predatory pets.',
    photos: [
      'https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=600',
      'https://images.unsplash.com/photo-1444464666168-49d633b86797?w=600'
    ],
    shelterId: 'shelter-2',
    shelterName: 'Second Chance Animal Haven',
    location: 'Seattle, WA',
    listedAt: new Date('2024-11-18'),
    personality: ['Cheerful', 'Musical', 'Social'],
    vaccinated: true,
    neutered: false
  },
  {
    id: 'pet-9',
    name: 'Bella',
    species: 'dog',
    breed: 'French Bulldog',
    age: 4,
    ageGroup: 'adult',
    size: 'small',
    gender: 'female',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Bella is a lovable French Bulldog with the cutest snorts! She\'s a couch potato who loves naps but also enjoys short walks. She\'s great with everyone and would fit perfectly in any loving home.',
    photos: [
      'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600',
      'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600'
    ],
    shelterId: 'shelter-3',
    shelterName: 'Furry Friends Forever',
    location: 'San Francisco, CA',
    listedAt: new Date('2024-11-30'),
    personality: ['Laid-back', 'Loving', 'Friendly'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-10',
    name: 'Shadow',
    species: 'cat',
    breed: 'Black Domestic Shorthair',
    age: 3,
    ageGroup: 'adult',
    size: 'medium',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Shadow is a sleek black cat with mesmerizing golden eyes. He\'s been overlooked because of his color, but he\'s one of the most affectionate cats we\'ve ever had. He loves to be held and will purr for hours.',
    photos: [
      'https://images.unsplash.com/photo-1618826411640-d6df44dd3f7a?w=600',
      'https://images.unsplash.com/photo-1571566882372-1598d88abd90?w=600'
    ],
    shelterId: 'shelter-1',
    shelterName: 'Happy Tails Rescue',
    location: 'Portland, OR',
    listedAt: new Date('2024-10-15'),
    personality: ['Affectionate', 'Calm', 'Loyal'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-11',
    name: 'Cinnamon',
    species: 'rabbit',
    breed: 'Rex',
    age: 2,
    ageGroup: 'young',
    size: 'medium',
    gender: 'female',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Cinnamon has the softest velvet-like fur you\'ve ever felt! She\'s very social and loves to binky when she\'s happy. She would love a home with space to run and explore.',
    photos: [
      'https://images.unsplash.com/photo-1535241749838-299277b6305f?w=600',
      'https://images.unsplash.com/photo-1518796745738-41048802f99a?w=600'
    ],
    shelterId: 'shelter-3',
    shelterName: 'Furry Friends Forever',
    location: 'San Francisco, CA',
    listedAt: new Date('2024-12-08'),
    personality: ['Active', 'Friendly', 'Soft'],
    vaccinated: true,
    neutered: true
  },
  {
    id: 'pet-12',
    name: 'Charlie',
    species: 'dog',
    breed: 'Beagle Mix',
    age: 5,
    ageGroup: 'adult',
    size: 'medium',
    gender: 'male',
    goodWithKids: true,
    goodWithPets: true,
    description: 'Charlie is a happy-go-lucky Beagle mix who loves everyone he meets. He\'s great on walks and has a nose for adventure. He gets along with all dogs and cats and would love to be part of a busy household.',
    photos: [
      'https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=600',
      'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?w=600'
    ],
    shelterId: 'shelter-2',
    shelterName: 'Second Chance Animal Haven',
    location: 'Seattle, WA',
    listedAt: new Date('2024-11-22'),
    personality: ['Happy', 'Adventurous', 'Social'],
    vaccinated: true,
    neutered: true
  }
];

export const getPetById = (id: string): Pet | undefined => {
  return pets.find(pet => pet.id === id);
};

export const getShelterById = (id: string): Shelter | undefined => {
  return shelters.find(shelter => shelter.id === id);
};
