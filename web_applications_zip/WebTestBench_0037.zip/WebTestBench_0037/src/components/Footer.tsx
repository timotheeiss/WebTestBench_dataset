import { PawPrint, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary">
              <PawPrint className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-semibold">PawfectMatch</span>
          </div>
          
          <nav className="flex gap-6 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">
              Home
            </Link>
            <Link to="/pets" className="hover:text-foreground transition-colors">
              Find Pets
            </Link>
            <Link to="/favorites" className="hover:text-foreground transition-colors">
              Favorites
            </Link>
          </nav>

          <p className="flex items-center gap-1 text-sm text-muted-foreground">
            Made with <Heart className="h-4 w-4 fill-accent text-accent" /> for pets everywhere
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
