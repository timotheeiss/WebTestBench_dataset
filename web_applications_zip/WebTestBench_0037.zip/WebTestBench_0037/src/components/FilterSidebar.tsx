import { Species, Size, AgeGroup } from '@/data/pets';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { X, Filter } from 'lucide-react';

export interface Filters {
  species: Species[];
  sizes: Size[];
  ageGroups: AgeGroup[];
  goodWithKids: boolean | null;
  goodWithPets: boolean | null;
}

interface FilterSidebarProps {
  filters: Filters;
  onFiltersChange: (filters: Filters) => void;
  onClose?: () => void;
  isMobile?: boolean;
}

const speciesOptions: { value: Species; label: string }[] = [
  { value: 'dog', label: 'Dogs' },
  { value: 'cat', label: 'Cats' },
  { value: 'rabbit', label: 'Rabbits' },
  { value: 'bird', label: 'Birds' },
];

const sizeOptions: { value: Size; label: string }[] = [
  { value: 'small', label: 'Small' },
  { value: 'medium', label: 'Medium' },
  { value: 'large', label: 'Large' },
];

const ageOptions: { value: AgeGroup; label: string }[] = [
  { value: 'baby', label: 'Baby (< 1 year)' },
  { value: 'young', label: 'Young (1-3 years)' },
  { value: 'adult', label: 'Adult (4-7 years)' },
  { value: 'senior', label: 'Senior (8+ years)' },
];

const FilterSidebar = ({ filters, onFiltersChange, onClose, isMobile }: FilterSidebarProps) => {
  const toggleArrayFilter = <T extends string>(
    key: 'species' | 'sizes' | 'ageGroups',
    value: T
  ) => {
    const currentArray = filters[key] as T[];
    const newArray = currentArray.includes(value)
      ? currentArray.filter(v => v !== value)
      : [...currentArray, value];
    onFiltersChange({ ...filters, [key]: newArray });
  };

  const toggleBooleanFilter = (key: 'goodWithKids' | 'goodWithPets') => {
    const current = filters[key];
    onFiltersChange({
      ...filters,
      [key]: current === true ? null : true,
    });
  };

  const clearFilters = () => {
    onFiltersChange({
      species: [],
      sizes: [],
      ageGroups: [],
      goodWithKids: null,
      goodWithPets: null,
    });
  };

  const hasActiveFilters =
    filters.species.length > 0 ||
    filters.sizes.length > 0 ||
    filters.ageGroups.length > 0 ||
    filters.goodWithKids !== null ||
    filters.goodWithPets !== null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Filters</h2>
        </div>
        {isMobile && onClose && (
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>

      {hasActiveFilters && (
        <Button variant="outline" size="sm" onClick={clearFilters} className="w-full">
          Clear all filters
        </Button>
      )}

      <Separator />

      {/* Species */}
      <div className="space-y-3">
        <Label className="text-sm font-medium">Species</Label>
        <div className="space-y-2">
          {speciesOptions.map(option => (
            <div key={option.value} className="flex items-center space-x-2">
              <Checkbox
                id={`species-${option.value}`}
                checked={filters.species.includes(option.value)}
                onCheckedChange={() => toggleArrayFilter('species', option.value)}
              />
              <label
                htmlFor={`species-${option.value}`}
                className="text-sm cursor-pointer"
              >
                {option.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Size */}
      <div className="space-y-3">
        <Label className="text-sm font-medium">Size</Label>
        <div className="space-y-2">
          {sizeOptions.map(option => (
            <div key={option.value} className="flex items-center space-x-2">
              <Checkbox
                id={`size-${option.value}`}
                checked={filters.sizes.includes(option.value)}
                onCheckedChange={() => toggleArrayFilter('sizes', option.value)}
              />
              <label
                htmlFor={`size-${option.value}`}
                className="text-sm cursor-pointer"
              >
                {option.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Age */}
      <div className="space-y-3">
        <Label className="text-sm font-medium">Age</Label>
        <div className="space-y-2">
          {ageOptions.map(option => (
            <div key={option.value} className="flex items-center space-x-2">
              <Checkbox
                id={`age-${option.value}`}
                checked={filters.ageGroups.includes(option.value)}
                onCheckedChange={() => toggleArrayFilter('ageGroups', option.value)}
              />
              <label
                htmlFor={`age-${option.value}`}
                className="text-sm cursor-pointer"
              >
                {option.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Compatibility */}
      <div className="space-y-3">
        <Label className="text-sm font-medium">Compatibility</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="good-with-kids"
              checked={filters.goodWithKids === true}
              onCheckedChange={() => toggleBooleanFilter('goodWithKids')}
            />
            <label htmlFor="good-with-kids" className="text-sm cursor-pointer">
              Good with kids
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="good-with-pets"
              checked={filters.goodWithPets === true}
              onCheckedChange={() => toggleBooleanFilter('goodWithPets')}
            />
            <label htmlFor="good-with-pets" className="text-sm cursor-pointer">
              Good with other pets
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;
