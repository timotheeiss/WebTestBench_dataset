import { Link } from 'react-router-dom';
import { Heart, MapPin, Clock } from 'lucide-react';
import { Pet } from '@/data/pets';
import { useFavorites } from '@/contexts/FavoritesContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { formatDistanceToNow } from 'date-fns';

interface PetCardProps {
  pet: Pet;
}

const PetCard = ({ pet }: PetCardProps) => {
  const { isFavorite, toggleFavorite } = useFavorites();
  const favorite = isFavorite(pet.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(pet.id);
  };

  const getAgeLabel = () => {
    if (pet.age < 1) {
      const months = Math.round(pet.age * 12);
      return `${months} month${months !== 1 ? 's' : ''}`;
    }
    return `${pet.age} year${pet.age !== 1 ? 's' : ''}`;
  };

  return (
    <Link to={`/pets/${pet.id}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1">
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={pet.photos[0]}
            alt={pet.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-9 w-9 rounded-full bg-background/80 backdrop-blur hover:bg-background"
            onClick={handleFavoriteClick}
          >
            <Heart
              className={`h-5 w-5 transition-colors ${
                favorite ? 'fill-accent text-accent' : 'text-muted-foreground'
              }`}
            />
          </Button>
          <div className="absolute bottom-2 left-2 flex gap-1">
            <Badge variant="secondary" className="capitalize">
              {pet.species}
            </Badge>
            {pet.goodWithKids && (
              <Badge variant="outline" className="bg-background/80 backdrop-blur">
                Kid-friendly
              </Badge>
            )}
          </div>
        </div>
        <CardContent className="p-4">
          <div className="mb-2 flex items-start justify-between">
            <div>
              <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                {pet.name}
              </h3>
              <p className="text-sm text-muted-foreground">{pet.breed}</p>
            </div>
            <Badge variant="outline" className="capitalize">
              {pet.size}
            </Badge>
          </div>
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {getAgeLabel()}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              {pet.location}
            </span>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Listed {formatDistanceToNow(pet.listedAt, { addSuffix: true })}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
};

export default PetCard;
