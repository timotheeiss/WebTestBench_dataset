import { Link } from 'react-router-dom';
import { Heart, Search, PawPrint } from 'lucide-react';
import { useFavorites } from '@/contexts/FavoritesContext';
import { Button } from '@/components/ui/button';

const Header = () => {
  const { favorites } = useFavorites();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 transition-transform hover:scale-105">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
            <PawPrint className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">PawfectMatch</span>
        </Link>

        <nav className="flex items-center gap-2">
          <Button variant="ghost" asChild className="gap-2">
            <Link to="/pets">
              <Search className="h-4 w-4" />
              <span className="hidden sm:inline">Find Pets</span>
            </Link>
          </Button>
          
          <Button variant="ghost" asChild className="relative gap-2">
            <Link to="/favorites">
              <Heart className="h-4 w-4" />
              <span className="hidden sm:inline">Favorites</span>
              {favorites.length > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-accent text-xs font-medium text-accent-foreground">
                  {favorites.length}
                </span>
              )}
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
