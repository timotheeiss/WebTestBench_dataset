import { useState, useMemo } from 'react';
import { pets, Pet } from '@/data/pets';
import PetCard from '@/components/PetCard';
import FilterSidebar, { Filters } from '@/components/FilterSidebar';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Search, SlidersHorizontal, PawPrint } from 'lucide-react';

type SortOption = 'relevance' | 'newest' | 'oldest' | 'name';

const PetsPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('relevance');
  const [filters, setFilters] = useState<Filters>({
    species: [],
    sizes: [],
    ageGroups: [],
    goodWithKids: null,
    goodWithPets: null,
  });
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const filteredAndSortedPets = useMemo(() => {
    let result = [...pets];

    // Apply search
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        pet =>
          pet.name.toLowerCase().includes(query) ||
          pet.breed.toLowerCase().includes(query) ||
          pet.species.toLowerCase().includes(query) ||
          pet.location.toLowerCase().includes(query)
      );
    }

    // Apply filters
    if (filters.species.length > 0) {
      result = result.filter(pet => filters.species.includes(pet.species));
    }
    if (filters.sizes.length > 0) {
      result = result.filter(pet => filters.sizes.includes(pet.size));
    }
    if (filters.ageGroups.length > 0) {
      result = result.filter(pet => filters.ageGroups.includes(pet.ageGroup));
    }
    if (filters.goodWithKids === true) {
      result = result.filter(pet => pet.goodWithKids);
    }
    if (filters.goodWithPets === true) {
      result = result.filter(pet => pet.goodWithPets);
    }

    // Apply sorting
    switch (sortBy) {
      case 'newest':
        result.sort((a, b) => b.listedAt.getTime() - a.listedAt.getTime());
        break;
      case 'oldest':
        result.sort((a, b) => a.listedAt.getTime() - b.listedAt.getTime());
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'relevance':
      default:
        // Keep original order (or implement relevance scoring)
        break;
    }

    return result;
  }, [pets, searchQuery, filters, sortBy]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    count += filters.species.length;
    count += filters.sizes.length;
    count += filters.ageGroups.length;
    if (filters.goodWithKids) count++;
    if (filters.goodWithPets) count++;
    return count;
  }, [filters]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/20">
        {/* Search Header */}
        <div className="border-b border-border bg-background">
          <div className="container mx-auto px-4 py-6">
            <div className="mb-4">
              <h1 className="text-2xl font-bold md:text-3xl">Find Your Perfect Pet</h1>
              <p className="text-muted-foreground">
                {filteredAndSortedPets.length} adorable pets available for adoption
              </p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by name, breed, or location..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="flex gap-2">
                <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevance</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="name">Name A-Z</SelectItem>
                  </SelectContent>
                </Select>

                <Sheet open={mobileFilterOpen} onOpenChange={setMobileFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="gap-2 lg:hidden">
                      <SlidersHorizontal className="h-4 w-4" />
                      Filters
                      {activeFilterCount > 0 && (
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                          {activeFilterCount}
                        </span>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80 overflow-y-auto">
                    <FilterSidebar
                      filters={filters}
                      onFiltersChange={setFilters}
                      onClose={() => setMobileFilterOpen(false)}
                      isMobile
                    />
                  </SheetContent>
                </Sheet>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-6">
          <div className="flex gap-8">
            {/* Desktop Sidebar */}
            <aside className="hidden w-64 shrink-0 lg:block">
              <div className="sticky top-24 rounded-xl border border-border bg-card p-6 shadow-card">
                <FilterSidebar filters={filters} onFiltersChange={setFilters} />
              </div>
            </aside>

            {/* Pet Grid */}
            <div className="flex-1">
              {filteredAndSortedPets.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                    <PawPrint className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <h3 className="mb-2 text-xl font-semibold">No pets found</h3>
                  <p className="mb-4 text-muted-foreground">
                    Try adjusting your search or filters to find more pets.
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery('');
                      setFilters({
                        species: [],
                        sizes: [],
                        ageGroups: [],
                        goodWithKids: null,
                        goodWithPets: null,
                      });
                    }}
                  >
                    Clear all filters
                  </Button>
                </div>
              ) : (
                <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                  {filteredAndSortedPets.map(pet => (
                    <PetCard key={pet.id} pet={pet} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PetsPage;
