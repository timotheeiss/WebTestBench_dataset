import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getPetById, getShelterById } from '@/data/pets';
import { useFavorites } from '@/contexts/FavoritesContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AdoptionInquiryForm from '@/components/AdoptionInquiryForm';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Heart,
  ArrowLeft,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  PawPrint,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const PetDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isFavorite, toggleFavorite } = useFavorites();
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  const pet = id ? getPetById(id) : undefined;
  const shelter = pet ? getShelterById(pet.shelterId) : undefined;

  if (!pet) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="mb-4 flex h-20 w-20 mx-auto items-center justify-center rounded-full bg-muted">
              <PawPrint className="h-10 w-10 text-muted-foreground" />
            </div>
            <h1 className="mb-2 text-2xl font-bold">Pet Not Found</h1>
            <p className="mb-4 text-muted-foreground">
              We couldn't find the pet you're looking for.
            </p>
            <Button asChild>
              <Link to="/pets">Browse All Pets</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const favorite = isFavorite(pet.id);

  const getAgeLabel = () => {
    if (pet.age < 1) {
      const months = Math.round(pet.age * 12);
      return `${months} month${months !== 1 ? 's' : ''} old`;
    }
    return `${pet.age} year${pet.age !== 1 ? 's' : ''} old`;
  };

  const nextPhoto = () => {
    setCurrentPhotoIndex(prev => (prev + 1) % pet.photos.length);
  };

  const prevPhoto = () => {
    setCurrentPhotoIndex(prev => (prev - 1 + pet.photos.length) % pet.photos.length);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-6">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-4 gap-2"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          <div className="grid gap-8 lg:grid-cols-2">
            {/* Photo Gallery */}
            <div className="space-y-4">
              <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-muted">
                <img
                  src={pet.photos[currentPhotoIndex]}
                  alt={`${pet.name} - Photo ${currentPhotoIndex + 1}`}
                  className="h-full w-full object-cover"
                />
                
                {pet.photos.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur hover:bg-background"
                      onClick={prevPhoto}
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur hover:bg-background"
                      onClick={nextPhoto}
                    >
                      <ChevronRight className="h-5 w-5" />
                    </Button>
                  </>
                )}

                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 top-4 h-10 w-10 rounded-full bg-background/80 backdrop-blur hover:bg-background"
                  onClick={() => toggleFavorite(pet.id)}
                >
                  <Heart
                    className={`h-5 w-5 transition-colors ${
                      favorite ? 'fill-accent text-accent' : 'text-muted-foreground'
                    }`}
                  />
                </Button>
              </div>

              {/* Photo Thumbnails */}
              {pet.photos.length > 1 && (
                <div className="flex gap-2">
                  {pet.photos.map((photo, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPhotoIndex(index)}
                      className={`relative aspect-square w-20 overflow-hidden rounded-lg border-2 transition-all ${
                        index === currentPhotoIndex
                          ? 'border-primary'
                          : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={photo}
                        alt={`${pet.name} - Thumbnail ${index + 1}`}
                        className="h-full w-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Pet Details */}
            <div className="space-y-6">
              {/* Header */}
              <div>
                <div className="mb-2 flex flex-wrap gap-2">
                  <Badge variant="secondary" className="capitalize">
                    {pet.species}
                  </Badge>
                  <Badge variant="outline" className="capitalize">
                    {pet.size}
                  </Badge>
                  <Badge variant="outline" className="capitalize">
                    {pet.gender}
                  </Badge>
                </div>
                <h1 className="mb-1 text-3xl font-bold md:text-4xl">{pet.name}</h1>
                <p className="text-lg text-muted-foreground">{pet.breed}</p>
              </div>

              {/* Quick Info */}
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-sm text-muted-foreground">Age</p>
                  <p className="font-semibold">{getAgeLabel()}</p>
                </div>
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-sm text-muted-foreground">Size</p>
                  <p className="font-semibold capitalize">{pet.size}</p>
                </div>
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-sm text-muted-foreground">Gender</p>
                  <p className="font-semibold capitalize">{pet.gender}</p>
                </div>
              </div>

              {/* Personality */}
              <div>
                <h3 className="mb-2 font-semibold">Personality</h3>
                <div className="flex flex-wrap gap-2">
                  {pet.personality.map(trait => (
                    <Badge key={trait} variant="secondary">
                      {trait}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Compatibility & Health */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <h3 className="mb-2 font-semibold">Compatibility</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      {pet.goodWithKids ? (
                        <Check className="h-4 w-4 text-success" />
                      ) : (
                        <X className="h-4 w-4 text-destructive" />
                      )}
                      <span>Good with kids</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {pet.goodWithPets ? (
                        <Check className="h-4 w-4 text-success" />
                      ) : (
                        <X className="h-4 w-4 text-destructive" />
                      )}
                      <span>Good with other pets</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="mb-2 font-semibold">Health</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      {pet.vaccinated ? (
                        <Check className="h-4 w-4 text-success" />
                      ) : (
                        <X className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>Vaccinated</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {pet.neutered ? (
                        <Check className="h-4 w-4 text-success" />
                      ) : (
                        <X className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>Spayed/Neutered</span>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Description */}
              <div>
                <h3 className="mb-2 font-semibold">About {pet.name}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {pet.description}
                </p>
              </div>

              <Separator />

              {/* Shelter Info */}
              {shelter && (
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-semibold">Shelter Information</h3>
                  <div className="space-y-2 text-sm">
                    <p className="font-medium">{shelter.name}</p>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      {shelter.location}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      {shelter.phone}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-4 w-4" />
                      {shelter.email}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      Listed {formatDistanceToNow(pet.listedAt, { addSuffix: true })}
                    </div>
                  </div>
                </div>
              )}

              {/* Adoption Inquiry Form */}
              <AdoptionInquiryForm pet={pet} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PetDetailPage;
