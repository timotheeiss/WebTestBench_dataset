import { Link } from 'react-router-dom';
import { useFavorites } from '@/contexts/FavoritesContext';
import { pets } from '@/data/pets';
import PetCard from '@/components/PetCard';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Heart, Search, PawPrint } from 'lucide-react';

const FavoritesPage = () => {
  const { favorites } = useFavorites();
  
  const favoritePets = pets.filter(pet => favorites.includes(pet.id));

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/20">
                <Heart className="h-5 w-5 text-accent" />
              </div>
              <h1 className="text-2xl font-bold md:text-3xl">Your Favorites</h1>
            </div>
            <p className="text-muted-foreground">
              {favoritePets.length === 0
                ? "You haven't saved any favorites yet"
                : `${favoritePets.length} pet${favoritePets.length !== 1 ? 's' : ''} saved to your favorites`}
            </p>
          </div>

          {favoritePets.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-muted">
                <PawPrint className="h-12 w-12 text-muted-foreground" />
              </div>
              <h2 className="mb-2 text-xl font-semibold">No favorites yet</h2>
              <p className="mb-6 max-w-sm text-muted-foreground">
                Start browsing our adorable pets and click the heart icon to save your favorites here!
              </p>
              <Button asChild className="gap-2">
                <Link to="/pets">
                  <Search className="h-4 w-4" />
                  Find Pets
                </Link>
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {favoritePets.map(pet => (
                <PetCard key={pet.id} pet={pet} />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default FavoritesPage;
