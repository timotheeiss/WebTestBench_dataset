import { Link } from 'react-router-dom';
import { ArrowRight, Heart, Search, Shield, PawPrint } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { pets } from '@/data/pets';
import PetCard from '@/components/PetCard';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const Index = () => {
  const featuredPets = pets.slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/5 py-16 md:py-24">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
            <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
          </div>
          
          <div className="container relative mx-auto px-4">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <PawPrint className="h-4 w-4" />
                Find your furry soulmate
              </div>
              
              <h1 className="mb-6 text-4xl font-extrabold tracking-tight text-foreground md:text-5xl lg:text-6xl animate-fade-in">
                Every Pet Deserves a{' '}
                <span className="text-primary">Loving Home</span>
              </h1>
              
              <p className="mb-8 text-lg text-muted-foreground md:text-xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
                Connect with shelters across the country to find your perfect companion. 
                Browse hundreds of adorable pets waiting for their forever families.
              </p>
              
              <div className="flex flex-col justify-center gap-4 sm:flex-row animate-slide-up" style={{ animationDelay: '0.2s' }}>
                <Button size="lg" asChild className="gap-2 text-base">
                  <Link to="/pets">
                    <Search className="h-5 w-5" />
                    Find Your Match
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="gap-2 text-base">
                  <Link to="/favorites">
                    <Heart className="h-5 w-5" />
                    View Favorites
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="border-y border-border/50 bg-muted/30 py-12">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 md:grid-cols-3">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <Search className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="mb-1 font-semibold">Smart Search</h3>
                  <p className="text-sm text-muted-foreground">
                    Filter by species, size, age, and compatibility to find your perfect match.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-accent/10">
                  <Heart className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h3 className="mb-1 font-semibold">Save Favorites</h3>
                  <p className="text-sm text-muted-foreground">
                    Keep track of pets you love and compare them side by side.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-success/10">
                  <Shield className="h-6 w-6 text-success" />
                </div>
                <div>
                  <h3 className="mb-1 font-semibold">Trusted Shelters</h3>
                  <p className="text-sm text-muted-foreground">
                    All pets come from verified, reputable rescue organizations.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Pets Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="mb-10 flex items-end justify-between">
              <div>
                <h2 className="mb-2 text-2xl font-bold md:text-3xl">Meet Our Featured Pets</h2>
                <p className="text-muted-foreground">
                  These adorable friends are looking for their forever homes
                </p>
              </div>
              <Button variant="ghost" asChild className="hidden gap-2 sm:flex">
                <Link to="/pets">
                  View all pets
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {featuredPets.map((pet, index) => (
                <div
                  key={pet.id}
                  className="animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <PetCard pet={pet} />
                </div>
              ))}
            </div>
            
            <div className="mt-8 text-center sm:hidden">
              <Button asChild className="gap-2">
                <Link to="/pets">
                  View all pets
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary py-16 text-primary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-2xl font-bold md:text-3xl">
              Ready to Find Your New Best Friend?
            </h2>
            <p className="mb-8 text-primary-foreground/80">
              Thousands of pets are waiting for loving homes. Start your search today!
            </p>
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="gap-2"
            >
              <Link to="/pets">
                <PawPrint className="h-5 w-5" />
                Browse All Pets
              </Link>
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
