export interface NoteHistory {
  content: string;
  timestamp: Date;
  author: string;
}

export interface Tag {
  id: string;
  name: string;
  groupId: string;
  usageCount: number;
  notes: string;
  noteHistory: NoteHistory[];
  createdAt: Date;
  color?: string;
}

export interface TagGroup {
  id: string;
  name: string;
  description: string;
  notes: string;
  noteHistory: NoteHistory[];
  color: string;
  isExpanded: boolean;
}

export interface ContentItem {
  id: string;
  title: string;
  type: 'article' | 'product' | 'page' | 'post';
  tagIds: string[];
  createdAt: Date;
}

export interface GroupTemplate {
  id: string;
  name: string;
  description: string;
  groups: Omit<TagGroup, 'id' | 'noteHistory'>[];
  tags: Omit<Tag, 'id' | 'usageCount' | 'noteHistory' | 'createdAt'>[];
}

export const initialTagGroups: TagGroup[] = [
  {
    id: 'group-1',
    name: 'Content Type',
    description: 'Tags for categorizing content by its format',
    notes: 'Use these tags to help users filter content by format. Essential for navigation.',
    noteHistory: [
      { content: 'Initial setup for content types', timestamp: new Date('2024-01-10'), author: 'Admin' }
    ],
    color: '#0d9488',
    isExpanded: true,
  },
  {
    id: 'group-2',
    name: 'Topics',
    description: 'Subject matter and topic classifications',
    notes: 'Primary topic tags. Limit to 2-3 per content item for better discoverability.',
    noteHistory: [
      { content: 'Created topic taxonomy', timestamp: new Date('2024-01-12'), author: 'Editor' }
    ],
    color: '#6366f1',
    isExpanded: true,
  },
  {
    id: 'group-3',
    name: 'Status',
    description: 'Content lifecycle and status tags',
    notes: 'Track content through its lifecycle. Only one status tag per item.',
    noteHistory: [],
    color: '#f59e0b',
    isExpanded: false,
  },
  {
    id: 'group-4',
    name: 'Priority',
    description: 'Content priority and importance levels',
    notes: 'For editorial planning. Review weekly with the team.',
    noteHistory: [],
    color: '#ef4444',
    isExpanded: false,
  },
];

export const initialTags: Tag[] = [
  // Content Type tags
  { id: 'tag-1', name: 'Article', groupId: 'group-1', usageCount: 45, notes: 'Long-form written content', noteHistory: [], createdAt: new Date('2024-01-10') },
  { id: 'tag-2', name: 'Tutorial', groupId: 'group-1', usageCount: 32, notes: 'Step-by-step guides', noteHistory: [], createdAt: new Date('2024-01-10') },
  { id: 'tag-3', name: 'Video', groupId: 'group-1', usageCount: 18, notes: 'Video content', noteHistory: [], createdAt: new Date('2024-01-11') },
  { id: 'tag-4', name: 'Infographic', groupId: 'group-1', usageCount: 8, notes: 'Visual data presentations', noteHistory: [], createdAt: new Date('2024-01-15') },
  
  // Topic tags
  { id: 'tag-5', name: 'Technology', groupId: 'group-2', usageCount: 67, notes: 'Tech industry and products', noteHistory: [], createdAt: new Date('2024-01-12') },
  { id: 'tag-6', name: 'Design', groupId: 'group-2', usageCount: 41, notes: 'UI/UX and visual design', noteHistory: [], createdAt: new Date('2024-01-12') },
  { id: 'tag-7', name: 'Marketing', groupId: 'group-2', usageCount: 29, notes: 'Marketing strategies and tips', noteHistory: [], createdAt: new Date('2024-01-13') },
  { id: 'tag-8', name: 'Business', groupId: 'group-2', usageCount: 35, notes: 'Business insights and news', noteHistory: [], createdAt: new Date('2024-01-13') },
  { id: 'tag-9', name: 'Development', groupId: 'group-2', usageCount: 52, notes: 'Software development topics', noteHistory: [], createdAt: new Date('2024-01-14') },
  
  // Status tags
  { id: 'tag-10', name: 'Draft', groupId: 'group-3', usageCount: 12, notes: 'Work in progress', noteHistory: [], createdAt: new Date('2024-01-15') },
  { id: 'tag-11', name: 'Review', groupId: 'group-3', usageCount: 8, notes: 'Pending editorial review', noteHistory: [], createdAt: new Date('2024-01-15') },
  { id: 'tag-12', name: 'Published', groupId: 'group-3', usageCount: 89, notes: 'Live content', noteHistory: [], createdAt: new Date('2024-01-15') },
  { id: 'tag-13', name: 'Archived', groupId: 'group-3', usageCount: 23, notes: 'Outdated or retired content', noteHistory: [], createdAt: new Date('2024-01-15') },
  
  // Priority tags
  { id: 'tag-14', name: 'High Priority', groupId: 'group-4', usageCount: 15, notes: 'Urgent content needs', noteHistory: [], createdAt: new Date('2024-01-16') },
  { id: 'tag-15', name: 'Featured', groupId: 'group-4', usageCount: 7, notes: 'Homepage featured content', noteHistory: [], createdAt: new Date('2024-01-16') },
  { id: 'tag-16', name: 'Evergreen', groupId: 'group-4', usageCount: 34, notes: 'Timeless content', noteHistory: [], createdAt: new Date('2024-01-17') },
];

export const initialContentItems: ContentItem[] = [
  { id: 'content-1', title: 'Getting Started with React Hooks', type: 'article', tagIds: ['tag-1', 'tag-5', 'tag-9', 'tag-12'], createdAt: new Date('2024-02-01') },
  { id: 'content-2', title: 'UI Design Principles for Beginners', type: 'article', tagIds: ['tag-1', 'tag-6', 'tag-12', 'tag-16'], createdAt: new Date('2024-02-03') },
  { id: 'content-3', title: 'Building a REST API with Node.js', type: 'article', tagIds: ['tag-2', 'tag-5', 'tag-9', 'tag-12'], createdAt: new Date('2024-02-05') },
  { id: 'content-4', title: 'Marketing Automation Strategies', type: 'article', tagIds: ['tag-1', 'tag-7', 'tag-8', 'tag-12'], createdAt: new Date('2024-02-07') },
  { id: 'content-5', title: 'TypeScript Best Practices', type: 'article', tagIds: ['tag-2', 'tag-9', 'tag-12', 'tag-14'], createdAt: new Date('2024-02-10') },
  { id: 'content-6', title: 'Introduction to Figma', type: 'article', tagIds: ['tag-3', 'tag-6', 'tag-12'], createdAt: new Date('2024-02-12') },
  { id: 'content-7', title: 'SEO Fundamentals Infographic', type: 'page', tagIds: ['tag-4', 'tag-7', 'tag-12', 'tag-15'], createdAt: new Date('2024-02-15') },
  { id: 'content-8', title: 'Q1 Business Review', type: 'post', tagIds: ['tag-1', 'tag-8', 'tag-10'], createdAt: new Date('2024-02-18') },
  { id: 'content-9', title: 'Advanced CSS Techniques', type: 'article', tagIds: ['tag-2', 'tag-6', 'tag-9', 'tag-11'], createdAt: new Date('2024-02-20') },
  { id: 'content-10', title: 'Product Launch Checklist', type: 'page', tagIds: ['tag-1', 'tag-7', 'tag-8', 'tag-16'], createdAt: new Date('2024-02-22') },
];

export const groupTemplates: GroupTemplate[] = [
  {
    id: 'template-1',
    name: 'Blog Content',
    description: 'Standard blog content organization with categories, topics, and status tracking',
    groups: [
      { name: 'Categories', description: 'Main content categories', notes: '', color: '#0d9488', isExpanded: true },
      { name: 'Topics', description: 'Subject matter tags', notes: '', color: '#6366f1', isExpanded: true },
      { name: 'Status', description: 'Publication status', notes: '', color: '#f59e0b', isExpanded: false },
    ],
    tags: [
      { name: 'News', groupId: 'Categories', notes: '' },
      { name: 'Opinion', groupId: 'Categories', notes: '' },
      { name: 'Guide', groupId: 'Categories', notes: '' },
      { name: 'Draft', groupId: 'Status', notes: '' },
      { name: 'Published', groupId: 'Status', notes: '' },
    ],
  },
  {
    id: 'template-2',
    name: 'E-commerce Products',
    description: 'Product categorization for online stores',
    groups: [
      { name: 'Product Type', description: 'Type of product', notes: '', color: '#8b5cf6', isExpanded: true },
      { name: 'Brand', description: 'Product brands', notes: '', color: '#ec4899', isExpanded: true },
      { name: 'Availability', description: 'Stock status', notes: '', color: '#22c55e', isExpanded: false },
    ],
    tags: [
      { name: 'Electronics', groupId: 'Product Type', notes: '' },
      { name: 'Clothing', groupId: 'Product Type', notes: '' },
      { name: 'In Stock', groupId: 'Availability', notes: '' },
      { name: 'Out of Stock', groupId: 'Availability', notes: '' },
      { name: 'Pre-order', groupId: 'Availability', notes: '' },
    ],
  },
  {
    id: 'template-3',
    name: 'Project Management',
    description: 'Task and project organization system',
    groups: [
      { name: 'Priority', description: 'Task priority levels', notes: '', color: '#ef4444', isExpanded: true },
      { name: 'Department', description: 'Team or department', notes: '', color: '#3b82f6', isExpanded: true },
      { name: 'Stage', description: 'Project lifecycle stage', notes: '', color: '#10b981', isExpanded: true },
    ],
    tags: [
      { name: 'Urgent', groupId: 'Priority', notes: '' },
      { name: 'High', groupId: 'Priority', notes: '' },
      { name: 'Medium', groupId: 'Priority', notes: '' },
      { name: 'Low', groupId: 'Priority', notes: '' },
      { name: 'Planning', groupId: 'Stage', notes: '' },
      { name: 'In Progress', groupId: 'Stage', notes: '' },
      { name: 'Complete', groupId: 'Stage', notes: '' },
    ],
  },
  {
    id: 'template-4',
    name: 'Knowledge Base',
    description: 'Documentation and help center organization',
    groups: [
      { name: 'Product Area', description: 'Product sections', notes: '', color: '#0ea5e9', isExpanded: true },
      { name: 'Audience', description: 'Target reader', notes: '', color: '#f97316', isExpanded: true },
      { name: 'Doc Type', description: 'Type of documentation', notes: '', color: '#84cc16', isExpanded: false },
    ],
    tags: [
      { name: 'Getting Started', groupId: 'Product Area', notes: '' },
      { name: 'API Reference', groupId: 'Product Area', notes: '' },
      { name: 'Troubleshooting', groupId: 'Product Area', notes: '' },
      { name: 'Beginners', groupId: 'Audience', notes: '' },
      { name: 'Advanced', groupId: 'Audience', notes: '' },
      { name: 'How-to', groupId: 'Doc Type', notes: '' },
      { name: 'Concept', groupId: 'Doc Type', notes: '' },
    ],
  },
];
