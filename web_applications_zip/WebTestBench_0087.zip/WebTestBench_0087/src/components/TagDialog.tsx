import React, { useState, useEffect } from 'react';
import { Tag } from '@/data/mockData';
import { useTagContext } from '@/contexts/TagContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TagChip } from './TagChip';
import { AlertCircle } from 'lucide-react';

interface TagDialogProps {
  open: boolean;
  onClose: () => void;
  tag?: Tag | null;
  defaultGroupId?: string;
}

export function TagDialog({ open, onClose, tag, defaultGroupId }: TagDialogProps) {
  const { tagGroups, createTag, updateTag, updateNotes, getSimilarTags } = useTagContext();
  
  const [name, setName] = useState('');
  const [groupId, setGroupId] = useState('');
  const [notes, setNotes] = useState('');
  const [similarTags, setSimilarTags] = useState<Tag[]>([]);

  useEffect(() => {
    if (tag) {
      setName(tag.name);
      setGroupId(tag.groupId);
      setNotes(tag.notes);
    } else {
      setName('');
      setGroupId(defaultGroupId || tagGroups[0]?.id || '');
      setNotes('');
    }
    setSimilarTags([]);
  }, [tag, defaultGroupId, open, tagGroups]);

  useEffect(() => {
    if (name && !tag) {
      const similar = getSimilarTags(name).filter(t => t.id !== tag?.id);
      setSimilarTags(similar);
    } else {
      setSimilarTags([]);
    }
  }, [name, getSimilarTags, tag]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (tag) {
      updateTag(tag.id, { name, groupId });
      if (notes !== tag.notes) {
        updateNotes('tag', tag.id, notes);
      }
    } else {
      createTag({ name, groupId, notes });
    }
    
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-card border border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {tag ? 'Edit Tag' : 'Create New Tag'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Tag Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter tag name"
              className="bg-background"
              autoFocus
            />
            
            {similarTags.length > 0 && (
              <div className="p-3 bg-warning/10 border border-warning/30 rounded-md animate-fade-in">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-warning mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-warning-foreground">Similar tags exist</p>
                    <p className="text-xs text-muted-foreground mb-2">
                      Consider using an existing tag to avoid duplicates
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {similarTags.map(t => (
                        <TagChip key={t.id} tag={t} showUsage={false} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="group">Group</Label>
            <Select value={groupId} onValueChange={setGroupId}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select a group" />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border z-50">
                {tagGroups.map(group => (
                  <SelectItem key={group.id} value={group.id}>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-2 h-2 rounded-full" 
                        style={{ backgroundColor: group.color }}
                      />
                      {group.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes or collaboration description..."
              className="bg-background min-h-[80px]"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!name || !groupId}>
              {tag ? 'Save Changes' : 'Create Tag'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
