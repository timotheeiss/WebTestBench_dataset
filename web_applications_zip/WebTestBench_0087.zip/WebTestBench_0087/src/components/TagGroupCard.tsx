import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Plus, MoreHorizontal, Edit2, Trash2 } from 'lucide-react';
import { TagGroup } from '@/data/mockData';
import { useTagContext } from '@/contexts/TagContext';
import { TagChip } from './TagChip';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface TagGroupCardProps {
  group: TagGroup;
  onAddTag: (groupId: string) => void;
  onEditGroup: (group: TagGroup) => void;
  onEditTag: (tag: any) => void;
  onDeleteTag: (id: string) => void;
  selectedTags: string[];
  onSelectTag: (id: string) => void;
  selectionMode: boolean;
}

export function TagGroupCard({
  group,
  onAddTag,
  onEditGroup,
  onEditTag,
  onDeleteTag,
  selectedTags,
  onSelectTag,
  selectionMode,
}: TagGroupCardProps) {
  const { getTagsByGroup, toggleGroupExpanded, deleteTagGroup } = useTagContext();
  const tags = getTagsByGroup(group.id);

  return (
    <div 
      className="bg-card rounded-lg border border-border overflow-hidden animate-fade-in"
      style={{ borderLeftColor: group.color, borderLeftWidth: '3px' }}
    >
      <Collapsible open={group.isExpanded} onOpenChange={() => toggleGroupExpanded(group.id)}>
        <div className="flex items-center justify-between p-4 bg-card hover:bg-muted/30 transition-colors">
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-3 flex-1 text-left">
              {group.isExpanded ? (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              )}
              
              <HoverCard openDelay={400}>
                <HoverCardTrigger asChild>
                  <div>
                    <h3 className="font-semibold text-foreground">{group.name}</h3>
                    <p className="text-sm text-muted-foreground">{group.description}</p>
                  </div>
                </HoverCardTrigger>
                <HoverCardContent className="w-80 bg-popover border border-border shadow-lg z-50">
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-foreground">{group.name}</h4>
                      <p className="text-sm text-muted-foreground">{group.description}</p>
                    </div>
                    {group.notes && (
                      <div className="p-2 bg-muted rounded-md">
                        <p className="text-sm text-muted-foreground">{group.notes}</p>
                      </div>
                    )}
                    <div className="text-sm text-muted-foreground">
                      {tags.length} tags • {tags.reduce((sum, t) => sum + t.usageCount, 0)} total uses
                    </div>
                    {group.noteHistory.length > 0 && (
                      <div className="border-t border-border pt-2">
                        <p className="text-xs font-medium text-muted-foreground mb-1">Note History</p>
                        <div className="space-y-1 max-h-24 overflow-y-auto scrollbar-thin">
                          {group.noteHistory.slice(-3).reverse().map((entry, i) => (
                            <div key={i} className="text-xs text-muted-foreground">
                              <span className="font-medium">{entry.author}</span>
                              <span> • {new Date(entry.timestamp).toLocaleDateString()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </HoverCardContent>
              </HoverCard>
            </button>
          </CollapsibleTrigger>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground px-2 py-1 bg-muted rounded">
              {tags.length} tags
            </span>
            
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onAddTag(group.id)}
              className="h-8 w-8 p-0"
            >
              <Plus className="w-4 h-4" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover border border-border shadow-lg z-50">
                <DropdownMenuItem onClick={() => onEditGroup(group)}>
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit group
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => deleteTagGroup(group.id)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete group
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <CollapsibleContent>
          <div className="px-4 pb-4 pt-2 flex flex-wrap gap-2">
            {tags.length === 0 ? (
              <p className="text-sm text-muted-foreground italic">No tags in this group yet</p>
            ) : (
              tags.map(tag => (
                <TagChip
                  key={tag.id}
                  tag={tag}
                  selectable={selectionMode}
                  selected={selectedTags.includes(tag.id)}
                  onSelect={onSelectTag}
                  onEdit={onEditTag}
                  onDelete={onDeleteTag}
                />
              ))
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
