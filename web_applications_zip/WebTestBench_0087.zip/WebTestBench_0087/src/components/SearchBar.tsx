import React, { useState, useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { useTagContext } from '@/contexts/TagContext';
import { Input } from '@/components/ui/input';
import { TagChip } from './TagChip';

interface SearchBarProps {
  onSelect?: (tagId: string) => void;
}

export function SearchBar({ onSelect }: SearchBarProps) {
  const { getSimilarTags, tags } = useTagContext();
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const suggestions = query.length >= 1 
    ? getSimilarTags(query)
    : [];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current && 
        !dropdownRef.current.contains(e.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (tagId: string) => {
    if (onSelect) {
      onSelect(tagId);
    }
    setQuery('');
    setIsOpen(false);
  };

  return (
    <div className="relative flex-1 max-w-md">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search tags..."
          className="pl-10 pr-10 bg-card"
        />
        {query && (
          <button
            onClick={() => {
              setQuery('');
              inputRef.current?.focus();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        )}
      </div>

      {isOpen && suggestions.length > 0 && (
        <div 
          ref={dropdownRef}
          className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-lg z-50 overflow-hidden animate-fade-in"
        >
          <div className="p-2 space-y-1">
            <p className="text-xs font-medium text-muted-foreground px-2 py-1">
              Matching tags
            </p>
            {suggestions.map(tag => (
              <button
                key={tag.id}
                onClick={() => handleSelect(tag.id)}
                className="w-full text-left"
              >
                <TagChip tag={tag} className="w-full justify-start" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
