import React, { useState, useEffect } from 'react';
import { TagGroup } from '@/data/mockData';
import { useTagContext } from '@/contexts/TagContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

const colorOptions = [
  '#0d9488', '#6366f1', '#f59e0b', '#ef4444', '#8b5cf6',
  '#ec4899', '#22c55e', '#3b82f6', '#f97316', '#84cc16',
];

interface GroupDialogProps {
  open: boolean;
  onClose: () => void;
  group?: TagGroup | null;
}

export function GroupDialog({ open, onClose, group }: GroupDialogProps) {
  const { createTagGroup, updateTagGroup, updateNotes } = useTagContext();
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');
  const [color, setColor] = useState(colorOptions[0]);

  useEffect(() => {
    if (group) {
      setName(group.name);
      setDescription(group.description);
      setNotes(group.notes);
      setColor(group.color);
    } else {
      setName('');
      setDescription('');
      setNotes('');
      setColor(colorOptions[Math.floor(Math.random() * colorOptions.length)]);
    }
  }, [group, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (group) {
      updateTagGroup(group.id, { name, description, color });
      if (notes !== group.notes) {
        updateNotes('group', group.id, notes);
      }
    } else {
      createTagGroup({ name, description, notes, color, isExpanded: true });
    }
    
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-card border border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {group ? 'Edit Group' : 'Create New Group'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Group Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter group name"
              className="bg-background"
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of this group"
              className="bg-background"
            />
          </div>

          <div className="space-y-2">
            <Label>Color</Label>
            <div className="flex gap-2 flex-wrap">
              {colorOptions.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-full transition-all ${
                    color === c ? 'ring-2 ring-offset-2 ring-offset-card ring-accent scale-110' : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes or collaboration guidelines..."
              className="bg-background min-h-[80px]"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!name}>
              {group ? 'Save Changes' : 'Create Group'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
