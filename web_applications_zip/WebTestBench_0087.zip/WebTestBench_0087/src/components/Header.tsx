import React from 'react';
import { Tags, Plus, FolderPlus, MousePointerClick } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SearchBar } from './SearchBar';
import { TemplatesPanel } from './TemplatesPanel';

interface HeaderProps {
  onCreateTag: () => void;
  onCreateGroup: () => void;
  selectionMode: boolean;
  onToggleSelectionMode: () => void;
}

export function Header({ onCreateTag, onCreateGroup, selectionMode, onToggleSelectionMode }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <Tags className="w-6 h-6 text-accent" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Tag Manager</h1>
              <p className="text-sm text-muted-foreground">Organize and manage content tags</p>
            </div>
          </div>

          <SearchBar />

          <div className="flex items-center gap-2">
            <Button
              variant={selectionMode ? "default" : "outline"}
              onClick={onToggleSelectionMode}
              className="gap-2"
            >
              <MousePointerClick className="w-4 h-4" />
              {selectionMode ? 'Exit Selection' : 'Select Tags'}
            </Button>

            <TemplatesPanel />

            <Button variant="outline" onClick={onCreateGroup} className="gap-2">
              <FolderPlus className="w-4 h-4" />
              New Group
            </Button>

            <Button onClick={onCreateTag} className="gap-2 btn-gradient-accent">
              <Plus className="w-4 h-4" />
              New Tag
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
