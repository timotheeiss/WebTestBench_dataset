import React from 'react';
import { Tags, FolderOpen, FileText, TrendingUp } from 'lucide-react';
import { useTagContext } from '@/contexts/TagContext';

export function StatsOverview() {
  const { tags, tagGroups, contentItems } = useTagContext();

  const totalUsage = tags.reduce((sum, t) => sum + t.usageCount, 0);
  const avgUsage = tags.length > 0 ? Math.round(totalUsage / tags.length) : 0;

  const stats = [
    {
      label: 'Total Tags',
      value: tags.length,
      icon: Tags,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
    {
      label: 'Tag Groups',
      value: tagGroups.length,
      icon: FolderOpen,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      label: 'Content Items',
      value: contentItems.length,
      icon: FileText,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
    {
      label: 'Avg Usage',
      value: avgUsage,
      icon: TrendingUp,
      color: 'text-warning',
      bgColor: 'bg-warning/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <div 
          key={stat.label}
          className="bg-card border border-border rounded-lg p-4 animate-fade-in"
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
