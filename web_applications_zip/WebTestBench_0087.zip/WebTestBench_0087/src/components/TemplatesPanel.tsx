import React, { useState } from 'react';
import { Layout, Plus, Save, Check } from 'lucide-react';
import { useTagContext } from '@/contexts/TagContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

export function TemplatesPanel() {
  const { templates, customTemplates, tagGroups, applyTemplate, saveAsTemplate } = useTagContext();
  
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);
  const [appliedTemplate, setAppliedTemplate] = useState<string | null>(null);

  const handleApplyTemplate = (templateId: string) => {
    applyTemplate(templateId);
    setAppliedTemplate(templateId);
    setTimeout(() => setAppliedTemplate(null), 2000);
  };

  const handleSaveTemplate = () => {
    if (templateName && selectedGroupIds.length > 0) {
      saveAsTemplate(templateName, templateDescription, selectedGroupIds);
      setShowSaveDialog(false);
      setTemplateName('');
      setTemplateDescription('');
      setSelectedGroupIds([]);
    }
  };

  const toggleGroupSelection = (groupId: string) => {
    setSelectedGroupIds(prev => 
      prev.includes(groupId) 
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const allTemplates = [...templates, ...customTemplates];

  return (
    <>
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Layout className="w-4 h-4" />
            Templates
          </Button>
        </SheetTrigger>
        <SheetContent className="w-96 bg-card border-l border-border">
          <SheetHeader>
            <SheetTitle className="text-foreground">Tag Group Templates</SheetTitle>
          </SheetHeader>
          
          <div className="mt-6 space-y-4">
            <Button 
              variant="outline" 
              className="w-full gap-2"
              onClick={() => setShowSaveDialog(true)}
              disabled={tagGroups.length === 0}
            >
              <Save className="w-4 h-4" />
              Save Current as Template
            </Button>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Built-in Templates</h4>
              {templates.map(template => (
                <div 
                  key={template.id}
                  className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h5 className="font-medium text-foreground">{template.name}</h5>
                      <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {template.groups.map((g, i) => (
                          <span 
                            key={i}
                            className="text-xs px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: `${g.color}20`, color: g.color }}
                          >
                            {g.name}
                          </span>
                        ))}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleApplyTemplate(template.id)}
                      disabled={appliedTemplate === template.id}
                      className="flex-shrink-0"
                    >
                      {appliedTemplate === template.id ? (
                        <>
                          <Check className="w-3 h-3 mr-1" />
                          Added
                        </>
                      ) : (
                        <>
                          <Plus className="w-3 h-3 mr-1" />
                          Apply
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {customTemplates.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Custom Templates</h4>
                {customTemplates.map(template => (
                  <div 
                    key={template.id}
                    className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <h5 className="font-medium text-foreground">{template.name}</h5>
                        <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {template.groups.map((g, i) => (
                            <span 
                              key={i}
                              className="text-xs px-2 py-0.5 rounded-full"
                              style={{ backgroundColor: `${g.color}20`, color: g.color }}
                            >
                              {g.name}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleApplyTemplate(template.id)}
                        disabled={appliedTemplate === template.id}
                        className="flex-shrink-0"
                      >
                        {appliedTemplate === template.id ? (
                          <>
                            <Check className="w-3 h-3 mr-1" />
                            Added
                          </>
                        ) : (
                          <>
                            <Plus className="w-3 h-3 mr-1" />
                            Apply
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="sm:max-w-md bg-card border border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Save as Template</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Save your current tag groups as a reusable template
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="templateName">Template Name</Label>
              <Input
                id="templateName"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                placeholder="My Custom Template"
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="templateDesc">Description</Label>
              <Input
                id="templateDesc"
                value={templateDescription}
                onChange={(e) => setTemplateDescription(e.target.value)}
                placeholder="Brief description..."
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <Label>Select Groups to Include</Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {tagGroups.map(group => (
                  <div 
                    key={group.id}
                    className="flex items-center gap-3 p-2 rounded hover:bg-muted/50"
                  >
                    <Checkbox
                      id={group.id}
                      checked={selectedGroupIds.includes(group.id)}
                      onCheckedChange={() => toggleGroupSelection(group.id)}
                    />
                    <label 
                      htmlFor={group.id}
                      className="flex items-center gap-2 cursor-pointer flex-1"
                    >
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: group.color }}
                      />
                      <span className="text-foreground">{group.name}</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSaveTemplate}
              disabled={!templateName || selectedGroupIds.length === 0}
            >
              Save Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
