import React, { useState, useMemo } from 'react';
import { X, Merge, Type, AlertTriangle, Check } from 'lucide-react';
import { useTagContext } from '@/contexts/TagContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

interface BatchOperationsPanelProps {
  selectedTagIds: string[];
  onClearSelection: () => void;
}

export function BatchOperationsPanel({ selectedTagIds, onClearSelection }: BatchOperationsPanelProps) {
  const { tags, mergeTags, batchRenameTags, getMergeImpact } = useTagContext();
  
  const [showMergeDialog, setShowMergeDialog] = useState(false);
  const [showRenameDialog, setShowRenameDialog] = useState(false);
  const [mergeTargetId, setMergeTargetId] = useState('');
  const [renamePattern, setRenamePattern] = useState('');
  const [renameReplacement, setRenameReplacement] = useState('');
  const [operationComplete, setOperationComplete] = useState(false);

  const selectedTags = useMemo(() => 
    tags.filter(t => selectedTagIds.includes(t.id)),
    [tags, selectedTagIds]
  );

  const mergeImpact = useMemo(() => {
    if (!mergeTargetId || selectedTagIds.length < 2) return null;
    const sourceIds = selectedTagIds.filter(id => id !== mergeTargetId);
    return getMergeImpact(sourceIds, mergeTargetId);
  }, [mergeTargetId, selectedTagIds, getMergeImpact]);

  const renamePreview = useMemo(() => {
    if (!renamePattern) return [];
    try {
      const regex = new RegExp(renamePattern, 'gi');
      return selectedTags.map(tag => ({
        id: tag.id,
        original: tag.name,
        preview: tag.name.replace(regex, renameReplacement),
        changed: tag.name !== tag.name.replace(regex, renameReplacement),
      }));
    } catch {
      return [];
    }
  }, [selectedTags, renamePattern, renameReplacement]);

  const handleMerge = () => {
    if (mergeTargetId && selectedTagIds.length >= 2) {
      const sourceIds = selectedTagIds.filter(id => id !== mergeTargetId);
      mergeTags(sourceIds, mergeTargetId);
      setOperationComplete(true);
      setTimeout(() => {
        setShowMergeDialog(false);
        setMergeTargetId('');
        setOperationComplete(false);
        onClearSelection();
      }, 1000);
    }
  };

  const handleRename = () => {
    if (renamePattern && selectedTagIds.length > 0) {
      batchRenameTags(selectedTagIds, renamePattern, renameReplacement);
      setOperationComplete(true);
      setTimeout(() => {
        setShowRenameDialog(false);
        setRenamePattern('');
        setRenameReplacement('');
        setOperationComplete(false);
        onClearSelection();
      }, 1000);
    }
  };

  if (selectedTagIds.length === 0) return null;

  return (
    <>
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-slide-in">
        <div className="bg-primary text-primary-foreground rounded-lg shadow-lg p-4 flex items-center gap-4">
          <span className="font-medium">
            {selectedTagIds.length} tag{selectedTagIds.length > 1 ? 's' : ''} selected
          </span>
          
          <div className="h-6 w-px bg-primary-foreground/30" />
          
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowMergeDialog(true)}
              disabled={selectedTagIds.length < 2}
              className="gap-2"
            >
              <Merge className="w-4 h-4" />
              Merge
            </Button>
            
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowRenameDialog(true)}
              className="gap-2"
            >
              <Type className="w-4 h-4" />
              Batch Rename
            </Button>
          </div>
          
          <button
            onClick={onClearSelection}
            className="ml-2 p-1 hover:bg-primary-foreground/10 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Merge Dialog */}
      <Dialog open={showMergeDialog} onOpenChange={setShowMergeDialog}>
        <DialogContent className="sm:max-w-lg bg-card border border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Merge Tags</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Select the target tag. All other selected tags will be merged into it.
            </p>

            <div className="space-y-2">
              <Label>Target Tag</Label>
              <Select value={mergeTargetId} onValueChange={setMergeTargetId}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Select target tag" />
                </SelectTrigger>
                <SelectContent className="bg-popover border border-border z-50">
                  {selectedTags.map(tag => (
                    <SelectItem key={tag.id} value={tag.id}>
                      {tag.name} ({tag.usageCount} uses)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {mergeImpact && (
              <div className="p-4 bg-muted rounded-lg space-y-3">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-warning flex-shrink-0" />
                  <div>
                    <p className="font-medium text-foreground">Impact Preview</p>
                    <p className="text-sm text-muted-foreground">
                      {mergeImpact.tagsMerged.length} tags will be merged
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">
                    Tags to be removed:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {mergeImpact.tagsMerged.map(t => (
                      <span 
                        key={t.id}
                        className="px-2 py-1 bg-destructive/10 text-destructive text-sm rounded"
                      >
                        {t.name}
                      </span>
                    ))}
                  </div>
                </div>

                {mergeImpact.affectedContent.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">
                      Affected content ({mergeImpact.affectedContent.length} items):
                    </p>
                    <div className="max-h-32 overflow-y-auto scrollbar-thin space-y-1">
                      {mergeImpact.affectedContent.slice(0, 5).map(item => (
                        <div key={item.id} className="text-sm text-foreground p-1.5 bg-background rounded">
                          {item.title}
                        </div>
                      ))}
                      {mergeImpact.affectedContent.length > 5 && (
                        <p className="text-xs text-muted-foreground">
                          +{mergeImpact.affectedContent.length - 5} more items
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMergeDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleMerge} 
              disabled={!mergeTargetId || operationComplete}
              className={cn(operationComplete && "bg-success")}
            >
              {operationComplete ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Merged!
                </>
              ) : (
                'Merge Tags'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename Dialog */}
      <Dialog open={showRenameDialog} onOpenChange={setShowRenameDialog}>
        <DialogContent className="sm:max-w-lg bg-card border border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Batch Rename Tags</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Use find and replace to rename multiple tags at once. Supports regex patterns.
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pattern">Find (pattern)</Label>
                <Input
                  id="pattern"
                  value={renamePattern}
                  onChange={(e) => setRenamePattern(e.target.value)}
                  placeholder="e.g., Old"
                  className="bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="replacement">Replace with</Label>
                <Input
                  id="replacement"
                  value={renameReplacement}
                  onChange={(e) => setRenameReplacement(e.target.value)}
                  placeholder="e.g., New"
                  className="bg-background"
                />
              </div>
            </div>

            {renamePreview.length > 0 && renamePreview.some(p => p.changed) && (
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm font-medium text-muted-foreground mb-3">Preview</p>
                <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
                  {renamePreview.filter(p => p.changed).map(p => (
                    <div key={p.id} className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground line-through">{p.original}</span>
                      <span className="text-muted-foreground">→</span>
                      <span className="text-foreground font-medium">{p.preview}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRenameDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleRename} 
              disabled={!renamePattern || !renamePreview.some(p => p.changed) || operationComplete}
              className={cn(operationComplete && "bg-success")}
            >
              {operationComplete ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Renamed!
                </>
              ) : (
                'Apply Rename'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
