import React, { useState } from 'react';
import { Copy, Check, X, MoreHorizontal } from 'lucide-react';
import { Tag, ContentItem } from '@/data/mockData';
import { useTagContext } from '@/contexts/TagContext';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface TagChipProps {
  tag: Tag;
  showUsage?: boolean;
  selectable?: boolean;
  selected?: boolean;
  onSelect?: (id: string) => void;
  onEdit?: (tag: Tag) => void;
  onDelete?: (id: string) => void;
  className?: string;
}

export function TagChip({
  tag,
  showUsage = true,
  selectable = false,
  selected = false,
  onSelect,
  onEdit,
  onDelete,
  className,
}: TagChipProps) {
  const { getContentByTag, tagGroups } = useTagContext();
  const [copied, setCopied] = useState(false);
  
  const group = tagGroups.find(g => g.id === tag.groupId);
  const relatedContent = getContentByTag(tag.id);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(tag.name);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleClick = () => {
    if (selectable && onSelect) {
      onSelect(tag.id);
    }
  };

  return (
    <HoverCard openDelay={300} closeDelay={100}>
      <HoverCardTrigger asChild>
        <div
          onClick={handleClick}
          className={cn(
            "inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-sm font-medium transition-all duration-200 group cursor-default",
            "bg-secondary/60 hover:bg-secondary text-secondary-foreground",
            selectable && "cursor-pointer",
            selected && "ring-2 ring-accent ring-offset-1 ring-offset-background bg-accent/10",
            className
          )}
          style={group?.color ? { 
            backgroundColor: `${group.color}15`,
            borderLeft: `3px solid ${group.color}`,
          } : undefined}
        >
          <span>{tag.name}</span>
          {showUsage && (
            <span className="text-xs text-muted-foreground ml-1">
              ({tag.usageCount})
            </span>
          )}
          
          <button
            onClick={handleCopy}
            className="opacity-0 group-hover:opacity-100 transition-opacity ml-1 p-0.5 hover:bg-secondary rounded"
            title="Copy tag name"
          >
            {copied ? (
              <Check className="w-3 h-3 text-success" />
            ) : (
              <Copy className="w-3 h-3 text-muted-foreground" />
            )}
          </button>

          {(onEdit || onDelete) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <button className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 hover:bg-secondary rounded">
                  <MoreHorizontal className="w-3 h-3 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover border border-border shadow-lg z-50">
                {onEdit && (
                  <DropdownMenuItem onClick={() => onEdit(tag)}>
                    Edit tag
                  </DropdownMenuItem>
                )}
                {onDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(tag.id)}
                    className="text-destructive focus:text-destructive"
                  >
                    Delete tag
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </HoverCardTrigger>

      <HoverCardContent 
        className="w-80 bg-popover border border-border shadow-lg z-50" 
        align="start"
      >
        <div className="space-y-3">
          <div>
            <h4 className="font-semibold text-foreground">{tag.name}</h4>
            {group && (
              <p className="text-sm text-muted-foreground">
                in {group.name}
              </p>
            )}
          </div>

          <div className="flex items-center gap-4 text-sm">
            <span className="text-muted-foreground">
              Used in <strong className="text-foreground">{tag.usageCount}</strong> items
            </span>
          </div>

          {tag.notes && (
            <div className="p-2 bg-muted rounded-md">
              <p className="text-sm text-muted-foreground">{tag.notes}</p>
            </div>
          )}

          {relatedContent.length > 0 && (
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-2">
                Related Content
              </p>
              <div className="space-y-1 max-h-32 overflow-y-auto scrollbar-thin">
                {relatedContent.slice(0, 5).map(item => (
                  <div 
                    key={item.id}
                    className="text-sm p-1.5 rounded bg-muted/50 flex items-center gap-2"
                  >
                    <span className="text-xs px-1.5 py-0.5 rounded bg-secondary text-muted-foreground capitalize">
                      {item.type}
                    </span>
                    <span className="truncate text-foreground">{item.title}</span>
                  </div>
                ))}
                {relatedContent.length > 5 && (
                  <p className="text-xs text-muted-foreground">
                    +{relatedContent.length - 5} more items
                  </p>
                )}
              </div>
            </div>
          )}

          {tag.noteHistory.length > 0 && (
            <div className="text-xs text-muted-foreground">
              Last updated: {new Date(tag.noteHistory[tag.noteHistory.length - 1].timestamp).toLocaleDateString()}
            </div>
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
