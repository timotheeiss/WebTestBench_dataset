import React, { createContext, useContext, useState, useCallback } from 'react';
import {
  Tag,
  TagGroup,
  ContentItem,
  GroupTemplate,
  NoteHistory,
  initialTags,
  initialTagGroups,
  initialContentItems,
  groupTemplates,
} from '@/data/mockData';

interface TagContextType {
  tags: Tag[];
  tagGroups: TagGroup[];
  contentItems: ContentItem[];
  templates: GroupTemplate[];
  customTemplates: GroupTemplate[];
  
  // Tag operations
  createTag: (tag: Omit<Tag, 'id' | 'usageCount' | 'noteHistory' | 'createdAt'>) => void;
  updateTag: (id: string, updates: Partial<Tag>) => void;
  deleteTag: (id: string) => void;
  mergeTags: (sourceIds: string[], targetId: string) => void;
  batchRenameTags: (tagIds: string[], pattern: string, replacement: string) => void;
  
  // Group operations
  createTagGroup: (group: Omit<TagGroup, 'id' | 'noteHistory'>) => void;
  updateTagGroup: (id: string, updates: Partial<TagGroup>) => void;
  deleteTagGroup: (id: string) => void;
  toggleGroupExpanded: (id: string) => void;
  
  // Note operations
  updateNotes: (type: 'tag' | 'group', id: string, notes: string) => void;
  
  // Template operations
  applyTemplate: (templateId: string) => void;
  saveAsTemplate: (name: string, description: string, groupIds: string[]) => void;
  
  // Utility functions
  getSimilarTags: (name: string) => Tag[];
  getTagsByGroup: (groupId: string) => Tag[];
  getContentByTag: (tagId: string) => ContentItem[];
  getMergeImpact: (sourceIds: string[], targetId: string) => { affectedContent: ContentItem[]; tagsMerged: Tag[] };
}

const TagContext = createContext<TagContextType | undefined>(undefined);

export function TagProvider({ children }: { children: React.ReactNode }) {
  const [tags, setTags] = useState<Tag[]>(initialTags);
  const [tagGroups, setTagGroups] = useState<TagGroup[]>(initialTagGroups);
  const [contentItems, setContentItems] = useState<ContentItem[]>(initialContentItems);
  const [customTemplates, setCustomTemplates] = useState<GroupTemplate[]>([]);

  const generateId = () => `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const createTag = useCallback((tagData: Omit<Tag, 'id' | 'usageCount' | 'noteHistory' | 'createdAt'>) => {
    const newTag: Tag = {
      ...tagData,
      id: generateId(),
      usageCount: 0,
      noteHistory: [],
      createdAt: new Date(),
    };
    setTags(prev => [...prev, newTag]);
  }, []);

  const updateTag = useCallback((id: string, updates: Partial<Tag>) => {
    setTags(prev => prev.map(tag => 
      tag.id === id ? { ...tag, ...updates } : tag
    ));
  }, []);

  const deleteTag = useCallback((id: string) => {
    setTags(prev => prev.filter(tag => tag.id !== id));
    setContentItems(prev => prev.map(item => ({
      ...item,
      tagIds: item.tagIds.filter(tagId => tagId !== id),
    })));
  }, []);

  const mergeTags = useCallback((sourceIds: string[], targetId: string) => {
    // Update content items to replace source tags with target
    setContentItems(prev => prev.map(item => {
      const hasSourceTag = item.tagIds.some(id => sourceIds.includes(id));
      if (hasSourceTag) {
        const newTagIds = item.tagIds.filter(id => !sourceIds.includes(id));
        if (!newTagIds.includes(targetId)) {
          newTagIds.push(targetId);
        }
        return { ...item, tagIds: newTagIds };
      }
      return item;
    }));

    // Update target tag usage count
    const sourceUsageCount = tags
      .filter(t => sourceIds.includes(t.id))
      .reduce((sum, t) => sum + t.usageCount, 0);
    
    setTags(prev => prev
      .filter(tag => !sourceIds.includes(tag.id))
      .map(tag => tag.id === targetId 
        ? { ...tag, usageCount: tag.usageCount + sourceUsageCount }
        : tag
      )
    );
  }, [tags]);

  const batchRenameTags = useCallback((tagIds: string[], pattern: string, replacement: string) => {
    setTags(prev => prev.map(tag => {
      if (tagIds.includes(tag.id)) {
        const regex = new RegExp(pattern, 'gi');
        return { ...tag, name: tag.name.replace(regex, replacement) };
      }
      return tag;
    }));
  }, []);

  const createTagGroup = useCallback((groupData: Omit<TagGroup, 'id' | 'noteHistory'>) => {
    const newGroup: TagGroup = {
      ...groupData,
      id: generateId(),
      noteHistory: [],
    };
    setTagGroups(prev => [...prev, newGroup]);
  }, []);

  const updateTagGroup = useCallback((id: string, updates: Partial<TagGroup>) => {
    setTagGroups(prev => prev.map(group => 
      group.id === id ? { ...group, ...updates } : group
    ));
  }, []);

  const deleteTagGroup = useCallback((id: string) => {
    // Also delete all tags in this group
    setTags(prev => prev.filter(tag => tag.groupId !== id));
    setTagGroups(prev => prev.filter(group => group.id !== id));
  }, []);

  const toggleGroupExpanded = useCallback((id: string) => {
    setTagGroups(prev => prev.map(group => 
      group.id === id ? { ...group, isExpanded: !group.isExpanded } : group
    ));
  }, []);

  const updateNotes = useCallback((type: 'tag' | 'group', id: string, notes: string) => {
    const historyEntry: NoteHistory = {
      content: notes,
      timestamp: new Date(),
      author: 'Current User',
    };

    if (type === 'tag') {
      setTags(prev => prev.map(tag => {
        if (tag.id === id) {
          return {
            ...tag,
            notes,
            noteHistory: [...tag.noteHistory, historyEntry],
          };
        }
        return tag;
      }));
    } else {
      setTagGroups(prev => prev.map(group => {
        if (group.id === id) {
          return {
            ...group,
            notes,
            noteHistory: [...group.noteHistory, historyEntry],
          };
        }
        return group;
      }));
    }
  }, []);

  const applyTemplate = useCallback((templateId: string) => {
    const template = [...groupTemplates, ...customTemplates].find(t => t.id === templateId);
    if (!template) return;

    const groupIdMap: Record<string, string> = {};
    
    // Create groups
    template.groups.forEach(groupData => {
      const newId = generateId();
      groupIdMap[groupData.name] = newId;
      const newGroup: TagGroup = {
        ...groupData,
        id: newId,
        noteHistory: [],
      };
      setTagGroups(prev => [...prev, newGroup]);
    });

    // Create tags with mapped group IDs
    template.tags.forEach(tagData => {
      const groupId = groupIdMap[tagData.groupId];
      if (groupId) {
        const newTag: Tag = {
          ...tagData,
          id: generateId(),
          groupId,
          usageCount: 0,
          noteHistory: [],
          createdAt: new Date(),
        };
        setTags(prev => [...prev, newTag]);
      }
    });
  }, [customTemplates]);

  const saveAsTemplate = useCallback((name: string, description: string, groupIds: string[]) => {
    const selectedGroups = tagGroups.filter(g => groupIds.includes(g.id));
    const selectedTags = tags.filter(t => groupIds.includes(t.groupId));

    const template: GroupTemplate = {
      id: generateId(),
      name,
      description,
      groups: selectedGroups.map(({ id, noteHistory, ...rest }) => rest),
      tags: selectedTags.map(({ id, usageCount, noteHistory, createdAt, groupId, ...rest }) => ({
        ...rest,
        groupId: tagGroups.find(g => g.id === groupId)?.name || groupId,
      })),
    };

    setCustomTemplates(prev => [...prev, template]);
  }, [tagGroups, tags]);

  const getSimilarTags = useCallback((name: string): Tag[] => {
    if (!name || name.length < 2) return [];
    const lowerName = name.toLowerCase();
    return tags.filter(tag => {
      const tagName = tag.name.toLowerCase();
      return tagName.includes(lowerName) || 
             lowerName.includes(tagName) ||
             levenshteinDistance(tagName, lowerName) <= 2;
    }).slice(0, 5);
  }, [tags]);

  const getTagsByGroup = useCallback((groupId: string): Tag[] => {
    return tags.filter(tag => tag.groupId === groupId);
  }, [tags]);

  const getContentByTag = useCallback((tagId: string): ContentItem[] => {
    return contentItems.filter(item => item.tagIds.includes(tagId));
  }, [contentItems]);

  const getMergeImpact = useCallback((sourceIds: string[], targetId: string) => {
    const affectedContent = contentItems.filter(item => 
      item.tagIds.some(id => sourceIds.includes(id))
    );
    const tagsMerged = tags.filter(t => sourceIds.includes(t.id));
    return { affectedContent, tagsMerged };
  }, [contentItems, tags]);

  return (
    <TagContext.Provider value={{
      tags,
      tagGroups,
      contentItems,
      templates: groupTemplates,
      customTemplates,
      createTag,
      updateTag,
      deleteTag,
      mergeTags,
      batchRenameTags,
      createTagGroup,
      updateTagGroup,
      deleteTagGroup,
      toggleGroupExpanded,
      updateNotes,
      applyTemplate,
      saveAsTemplate,
      getSimilarTags,
      getTagsByGroup,
      getContentByTag,
      getMergeImpact,
    }}>
      {children}
    </TagContext.Provider>
  );
}

export function useTagContext() {
  const context = useContext(TagContext);
  if (!context) {
    throw new Error('useTagContext must be used within a TagProvider');
  }
  return context;
}

// Simple Levenshtein distance for similarity matching
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[b.length][a.length];
}
