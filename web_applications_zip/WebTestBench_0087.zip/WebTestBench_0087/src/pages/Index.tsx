import React, { useState } from 'react';
import { TagProvider, useTagContext } from '@/contexts/TagContext';
import { Header } from '@/components/Header';
import { StatsOverview } from '@/components/StatsOverview';
import { TagGroupCard } from '@/components/TagGroupCard';
import { TagDialog } from '@/components/TagDialog';
import { GroupDialog } from '@/components/GroupDialog';
import { BatchOperationsPanel } from '@/components/BatchOperationsPanel';
import { Tag, TagGroup } from '@/data/mockData';

function TagManagerContent() {
  const { tagGroups } = useTagContext();
  
  const [showTagDialog, setShowTagDialog] = useState(false);
  const [showGroupDialog, setShowGroupDialog] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [editingGroup, setEditingGroup] = useState<TagGroup | null>(null);
  const [defaultGroupId, setDefaultGroupId] = useState<string | undefined>();
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const handleCreateTag = (groupId?: string) => {
    setEditingTag(null);
    setDefaultGroupId(groupId);
    setShowTagDialog(true);
  };

  const handleEditTag = (tag: Tag) => {
    setEditingTag(tag);
    setDefaultGroupId(undefined);
    setShowTagDialog(true);
  };

  const handleCreateGroup = () => {
    setEditingGroup(null);
    setShowGroupDialog(true);
  };

  const handleEditGroup = (group: TagGroup) => {
    setEditingGroup(group);
    setShowGroupDialog(true);
  };

  const handleSelectTag = (id: string) => {
    setSelectedTags(prev => 
      prev.includes(id) 
        ? prev.filter(t => t !== id)
        : [...prev, id]
    );
  };

  const handleClearSelection = () => {
    setSelectedTags([]);
    setSelectionMode(false);
  };

  const toggleSelectionMode = () => {
    if (selectionMode) {
      setSelectedTags([]);
    }
    setSelectionMode(!selectionMode);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        onCreateTag={() => handleCreateTag()}
        onCreateGroup={handleCreateGroup}
        selectionMode={selectionMode}
        onToggleSelectionMode={toggleSelectionMode}
      />

      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        <StatsOverview />

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">Tag Groups</h2>
            {selectionMode && (
              <p className="text-sm text-muted-foreground">
                Click tags to select them for batch operations
              </p>
            )}
          </div>

          <div className="space-y-4">
            {tagGroups.map(group => (
              <TagGroupCard
                key={group.id}
                group={group}
                onAddTag={handleCreateTag}
                onEditGroup={handleEditGroup}
                onEditTag={handleEditTag}
                onDeleteTag={() => {}}
                selectedTags={selectedTags}
                onSelectTag={handleSelectTag}
                selectionMode={selectionMode}
              />
            ))}

            {tagGroups.length === 0 && (
              <div className="text-center py-16 bg-card border border-border rounded-lg">
                <p className="text-muted-foreground mb-4">
                  No tag groups yet. Create your first group or use a template.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      <TagDialog
        open={showTagDialog}
        onClose={() => setShowTagDialog(false)}
        tag={editingTag}
        defaultGroupId={defaultGroupId}
      />

      <GroupDialog
        open={showGroupDialog}
        onClose={() => setShowGroupDialog(false)}
        group={editingGroup}
      />

      <BatchOperationsPanel
        selectedTagIds={selectedTags}
        onClearSelection={handleClearSelection}
      />
    </div>
  );
}

export default function Index() {
  return (
    <TagProvider>
      <TagManagerContent />
    </TagProvider>
  );
}
