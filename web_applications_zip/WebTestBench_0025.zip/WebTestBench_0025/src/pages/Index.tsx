import { useState, useCallback } from "react";
import { categories as defaultCategories, prompts as defaultPrompts, Category, Prompt } from "@/data/prompts";
import CategoryCard from "@/components/CategoryCard";
import PromptDisplay from "@/components/PromptDisplay";
import HistoryPanel from "@/components/HistoryPanel";
import FavoritesPanel from "@/components/FavoritesPanel";
import CategoryDialog from "@/components/CategoryDialog";
import DeleteCategoryDialog from "@/components/DeleteCategoryDialog";
import { Button } from "@/components/ui/button";
import { Feather, Plus } from "lucide-react";
import { toast } from "sonner";

const Index = () => {
  const [categories, setCategories] = useState<Category[]>(defaultCategories);
  const [prompts, setPrompts] = useState<Prompt[]>(defaultPrompts);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentPrompt, setCurrentPrompt] = useState<Prompt | null>(null);
  const [history, setHistory] = useState<Prompt[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  // Category dialog state
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deleteCategoryDialogOpen, setDeleteCategoryDialogOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);

  const getRandomPrompt = useCallback((categoryId: string): Prompt | null => {
    const categoryPrompts = prompts.filter((p) => p.categoryId === categoryId);
    if (categoryPrompts.length === 0) return null;
    return categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)];
  }, [prompts]);

  const handleCategorySelect = useCallback((categoryId: string) => {
    setSelectedCategory(categoryId);
    // Generate a prompt when category is selected
    const newPrompt = getRandomPrompt(categoryId);
    if (newPrompt) {
      setCurrentPrompt(newPrompt);
      setHistory((prev) => {
        // Avoid duplicate consecutive entries
        if (prev[0]?.id === newPrompt.id) return prev;
        return [newPrompt, ...prev].slice(0, 50); // Keep last 50
      });
    }
  }, []);

  const handleGeneratePrompt = useCallback(() => {
    if (!selectedCategory) return;

    const newPrompt = getRandomPrompt(selectedCategory);
    if (newPrompt) {
      setCurrentPrompt(newPrompt);
      setHistory((prev) => {
        if (prev[0]?.id === newPrompt.id) return prev;
        return [newPrompt, ...prev].slice(0, 50);
      });
    }
  }, [selectedCategory]);

  const handleToggleFavorite = useCallback((promptId?: string) => {
    const id = promptId || currentPrompt?.id;
    if (!id) return;

    setFavorites((prev) => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(id)) {
        newFavorites.delete(id);
      } else {
        newFavorites.add(id);
      }
      return newFavorites;
    });
  }, [currentPrompt]);

  const handleSelectFromHistory = useCallback((prompt: Prompt) => {
    setCurrentPrompt(prompt);
    setSelectedCategory(prompt.categoryId);
  }, []);

  const handleClearHistory = useCallback(() => {
    setHistory([]);
  }, []);

  const handleAddCategory = useCallback(() => {
    setEditingCategory(null);
    setCategoryDialogOpen(true);
  }, []);

  const handleEditCategory = useCallback((category: Category) => {
    setEditingCategory(category);
    setCategoryDialogOpen(true);
  }, []);

  const handleDeleteCategoryClick = useCallback((category: Category) => {
    setCategoryToDelete(category);
    setDeleteCategoryDialogOpen(true);
  }, []);

  const handleSaveCategory = useCallback((categoryData: Omit<Category, "id"> & { id?: string }) => {
    if (categoryData.id) {
      // Editing existing category
      setCategories((prev) =>
        prev.map((cat) =>
          cat.id === categoryData.id ? { ...cat, ...categoryData } as Category : cat
        )
      );
      toast.success("Category updated");
    } else {
      // Adding new category
      const newCategory: Category = {
        ...categoryData,
        id: `custom-${Date.now()}`,
      };
      setCategories((prev) => [...prev, newCategory]);
      toast.success("Category added");
    }
  }, []);

  const handleConfirmDelete = useCallback(() => {
    if (!categoryToDelete) return;

    setCategories((prev) => prev.filter((cat) => cat.id !== categoryToDelete.id));
    setPrompts((prev) => prev.filter((p) => p.categoryId !== categoryToDelete.id));

    if (selectedCategory === categoryToDelete.id) {
      setSelectedCategory(null);
      setCurrentPrompt(null);
    }

    toast.success("Category deleted");
    setDeleteCategoryDialogOpen(false);
    setCategoryToDelete(null);
  }, [categoryToDelete, selectedCategory]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Feather className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold text-foreground">
              Muse & Quill
            </h1>
            <p className="text-xs text-muted-foreground">
              Creative Prompt Generator
            </p>
          </div>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main content area */}
          <div className="lg:col-span-8 space-y-8">
            {/* Hero section */}
            <section className="text-center mb-8">
              <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
                Ignite Your Creativity
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                Select a category below to discover unique prompts that will spark
                your imagination and guide your creative journey.
              </p>
            </section>

            {/* Category grid */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                  <span className="w-1.5 h-6 bg-primary rounded-full" />
                  Choose Your Path
                </h3>
                <Button variant="outline" size="sm" onClick={handleAddCategory}>
                  <Plus className="w-4 h-4 mr-1" />
                  Add Category
                </Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((category) => (
                  <CategoryCard
                    key={category.id}
                    category={category}
                    isSelected={selectedCategory === category.id}
                    onClick={() => handleCategorySelect(category.id)}
                    onEdit={() => handleEditCategory(category)}
                    onDelete={() => handleDeleteCategoryClick(category)}
                  />
                ))}
              </div>
            </section>

            {/* Prompt display */}
            <section>
              <h3 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <span className="w-1.5 h-6 bg-secondary rounded-full" />
                Your Prompt
              </h3>
              <PromptDisplay
                prompt={currentPrompt}
                isFavorite={currentPrompt ? favorites.has(currentPrompt.id) : false}
                onToggleFavorite={() => handleToggleFavorite()}
                onGenerate={handleGeneratePrompt}
                hasCategory={!!selectedCategory}
              />
            </section>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-6">
            {/* History panel */}
            <div className="h-80 lg:h-[400px]">
              <HistoryPanel
                history={history}
                favorites={favorites}
                onSelectPrompt={handleSelectFromHistory}
                onToggleFavorite={handleToggleFavorite}
                onClearHistory={handleClearHistory}
                currentPromptId={currentPrompt?.id}
              />
            </div>

            {/* Favorites panel */}
            <div className="h-80 lg:h-[400px]">
              <FavoritesPanel
                favorites={favorites}
                onSelectPrompt={handleSelectFromHistory}
                onToggleFavorite={handleToggleFavorite}
                currentPromptId={currentPrompt?.id}
              />
            </div>
          </aside>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16 py-8">
        <div className="container max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Let the words flow. Every great story begins with a single spark of inspiration.
          </p>
        </div>
      </footer>

      {/* Dialogs */}
      <CategoryDialog
        open={categoryDialogOpen}
        onOpenChange={setCategoryDialogOpen}
        category={editingCategory}
        onSave={handleSaveCategory}
      />

      <DeleteCategoryDialog
        open={deleteCategoryDialogOpen}
        onOpenChange={setDeleteCategoryDialogOpen}
        category={categoryToDelete}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
};

export default Index;
