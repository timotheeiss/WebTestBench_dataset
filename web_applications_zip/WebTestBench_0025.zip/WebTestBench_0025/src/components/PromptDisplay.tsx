import { Prompt, getCategoryById } from "@/data/prompts";
import { Heart, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface PromptDisplayProps {
  prompt: Prompt | null;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onGenerate: () => void;
  hasCategory: boolean;
}

const PromptDisplay = ({
  prompt,
  isFavorite,
  onToggleFavorite,
  onGenerate,
  hasCategory,
}: PromptDisplayProps) => {
  const category = prompt ? getCategoryById(prompt.categoryId) : null;

  return (
    <div className="relative bg-card rounded-2xl border border-border shadow-soft p-8 md:p-12">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden rounded-2xl pointer-events-none">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-secondary/5 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {!hasCategory ? (
          <div className="text-center py-12">
            <span className="text-6xl mb-6 block animate-float">✨</span>
            <h2 className="font-display text-2xl md:text-3xl text-foreground mb-4">
              Choose Your Muse
            </h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Select a category above to begin your creative journey. Each category
              holds unique prompts waiting to spark your imagination.
            </p>
          </div>
        ) : prompt ? (
          <div className="animate-fade-in">
            {/* Category badge */}
            {category && (
              <div className="flex items-center gap-2 mb-6">
                <span className="text-xl">{category.icon}</span>
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {category.name}
                </span>
              </div>
            )}

            {/* Prompt text */}
            <blockquote className="font-display text-2xl md:text-3xl lg:text-4xl text-foreground leading-relaxed mb-8 text-balance">
              "{prompt.text}"
            </blockquote>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onGenerate}
                className={cn(
                  "flex items-center justify-center gap-2 px-6 py-3 rounded-xl",
                  "bg-primary text-primary-foreground font-medium",
                  "hover:opacity-90 transition-all duration-200",
                  "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
                  "shadow-soft hover:shadow-elevated"
                )}
              >
                <Sparkles className="w-5 h-5" />
                Generate Another
              </button>

              <button
                onClick={onToggleFavorite}
                className={cn(
                  "flex items-center justify-center gap-2 px-6 py-3 rounded-xl",
                  "border-2 font-medium transition-all duration-200",
                  "focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 focus:ring-offset-background",
                  isFavorite
                    ? "border-accent bg-accent/10 text-accent"
                    : "border-border text-foreground hover:border-accent hover:text-accent"
                )}
              >
                <Heart
                  className={cn(
                    "w-5 h-5 transition-all duration-200",
                    isFavorite && "fill-accent"
                  )}
                />
                {isFavorite ? "Favorited" : "Add to Favorites"}
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <span className="text-6xl mb-6 block">🎲</span>
            <h2 className="font-display text-2xl text-foreground mb-4">
              Ready to Create?
            </h2>
            <p className="text-muted-foreground mb-6">
              Click the button below to generate your first prompt.
            </p>
            <button
              onClick={onGenerate}
              className={cn(
                "inline-flex items-center gap-2 px-8 py-4 rounded-xl",
                "bg-primary text-primary-foreground font-medium text-lg",
                "hover:opacity-90 transition-all duration-200",
                "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
                "shadow-soft hover:shadow-elevated"
              )}
            >
              <Sparkles className="w-5 h-5" />
              Generate Prompt
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PromptDisplay;
