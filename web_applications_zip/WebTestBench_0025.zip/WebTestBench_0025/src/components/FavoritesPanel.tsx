import { Prompt, getCategoryById, prompts } from "@/data/prompts";
import { Heart, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface FavoritesPanelProps {
  favorites: Set<string>;
  onSelectPrompt: (prompt: Prompt) => void;
  onToggleFavorite: (promptId: string) => void;
  currentPromptId?: string;
}

const FavoritesPanel = ({
  favorites,
  onSelectPrompt,
  onToggleFavorite,
  currentPromptId,
}: FavoritesPanelProps) => {
  const favoritePrompts = prompts.filter((p) => favorites.has(p.id));

  return (
    <div className="bg-card rounded-2xl border border-border shadow-soft overflow-hidden h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center gap-2">
        <Heart className="w-4 h-4 text-accent fill-accent" />
        <h3 className="font-display font-semibold text-foreground">Favorites</h3>
        <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
          {favorites.size}
        </span>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {favoritePrompts.length === 0 ? (
          <div className="p-6 text-center">
            <span className="text-3xl mb-3 block opacity-50">💫</span>
            <p className="text-sm text-muted-foreground">
              Save your favorite prompts by clicking the heart icon.
            </p>
          </div>
        ) : (
          <div className="p-2">
            {favoritePrompts.map((prompt) => {
              const category = getCategoryById(prompt.categoryId);
              const isCurrent = prompt.id === currentPromptId;

              return (
                <div
                  key={prompt.id}
                  className={cn(
                    "group relative p-3 rounded-lg cursor-pointer transition-all duration-200",
                    "hover:bg-muted/50",
                    isCurrent && "bg-primary/10 border border-primary/20"
                  )}
                  onClick={() => onSelectPrompt(prompt)}
                >
                  <div className="flex items-start gap-3">
                    {/* Category icon */}
                    <span className="text-lg shrink-0">{category?.icon}</span>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground line-clamp-2 leading-relaxed">
                        {prompt.text}
                      </p>
                      <span className="text-xs text-muted-foreground mt-1 block">
                        {category?.name}
                      </span>
                    </div>

                    {/* Remove favorite button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(prompt.id);
                      }}
                      className="shrink-0 p-1 rounded-md transition-all duration-200"
                    >
                      <Heart className="w-4 h-4 text-accent fill-accent hover:scale-110 transition-transform" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default FavoritesPanel;
