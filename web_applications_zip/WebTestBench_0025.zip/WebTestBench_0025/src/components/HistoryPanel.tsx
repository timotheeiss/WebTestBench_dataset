import { Prompt, getCategoryById } from "@/data/prompts";
import { Clock, Heart, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface HistoryPanelProps {
  history: Prompt[];
  favorites: Set<string>;
  onSelectPrompt: (prompt: Prompt) => void;
  onToggleFavorite: (promptId: string) => void;
  onClearHistory: () => void;
  currentPromptId?: string;
}

const HistoryPanel = ({
  history,
  favorites,
  onSelectPrompt,
  onToggleFavorite,
  onClearHistory,
  currentPromptId,
}: HistoryPanelProps) => {
  return (
    <div className="bg-card rounded-2xl border border-border shadow-soft overflow-hidden h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <h3 className="font-display font-semibold text-foreground">History</h3>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
            {history.length}
          </span>
        </div>
        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="text-xs text-muted-foreground hover:text-destructive transition-colors flex items-center gap-1"
          >
            <Trash2 className="w-3 h-3" />
            Clear
          </button>
        )}
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {history.length === 0 ? (
          <div className="p-6 text-center">
            <span className="text-3xl mb-3 block opacity-50">📜</span>
            <p className="text-sm text-muted-foreground">
              Your prompt history will appear here as you explore.
            </p>
          </div>
        ) : (
          <div className="p-2">
            {history.map((prompt, index) => {
              const category = getCategoryById(prompt.categoryId);
              const isFavorite = favorites.has(prompt.id);
              const isCurrent = prompt.id === currentPromptId;

              return (
                <div
                  key={`${prompt.id}-${index}`}
                  className={cn(
                    "group relative p-3 rounded-lg cursor-pointer transition-all duration-200",
                    "hover:bg-muted/50",
                    isCurrent && "bg-primary/10 border border-primary/20"
                  )}
                  onClick={() => onSelectPrompt(prompt)}
                >
                  <div className="flex items-start gap-3">
                    {/* Category icon */}
                    <span className="text-lg shrink-0">{category?.icon}</span>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground line-clamp-2 leading-relaxed">
                        {prompt.text}
                      </p>
                      <span className="text-xs text-muted-foreground mt-1 block">
                        {category?.name}
                      </span>
                    </div>

                    {/* Favorite button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(prompt.id);
                      }}
                      className={cn(
                        "shrink-0 p-1 rounded-md transition-all duration-200",
                        "opacity-0 group-hover:opacity-100",
                        isFavorite && "opacity-100"
                      )}
                    >
                      <Heart
                        className={cn(
                          "w-4 h-4 transition-colors",
                          isFavorite
                            ? "text-accent fill-accent"
                            : "text-muted-foreground hover:text-accent"
                        )}
                      />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default HistoryPanel;
