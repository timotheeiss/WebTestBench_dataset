import { Category } from "@/data/prompts";
import { cn } from "@/lib/utils";
import { Pencil, Trash2 } from "lucide-react";

interface CategoryCardProps {
  category: Category;
  isSelected: boolean;
  onClick: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}

const CategoryCard = ({ category, isSelected, onClick, onEdit, onDelete }: CategoryCardProps) => {
  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit?.();
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete?.();
  };

  return (
    <button
      onClick={onClick}
      className={cn(
        "group relative w-full p-6 rounded-xl border-2 text-left transition-all duration-300",
        "hover:shadow-elevated hover:-translate-y-1",
        "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
        isSelected
          ? "border-primary bg-card shadow-glow"
          : "border-border bg-card/50 hover:bg-card hover:border-primary/40"
      )}
    >
      {/* Action buttons */}
      <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div
          role="button"
          tabIndex={0}
          onClick={handleEdit}
          onKeyDown={(e) => e.key === 'Enter' && handleEdit(e as any)}
          className="p-1.5 rounded-md bg-muted hover:bg-muted-foreground/20 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <Pencil className="w-3.5 h-3.5" />
        </div>
        <div
          role="button"
          tabIndex={0}
          onClick={handleDelete}
          onKeyDown={(e) => e.key === 'Enter' && handleDelete(e as any)}
          className="p-1.5 rounded-md bg-muted hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </div>
      </div>

      {/* Decorative corner */}
      <div
        className={cn(
          "absolute top-0 right-0 w-16 h-16 opacity-20 transition-opacity duration-300",
          "bg-gradient-to-bl from-primary/30 to-transparent rounded-tr-xl",
          isSelected && "opacity-40"
        )}
      />

      {/* Icon */}
      <span className="text-4xl mb-4 block group-hover:animate-float">
        {category.icon}
      </span>

      {/* Title */}
      <h3 className="font-display text-xl font-semibold text-foreground mb-2">
        {category.name}
      </h3>

      {/* Description */}
      <p className="text-sm text-muted-foreground leading-relaxed">
        {category.description}
      </p>

      {/* Selection indicator */}
      {isSelected && (
        <div className="absolute bottom-3 right-3 w-3 h-3 rounded-full bg-primary animate-pulse" />
      )}
    </button>
  );
};

export default CategoryCard;
