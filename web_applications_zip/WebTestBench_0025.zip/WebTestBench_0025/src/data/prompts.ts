export type Category = {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
};

export type Prompt = {
  id: string;
  categoryId: string;
  text: string;
};

export const categories: Category[] = [
  {
    id: "short-stories",
    name: "Short Stories",
    description: "Spark your imagination with compelling narrative starters",
    icon: "📖",
    color: "primary",
  },
  {
    id: "poetry",
    name: "Poetry",
    description: "Find inspiration for verses that move the soul",
    icon: "🪶",
    color: "secondary",
  },
  {
    id: "character-sketches",
    name: "Character Sketches",
    description: "Craft memorable characters with depth and nuance",
    icon: "👤",
    color: "accent",
  },
  {
    id: "fantasy-landscapes",
    name: "Fantasy Landscapes",
    description: "Build worlds beyond imagination",
    icon: "🏔️",
    color: "sage",
  },
  {
    id: "brainstorming",
    name: "Brainstorming",
    description: "Unlock creative ideas and fresh perspectives",
    icon: "💡",
    color: "gold",
  },
];

export const prompts: Prompt[] = [
  // Short Stories
  {
    id: "ss-1",
    categoryId: "short-stories",
    text: "A letter arrives 50 years late, addressed to someone who has been dead for decades. The recipient's grandchild opens it.",
  },
  {
    id: "ss-2",
    categoryId: "short-stories",
    text: "The last lighthouse keeper on Earth receives an unexpected visitor during the final storm.",
  },
  {
    id: "ss-3",
    categoryId: "short-stories",
    text: "Two strangers are stuck in an elevator during a blackout. One of them knows a secret about the other.",
  },
  {
    id: "ss-4",
    categoryId: "short-stories",
    text: "A chef discovers that their signature dish has an unusual effect on everyone who eats it.",
  },
  {
    id: "ss-5",
    categoryId: "short-stories",
    text: "The night before their wedding, they find a journal hidden in the attic that changes everything.",
  },
  {
    id: "ss-6",
    categoryId: "short-stories",
    text: "A music box that hasn't played in 30 years suddenly starts playing at midnight.",
  },
  {
    id: "ss-7",
    categoryId: "short-stories",
    text: "The town's oldest tree is about to be cut down. Only one person knows what's buried beneath it.",
  },
  {
    id: "ss-8",
    categoryId: "short-stories",
    text: "A photographer develops their last roll of film and finds pictures they don't remember taking.",
  },

  // Poetry
  {
    id: "p-1",
    categoryId: "poetry",
    text: "Write about the moment between sleep and waking—that liminal space where dreams still feel real.",
  },
  {
    id: "p-2",
    categoryId: "poetry",
    text: "Describe the color blue without using the word 'blue' or any of its synonyms.",
  },
  {
    id: "p-3",
    categoryId: "poetry",
    text: "A love poem from the perspective of the moon watching two people on Earth.",
  },
  {
    id: "p-4",
    categoryId: "poetry",
    text: "The last conversation between autumn and winter as the seasons change.",
  },
  {
    id: "p-5",
    categoryId: "poetry",
    text: "Write about hands—what they remember, what they've held, what they've let go.",
  },
  {
    id: "p-6",
    categoryId: "poetry",
    text: "A poem that begins with silence and ends with thunder.",
  },
  {
    id: "p-7",
    categoryId: "poetry",
    text: "Describe grief as if it were a physical place you must travel through.",
  },
  {
    id: "p-8",
    categoryId: "poetry",
    text: "Write about something ordinary—a coffee cup, a doorknob, a shadow—as if seeing it for the first time.",
  },

  // Character Sketches
  {
    id: "cs-1",
    categoryId: "character-sketches",
    text: "A retired assassin who now runs a peaceful flower shop, but their past clients keep finding them.",
  },
  {
    id: "cs-2",
    categoryId: "character-sketches",
    text: "An archivist who can hear the whispers of everyone who has ever touched the documents they handle.",
  },
  {
    id: "cs-3",
    categoryId: "character-sketches",
    text: "A street musician who plays songs from people's memories—songs they've forgotten they knew.",
  },
  {
    id: "cs-4",
    categoryId: "character-sketches",
    text: "A lighthouse keeper who has never seen the ocean but knows its moods better than anyone.",
  },
  {
    id: "cs-5",
    categoryId: "character-sketches",
    text: "A cartographer who maps places that don't exist yet—but somehow, they always come true.",
  },
  {
    id: "cs-6",
    categoryId: "character-sketches",
    text: "An elderly dancer whose body remembers choreography their mind has forgotten.",
  },
  {
    id: "cs-7",
    categoryId: "character-sketches",
    text: "A chef who can taste lies. Every dishonest word leaves a bitter flavor only they can detect.",
  },
  {
    id: "cs-8",
    categoryId: "character-sketches",
    text: "A translator who discovers they can understand languages that have never been spoken by humans.",
  },

  // Fantasy Landscapes
  {
    id: "fl-1",
    categoryId: "fantasy-landscapes",
    text: "A forest where the trees grow downward into the sky, their roots reaching toward the stars.",
  },
  {
    id: "fl-2",
    categoryId: "fantasy-landscapes",
    text: "A city built entirely on the back of a sleeping giant, who stirs once every hundred years.",
  },
  {
    id: "fl-3",
    categoryId: "fantasy-landscapes",
    text: "An ocean where memories wash ashore instead of shells, and you can pick up moments from other lives.",
  },
  {
    id: "fl-4",
    categoryId: "fantasy-landscapes",
    text: "A mountain range where each peak exists in a different season simultaneously.",
  },
  {
    id: "fl-5",
    categoryId: "fantasy-landscapes",
    text: "A desert made of crystallized music, where every footstep releases a different melody.",
  },
  {
    id: "fl-6",
    categoryId: "fantasy-landscapes",
    text: "A garden where plants grow different emotions—joy blooms in spring, melancholy roots in autumn.",
  },
  {
    id: "fl-7",
    categoryId: "fantasy-landscapes",
    text: "An underground library where books write themselves from the dreams of those sleeping above.",
  },
  {
    id: "fl-8",
    categoryId: "fantasy-landscapes",
    text: "A floating marketplace that appears only during eclipses, trading in impossible things.",
  },

  // Brainstorming
  {
    id: "b-1",
    categoryId: "brainstorming",
    text: "What would the world look like if humans could only communicate through music?",
  },
  {
    id: "b-2",
    categoryId: "brainstorming",
    text: "Imagine a society where sleep is a shared experience. How would privacy change?",
  },
  {
    id: "b-3",
    categoryId: "brainstorming",
    text: "What if memories could be traded like currency? What would be most valuable?",
  },
  {
    id: "b-4",
    categoryId: "brainstorming",
    text: "Design a new holiday that celebrates something currently overlooked or undervalued.",
  },
  {
    id: "b-5",
    categoryId: "brainstorming",
    text: "What would happen if every lie you told became visible as a physical mark on your skin?",
  },
  {
    id: "b-6",
    categoryId: "brainstorming",
    text: "Reimagine the concept of 'home' for a species that never stops moving.",
  },
  {
    id: "b-7",
    categoryId: "brainstorming",
    text: "What art form might exist that we haven't invented yet? Describe how it would work.",
  },
  {
    id: "b-8",
    categoryId: "brainstorming",
    text: "If you could redesign the way humans experience time, what would you change?",
  },
];

export const getPromptsByCategory = (categoryId: string): Prompt[] => {
  return prompts.filter((p) => p.categoryId === categoryId);
};

export const getRandomPrompt = (categoryId: string): Prompt | null => {
  const categoryPrompts = getPromptsByCategory(categoryId);
  if (categoryPrompts.length === 0) return null;
  return categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)];
};

export const getCategoryById = (categoryId: string): Category | undefined => {
  return categories.find((c) => c.id === categoryId);
};
