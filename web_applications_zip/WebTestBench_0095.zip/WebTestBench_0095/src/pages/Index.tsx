import { Header } from '@/components/Header';
import { ProblemForm } from '@/components/ProblemForm';
import { SolutionList } from '@/components/SolutionList';
import { WeightControls } from '@/components/WeightControls';
import { ProblemHistory } from '@/components/ProblemHistory';
import { useProblemStore } from '@/hooks/useProblemStore';

const Index = () => {
  const {
    problemsWithSolutions,
    weights,
    setWeights,
    addProblem,
    toggleSolutionAvailability,
    calculateScore,
    getRankedSolutions,
    currentProblemId,
    setCurrentProblemId,
    currentProblem,
  } = useProblemStore();

  const rankedSolutions = currentProblemId ? getRankedSolutions(currentProblemId) : [];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column - Form & History */}
          <div className="lg:col-span-4 space-y-6">
            <ProblemForm onSubmit={addProblem} />
            
            <ProblemHistory
              problems={problemsWithSolutions}
              currentId={currentProblemId}
              onSelect={setCurrentProblemId}
            />
          </div>

          {/* Right Column - Solutions & Weights */}
          <div className="lg:col-span-8 space-y-6">
            {currentProblem ? (
              <>
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  <div className="xl:col-span-2">
                    <SolutionList
                      solutions={rankedSolutions}
                      urgency={currentProblem.problem.urgency}
                      problemDescription={currentProblem.problem.description}
                      calculateScore={calculateScore}
                      onToggleAvailability={(solutionId) => 
                        toggleSolutionAvailability(currentProblem.problem.id, solutionId)
                      }
                    />
                  </div>
                  <div className="xl:col-span-1">
                    <div className="sticky top-24">
                      <WeightControls weights={weights} onChange={setWeights} />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-[400px] bg-card rounded-xl border-2 border-dashed border-border">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                    <span className="text-3xl">💡</span>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">No Problem Selected</h3>
                  <p className="text-muted-foreground max-w-sm">
                    Submit a new problem using the form, or select one from your history to view solutions.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
