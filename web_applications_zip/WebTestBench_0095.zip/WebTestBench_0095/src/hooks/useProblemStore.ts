import { useState, useCallback } from 'react';
import { Problem, Solution, ProblemWithSolutions, RankingWeights, ProblemCategory, UrgencyLevel } from '@/types';
import { generateSolutions } from '@/data/solutions';

const DEFAULT_WEIGHTS: RankingWeights = {
  availability: 30,
  matchScore: 35,
  complexity: 15,
  adaptability: 20,
};

// Initial sample data
const initialProblems: ProblemWithSolutions[] = [
  {
    problem: {
      id: 'sample-1',
      category: 'technical',
      description: 'Our API response times have increased by 300% after the latest deployment. Need to identify and fix the bottleneck.',
      urgency: 'high',
      createdAt: new Date(Date.now() - 86400000), // 1 day ago
    },
    solutions: generateSolutions('sample-1', 'technical'),
  },
  {
    problem: {
      id: 'sample-2',
      category: 'business',
      description: 'We need to improve our customer retention rate which has dropped from 80% to 65% over the last quarter.',
      urgency: 'medium',
      createdAt: new Date(Date.now() - 172800000), // 2 days ago
    },
    solutions: generateSolutions('sample-2', 'business'),
  },
];

export function useProblemStore() {
  const [problemsWithSolutions, setProblemsWithSolutions] = useState<ProblemWithSolutions[]>(initialProblems);
  const [weights, setWeights] = useState<RankingWeights>(DEFAULT_WEIGHTS);
  const [currentProblemId, setCurrentProblemId] = useState<string | null>(null);

  const addProblem = useCallback((category: ProblemCategory, description: string, urgency: UrgencyLevel) => {
    const id = `problem-${Date.now()}`;
    const newProblem: Problem = {
      id,
      category,
      description,
      urgency,
      createdAt: new Date(),
    };
    
    const solutions = generateSolutions(id, category);
    
    setProblemsWithSolutions(prev => [{
      problem: newProblem,
      solutions,
    }, ...prev]);
    
    setCurrentProblemId(id);
    
    return id;
  }, []);

  const toggleSolutionAvailability = useCallback((problemId: string, solutionId: string) => {
    setProblemsWithSolutions(prev => prev.map(item => {
      if (item.problem.id !== problemId) return item;
      
      return {
        ...item,
        solutions: item.solutions.map(sol => 
          sol.id === solutionId 
            ? { ...sol, isAvailable: !sol.isAvailable }
            : sol
        ),
      };
    }));
  }, []);

  const calculateScore = useCallback((solution: Solution, urgency: UrgencyLevel): number => {
    const urgencyMultiplier = urgency === 'high' ? 1.5 : urgency === 'medium' ? 1.2 : 1;
    
    // Invert complexity so lower complexity = higher score
    const complexityScore = ((5 - solution.complexity) / 4) * 100;
    
    const weightedScore = 
      (solution.isAvailable ? 100 : 0) * (weights.availability / 100) +
      solution.matchScore * (weights.matchScore / 100) +
      complexityScore * (weights.complexity / 100) +
      solution.adaptability * (weights.adaptability / 100);
    
    // Apply urgency multiplier to adaptability component
    const urgencyBonus = solution.adaptability * (weights.adaptability / 100) * (urgencyMultiplier - 1);
    
    return Math.round(weightedScore + urgencyBonus);
  }, [weights]);

  const getRankedSolutions = useCallback((problemId: string): Solution[] => {
    const item = problemsWithSolutions.find(p => p.problem.id === problemId);
    if (!item) return [];
    
    return [...item.solutions].sort((a, b) => 
      calculateScore(b, item.problem.urgency) - calculateScore(a, item.problem.urgency)
    );
  }, [problemsWithSolutions, calculateScore]);

  const currentProblem = problemsWithSolutions.find(p => p.problem.id === currentProblemId);

  return {
    problemsWithSolutions,
    weights,
    setWeights,
    addProblem,
    toggleSolutionAvailability,
    calculateScore,
    getRankedSolutions,
    currentProblemId,
    setCurrentProblemId,
    currentProblem,
  };
}
