import { Solution, UrgencyLevel } from '@/types';
import { SolutionCard } from './SolutionCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles } from 'lucide-react';

interface SolutionListProps {
  solutions: Solution[];
  urgency: UrgencyLevel;
  problemDescription: string;
  calculateScore: (solution: Solution, urgency: UrgencyLevel) => number;
  onToggleAvailability: (solutionId: string) => void;
}

export function SolutionList({ 
  solutions, 
  urgency, 
  problemDescription,
  calculateScore, 
  onToggleAvailability 
}: SolutionListProps) {
  const availableCount = solutions.filter(s => s.isAvailable).length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Suggested Solutions
            </CardTitle>
            <CardDescription className="mt-1 line-clamp-2 max-w-xl">
              {problemDescription}
            </CardDescription>
          </div>
          <Badge variant="outline" className="shrink-0">
            {availableCount}/{solutions.length} available
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {solutions.map((solution, index) => (
          <SolutionCard
            key={solution.id}
            solution={solution}
            rank={index + 1}
            score={calculateScore(solution, urgency)}
            urgency={urgency}
            onToggleAvailability={() => onToggleAvailability(solution.id)}
          />
        ))}
      </CardContent>
    </Card>
  );
}
