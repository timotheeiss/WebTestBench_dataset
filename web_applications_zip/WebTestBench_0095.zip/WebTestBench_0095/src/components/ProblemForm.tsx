import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ProblemCategory, UrgencyLevel } from '@/types';
import { Lightbulb, Zap, Clock, AlertTriangle } from 'lucide-react';

interface ProblemFormProps {
  onSubmit: (category: ProblemCategory, description: string, urgency: UrgencyLevel) => void;
}

const categories: { value: ProblemCategory; label: string; icon: React.ReactNode }[] = [
  { value: 'technical', label: 'Technical', icon: <Zap className="w-4 h-4" /> },
  { value: 'business', label: 'Business', icon: <Lightbulb className="w-4 h-4" /> },
  { value: 'personal', label: 'Personal', icon: <Clock className="w-4 h-4" /> },
  { value: 'academic', label: 'Academic', icon: <AlertTriangle className="w-4 h-4" /> },
];

const urgencyLevels: { value: UrgencyLevel; label: string }[] = [
  { value: 'low', label: 'Low - Can wait' },
  { value: 'medium', label: 'Medium - Soon' },
  { value: 'high', label: 'High - Urgent' },
];

export function ProblemForm({ onSubmit }: ProblemFormProps) {
  const [category, setCategory] = useState<ProblemCategory | ''>('');
  const [description, setDescription] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel | ''>('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!category) newErrors.category = 'Please select a category';
    if (!description.trim()) newErrors.description = 'Please describe your problem';
    if (description.trim().length < 10) newErrors.description = 'Please provide more details (at least 10 characters)';
    if (!urgency) newErrors.urgency = 'Please select urgency level';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate() && category && urgency) {
      onSubmit(category, description.trim(), urgency);
      setDescription('');
      setCategory('');
      setUrgency('');
      setErrors({});
    }
  };

  return (
    <Card className="card-hover">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          Describe Your Problem
        </CardTitle>
        <CardDescription>
          Tell us what you're facing and we'll suggest solution approaches
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Problem Category</Label>
              <Select value={category} onValueChange={(val) => setCategory(val as ProblemCategory)}>
                <SelectTrigger id="category" className={errors.category ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select category..." />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      <span className="flex items-center gap-2">
                        {cat.icon}
                        {cat.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.category && (
                <p className="text-sm text-destructive">{errors.category}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="urgency">Urgency Level</Label>
              <Select value={urgency} onValueChange={(val) => setUrgency(val as UrgencyLevel)}>
                <SelectTrigger id="urgency" className={errors.urgency ? 'border-destructive' : ''}>
                  <SelectValue placeholder="How urgent?" />
                </SelectTrigger>
                <SelectContent>
                  {urgencyLevels.map((level) => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.urgency && (
                <p className="text-sm text-destructive">{errors.urgency}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Problem Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your problem in detail. What's happening? What have you tried? What outcome do you need?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`min-h-[120px] resize-none ${errors.description ? 'border-destructive' : ''}`}
            />
            {errors.description && (
              <p className="text-sm text-destructive">{errors.description}</p>
            )}
          </div>

          <Button type="submit" className="w-full" size="lg">
            Get Solution Suggestions
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
