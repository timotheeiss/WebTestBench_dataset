import { ProblemWithSolutions } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, Clock, ChevronRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface ProblemHistoryProps {
  problems: ProblemWithSolutions[];
  currentId: string | null;
  onSelect: (id: string) => void;
}

const categoryColors: Record<string, string> = {
  technical: 'category-badge-technical',
  business: 'category-badge-business',
  personal: 'category-badge-personal',
  academic: 'category-badge-academic',
};

const urgencyColors: Record<string, string> = {
  low: 'urgency-badge-low',
  medium: 'urgency-badge-medium',
  high: 'urgency-badge-high',
};

export function ProblemHistory({ problems, currentId, onSelect }: ProblemHistoryProps) {
  if (problems.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <History className="w-4 h-4 text-primary" />
            Problem History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No problems submitted yet. Describe your first problem above!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <History className="w-4 h-4 text-primary" />
          Problem History
          <Badge variant="secondary" className="ml-auto">{problems.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <div className="space-y-1 p-3 pt-0">
            {problems.map((item) => (
              <button
                key={item.problem.id}
                onClick={() => onSelect(item.problem.id)}
                className={`w-full text-left p-3 rounded-lg transition-all duration-200 group ${
                  currentId === item.problem.id
                    ? 'bg-primary/10 border border-primary/20'
                    : 'hover:bg-muted/50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <Badge className={`text-xs ${categoryColors[item.problem.category]}`}>
                        {item.problem.category}
                      </Badge>
                      <Badge className={`text-xs ${urgencyColors[item.problem.urgency]}`}>
                        {item.problem.urgency}
                      </Badge>
                    </div>
                    <p className="text-sm text-foreground line-clamp-2 mb-1.5">
                      {item.problem.description}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {formatDistanceToNow(item.problem.createdAt, { addSuffix: true })}
                      <span className="mx-1">•</span>
                      {item.solutions.length} solutions
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${
                    currentId === item.problem.id ? 'text-primary' : 'group-hover:translate-x-0.5'
                  }`} />
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
