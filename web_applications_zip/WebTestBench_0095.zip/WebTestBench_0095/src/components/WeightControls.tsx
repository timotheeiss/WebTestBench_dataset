import { RankingWeights } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Settings2 } from 'lucide-react';

interface WeightControlsProps {
  weights: RankingWeights;
  onChange: (weights: RankingWeights) => void;
}

const weightLabels: Record<keyof RankingWeights, { label: string; description: string }> = {
  availability: { 
    label: 'Availability', 
    description: 'Prioritize solutions marked as available' 
  },
  matchScore: { 
    label: 'Match Score', 
    description: 'How well the solution fits your problem' 
  },
  complexity: { 
    label: 'Simplicity', 
    description: 'Prefer simpler, easier-to-implement solutions' 
  },
  adaptability: { 
    label: 'Urgency Adaptability', 
    description: 'Solutions that work well under time pressure' 
  },
};

export function WeightControls({ weights, onChange }: WeightControlsProps) {
  const handleChange = (key: keyof RankingWeights, value: number[]) => {
    onChange({ ...weights, [key]: value[0] });
  };

  const total = Object.values(weights).reduce((sum, val) => sum + val, 0);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Settings2 className="w-4 h-4 text-primary" />
          Ranking Weights
        </CardTitle>
        <CardDescription className="text-xs">
          Customize how solutions are ranked. Total: {total}%
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {(Object.keys(weights) as Array<keyof RankingWeights>).map((key) => (
          <div key={key} className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">{weightLabels[key].label}</Label>
              <span className="text-sm font-mono text-muted-foreground">{weights[key]}%</span>
            </div>
            <Slider
              value={[weights[key]]}
              onValueChange={(val) => handleChange(key, val)}
              max={100}
              min={0}
              step={5}
              className="py-1"
            />
            <p className="text-xs text-muted-foreground">{weightLabels[key].description}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
