import { Solution, UrgencyLevel } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Gauge, Target, Zap } from 'lucide-react';

interface SolutionCardProps {
  solution: Solution;
  rank: number;
  score: number;
  urgency: UrgencyLevel;
  onToggleAvailability: () => void;
}

export function SolutionCard({ solution, rank, score, onToggleAvailability }: SolutionCardProps) {
  const complexityLabels = ['Very Easy', 'Easy', 'Moderate', 'Complex', 'Very Complex'];
  
  return (
    <Card className={`card-hover animate-slide-up transition-all duration-300 ${
      solution.isAvailable ? 'border-l-4 border-l-primary' : 'opacity-70'
    }`} style={{ animationDelay: `${rank * 50}ms` }}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4 flex-1">
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-semibold text-lg ${
              rank <= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}>
              {rank}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold text-foreground">{solution.title}</h3>
                {solution.isAvailable ? (
                  <CheckCircle2 className="w-4 h-4 text-[hsl(var(--success))]" />
                ) : (
                  <XCircle className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
              
              <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                {solution.description}
              </p>
              
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="text-xs gap-1">
                  <Target className="w-3 h-3" />
                  Match: {solution.matchScore}%
                </Badge>
                <Badge variant="outline" className="text-xs gap-1">
                  <Gauge className="w-3 h-3" />
                  {complexityLabels[solution.complexity - 1]}
                </Badge>
                <Badge variant="outline" className="text-xs gap-1">
                  <Zap className="w-3 h-3" />
                  Adapt: {solution.adaptability}%
                </Badge>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-3">
            <div className="text-right">
              <div className="text-2xl font-bold text-primary">{score}</div>
              <div className="text-xs text-muted-foreground">score</div>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Available</span>
              <Switch
                checked={solution.isAvailable}
                onCheckedChange={onToggleAvailability}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
