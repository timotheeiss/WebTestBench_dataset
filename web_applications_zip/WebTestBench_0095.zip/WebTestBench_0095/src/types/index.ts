export type ProblemCategory = 'technical' | 'business' | 'personal' | 'academic';
export type UrgencyLevel = 'low' | 'medium' | 'high';

export interface Problem {
  id: string;
  category: ProblemCategory;
  description: string;
  urgency: UrgencyLevel;
  createdAt: Date;
}

export interface Solution {
  id: string;
  problemId: string;
  title: string;
  description: string;
  matchScore: number; // 0-100 how well it matches the problem
  complexity: number; // 1-5, 1 being simplest
  adaptability: number; // 0-100 how well it adapts to urgency
  isAvailable: boolean;
}

export interface RankingWeights {
  availability: number;
  matchScore: number;
  complexity: number;
  adaptability: number;
}

export interface ProblemWithSolutions {
  problem: Problem;
  solutions: Solution[];
}
