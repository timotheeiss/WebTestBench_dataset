import { ProblemCategory, Solution } from '@/types';

interface SolutionTemplate {
  title: string;
  description: string;
  categories: ProblemCategory[];
  baseMatchScore: number;
  complexity: number;
  adaptability: number;
}

export const solutionTemplates: SolutionTemplate[] = [
  {
    title: "Break Down Into Smaller Tasks",
    description: "Divide the problem into manageable sub-tasks. This reduces overwhelm and makes progress measurable.",
    categories: ['technical', 'business', 'academic', 'personal'],
    baseMatchScore: 85,
    complexity: 1,
    adaptability: 90,
  },
  {
    title: "Seek Expert Consultation",
    description: "Connect with domain experts or mentors who have solved similar problems. Their experience can save significant time.",
    categories: ['technical', 'business', 'academic'],
    baseMatchScore: 80,
    complexity: 2,
    adaptability: 75,
  },
  {
    title: "Research Best Practices",
    description: "Study documented solutions and industry standards. Many problems have well-established approaches.",
    categories: ['technical', 'business', 'academic'],
    baseMatchScore: 75,
    complexity: 2,
    adaptability: 60,
  },
  {
    title: "Implement a Quick Prototype",
    description: "Build a minimal version to test assumptions quickly. Fail fast and learn faster.",
    categories: ['technical', 'business'],
    baseMatchScore: 88,
    complexity: 3,
    adaptability: 95,
  },
  {
    title: "Use Root Cause Analysis",
    description: "Apply the 5 Whys technique to identify the underlying cause rather than treating symptoms.",
    categories: ['technical', 'business', 'personal'],
    baseMatchScore: 82,
    complexity: 2,
    adaptability: 70,
  },
  {
    title: "Leverage Automation Tools",
    description: "Identify repetitive aspects that can be automated to free up time for creative problem-solving.",
    categories: ['technical', 'business'],
    baseMatchScore: 78,
    complexity: 4,
    adaptability: 85,
  },
  {
    title: "Collaborate with Peers",
    description: "Form a study group or brainstorming session. Different perspectives often reveal blind spots.",
    categories: ['academic', 'personal', 'business'],
    baseMatchScore: 76,
    complexity: 2,
    adaptability: 80,
  },
  {
    title: "Apply Time-Boxing",
    description: "Set strict time limits for exploration. Prevents analysis paralysis and forces decisive action.",
    categories: ['technical', 'business', 'academic', 'personal'],
    baseMatchScore: 70,
    complexity: 1,
    adaptability: 95,
  },
  {
    title: "Review Documentation & Resources",
    description: "Thoroughly check existing documentation, FAQs, and knowledge bases before reinventing solutions.",
    categories: ['technical', 'academic'],
    baseMatchScore: 72,
    complexity: 1,
    adaptability: 50,
  },
  {
    title: "Take a Strategic Break",
    description: "Step away temporarily. Fresh perspective after rest often leads to breakthrough insights.",
    categories: ['technical', 'personal', 'academic'],
    baseMatchScore: 65,
    complexity: 1,
    adaptability: 40,
  },
  {
    title: "Create a Decision Matrix",
    description: "List options and evaluate against weighted criteria. Makes complex decisions more objective.",
    categories: ['business', 'personal'],
    baseMatchScore: 80,
    complexity: 3,
    adaptability: 65,
  },
  {
    title: "Perform SWOT Analysis",
    description: "Assess Strengths, Weaknesses, Opportunities, and Threats to understand the full picture.",
    categories: ['business'],
    baseMatchScore: 85,
    complexity: 3,
    adaptability: 55,
  },
  {
    title: "Set Incremental Goals",
    description: "Define small, achievable milestones. Builds momentum and provides regular feedback loops.",
    categories: ['personal', 'academic', 'business'],
    baseMatchScore: 78,
    complexity: 1,
    adaptability: 85,
  },
  {
    title: "Practice Mindfulness",
    description: "Reduce stress through meditation or reflection. Clearer thinking leads to better solutions.",
    categories: ['personal'],
    baseMatchScore: 70,
    complexity: 1,
    adaptability: 60,
  },
];

export function generateSolutions(problemId: string, category: ProblemCategory): Solution[] {
  const relevantTemplates = solutionTemplates.filter(t => 
    t.categories.includes(category)
  );
  
  // Add some randomness to match scores to simulate real variation
  return relevantTemplates.map((template, index) => ({
    id: `${problemId}-solution-${index}`,
    problemId,
    title: template.title,
    description: template.description,
    matchScore: Math.min(100, template.baseMatchScore + Math.floor(Math.random() * 15) - 7),
    complexity: template.complexity,
    adaptability: template.adaptability,
    isAvailable: Math.random() > 0.3, // 70% chance of being available initially
  }));
}
