import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { formatDistanceToNow, format } from 'date-fns';
import { ArrowLeft, Clock, User, Edit3, History, AlertCircle, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Header } from '@/components/Header';
import { CommentSection } from '@/components/CommentSection';
import { RevisionHistory } from '@/components/RevisionHistory';
import { useApp } from '@/context/AppContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const SolutionDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getSolutionById, getUserById, currentUser, updateSolution, canViewRevisions } = useApp();
  
  const solution = getSolutionById(id || '');
  const author = solution ? getUserById(solution.authorId) : null;
  
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [explanation, setExplanation] = useState('');
  const [showRevisions, setShowRevisions] = useState(false);

  if (!solution) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Solution not found</h1>
          <Link to="/">
            <Button variant="outline">Back to Home</Button>
          </Link>
        </main>
      </div>
    );
  }

  const isOwner = solution.authorId === currentUser.id;
  const requiresExplanation = solution.editCount >= 3;

  const handleEdit = () => {
    setEditTitle(solution.title);
    setEditContent(solution.content);
    setExplanation('');
    setIsEditing(true);
  };

  const handleSaveEdit = () => {
    if (!editTitle.trim() || !editContent.trim()) return;
    if (requiresExplanation && !explanation.trim()) return;

    const success = updateSolution(
      solution.id, 
      editTitle.trim(), 
      editContent.trim(), 
      explanation.trim() || undefined
    );
    
    if (success) {
      setIsEditing(false);
      setEditTitle('');
      setEditContent('');
      setExplanation('');
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditTitle('');
    setEditContent('');
    setExplanation('');
  };

  // Simple markdown rendering
  const renderContent = (content: string) => {
    return content.split('\n').map((line, i) => {
      if (line.startsWith('## ')) {
        return <h2 key={i} className="text-xl font-semibold mt-6 mb-3">{line.slice(3)}</h2>;
      }
      if (line.startsWith('# ')) {
        return <h1 key={i} className="text-2xl font-bold mt-6 mb-4">{line.slice(2)}</h1>;
      }
      if (line.startsWith('```')) {
        return null; // Handle code blocks separately
      }
      if (line.startsWith('- ')) {
        return <li key={i} className="ml-4">{line.slice(2)}</li>;
      }
      if (line.match(/^\d+\. /)) {
        return <li key={i} className="ml-4 list-decimal">{line.replace(/^\d+\. /, '')}</li>;
      }
      if (line.trim() === '') {
        return <br key={i} />;
      }
      // Handle inline code
      const parts = line.split(/(`[^`]+`)/g);
      return (
        <p key={i} className="my-2">
          {parts.map((part, j) => {
            if (part.startsWith('`') && part.endsWith('`')) {
              return <code key={j} className="px-1.5 py-0.5 rounded bg-muted font-mono text-sm">{part.slice(1, -1)}</code>;
            }
            // Handle bold
            const boldParts = part.split(/(\*\*[^*]+\*\*)/g);
            return boldParts.map((bp, k) => {
              if (bp.startsWith('**') && bp.endsWith('**')) {
                return <strong key={`${j}-${k}`}>{bp.slice(2, -2)}</strong>;
              }
              return bp;
            });
          })}
        </p>
      );
    });
  };

  // Extract code blocks
  const renderContentWithCode = (content: string) => {
    const parts = content.split(/(```[\s\S]*?```)/g);
    return parts.map((part, i) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const lines = part.slice(3, -3).split('\n');
        const language = lines[0];
        const code = lines.slice(1).join('\n');
        return (
          <pre key={i} className="my-4 p-4 rounded-lg bg-foreground/5 border border-border overflow-x-auto">
            {language && (
              <div className="text-xs text-muted-foreground mb-2 font-mono">{language}</div>
            )}
            <code className="font-mono text-sm">{code}</code>
          </pre>
        );
      }
      return <div key={i}>{renderContent(part)}</div>;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 max-w-4xl">
        {/* Back button */}
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to solutions
        </Link>

        {/* Solution header */}
        <article className="animate-fade-in">
          {isEditing ? (
            <div className="space-y-4 mb-8">
              <Input
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                placeholder="Solution title"
                className="text-2xl font-bold h-auto py-3"
              />
              <Textarea
                value={editContent}
                onChange={e => setEditContent(e.target.value)}
                placeholder="Solution content (supports Markdown)"
                className="min-h-[400px] font-mono text-sm"
              />
              
              {requiresExplanation && (
                <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 text-warning">
                    <AlertCircle className="h-5 w-5" />
                    <span className="font-semibold">Explanation required</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    This solution has been edited 3+ times. Please explain your changes for admin review before they can be published.
                  </p>
                  <Textarea
                    placeholder="Why are you making this change?"
                    value={explanation}
                    onChange={e => setExplanation(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
              )}

              <div className="flex gap-3">
                <Button onClick={handleSaveEdit} disabled={!editTitle.trim() || !editContent.trim() || (requiresExplanation && !explanation.trim())}>
                  <Check className="h-4 w-4 mr-2" />
                  {requiresExplanation ? 'Submit for Review' : 'Save Changes'}
                </Button>
                <Button variant="outline" onClick={handleCancelEdit}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <>
              <header className="mb-8">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <h1 className="text-3xl font-bold tracking-tight">{solution.title}</h1>
                  {solution.updatedAt && (
                    <Badge variant="secondary" className="shrink-0 gap-1">
                      <Edit3 className="h-3 w-3" />
                      Updated {formatDistanceToNow(solution.updatedAt, { addSuffix: true })}
                    </Badge>
                  )}
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <User className="h-4 w-4" />
                    <span>{author?.name || 'Unknown'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" />
                    <span>{format(solution.createdAt, 'MMM d, yyyy')}</span>
                  </div>
                  <div className="flex gap-2">
                    {solution.tags.map(tag => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  {isOwner && (
                    <Button variant="outline" size="sm" onClick={handleEdit}>
                      <Edit3 className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  )}
                  {canViewRevisions(solution.authorId) && solution.revisions.length > 0 && (
                    <Button variant="outline" size="sm" onClick={() => setShowRevisions(true)}>
                      <History className="h-4 w-4 mr-2" />
                      Revision History ({solution.revisions.length})
                    </Button>
                  )}
                </div>
              </header>

              {/* Solution content */}
              <div className="prose prose-slate dark:prose-invert max-w-none mb-12">
                {renderContentWithCode(solution.content)}
              </div>
            </>
          )}

          {/* Comments section */}
          <section className="border-t border-border pt-8">
            <CommentSection solutionId={solution.id} />
          </section>
        </article>
      </main>

      {/* Revision history dialog */}
      <Dialog open={showRevisions} onOpenChange={setShowRevisions}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Revision History</DialogTitle>
            <DialogDescription>
              Previous versions of this solution
            </DialogDescription>
          </DialogHeader>
          <RevisionHistory revisions={solution.revisions} />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SolutionDetail;
