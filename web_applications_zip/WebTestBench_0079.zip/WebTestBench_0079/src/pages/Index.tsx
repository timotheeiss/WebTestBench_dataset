import { useState, useMemo } from 'react';
import { Search, Code2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/Header';
import { SolutionCard } from '@/components/SolutionCard';
import { useApp } from '@/context/AppContext';

const Index = () => {
  const { solutions } = useApp();
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    solutions.forEach(s => s.tags.forEach(t => tags.add(t)));
    return Array.from(tags).sort();
  }, [solutions]);

  const filteredSolutions = useMemo(() => {
    return solutions.filter(solution => {
      const matchesSearch = !search || 
        solution.title.toLowerCase().includes(search.toLowerCase()) ||
        solution.content.toLowerCase().includes(search.toLowerCase());
      const matchesTag = !selectedTag || solution.tags.includes(selectedTag);
      return matchesSearch && matchesTag;
    });
  }, [solutions, search, selectedTag]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="border-b border-border bg-gradient-to-b from-primary/5 to-transparent">
        <div className="container py-12 md:py-16">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <div className="flex items-center justify-center gap-2 text-primary mb-4">
              <Code2 className="h-8 w-8" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
              Find Solutions to
              <span className="text-gradient"> Technical Problems</span>
            </h1>
            <p className="text-muted-foreground text-lg">
              A community-driven platform for sharing and discovering solutions to common technical challenges.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="border-b border-border sticky top-16 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-40">
        <div className="container py-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search solutions..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge 
                variant={selectedTag === null ? 'default' : 'outline'}
                className="cursor-pointer"
                onClick={() => setSelectedTag(null)}
              >
                All
              </Badge>
              {allTags.map(tag => (
                <Badge 
                  key={tag}
                  variant={selectedTag === tag ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setSelectedTag(tag === selectedTag ? null : tag)}
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Grid */}
      <main className="container py-8">
        {filteredSolutions.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No solutions found matching your criteria.</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredSolutions.map(solution => (
              <SolutionCard key={solution.id} solution={solution} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Index;
