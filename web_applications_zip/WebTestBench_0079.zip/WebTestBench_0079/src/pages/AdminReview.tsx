import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { ArrowLeft, Check, X, FileText, MessageSquare, Clock, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/Header';
import { useApp } from '@/context/AppContext';

const AdminReview = () => {
  const { currentUser, pendingEdits, approvePendingEdit, rejectPendingEdit, getUserById, getSolutionById, comments } = useApp();

  if (!currentUser.isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You need admin privileges to view this page.</p>
          <Link to="/">
            <Button variant="outline">Back to Home</Button>
          </Link>
        </main>
      </div>
    );
  }

  const pendingItems = pendingEdits.filter(e => e.status === 'pending');
  const reviewedItems = pendingEdits.filter(e => e.status !== 'pending');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 max-w-4xl">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to solutions
        </Link>

        <div className="animate-fade-in">
          <h1 className="text-3xl font-bold tracking-tight mb-2">Review Queue</h1>
          <p className="text-muted-foreground mb-8">
            Review and approve content modifications that require admin approval.
          </p>

          {/* Pending reviews */}
          <section className="mb-12">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              Pending Reviews
              <Badge>{pendingItems.length}</Badge>
            </h2>

            {pendingItems.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">No pending reviews at this time.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {pendingItems.map(edit => {
                  const author = getUserById(edit.authorId);
                  const target = edit.targetType === 'solution' 
                    ? getSolutionById(edit.targetId)
                    : comments.find(c => c.id === edit.targetId);

                  return (
                    <Card key={edit.id} className="animate-fade-in">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <CardTitle className="text-lg flex items-center gap-2">
                              {edit.targetType === 'solution' ? (
                                <FileText className="h-5 w-5 text-primary" />
                              ) : (
                                <MessageSquare className="h-5 w-5 text-primary" />
                              )}
                              {edit.targetType === 'solution' ? 'Solution Edit' : 'Comment Edit'}
                            </CardTitle>
                            <CardDescription className="flex items-center gap-4">
                              <span className="flex items-center gap-1">
                                <User className="h-3 w-3" />
                                {author?.name || 'Unknown'}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {format(edit.timestamp, 'MMM d, yyyy h:mm a')}
                              </span>
                            </CardDescription>
                          </div>
                          <Badge variant="secondary">Pending</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {edit.newTitle && (
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">New Title</p>
                            <p className="font-medium">{edit.newTitle}</p>
                          </div>
                        )}
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">New Content</p>
                          <div className="p-3 rounded-lg bg-muted/50 border border-border text-sm max-h-40 overflow-y-auto whitespace-pre-wrap">
                            {edit.newContent}
                          </div>
                        </div>
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                          <p className="text-xs text-primary font-medium mb-1">Author's Explanation</p>
                          <p className="text-sm">{edit.explanation}</p>
                        </div>
                      </CardContent>
                      <CardFooter className="gap-2">
                        <Button onClick={() => approvePendingEdit(edit.id)} className="gap-2">
                          <Check className="h-4 w-4" />
                          Approve
                        </Button>
                        <Button variant="outline" onClick={() => rejectPendingEdit(edit.id)} className="gap-2">
                          <X className="h-4 w-4" />
                          Reject
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </section>

          {/* Review history */}
          {reviewedItems.length > 0 && (
            <section>
              <h2 className="text-xl font-semibold mb-4">Review History</h2>
              <div className="space-y-3">
                {reviewedItems.map(edit => {
                  const author = getUserById(edit.authorId);
                  return (
                    <div key={edit.id} className="flex items-center justify-between p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center gap-3">
                        {edit.targetType === 'solution' ? (
                          <FileText className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        )}
                        <div>
                          <p className="text-sm font-medium">
                            {edit.targetType === 'solution' ? 'Solution' : 'Comment'} edit by {author?.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {format(edit.timestamp, 'MMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                      <Badge variant={edit.status === 'approved' ? 'default' : 'destructive'}>
                        {edit.status === 'approved' ? 'Approved' : 'Rejected'}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminReview;
