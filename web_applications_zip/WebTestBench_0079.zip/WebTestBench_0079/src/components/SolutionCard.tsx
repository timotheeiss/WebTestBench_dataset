import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { MessageSquare, Clock, User, Edit3 } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/context/AppContext';
import { Solution } from '@/types';

interface SolutionCardProps {
  solution: Solution;
}

export function SolutionCard({ solution }: SolutionCardProps) {
  const { getUserById, getCommentsBySolution } = useApp();
  const author = getUserById(solution.authorId);
  const comments = getCommentsBySolution(solution.id);

  return (
    <Link to={`/solution/${solution.id}`}>
      <Card className="glass-card hover-lift cursor-pointer group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <CardTitle className="text-lg font-semibold leading-tight group-hover:text-primary transition-colors line-clamp-2">
              {solution.title}
            </CardTitle>
            {solution.updatedAt && (
              <Badge variant="secondary" className="shrink-0 gap-1 text-xs">
                <Edit3 className="h-3 w-3" />
                Updated
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="pb-3">
          <p className="text-muted-foreground text-sm line-clamp-3">
            {solution.content.replace(/[#`*_\[\]]/g, '').substring(0, 200)}...
          </p>
          <div className="flex flex-wrap gap-2 mt-3">
            {solution.tags.map(tag => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
        <CardFooter className="pt-3 border-t border-border/50 text-sm text-muted-foreground">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <User className="h-3.5 w-3.5" />
                <span>{author?.name || 'Unknown'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />
                <span>{formatDistanceToNow(solution.createdAt, { addSuffix: true })}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <MessageSquare className="h-3.5 w-3.5" />
              <span>{comments.length}</span>
            </div>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
