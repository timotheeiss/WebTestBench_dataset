import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { Revision } from '@/types';
import { useApp } from '@/context/AppContext';

interface RevisionHistoryProps {
  revisions: Revision[];
}

export function RevisionHistory({ revisions }: RevisionHistoryProps) {
  const { getUserById } = useApp();

  if (revisions.length === 0) {
    return (
      <p className="text-muted-foreground text-sm text-center py-4">
        No revision history available.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {revisions.slice().reverse().map((revision, index) => {
        const author = getUserById(revision.authorId);
        return (
          <div 
            key={revision.id} 
            className="p-4 rounded-lg border border-border bg-muted/30 space-y-2"
          >
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">
                Revision {revisions.length - index}
              </span>
              <span className="text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {format(revision.timestamp, 'MMM d, yyyy h:mm a')}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              by {author?.name || 'Unknown'}
            </p>
            {revision.title && (
              <div className="pt-2 border-t border-border/50">
                <p className="text-xs text-muted-foreground mb-1">Title:</p>
                <p className="text-sm font-medium">{revision.title}</p>
              </div>
            )}
            <div className="pt-2 border-t border-border/50">
              <p className="text-xs text-muted-foreground mb-1">Content:</p>
              <p className="text-sm whitespace-pre-wrap line-clamp-6">
                {revision.content}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
