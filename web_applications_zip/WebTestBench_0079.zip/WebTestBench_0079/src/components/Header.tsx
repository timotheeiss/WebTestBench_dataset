import { Link, useLocation } from 'react-router-dom';
import { Code2, Plus, Shield, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useApp } from '@/context/AppContext';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export function Header() {
  const location = useLocation();
  const { currentUser, setCurrentUser, users, pendingEdits } = useApp();
  
  const pendingCount = pendingEdits.filter(e => e.status === 'pending').length;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Code2 className="h-5 w-5" />
          </div>
          <span className="text-xl font-semibold tracking-tight">SolveHub</span>
        </Link>

        <nav className="flex items-center gap-4">
          {location.pathname !== '/create' && (
            <Link to="/create">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Solution
              </Button>
            </Link>
          )}

          {currentUser.isAdmin && (
            <Link to="/admin">
              <Button variant="outline" className="gap-2 relative">
                <Shield className="h-4 w-4" />
                Review
                {pendingCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
                    {pendingCount}
                  </span>
                )}
              </Button>
            </Link>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2 px-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary/10 text-primary text-sm">
                    {currentUser.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden sm:inline">{currentUser.name}</span>
                {currentUser.isAdmin && (
                  <Shield className="h-3 w-3 text-primary" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Switch User</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {users.map(u => (
                <DropdownMenuItem 
                  key={u.id}
                  onClick={() => setCurrentUser(u)}
                  className="gap-2 cursor-pointer"
                >
                  <User className="h-4 w-4" />
                  {u.name}
                  {u.isAdmin && <Shield className="h-3 w-3 text-primary ml-auto" />}
                  {u.id === currentUser.id && (
                    <span className="ml-auto text-xs text-muted-foreground">Current</span>
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </div>
    </header>
  );
}
