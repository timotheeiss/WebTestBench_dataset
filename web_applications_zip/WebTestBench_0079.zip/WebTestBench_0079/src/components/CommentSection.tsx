import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { User, Clock, Edit3, History, Send, X, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useApp } from '@/context/AppContext';
import { Comment } from '@/types';
import { RevisionHistory } from './RevisionHistory';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface CommentSectionProps {
  solutionId: string;
}

export function CommentSection({ solutionId }: CommentSectionProps) {
  const { currentUser, getCommentsBySolution, addComment, updateComment, getUserById, canViewRevisions } = useApp();
  const comments = getCommentsBySolution(solutionId);
  const [newComment, setNewComment] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [showRevisions, setShowRevisions] = useState<string | null>(null);
  const [requiresExplanation, setRequiresExplanation] = useState(false);
  const [explanation, setExplanation] = useState('');

  const handleSubmit = () => {
    if (!newComment.trim()) return;
    addComment(solutionId, newComment.trim());
    setNewComment('');
  };

  const handleEdit = (comment: Comment) => {
    setEditingId(comment.id);
    setEditContent(comment.content);
    setRequiresExplanation(comment.editCount >= 3);
    setExplanation('');
  };

  const handleSaveEdit = () => {
    if (!editContent.trim() || !editingId) return;
    
    const comment = comments.find(c => c.id === editingId);
    if (comment && comment.editCount >= 3 && !explanation.trim()) {
      return;
    }
    
    const success = updateComment(editingId, editContent.trim(), explanation.trim() || undefined);
    if (success) {
      setEditingId(null);
      setEditContent('');
      setRequiresExplanation(false);
      setExplanation('');
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditContent('');
    setRequiresExplanation(false);
    setExplanation('');
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        Comments
        <Badge variant="secondary">{comments.length}</Badge>
      </h3>

      {/* Add comment form */}
      <div className="flex gap-3">
        <Avatar className="h-10 w-10 shrink-0">
          <AvatarFallback className="bg-primary/10 text-primary text-sm">
            {currentUser.name.split(' ').map(n => n[0]).join('')}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <Textarea
            placeholder="Add a comment..."
            value={newComment}
            onChange={e => setNewComment(e.target.value)}
            className="min-h-[80px] resize-none"
          />
          <div className="flex justify-end">
            <Button onClick={handleSubmit} disabled={!newComment.trim()} className="gap-2">
              <Send className="h-4 w-4" />
              Comment
            </Button>
          </div>
        </div>
      </div>

      {/* Comments list */}
      <div className="space-y-4">
        {comments.map(comment => {
          const author = getUserById(comment.authorId);
          const isOwner = comment.authorId === currentUser.id;
          const isEditing = editingId === comment.id;

          return (
            <div key={comment.id} className="flex gap-3 animate-fade-in">
              <Avatar className="h-10 w-10 shrink-0">
                <AvatarFallback className="bg-muted text-muted-foreground text-sm">
                  {author?.name.split(' ').map(n => n[0]).join('') || '?'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm">{author?.name || 'Unknown'}</span>
                  <span className="text-muted-foreground text-xs flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDistanceToNow(comment.createdAt, { addSuffix: true })}
                  </span>
                  {comment.updatedAt && (
                    <Badge variant="secondary" className="text-xs gap-1">
                      <Edit3 className="h-3 w-3" />
                      Edited
                    </Badge>
                  )}
                </div>

                {isEditing ? (
                  <div className="space-y-3">
                    <Textarea
                      value={editContent}
                      onChange={e => setEditContent(e.target.value)}
                      className="min-h-[80px] resize-none"
                    />
                    {requiresExplanation && (
                      <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg space-y-2">
                        <div className="flex items-center gap-2 text-sm text-warning">
                          <AlertCircle className="h-4 w-4" />
                          <span className="font-medium">Explanation required</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          This comment has been edited 3+ times. Please explain your changes for admin review.
                        </p>
                        <Textarea
                          placeholder="Why are you making this change?"
                          value={explanation}
                          onChange={e => setExplanation(e.target.value)}
                          className="min-h-[60px] resize-none"
                        />
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveEdit} disabled={!editContent.trim() || (requiresExplanation && !explanation.trim())}>
                        {requiresExplanation ? 'Submit for Review' : 'Save'}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={handleCancelEdit}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-sm text-foreground/90 whitespace-pre-wrap">
                      {comment.content}
                    </p>
                    <div className="flex items-center gap-2">
                      {isOwner && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => handleEdit(comment)}>
                          <Edit3 className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                      )}
                      {canViewRevisions(comment.authorId) && comment.revisions.length > 0 && (
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-7 px-2 text-xs"
                          onClick={() => setShowRevisions(comment.id)}
                        >
                          <History className="h-3 w-3 mr-1" />
                          History ({comment.revisions.length})
                        </Button>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Revision history dialog */}
      <Dialog open={!!showRevisions} onOpenChange={() => setShowRevisions(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Revision History</DialogTitle>
            <DialogDescription>
              Previous versions of this comment
            </DialogDescription>
          </DialogHeader>
          {showRevisions && (
            <RevisionHistory 
              revisions={comments.find(c => c.id === showRevisions)?.revisions || []} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
