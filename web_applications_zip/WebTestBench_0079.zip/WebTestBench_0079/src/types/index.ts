export interface User {
  id: string;
  name: string;
  avatar?: string;
  isAdmin: boolean;
}

export interface Revision {
  id: string;
  content: string;
  title?: string;
  timestamp: Date;
  authorId: string;
}

export interface PendingEdit {
  id: string;
  targetId: string;
  targetType: 'solution' | 'comment';
  newContent: string;
  newTitle?: string;
  explanation: string;
  authorId: string;
  timestamp: Date;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Comment {
  id: string;
  solutionId: string;
  content: string;
  authorId: string;
  createdAt: Date;
  updatedAt?: Date;
  revisions: Revision[];
  editCount: number;
}

export interface Solution {
  id: string;
  title: string;
  content: string;
  authorId: string;
  createdAt: Date;
  updatedAt?: Date;
  revisions: Revision[];
  editCount: number;
  tags: string[];
}

export interface AppState {
  currentUser: User;
  users: User[];
  solutions: Solution[];
  comments: Comment[];
  pendingEdits: PendingEdit[];
}
