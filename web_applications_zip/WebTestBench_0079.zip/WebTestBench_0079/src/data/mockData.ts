import { User, Solution, Comment, PendingEdit } from '@/types';

export const mockUsers: User[] = [
  { id: 'user-1', name: 'Alex Chen', isAdmin: false },
  { id: 'user-2', name: 'Sarah Kim', isAdmin: false },
  { id: 'user-3', name: 'Marcus Johnson', isAdmin: true },
  { id: 'user-4', name: 'Emily Davis', isAdmin: false },
];

export const mockSolutions: Solution[] = [
  {
    id: 'sol-1',
    title: 'How to fix "Cannot read properties of undefined" in React',
    content: `This error typically occurs when you're trying to access a property on an object that hasn't been initialized yet.

## Common Causes

1. **Async data not loaded yet**: When fetching data, the initial state is often undefined
2. **Incorrect prop passing**: Parent component might not be passing the expected props
3. **Typos in property names**: Simple spelling mistakes

## Solution

Use optional chaining and nullish coalescing:

\`\`\`javascript
// Instead of this
const name = user.profile.name;

// Do this
const name = user?.profile?.name ?? 'Default Name';
\`\`\`

Also consider adding loading states:

\`\`\`javascript
if (!data) return <Loading />;
return <Component data={data} />;
\`\`\``,
    authorId: 'user-1',
    createdAt: new Date('2024-01-10T10:30:00'),
    updatedAt: new Date('2024-01-11T14:20:00'),
    revisions: [
      {
        id: 'rev-1',
        title: 'How to fix "Cannot read properties of undefined" in React',
        content: 'This error occurs when accessing undefined properties. Use optional chaining.',
        timestamp: new Date('2024-01-10T10:30:00'),
        authorId: 'user-1',
      },
    ],
    editCount: 1,
    tags: ['React', 'JavaScript', 'Debugging'],
  },
  {
    id: 'sol-2',
    title: 'Optimizing PostgreSQL queries with proper indexing',
    content: `Slow database queries can cripple your application. Here's how to identify and fix them with indexes.

## Identifying Slow Queries

Use \`EXPLAIN ANALYZE\` to understand query execution:

\`\`\`sql
EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'test@example.com';
\`\`\`

## Creating Effective Indexes

For frequently queried columns:

\`\`\`sql
CREATE INDEX idx_users_email ON users(email);
\`\`\`

For composite queries:

\`\`\`sql
CREATE INDEX idx_orders_user_date ON orders(user_id, created_at DESC);
\`\`\`

## Best Practices

- Don't over-index: each index slows down writes
- Use partial indexes for filtered queries
- Consider covering indexes for read-heavy tables`,
    authorId: 'user-2',
    createdAt: new Date('2024-01-12T09:15:00'),
    revisions: [],
    editCount: 0,
    tags: ['PostgreSQL', 'Database', 'Performance'],
  },
  {
    id: 'sol-3',
    title: 'Setting up Docker containers for local development',
    content: `A consistent development environment eliminates "works on my machine" issues.

## Basic docker-compose.yml

\`\`\`yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    volumes:
      - .:/app
      - /app/node_modules
    environment:
      - NODE_ENV=development
  
  db:
    image: postgres:15
    environment:
      POSTGRES_PASSWORD: devpassword
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
\`\`\`

## Key Tips

1. Use volumes for hot-reload during development
2. Separate node_modules to avoid platform issues
3. Use named volumes for database persistence`,
    authorId: 'user-3',
    createdAt: new Date('2024-01-14T16:45:00'),
    revisions: [],
    editCount: 0,
    tags: ['Docker', 'DevOps', 'Development'],
  },
];

export const mockComments: Comment[] = [
  {
    id: 'comment-1',
    solutionId: 'sol-1',
    content: 'This helped me solve my issue! The optional chaining tip was exactly what I needed.',
    authorId: 'user-2',
    createdAt: new Date('2024-01-10T14:30:00'),
    revisions: [],
    editCount: 0,
  },
  {
    id: 'comment-2',
    solutionId: 'sol-1',
    content: 'You should also mention using TypeScript for compile-time checks. It catches these errors before runtime.',
    authorId: 'user-3',
    createdAt: new Date('2024-01-10T15:45:00'),
    updatedAt: new Date('2024-01-10T16:00:00'),
    revisions: [
      {
        id: 'crev-1',
        content: 'Also consider TypeScript.',
        timestamp: new Date('2024-01-10T15:45:00'),
        authorId: 'user-3',
      },
    ],
    editCount: 1,
  },
  {
    id: 'comment-3',
    solutionId: 'sol-2',
    content: 'Great explanation! Would love to see a follow-up about query planners.',
    authorId: 'user-4',
    createdAt: new Date('2024-01-12T11:20:00'),
    revisions: [],
    editCount: 0,
  },
];

export const mockPendingEdits: PendingEdit[] = [
  {
    id: 'pending-1',
    targetId: 'sol-1',
    targetType: 'solution',
    newTitle: 'How to fix "Cannot read properties of undefined" in React - Complete Guide',
    newContent: 'Updated comprehensive guide...',
    explanation: 'Adding more detailed examples and edge cases based on community feedback.',
    authorId: 'user-1',
    timestamp: new Date('2024-01-15T10:00:00'),
    status: 'pending',
  },
];

export const currentUser = mockUsers[0]; // Alex Chen is the default logged-in user
