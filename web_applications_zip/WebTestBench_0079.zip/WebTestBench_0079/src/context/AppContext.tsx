import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { User, Solution, Comment, PendingEdit, Revision } from '@/types';
import { mockUsers, mockSolutions, mockComments, mockPendingEdits, currentUser } from '@/data/mockData';

interface AppContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  users: User[];
  solutions: Solution[];
  comments: Comment[];
  pendingEdits: PendingEdit[];
  addSolution: (title: string, content: string, tags: string[]) => Solution;
  updateSolution: (id: string, title: string, content: string, explanation?: string) => boolean;
  addComment: (solutionId: string, content: string) => Comment;
  updateComment: (id: string, content: string, explanation?: string) => boolean;
  getCommentsBySolution: (solutionId: string) => Comment[];
  getSolutionById: (id: string) => Solution | undefined;
  getUserById: (id: string) => User | undefined;
  approvePendingEdit: (editId: string) => void;
  rejectPendingEdit: (editId: string) => void;
  canViewRevisions: (authorId: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(currentUser);
  const [users] = useState<User[]>(mockUsers);
  const [solutions, setSolutions] = useState<Solution[]>(mockSolutions);
  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [pendingEdits, setPendingEdits] = useState<PendingEdit[]>(mockPendingEdits);

  const addSolution = useCallback((title: string, content: string, tags: string[]) => {
    const newSolution: Solution = {
      id: `sol-${Date.now()}`,
      title,
      content,
      authorId: user.id,
      createdAt: new Date(),
      revisions: [],
      editCount: 0,
      tags,
    };
    setSolutions(prev => [newSolution, ...prev]);
    return newSolution;
  }, [user.id]);

  const updateSolution = useCallback((id: string, title: string, content: string, explanation?: string): boolean => {
    const solution = solutions.find(s => s.id === id);
    if (!solution || solution.authorId !== user.id) return false;

    if (solution.editCount >= 3) {
      if (!explanation) return false;
      
      const pendingEdit: PendingEdit = {
        id: `pending-${Date.now()}`,
        targetId: id,
        targetType: 'solution',
        newTitle: title,
        newContent: content,
        explanation,
        authorId: user.id,
        timestamp: new Date(),
        status: 'pending',
      };
      setPendingEdits(prev => [...prev, pendingEdit]);
      return true;
    }

    const revision: Revision = {
      id: `rev-${Date.now()}`,
      title: solution.title,
      content: solution.content,
      timestamp: new Date(),
      authorId: user.id,
    };

    setSolutions(prev => prev.map(s => 
      s.id === id 
        ? { 
            ...s, 
            title, 
            content, 
            updatedAt: new Date(), 
            revisions: [...s.revisions, revision],
            editCount: s.editCount + 1,
          }
        : s
    ));
    return true;
  }, [solutions, user.id]);

  const addComment = useCallback((solutionId: string, content: string) => {
    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      solutionId,
      content,
      authorId: user.id,
      createdAt: new Date(),
      revisions: [],
      editCount: 0,
    };
    setComments(prev => [...prev, newComment]);
    return newComment;
  }, [user.id]);

  const updateComment = useCallback((id: string, content: string, explanation?: string): boolean => {
    const comment = comments.find(c => c.id === id);
    if (!comment || comment.authorId !== user.id) return false;

    if (comment.editCount >= 3) {
      if (!explanation) return false;
      
      const pendingEdit: PendingEdit = {
        id: `pending-${Date.now()}`,
        targetId: id,
        targetType: 'comment',
        newContent: content,
        explanation,
        authorId: user.id,
        timestamp: new Date(),
        status: 'pending',
      };
      setPendingEdits(prev => [...prev, pendingEdit]);
      return true;
    }

    const revision: Revision = {
      id: `crev-${Date.now()}`,
      content: comment.content,
      timestamp: new Date(),
      authorId: user.id,
    };

    setComments(prev => prev.map(c => 
      c.id === id 
        ? { 
            ...c, 
            content, 
            updatedAt: new Date(), 
            revisions: [...c.revisions, revision],
            editCount: c.editCount + 1,
          }
        : c
    ));
    return true;
  }, [comments, user.id]);

  const getCommentsBySolution = useCallback((solutionId: string) => {
    return comments.filter(c => c.solutionId === solutionId);
  }, [comments]);

  const getSolutionById = useCallback((id: string) => {
    return solutions.find(s => s.id === id);
  }, [solutions]);

  const getUserById = useCallback((id: string) => {
    return users.find(u => u.id === id);
  }, [users]);

  const approvePendingEdit = useCallback((editId: string) => {
    const edit = pendingEdits.find(e => e.id === editId);
    if (!edit || !user.isAdmin) return;

    if (edit.targetType === 'solution') {
      const solution = solutions.find(s => s.id === edit.targetId);
      if (solution) {
        const revision: Revision = {
          id: `rev-${Date.now()}`,
          title: solution.title,
          content: solution.content,
          timestamp: new Date(),
          authorId: edit.authorId,
        };

        setSolutions(prev => prev.map(s => 
          s.id === edit.targetId 
            ? { 
                ...s, 
                title: edit.newTitle || s.title, 
                content: edit.newContent, 
                updatedAt: new Date(), 
                revisions: [...s.revisions, revision],
                editCount: s.editCount + 1,
              }
            : s
        ));
      }
    } else {
      const comment = comments.find(c => c.id === edit.targetId);
      if (comment) {
        const revision: Revision = {
          id: `crev-${Date.now()}`,
          content: comment.content,
          timestamp: new Date(),
          authorId: edit.authorId,
        };

        setComments(prev => prev.map(c => 
          c.id === edit.targetId 
            ? { 
                ...c, 
                content: edit.newContent, 
                updatedAt: new Date(), 
                revisions: [...c.revisions, revision],
                editCount: c.editCount + 1,
              }
            : c
        ));
      }
    }

    setPendingEdits(prev => prev.map(e => 
      e.id === editId ? { ...e, status: 'approved' as const } : e
    ));
  }, [pendingEdits, user.isAdmin, solutions, comments]);

  const rejectPendingEdit = useCallback((editId: string) => {
    if (!user.isAdmin) return;
    setPendingEdits(prev => prev.map(e => 
      e.id === editId ? { ...e, status: 'rejected' as const } : e
    ));
  }, [user.isAdmin]);

  const canViewRevisions = useCallback((authorId: string) => {
    return user.isAdmin || user.id === authorId;
  }, [user]);

  return (
    <AppContext.Provider value={{
      currentUser: user,
      setCurrentUser: setUser,
      users,
      solutions,
      comments,
      pendingEdits,
      addSolution,
      updateSolution,
      addComment,
      updateComment,
      getCommentsBySolution,
      getSolutionById,
      getUserById,
      approvePendingEdit,
      rejectPendingEdit,
      canViewRevisions,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
