import { useState } from 'react';
import { format, parseISO, isPast } from 'date-fns';
import { Calendar, Clock, Users, MapPin, Edit2, X, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Reservation, restaurants } from '@/data/restaurants';
import { useReservations } from '@/context/ReservationContext';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ReservationCardProps {
  reservation: Reservation;
}

export function ReservationCard({ reservation }: ReservationCardProps) {
  const restaurant = restaurants.find(r => r.id === reservation.restaurantId);
  const { updateReservation, cancelReservation } = useReservations();
  const { toast } = useToast();
  const [isModifyOpen, setIsModifyOpen] = useState(false);
  const [newTime, setNewTime] = useState(reservation.time);
  const [newPartySize, setNewPartySize] = useState(reservation.partySize.toString());

  if (!restaurant) return null;

  const reservationDate = parseISO(reservation.date);
  const isUpcoming = !isPast(reservationDate) && reservation.status !== 'cancelled';
  const isCancelled = reservation.status === 'cancelled';

  const handleModify = () => {
    updateReservation(reservation.id, {
      time: newTime,
      partySize: parseInt(newPartySize),
    });
    toast({
      title: 'Reservation Updated',
      description: 'Your reservation has been modified successfully.',
    });
    setIsModifyOpen(false);
  };

  const handleCancel = () => {
    cancelReservation(reservation.id);
    toast({
      title: 'Reservation Cancelled',
      description: 'Your reservation has been cancelled.',
    });
  };

  return (
    <div
      className={cn(
        'rounded-xl border bg-card overflow-hidden transition-all',
        isCancelled && 'opacity-60'
      )}
    >
      <div className="flex flex-col sm:flex-row">
        <div className="sm:w-48 h-32 sm:h-auto">
          <img
            src={restaurant.image}
            alt={restaurant.name}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="flex-1 p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-semibold">{restaurant.name}</h3>
              <p className="text-sm text-muted-foreground">
                {restaurant.cuisine} · {restaurant.priceRange}
              </p>
            </div>
            <span
              className={cn(
                'text-xs font-medium px-2.5 py-1 rounded-full',
                isCancelled
                  ? 'bg-destructive/10 text-destructive'
                  : isUpcoming
                  ? 'bg-primary/10 text-primary'
                  : 'bg-muted text-muted-foreground'
              )}
            >
              {isCancelled ? 'Cancelled' : isUpcoming ? 'Upcoming' : 'Completed'}
            </span>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>{format(reservationDate, 'MMMM d, yyyy')}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>{reservation.time}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{reservation.partySize} {reservation.partySize === 1 ? 'Guest' : 'Guests'}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{restaurant.neighborhood}</span>
            </div>
          </div>

          {reservation.couponCode && (
            <div className="mt-3 flex items-center gap-2 text-sm text-primary">
              <Tag className="h-4 w-4" />
              <span>Coupon applied: {reservation.couponCode}</span>
            </div>
          )}

          {isUpcoming && !isCancelled && (
            <div className="mt-4 flex gap-2">
              <Dialog open={isModifyOpen} onOpenChange={setIsModifyOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Edit2 className="h-4 w-4 mr-1.5" />
                    Modify
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Modify Reservation</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label>New Time</Label>
                      <Select value={newTime} onValueChange={setNewTime}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {restaurant.availableTimes.map(t => (
                            <SelectItem key={t} value={t}>
                              {t}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Party Size</Label>
                      <Select value={newPartySize} onValueChange={setNewPartySize}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(size => (
                            <SelectItem key={size} value={size.toString()}>
                              {size} {size === 1 ? 'Guest' : 'Guests'}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleModify} className="w-full">
                      Save Changes
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
                    <X className="h-4 w-4 mr-1.5" />
                    Cancel
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancel Reservation?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. Your reservation at {restaurant.name} will be cancelled.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Keep Reservation</AlertDialogCancel>
                    <AlertDialogAction onClick={handleCancel} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Cancel Reservation
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
