import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Annotation, initialAnnotations } from '@/data/manualData';

export type ActiveSection = 'selection' | 'comparison' | 'annotations';

interface AppState {
  // Navigation
  activeSection: ActiveSection;
  setActiveSection: (section: ActiveSection) => void;

  // Version Selection
  selectedProductId: string | null;
  selectedVersionIds: string[];
  setSelectedProductId: (id: string | null) => void;
  setSelectedVersionIds: (ids: string[]) => void;
  toggleVersionSelection: (id: string) => void;

  // Chapter Expansion
  expandedChapters: Record<string, boolean>;
  syncExpansion: boolean;
  toggleChapter: (chapterId: string, versionId?: string) => void;
  setSyncExpansion: (sync: boolean) => void;
  expandAll: () => void;
  collapseAll: () => void;

  // Search
  searchKeyword: string;
  setSearchKeyword: (keyword: string) => void;
  searchMatchIndex: number;
  setSearchMatchIndex: (index: number) => void;

  // Scroll & Display
  scrollLock: boolean;
  diffMode: boolean;
  setScrollLock: (lock: boolean) => void;
  setDiffMode: (mode: boolean) => void;

  // Annotations
  annotations: Annotation[];
  addAnnotation: (annotation: Omit<Annotation, 'id' | 'createdAt'>) => void;
  removeAnnotation: (id: string) => void;
  updateAnnotation: (id: string, text: string) => void;

  // Filter for annotations
  annotationFilter: string;
  setAnnotationFilter: (filter: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Navigation
      activeSection: 'selection',
      setActiveSection: (section) => set({ activeSection: section }),

      // Version Selection
      selectedProductId: null,
      selectedVersionIds: [],
      setSelectedProductId: (id) => set({ selectedProductId: id, selectedVersionIds: [] }),
      setSelectedVersionIds: (ids) => set({ selectedVersionIds: ids }),
      toggleVersionSelection: (id) => {
        const current = get().selectedVersionIds;
        if (current.includes(id)) {
          set({ selectedVersionIds: current.filter(v => v !== id) });
        } else if (current.length < 3) {
          set({ selectedVersionIds: [...current, id] });
        }
      },

      // Chapter Expansion
      expandedChapters: {},
      syncExpansion: true,
      toggleChapter: (chapterId, versionId) => {
        const { expandedChapters, syncExpansion } = get();
        const key = syncExpansion ? chapterId : `${versionId}-${chapterId}`;
        set({
          expandedChapters: {
            ...expandedChapters,
            [key]: !expandedChapters[key]
          }
        });
      },
      setSyncExpansion: (sync) => set({ syncExpansion: sync }),
      expandAll: () => set({ expandedChapters: {} }),
      collapseAll: () => set({ expandedChapters: {} }),

      // Search
      searchKeyword: '',
      setSearchKeyword: (keyword) => set({ searchKeyword: keyword, searchMatchIndex: 0 }),
      searchMatchIndex: 0,
      setSearchMatchIndex: (index) => set({ searchMatchIndex: index }),

      // Scroll & Display
      scrollLock: false,
      diffMode: false,
      setScrollLock: (lock) => set({ scrollLock: lock }),
      setDiffMode: (mode) => set({ diffMode: mode }),

      // Annotations
      annotations: initialAnnotations,
      addAnnotation: (annotation) => {
        const newAnnotation: Annotation = {
          ...annotation,
          id: `ann-${Date.now()}`,
          createdAt: new Date().toISOString()
        };
        set({ annotations: [...get().annotations, newAnnotation] });
      },
      removeAnnotation: (id) => {
        set({ annotations: get().annotations.filter(a => a.id !== id) });
      },
      updateAnnotation: (id, text) => {
        set({
          annotations: get().annotations.map(a =>
            a.id === id ? { ...a, text } : a
          )
        });
      },

      // Filter
      annotationFilter: '',
      setAnnotationFilter: (filter) => set({ annotationFilter: filter }),
    }),
    {
      name: 'manual-comparison-store',
      partialize: (state) => ({
        selectedProductId: state.selectedProductId,
        selectedVersionIds: state.selectedVersionIds,
        expandedChapters: state.expandedChapters,
        syncExpansion: state.syncExpansion,
        searchKeyword: state.searchKeyword,
        scrollLock: state.scrollLock,
        diffMode: state.diffMode,
        annotations: state.annotations,
        annotationFilter: state.annotationFilter,
      }),
    }
  )
);
