import { useAppStore } from '@/store/appStore';
import { Navigation } from '@/components/Navigation';
import { VersionSelector } from '@/components/VersionSelector';
import { ComparisonView } from '@/components/ComparisonView';
import { AnnotationsView } from '@/components/AnnotationsView';

const Index = () => {
  const { activeSection } = useAppStore();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {activeSection === 'selection' && <VersionSelector />}
        {activeSection === 'comparison' && <ComparisonView />}
        {activeSection === 'annotations' && <AnnotationsView />}
      </main>
    </div>
  );
};

export default Index;
