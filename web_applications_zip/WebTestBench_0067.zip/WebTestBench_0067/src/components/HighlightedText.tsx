import { useMemo, useCallback } from 'react';

interface HighlightedTextProps {
  text: string;
  keyword: string;
  className?: string;
}

export function HighlightedText({ text, keyword, className = '' }: HighlightedTextProps) {
  const parts = useMemo(() => {
    if (!keyword.trim()) {
      return [{ text, isMatch: false }];
    }

    const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts: { text: string; isMatch: boolean }[] = [];
    let lastIndex = 0;
    let match;

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ text: text.slice(lastIndex, match.index), isMatch: false });
      }
      parts.push({ text: match[0], isMatch: true });
      lastIndex = regex.lastIndex;
    }

    if (lastIndex < text.length) {
      parts.push({ text: text.slice(lastIndex), isMatch: false });
    }

    return parts;
  }, [text, keyword]);

  return (
    <span className={className}>
      {parts.map((part, index) =>
        part.isMatch ? (
          <mark
            key={index}
            className="search-highlight animate-highlight-pulse"
            data-search-match
          >
            {part.text}
          </mark>
        ) : (
          <span key={index}>{part.text}</span>
        )
      )}
    </span>
  );
}

export function useSearchHighlight(keyword: string) {
  const scrollToMatch = useCallback((index: number = 0) => {
    const matches = document.querySelectorAll('[data-search-match]');
    if (matches.length > 0 && matches[index]) {
      matches[index].scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, []);

  const getMatchCount = useCallback(() => {
    return document.querySelectorAll('[data-search-match]').length;
  }, []);

  return { scrollToMatch, getMatchCount };
}
