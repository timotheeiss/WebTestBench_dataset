import { useAppStore } from '@/store/appStore';
import { products } from '@/data/manualData';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Package, Layers } from 'lucide-react';

export function VersionSelector() {
  const {
    selectedProductId,
    selectedVersionIds,
    setSelectedProductId,
    toggleVersionSelection,
    setActiveSection
  } = useAppStore();

  const selectedProduct = products.find(p => p.id === selectedProductId);

  const handleCompare = () => {
    if (selectedVersionIds.length >= 1) {
      setActiveSection('comparison');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8 animate-fade-in">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-foreground">Product Manual Comparison</h1>
        <p className="text-muted-foreground">Select a product and up to 3 versions to compare side by side</p>
      </div>

      <Card className="border-2">
        <CardHeader className="bg-secondary/50">
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" />
            Select Product
          </CardTitle>
          <CardDescription>Choose the product model to view its manuals</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Select value={selectedProductId || ''} onValueChange={setSelectedProductId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Choose a product..." />
            </SelectTrigger>
            <SelectContent className="bg-popover z-50">
              {products.map(product => (
                <SelectItem key={product.id} value={product.id}>
                  <span className="font-medium">{product.name}</span>
                  <span className="text-muted-foreground ml-2">({product.model})</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedProduct && (
        <Card className="border-2 animate-slide-in">
          <CardHeader className="bg-secondary/50">
            <CardTitle className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-primary" />
              Select Versions
            </CardTitle>
            <CardDescription>
              Select 1-3 versions to compare. {selectedVersionIds.length}/3 selected
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid gap-4">
              {selectedProduct.versions.map(version => {
                const isSelected = selectedVersionIds.includes(version.id);
                const isDisabled = !isSelected && selectedVersionIds.length >= 3;

                return (
                  <label
                    key={version.id}
                    className={`
                      flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all
                      ${isSelected 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-primary/50 hover:bg-secondary/30'
                      }
                      ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                  >
                    <Checkbox
                      checked={isSelected}
                      disabled={isDisabled}
                      onCheckedChange={() => !isDisabled && toggleVersionSelection(version.id)}
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-foreground">Version {version.version}</span>
                        {version.id === selectedProduct.versions[selectedProduct.versions.length - 1].id && (
                          <Badge className="bg-accent text-accent-foreground">Latest</Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Released: {new Date(version.releaseDate).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {version.chapters.length} chapters
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {selectedVersionIds.length >= 1 && (
        <div className="flex justify-center animate-fade-in">
          <Button size="lg" onClick={handleCompare} className="gap-2">
            Compare {selectedVersionIds.length} Version{selectedVersionIds.length > 1 ? 's' : ''}
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}
