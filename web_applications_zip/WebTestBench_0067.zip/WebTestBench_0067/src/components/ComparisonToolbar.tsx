import { useAppStore } from '@/store/appStore';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  Search, 
  ChevronUp, 
  ChevronDown, 
  Lock, 
  Unlock, 
  GitCompare, 
  FileText,
  Link,
  Unlink,
  ChevronsUpDown,
  ChevronsDownUp
} from 'lucide-react';
import { useSearchHighlight } from './HighlightedText';
import { useEffect, useState } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

export function ComparisonToolbar() {
  const {
    searchKeyword,
    setSearchKeyword,
    searchMatchIndex,
    setSearchMatchIndex,
    scrollLock,
    setScrollLock,
    diffMode,
    setDiffMode,
    syncExpansion,
    setSyncExpansion,
    expandAll,
    collapseAll
  } = useAppStore();

  const { scrollToMatch, getMatchCount } = useSearchHighlight(searchKeyword);
  const [matchCount, setMatchCount] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      const count = getMatchCount();
      setMatchCount(count);
      if (count > 0 && searchKeyword) {
        scrollToMatch(0);
        setSearchMatchIndex(0);
      }
    }, 100);
    return () => clearTimeout(timer);
  }, [searchKeyword, getMatchCount, scrollToMatch, setSearchMatchIndex]);

  const handlePrevMatch = () => {
    const newIndex = searchMatchIndex > 0 ? searchMatchIndex - 1 : matchCount - 1;
    setSearchMatchIndex(newIndex);
    scrollToMatch(newIndex);
  };

  const handleNextMatch = () => {
    const newIndex = searchMatchIndex < matchCount - 1 ? searchMatchIndex + 1 : 0;
    setSearchMatchIndex(newIndex);
    scrollToMatch(newIndex);
  };

  return (
    <div className="bg-card border-b border-border px-4 py-3">
      <div className="flex flex-wrap items-center gap-4">
        {/* Search */}
        <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              placeholder="Search in manuals..."
              className="pl-9 pr-16"
            />
            {matchCount > 0 && searchKeyword && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                {searchMatchIndex + 1}/{matchCount}
              </span>
            )}
          </div>
          {matchCount > 0 && searchKeyword && (
            <div className="flex gap-1">
              <Button variant="outline" size="icon" onClick={handlePrevMatch}>
                <ChevronUp className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={handleNextMatch}>
                <ChevronDown className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="h-6 w-px bg-border" />

        {/* Scroll Lock */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2">
              <Switch
                id="scroll-lock"
                checked={scrollLock}
                onCheckedChange={setScrollLock}
              />
              <Label htmlFor="scroll-lock" className="flex items-center gap-1 cursor-pointer">
                {scrollLock ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                <span className="hidden sm:inline">Scroll Lock</span>
              </Label>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            Sync scrolling across all version panels
          </TooltipContent>
        </Tooltip>

        <div className="h-6 w-px bg-border" />

        {/* Sync Expansion */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2">
              <Switch
                id="sync-expansion"
                checked={syncExpansion}
                onCheckedChange={setSyncExpansion}
              />
              <Label htmlFor="sync-expansion" className="flex items-center gap-1 cursor-pointer">
                {syncExpansion ? <Link className="w-4 h-4" /> : <Unlink className="w-4 h-4" />}
                <span className="hidden sm:inline">Sync Chapters</span>
              </Label>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            Expand/collapse chapters together across versions
          </TooltipContent>
        </Tooltip>

        <div className="h-6 w-px bg-border" />

        {/* Diff Mode */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2">
              <Switch
                id="diff-mode"
                checked={diffMode}
                onCheckedChange={setDiffMode}
              />
              <Label htmlFor="diff-mode" className="flex items-center gap-1 cursor-pointer">
                {diffMode ? <GitCompare className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                <span className="hidden sm:inline">Diff Mode</span>
              </Label>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            Show only differences between versions
          </TooltipContent>
        </Tooltip>

        <div className="h-6 w-px bg-border hidden lg:block" />

        {/* Expand/Collapse All */}
        <div className="hidden lg:flex gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" onClick={expandAll}>
                <ChevronsUpDown className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Expand all chapters</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" onClick={collapseAll}>
                <ChevronsDownUp className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Collapse all chapters</TooltipContent>
          </Tooltip>
        </div>
      </div>
    </div>
  );
}
