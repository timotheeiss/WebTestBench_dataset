import { useState } from 'react';
import { Chapter, Annotation } from '@/data/manualData';
import { useAppStore } from '@/store/appStore';
import { HighlightedText } from './HighlightedText';
import { ChevronDown, ChevronRight, MessageSquarePlus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

interface ChapterViewProps {
  chapter: Chapter;
  versionId: string;
  annotations: Annotation[];
  isModified?: boolean;
  isAdded?: boolean;
  isRemoved?: boolean;
  depth?: number;
}

export function ChapterView({
  chapter,
  versionId,
  annotations,
  isModified = false,
  isAdded = false,
  isRemoved = false,
  depth = 0
}: ChapterViewProps) {
  const {
    expandedChapters,
    syncExpansion,
    toggleChapter,
    searchKeyword,
    addAnnotation,
    removeAnnotation
  } = useAppStore();

  const [showAnnotationInput, setShowAnnotationInput] = useState(false);
  const [annotationText, setAnnotationText] = useState('');

  const expansionKey = syncExpansion ? chapter.id : `${versionId}-${chapter.id}`;
  const isExpanded = expandedChapters[expansionKey] ?? true;

  const chapterAnnotations = annotations.filter(a => a.chapterId === chapter.id);

  const handleAddAnnotation = () => {
    if (annotationText.trim()) {
      addAnnotation({
        versionId,
        chapterId: chapter.id,
        text: annotationText.trim(),
        author: 'You'
      });
      setAnnotationText('');
      setShowAnnotationInput(false);
    }
  };

  const diffClass = isAdded 
    ? 'diff-added' 
    : isRemoved 
      ? 'diff-removed' 
      : isModified 
        ? 'border-l-4 border-highlight bg-highlight-bg/30' 
        : '';

  return (
    <div 
      className={cn(
        'border-b border-chapter-border',
        diffClass
      )}
      style={{ paddingLeft: `${depth * 1}rem` }}
      data-chapter-id={chapter.id}
    >
      <button
        onClick={() => toggleChapter(chapter.id, versionId)}
        className="w-full flex items-center gap-2 p-3 text-left hover:bg-secondary/50 transition-colors"
      >
        {isExpanded ? (
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
        )}
        <span className="font-medium text-foreground">
          <HighlightedText text={chapter.title} keyword={searchKeyword} />
        </span>
        {chapterAnnotations.length > 0 && (
          <span className="ml-auto text-xs bg-annotation-bg text-annotation px-2 py-0.5 rounded-full">
            {chapterAnnotations.length} note{chapterAnnotations.length > 1 ? 's' : ''}
          </span>
        )}
      </button>

      {isExpanded && (
        <div className="px-4 pb-4 animate-accordion-down">
          <div className="prose prose-sm max-w-none text-foreground/90">
            {chapter.content.split('\n').map((paragraph, idx) => (
              <p key={idx} className="mb-2">
                <HighlightedText text={paragraph} keyword={searchKeyword} />
              </p>
            ))}
          </div>

          {/* Annotations */}
          {chapterAnnotations.length > 0 && (
            <div className="mt-4 space-y-2">
              {chapterAnnotations.map(annotation => (
                <div key={annotation.id} className="annotation-marker flex items-start gap-2">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-annotation">{annotation.author}</div>
                    <div className="text-sm text-foreground">{annotation.text}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(annotation.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAnnotation(annotation.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Add annotation */}
          {showAnnotationInput ? (
            <div className="mt-4 space-y-2">
              <Textarea
                value={annotationText}
                onChange={(e) => setAnnotationText(e.target.value)}
                placeholder="Add your note..."
                className="text-sm"
                rows={2}
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={handleAddAnnotation}>
                  Save Note
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => {
                    setShowAnnotationInput(false);
                    setAnnotationText('');
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              className="mt-2 text-muted-foreground"
              onClick={() => setShowAnnotationInput(true)}
            >
              <MessageSquarePlus className="w-4 h-4 mr-1" />
              Add Note
            </Button>
          )}

          {/* Subsections */}
          {chapter.subsections?.map(sub => (
            <ChapterView
              key={sub.id}
              chapter={sub}
              versionId={versionId}
              annotations={annotations}
              isModified={isModified}
              isAdded={isAdded}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}
