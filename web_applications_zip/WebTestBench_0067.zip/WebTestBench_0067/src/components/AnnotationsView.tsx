import { useAppStore } from '@/store/appStore';
import { products, getVersionById } from '@/data/manualData';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Search, MessageSquare, Trash2, Edit2, Check, X } from 'lucide-react';
import { useState } from 'react';

export function AnnotationsView() {
  const {
    annotations,
    annotationFilter,
    setAnnotationFilter,
    removeAnnotation,
    updateAnnotation,
    selectedProductId,
    selectedVersionIds
  } = useAppStore();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  const selectedProduct = products.find(p => p.id === selectedProductId);
  
  // Get all annotations for selected versions
  const relevantAnnotations = annotations.filter(a => 
    selectedVersionIds.includes(a.versionId)
  );

  // Filter annotations by search
  const filteredAnnotations = relevantAnnotations.filter(a =>
    a.text.toLowerCase().includes(annotationFilter.toLowerCase()) ||
    a.author.toLowerCase().includes(annotationFilter.toLowerCase()) ||
    a.chapterId.toLowerCase().includes(annotationFilter.toLowerCase())
  );

  // Group by version
  const groupedAnnotations = selectedVersionIds.map(versionId => {
    const version = getVersionById(selectedProductId!, versionId);
    return {
      versionId,
      version,
      annotations: filteredAnnotations.filter(a => a.versionId === versionId)
    };
  });

  const handleEdit = (id: string, text: string) => {
    setEditingId(id);
    setEditText(text);
  };

  const handleSaveEdit = (id: string) => {
    if (editText.trim()) {
      updateAnnotation(id, editText.trim());
    }
    setEditingId(null);
    setEditText('');
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditText('');
  };

  if (!selectedProduct || selectedVersionIds.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <MessageSquare className="w-12 h-12 text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold mb-2">No Versions Selected</h2>
        <p className="text-muted-foreground">
          Select versions first to view and manage annotations
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Annotations</h1>
          <p className="text-muted-foreground">
            Manage notes across {selectedVersionIds.length} selected version{selectedVersionIds.length > 1 ? 's' : ''}
          </p>
        </div>
        <Badge variant="outline" className="text-sm">
          {relevantAnnotations.length} total note{relevantAnnotations.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={annotationFilter}
          onChange={(e) => setAnnotationFilter(e.target.value)}
          placeholder="Filter annotations..."
          className="pl-9"
        />
      </div>

      {/* Annotations Grid */}
      <div className={`grid gap-6 ${selectedVersionIds.length > 1 ? 'md:grid-cols-2 lg:grid-cols-3' : ''}`}>
        {groupedAnnotations.map(({ versionId, version, annotations }) => (
          <Card key={versionId} className="border-2">
            <CardHeader className="bg-secondary/50">
              <CardTitle className="text-lg">
                Version {version?.version}
              </CardTitle>
              <CardDescription>
                {annotations.length} annotation{annotations.length !== 1 ? 's' : ''}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              {annotations.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No annotations{annotationFilter ? ' matching filter' : ''}
                </p>
              ) : (
                <div className="space-y-3">
                  {annotations.map(annotation => (
                    <div
                      key={annotation.id}
                      className="annotation-marker"
                    >
                      {editingId === annotation.id ? (
                        <div className="space-y-2">
                          <Textarea
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            rows={2}
                            className="text-sm"
                          />
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleSaveEdit(annotation.id)}
                            >
                              <Check className="w-3 h-3 mr-1" />
                              Save
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={handleCancelEdit}
                            >
                              <X className="w-3 h-3 mr-1" />
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <div className="text-sm font-medium text-annotation">
                                {annotation.author}
                              </div>
                              <div className="text-xs text-muted-foreground mb-1">
                                Chapter: {annotation.chapterId}
                              </div>
                              <div className="text-sm text-foreground">
                                {annotation.text}
                              </div>
                              <div className="text-xs text-muted-foreground mt-2">
                                {new Date(annotation.createdAt).toLocaleString()}
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(annotation.id, annotation.text)}
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeAnnotation(annotation.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
