import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { products, getVersionById } from '@/data/manualData';
import { ManualPanel } from './ManualPanel';
import { ComparisonToolbar } from './ComparisonToolbar';
import { Button } from '@/components/ui/button';
import { ArrowLeft, AlertCircle } from 'lucide-react';

export function ComparisonView() {
  const { selectedProductId, selectedVersionIds, setActiveSection } = useAppStore();
  const [syncScrollTop, setSyncScrollTop] = useState(0);

  const selectedProduct = products.find(p => p.id === selectedProductId);
  
  const selectedVersions = selectedVersionIds
    .map(id => getVersionById(selectedProductId!, id))
    .filter(Boolean);

  if (!selectedProduct || selectedVersions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <AlertCircle className="w-12 h-12 text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold mb-2">No Versions Selected</h2>
        <p className="text-muted-foreground mb-4">
          Please select at least one version to view
        </p>
        <Button onClick={() => setActiveSection('selection')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Go to Selection
        </Button>
      </div>
    );
  }

  const handlePanelScroll = (scrollTop: number) => {
    setSyncScrollTop(scrollTop);
  };

  const gridCols = selectedVersions.length === 1 
    ? 'grid-cols-1' 
    : selectedVersions.length === 2 
      ? 'grid-cols-2' 
      : 'grid-cols-3';

  return (
    <div className="flex flex-col h-full">
      <ComparisonToolbar />
      
      <div className={`flex-1 grid ${gridCols} overflow-hidden`}>
        {selectedVersions.map((version, index) => (
          <ManualPanel
            key={version!.id}
            version={version!}
            compareVersions={selectedVersions.filter((_, i) => i !== index) as any}
            panelIndex={index}
            onScroll={handlePanelScroll}
            scrollTop={syncScrollTop}
          />
        ))}
      </div>
    </div>
  );
}
