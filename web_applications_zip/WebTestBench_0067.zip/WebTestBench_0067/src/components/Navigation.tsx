import { useAppStore, ActiveSection } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { FileStack, GitCompare, MessageSquare, BookOpen } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Navigation() {
  const { activeSection, setActiveSection, selectedVersionIds } = useAppStore();

  const navItems: { id: ActiveSection; label: string; icon: React.ReactNode }[] = [
    { id: 'selection', label: 'Version Selection', icon: <FileStack className="w-4 h-4" /> },
    { id: 'comparison', label: 'Comparison', icon: <GitCompare className="w-4 h-4" /> },
    { id: 'annotations', label: 'Annotations', icon: <MessageSquare className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-primary" />
            <span className="font-semibold text-foreground">Manual Compare</span>
          </div>

          <nav className="flex items-center gap-1">
            {navItems.map(item => (
              <Button
                key={item.id}
                variant={activeSection === item.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveSection(item.id)}
                className={cn(
                  'gap-2',
                  activeSection === item.id && 'shadow-sm'
                )}
                disabled={item.id !== 'selection' && selectedVersionIds.length === 0}
              >
                {item.icon}
                <span className="hidden sm:inline">{item.label}</span>
              </Button>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
}
