import { useRef, useEffect, useCallback } from 'react';
import { ManualVersion, findChapterDifferences, getAllChapters } from '@/data/manualData';
import { useAppStore } from '@/store/appStore';
import { ChapterView } from './ChapterView';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ManualPanelProps {
  version: ManualVersion;
  compareVersions: ManualVersion[];
  panelIndex: number;
  onScroll?: (scrollTop: number) => void;
  scrollTop?: number;
}

export function ManualPanel({ 
  version, 
  compareVersions,
  panelIndex,
  onScroll,
  scrollTop
}: ManualPanelProps) {
  const { annotations, diffMode, scrollLock } = useAppStore();
  const scrollRef = useRef<HTMLDivElement>(null);
  const isScrolling = useRef(false);

  const versionAnnotations = annotations.filter(a => a.versionId === version.id);

  // Calculate differences if in diff mode
  const differences = diffMode && compareVersions.length > 0
    ? compareVersions.map(cv => findChapterDifferences(cv, version))
    : [];

  const allAddedIds = new Set(differences.flatMap(d => d.added));
  const allModifiedIds = new Set(differences.flatMap(d => d.modified));
  const allRemovedIds = new Set(differences.flatMap(d => d.removed));

  // Handle scroll sync
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    if (scrollLock && onScroll && !isScrolling.current) {
      onScroll((e.target as HTMLDivElement).scrollTop);
    }
  }, [scrollLock, onScroll]);

  useEffect(() => {
    if (scrollLock && scrollTop !== undefined && scrollRef.current) {
      isScrolling.current = true;
      scrollRef.current.scrollTop = scrollTop;
      setTimeout(() => {
        isScrolling.current = false;
      }, 50);
    }
  }, [scrollTop, scrollLock]);

  // Filter chapters based on diff mode
  const getVisibleChapters = () => {
    if (!diffMode) return version.chapters;
    
    const allChapters = getAllChapters(version);
    const hasChanges = allChapters.some(
      c => allAddedIds.has(c.id) || allModifiedIds.has(c.id)
    );
    
    if (!hasChanges && differences.length > 0) {
      return []; // No differences to show
    }
    
    return version.chapters;
  };

  const visibleChapters = getVisibleChapters();

  return (
    <div className="flex flex-col h-full border-r border-chapter-border last:border-r-0">
      {/* Version Header */}
      <div className="sticky top-0 z-10 bg-secondary/95 backdrop-blur px-4 py-3 border-b border-chapter-border">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-version-header">
              Version {version.version}
            </h3>
            <div className="text-xs text-muted-foreground">
              {new Date(version.releaseDate).toLocaleDateString()}
            </div>
          </div>
          <Badge variant="outline" className="text-xs">
            {version.chapters.length} chapters
          </Badge>
        </div>
      </div>

      {/* Chapters */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto manual-panel"
        onScroll={handleScroll}
      >
        {visibleChapters.length === 0 && diffMode ? (
          <div className="p-8 text-center text-muted-foreground">
            <p>No differences in this version</p>
          </div>
        ) : (
          visibleChapters.map(chapter => (
            <ChapterView
              key={chapter.id}
              chapter={chapter}
              versionId={version.id}
              annotations={versionAnnotations}
              isModified={allModifiedIds.has(chapter.id)}
              isAdded={allAddedIds.has(chapter.id)}
              isRemoved={allRemovedIds.has(chapter.id)}
            />
          ))
        )}
      </div>
    </div>
  );
}
