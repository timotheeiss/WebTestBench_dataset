export interface Chapter {
  id: string;
  title: string;
  content: string;
  subsections?: Chapter[];
}

export interface ManualVersion {
  id: string;
  version: string;
  releaseDate: string;
  chapters: Chapter[];
}

export interface Product {
  id: string;
  name: string;
  model: string;
  versions: ManualVersion[];
}

export interface Annotation {
  id: string;
  versionId: string;
  chapterId: string;
  text: string;
  createdAt: string;
  author: string;
}

export const products: Product[] = [
  {
    id: "prod-1",
    name: "CloudSync Pro",
    model: "CS-3000",
    versions: [
      {
        id: "v1",
        version: "1.0.0",
        releaseDate: "2024-01-15",
        chapters: [
          {
            id: "ch1",
            title: "1. Getting Started",
            content: `Welcome to CloudSync Pro CS-3000. This guide will help you set up and configure your device.

**System Requirements:**
- Operating System: Windows 10/11, macOS 12+, or Linux (Ubuntu 20.04+)
- RAM: Minimum 4GB, recommended 8GB
- Storage: 500MB available space
- Network: Stable internet connection (minimum 10 Mbps)

**Initial Setup:**
1. Download the installer from our official website
2. Run the installation wizard
3. Accept the license agreement
4. Choose your installation directory
5. Complete the setup process`,
            subsections: [
              {
                id: "ch1-1",
                title: "1.1 Installation",
                content: `**Step-by-step Installation Guide:**

1. Download the appropriate installer for your operating system
2. Verify the checksum of the downloaded file
3. Double-click the installer to begin
4. Follow the on-screen prompts
5. Restart your computer when prompted

**Note:** Administrator privileges are required for installation.`
              },
              {
                id: "ch1-2",
                title: "1.2 First Launch",
                content: `After installation, launch CloudSync Pro from your applications menu.

**First-time Configuration:**
- Enter your license key
- Create or sign in to your account
- Configure your sync preferences
- Select folders to synchronize`
              }
            ]
          },
          {
            id: "ch2",
            title: "2. Core Features",
            content: `CloudSync Pro offers powerful synchronization capabilities across all your devices.

**Key Features:**
- Real-time file synchronization
- Automatic conflict resolution
- Version history (up to 30 days)
- Selective sync for large folders
- Bandwidth throttling options`,
            subsections: [
              {
                id: "ch2-1",
                title: "2.1 File Synchronization",
                content: `**How Sync Works:**

CloudSync Pro monitors your selected folders and automatically uploads changes to the cloud. Changes are then propagated to all connected devices.

**Sync Status Indicators:**
- Green checkmark: Fully synced
- Blue arrows: Syncing in progress
- Yellow warning: Attention needed
- Red cross: Sync error`
              },
              {
                id: "ch2-2",
                title: "2.2 Sharing & Collaboration",
                content: `Share files and folders with team members easily.

**Sharing Options:**
- Public links with optional password protection
- Direct sharing with specific users
- Read-only or edit permissions
- Expiration dates for shared links`
              }
            ]
          },
          {
            id: "ch3",
            title: "3. Troubleshooting",
            content: `Common issues and their solutions.

**Connection Issues:**
If you experience connection problems, check your firewall settings and ensure ports 443 and 8080 are open.

**Sync Conflicts:**
When the same file is edited on multiple devices, CloudSync Pro creates a conflict copy. Review both versions and merge changes manually.`
          }
        ]
      },
      {
        id: "v2",
        version: "2.0.0",
        releaseDate: "2024-06-20",
        chapters: [
          {
            id: "ch1",
            title: "1. Getting Started",
            content: `Welcome to CloudSync Pro CS-3000 v2.0. This major update includes significant improvements and new features.

**System Requirements:**
- Operating System: Windows 10/11, macOS 12+, or Linux (Ubuntu 22.04+)
- RAM: Minimum 8GB, recommended 16GB
- Storage: 1GB available space
- Network: Stable internet connection (minimum 25 Mbps recommended)

**What's New in v2.0:**
- Redesigned user interface
- Improved sync performance (up to 3x faster)
- New team collaboration features
- Enhanced security with end-to-end encryption

**Initial Setup:**
1. Download the installer from our official website
2. Run the installation wizard
3. Accept the updated license agreement
4. Choose your installation directory
5. Migrate data from previous version (optional)
6. Complete the setup process`,
            subsections: [
              {
                id: "ch1-1",
                title: "1.1 Installation",
                content: `**Step-by-step Installation Guide:**

1. Download the appropriate installer for your operating system
2. Verify the checksum of the downloaded file
3. Uninstall previous versions (recommended but optional)
4. Double-click the installer to begin
5. Follow the on-screen prompts
6. Configure automatic updates
7. Restart your computer when prompted

**Note:** Administrator privileges are required. The installer will automatically detect and migrate settings from v1.x.`
              },
              {
                id: "ch1-2",
                title: "1.2 First Launch",
                content: `After installation, launch CloudSync Pro from your applications menu.

**First-time Configuration:**
- Enter your license key or activate trial
- Create or sign in to your account
- Enable two-factor authentication (recommended)
- Configure your sync preferences
- Select folders to synchronize
- Set up backup schedule`
              },
              {
                id: "ch1-3",
                title: "1.3 Migration from v1.x",
                content: `**Upgrading from Version 1.x:**

If you're upgrading from v1.x, your settings and sync preferences will be automatically migrated.

**Migration Steps:**
1. Back up your current configuration
2. Export any custom rules
3. Install v2.0
4. Review migrated settings
5. Verify sync status of all folders`
              }
            ]
          },
          {
            id: "ch2",
            title: "2. Core Features",
            content: `CloudSync Pro v2.0 offers enhanced synchronization capabilities with new team features.

**Key Features:**
- Real-time file synchronization with delta sync
- AI-powered conflict resolution
- Version history (up to 90 days)
- Selective sync for large folders
- Bandwidth throttling with smart scheduling
- Team workspaces
- Advanced file locking`,
            subsections: [
              {
                id: "ch2-1",
                title: "2.1 File Synchronization",
                content: `**How Sync Works:**

CloudSync Pro v2.0 uses delta synchronization to upload only changed portions of files, dramatically reducing bandwidth usage and sync time.

**Sync Status Indicators:**
- Green checkmark: Fully synced
- Blue arrows: Syncing in progress
- Purple cloud: Queued for sync
- Yellow warning: Attention needed
- Red cross: Sync error
- Lock icon: File locked by user`
              },
              {
                id: "ch2-2",
                title: "2.2 Sharing & Collaboration",
                content: `Share files and folders with enhanced team features.

**Sharing Options:**
- Public links with optional password protection
- Direct sharing with specific users
- Read-only, comment, or edit permissions
- Expiration dates for shared links
- Download limits
- Activity tracking

**Team Features:**
- Shared team folders
- Real-time co-editing (Office documents)
- Comment threads on files
- @mention notifications`
              },
              {
                id: "ch2-3",
                title: "2.3 Smart Sync",
                content: `**New in v2.0: Smart Sync**

Smart Sync allows you to see all your cloud files in your file explorer without downloading them. Files are downloaded on-demand when you open them.

**Benefits:**
- Save local storage space
- Access all files instantly
- Automatic cache management`
              }
            ]
          },
          {
            id: "ch3",
            title: "3. Troubleshooting",
            content: `Common issues and their solutions.

**Connection Issues:**
If you experience connection problems, use the built-in network diagnostics tool (Help > Diagnose Connection).

**Sync Conflicts:**
CloudSync Pro v2.0 uses AI to automatically resolve most conflicts. For complex conflicts, you'll be prompted to choose the preferred version.

**Performance Issues:**
Enable "Lite Mode" in Settings > Performance for better performance on older hardware.`
          },
          {
            id: "ch4",
            title: "4. Security & Privacy",
            content: `**New in v2.0: Enhanced Security**

CloudSync Pro v2.0 introduces end-to-end encryption for all your files.

**Security Features:**
- AES-256 encryption at rest
- TLS 1.3 encryption in transit
- Zero-knowledge encryption option
- Two-factor authentication
- Audit logs for enterprise accounts
- Remote wipe capability`
          }
        ]
      },
      {
        id: "v3",
        version: "2.5.0",
        releaseDate: "2025-01-10",
        chapters: [
          {
            id: "ch1",
            title: "1. Getting Started",
            content: `Welcome to CloudSync Pro CS-3000 v2.5 - The AI-Enhanced Edition.

**System Requirements:**
- Operating System: Windows 11, macOS 13+, or Linux (Ubuntu 22.04+)
- RAM: Minimum 8GB, recommended 16GB
- Storage: 2GB available space
- Network: Stable internet connection (minimum 50 Mbps for AI features)
- GPU: Optional, for accelerated AI processing

**What's New in v2.5:**
- AI-powered file organization
- Natural language search
- Predictive sync
- Enhanced mobile integration

**Initial Setup:**
1. Download the installer from our official website
2. Run the installation wizard  
3. Accept the updated license agreement
4. Choose your installation directory
5. Configure AI features
6. Complete the setup process`,
            subsections: [
              {
                id: "ch1-1",
                title: "1.1 Installation",
                content: `**Step-by-step Installation Guide:**

1. Download the appropriate installer for your operating system
2. Verify the checksum using SHA-256
3. Previous versions will be automatically updated
4. Double-click the installer to begin
5. Follow the on-screen prompts
6. Configure AI processing (cloud or local)
7. Enable automatic updates
8. Complete setup

**Note:** GPU acceleration requires compatible NVIDIA or Apple Silicon hardware.`
              },
              {
                id: "ch1-2",
                title: "1.2 First Launch",
                content: `After installation, launch CloudSync Pro from your applications menu.

**First-time Configuration:**
- Enter your license key or activate trial
- Create or sign in to your account
- Enable two-factor authentication (required for enterprise)
- Configure your sync preferences
- Select folders to synchronize
- Enable AI features
- Set up backup schedule
- Connect mobile devices`
              },
              {
                id: "ch1-3",
                title: "1.3 AI Setup",
                content: `**New in v2.5: AI Configuration**

Configure how AI features process your files:

**Processing Options:**
- Cloud Processing: Faster, requires internet
- Local Processing: Private, requires compatible GPU
- Hybrid: Best of both worlds

**AI Features to Enable:**
- Smart file tagging
- Content search
- Duplicate detection
- Storage optimization suggestions`
              }
            ]
          },
          {
            id: "ch2",
            title: "2. Core Features",
            content: `CloudSync Pro v2.5 introduces AI-powered features alongside improved core functionality.

**Key Features:**
- Real-time file synchronization with predictive sync
- AI-powered conflict resolution and prevention
- Version history (up to 365 days)
- Selective sync with smart suggestions
- Bandwidth optimization using ML
- Team workspaces with AI insights
- Advanced file locking with notifications`,
            subsections: [
              {
                id: "ch2-1",
                title: "2.1 File Synchronization",
                content: `**How Sync Works:**

CloudSync Pro v2.5 uses predictive synchronization to pre-sync files you're likely to need based on your usage patterns.

**Sync Status Indicators:**
- Green checkmark: Fully synced
- Blue arrows: Syncing in progress
- Purple cloud: Queued for sync
- Cyan brain: AI processing
- Yellow warning: Attention needed
- Red cross: Sync error
- Lock icon: File locked by user
- Star: Priority sync enabled`
              },
              {
                id: "ch2-2",
                title: "2.2 Sharing & Collaboration",
                content: `Share files and folders with AI-enhanced team features.

**Sharing Options:**
- Smart links with dynamic permissions
- Direct sharing with specific users
- Granular permissions (view, comment, edit, manage)
- Expiration dates with smart reminders
- Download limits with analytics
- Full activity tracking

**AI-Enhanced Team Features:**
- Shared team folders with auto-organization
- Real-time co-editing with AI suggestions
- Smart comment summaries
- @mention with context-aware suggestions
- Meeting notes auto-extraction`
              },
              {
                id: "ch2-3",
                title: "2.3 Smart Sync",
                content: `**Enhanced in v2.5: Predictive Smart Sync**

Smart Sync now predicts which files you'll need and pre-downloads them.

**Benefits:**
- Save local storage space
- Instant access to predicted files
- Automatic cache management
- Offline mode preparation

**AI Predictions Based On:**
- Time of day patterns
- Project context
- Calendar integration
- Collaboration activity`
              },
              {
                id: "ch2-4",
                title: "2.4 Natural Language Search",
                content: `**New in v2.5: Search with Natural Language**

Find files by describing what you're looking for:
- "The budget spreadsheet from last month's meeting"
- "Photos from the company retreat"
- "That PDF John sent about the new project"

**Search Features:**
- Content-aware search
- Image recognition
- Handwriting recognition (scanned docs)
- Audio transcription search`
              }
            ]
          },
          {
            id: "ch3",
            title: "3. Troubleshooting",
            content: `Common issues and their solutions.

**Connection Issues:**
Use the AI-powered network diagnostics (Help > Smart Diagnose) for automatic problem detection and resolution.

**Sync Conflicts:**
CloudSync Pro v2.5 uses predictive AI to prevent most conflicts before they occur. When conflicts do happen, the AI provides a detailed explanation and recommended resolution.

**Performance Issues:**
The new "Adaptive Mode" automatically adjusts resource usage based on your system's capabilities.

**AI Feature Issues:**
If AI features are slow, consider switching between cloud and local processing modes.`
          },
          {
            id: "ch4",
            title: "4. Security & Privacy",
            content: `**Enhanced in v2.5: AI-Aware Security**

CloudSync Pro v2.5 maintains the highest security standards while enabling AI features.

**Security Features:**
- AES-256 encryption at rest
- TLS 1.3 encryption in transit
- Zero-knowledge encryption option
- Hardware key support (YubiKey, etc.)
- Biometric authentication
- Comprehensive audit logs
- AI threat detection
- Anomaly alerts
- Remote wipe capability
- Data residency controls`
          },
          {
            id: "ch5",
            title: "5. AI Features Reference",
            content: `**Complete AI Features Guide**

This chapter covers all AI-powered features in CloudSync Pro v2.5.

**Available AI Features:**
- Smart Organization: Automatically categorize and tag files
- Content Analysis: Extract text, identify objects in images
- Predictive Sync: Pre-download files you'll likely need
- Natural Language Search: Find files using everyday language
- Duplicate Detection: Identify and manage duplicate files
- Storage Optimizer: Suggestions for freeing up space
- Collaboration Insights: Team productivity analytics`
          }
        ]
      }
    ]
  },
  {
    id: "prod-2",
    name: "DataVault Enterprise",
    model: "DV-500",
    versions: [
      {
        id: "dv-v1",
        version: "3.0.0",
        releaseDate: "2024-03-01",
        chapters: [
          {
            id: "dv-ch1",
            title: "1. Introduction",
            content: `DataVault Enterprise DV-500 is a secure data storage and management solution for businesses.

**Key Capabilities:**
- Encrypted data storage
- Role-based access control
- Compliance management (GDPR, HIPAA, SOC 2)
- Automated backup and recovery`
          },
          {
            id: "dv-ch2",
            title: "2. Configuration",
            content: `**Initial Configuration Steps:**

1. Connect to your network
2. Access the admin console
3. Configure user directories
4. Set up storage pools
5. Define retention policies`
          }
        ]
      },
      {
        id: "dv-v2",
        version: "3.5.0",
        releaseDate: "2024-09-15",
        chapters: [
          {
            id: "dv-ch1",
            title: "1. Introduction",
            content: `DataVault Enterprise DV-500 v3.5 introduces cloud-hybrid capabilities.

**Key Capabilities:**
- Encrypted data storage with hardware acceleration
- Role-based access control with SSO
- Extended compliance (GDPR, HIPAA, SOC 2, ISO 27001)
- Automated backup and recovery
- Cloud tiering for cost optimization`
          },
          {
            id: "dv-ch2",
            title: "2. Configuration",
            content: `**Initial Configuration Steps:**

1. Connect to your network
2. Access the admin console (new UI in v3.5)
3. Configure user directories or connect SSO
4. Set up storage pools with tiering
5. Define retention policies
6. Configure cloud integration`
          },
          {
            id: "dv-ch3",
            title: "3. Cloud Integration",
            content: `**New in v3.5: Cloud Tiering**

Automatically move less-accessed data to cloud storage while maintaining seamless access.

**Supported Providers:**
- AWS S3
- Azure Blob Storage
- Google Cloud Storage`
          }
        ]
      }
    ]
  }
];

export const initialAnnotations: Annotation[] = [
  {
    id: "ann-1",
    versionId: "v1",
    chapterId: "ch1",
    text: "Remember to verify checksum before installation in production environments.",
    createdAt: "2024-02-15T10:30:00Z",
    author: "System Admin"
  },
  {
    id: "ann-2",
    versionId: "v2",
    chapterId: "ch2-2",
    text: "The new team features require Enterprise license.",
    createdAt: "2024-07-01T14:20:00Z",
    author: "Product Manager"
  },
  {
    id: "ann-3",
    versionId: "v3",
    chapterId: "ch2-4",
    text: "Natural language search works best with clear, descriptive queries.",
    createdAt: "2025-01-12T09:15:00Z",
    author: "Technical Writer"
  }
];

export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}

export function getVersionById(productId: string, versionId: string): ManualVersion | undefined {
  const product = getProductById(productId);
  return product?.versions.find(v => v.id === versionId);
}

export function getAllChapters(version: ManualVersion): Chapter[] {
  const chapters: Chapter[] = [];
  
  function collectChapters(chapter: Chapter) {
    chapters.push(chapter);
    if (chapter.subsections) {
      chapter.subsections.forEach(collectChapters);
    }
  }
  
  version.chapters.forEach(collectChapters);
  return chapters;
}

export function findChapterDifferences(version1: ManualVersion, version2: ManualVersion): {
  added: string[];
  removed: string[];
  modified: string[];
} {
  const chapters1 = getAllChapters(version1);
  const chapters2 = getAllChapters(version2);
  
  const ids1 = new Set(chapters1.map(c => c.id));
  const ids2 = new Set(chapters2.map(c => c.id));
  
  const added = chapters2.filter(c => !ids1.has(c.id)).map(c => c.id);
  const removed = chapters1.filter(c => !ids2.has(c.id)).map(c => c.id);
  
  const modified: string[] = [];
  chapters1.forEach(c1 => {
    if (ids2.has(c1.id)) {
      const c2 = chapters2.find(c => c.id === c1.id);
      if (c2 && (c1.content !== c2.content || c1.title !== c2.title)) {
        modified.push(c1.id);
      }
    }
  });
  
  return { added, removed, modified };
}
