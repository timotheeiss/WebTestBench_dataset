import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ReviewProvider } from "@/context/ReviewContext";
import Index from "./pages/Index";
import { CategoryPage } from "./pages/CategoryPage";
import Dashboard from "./pages/Dashboard";
import ItemDetail from "./pages/ItemDetail";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <ReviewProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/books" element={<CategoryPage category="books" />} />
            <Route path="/movies" element={<CategoryPage category="movies" />} />
            <Route path="/products" element={<CategoryPage category="products" />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/books/:itemId" element={<ItemDetail />} />
            <Route path="/movies/:itemId" element={<ItemDetail />} />
            <Route path="/products/:itemId" element={<ItemDetail />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </ReviewProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
