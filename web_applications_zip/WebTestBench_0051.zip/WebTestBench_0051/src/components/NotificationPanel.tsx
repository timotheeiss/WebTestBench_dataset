import React from 'react';
import { Bell, Heart, Bookmark, CheckCircle, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { useReviews } from '@/context/ReviewContext';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

const iconMap = {
  like: Heart,
  save: Bookmark,
  approval: CheckCircle,
  reply: MessageCircle,
};

const colorMap = {
  like: 'text-like',
  save: 'text-save',
  approval: 'text-success',
  reply: 'text-primary',
};

export const NotificationPanel: React.FC = () => {
  const { notifications, unreadCount, markNotificationRead, markAllNotificationsRead } = useReviews();

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-accent text-accent-foreground text-xs flex items-center justify-center font-medium animate-pulse-glow">
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent 
        align="end" 
        className="w-80 p-0 bg-card border-border"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h3 className="font-serif text-lg">Notifications</h3>
          {unreadCount > 0 && (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={markAllNotificationsRead}
              className="text-xs text-primary"
            >
              Mark all read
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {notifications.length > 0 ? (
            notifications.map((notification) => {
              const Icon = iconMap[notification.type];
              return (
                <div
                  key={notification.id}
                  onClick={() => markNotificationRead(notification.id)}
                  className={cn(
                    'flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors hover:bg-secondary/50 animate-fade-in',
                    !notification.read && 'bg-secondary/30'
                  )}
                >
                  <div className={cn('mt-0.5', colorMap[notification.type])}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground leading-relaxed">
                      {notification.message}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatDistanceToNow(notification.createdAt, { addSuffix: true })}
                    </p>
                  </div>
                  {!notification.read && (
                    <span className="h-2 w-2 rounded-full bg-primary animate-pulse-glow" />
                  )}
                </div>
              );
            })
          ) : (
            <div className="p-6 text-center text-muted-foreground">
              No notifications yet
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
