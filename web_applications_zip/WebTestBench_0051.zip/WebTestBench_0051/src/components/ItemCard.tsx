import React from 'react';
import { Link } from 'react-router-dom';
import { Item } from '@/data/mockData';
import { StarRating } from './StarRating';

interface ItemCardProps {
  item: Item;
}

export const ItemCard: React.FC<ItemCardProps> = ({ item }) => {
  return (
    <Link to={`/${item.category}/${item.id}`}>
      <article className="group relative overflow-hidden rounded-xl bg-card border border-border/50 transition-all duration-300 hover:border-primary/30 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02]">
        {/* Image */}
        <div className="aspect-[3/4] overflow-hidden">
          <img
            src={item.image}
            alt={item.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
        </div>

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <span className="mb-1 inline-block text-xs uppercase tracking-wider text-primary">
            {item.category}
          </span>
          <h3 className="font-serif text-lg text-foreground leading-tight mb-1">
            {item.title}
          </h3>
          <p className="text-sm text-muted-foreground mb-2">
            {item.subtitle}
          </p>
          <div className="flex items-center justify-between">
            <StarRating rating={item.avgRating} size="sm" showValue />
            <span className="text-xs text-muted-foreground">
              {item.reviewCount.toLocaleString()} reviews
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
};
