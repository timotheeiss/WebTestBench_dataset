import React from 'react';
import { Heart, Bookmark, MoreHorizontal } from 'lucide-react';
import { Review } from '@/data/mockData';
import { StarRating } from './StarRating';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { cn } from '@/lib/utils';
import { useReviews } from '@/context/ReviewContext';
import { formatDistanceToNow } from 'date-fns';

interface ReviewCardProps {
  review: Review;
  showItem?: boolean;
  onEdit?: () => void;
  isOwn?: boolean;
}

export const ReviewCard: React.FC<ReviewCardProps> = ({ 
  review, 
  showItem = true,
  onEdit,
  isOwn = false,
}) => {
  const { toggleLike, toggleSave } = useReviews();

  return (
    <article className="group relative rounded-xl bg-card border border-border/50 p-5 transition-all duration-300 hover:border-border hover:shadow-lg animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border-2 border-border">
            <AvatarImage src={review.userAvatar} alt={review.userName} />
            <AvatarFallback>{review.userName[0]}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium text-foreground">{review.userName}</p>
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(review.createdAt, { addSuffix: true })}
            </p>
          </div>
        </div>
        {isOwn && onEdit && (
          <Button variant="ghost" size="xs" onClick={onEdit}>
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Item info */}
      {showItem && (
        <div className="flex items-center gap-3 mb-4">
          <img 
            src={review.itemImage} 
            alt={review.itemTitle}
            className="w-12 h-16 object-cover rounded-md"
          />
          <div>
            <h3 className="font-serif text-lg text-foreground leading-tight">
              {review.itemTitle}
            </h3>
            <span className="text-xs uppercase tracking-wider text-muted-foreground">
              {review.category}
            </span>
          </div>
        </div>
      )}

      {/* Rating */}
      <div className="flex items-center gap-3 mb-3">
        <StarRating rating={review.overallRating} size="sm" />
        <span className="text-sm font-medium text-primary">
          {review.overallRating}/5
        </span>
      </div>

      {/* Content */}
      <p className="text-foreground/90 leading-relaxed mb-4">
        {review.content}
      </p>

      {/* Dimension ratings */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {review.dimensions.map((dim) => (
          <div 
            key={dim.name}
            className="flex items-center justify-between px-3 py-1.5 rounded-md bg-secondary/50"
          >
            <span className="text-xs text-muted-foreground">{dim.name}</span>
            <StarRating rating={dim.value} size="sm" />
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 pt-3 border-t border-border/50">
        <Button
          variant="like"
          size="sm"
          onClick={() => toggleLike(review.id)}
          className={cn(review.isLiked && 'text-like')}
        >
          <Heart className={cn('h-4 w-4', review.isLiked && 'fill-current')} />
          <span>{review.likes}</span>
        </Button>
        <Button
          variant="save"
          size="sm"
          onClick={() => toggleSave(review.id)}
          className={cn(review.isSaved && 'text-save')}
        >
          <Bookmark className={cn('h-4 w-4', review.isSaved && 'fill-current')} />
          <span>{review.isSaved ? 'Saved' : 'Save'}</span>
        </Button>
      </div>
    </article>
  );
};
