import React, { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { useReviews } from '@/context/ReviewContext';
import { ReviewCard } from './ReviewCard';

export const SearchBar: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const { searchReviews } = useReviews();
  const results = query.length >= 2 ? searchReviews(query) : [];
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative w-full max-w-md">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search reviews, items, users..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="pl-10 pr-10 bg-secondary/50 border-border/50 focus:bg-secondary focus:border-primary/50"
        />
        {query && (
          <Button
            variant="ghost"
            size="xs"
            onClick={() => {
              setQuery('');
              setIsOpen(false);
            }}
            className="absolute right-1 top-1/2 -translate-y-1/2"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {isOpen && query.length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-2 max-h-96 overflow-y-auto rounded-xl border border-border bg-card shadow-xl z-50 animate-slide-up">
          {results.length > 0 ? (
            <div className="p-3 space-y-3">
              <p className="text-xs text-muted-foreground px-2">
                {results.length} result{results.length !== 1 && 's'} found
              </p>
              {results.slice(0, 5).map((review) => (
                <ReviewCard key={review.id} review={review} showItem />
              ))}
            </div>
          ) : (
            <div className="p-6 text-center text-muted-foreground">
              No results found for "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
};
