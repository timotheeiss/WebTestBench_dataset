import React, { useState, useEffect, useCallback } from 'react';
import { Save, History, RotateCcw, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { StarRating } from './StarRating';
import { useReviews } from '@/context/ReviewContext';
import { Review, ReviewCategory, dimensionsByCategory, items } from '@/data/mockData';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

interface ReviewEditorProps {
  existingReview?: Review;
  onClose?: () => void;
}

export const ReviewEditor: React.FC<ReviewEditorProps> = ({ existingReview, onClose }) => {
  const { addReview, updateReview, saveDraft, getDraft, clearDraft, rollbackToVersion } = useReviews();
  
  const [category, setCategory] = useState<ReviewCategory>(existingReview?.category || 'books');
  const [itemId, setItemId] = useState(existingReview?.itemId || '');
  const [content, setContent] = useState(existingReview?.content || '');
  const [overallRating, setOverallRating] = useState(existingReview?.overallRating || 0);
  const [dimensions, setDimensions] = useState<{ name: string; value: number }[]>(
    existingReview?.dimensions || dimensionsByCategory[category].map(d => ({ name: d, value: 0 }))
  );
  const [showVersions, setShowVersions] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  const categoryItems = items.filter(i => i.category === category);
  const selectedItem = items.find(i => i.id === itemId);
  const charCount = content.length;
  const maxChars = 200;

  // Load draft on mount
  useEffect(() => {
    if (!existingReview) {
      const draft = getDraft();
      if (draft) {
        setContent(draft.content);
        setCategory(draft.category);
        setItemId(draft.itemId);
        toast.info('Draft restored');
      }
    }
  }, []);

  // Update dimensions when category changes
  useEffect(() => {
    if (!existingReview) {
      setDimensions(dimensionsByCategory[category].map(d => ({ name: d, value: 0 })));
    }
  }, [category, existingReview]);

  // Auto-save draft
  useEffect(() => {
    if (content && itemId && !existingReview) {
      const timer = setTimeout(() => {
        saveDraft(content, itemId, category);
        setLastSaved(new Date());
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [content, itemId, category, saveDraft, existingReview]);

  const handleDimensionChange = useCallback((name: string, value: number) => {
    setDimensions(prev => prev.map(d => d.name === name ? { ...d, value } : d));
  }, []);

  const handleSubmit = () => {
    if (!itemId || !content || overallRating === 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (existingReview) {
      updateReview(existingReview.id, content, overallRating, dimensions);
      toast.success('Review updated!');
    } else {
      const item = items.find(i => i.id === itemId);
      if (!item) return;

      addReview({
        userId: 'user-1',
        userName: 'Alex Chen',
        userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        category,
        itemId,
        itemTitle: item.title,
        itemImage: item.image,
        content,
        overallRating,
        dimensions,
      });
      toast.success('Review published!');
    }

    clearDraft();
    onClose?.();
  };

  return (
    <div className="space-y-6">
      {/* Category & Item Selection */}
      {!existingReview && (
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Category</label>
            <Select value={category} onValueChange={(v: ReviewCategory) => setCategory(v)}>
              <SelectTrigger className="bg-secondary/50 border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="books">Books</SelectItem>
                <SelectItem value="movies">Movies</SelectItem>
                <SelectItem value="products">Products</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Item</label>
            <Select value={itemId} onValueChange={setItemId}>
              <SelectTrigger className="bg-secondary/50 border-border">
                <SelectValue placeholder="Select item" />
              </SelectTrigger>
              <SelectContent>
                {categoryItems.map(item => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {/* Selected item preview */}
      {selectedItem && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
          <img 
            src={selectedItem.image} 
            alt={selectedItem.title}
            className="w-12 h-16 object-cover rounded"
          />
          <div>
            <h4 className="font-serif text-foreground">{selectedItem.title}</h4>
            <p className="text-sm text-muted-foreground">{selectedItem.subtitle}</p>
          </div>
        </div>
      )}

      {/* Overall Rating */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Overall Rating</label>
        <StarRating 
          rating={overallRating} 
          size="lg" 
          interactive 
          onChange={setOverallRating} 
        />
      </div>

      {/* Dimension Ratings */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-foreground">Category Ratings</label>
        <div className="grid grid-cols-2 gap-3">
          {dimensions.map((dim) => (
            <div 
              key={dim.name}
              className="flex items-center justify-between p-3 rounded-lg bg-secondary/30"
            >
              <span className="text-sm text-muted-foreground">{dim.name}</span>
              <StarRating 
                rating={dim.value} 
                size="sm" 
                interactive 
                onChange={(v) => handleDimensionChange(dim.name, v)} 
              />
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-foreground">Your Review</label>
          <span className={`text-xs ${charCount > maxChars ? 'text-destructive' : 'text-muted-foreground'}`}>
            {charCount}/{maxChars}
          </span>
        </div>
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value.slice(0, maxChars))}
          placeholder="Share your thoughts in 200 characters or less..."
          className="min-h-24 bg-secondary/50 border-border resize-none"
        />
      </div>

      {/* Version History */}
      {existingReview && existingReview.versions.length > 0 && (
        <Dialog open={showVersions} onOpenChange={setShowVersions}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <History className="h-4 w-4" />
              Version History ({existingReview.versions.length})
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="font-serif">Version History</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {existingReview.versions.map((version) => (
                <div 
                  key={version.id}
                  className="p-3 rounded-lg bg-secondary/30 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(version.timestamp, { addSuffix: true })}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        rollbackToVersion(existingReview.id, version.id);
                        setContent(version.content);
                        setShowVersions(false);
                        toast.success('Rolled back to previous version');
                      }}
                    >
                      <RotateCcw className="h-3 w-3 mr-1" />
                      Restore
                    </Button>
                  </div>
                  <p className="text-sm text-foreground/80">{version.content}</p>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-border">
        <div className="text-xs text-muted-foreground">
          {lastSaved && !existingReview && (
            <span className="flex items-center gap-1">
              <Save className="h-3 w-3" />
              Auto-saved {formatDistanceToNow(lastSaved, { addSuffix: true })}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {onClose && (
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          )}
          <Button onClick={handleSubmit} className="gap-2">
            <Send className="h-4 w-4" />
            {existingReview ? 'Update' : 'Publish'}
          </Button>
        </div>
      </div>
    </div>
  );
};
