import React from 'react';
import { ArrowRight, TrendingUp, BookOpen, Film, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { ReviewCard } from '@/components/ReviewCard';
import { ItemCard } from '@/components/ItemCard';
import { useReviews } from '@/context/ReviewContext';
import { items } from '@/data/mockData';

const categoryIcons = {
  books: BookOpen,
  movies: Film,
  products: Package,
};

const Index = () => {
  const { reviews } = useReviews();
  
  const latestReviews = reviews.slice(0, 4);
  const trendingItems = items.slice(0, 6);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="text-center py-12 mb-12">
        <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">
          Share your thoughts in{' '}
          <span className="text-gradient">200 characters</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          Quick, honest reviews on books, movies, and products. 
          Rate, save, and discover what matters most.
        </p>
        <div className="flex items-center justify-center gap-4">
          {(['books', 'movies', 'products'] as const).map((cat) => {
            const Icon = categoryIcons[cat];
            return (
              <Link 
                key={cat}
                to={`/${cat}`}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <Icon className="h-4 w-4 text-primary" />
                <span className="capitalize text-sm font-medium">{cat}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Trending Items */}
      <section className="mb-16">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="font-serif text-2xl text-foreground">Trending Now</h2>
          </div>
          <Link 
            to="/books"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {trendingItems.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
      </section>

      {/* Latest Reviews */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-serif text-2xl text-foreground">Latest Reviews</h2>
          <Link 
            to="/dashboard"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            Your reviews <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {latestReviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
      </section>
    </Layout>
  );
};

export default Index;
