import React, { useState } from 'react';
import { PenSquare, Heart, Bookmark, TrendingUp, BarChart3, PieChart as PieChartIcon, ZoomIn, ZoomOut } from 'lucide-react';
import { Layout } from '@/components/Layout';
import { ReviewCard } from '@/components/ReviewCard';
import { ReviewEditor } from '@/components/ReviewEditor';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useReviews } from '@/context/ReviewContext';
import { currentUser } from '@/data/mockData';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend,
  Area, AreaChart
} from 'recharts';
import { format, subDays } from 'date-fns';

const COLORS = ['hsl(38, 92%, 55%)', 'hsl(350, 75%, 60%)', 'hsl(200, 80%, 55%)', 'hsl(150, 80%, 45%)'];

const Dashboard = () => {
  const { getReviewsByUser, getSavedReviews, reviews } = useReviews();
  const [editingReview, setEditingReview] = useState<string | null>(null);
  const [chartType, setChartType] = useState<'bar' | 'pie' | 'area'>('bar');
  const [zoomLevel, setZoomLevel] = useState(1);

  const myReviews = getReviewsByUser(currentUser.id);
  const savedReviews = getSavedReviews();
  const likedReviews = reviews.filter(r => r.isLiked);

  // Stats
  const totalReviews = myReviews.length;
  const totalLikes = myReviews.reduce((sum, r) => sum + r.likes, 0);
  const avgRating = myReviews.length > 0 
    ? (myReviews.reduce((sum, r) => sum + r.overallRating, 0) / myReviews.length).toFixed(1)
    : '0';

  // Category distribution for pie chart
  const categoryDistribution = ['books', 'movies', 'products'].map(cat => ({
    name: cat.charAt(0).toUpperCase() + cat.slice(1),
    value: myReviews.filter(r => r.category === cat).length,
  }));

  // Rating trend data (mock last 7 days)
  const trendData = Array.from({ length: 7 }, (_, i) => ({
    date: format(subDays(new Date(), 6 - i), 'MMM d'),
    reviews: Math.floor(Math.random() * 5) + 1,
    likes: Math.floor(Math.random() * 20) + 5,
  }));

  // Rating distribution
  const ratingDistribution = [1, 2, 3, 4, 5].map(rating => ({
    rating: `${rating}★`,
    count: myReviews.filter(r => r.overallRating === rating).length,
  }));

  const reviewToEdit = editingReview ? myReviews.find(r => r.id === editingReview) : null;

  return (
    <Layout>
      {/* Header */}
      <section className="flex items-center gap-4 mb-8">
        <img 
          src={currentUser.avatar} 
          alt={currentUser.name}
          className="w-16 h-16 rounded-full border-2 border-primary"
        />
        <div>
          <h1 className="font-serif text-3xl text-foreground">{currentUser.name}</h1>
          <p className="text-muted-foreground">Your personal review dashboard</p>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-3 gap-4 mb-8">
        <div className="p-4 rounded-xl bg-card border border-border/50 text-center">
          <PenSquare className="h-6 w-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-serif text-foreground">{totalReviews}</p>
          <p className="text-sm text-muted-foreground">Reviews</p>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border/50 text-center">
          <Heart className="h-6 w-6 text-like mx-auto mb-2" />
          <p className="text-2xl font-serif text-foreground">{totalLikes}</p>
          <p className="text-sm text-muted-foreground">Likes Received</p>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border/50 text-center">
          <TrendingUp className="h-6 w-6 text-success mx-auto mb-2" />
          <p className="text-2xl font-serif text-foreground">{avgRating}</p>
          <p className="text-sm text-muted-foreground">Avg Rating</p>
        </div>
      </section>

      {/* Charts Section */}
      <section className="mb-8 p-6 rounded-xl bg-card border border-border/50">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-serif text-xl text-foreground">Analytics</h2>
          <div className="flex items-center gap-2">
            {/* Chart type switcher */}
            <div className="flex items-center gap-1 bg-secondary/50 rounded-lg p-1">
              <Button
                variant={chartType === 'bar' ? 'default' : 'ghost'}
                size="xs"
                onClick={() => setChartType('bar')}
              >
                <BarChart3 className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'pie' ? 'default' : 'ghost'}
                size="xs"
                onClick={() => setChartType('pie')}
              >
                <PieChartIcon className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'area' ? 'default' : 'ghost'}
                size="xs"
                onClick={() => setChartType('area')}
              >
                <TrendingUp className="h-4 w-4" />
              </Button>
            </div>
            {/* Zoom controls */}
            <div className="flex items-center gap-1 bg-secondary/50 rounded-lg p-1">
              <Button
                variant="ghost"
                size="xs"
                onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.25))}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-xs text-muted-foreground px-2">{Math.round(zoomLevel * 100)}%</span>
              <Button
                variant="ghost"
                size="xs"
                onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.25))}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div 
          className="transition-all duration-300 overflow-hidden"
          style={{ height: 250 * zoomLevel }}
        >
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? (
              <BarChart data={ratingDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="rating" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            ) : chartType === 'pie' ? (
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            ) : (
              <AreaChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="reviews" 
                  stackId="1"
                  stroke="hsl(var(--primary))" 
                  fill="hsl(var(--primary) / 0.3)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="likes" 
                  stackId="2"
                  stroke="hsl(var(--like))" 
                  fill="hsl(350 75% 60% / 0.3)" 
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </section>

      {/* Tabs for Reviews */}
      <Tabs defaultValue="my-reviews" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="my-reviews" className="gap-2">
            <PenSquare className="h-4 w-4" />
            My Reviews
          </TabsTrigger>
          <TabsTrigger value="saved" className="gap-2">
            <Bookmark className="h-4 w-4" />
            Saved
          </TabsTrigger>
          <TabsTrigger value="liked" className="gap-2">
            <Heart className="h-4 w-4" />
            Liked
          </TabsTrigger>
        </TabsList>

        <TabsContent value="my-reviews">
          {myReviews.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {myReviews.map((review) => (
                <ReviewCard 
                  key={review.id} 
                  review={review} 
                  isOwn
                  onEdit={() => setEditingReview(review.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              You haven't written any reviews yet. Start sharing your thoughts!
            </div>
          )}
        </TabsContent>

        <TabsContent value="saved">
          {savedReviews.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {savedReviews.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              No saved reviews yet. Bookmark reviews to find them here!
            </div>
          )}
        </TabsContent>

        <TabsContent value="liked">
          {likedReviews.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {likedReviews.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              No liked reviews yet. Show some love to reviews you enjoy!
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Edit Review Dialog */}
      <Dialog open={!!editingReview} onOpenChange={() => setEditingReview(null)}>
        <DialogContent className="bg-card border-border max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Edit Review</DialogTitle>
          </DialogHeader>
          {reviewToEdit && (
            <ReviewEditor 
              existingReview={reviewToEdit} 
              onClose={() => setEditingReview(null)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Dashboard;
