import React from 'react';
import { useParams } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { ReviewCard } from '@/components/ReviewCard';
import { StarRating } from '@/components/StarRating';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ReviewEditor } from '@/components/ReviewEditor';
import { useReviews } from '@/context/ReviewContext';
import { items, dimensionsByCategory } from '@/data/mockData';
import { PenSquare } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const ItemDetail = () => {
  const { itemId } = useParams<{ itemId: string }>();
  const { reviews } = useReviews();
  const [isEditorOpen, setIsEditorOpen] = React.useState(false);

  const item = items.find(i => i.id === itemId);
  const itemReviews = reviews.filter(r => r.itemId === itemId);

  if (!item) {
    return (
      <Layout>
        <div className="text-center py-12 text-muted-foreground">
          Item not found
        </div>
      </Layout>
    );
  }

  // Calculate dimension averages
  const dimensions = dimensionsByCategory[item.category];
  const dimensionAverages = dimensions.map(dim => {
    const ratings = itemReviews
      .flatMap(r => r.dimensions)
      .filter(d => d.name === dim)
      .map(d => d.value);
    const avg = ratings.length > 0 
      ? ratings.reduce((a, b) => a + b, 0) / ratings.length 
      : 0;
    return { name: dim, average: avg };
  });

  // Rating distribution
  const ratingDistribution = [1, 2, 3, 4, 5].map(rating => ({
    rating: `${rating}★`,
    count: itemReviews.filter(r => r.overallRating === rating).length,
  }));

  return (
    <Layout>
      {/* Item Header */}
      <section className="flex flex-col md:flex-row gap-8 mb-12">
        <div className="w-full md:w-64 flex-shrink-0">
          <img
            src={item.image}
            alt={item.title}
            className="w-full aspect-[3/4] object-cover rounded-xl"
          />
        </div>
        <div className="flex-1">
          <span className="text-sm uppercase tracking-wider text-primary mb-2 inline-block">
            {item.category}
          </span>
          <h1 className="font-serif text-4xl text-foreground mb-2">{item.title}</h1>
          <p className="text-lg text-muted-foreground mb-4">{item.subtitle}</p>
          
          <div className="flex items-center gap-4 mb-6">
            <StarRating rating={item.avgRating} size="lg" showValue />
            <span className="text-muted-foreground">
              {item.reviewCount.toLocaleString()} reviews
            </span>
          </div>

          {/* Dimension Ratings */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            {dimensionAverages.map((dim) => (
              <div 
                key={dim.name}
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/30"
              >
                <span className="text-sm text-muted-foreground">{dim.name}</span>
                <div className="flex items-center gap-2">
                  <StarRating rating={Math.round(dim.average)} size="sm" />
                  <span className="text-xs text-muted-foreground">
                    {dim.average.toFixed(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
            <DialogTrigger asChild>
              <Button variant="glow" className="gap-2">
                <PenSquare className="h-4 w-4" />
                Write a Review
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="font-serif text-2xl">Review {item.title}</DialogTitle>
              </DialogHeader>
              <ReviewEditor onClose={() => setIsEditorOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </section>

      {/* Rating Distribution */}
      <section className="mb-12 p-6 rounded-xl bg-card border border-border/50">
        <h2 className="font-serif text-xl text-foreground mb-4">Rating Distribution</h2>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ratingDistribution} layout="vertical">
              <XAxis type="number" hide />
              <YAxis 
                type="category" 
                dataKey="rating" 
                axisLine={false} 
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                {ratingDistribution.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={`hsl(38 92% ${55 - index * 8}%)`}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Reviews */}
      <section>
        <h2 className="font-serif text-2xl text-foreground mb-6">
          Reviews ({itemReviews.length})
        </h2>
        {itemReviews.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {itemReviews.map((review) => (
              <ReviewCard key={review.id} review={review} showItem={false} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No reviews yet. Be the first to review!
          </div>
        )}
      </section>
    </Layout>
  );
};

export default ItemDetail;
