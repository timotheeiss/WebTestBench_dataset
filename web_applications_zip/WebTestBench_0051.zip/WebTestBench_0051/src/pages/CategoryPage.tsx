import React from 'react';
import { useParams } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { ReviewCard } from '@/components/ReviewCard';
import { ItemCard } from '@/components/ItemCard';
import { StarRating } from '@/components/StarRating';
import { useReviews } from '@/context/ReviewContext';
import { items, ReviewCategory } from '@/data/mockData';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface CategoryPageProps {
  category: ReviewCategory;
}

const categoryTitles = {
  books: 'Books',
  movies: 'Movies',
  products: 'Products',
};

const categoryDescriptions = {
  books: 'Discover and share quick reviews on your favorite reads',
  movies: 'Rate the latest films and classic cinema',
  products: 'Help others make informed purchasing decisions',
};

export const CategoryPage: React.FC<CategoryPageProps> = ({ category }) => {
  const { getReviewsByCategory } = useReviews();
  const categoryItems = items.filter(i => i.category === category);
  const categoryReviews = getReviewsByCategory(category);

  // Calculate rating distribution
  const ratingDistribution = [1, 2, 3, 4, 5].map(rating => ({
    rating: `${rating}★`,
    count: categoryReviews.filter(r => r.overallRating === rating).length,
  }));

  return (
    <Layout>
      {/* Header */}
      <section className="mb-12">
        <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-3">
          {categoryTitles[category]}
        </h1>
        <p className="text-lg text-muted-foreground">
          {categoryDescriptions[category]}
        </p>
      </section>

      {/* Rating Distribution Chart */}
      <section className="mb-12 p-6 rounded-xl bg-card border border-border/50">
        <h2 className="font-serif text-xl text-foreground mb-4">Rating Distribution</h2>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ratingDistribution} layout="vertical">
              <XAxis type="number" hide />
              <YAxis 
                type="category" 
                dataKey="rating" 
                axisLine={false} 
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
              />
              <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                {ratingDistribution.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={`hsl(38 92% ${55 - index * 8}%)`}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Items Grid */}
      <section className="mb-12">
        <h2 className="font-serif text-2xl text-foreground mb-6">
          Browse {categoryTitles[category]}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {categoryItems.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section>
        <h2 className="font-serif text-2xl text-foreground mb-6">
          Recent Reviews
        </h2>
        {categoryReviews.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {categoryReviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No reviews yet. Be the first to review!
          </div>
        )}
      </section>
    </Layout>
  );
};
