export type ReviewCategory = 'books' | 'movies' | 'products';

export interface RatingDimension {
  name: string;
  value: number;
}

export interface ReviewVersion {
  id: string;
  content: string;
  timestamp: Date;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  category: ReviewCategory;
  itemId: string;
  itemTitle: string;
  itemImage: string;
  content: string;
  overallRating: number;
  dimensions: RatingDimension[];
  likes: number;
  isLiked: boolean;
  isSaved: boolean;
  createdAt: Date;
  versions: ReviewVersion[];
}

export interface Item {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  category: ReviewCategory;
  year?: number;
  author?: string;
  director?: string;
  brand?: string;
  avgRating: number;
  reviewCount: number;
}

export interface Notification {
  id: string;
  type: 'like' | 'save' | 'approval' | 'reply';
  message: string;
  reviewId: string;
  read: boolean;
  createdAt: Date;
}

export const currentUser = {
  id: 'user-1',
  name: 'Alex Chen',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
};

export const items: Item[] = [
  // Books
  {
    id: 'book-1',
    title: 'The Midnight Library',
    subtitle: 'Matt Haig',
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop',
    category: 'books',
    year: 2020,
    author: 'Matt Haig',
    avgRating: 4.2,
    reviewCount: 2847,
  },
  {
    id: 'book-2',
    title: 'Atomic Habits',
    subtitle: 'James Clear',
    image: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=600&fit=crop',
    category: 'books',
    year: 2018,
    author: 'James Clear',
    avgRating: 4.7,
    reviewCount: 5621,
  },
  {
    id: 'book-3',
    title: 'Project Hail Mary',
    subtitle: 'Andy Weir',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=600&fit=crop',
    category: 'books',
    year: 2021,
    author: 'Andy Weir',
    avgRating: 4.8,
    reviewCount: 3412,
  },
  // Movies
  {
    id: 'movie-1',
    title: 'Oppenheimer',
    subtitle: 'Christopher Nolan',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop',
    category: 'movies',
    year: 2023,
    director: 'Christopher Nolan',
    avgRating: 4.5,
    reviewCount: 8934,
  },
  {
    id: 'movie-2',
    title: 'Everything Everywhere',
    subtitle: 'Daniels',
    image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop',
    category: 'movies',
    year: 2022,
    director: 'Daniels',
    avgRating: 4.6,
    reviewCount: 6721,
  },
  {
    id: 'movie-3',
    title: 'Dune: Part Two',
    subtitle: 'Denis Villeneuve',
    image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=400&h=600&fit=crop',
    category: 'movies',
    year: 2024,
    director: 'Denis Villeneuve',
    avgRating: 4.7,
    reviewCount: 4523,
  },
  // Products
  {
    id: 'product-1',
    title: 'Sony WH-1000XM5',
    subtitle: 'Sony',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=600&fit=crop',
    category: 'products',
    brand: 'Sony',
    avgRating: 4.4,
    reviewCount: 2156,
  },
  {
    id: 'product-2',
    title: 'MacBook Pro M3',
    subtitle: 'Apple',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=600&fit=crop',
    category: 'products',
    brand: 'Apple',
    avgRating: 4.8,
    reviewCount: 3892,
  },
  {
    id: 'product-3',
    title: 'Kindle Paperwhite',
    subtitle: 'Amazon',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=600&fit=crop',
    category: 'products',
    brand: 'Amazon',
    avgRating: 4.5,
    reviewCount: 4127,
  },
];

export const dimensionsByCategory: Record<ReviewCategory, string[]> = {
  books: ['Writing Style', 'Plot', 'Characters', 'Pacing'],
  movies: ['Cinematography', 'Acting', 'Story', 'Soundtrack'],
  products: ['Quality', 'Value', 'Design', 'Usability'],
};

export const initialReviews: Review[] = [
  {
    id: 'review-1',
    userId: 'user-1',
    userName: 'Alex Chen',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    category: 'books',
    itemId: 'book-1',
    itemTitle: 'The Midnight Library',
    itemImage: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop',
    content: 'A beautiful meditation on life choices and regret. Haig writes with such warmth and empathy. The concept is simple but executed perfectly.',
    overallRating: 4,
    dimensions: [
      { name: 'Writing Style', value: 5 },
      { name: 'Plot', value: 4 },
      { name: 'Characters', value: 4 },
      { name: 'Pacing', value: 3 },
    ],
    likes: 42,
    isLiked: false,
    isSaved: true,
    createdAt: new Date('2024-12-15'),
    versions: [],
  },
  {
    id: 'review-2',
    userId: 'user-2',
    userName: 'Sarah Miller',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    category: 'movies',
    itemId: 'movie-1',
    itemTitle: 'Oppenheimer',
    itemImage: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop',
    content: 'Nolan delivers a masterpiece. The tension is incredible, and Cillian Murphy gives the performance of his career. IMAX is a must.',
    overallRating: 5,
    dimensions: [
      { name: 'Cinematography', value: 5 },
      { name: 'Acting', value: 5 },
      { name: 'Story', value: 5 },
      { name: 'Soundtrack', value: 4 },
    ],
    likes: 127,
    isLiked: true,
    isSaved: false,
    createdAt: new Date('2024-11-28'),
    versions: [],
  },
  {
    id: 'review-3',
    userId: 'user-3',
    userName: 'Marcus Lee',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    category: 'products',
    itemId: 'product-1',
    itemTitle: 'Sony WH-1000XM5',
    itemImage: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=600&fit=crop',
    content: 'Best noise cancellation I\'ve ever experienced. Comfortable for long sessions. Only downside is the non-folding design for travel.',
    overallRating: 4,
    dimensions: [
      { name: 'Quality', value: 5 },
      { name: 'Value', value: 4 },
      { name: 'Design', value: 4 },
      { name: 'Usability', value: 5 },
    ],
    likes: 89,
    isLiked: false,
    isSaved: false,
    createdAt: new Date('2024-12-01'),
    versions: [],
  },
  {
    id: 'review-4',
    userId: 'user-1',
    userName: 'Alex Chen',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    category: 'books',
    itemId: 'book-2',
    itemTitle: 'Atomic Habits',
    itemImage: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=600&fit=crop',
    content: 'Changed how I think about building good habits. The 1% improvement concept is powerful. Practical and immediately actionable.',
    overallRating: 5,
    dimensions: [
      { name: 'Writing Style', value: 4 },
      { name: 'Plot', value: 5 },
      { name: 'Characters', value: 4 },
      { name: 'Pacing', value: 5 },
    ],
    likes: 156,
    isLiked: true,
    isSaved: true,
    createdAt: new Date('2024-10-20'),
    versions: [],
  },
  {
    id: 'review-5',
    userId: 'user-4',
    userName: 'Emma Watson',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    category: 'movies',
    itemId: 'movie-2',
    itemTitle: 'Everything Everywhere',
    itemImage: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop',
    content: 'Wild, emotional, hilarious. A story about family wrapped in multiverse chaos. Michelle Yeoh deserved every award.',
    overallRating: 5,
    dimensions: [
      { name: 'Cinematography', value: 4 },
      { name: 'Acting', value: 5 },
      { name: 'Story', value: 5 },
      { name: 'Soundtrack', value: 4 },
    ],
    likes: 234,
    isLiked: false,
    isSaved: true,
    createdAt: new Date('2024-09-15'),
    versions: [],
  },
];

export const initialNotifications: Notification[] = [
  {
    id: 'notif-1',
    type: 'like',
    message: 'Sarah liked your review of "The Midnight Library"',
    reviewId: 'review-1',
    read: false,
    createdAt: new Date('2024-12-20'),
  },
  {
    id: 'notif-2',
    type: 'save',
    message: 'Marcus saved your review of "Atomic Habits"',
    reviewId: 'review-4',
    read: false,
    createdAt: new Date('2024-12-19'),
  },
  {
    id: 'notif-3',
    type: 'approval',
    message: 'Your review of "The Midnight Library" was approved',
    reviewId: 'review-1',
    read: true,
    createdAt: new Date('2024-12-15'),
  },
];
