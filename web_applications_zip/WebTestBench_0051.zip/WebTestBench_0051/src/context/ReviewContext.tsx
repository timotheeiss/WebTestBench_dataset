import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { 
  Review, 
  Notification, 
  ReviewCategory,
  ReviewVersion,
  initialReviews, 
  initialNotifications,
  currentUser,
  dimensionsByCategory,
} from '@/data/mockData';

interface ReviewContextType {
  reviews: Review[];
  notifications: Notification[];
  unreadCount: number;
  addReview: (review: Omit<Review, 'id' | 'createdAt' | 'versions' | 'likes' | 'isLiked' | 'isSaved'>) => void;
  updateReview: (reviewId: string, content: string, overallRating: number, dimensions: { name: string; value: number }[]) => void;
  toggleLike: (reviewId: string) => void;
  toggleSave: (reviewId: string) => void;
  markNotificationRead: (notificationId: string) => void;
  markAllNotificationsRead: () => void;
  getReviewsByCategory: (category: ReviewCategory) => Review[];
  getReviewsByUser: (userId: string) => Review[];
  getSavedReviews: () => Review[];
  searchReviews: (query: string) => Review[];
  getDraft: () => { content: string; itemId: string; category: ReviewCategory } | null;
  saveDraft: (content: string, itemId: string, category: ReviewCategory) => void;
  clearDraft: () => void;
  rollbackToVersion: (reviewId: string, versionId: string) => void;
}

const ReviewContext = createContext<ReviewContextType | undefined>(undefined);

export const ReviewProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [draft, setDraft] = useState<{ content: string; itemId: string; category: ReviewCategory } | null>(null);

  // Load draft from localStorage
  useEffect(() => {
    const savedDraft = localStorage.getItem('reviewDraft');
    if (savedDraft) {
      setDraft(JSON.parse(savedDraft));
    }
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const addReview = useCallback((reviewData: Omit<Review, 'id' | 'createdAt' | 'versions' | 'likes' | 'isLiked' | 'isSaved'>) => {
    const newReview: Review = {
      ...reviewData,
      id: `review-${Date.now()}`,
      createdAt: new Date(),
      versions: [],
      likes: 0,
      isLiked: false,
      isSaved: false,
    };
    setReviews(prev => [newReview, ...prev]);
    clearDraft();
  }, []);

  const updateReview = useCallback((reviewId: string, content: string, overallRating: number, dimensions: { name: string; value: number }[]) => {
    setReviews(prev => prev.map(review => {
      if (review.id === reviewId) {
        const newVersion: ReviewVersion = {
          id: `version-${Date.now()}`,
          content: review.content,
          timestamp: new Date(),
        };
        return {
          ...review,
          content,
          overallRating,
          dimensions,
          versions: [...review.versions, newVersion],
        };
      }
      return review;
    }));
  }, []);

  const rollbackToVersion = useCallback((reviewId: string, versionId: string) => {
    setReviews(prev => prev.map(review => {
      if (review.id === reviewId) {
        const version = review.versions.find(v => v.id === versionId);
        if (version) {
          return {
            ...review,
            content: version.content,
          };
        }
      }
      return review;
    }));
  }, []);

  const toggleLike = useCallback((reviewId: string) => {
    setReviews(prev => prev.map(review => {
      if (review.id === reviewId) {
        const newIsLiked = !review.isLiked;
        return {
          ...review,
          isLiked: newIsLiked,
          likes: newIsLiked ? review.likes + 1 : review.likes - 1,
        };
      }
      return review;
    }));
  }, []);

  const toggleSave = useCallback((reviewId: string) => {
    setReviews(prev => prev.map(review => {
      if (review.id === reviewId) {
        return {
          ...review,
          isSaved: !review.isSaved,
        };
      }
      return review;
    }));
  }, []);

  const markNotificationRead = useCallback((notificationId: string) => {
    setNotifications(prev => prev.map(n => 
      n.id === notificationId ? { ...n, read: true } : n
    ));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const getReviewsByCategory = useCallback((category: ReviewCategory) => {
    return reviews.filter(r => r.category === category);
  }, [reviews]);

  const getReviewsByUser = useCallback((userId: string) => {
    return reviews.filter(r => r.userId === userId);
  }, [reviews]);

  const getSavedReviews = useCallback(() => {
    return reviews.filter(r => r.isSaved);
  }, [reviews]);

  const searchReviews = useCallback((query: string) => {
    const lowerQuery = query.toLowerCase();
    return reviews.filter(r => 
      r.content.toLowerCase().includes(lowerQuery) ||
      r.itemTitle.toLowerCase().includes(lowerQuery) ||
      r.userName.toLowerCase().includes(lowerQuery)
    );
  }, [reviews]);

  const saveDraft = useCallback((content: string, itemId: string, category: ReviewCategory) => {
    const draftData = { content, itemId, category };
    setDraft(draftData);
    localStorage.setItem('reviewDraft', JSON.stringify(draftData));
  }, []);

  const getDraft = useCallback(() => draft, [draft]);

  const clearDraft = useCallback(() => {
    setDraft(null);
    localStorage.removeItem('reviewDraft');
  }, []);

  return (
    <ReviewContext.Provider value={{
      reviews,
      notifications,
      unreadCount,
      addReview,
      updateReview,
      toggleLike,
      toggleSave,
      markNotificationRead,
      markAllNotificationsRead,
      getReviewsByCategory,
      getReviewsByUser,
      getSavedReviews,
      searchReviews,
      getDraft,
      saveDraft,
      clearDraft,
      rollbackToVersion,
    }}>
      {children}
    </ReviewContext.Provider>
  );
};

export const useReviews = () => {
  const context = useContext(ReviewContext);
  if (!context) {
    throw new Error('useReviews must be used within a ReviewProvider');
  }
  return context;
};
