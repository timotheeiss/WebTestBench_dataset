import { useState, useEffect, useCallback } from "react";

const FAVORITES_KEY = "city-stories-favorites";

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(FAVORITES_KEY);
    if (stored) {
      try {
        setFavorites(JSON.parse(stored));
      } catch {
        setFavorites([]);
      }
    }
  }, []);

  const saveFavorites = useCallback((newFavorites: string[]) => {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
    setFavorites(newFavorites);
  }, []);

  const addFavorite = useCallback(
    (storyId: string) => {
      if (!favorites.includes(storyId)) {
        saveFavorites([...favorites, storyId]);
      }
    },
    [favorites, saveFavorites]
  );

  const removeFavorite = useCallback(
    (storyId: string) => {
      saveFavorites(favorites.filter((id) => id !== storyId));
    },
    [favorites, saveFavorites]
  );

  const toggleFavorite = useCallback(
    (storyId: string) => {
      if (favorites.includes(storyId)) {
        removeFavorite(storyId);
      } else {
        addFavorite(storyId);
      }
    },
    [favorites, addFavorite, removeFavorite]
  );

  const isFavorite = useCallback(
    (storyId: string) => favorites.includes(storyId),
    [favorites]
  );

  return {
    favorites,
    addFavorite,
    removeFavorite,
    toggleFavorite,
    isFavorite,
  };
}
