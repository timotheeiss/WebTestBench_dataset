export type TopicType = "history" | "food" | "festivals" | "neighborhoods" | "hidden-gems";

export interface TimelineEvent {
  year: string;
  title: string;
  description: string;
}

export interface Story {
  id: string;
  title: string;
  subtitle: string;
  excerpt: string;
  content: string;
  coverImage: string;
  images: string[];
  topics: TopicType[];
  readTime: number;
  audioUrl?: string;
  videoUrl?: string;
  timeline?: TimelineEvent[];
  featured?: boolean;
  collectionId?: string;
}

export interface Collection {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  storyIds: string[];
}

export const topics: { id: TopicType; label: string; icon: string }[] = [
  { id: "history", label: "History", icon: "🏛️" },
  { id: "food", label: "Food & Drink", icon: "🍝" },
  { id: "festivals", label: "Festivals", icon: "🎭" },
  { id: "neighborhoods", label: "Neighborhoods", icon: "🏘️" },
  { id: "hidden-gems", label: "Hidden Gems", icon: "💎" },
];

export const stories: Story[] = [
  {
    id: "ancient-roman-baths",
    title: "The Ancient Roman Baths",
    subtitle: "Where emperors once bathed",
    excerpt: "Discover the remnants of ancient Rome hidden beneath the modern city streets, where thermal waters still flow through millennia-old marble corridors.",
    content: `The thermal baths of ancient Rome were far more than mere bathing facilities—they were the social heartbeat of the empire. Beneath the bustling streets of today's city center lie the remarkably preserved remains of what was once the grandest bathhouse in the Roman world.

Walking through the subterranean chambers, you can almost hear the echoes of senators debating politics, merchants closing deals, and citizens discussing the affairs of the day. The ingenious engineering that heated these waters through hypocaust systems remains a marvel of ancient technology.

The complex featured a frigidarium (cold room), tepidarium (warm room), and caldarium (hot room), each designed to provide a complete wellness experience. Mosaics depicting Neptune and sea creatures still adorn portions of the original floors, their colors muted but undeniably magnificent.

Local guides recommend visiting in the early morning, when the underground chambers are quiet and the play of light through the ancient skylights creates an almost mystical atmosphere. The thermal springs that fed these baths still bubble up in certain spots, maintaining a constant temperature of 42°C as they have for millennia.`,
    coverImage: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1200",
    images: [
      "https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=800",
      "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?w=800",
      "https://images.unsplash.com/photo-1523365280197-f1783db9fe62?w=800",
    ],
    topics: ["history", "hidden-gems"],
    readTime: 8,
    timeline: [
      { year: "19 BC", title: "Construction Begins", description: "Emperor Augustus commissions the first public baths on this site" },
      { year: "64 AD", title: "Great Fire", description: "The original structure damaged but quickly rebuilt under Nero" },
      { year: "212 AD", title: "Golden Age", description: "Caracalla expands the baths to accommodate 1,600 bathers daily" },
      { year: "537 AD", title: "Waters Cut", description: "Gothic siege cuts the aqueducts, ending the baths' primary function" },
      { year: "1824", title: "Rediscovery", description: "Archaeological excavations reveal the preserved underground chambers" },
    ],
    featured: true,
    collectionId: "ancient-wonders",
  },
  {
    id: "street-food-odyssey",
    title: "A Street Food Odyssey",
    subtitle: "Tasting history one bite at a time",
    excerpt: "From sizzling supplì to creamy gelato, the city's street vendors carry on traditions that stretch back centuries.",
    content: `The aroma hits you before you see the cart—a intoxicating blend of frying rice balls and fresh basil that has drawn hungry travelers for generations. Street food here isn't just sustenance; it's edible history, a continuous thread connecting today's vendors to their medieval predecessors.

Start your journey in the old market quarter where Nonna Maria has been serving supplì al telefono since 1962. The name comes from the strings of mozzarella that stretch like telephone cords when you pull the fried rice balls apart. Her secret? A recipe passed down through four generations that includes a splash of her grandfather's wine.

Move through the cobblestone alleys to find the porchetta stands, where whole roasted pigs are carved to order and served on crusty bread with just a sprinkle of salt. The technique has remained unchanged since the Renaissance, though the vendors now accept credit cards.

No odyssey is complete without visiting the gelato artisans of the historic center. Forget the tourist shops with their artificially colored mountains of foam—the true masters keep their creations in covered steel containers, where flavors like pistachio from Bronte and fior di latte reveal themselves in subtle, authentic glory.`,
    coverImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200",
    images: [
      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800",
      "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800",
      "https://images.unsplash.com/photo-1499028344343-cd173ffc68a9?w=800",
    ],
    topics: ["food", "neighborhoods"],
    readTime: 6,
    featured: true,
    collectionId: "culinary-heritage",
  },
  {
    id: "carnival-of-masks",
    title: "The Carnival of Masks",
    subtitle: "Behind the elaborate facades",
    excerpt: "Each February, the city transforms into a living theater where centuries-old traditions of mystery and celebration take center stage.",
    content: `When the first masks appear in shop windows each January, the city begins its transformation. The Carnival isn't merely a festival—it's a metamorphosis, as the entire urban landscape becomes a stage for one of humanity's oldest theatrical traditions.

The origins trace back to 1162, when citizens celebrated a military victory with gatherings and festivities in the main square. Over centuries, the celebration evolved, absorbing influences from commedia dell'arte and becoming a time when social barriers temporarily dissolved behind the anonymity of masks.

Today's mask-makers, or mascherari, maintain workshops in the same neighborhoods where their craft flourished in the 18th century. Watch as they layer papier-mâché over clay molds, building up the structure that will become a character from the traditional cast: the long-nosed Plague Doctor, the melancholy Pierrot, the mischievous Arlecchino.

The two weeks of Carnival crescendo toward Fat Tuesday, when the population of the city seems to double overnight. Elaborate costumes fill every campo and calleway, and temporary stages host performances ranging from classical music to contemporary dance. The best strategy? Lose yourself in the labyrinth and let the celebration find you.`,
    coverImage: "https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=1200",
    images: [
      "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800",
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800",
    ],
    topics: ["festivals", "history"],
    readTime: 7,
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    collectionId: "living-traditions",
  },
  {
    id: "artisan-quarter",
    title: "The Artisan Quarter",
    subtitle: "Where craft meets community",
    excerpt: "In winding alleys untouched by time, master craftspeople continue traditions that defined the city's golden age.",
    content: `Turn left at the fountain of the four dolphins, duck under the medieval archway, and you've entered the Artisan Quarter—a neighborhood that tourism brochures rarely mention but locals consider the soul of the city.

Here, the rhythm of the day is set by the tap of cobbler's hammers and the whir of pottery wheels. The workshops—botteghe—have occupied these spaces for centuries, their expertise passed from master to apprentice in an unbroken chain that connects today's craftspeople to Renaissance predecessors.

Start at Signor Bernardini's leather workshop, where the air is thick with the scent of vegetable-tanned hides and beeswax. He makes everything from book covers to belts using techniques unchanged since the 15th century, his tools themselves family heirlooms.

Cross the small piazza to find the ceramicists' row, where artisans create the distinctive majolica tiles that adorn churches and palaces throughout the region. The geometric patterns and rich cobalt blues follow designs standardized in 1540, yet each piece bears the subtle imperfections that distinguish handcraft from machine production.

The quarter comes alive on Thursday evenings, when workshops stay open late and the community gathers for aperitivo in the small bars wedged between studios. This is when you'll hear the old stories—of master painters who mixed pigments in secret cellars, of apprentice rivalries, of pieces that found their way into royal collections.`,
    coverImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200",
    images: [
      "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=800",
      "https://images.unsplash.com/photo-1493106641515-6b5631de4bb9?w=800",
      "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=800",
    ],
    topics: ["neighborhoods", "hidden-gems"],
    readTime: 9,
    audioUrl: "/audio/artisan-quarter.mp3",
    featured: true,
    collectionId: "local-secrets",
  },
  {
    id: "wine-harvest-festival",
    title: "The Wine Harvest Festival",
    subtitle: "Grape crushing and golden afternoons",
    excerpt: "When autumn arrives, the surrounding hillsides come alive with the joyous traditions of the vendemmia.",
    content: `As September light turns golden and the summer tourists depart, a different kind of visitor arrives—those seeking the authentic ritual of the wine harvest, or vendemmia. The tradition stretches back to Etruscan times, making it one of the oldest continuously celebrated festivals in the Western world.

The surrounding hillsides, terraced with vines since Roman times, become a hive of activity as families gather to pick grapes by hand. Despite the availability of mechanical harvesters, most small producers insist on the traditional method, claiming that only human hands can properly select the ripest clusters.

The festival officially begins with the blessing of the first grapes at the Church of San Vincenzo, patron saint of winemakers. From there, a procession of decorated carts carries the harvest through the historic center to the ancient stone pressing houses, where the first juice of the season will flow.

For visitors, the highlight is often the grape-stomping competition held in the main piazza. Teams compete to extract the most juice in five minutes, their bare feet purple and their spirits high. The resulting must—cloudy and sweet—is offered to spectators as a foretaste of wines that will mature in cellars below the city streets.

The evenings bring sagre, community feasts where long tables fill the medieval streets and local families serve traditional dishes passed down through generations: wild boar stew, hand-rolled pasta, and of course, last year's vintage flowing freely.`,
    coverImage: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=1200",
    images: [
      "https://images.unsplash.com/photo-1516594915307-8f71e4aba4a5?w=800",
      "https://images.unsplash.com/photo-1560148218-1a83060f7b32?w=800",
    ],
    topics: ["festivals", "food"],
    readTime: 7,
    collectionId: "living-traditions",
  },
  {
    id: "midnight-bakeries",
    title: "The Midnight Bakeries",
    subtitle: "Following the scent of fresh bread",
    excerpt: "When the city sleeps, a hidden network of bakeries comes alive, producing the loaves that have sustained locals for generations.",
    content: `At 2 AM, most streets are silent. But follow your nose toward the industrial quarter, and you'll find windows glowing with the warm light of wood-fired ovens and the intoxicating aroma of bread in its final rise.

The midnight bakeries—forni di mezzanotte—are a tradition unique to this region. They supply the restaurants, markets, and households that expect their pane to be mere hours old. The bakers themselves are a breed apart, night owls who've adapted their lives to this inverted schedule.

Signora Lucia has been at her oven since 1978. Her specialty is pane casereccio, a rustic sourdough whose starter—the madre—is allegedly descended from one kept since 1923. She allows visitors to watch but not to help; the craft, she explains, requires decades to master.

The varieties produced each night follow a weekly rhythm unchanged for a century. Monday brings focaccia, Tuesday the ring-shaped ciambella, and Wednesday the olive-studded pane alle olive. Thursday night sees the production of special occasion loaves, from wedding breads twisted into symbolic shapes to the giant round pagnotte used in religious ceremonies.

Most forni welcome respectful visitors who arrive after 3 AM, when the most intense work is done. A few euros will buy you bread still warm from the oven, best eaten immediately while walking home through streets that are beginning to show the first light of dawn.`,
    coverImage: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1200",
    images: [
      "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=800",
      "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=800",
    ],
    topics: ["food", "hidden-gems"],
    readTime: 6,
    collectionId: "local-secrets",
  },
  {
    id: "bell-tower-keepers",
    title: "The Bell Tower Keepers",
    subtitle: "Guardians of time itself",
    excerpt: "High above the rooftops, a small group maintains the ancient bells that have marked the hours for eight centuries.",
    content: `The climb is 287 steps of worn stone, spiraling upward through narrow passages that open occasionally onto dizzying views of the city below. At the top waits Marco, the current keeper of the bells—a role his family has held since 1847.

The great bronze bells of the campanile were cast between the 12th and 14th centuries. Each has a name—Maria, Giuseppe, Paolo, and the massive 12-ton masterpiece known simply as La Nonna, the Grandmother. Their collective voice has announced births and deaths, victories and defeats, for longer than most nations have existed.

Marco's duties begin before dawn with an inspection of the mechanisms. The bells are rung both electrically for hourly timekeeping and manually for special occasions. It is the manual ringing—requiring perfect coordination of ropes, pulleys, and human muscle—that distinguishes great bell-keepers from mere technicians.

The most demanding tradition is the Easter ringing, when all four bells are sounded simultaneously in a complex pattern that requires a team of eight ringers working in precise choreography. Marco spends months training for this annual performance, recruiting helpers from a dwindling pool of those who know the old art.

Visitors who make the climb are rewarded not just with panoramic views but with Marco's stories of the bells' history: the lightning strike of 1764 that cracked Maria (repaired by a Dutch master), the German soldiers who nearly melted the bells for artillery in 1944 (hidden in a convent cellar), and the night when the death of a beloved pope was tolled until dawn.`,
    coverImage: "https://images.unsplash.com/photo-1564429238857-4b5912e6a71f?w=1200",
    images: [
      "https://images.unsplash.com/photo-1564429238984-df62e09c3de4?w=800",
      "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=800",
    ],
    topics: ["history", "hidden-gems"],
    readTime: 8,
    timeline: [
      { year: "1173", title: "First Bell", description: "Maria, the oldest surviving bell, is cast and raised" },
      { year: "1342", title: "La Nonna", description: "The great grandmother bell is installed" },
      { year: "1764", title: "Lightning Strike", description: "Maria is damaged and repaired" },
      { year: "1847", title: "Current Family", description: "The Rossi family begins their tenure as keepers" },
      { year: "1944", title: "The Hiding", description: "Bells hidden to prevent wartime destruction" },
    ],
    collectionId: "ancient-wonders",
  },
  {
    id: "jewish-quarter",
    title: "The Jewish Quarter",
    subtitle: "A thousand years of resilience",
    excerpt: "Within the old ghetto walls lies a community whose contributions to the city's culture run far deeper than most visitors realize.",
    content: `The narrow streets of the former ghetto have a different character from the rest of the historic center. Buildings rise higher here—a consequence of the 16th-century walls that once confined the Jewish population to this small area, forcing them to build upward when they couldn't expand outward.

Begin at the Synagogue, whose plain exterior conceals one of Europe's most beautiful prayer halls. The baroque interior, with its elaborate gilded ark and crystal chandeliers, speaks to the community's resilience—beauty created behind walls meant to isolate.

The community's history here predates the ghetto by several centuries. Jews served as physicians to popes, as translators who preserved ancient texts, and as merchants whose trading networks connected this city to communities across the Mediterranean. Their cultural influence permeates local cuisine, dialect, and customs in ways that even longtime residents don't always recognize.

Wander the streets during morning hours and you'll find the kosher bakeries producing the traditional Roman Jewish pastries—ricotta cakes, almond cookies, and the famous pizza ebraica, a dense fruit-and-nut confection that bears no resemblance to its namesake. These recipes, developed within ghetto walls, are now beloved citywide.

The community museum, housed in a former textile workshop, offers guided tours that contextualize the neighborhood within both local and broader Jewish European history. Evening programs often feature traditional music, lectures on Judeo-Roman culture, and cooking demonstrations that reveal the sophisticated fusion cuisine developed over a millennium.`,
    coverImage: "https://images.unsplash.com/photo-1558981852-426c6c22a060?w=1200",
    images: [
      "https://images.unsplash.com/photo-1529260830199-42c24126f198?w=800",
      "https://images.unsplash.com/photo-1569004680137-4de1f8b5b482?w=800",
    ],
    topics: ["neighborhoods", "history", "food"],
    readTime: 10,
    collectionId: "local-secrets",
  },
];

export const collections: Collection[] = [
  {
    id: "ancient-wonders",
    title: "Ancient Wonders",
    description: "Explore the remnants of civilizations past, from Roman baths to medieval towers",
    coverImage: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800",
    storyIds: ["ancient-roman-baths", "bell-tower-keepers"],
  },
  {
    id: "culinary-heritage",
    title: "Culinary Heritage",
    description: "A journey through centuries of flavor, tradition, and gastronomic innovation",
    coverImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800",
    storyIds: ["street-food-odyssey", "midnight-bakeries"],
  },
  {
    id: "living-traditions",
    title: "Living Traditions",
    description: "Celebrations and customs that have defined the city's spirit for generations",
    coverImage: "https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=800",
    storyIds: ["carnival-of-masks", "wine-harvest-festival"],
  },
  {
    id: "local-secrets",
    title: "Local Secrets",
    description: "Off the beaten path discoveries known only to those who truly know the city",
    coverImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
    storyIds: ["artisan-quarter", "midnight-bakeries", "jewish-quarter"],
  },
];

export const getStoryById = (id: string): Story | undefined => {
  return stories.find((story) => story.id === id);
};

export const getStoriesByCollection = (collectionId: string): Story[] => {
  return stories.filter((story) => story.collectionId === collectionId);
};

export const getStoriesByTopic = (topic: TopicType): Story[] => {
  return stories.filter((story) => story.topics.includes(topic));
};

export const getFeaturedStories = (): Story[] => {
  return stories.filter((story) => story.featured);
};

export const searchStories = (query: string): Story[] => {
  const lowercaseQuery = query.toLowerCase();
  return stories.filter(
    (story) =>
      story.title.toLowerCase().includes(lowercaseQuery) ||
      story.excerpt.toLowerCase().includes(lowercaseQuery) ||
      story.content.toLowerCase().includes(lowercaseQuery) ||
      story.topics.some((topic) => topic.includes(lowercaseQuery))
  );
};
