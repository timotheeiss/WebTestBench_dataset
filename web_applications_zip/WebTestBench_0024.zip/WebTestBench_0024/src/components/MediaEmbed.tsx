import { useState } from "react";
import { Play, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface MediaEmbedProps {
  type: "audio" | "video";
  src: string;
  title?: string;
}

export function MediaEmbed({ type, src, title }: MediaEmbedProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  if (type === "video") {
    return (
      <div className="relative aspect-video rounded-xl overflow-hidden bg-muted">
        {!isPlaying ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/50 to-transparent" />
            <Button
              onClick={() => setIsPlaying(true)}
              className="relative z-10 w-16 h-16 rounded-full gradient-warm shadow-glow hover:scale-110 transition-transform"
            >
              <Play className="w-6 h-6 text-primary-foreground ml-1" fill="currentColor" />
            </Button>
            {title && (
              <p className="absolute bottom-4 left-4 text-primary-foreground font-medium">{title}</p>
            )}
          </div>
        ) : (
          <iframe
            src={`${src}?autoplay=1`}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        )}
      </div>
    );
  }

  return (
    <div className="bg-secondary/50 rounded-xl p-4">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full gradient-sage flex items-center justify-center flex-shrink-0">
          <Volume2 className="w-5 h-5 text-secondary-foreground" />
        </div>
        <div className="flex-1">
          {title && <p className="font-medium text-foreground mb-1">{title}</p>}
          <p className="text-sm text-muted-foreground">Audio narration available</p>
        </div>
      </div>
      <audio controls className="w-full mt-4 accent-primary">
        <source src={src} type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>
    </div>
  );
}
