import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Clock, Heart } from "lucide-react";
import { Story, topics } from "@/data/stories";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface StoryCardProps {
  story: Story;
  isFavorite?: boolean;
  onToggleFavorite?: (id: string) => void;
  featured?: boolean;
  index?: number;
}

export function StoryCard({
  story,
  isFavorite = false,
  onToggleFavorite,
  featured = false,
  index = 0,
}: StoryCardProps) {
  const storyTopics = topics.filter((t) => story.topics.includes(t.id));

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className={cn(
        "group relative bg-card rounded-xl overflow-hidden shadow-soft hover:shadow-elevated transition-all duration-500",
        featured && "md:col-span-2 md:row-span-2"
      )}
    >
      <Link to={`/story/${story.id}`} className="block">
        {/* Image Container */}
        <div className={cn("relative overflow-hidden", featured ? "aspect-[16/9] md:aspect-[2/1]" : "aspect-[4/3]")}>
          <img
            src={story.coverImage}
            alt={story.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 gradient-overlay opacity-60" />
          
          {/* Topic Tags */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            {storyTopics.slice(0, 2).map((topic) => (
              <span
                key={topic.id}
                className="px-3 py-1 rounded-full bg-background/90 backdrop-blur-sm text-xs font-medium text-foreground"
              >
                {topic.icon} {topic.label}
              </span>
            ))}
          </div>

          {/* Read Time */}
          <div className="absolute bottom-4 left-4 flex items-center gap-1.5 text-primary-foreground/90 text-sm">
            <Clock className="w-4 h-4" />
            <span>{story.readTime} min read</span>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 md:p-6">
          <h3
            className={cn(
              "font-display font-semibold text-foreground leading-tight mb-2 group-hover:text-primary transition-colors",
              featured ? "text-2xl md:text-3xl" : "text-lg md:text-xl"
            )}
          >
            {story.title}
          </h3>
          <p className="text-sm text-muted-foreground italic mb-3">{story.subtitle}</p>
          <p
            className={cn(
              "text-muted-foreground line-clamp-2",
              featured ? "text-base" : "text-sm"
            )}
          >
            {story.excerpt}
          </p>
        </div>
      </Link>

      {/* Favorite Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={(e) => {
          e.preventDefault();
          onToggleFavorite?.(story.id);
        }}
        className={cn(
          "absolute top-4 right-4 w-10 h-10 rounded-full bg-background/90 backdrop-blur-sm hover:bg-background transition-all",
          isFavorite && "text-primary"
        )}
      >
        <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
      </Button>
    </motion.article>
  );
}
