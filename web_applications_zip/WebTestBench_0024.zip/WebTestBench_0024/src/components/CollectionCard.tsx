import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Collection, getStoriesByCollection } from "@/data/stories";

interface CollectionCardProps {
  collection: Collection;
  index?: number;
}

export function CollectionCard({ collection, index = 0 }: CollectionCardProps) {
  const storyCount = getStoriesByCollection(collection.id).length;

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <Link
        to={`/collection/${collection.id}`}
        className="group block relative bg-card rounded-xl overflow-hidden shadow-soft hover:shadow-elevated transition-all duration-500"
      >
        {/* Image */}
        <div className="relative aspect-[3/2] overflow-hidden">
          <img
            src={collection.coverImage}
            alt={collection.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 gradient-overlay opacity-70" />

          {/* Content Overlay */}
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <span className="text-primary-foreground/80 text-sm mb-2">
              {storyCount} {storyCount === 1 ? "story" : "stories"}
            </span>
            <h3 className="font-display text-2xl font-semibold text-primary-foreground mb-2">
              {collection.title}
            </h3>
            <p className="text-primary-foreground/90 text-sm line-clamp-2 mb-4">
              {collection.description}
            </p>
            <div className="flex items-center gap-2 text-primary-foreground text-sm font-medium group-hover:gap-3 transition-all">
              Explore collection
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}
