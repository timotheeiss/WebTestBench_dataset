import { motion } from "framer-motion";
import { topics, TopicType } from "@/data/stories";
import { cn } from "@/lib/utils";

interface TopicFilterProps {
  selectedTopics: TopicType[];
  onToggleTopic: (topic: TopicType) => void;
}

export function TopicFilter({ selectedTopics, onToggleTopic }: TopicFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {topics.map((topic) => {
        const isSelected = selectedTopics.includes(topic.id);
        return (
          <button
            key={topic.id}
            onClick={() => onToggleTopic(topic.id)}
            className={cn(
              "relative px-4 py-2 rounded-full text-sm font-medium transition-all duration-300",
              isSelected
                ? "text-primary-foreground"
                : "text-muted-foreground hover:text-foreground bg-muted hover:bg-secondary"
            )}
          >
            {isSelected && (
              <motion.div
                layoutId="selectedTopic"
                className="absolute inset-0 gradient-warm rounded-full"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <span className="relative z-10 flex items-center gap-2">
              <span>{topic.icon}</span>
              <span>{topic.label}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
