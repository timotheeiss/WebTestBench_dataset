import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ChevronUp } from "lucide-react";
import { TimelineEvent } from "@/data/stories";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface TimelineProps {
  events: TimelineEvent[];
}

export function Timeline({ events }: TimelineProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const displayEvents = isExpanded ? events : events.slice(0, 3);

  return (
    <div className="bg-secondary/50 rounded-xl p-6">
      <h3 className="font-display text-xl font-semibold text-foreground mb-6">Historical Timeline</h3>
      
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-border" />

        {/* Events */}
        <div className="space-y-6">
          <AnimatePresence mode="popLayout">
            {displayEvents.map((event, index) => (
              <motion.div
                key={event.year}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-8"
              >
                {/* Dot */}
                <div
                  className={cn(
                    "absolute left-0 top-1 w-6 h-6 rounded-full flex items-center justify-center",
                    index === 0 ? "gradient-warm" : "bg-muted border-2 border-border"
                  )}
                >
                  <div className={cn("w-2 h-2 rounded-full", index === 0 ? "bg-primary-foreground" : "bg-primary")} />
                </div>

                {/* Content */}
                <div>
                  <span className="inline-block px-2 py-0.5 rounded bg-primary/10 text-primary text-xs font-semibold mb-1">
                    {event.year}
                  </span>
                  <h4 className="font-semibold text-foreground">{event.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Expand/Collapse Button */}
        {events.length > 3 && (
          <Button
            variant="ghost"
            onClick={() => setIsExpanded(!isExpanded)}
            className="mt-4 w-full text-muted-foreground hover:text-foreground"
          >
            {isExpanded ? (
              <>
                Show less <ChevronUp className="ml-2 w-4 h-4" />
              </>
            ) : (
              <>
                Show {events.length - 3} more <ChevronDown className="ml-2 w-4 h-4" />
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}
