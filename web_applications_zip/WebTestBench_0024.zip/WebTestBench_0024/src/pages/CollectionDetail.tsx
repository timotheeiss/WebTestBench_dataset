import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Header } from "@/components/Header";
import { StoryCard } from "@/components/StoryCard";
import { Button } from "@/components/ui/button";
import { collections, getStoriesByCollection } from "@/data/stories";
import { useFavorites } from "@/hooks/useFavorites";

const CollectionDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { favorites, toggleFavorite, isFavorite } = useFavorites();

  const collection = collections.find((c) => c.id === id);
  const collectionStories = id ? getStoriesByCollection(id) : [];

  if (!collection) {
    return (
      <div className="min-h-screen bg-background">
        <Header favoritesCount={favorites.length} />
        <div className="container py-24 text-center">
          <h1 className="font-display text-3xl font-semibold text-foreground mb-4">
            Collection not found
          </h1>
          <p className="text-muted-foreground mb-8">
            The collection you're looking for doesn't exist.
          </p>
          <Button asChild>
            <Link to="/collections">View all collections</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header favoritesCount={favorites.length} />

      {/* Hero */}
      <div className="relative h-[40vh] md:h-[50vh] overflow-hidden">
        <motion.img
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1 }}
          src={collection.coverImage}
          alt={collection.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 gradient-overlay" />

        {/* Back Button */}
        <Link
          to="/collections"
          className="absolute top-6 left-6 flex items-center gap-2 px-4 py-2 rounded-full bg-background/90 backdrop-blur-sm text-foreground text-sm font-medium hover:bg-background transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Collections
        </Link>

        {/* Content Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="container">
            <span className="inline-block px-3 py-1 rounded-full bg-background/90 backdrop-blur-sm text-sm font-medium text-foreground mb-4">
              {collectionStories.length} {collectionStories.length === 1 ? "story" : "stories"}
            </span>
            <h1 className="font-display text-3xl md:text-5xl font-bold text-primary-foreground mb-3">
              {collection.title}
            </h1>
            <p className="text-lg text-primary-foreground/90 max-w-2xl">
              {collection.description}
            </p>
          </div>
        </div>
      </div>

      {/* Stories */}
      <main className="container py-12 md:py-16">
        {collectionStories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {collectionStories.map((story, index) => (
              <StoryCard
                key={story.id}
                story={story}
                index={index}
                isFavorite={isFavorite(story.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No stories in this collection yet.</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-semibold text-foreground">CityStories</h3>
              <p className="text-sm text-muted-foreground">Discover the soul of the city</p>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CityStories. Crafted with love for travelers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CollectionDetail;
