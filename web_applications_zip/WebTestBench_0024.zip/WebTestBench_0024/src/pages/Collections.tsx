import { motion } from "framer-motion";
import { Layers, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { CollectionCard } from "@/components/CollectionCard";
import { collections } from "@/data/stories";
import { useFavorites } from "@/hooks/useFavorites";

const Collections = () => {
  const { favorites } = useFavorites();

  return (
    <div className="min-h-screen bg-background">
      <Header favoritesCount={favorites.length} />

      <main className="container py-12 md:py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to explore
          </Link>

          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl gradient-sage flex items-center justify-center shadow-soft">
              <Layers className="w-7 h-7 text-secondary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground">
                Collections
              </h1>
              <p className="text-muted-foreground">
                Curated journeys through culture, history, and hidden treasures
              </p>
            </div>
          </div>
        </motion.div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {collections.map((collection, index) => (
            <CollectionCard key={collection.id} collection={collection} index={index} />
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-border mt-auto">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-semibold text-foreground">CityStories</h3>
              <p className="text-sm text-muted-foreground">Discover the soul of the city</p>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CityStories. Crafted with love for travelers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Collections;
