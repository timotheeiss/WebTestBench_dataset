import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Heart, Clock, Share2, MapPin } from "lucide-react";
import { Header } from "@/components/Header";
import { Timeline } from "@/components/Timeline";
import { ImageGallery } from "@/components/ImageGallery";
import { MediaEmbed } from "@/components/MediaEmbed";
import { StoryCard } from "@/components/StoryCard";
import { Button } from "@/components/ui/button";
import { getStoryById, stories, topics } from "@/data/stories";
import { useFavorites } from "@/hooks/useFavorites";
import { cn } from "@/lib/utils";

const StoryDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  
  const story = id ? getStoryById(id) : undefined;

  if (!story) {
    return (
      <div className="min-h-screen bg-background">
        <Header favoritesCount={favorites.length} />
        <div className="container py-24 text-center">
          <h1 className="font-display text-3xl font-semibold text-foreground mb-4">
            Story not found
          </h1>
          <p className="text-muted-foreground mb-8">
            The story you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link to="/">Return home</Link>
          </Button>
        </div>
      </div>
    );
  }

  const storyTopics = topics.filter((t) => story.topics.includes(t.id));
  const relatedStories = stories
    .filter((s) => s.id !== story.id && s.topics.some((t) => story.topics.includes(t)))
    .slice(0, 3);

  const handleShare = async () => {
    try {
      await navigator.share({
        title: story.title,
        text: story.excerpt,
        url: window.location.href,
      });
    } catch {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header favoritesCount={favorites.length} />

      {/* Hero Image */}
      <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
        <motion.img
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1 }}
          src={story.coverImage}
          alt={story.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 gradient-overlay" />
        
        {/* Back Button */}
        <Link
          to="/"
          className="absolute top-6 left-6 flex items-center gap-2 px-4 py-2 rounded-full bg-background/90 backdrop-blur-sm text-foreground text-sm font-medium hover:bg-background transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>

        {/* Content Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="container">
            {/* Topics */}
            <div className="flex flex-wrap gap-2 mb-4">
              {storyTopics.map((topic) => (
                <span
                  key={topic.id}
                  className="px-3 py-1 rounded-full bg-background/90 backdrop-blur-sm text-sm font-medium text-foreground"
                >
                  {topic.icon} {topic.label}
                </span>
              ))}
            </div>

            <h1 className="font-display text-3xl md:text-5xl font-bold text-primary-foreground mb-2">
              {story.title}
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/90 italic mb-4">
              {story.subtitle}
            </p>
            <div className="flex items-center gap-4 text-primary-foreground/80 text-sm">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                {story.readTime} min read
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <article className="container py-12 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Actions */}
            <div className="flex items-center gap-3 mb-8 pb-8 border-b border-border">
              <Button
                variant={isFavorite(story.id) ? "default" : "outline"}
                onClick={() => toggleFavorite(story.id)}
                className={cn(isFavorite(story.id) && "gradient-warm")}
              >
                <Heart className={cn("w-4 h-4 mr-2", isFavorite(story.id) && "fill-current")} />
                {isFavorite(story.id) ? "Saved" : "Save for later"}
              </Button>
              <Button variant="outline" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>

            {/* Intro */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-xl text-foreground leading-relaxed mb-8 font-medium"
            >
              {story.excerpt}
            </motion.p>

            {/* Body */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="prose prose-lg max-w-none"
            >
              {story.content.split("\n\n").map((paragraph, index) => (
                <p key={index} className="text-muted-foreground leading-relaxed mb-6">
                  {paragraph}
                </p>
              ))}
            </motion.div>

            {/* Video Embed */}
            {story.videoUrl && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-12"
              >
                <h3 className="font-display text-xl font-semibold text-foreground mb-4">
                  Watch the Story
                </h3>
                <MediaEmbed type="video" src={story.videoUrl} title={story.title} />
              </motion.div>
            )}

            {/* Audio Embed */}
            {story.audioUrl && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-12"
              >
                <h3 className="font-display text-xl font-semibold text-foreground mb-4">
                  Listen to the Story
                </h3>
                <MediaEmbed type="audio" src={story.audioUrl} title="Narrated by local guides" />
              </motion.div>
            )}

            {/* Image Gallery */}
            {story.images.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mt-12"
              >
                <h3 className="font-display text-xl font-semibold text-foreground mb-4">
                  Gallery
                </h3>
                <ImageGallery images={story.images} title={story.title} />
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1 space-y-8">
            {/* Timeline */}
            {story.timeline && story.timeline.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Timeline events={story.timeline} />
              </motion.div>
            )}

            {/* Quick Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-secondary/50 rounded-xl p-6"
            >
              <h3 className="font-display text-xl font-semibold text-foreground mb-4">
                Quick Info
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground">Location</p>
                    <p className="text-sm text-muted-foreground">Historic City Center</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground">Best Time to Visit</p>
                    <p className="text-sm text-muted-foreground">Morning or late afternoon</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </aside>
        </div>
      </article>

      {/* Related Stories */}
      {relatedStories.length > 0 && (
        <section className="py-16 bg-muted/30">
          <div className="container">
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-foreground mb-8">
              You might also enjoy
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedStories.map((relatedStory, index) => (
                <StoryCard
                  key={relatedStory.id}
                  story={relatedStory}
                  index={index}
                  isFavorite={isFavorite(relatedStory.id)}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-semibold text-foreground">CityStories</h3>
              <p className="text-sm text-muted-foreground">Discover the soul of the city</p>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CityStories. Crafted with love for travelers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default StoryDetail;
