import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { StoryCard } from "@/components/StoryCard";
import { CollectionCard } from "@/components/CollectionCard";
import { TopicFilter } from "@/components/TopicFilter";
import { Button } from "@/components/ui/button";
import { stories, collections, getFeaturedStories, TopicType, searchStories } from "@/data/stories";
import { useFavorites } from "@/hooks/useFavorites";

const Index = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTopics, setSelectedTopics] = useState<TopicType[]>([]);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();

  const featuredStories = getFeaturedStories();

  const filteredStories = useMemo(() => {
    let result = stories;

    if (searchQuery.trim()) {
      result = searchStories(searchQuery);
    }

    if (selectedTopics.length > 0) {
      result = result.filter((story) =>
        selectedTopics.some((topic) => story.topics.includes(topic))
      );
    }

    return result;
  }, [searchQuery, selectedTopics]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      // Scroll to stories section
      document.getElementById("stories")?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleToggleTopic = (topic: TopicType) => {
    setSelectedTopics((prev) =>
      prev.includes(topic) ? prev.filter((t) => t !== topic) : [...prev, topic]
    );
  };

  const handleHeaderSearch = (query: string) => {
    setSearchQuery(query);
    document.getElementById("stories")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onSearch={handleHeaderSearch} favoritesCount={favorites.length} />

      {/* Hero */}
      <HeroSection
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearch={handleSearch}
      />

      {/* Featured Stories */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-end justify-between mb-8"
          >
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
                Featured Stories
              </h2>
              <p className="text-muted-foreground">
                Curated tales that define the city's spirit
              </p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredStories.slice(0, 3).map((story, index) => (
              <StoryCard
                key={story.id}
                story={story}
                featured={index === 0}
                index={index}
                isFavorite={isFavorite(story.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Collections */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-end justify-between mb-8"
          >
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
                Collections
              </h2>
              <p className="text-muted-foreground">
                Themed journeys through culture and history
              </p>
            </div>
            <Button
              variant="ghost"
              onClick={() => navigate("/collections")}
              className="hidden md:flex text-primary"
            >
              View all <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {collections.map((collection, index) => (
              <CollectionCard key={collection.id} collection={collection} index={index} />
            ))}
          </div>

          <Button
            variant="outline"
            onClick={() => navigate("/collections")}
            className="w-full mt-6 md:hidden"
          >
            View all collections
          </Button>
        </div>
      </section>

      {/* All Stories */}
      <section id="stories" className="py-16 md:py-24">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-4">
              Explore Stories
            </h2>
            <TopicFilter selectedTopics={selectedTopics} onToggleTopic={handleToggleTopic} />
          </motion.div>

          {filteredStories.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStories.map((story, index) => (
                <StoryCard
                  key={story.id}
                  story={story}
                  index={index}
                  isFavorite={isFavorite(story.id)}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <p className="text-lg text-muted-foreground mb-4">
                No stories match your filters
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedTopics([]);
                }}
              >
                Clear filters
              </Button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-semibold text-foreground">CityStories</h3>
              <p className="text-sm text-muted-foreground">Discover the soul of the city</p>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CityStories. Crafted with love for travelers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
