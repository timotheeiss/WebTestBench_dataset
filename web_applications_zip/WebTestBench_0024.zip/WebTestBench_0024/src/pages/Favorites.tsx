import { motion } from "framer-motion";
import { Heart, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { StoryCard } from "@/components/StoryCard";
import { Button } from "@/components/ui/button";
import { stories } from "@/data/stories";
import { useFavorites } from "@/hooks/useFavorites";

const Favorites = () => {
  const { favorites, toggleFavorite, isFavorite } = useFavorites();

  const favoriteStories = stories.filter((story) => favorites.includes(story.id));

  return (
    <div className="min-h-screen bg-background">
      <Header favoritesCount={favorites.length} />

      <main className="container py-12 md:py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to explore
          </Link>

          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl gradient-warm flex items-center justify-center shadow-soft">
              <Heart className="w-7 h-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground">
                Your Favorites
              </h1>
              <p className="text-muted-foreground">
                {favoriteStories.length} {favoriteStories.length === 1 ? "story" : "stories"} saved for your trip
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stories Grid */}
        {favoriteStories.length > 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {favoriteStories.map((story, index) => (
              <StoryCard
                key={story.id}
                story={story}
                index={index}
                isFavorite={isFavorite(story.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-24"
          >
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
              <Heart className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="font-display text-2xl font-semibold text-foreground mb-3">
              No favorites yet
            </h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Start exploring and save stories you want to revisit during your trip. 
              They'll all appear here for easy access.
            </p>
            <Button asChild variant="hero" size="lg">
              <Link to="/">Start exploring</Link>
            </Button>
          </motion.div>
        )}
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-border mt-auto">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h3 className="font-display text-xl font-semibold text-foreground">CityStories</h3>
              <p className="text-sm text-muted-foreground">Discover the soul of the city</p>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 CityStories. Crafted with love for travelers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Favorites;
