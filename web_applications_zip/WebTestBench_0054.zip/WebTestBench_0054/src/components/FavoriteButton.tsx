import { Star } from 'lucide-react';
import { useAppStore } from '@/store/appStore';
import { cn } from '@/lib/utils';

interface FavoriteButtonProps {
  docId: string;
  className?: string;
}

export function FavoriteButton({ docId, className }: FavoriteButtonProps) {
  const { isFavorite, toggleFavorite } = useAppStore();
  const isActive = isFavorite(docId);

  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        toggleFavorite(docId);
      }}
      className={cn(
        'p-1.5 rounded-md transition-all duration-200 hover:bg-secondary',
        className
      )}
      aria-label={isActive ? 'Remove from favorites' : 'Add to favorites'}
    >
      <Star
        size={18}
        className={cn(
          'favorite-star transition-all duration-200',
          isActive && 'active'
        )}
      />
    </button>
  );
}
