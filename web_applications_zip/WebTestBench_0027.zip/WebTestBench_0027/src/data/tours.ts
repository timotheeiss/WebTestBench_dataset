export interface Exhibit {
  id: string;
  title: string;
  image: string;
  overview: string;
  deepDive: string;
  relatedItems: string[];
  quiz?: {
    question: string;
    options: string[];
    correctIndex: number;
  };
  timeline?: {
    year: string;
    event: string;
  }[];
}

export interface Room {
  id: string;
  name: string;
  description: string;
  image: string;
  exhibits: Exhibit[];
}

export interface Tour {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  coverImage: string;
  theme: string;
  period: string;
  culture: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  rooms: Room[];
  relatedTourIds: string[];
}

export const tours: Tour[] = [
  {
    id: 'ancient-egypt',
    title: 'Mysteries of Ancient Egypt',
    subtitle: 'Journey Through the Land of Pharaohs',
    description: 'Explore the magnificent temples, tombs, and treasures of ancient Egyptian civilization. From the pyramids of Giza to the Valley of the Kings, discover the secrets of one of history\'s most fascinating cultures.',
    coverImage: 'https://images.unsplash.com/photo-1539650116574-8efeb43e2750?w=1200',
    theme: 'Ancient Civilizations',
    period: 'Ancient (3000 BCE - 30 BCE)',
    culture: 'Egyptian',
    difficulty: 'Beginner',
    duration: '45 min',
    rooms: [
      {
        id: 'great-hall',
        name: 'The Great Hall of Pharaohs',
        description: 'Begin your journey in the grand entrance hall, surrounded by colossal statues of Egypt\'s most powerful rulers.',
        image: 'https://images.unsplash.com/photo-1608328520983-b9e56f893e2a?w=800',
        exhibits: [
          {
            id: 'ramesses-statue',
            title: 'Colossal Statue of Ramesses II',
            image: 'https://images.unsplash.com/photo-1568322445389-f64ac2515020?w=600',
            overview: 'This 10-meter granite statue depicts Ramesses II, often considered Egypt\'s most powerful pharaoh, who reigned for 66 years.',
            deepDive: 'Ramesses II (c. 1303-1213 BCE) was the third pharaoh of the Nineteenth Dynasty. He is often regarded as the most powerful and celebrated pharaoh of the Egyptian Empire. His reign saw numerous military campaigns, massive building projects, and the establishment of the first known peace treaty in history with the Hittites.',
            relatedItems: ['nefertari-bust', 'abu-simbel-model'],
            quiz: {
              question: 'How long did Ramesses II reign as pharaoh?',
              options: ['30 years', '45 years', '66 years', '80 years'],
              correctIndex: 2
            },
            timeline: [
              { year: '1303 BCE', event: 'Birth of Ramesses II' },
              { year: '1279 BCE', event: 'Becomes Pharaoh' },
              { year: '1274 BCE', event: 'Battle of Kadesh' },
              { year: '1213 BCE', event: 'Death of Ramesses II' }
            ]
          },
          {
            id: 'nefertari-bust',
            title: 'Bust of Queen Nefertari',
            image: 'https://images.unsplash.com/photo-1594736797933-d0501ba2fe65?w=600',
            overview: 'This exquisite painted limestone bust portrays Nefertari, the Great Royal Wife of Ramesses II and one of the best-known Egyptian queens.',
            deepDive: 'Nefertari Meritmut was the first of the Great Royal Wives of Ramesses II. She is one of the best known Egyptian queens, alongside Cleopatra, Nefertiti, and Hatshepsut. Her tomb in the Valley of the Queens is considered one of the most beautiful in all of Egypt.',
            relatedItems: ['ramesses-statue', 'hieroglyphic-panel']
          }
        ]
      },
      {
        id: 'tomb-chamber',
        name: 'The Tomb Chamber',
        description: 'Descend into a recreation of a royal tomb, complete with painted walls depicting the journey to the afterlife.',
        image: 'https://images.unsplash.com/photo-1553913861-c0fddf2619ee?w=800',
        exhibits: [
          {
            id: 'book-of-dead',
            title: 'The Book of the Dead',
            image: 'https://images.unsplash.com/photo-1461360370896-922624d12a74?w=600',
            overview: 'This papyrus scroll contains spells and instructions to guide the deceased through the underworld and into the afterlife.',
            deepDive: 'The Book of the Dead is an ancient Egyptian funerary text used from approximately 1550 BCE to 50 BCE. It consists of magic spells intended to assist a dead person\'s journey through the Duat, or underworld, and into the afterlife. The text was initially carved on the walls of tombs, but later was written on papyrus.',
            relatedItems: ['canopic-jars', 'scarab-amulet'],
            quiz: {
              question: 'What was the primary purpose of the Book of the Dead?',
              options: ['To record history', 'To guide souls to the afterlife', 'To teach hieroglyphics', 'To preserve food'],
              correctIndex: 1
            }
          },
          {
            id: 'canopic-jars',
            title: 'Canopic Jars Set',
            image: 'https://images.unsplash.com/photo-1599561046251-bfb9465b4c44?w=600',
            overview: 'These four alabaster jars were used to store and preserve the internal organs of the deceased for the afterlife.',
            deepDive: 'Canopic jars were used by the ancient Egyptians during the mummification process to store and preserve the viscera of their owner for the afterlife. They were commonly either carved from limestone or pottery. Each jar was associated with one of the Four Sons of Horus, who protected the organs.',
            relatedItems: ['book-of-dead', 'mummy-mask']
          }
        ]
      },
      {
        id: 'treasures-gallery',
        name: 'Treasury of the Pharaohs',
        description: 'Marvel at the golden treasures and precious artifacts that accompanied Egypt\'s rulers into eternity.',
        image: 'https://images.unsplash.com/photo-1569230516306-5a8cb5586399?w=800',
        exhibits: [
          {
            id: 'tutankhamun-mask',
            title: 'Golden Death Mask of Tutankhamun',
            image: 'https://images.unsplash.com/photo-1608328520983-b9e56f893e2a?w=600',
            overview: 'The iconic golden funerary mask of the young pharaoh Tutankhamun, weighing 11 kg of solid gold.',
            deepDive: 'The mask of Tutankhamun is a gold mask of the 18th-dynasty ancient Egyptian Pharaoh Tutankhamun. It was discovered by Howard Carter in 1925 and is now housed in the Egyptian Museum in Cairo. The mask is one of the most well-known works of art in the world.',
            relatedItems: ['scarab-necklace', 'royal-throne'],
            timeline: [
              { year: '1341 BCE', event: 'Birth of Tutankhamun' },
              { year: '1332 BCE', event: 'Becomes Pharaoh at age 9' },
              { year: '1323 BCE', event: 'Death of Tutankhamun' },
              { year: '1922 CE', event: 'Tomb discovered by Howard Carter' }
            ]
          }
        ]
      }
    ],
    relatedTourIds: ['greek-mythology', 'roman-empire']
  },
  {
    id: 'renaissance-masters',
    title: 'Renaissance Masters',
    subtitle: 'The Golden Age of European Art',
    description: 'Walk through the galleries of Florence, Rome, and Venice to witness the revolutionary works of Leonardo, Michelangelo, Raphael, and other masters who transformed the art world.',
    coverImage: 'https://images.unsplash.com/photo-1544531586-fde5298cdd40?w=1200',
    theme: 'Art History',
    period: 'Renaissance (1400-1600)',
    culture: 'European',
    difficulty: 'Intermediate',
    duration: '60 min',
    rooms: [
      {
        id: 'florentine-gallery',
        name: 'The Florentine Gallery',
        description: 'Experience the birthplace of the Renaissance through the masterpieces that emerged from the workshops of Florence.',
        image: 'https://images.unsplash.com/photo-1580136579312-94651dfd596d?w=800',
        exhibits: [
          {
            id: 'birth-of-venus',
            title: 'The Birth of Venus',
            image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600',
            overview: 'Botticelli\'s iconic masterpiece depicting the goddess Venus emerging from the sea as a fully grown woman.',
            deepDive: 'Painted by Sandro Botticelli around 1485, this tempera on canvas depicts the goddess Venus arriving at the shore after her birth. The painting is in the Uffizi Gallery in Florence, Italy. It depicts the goddess Venus arriving at the shore after her birth, when she had emerged from the sea fully-grown.',
            relatedItems: ['primavera', 'medici-portraits'],
            quiz: {
              question: 'Who commissioned The Birth of Venus?',
              options: ['The Pope', 'The Medici Family', 'The King of France', 'The Doge of Venice'],
              correctIndex: 1
            }
          },
          {
            id: 'david-sculpture',
            title: 'David by Michelangelo',
            image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600',
            overview: 'Michelangelo\'s 17-foot marble masterpiece representing the Biblical hero David, carved from a single block of marble.',
            deepDive: 'Created between 1501 and 1504, David is a masterpiece of Renaissance sculpture. The statue represents the Biblical hero David, a favoured subject in the art of Florence. It was originally commissioned for the Florence Cathedral but was instead placed in the Piazza della Signoria.',
            relatedItems: ['sistine-chapel', 'pieta']
          }
        ]
      },
      {
        id: 'vatican-rooms',
        name: 'The Vatican Chambers',
        description: 'Step into the private chambers of the Pope, adorned with Raphael\'s magnificent frescoes.',
        image: 'https://images.unsplash.com/photo-1533154683836-84ea7a0bc310?w=800',
        exhibits: [
          {
            id: 'school-of-athens',
            title: 'The School of Athens',
            image: 'https://images.unsplash.com/photo-1591197172062-c718f82aba20?w=600',
            overview: 'Raphael\'s fresco depicting the greatest philosophers, scientists, and mathematicians of classical antiquity.',
            deepDive: 'Painted between 1509 and 1511, The School of Athens is one of four frescoes in the Stanza della Segnatura in the Vatican. It represents Philosophy and features figures from classical antiquity, with Plato and Aristotle at the center.',
            relatedItems: ['sistine-chapel', 'last-judgment'],
            timeline: [
              { year: '1483', event: 'Birth of Raphael' },
              { year: '1508', event: 'Commissioned by Pope Julius II' },
              { year: '1511', event: 'Completion of The School of Athens' },
              { year: '1520', event: 'Death of Raphael' }
            ]
          }
        ]
      }
    ],
    relatedTourIds: ['impressionist-paris', 'ancient-egypt']
  },
  {
    id: 'impressionist-paris',
    title: 'Impressionist Paris',
    subtitle: 'Light, Color, and the Modern Eye',
    description: 'Stroll through 19th century Paris and discover how Monet, Renoir, Degas, and their contemporaries revolutionized the art world with their bold new vision.',
    coverImage: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=1200',
    theme: 'Art History',
    period: 'Modern (1860-1900)',
    culture: 'French',
    difficulty: 'Beginner',
    duration: '40 min',
    rooms: [
      {
        id: 'water-lilies-room',
        name: 'Monet\'s Water Gardens',
        description: 'Immerse yourself in the serene beauty of Giverny through Monet\'s magnificent water lily paintings.',
        image: 'https://images.unsplash.com/photo-1460627390041-532a28402358?w=800',
        exhibits: [
          {
            id: 'water-lilies',
            title: 'Water Lilies (Nymphéas)',
            image: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=600',
            overview: 'Part of Monet\'s famous series of approximately 250 oil paintings depicting his flower garden at Giverny.',
            deepDive: 'Claude Monet painted his famous Water Lilies series over the last 30 years of his life at his home in Giverny. The paintings capture his flower garden and Japanese-style water garden, featuring the water lilies that floated on his pond.',
            relatedItems: ['japanese-bridge', 'haystacks'],
            quiz: {
              question: 'How many Water Lilies paintings did Monet create?',
              options: ['About 50', 'About 100', 'About 250', 'About 500'],
              correctIndex: 2
            }
          }
        ]
      },
      {
        id: 'dance-hall',
        name: 'The Dance Hall',
        description: 'Experience the vibrant nightlife of Paris through Renoir\'s and Degas\' portrayals of dancers and celebrations.',
        image: 'https://images.unsplash.com/photo-1504898770365-14faca6a7320?w=800',
        exhibits: [
          {
            id: 'moulin-galette',
            title: 'Dance at Le Moulin de la Galette',
            image: 'https://images.unsplash.com/photo-1541367777708-7905fe3296c0?w=600',
            overview: 'Renoir\'s joyful depiction of Parisians dancing on a Sunday afternoon at the outdoor dance hall in Montmartre.',
            deepDive: 'Painted in 1876, this masterpiece captures the lively atmosphere of a typical Sunday afternoon at the original Moulin de la Galette, a windmill and guinguette near the top of Montmartre. The dappled sunlight filtering through the trees creates a warm, festive atmosphere.',
            relatedItems: ['ballet-class', 'absinthe']
          }
        ]
      }
    ],
    relatedTourIds: ['renaissance-masters', 'modern-architecture']
  },
  {
    id: 'greek-mythology',
    title: 'Realm of the Greek Gods',
    subtitle: 'Legends of Mount Olympus',
    description: 'Ascend to the heavens and explore the mythological world of ancient Greece. Meet the Olympian gods, witness epic battles, and discover the heroes who became legends.',
    coverImage: 'https://images.unsplash.com/photo-1603565816030-6b389eeb23cb?w=1200',
    theme: 'Mythology',
    period: 'Ancient (800 BCE - 31 BCE)',
    culture: 'Greek',
    difficulty: 'Beginner',
    duration: '50 min',
    rooms: [
      {
        id: 'olympus-throne',
        name: 'The Throne Room of Olympus',
        description: 'Enter the magnificent throne room where Zeus and the twelve Olympians hold court over mortals and gods alike.',
        image: 'https://images.unsplash.com/photo-1564399579883-451a5d44ec08?w=800',
        exhibits: [
          {
            id: 'zeus-throne',
            title: 'The Throne of Zeus',
            image: 'https://images.unsplash.com/photo-1583425921686-c5daf5f49e66?w=600',
            overview: 'The golden throne of the King of the Gods, from which he commands thunder and lightning and rules over all of Olympus.',
            deepDive: 'Zeus, the youngest son of the Titans Cronus and Rhea, became the supreme ruler of the gods after overthrowing his father. From his throne on Mount Olympus, he governed both gods and mortals, wielding his famous thunderbolts.',
            relatedItems: ['athena-shield', 'poseidon-trident'],
            quiz: {
              question: 'Who were Zeus\'s parents?',
              options: ['Uranus and Gaia', 'Cronus and Rhea', 'Hyperion and Theia', 'Oceanus and Tethys'],
              correctIndex: 1
            }
          }
        ]
      }
    ],
    relatedTourIds: ['ancient-egypt', 'roman-empire']
  },
  {
    id: 'roman-empire',
    title: 'Glory of Rome',
    subtitle: 'Rise and Legacy of an Empire',
    description: 'Walk the streets of ancient Rome at the height of its power. From the Colosseum to the Forum, experience the grandeur of the civilization that shaped the Western world.',
    coverImage: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1200',
    theme: 'Ancient Civilizations',
    period: 'Ancient (753 BCE - 476 CE)',
    culture: 'Roman',
    difficulty: 'Intermediate',
    duration: '55 min',
    rooms: [
      {
        id: 'colosseum',
        name: 'The Colosseum',
        description: 'Step into the largest amphitheater ever built, where gladiators fought for glory and emperors entertained the masses.',
        image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800',
        exhibits: [
          {
            id: 'gladiator-armor',
            title: 'Gladiator\'s Armor',
            image: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=600',
            overview: 'Complete armor set of a Roman gladiator, including helmet, shield, and sword, representing the brutal entertainment of imperial Rome.',
            deepDive: 'Gladiatorial combat was one of the most popular forms of entertainment in the Roman Empire. Gladiators were typically slaves, prisoners of war, or condemned criminals who were trained in specialized schools. Different types of gladiators had different armor and weapons.',
            relatedItems: ['emperor-bust', 'triumph-arch'],
            timeline: [
              { year: '264 BCE', event: 'First recorded gladiatorial games in Rome' },
              { year: '80 CE', event: 'Colosseum completed' },
              { year: '404 CE', event: 'Last gladiatorial games' },
              { year: '476 CE', event: 'Fall of the Western Roman Empire' }
            ]
          }
        ]
      }
    ],
    relatedTourIds: ['greek-mythology', 'ancient-egypt']
  },
  {
    id: 'modern-architecture',
    title: 'Modern Architecture Marvels',
    subtitle: 'Visionary Designs of the 20th Century',
    description: 'Explore the revolutionary buildings and designs that redefined architecture. From Bauhaus to Brutalism, discover how modern architects reimagined our built environment.',
    coverImage: 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?w=1200',
    theme: 'Architecture',
    period: 'Modern (1900-1980)',
    culture: 'International',
    difficulty: 'Advanced',
    duration: '65 min',
    rooms: [
      {
        id: 'bauhaus-studio',
        name: 'The Bauhaus Studio',
        description: 'Enter the revolutionary design school that merged art, craft, and technology to create the foundations of modern design.',
        image: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800',
        exhibits: [
          {
            id: 'wassily-chair',
            title: 'Wassily Chair by Marcel Breuer',
            image: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=600',
            overview: 'The iconic tubular steel chair that revolutionized furniture design and became a symbol of modernist aesthetics.',
            deepDive: 'Designed by Marcel Breuer in 1925-1926 while he was the head of the cabinet-making workshop at the Bauhaus, the Wassily Chair (Model B3) was one of the first tubular steel chairs. It was inspired by the frame of a bicycle.',
            relatedItems: ['barcelona-chair', 'farnsworth-house'],
            quiz: {
              question: 'What material innovation made the Wassily Chair revolutionary?',
              options: ['Plastic molding', 'Tubular steel', 'Bent plywood', 'Cast aluminum'],
              correctIndex: 1
            }
          }
        ]
      }
    ],
    relatedTourIds: ['impressionist-paris', 'renaissance-masters']
  }
];

export const themes = ['Ancient Civilizations', 'Art History', 'Mythology', 'Architecture'];
export const periods = ['Ancient (3000 BCE - 30 BCE)', 'Ancient (800 BCE - 31 BCE)', 'Ancient (753 BCE - 476 CE)', 'Renaissance (1400-1600)', 'Modern (1860-1900)', 'Modern (1900-1980)'];
export const cultures = ['Egyptian', 'European', 'French', 'Greek', 'Roman', 'International'];
export const difficulties = ['Beginner', 'Intermediate', 'Advanced'];
