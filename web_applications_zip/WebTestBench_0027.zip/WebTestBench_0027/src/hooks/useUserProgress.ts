import { useState, useEffect, useCallback } from 'react';

export interface TourProgress {
  tourId: string;
  currentRoomIndex: number;
  visitedExhibits: string[];
  completedQuizzes: string[];
  lastVisited: string;
  isComplete: boolean;
}

export interface UserProgress {
  bookmarkedTours: string[];
  tourProgress: Record<string, TourProgress>;
}

const STORAGE_KEY = 'culturverse-user-progress';

const defaultProgress: UserProgress = {
  bookmarkedTours: [],
  tourProgress: {},
};

export function useUserProgress() {
  const [progress, setProgress] = useState<UserProgress>(() => {
    if (typeof window === 'undefined') return defaultProgress;
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : defaultProgress;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  const toggleBookmark = useCallback((tourId: string) => {
    setProgress(prev => ({
      ...prev,
      bookmarkedTours: prev.bookmarkedTours.includes(tourId)
        ? prev.bookmarkedTours.filter(id => id !== tourId)
        : [...prev.bookmarkedTours, tourId],
    }));
  }, []);

  const isBookmarked = useCallback((tourId: string) => {
    return progress.bookmarkedTours.includes(tourId);
  }, [progress.bookmarkedTours]);

  const startOrResumeTour = useCallback((tourId: string) => {
    setProgress(prev => {
      if (prev.tourProgress[tourId]) {
        return {
          ...prev,
          tourProgress: {
            ...prev.tourProgress,
            [tourId]: {
              ...prev.tourProgress[tourId],
              lastVisited: new Date().toISOString(),
            },
          },
        };
      }
      return {
        ...prev,
        tourProgress: {
          ...prev.tourProgress,
          [tourId]: {
            tourId,
            currentRoomIndex: 0,
            visitedExhibits: [],
            completedQuizzes: [],
            lastVisited: new Date().toISOString(),
            isComplete: false,
          },
        },
      };
    });
  }, []);

  const updateRoomProgress = useCallback((tourId: string, roomIndex: number) => {
    setProgress(prev => ({
      ...prev,
      tourProgress: {
        ...prev.tourProgress,
        [tourId]: {
          ...prev.tourProgress[tourId],
          currentRoomIndex: roomIndex,
          lastVisited: new Date().toISOString(),
        },
      },
    }));
  }, []);

  const markExhibitVisited = useCallback((tourId: string, exhibitId: string) => {
    setProgress(prev => {
      const tourProg = prev.tourProgress[tourId];
      if (!tourProg) return prev;
      if (tourProg.visitedExhibits.includes(exhibitId)) return prev;
      return {
        ...prev,
        tourProgress: {
          ...prev.tourProgress,
          [tourId]: {
            ...tourProg,
            visitedExhibits: [...tourProg.visitedExhibits, exhibitId],
          },
        },
      };
    });
  }, []);

  const markQuizCompleted = useCallback((tourId: string, exhibitId: string) => {
    setProgress(prev => {
      const tourProg = prev.tourProgress[tourId];
      if (!tourProg) return prev;
      if (tourProg.completedQuizzes.includes(exhibitId)) return prev;
      return {
        ...prev,
        tourProgress: {
          ...prev.tourProgress,
          [tourId]: {
            ...tourProg,
            completedQuizzes: [...tourProg.completedQuizzes, exhibitId],
          },
        },
      };
    });
  }, []);

  const completeTour = useCallback((tourId: string) => {
    setProgress(prev => ({
      ...prev,
      tourProgress: {
        ...prev.tourProgress,
        [tourId]: {
          ...prev.tourProgress[tourId],
          isComplete: true,
          lastVisited: new Date().toISOString(),
        },
      },
    }));
  }, []);

  const getTourProgress = useCallback((tourId: string) => {
    return progress.tourProgress[tourId];
  }, [progress.tourProgress]);

  const getInProgressTours = useCallback(() => {
    return Object.values(progress.tourProgress).filter(p => !p.isComplete);
  }, [progress.tourProgress]);

  return {
    progress,
    toggleBookmark,
    isBookmarked,
    startOrResumeTour,
    updateRoomProgress,
    markExhibitVisited,
    markQuizCompleted,
    completeTour,
    getTourProgress,
    getInProgressTours,
  };
}
