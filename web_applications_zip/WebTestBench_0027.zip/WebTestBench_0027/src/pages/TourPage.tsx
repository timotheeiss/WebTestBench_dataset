import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, BookmarkIcon, Clock, Users, BarChart3, Trophy, CheckCircle } from 'lucide-react';
import { Header } from '@/components/Header';
import { RoomNavigator } from '@/components/RoomNavigator';
import { ExhibitGrid } from '@/components/ExhibitGrid';
import { ExhibitModal } from '@/components/ExhibitModal';
import { RelatedTours } from '@/components/RelatedTours';
import { tours, Exhibit } from '@/data/tours';
import { useUserProgress } from '@/hooks/useUserProgress';
import { cn } from '@/lib/utils';

const TourPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const tour = tours.find(t => t.id === id);
  
  const {
    isBookmarked,
    toggleBookmark,
    startOrResumeTour,
    updateRoomProgress,
    markExhibitVisited,
    markQuizCompleted,
    completeTour,
    getTourProgress,
  } = useUserProgress();

  const [selectedExhibit, setSelectedExhibit] = useState<Exhibit | null>(null);
  const [currentRoomIndex, setCurrentRoomIndex] = useState(0);
  const [showCompletion, setShowCompletion] = useState(false);

  const progress = getTourProgress(id || '');
  const bookmarked = isBookmarked(id || '');

  useEffect(() => {
    if (tour && id) {
      startOrResumeTour(id);
      if (progress?.currentRoomIndex !== undefined) {
        setCurrentRoomIndex(progress.currentRoomIndex);
      }
    }
  }, [id, tour]);

  useEffect(() => {
    if (id && currentRoomIndex !== progress?.currentRoomIndex) {
      updateRoomProgress(id, currentRoomIndex);
    }
  }, [currentRoomIndex, id]);

  if (!tour) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl font-semibold mb-4">Tour not found</h1>
          <Link to="/" className="text-primary hover:underline">
            Return to explore
          </Link>
        </div>
      </div>
    );
  }

  const currentRoom = tour.rooms[currentRoomIndex];
  const visitedExhibits = progress?.visitedExhibits || [];
  const completedQuizzes = progress?.completedQuizzes || [];

  const totalExhibits = tour.rooms.reduce((acc, room) => acc + room.exhibits.length, 0);
  const totalVisited = visitedExhibits.length;
  const progressPercentage = (totalVisited / totalExhibits) * 100;

  const handleExhibitClick = (exhibit: Exhibit) => {
    setSelectedExhibit(exhibit);
    if (id) {
      markExhibitVisited(id, exhibit.id);
    }
  };

  const handleQuizComplete = () => {
    if (id && selectedExhibit) {
      markQuizCompleted(id, selectedExhibit.id);
    }
  };

  const handleCompleteTour = () => {
    if (id) {
      completeTour(id);
      setShowCompletion(true);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'text-emerald-400';
      case 'Intermediate':
        return 'text-amber-400';
      case 'Advanced':
        return 'text-rose-400';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero */}
      <section className="relative pt-20 md:pt-24">
        <div className="relative h-64 md:h-80 lg:h-96 overflow-hidden">
          <img
            src={tour.coverImage}
            alt={tour.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
          
          <div className="absolute inset-x-0 bottom-0 container mx-auto px-4 pb-8">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Explore
            </Link>
            
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 mb-2 flex-wrap">
                  <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
                    {tour.theme}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-sm">
                    {tour.culture}
                  </span>
                </div>
                <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-2">
                  {tour.title}
                </h1>
                <p className="text-lg text-muted-foreground max-w-2xl">
                  {tour.subtitle}
                </p>
              </div>
              
              <button
                onClick={() => id && toggleBookmark(id)}
                className={cn(
                  "flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all shrink-0",
                  bookmarked
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-foreground hover:bg-secondary/80"
                )}
              >
                <BookmarkIcon className={cn("w-5 h-5", bookmarked && "fill-current")} />
                {bookmarked ? 'Saved' : 'Save Tour'}
              </button>
            </div>
          </div>
        </div>
      </section>

      <main className="container mx-auto px-4 py-8 md:py-12">
        {/* Tour Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-sm">Duration</span>
            </div>
            <p className="font-display text-xl font-semibold">{tour.duration}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Users className="w-4 h-4" />
              <span className="text-sm">Rooms</span>
            </div>
            <p className="font-display text-xl font-semibold">{tour.rooms.length}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <BarChart3 className="w-4 h-4" />
              <span className="text-sm">Difficulty</span>
            </div>
            <p className={cn("font-display text-xl font-semibold", getDifficultyColor(tour.difficulty))}>
              {tour.difficulty}
            </p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Trophy className="w-4 h-4" />
              <span className="text-sm">Progress</span>
            </div>
            <p className="font-display text-xl font-semibold text-primary">
              {Math.round(progressPercentage)}%
            </p>
          </div>
        </div>

        {/* Overall Progress Bar */}
        <div className="mb-10">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-muted-foreground">Tour Progress</span>
            <span className="text-foreground">{totalVisited}/{totalExhibits} exhibits viewed</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
            />
          </div>
          {progressPercentage === 100 && !progress?.isComplete && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={handleCompleteTour}
              className="mt-4 w-full py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Complete Tour
            </motion.button>
          )}
        </div>

        {/* Description */}
        <div className="mb-10">
          <h2 className="font-display text-xl font-semibold mb-3">About This Tour</h2>
          <p className="text-foreground/80 leading-relaxed">{tour.description}</p>
        </div>

        {/* Room Navigator */}
        <div className="mb-10">
          <RoomNavigator
            rooms={tour.rooms}
            currentRoomIndex={currentRoomIndex}
            onRoomChange={setCurrentRoomIndex}
            visitedExhibits={visitedExhibits}
          />
        </div>

        {/* Exhibits Grid */}
        <section className="mb-10">
          <h2 className="font-display text-xl font-semibold mb-6">
            Exhibits in {currentRoom.name}
          </h2>
          <ExhibitGrid
            exhibits={currentRoom.exhibits}
            visitedExhibits={visitedExhibits}
            completedQuizzes={completedQuizzes}
            onExhibitClick={handleExhibitClick}
          />
        </section>

        {/* Related Tours */}
        <RelatedTours tourIds={tour.relatedTourIds} />
      </main>

      {/* Exhibit Modal */}
      <ExhibitModal
        exhibit={selectedExhibit!}
        isOpen={!!selectedExhibit}
        onClose={() => setSelectedExhibit(null)}
        onQuizComplete={handleQuizComplete}
      />

      {/* Completion Modal */}
      {showCompletion && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
          onClick={() => setShowCompletion(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-card border border-border rounded-2xl p-8 max-w-md text-center"
          >
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
              <Trophy className="w-10 h-10 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-bold mb-2">Tour Complete!</h2>
            <p className="text-muted-foreground mb-6">
              Congratulations! You've explored all exhibits in {tour.title}.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowCompletion(false)}
                className="flex-1 py-3 bg-secondary text-foreground rounded-xl font-medium hover:bg-secondary/80 transition-colors"
              >
                Stay Here
              </button>
              <button
                onClick={() => navigate('/')}
                className="flex-1 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
              >
                Explore More
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 Culturverse. Explore the world's cultural heritage.</p>
        </div>
      </footer>
    </div>
  );
};

export default TourPage;
