import { motion } from 'framer-motion';
import { BookmarkIcon, Clock, Compass } from 'lucide-react';
import { Header } from '@/components/Header';
import { TourCard } from '@/components/TourCard';
import { tours } from '@/data/tours';
import { useUserProgress } from '@/hooks/useUserProgress';
import { Link } from 'react-router-dom';

const Bookmarks = () => {
  const { progress, getInProgressTours } = useUserProgress();
  
  const bookmarkedTours = tours.filter(tour => 
    progress.bookmarkedTours.includes(tour.id)
  );
  
  const inProgressTours = getInProgressTours();
  const inProgressTourData = inProgressTours
    .map(p => tours.find(t => t.id === p.tourId))
    .filter(Boolean);

  const completedTours = Object.values(progress.tourProgress)
    .filter(p => p.isComplete)
    .map(p => tours.find(t => t.id === p.tourId))
    .filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 pt-24 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
            My Collection
          </h1>
          <p className="text-muted-foreground">
            Your saved tours, progress, and completed journeys
          </p>
        </motion.div>

        {/* In Progress */}
        {inProgressTourData.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/10">
                <Clock className="w-5 h-5 text-primary" />
              </div>
              <h2 className="font-display text-2xl font-semibold">In Progress</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-secondary text-secondary-foreground text-sm">
                {inProgressTourData.length}
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {inProgressTourData.map((tour, index) => (
                <TourCard key={tour!.id} tour={tour!} index={index} />
              ))}
            </div>
          </section>
        )}

        {/* Bookmarked */}
        <section className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <BookmarkIcon className="w-5 h-5 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-semibold">Saved Tours</h2>
            <span className="px-2.5 py-0.5 rounded-full bg-secondary text-secondary-foreground text-sm">
              {bookmarkedTours.length}
            </span>
          </div>
          
          {bookmarkedTours.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bookmarkedTours.map((tour, index) => (
                <TourCard key={tour.id} tour={tour} index={index} />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16 bg-card border border-border rounded-xl"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                <BookmarkIcon className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-display text-xl font-semibold mb-2">No saved tours yet</h3>
              <p className="text-muted-foreground mb-4">
                Bookmark tours to find them easily later
              </p>
              <Link
                to="/"
                className="inline-flex items-center gap-2 text-primary hover:underline"
              >
                <Compass className="w-4 h-4" />
                Explore Tours
              </Link>
            </motion.div>
          )}
        </section>

        {/* Completed */}
        {completedTours.length > 0 && (
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <svg className="w-5 h-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="font-display text-2xl font-semibold">Completed</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-sm">
                {completedTours.length}
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {completedTours.map((tour, index) => (
                <TourCard key={tour!.id} tour={tour!} index={index} />
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 Culturverse. Explore the world's cultural heritage.</p>
        </div>
      </footer>
    </div>
  );
};

export default Bookmarks;
