import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Compass, Sparkles, Clock } from 'lucide-react';
import { Header } from '@/components/Header';
import { TourCard } from '@/components/TourCard';
import { SearchFilters } from '@/components/SearchFilters';
import { tours } from '@/data/tours';
import { useUserProgress } from '@/hooks/useUserProgress';
import { Link } from 'react-router-dom';

const Index = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    theme: '',
    period: '',
    culture: '',
    difficulty: '',
  });

  const { getInProgressTours } = useUserProgress();
  const inProgressTours = getInProgressTours();

  const filteredTours = useMemo(() => {
    return tours.filter(tour => {
      const matchesSearch = searchQuery === '' ||
        tour.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tour.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tour.theme.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tour.culture.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTheme = filters.theme === '' || tour.theme === filters.theme;
      const matchesPeriod = filters.period === '' || tour.period === filters.period;
      const matchesCulture = filters.culture === '' || tour.culture === filters.culture;
      const matchesDifficulty = filters.difficulty === '' || tour.difficulty === filters.difficulty;

      return matchesSearch && matchesTheme && matchesPeriod && matchesCulture && matchesDifficulty;
    });
  }, [searchQuery, filters]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({ theme: '', period: '', culture: '', difficulty: '' });
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 spotlight opacity-50" />
        <div className="container mx-auto px-4 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-6">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Discover World Heritage</span>
            </div>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Journey Through
              <span className="block text-gradient">Art & History</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Immerse yourself in interactive digital tours of the world's most fascinating museums, 
              galleries, and cultural landmarks.
            </p>
          </motion.div>
        </div>
      </section>

      <main className="container mx-auto px-4 pb-20">
        {/* In Progress Section */}
        {inProgressTours.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/10">
                <Clock className="w-5 h-5 text-primary" />
              </div>
              <h2 className="font-display text-2xl font-semibold">Continue Exploring</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {inProgressTours.slice(0, 3).map(progress => {
                const tour = tours.find(t => t.id === progress.tourId);
                if (!tour) return null;
                return <TourCard key={tour.id} tour={tour} />;
              })}
            </div>
          </section>
        )}

        {/* Search & Filters */}
        <section className="mb-10">
          <SearchFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedFilters={filters}
            onFilterChange={handleFilterChange}
            onClearFilters={clearFilters}
          />
        </section>

        {/* Tours Grid */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Compass className="w-5 h-5 text-primary" />
              </div>
              <h2 className="font-display text-2xl font-semibold">
                {filteredTours.length} {filteredTours.length === 1 ? 'Tour' : 'Tours'} Available
              </h2>
            </div>
          </div>

          {filteredTours.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTours.map((tour, index) => (
                <TourCard key={tour.id} tour={tour} index={index} />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                <Compass className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-display text-xl font-semibold mb-2">No tours found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search or filters
              </p>
              <button
                onClick={clearFilters}
                className="text-primary hover:underline"
              >
                Clear all filters
              </button>
            </motion.div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 Culturverse. Explore the world's cultural heritage.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
