import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, X, ChevronDown } from 'lucide-react';
import { themes, periods, cultures, difficulties } from '@/data/tours';
import { cn } from '@/lib/utils';

interface SearchFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedFilters: {
    theme: string;
    period: string;
    culture: string;
    difficulty: string;
  };
  onFilterChange: (key: string, value: string) => void;
  onClearFilters: () => void;
}

export function SearchFilters({
  searchQuery,
  onSearchChange,
  selectedFilters,
  onFilterChange,
  onClearFilters,
}: SearchFiltersProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const hasActiveFilters = Object.values(selectedFilters).some(v => v !== '');

  const FilterSelect = ({ 
    label, 
    value, 
    options, 
    filterKey 
  }: { 
    label: string; 
    value: string; 
    options: string[]; 
    filterKey: string;
  }) => (
    <div className="relative">
      <label className="block text-xs text-muted-foreground mb-1.5">{label}</label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onFilterChange(filterKey, e.target.value)}
          className="w-full appearance-none bg-secondary border border-border rounded-lg px-3 py-2.5 pr-8 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer"
        >
          <option value="">All {label}s</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
        <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search tours, themes, cultures..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-secondary border border-border rounded-xl pl-12 pr-4 py-3.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
          />
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={cn(
            "flex items-center gap-2 px-5 py-3.5 rounded-xl border transition-all",
            isExpanded || hasActiveFilters
              ? "bg-primary text-primary-foreground border-primary"
              : "bg-secondary text-foreground border-border hover:border-primary/50"
          )}
        >
          <Filter className="w-4 h-4" />
          <span className="font-medium">Filters</span>
          {hasActiveFilters && (
            <span className="w-5 h-5 rounded-full bg-primary-foreground/20 text-xs flex items-center justify-center">
              {Object.values(selectedFilters).filter(v => v !== '').length}
            </span>
          )}
        </button>
      </div>

      {/* Filter Panel */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="p-5 bg-card border border-border rounded-xl">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <FilterSelect
                  label="Theme"
                  value={selectedFilters.theme}
                  options={themes}
                  filterKey="theme"
                />
                <FilterSelect
                  label="Period"
                  value={selectedFilters.period}
                  options={periods}
                  filterKey="period"
                />
                <FilterSelect
                  label="Culture"
                  value={selectedFilters.culture}
                  options={cultures}
                  filterKey="culture"
                />
                <FilterSelect
                  label="Difficulty"
                  value={selectedFilters.difficulty}
                  options={difficulties}
                  filterKey="difficulty"
                />
              </div>
              
              {hasActiveFilters && (
                <button
                  onClick={onClearFilters}
                  className="mt-4 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-4 h-4" />
                  Clear all filters
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
