import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { tours } from '@/data/tours';

interface RelatedToursProps {
  tourIds: string[];
}

export function RelatedTours({ tourIds }: RelatedToursProps) {
  const relatedTours = tours.filter(tour => tourIds.includes(tour.id));

  if (relatedTours.length === 0) return null;

  return (
    <section className="mt-16 pt-12 border-t border-border">
      <h2 className="font-display text-2xl font-semibold mb-6">
        Continue Your Journey
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {relatedTours.map((tour, index) => (
          <motion.div
            key={tour.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Link
              to={`/tour/${tour.id}`}
              className="group block bg-card border border-border rounded-xl overflow-hidden transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_30px_rgba(200,170,100,0.1)]"
            >
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={tour.coverImage}
                  alt={tour.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              </div>
              <div className="p-4">
                <span className="text-xs text-primary font-medium uppercase tracking-wider">
                  {tour.theme}
                </span>
                <h3 className="font-display text-lg font-semibold mt-1 text-foreground group-hover:text-primary transition-colors">
                  {tour.title}
                </h3>
                <div className="flex items-center gap-1.5 mt-3 text-sm text-muted-foreground group-hover:text-primary transition-colors">
                  <span>Explore tour</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
