import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { Room } from '@/data/tours';
import { cn } from '@/lib/utils';

interface RoomNavigatorProps {
  rooms: Room[];
  currentRoomIndex: number;
  onRoomChange: (index: number) => void;
  visitedExhibits: string[];
}

export function RoomNavigator({
  rooms,
  currentRoomIndex,
  onRoomChange,
  visitedExhibits,
}: RoomNavigatorProps) {
  const currentRoom = rooms[currentRoomIndex];

  const getRoomProgress = (room: Room) => {
    const totalExhibits = room.exhibits.length;
    const visited = room.exhibits.filter(e => visitedExhibits.includes(e.id)).length;
    return { visited, total: totalExhibits, percentage: (visited / totalExhibits) * 100 };
  };

  return (
    <div className="space-y-6">
      {/* Room Progress Dots */}
      <div className="flex items-center justify-center gap-2">
        {rooms.map((room, index) => {
          const progress = getRoomProgress(room);
          const isActive = index === currentRoomIndex;
          const isComplete = progress.percentage === 100;

          return (
            <button
              key={room.id}
              onClick={() => onRoomChange(index)}
              className="group relative"
            >
              <div
                className={cn(
                  "w-3 h-3 rounded-full transition-all duration-300",
                  isActive
                    ? "bg-primary scale-125"
                    : isComplete
                      ? "bg-emerald-500"
                      : progress.visited > 0
                        ? "bg-primary/50"
                        : "bg-muted"
                )}
              />
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                <span className="text-xs text-muted-foreground bg-popover px-2 py-1 rounded">
                  {room.name}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onRoomChange(currentRoomIndex - 1)}
          disabled={currentRoomIndex === 0}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 rounded-lg transition-all",
            currentRoomIndex === 0
              ? "text-muted-foreground/50 cursor-not-allowed"
              : "text-foreground hover:bg-secondary"
          )}
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="hidden sm:inline">Previous Room</span>
        </button>

        <div className="text-center">
          <div className="flex items-center gap-2 text-primary">
            <MapPin className="w-4 h-4" />
            <span className="text-sm font-medium">
              Room {currentRoomIndex + 1} of {rooms.length}
            </span>
          </div>
        </div>

        <button
          onClick={() => onRoomChange(currentRoomIndex + 1)}
          disabled={currentRoomIndex === rooms.length - 1}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 rounded-lg transition-all",
            currentRoomIndex === rooms.length - 1
              ? "text-muted-foreground/50 cursor-not-allowed"
              : "text-foreground hover:bg-secondary"
          )}
        >
          <span className="hidden sm:inline">Next Room</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Current Room Info */}
      <motion.div
        key={currentRoom.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card border border-border rounded-xl overflow-hidden"
      >
        <div className="relative h-48 md:h-64">
          <img
            src={currentRoom.image}
            alt={currentRoom.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="font-display text-2xl font-semibold text-foreground mb-1">
              {currentRoom.name}
            </h3>
            <p className="text-sm text-muted-foreground">
              {currentRoom.exhibits.length} exhibits
            </p>
          </div>
        </div>
        <div className="p-4">
          <p className="text-foreground/80">{currentRoom.description}</p>
          
          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Progress</span>
              <span className="text-primary">
                {getRoomProgress(currentRoom).visited}/{getRoomProgress(currentRoom).total}
              </span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${getRoomProgress(currentRoom).percentage}%` }}
                className="h-full bg-primary rounded-full"
              />
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
