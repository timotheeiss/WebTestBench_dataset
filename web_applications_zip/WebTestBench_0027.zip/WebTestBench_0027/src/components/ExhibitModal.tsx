import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, BookOpen, Clock, HelpCircle, Check, AlertCircle } from 'lucide-react';
import { Exhibit } from '@/data/tours';
import { cn } from '@/lib/utils';

interface ExhibitModalProps {
  exhibit: Exhibit;
  isOpen: boolean;
  onClose: () => void;
  onQuizComplete?: () => void;
}

type TabType = 'overview' | 'deepDive' | 'timeline' | 'quiz';

export function ExhibitModal({ exhibit, isOpen, onClose, onQuizComplete }: ExhibitModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleQuizSubmit = () => {
    setShowResult(true);
    if (selectedAnswer === exhibit?.quiz?.correctIndex) {
      onQuizComplete?.();
    }
  };

  const resetQuiz = () => {
    setSelectedAnswer(null);
    setShowResult(false);
  };

  // Early return if no exhibit - must be after all hooks
  if (!exhibit) return null;

  const tabs = [
    { id: 'overview' as TabType, label: 'Overview', icon: BookOpen },
    { id: 'deepDive' as TabType, label: 'Deep Dive', icon: ChevronRight },
    ...(exhibit.timeline ? [{ id: 'timeline' as TabType, label: 'Timeline', icon: Clock }] : []),
    ...(exhibit.quiz ? [{ id: 'quiz' as TabType, label: 'Quiz', icon: HelpCircle }] : []),
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:inset-10 lg:inset-20 z-50 overflow-hidden"
          >
            <div className="h-full bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col">
              {/* Header */}
              <div className="relative h-48 md:h-64 overflow-hidden shrink-0">
                <img
                  src={exhibit.image}
                  alt={exhibit.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                <button
                  onClick={onClose}
                  className="absolute top-4 right-4 p-2.5 rounded-full bg-background/80 backdrop-blur-sm text-foreground hover:bg-background transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-4 left-6 right-6">
                  <h2 className="font-display text-2xl md:text-3xl font-semibold text-foreground">
                    {exhibit.title}
                  </h2>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-border shrink-0 overflow-x-auto">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      if (tab.id === 'quiz') resetQuiz();
                    }}
                    className={cn(
                      "flex items-center gap-2 px-5 py-4 text-sm font-medium transition-colors whitespace-nowrap",
                      activeTab === tab.id
                        ? "text-primary border-b-2 border-primary"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <tab.icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-6">
                <AnimatePresence mode="wait">
                  {activeTab === 'overview' && (
                    <motion.div
                      key="overview"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="prose prose-invert max-w-none"
                    >
                      <p className="text-foreground/90 text-lg leading-relaxed">
                        {exhibit.overview}
                      </p>
                    </motion.div>
                  )}

                  {activeTab === 'deepDive' && (
                    <motion.div
                      key="deepDive"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="prose prose-invert max-w-none"
                    >
                      <p className="text-foreground/90 text-lg leading-relaxed">
                        {exhibit.deepDive}
                      </p>
                      {exhibit.relatedItems.length > 0 && (
                        <div className="mt-6 pt-6 border-t border-border">
                          <h4 className="text-sm font-medium text-muted-foreground mb-3">
                            Related Items
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {exhibit.relatedItems.map((item) => (
                              <span
                                key={item}
                                className="px-3 py-1.5 bg-secondary rounded-full text-sm text-secondary-foreground"
                              >
                                {item.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {activeTab === 'timeline' && exhibit.timeline && (
                    <motion.div
                      key="timeline"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                    >
                      <div className="relative">
                        <div className="absolute left-3 top-2 bottom-2 w-0.5 bg-border" />
                        <div className="space-y-6">
                          {exhibit.timeline.map((event, index) => (
                            <motion.div
                              key={event.year}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="relative pl-10"
                            >
                              <div className="absolute left-0 w-6 h-6 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center">
                                <div className="w-2 h-2 rounded-full bg-primary" />
                              </div>
                              <div className="bg-secondary rounded-lg p-4">
                                <span className="text-primary font-semibold text-sm">
                                  {event.year}
                                </span>
                                <p className="text-foreground mt-1">{event.event}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === 'quiz' && exhibit.quiz && (
                    <motion.div
                      key="quiz"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                    >
                      <h3 className="font-display text-xl font-semibold mb-6">
                        {exhibit.quiz.question}
                      </h3>
                      <div className="space-y-3">
                        {exhibit.quiz.options.map((option, index) => {
                          const isCorrect = index === exhibit.quiz!.correctIndex;
                          const isSelected = selectedAnswer === index;
                          
                          return (
                            <button
                              key={index}
                              onClick={() => !showResult && setSelectedAnswer(index)}
                              disabled={showResult}
                              className={cn(
                                "w-full text-left p-4 rounded-xl border transition-all",
                                showResult
                                  ? isCorrect
                                    ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                                    : isSelected
                                      ? "bg-destructive/20 border-destructive text-destructive"
                                      : "bg-secondary border-border text-muted-foreground"
                                  : isSelected
                                    ? "bg-primary/20 border-primary"
                                    : "bg-secondary border-border hover:border-primary/50"
                              )}
                            >
                              <div className="flex items-center justify-between">
                                <span>{option}</span>
                                {showResult && isCorrect && (
                                  <Check className="w-5 h-5 text-emerald-400" />
                                )}
                                {showResult && isSelected && !isCorrect && (
                                  <AlertCircle className="w-5 h-5 text-destructive" />
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      
                      {!showResult && selectedAnswer !== null && (
                        <motion.button
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          onClick={handleQuizSubmit}
                          className="mt-6 w-full py-3.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
                        >
                          Submit Answer
                        </motion.button>
                      )}

                      {showResult && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={cn(
                            "mt-6 p-4 rounded-xl text-center",
                            selectedAnswer === exhibit.quiz.correctIndex
                              ? "bg-emerald-500/20 text-emerald-400"
                              : "bg-destructive/20 text-destructive"
                          )}
                        >
                          {selectedAnswer === exhibit.quiz.correctIndex
                            ? "🎉 Correct! Well done!"
                            : "Not quite. The correct answer is highlighted above."}
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
