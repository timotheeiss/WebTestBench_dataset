import { motion } from 'framer-motion';
import { Eye, Check, HelpCircle } from 'lucide-react';
import { Exhibit } from '@/data/tours';
import { cn } from '@/lib/utils';

interface ExhibitGridProps {
  exhibits: Exhibit[];
  visitedExhibits: string[];
  completedQuizzes: string[];
  onExhibitClick: (exhibit: Exhibit) => void;
}

export function ExhibitGrid({
  exhibits,
  visitedExhibits,
  completedQuizzes,
  onExhibitClick,
}: ExhibitGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {exhibits.map((exhibit, index) => {
        const isVisited = visitedExhibits.includes(exhibit.id);
        const hasQuiz = !!exhibit.quiz;
        const quizCompleted = completedQuizzes.includes(exhibit.id);

        return (
          <motion.button
            key={exhibit.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onExhibitClick(exhibit)}
            className="group relative bg-card border border-border rounded-xl overflow-hidden text-left transition-all duration-300 hover:border-primary/50 hover:shadow-[0_0_30px_rgba(200,170,100,0.1)]"
          >
            {/* Image */}
            <div className="relative aspect-[4/3] overflow-hidden">
              <img
                src={exhibit.image}
                alt={exhibit.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              
              {/* Status Badges */}
              <div className="absolute top-2 right-2 flex gap-1.5">
                {isVisited && (
                  <div className="w-7 h-7 rounded-full bg-emerald-500/90 flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
                {hasQuiz && (
                  <div className={cn(
                    "w-7 h-7 rounded-full flex items-center justify-center",
                    quizCompleted ? "bg-primary" : "bg-secondary"
                  )}>
                    <HelpCircle className={cn(
                      "w-4 h-4",
                      quizCompleted ? "text-primary-foreground" : "text-muted-foreground"
                    )} />
                  </div>
                )}
              </div>

              {/* View Overlay */}
              <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-background/90 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-primary" />
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              <h4 className="font-display text-lg font-medium text-foreground group-hover:text-primary transition-colors line-clamp-2">
                {exhibit.title}
              </h4>
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2">
                {exhibit.overview}
              </p>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}
