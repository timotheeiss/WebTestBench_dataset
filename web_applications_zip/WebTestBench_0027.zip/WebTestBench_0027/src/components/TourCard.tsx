import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Clock, BookmarkIcon, Check, Play } from 'lucide-react';
import { Tour } from '@/data/tours';
import { useUserProgress } from '@/hooks/useUserProgress';
import { cn } from '@/lib/utils';

interface TourCardProps {
  tour: Tour;
  index?: number;
}

export function TourCard({ tour, index = 0 }: TourCardProps) {
  const { isBookmarked, toggleBookmark, getTourProgress } = useUserProgress();
  const bookmarked = isBookmarked(tour.id);
  const progress = getTourProgress(tour.id);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'bg-emerald-500/20 text-emerald-400';
      case 'Intermediate':
        return 'bg-amber-500/20 text-amber-400';
      case 'Advanced':
        return 'bg-rose-500/20 text-rose-400';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative"
    >
      <Link to={`/tour/${tour.id}`} className="block">
        <div className="relative overflow-hidden rounded-xl bg-card border border-border/50 transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_30px_rgba(200,170,100,0.1)]">
          {/* Image Container */}
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={tour.coverImage}
              alt={tour.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
            
            {/* Bookmark Button */}
            <button
              onClick={(e) => {
                e.preventDefault();
                toggleBookmark(tour.id);
              }}
              className={cn(
                "absolute top-3 right-3 p-2.5 rounded-full transition-all duration-200",
                bookmarked
                  ? "bg-primary text-primary-foreground"
                  : "bg-background/80 backdrop-blur-sm text-foreground hover:bg-primary/20"
              )}
            >
              <BookmarkIcon className={cn("w-4 h-4", bookmarked && "fill-current")} />
            </button>

            {/* Progress Indicator */}
            {progress && !progress.isComplete && (
              <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-primary/90 text-primary-foreground text-xs font-medium flex items-center gap-1.5">
                <Play className="w-3 h-3" />
                In Progress
              </div>
            )}
            {progress?.isComplete && (
              <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-emerald-500/90 text-white text-xs font-medium flex items-center gap-1.5">
                <Check className="w-3 h-3" />
                Completed
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-5">
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <span className="px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-medium">
                {tour.theme}
              </span>
              <span className={cn("px-2.5 py-1 rounded-full text-xs font-medium", getDifficultyColor(tour.difficulty))}>
                {tour.difficulty}
              </span>
            </div>

            <h3 className="font-display text-xl font-semibold mb-2 text-foreground group-hover:text-primary transition-colors">
              {tour.title}
            </h3>
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {tour.subtitle}
            </p>

            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>{tour.duration}</span>
              </div>
              <span>{tour.rooms.length} rooms</span>
            </div>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}
