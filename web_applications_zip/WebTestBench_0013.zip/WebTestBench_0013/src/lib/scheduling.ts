import { UserProfile, TimeSlot, Participant } from '@/types/meeting';
import { addMinutes, setHours, setMinutes, isWithinInterval, getDay, format, addDays, isBefore, isAfter } from 'date-fns';

const DEFAULT_BUSINESS_HOURS = { start: '09:00', end: '17:00' };
const SLOT_INCREMENT = 30; // minutes

function parseTime(timeStr: string): { hours: number; minutes: number } {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return { hours, minutes };
}

function isInBreakTime(time: Date, breakTimes: { start: string; end: string }[]): boolean {
  const timeMinutes = time.getHours() * 60 + time.getMinutes();
  
  return breakTimes.some(breakTime => {
    const breakStart = parseTime(breakTime.start);
    const breakEnd = parseTime(breakTime.end);
    const breakStartMinutes = breakStart.hours * 60 + breakStart.minutes;
    const breakEndMinutes = breakEnd.hours * 60 + breakEnd.minutes;
    
    return timeMinutes >= breakStartMinutes && timeMinutes < breakEndMinutes;
  });
}

function isWithinWorkingHours(
  slotStart: Date,
  slotEnd: Date,
  workingHours: { start: string; end: string }
): boolean {
  const startTime = parseTime(workingHours.start);
  const endTime = parseTime(workingHours.end);
  
  const slotStartMinutes = slotStart.getHours() * 60 + slotStart.getMinutes();
  const slotEndMinutes = slotEnd.getHours() * 60 + slotEnd.getMinutes();
  const workStartMinutes = startTime.hours * 60 + startTime.minutes;
  const workEndMinutes = endTime.hours * 60 + endTime.minutes;
  
  return slotStartMinutes >= workStartMinutes && slotEndMinutes <= workEndMinutes;
}

export function generateTimeSlots(
  startDate: Date,
  endDate: Date,
  duration: number,
  profiles: UserProfile[],
  unknownParticipants: Participant[]
): TimeSlot[] {
  const slots: TimeSlot[] = [];
  let currentDate = new Date(startDate);
  currentDate.setHours(0, 0, 0, 0);
  
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);

  while (isBefore(currentDate, end) || currentDate.getTime() === end.getTime()) {
    const dayOfWeek = getDay(currentDate);
    
    // Check if any profile has this as a never-meet day
    const isBlockedDay = profiles.some(p => p.neverMeetDays.includes(dayOfWeek));
    
    if (!isBlockedDay) {
      // Find overlapping working hours across all profiles
      let earliestStart = 6 * 60; // 6:00 AM
      let latestEnd = 20 * 60; // 8:00 PM
      
      if (profiles.length > 0) {
        const workingRanges = profiles.map(p => ({
          start: parseTime(p.workingHours.start).hours * 60 + parseTime(p.workingHours.start).minutes,
          end: parseTime(p.workingHours.end).hours * 60 + parseTime(p.workingHours.end).minutes,
        }));
        
        earliestStart = Math.max(...workingRanges.map(r => r.start));
        latestEnd = Math.min(...workingRanges.map(r => r.end));
      }

      // Use business hours for unknown participants
      if (unknownParticipants.length > 0) {
        const businessStart = parseTime(DEFAULT_BUSINESS_HOURS.start);
        const businessEnd = parseTime(DEFAULT_BUSINESS_HOURS.end);
        earliestStart = Math.max(earliestStart, businessStart.hours * 60 + businessStart.minutes);
        latestEnd = Math.min(latestEnd, businessEnd.hours * 60 + businessEnd.minutes);
      }

      // Generate slots for this day
      let currentSlotStart = new Date(currentDate);
      currentSlotStart.setHours(Math.floor(earliestStart / 60), earliestStart % 60, 0, 0);
      
      while (true) {
        const slotEnd = addMinutes(currentSlotStart, duration);
        const slotEndMinutes = slotEnd.getHours() * 60 + slotEnd.getMinutes();
        
        if (slotEndMinutes > latestEnd) break;
        
        // Check for break time conflicts
        const conflicts: string[] = [];
        const partialOverlaps: string[] = [];
        
        profiles.forEach(profile => {
          const inBreak = isInBreakTime(currentSlotStart, profile.breakTimes) ||
                         isInBreakTime(addMinutes(currentSlotStart, duration - 1), profile.breakTimes);
          
          if (inBreak) {
            conflicts.push(profile.name);
          }
          
          const withinHours = isWithinWorkingHours(
            currentSlotStart,
            slotEnd,
            profile.workingHours
          );
          
          if (!withinHours && !conflicts.includes(profile.name)) {
            partialOverlaps.push(profile.name);
          }
        });

        const slot: TimeSlot = {
          id: `slot-${format(currentSlotStart, 'yyyyMMddHHmm')}`,
          start: new Date(currentSlotStart),
          end: slotEnd,
          score: 100 - (conflicts.length * 30) - (partialOverlaps.length * 15),
          conflicts,
          partialOverlaps,
          preferredBy: [],
          lastResortFor: [],
        };
        
        slots.push(slot);
        currentSlotStart = addMinutes(currentSlotStart, SLOT_INCREMENT);
      }
    }
    
    currentDate = addDays(currentDate, 1);
  }

  return slots;
}

export function rankTimeSlots(slots: TimeSlot[], participants: Participant[]): TimeSlot[] {
  return slots.map(slot => {
    let score = 100;
    const preferredBy: string[] = [];
    const lastResortFor: string[] = [];
    const conflicts: string[] = [...slot.conflicts];

    participants.forEach(participant => {
      const response = participant.responses.find(r => r.slotId === slot.id);
      
      if (response) {
        switch (response.preference) {
          case 'preferred':
            score += 20;
            preferredBy.push(participant.name);
            break;
          case 'available':
            // No score change
            break;
          case 'last-resort':
            score -= 15;
            lastResortFor.push(participant.name);
            break;
          case 'unavailable':
            score -= 40;
            if (!conflicts.includes(participant.name)) {
              conflicts.push(participant.name);
            }
            break;
        }
      }
    });

    // Ensure score stays within bounds
    score = Math.max(0, Math.min(100, score));

    return {
      ...slot,
      score,
      preferredBy,
      lastResortFor,
      conflicts,
    };
  }).sort((a, b) => b.score - a.score);
}

export function formatTimeSlot(slot: TimeSlot): string {
  return `${format(slot.start, 'EEE, MMM d')} • ${format(slot.start, 'h:mm a')} - ${format(slot.end, 'h:mm a')}`;
}
