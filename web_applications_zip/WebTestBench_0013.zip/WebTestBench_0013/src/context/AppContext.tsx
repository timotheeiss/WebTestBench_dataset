import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { UserProfile, Meeting, TimeSlot, Participant, ParticipantResponse } from '@/types/meeting';
import { mockProfiles, mockMeetings, currentUserId, getProfileByEmail } from '@/data/mockData';
import { generateTimeSlots, rankTimeSlots } from '@/lib/scheduling';

interface AppContextType {
  currentUser: UserProfile;
  profiles: UserProfile[];
  meetings: Meeting[];
  updateProfile: (profile: Partial<UserProfile>) => void;
  createMeeting: (meeting: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt' | 'suggestedSlots'>) => Meeting;
  updateMeeting: (meetingId: string, updates: Partial<Meeting>) => void;
  deleteMeeting: (meetingId: string) => void;
  addParticipant: (meetingId: string, name: string, email: string) => void;
  removeParticipant: (meetingId: string, participantId: string) => void;
  updateParticipantResponse: (meetingId: string, participantId: string, slotId: string, preference: ParticipantResponse['preference']) => void;
  confirmMeetingSlot: (meetingId: string, slotId: string) => void;
  reopenMeeting: (meetingId: string) => void;
  generateSlotsForMeeting: (meetingId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [profiles, setProfiles] = useState<UserProfile[]>(mockProfiles);
  const [meetings, setMeetings] = useState<Meeting[]>(mockMeetings);

  const currentUser = profiles.find(p => p.id === currentUserId)!;

  const updateProfile = useCallback((updates: Partial<UserProfile>) => {
    setProfiles(prev =>
      prev.map(p => (p.id === currentUserId ? { ...p, ...updates } : p))
    );
  }, []);

  const createMeeting = useCallback((meetingData: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt' | 'suggestedSlots'>) => {
    const newMeeting: Meeting = {
      ...meetingData,
      id: `meeting-${Date.now()}`,
      suggestedSlots: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Generate initial slots
    const participantProfiles = meetingData.participants
      .filter(p => p.isKnown && p.profileId)
      .map(p => profiles.find(prof => prof.id === p.profileId))
      .filter(Boolean) as UserProfile[];

    const allProfiles = [currentUser, ...participantProfiles];
    const slots = generateTimeSlots(
      meetingData.dateRange.start,
      meetingData.dateRange.end,
      meetingData.duration,
      allProfiles,
      meetingData.participants.filter(p => !p.isKnown)
    );

    newMeeting.suggestedSlots = rankTimeSlots(slots, meetingData.participants);

    setMeetings(prev => [...prev, newMeeting]);
    return newMeeting;
  }, [currentUser, profiles]);

  const updateMeeting = useCallback((meetingId: string, updates: Partial<Meeting>) => {
    setMeetings(prev =>
      prev.map(m =>
        m.id === meetingId ? { ...m, ...updates, updatedAt: new Date() } : m
      )
    );
  }, []);

  const deleteMeeting = useCallback((meetingId: string) => {
    setMeetings(prev => prev.filter(m => m.id !== meetingId));
  }, []);

  const addParticipant = useCallback((meetingId: string, name: string, email: string) => {
    const profile = getProfileByEmail(email);
    const newParticipant: Participant = {
      id: `part-${Date.now()}`,
      name,
      email,
      isKnown: !!profile,
      profileId: profile?.id,
      responses: [],
    };

    setMeetings(prev =>
      prev.map(m => {
        if (m.id !== meetingId) return m;
        return {
          ...m,
          participants: [...m.participants, newParticipant],
          updatedAt: new Date(),
        };
      })
    );
  }, []);

  const removeParticipant = useCallback((meetingId: string, participantId: string) => {
    setMeetings(prev =>
      prev.map(m => {
        if (m.id !== meetingId) return m;
        return {
          ...m,
          participants: m.participants.filter(p => p.id !== participantId),
          updatedAt: new Date(),
        };
      })
    );
  }, []);

  const updateParticipantResponse = useCallback(
    (meetingId: string, participantId: string, slotId: string, preference: ParticipantResponse['preference']) => {
      setMeetings(prev =>
        prev.map(m => {
          if (m.id !== meetingId) return m;
          const updatedParticipants = m.participants.map(p => {
            if (p.id !== participantId) return p;
            const existingResponseIndex = p.responses.findIndex(r => r.slotId === slotId);
            const newResponse: ParticipantResponse = { participantId, slotId, preference };
            
            if (existingResponseIndex >= 0) {
              const newResponses = [...p.responses];
              newResponses[existingResponseIndex] = newResponse;
              return { ...p, responses: newResponses };
            }
            return { ...p, responses: [...p.responses, newResponse] };
          });

          // Re-rank slots based on new responses
          const rankedSlots = rankTimeSlots(m.suggestedSlots, updatedParticipants);

          return {
            ...m,
            participants: updatedParticipants,
            suggestedSlots: rankedSlots,
            updatedAt: new Date(),
          };
        })
      );
    },
    []
  );

  const confirmMeetingSlot = useCallback((meetingId: string, slotId: string) => {
    setMeetings(prev =>
      prev.map(m => {
        if (m.id !== meetingId) return m;
        const confirmedSlot = m.suggestedSlots.find(s => s.id === slotId);
        return {
          ...m,
          confirmedSlot,
          status: 'confirmed',
          updatedAt: new Date(),
        };
      })
    );
  }, []);

  const reopenMeeting = useCallback((meetingId: string) => {
    setMeetings(prev =>
      prev.map(m => {
        if (m.id !== meetingId) return m;
        return {
          ...m,
          confirmedSlot: undefined,
          status: 'reopened',
          updatedAt: new Date(),
        };
      })
    );
  }, []);

  const generateSlotsForMeeting = useCallback((meetingId: string) => {
    setMeetings(prev =>
      prev.map(m => {
        if (m.id !== meetingId) return m;

        const participantProfiles = m.participants
          .filter(p => p.isKnown && p.profileId)
          .map(p => profiles.find(prof => prof.id === p.profileId))
          .filter(Boolean) as UserProfile[];

        const allProfiles = [currentUser, ...participantProfiles];
        const unknownParticipants = m.participants.filter(p => !p.isKnown);
        
        const slots = generateTimeSlots(
          m.dateRange.start,
          m.dateRange.end,
          m.duration,
          allProfiles,
          unknownParticipants
        );

        const rankedSlots = rankTimeSlots(slots, m.participants);

        return {
          ...m,
          suggestedSlots: rankedSlots,
          updatedAt: new Date(),
        };
      })
    );
  }, [currentUser, profiles]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        profiles,
        meetings,
        updateProfile,
        createMeeting,
        updateMeeting,
        deleteMeeting,
        addParticipant,
        removeParticipant,
        updateParticipantResponse,
        confirmMeetingSlot,
        reopenMeeting,
        generateSlotsForMeeting,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
