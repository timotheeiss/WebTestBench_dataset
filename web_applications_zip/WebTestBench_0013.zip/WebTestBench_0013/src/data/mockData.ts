import { UserProfile, Meeting, TimeSlot, Participant } from '@/types/meeting';

export const mockProfiles: UserProfile[] = [
  {
    id: 'user-1',
    name: 'Alex Morgan',
    email: 'alex.morgan@company.com',
    workingHours: { start: '09:00', end: '17:00' },
    breakTimes: [{ start: '12:00', end: '13:00' }],
    neverMeetDays: [0, 6], // Sunday, Saturday
    timezone: 'America/New_York',
  },
  {
    id: 'user-2',
    name: 'Jordan Chen',
    email: 'jordan.chen@company.com',
    workingHours: { start: '10:00', end: '18:00' },
    breakTimes: [{ start: '13:00', end: '14:00' }],
    neverMeetDays: [0, 6],
    timezone: 'America/Los_Angeles',
  },
  {
    id: 'user-3',
    name: 'Taylor Swift',
    email: 'taylor.s@external.com',
    workingHours: { start: '08:00', end: '16:00' },
    breakTimes: [{ start: '11:30', end: '12:30' }],
    neverMeetDays: [0, 5, 6], // Sunday, Friday, Saturday
    timezone: 'Europe/London',
  },
  {
    id: 'user-4',
    name: 'Sam Rivera',
    email: 'sam.rivera@company.com',
    workingHours: { start: '09:30', end: '17:30' },
    breakTimes: [{ start: '12:30', end: '13:30' }],
    neverMeetDays: [0, 6],
    timezone: 'America/Chicago',
  },
];

export const currentUserId = 'user-1';

export const getCurrentUser = (): UserProfile => {
  return mockProfiles.find(p => p.id === currentUserId)!;
};

export const getProfileByEmail = (email: string): UserProfile | undefined => {
  return mockProfiles.find(p => p.email.toLowerCase() === email.toLowerCase());
};

// Sample meetings
export const mockMeetings: Meeting[] = [
  {
    id: 'meeting-1',
    title: 'Q4 Planning Session',
    description: 'Discuss quarterly goals and resource allocation',
    duration: 60,
    organizerId: 'user-1',
    dateRange: {
      start: new Date('2024-12-16'),
      end: new Date('2024-12-20'),
    },
    participants: [
      {
        id: 'part-1',
        name: 'Jordan Chen',
        email: 'jordan.chen@company.com',
        isKnown: true,
        profileId: 'user-2',
        responses: [
          { participantId: 'part-1', slotId: 'slot-1', preference: 'preferred' },
          { participantId: 'part-1', slotId: 'slot-2', preference: 'available' },
          { participantId: 'part-1', slotId: 'slot-3', preference: 'last-resort' },
        ],
      },
      {
        id: 'part-2',
        name: 'Sam Rivera',
        email: 'sam.rivera@company.com',
        isKnown: true,
        profileId: 'user-4',
        responses: [
          { participantId: 'part-2', slotId: 'slot-1', preference: 'available' },
          { participantId: 'part-2', slotId: 'slot-2', preference: 'preferred' },
          { participantId: 'part-2', slotId: 'slot-3', preference: 'unavailable' },
        ],
      },
    ],
    suggestedSlots: [
      {
        id: 'slot-1',
        start: new Date('2024-12-17T10:00:00'),
        end: new Date('2024-12-17T11:00:00'),
        score: 85,
        conflicts: [],
        partialOverlaps: [],
        preferredBy: ['Jordan Chen'],
        lastResortFor: [],
      },
      {
        id: 'slot-2',
        start: new Date('2024-12-18T14:00:00'),
        end: new Date('2024-12-18T15:00:00'),
        score: 90,
        conflicts: [],
        partialOverlaps: [],
        preferredBy: ['Sam Rivera'],
        lastResortFor: [],
      },
      {
        id: 'slot-3',
        start: new Date('2024-12-19T09:00:00'),
        end: new Date('2024-12-19T10:00:00'),
        score: 60,
        conflicts: ['Sam Rivera'],
        partialOverlaps: [],
        preferredBy: [],
        lastResortFor: ['Jordan Chen'],
      },
    ],
    status: 'polling',
    createdAt: new Date('2024-12-10'),
    updatedAt: new Date('2024-12-11'),
  },
  {
    id: 'meeting-2',
    title: 'Design Review',
    description: 'Review new dashboard mockups',
    duration: 30,
    organizerId: 'user-1',
    dateRange: {
      start: new Date('2024-12-18'),
      end: new Date('2024-12-20'),
    },
    participants: [
      {
        id: 'part-3',
        name: 'External Client',
        email: 'client@external.com',
        isKnown: false,
        responses: [],
      },
    ],
    suggestedSlots: [
      {
        id: 'slot-4',
        start: new Date('2024-12-18T10:00:00'),
        end: new Date('2024-12-18T10:30:00'),
        score: 70,
        conflicts: [],
        partialOverlaps: [],
        preferredBy: [],
        lastResortFor: [],
      },
      {
        id: 'slot-5',
        start: new Date('2024-12-19T15:00:00'),
        end: new Date('2024-12-19T15:30:00'),
        score: 75,
        conflicts: [],
        partialOverlaps: [],
        preferredBy: [],
        lastResortFor: [],
      },
    ],
    status: 'draft',
    createdAt: new Date('2024-12-11'),
    updatedAt: new Date('2024-12-11'),
  },
];
