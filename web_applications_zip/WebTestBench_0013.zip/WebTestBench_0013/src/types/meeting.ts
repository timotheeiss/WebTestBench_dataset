export interface UserProfile {
  id: string;
  name: string;
  email: string;
  workingHours: {
    start: string; // "09:00"
    end: string; // "17:00"
  };
  breakTimes: {
    start: string;
    end: string;
  }[];
  neverMeetDays: number[]; // 0 = Sunday, 1 = Monday, etc.
  timezone: string;
}

export interface TimeSlot {
  id: string;
  start: Date;
  end: Date;
  score: number;
  conflicts: string[]; // participant names with conflicts
  partialOverlaps: string[]; // participant names with partial availability
  preferredBy: string[]; // participant names who prefer this slot
  lastResortFor: string[]; // participant names who marked as last resort
}

export interface ParticipantResponse {
  participantId: string;
  slotId: string;
  preference: 'available' | 'preferred' | 'last-resort' | 'unavailable';
}

export interface Participant {
  id: string;
  name: string;
  email: string;
  isKnown: boolean; // has a profile
  profileId?: string;
  responses: ParticipantResponse[];
}

export interface Meeting {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  organizerId: string;
  dateRange: {
    start: Date;
    end: Date;
  };
  participants: Participant[];
  suggestedSlots: TimeSlot[];
  confirmedSlot?: TimeSlot;
  status: 'draft' | 'polling' | 'confirmed' | 'reopened';
  createdAt: Date;
  updatedAt: Date;
}
