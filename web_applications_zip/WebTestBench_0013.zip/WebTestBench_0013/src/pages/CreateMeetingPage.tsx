import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, Calendar, Clock, Users, Check, X, UserPlus, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp } from '@/context/AppContext';
import { getProfileByEmail } from '@/data/mockData';
import { Participant, Meeting } from '@/types/meeting';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { addDays, format } from 'date-fns';
import { DateRange } from 'react-day-picker';

const steps = [
  { id: 1, title: 'Details', icon: Calendar },
  { id: 2, title: 'Participants', icon: Users },
  { id: 3, title: 'Review', icon: Check },
];

const durationOptions = [
  { value: 15, label: '15 minutes' },
  { value: 30, label: '30 minutes' },
  { value: 45, label: '45 minutes' },
  { value: 60, label: '1 hour' },
  { value: 90, label: '1.5 hours' },
  { value: 120, label: '2 hours' },
];

export default function CreateMeetingPage() {
  const navigate = useNavigate();
  const { createMeeting, currentUser } = useApp();
  const [step, setStep] = useState(1);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState(60);
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: addDays(new Date(), 1),
    to: addDays(new Date(), 7),
  });
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [newParticipantName, setNewParticipantName] = useState('');
  const [newParticipantEmail, setNewParticipantEmail] = useState('');

  const addParticipant = () => {
    if (!newParticipantName.trim() || !newParticipantEmail.trim()) {
      toast.error('Please enter both name and email');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newParticipantEmail)) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (participants.some(p => p.email.toLowerCase() === newParticipantEmail.toLowerCase())) {
      toast.error('This participant is already added');
      return;
    }

    const profile = getProfileByEmail(newParticipantEmail);
    const newParticipant: Participant = {
      id: `part-${Date.now()}`,
      name: newParticipantName,
      email: newParticipantEmail,
      isKnown: !!profile,
      profileId: profile?.id,
      responses: [],
    };

    setParticipants(prev => [...prev, newParticipant]);
    setNewParticipantName('');
    setNewParticipantEmail('');
    toast.success(profile ? 'Known participant added' : 'External participant added');
  };

  const removeParticipant = (id: string) => {
    setParticipants(prev => prev.filter(p => p.id !== id));
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return title.trim() && dateRange?.from && dateRange?.to;
      case 2:
        return true; // Participants are optional
      default:
        return true;
    }
  };

  const handleCreate = () => {
    if (!dateRange?.from || !dateRange?.to) return;

    const meeting = createMeeting({
      title,
      description,
      duration,
      organizerId: currentUser.id,
      dateRange: {
        start: dateRange.from,
        end: dateRange.to,
      },
      participants,
      status: participants.length > 0 ? 'polling' : 'draft',
    });

    toast.success('Meeting created successfully!');
    navigate(`/meeting/${meeting.id}`);
  };

  return (
    <div className="mx-auto max-w-3xl">
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((s, index) => {
            const StepIcon = s.icon;
            const isActive = step === s.id;
            const isCompleted = step > s.id;

            return (
              <div key={s.id} className="flex items-center">
                <div className="flex items-center gap-2">
                  <div
                    className={cn(
                      'flex h-10 w-10 items-center justify-center rounded-full transition-all',
                      isActive && 'bg-gradient-primary text-primary-foreground shadow-glow',
                      isCompleted && 'bg-success text-success-foreground',
                      !isActive && !isCompleted && 'bg-muted text-muted-foreground'
                    )}
                  >
                    {isCompleted ? (
                      <Check className="h-5 w-5" />
                    ) : (
                      <StepIcon className="h-5 w-5" />
                    )}
                  </div>
                  <span
                    className={cn(
                      'hidden text-sm font-medium sm:block',
                      isActive && 'text-primary',
                      isCompleted && 'text-success',
                      !isActive && !isCompleted && 'text-muted-foreground'
                    )}
                  >
                    {s.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={cn(
                      'mx-4 h-0.5 w-12 sm:w-24',
                      isCompleted ? 'bg-success' : 'bg-muted'
                    )}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* Step 1: Meeting Details */}
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Meeting Details</CardTitle>
                <CardDescription>
                  Set the basic information for your meeting
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Meeting Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Weekly Team Sync"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="What's this meeting about?"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Duration</Label>
                  <Select
                    value={duration.toString()}
                    onValueChange={v => setDuration(Number(v))}
                  >
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {durationOptions.map(opt => (
                        <SelectItem key={opt.value} value={opt.value.toString()}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Date Range *</Label>
                  <div className="rounded-lg border border-border p-4">
                    <CalendarComponent
                      mode="range"
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                      disabled={{ before: new Date() }}
                      className="mx-auto"
                    />
                  </div>
                  {dateRange?.from && dateRange?.to && (
                    <p className="text-sm text-muted-foreground">
                      {format(dateRange.from, 'MMM d, yyyy')} - {format(dateRange.to, 'MMM d, yyyy')}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 2: Participants */}
        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Add Participants</CardTitle>
                <CardDescription>
                  Invite people to your meeting. Known users will have their availability considered.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border border-border bg-muted/30 p-4">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="pname">Name</Label>
                      <Input
                        id="pname"
                        placeholder="John Doe"
                        value={newParticipantName}
                        onChange={e => setNewParticipantName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pemail">Email</Label>
                      <Input
                        id="pemail"
                        type="email"
                        placeholder="john@example.com"
                        value={newParticipantEmail}
                        onChange={e => setNewParticipantEmail(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && addParticipant()}
                      />
                    </div>
                  </div>
                  <Button onClick={addParticipant} className="mt-3 gap-2">
                    <UserPlus className="h-4 w-4" />
                    Add Participant
                  </Button>
                </div>

                {participants.length > 0 ? (
                  <div className="space-y-2">
                    <Label>Invited Participants</Label>
                    <div className="space-y-2">
                      {participants.map(p => (
                        <div
                          key={p.id}
                          className="flex items-center justify-between rounded-lg border border-border bg-card p-3"
                        >
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              'flex h-10 w-10 items-center justify-center rounded-full text-sm font-medium',
                              p.isKnown ? 'bg-success-light text-success' : 'bg-muted text-muted-foreground'
                            )}>
                              {p.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium text-foreground">{p.name}</p>
                              <p className="text-sm text-muted-foreground">{p.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={p.isKnown ? 'default' : 'secondary'}>
                              {p.isKnown ? 'Known' : 'External'}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeParticipant(p.id)}
                              className="text-muted-foreground hover:text-destructive"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border py-12 text-center">
                    <Users className="mb-3 h-10 w-10 text-muted-foreground" />
                    <p className="text-muted-foreground">No participants added yet</p>
                    <p className="text-sm text-muted-foreground">
                      You can skip this step and add participants later
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 3: Review */}
        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Review & Create</CardTitle>
                <CardDescription>
                  Review your meeting details before creating
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg bg-muted/30 p-4 space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Title</p>
                    <p className="font-medium text-foreground">{title}</p>
                  </div>
                  
                  {description && (
                    <div>
                      <p className="text-sm text-muted-foreground">Description</p>
                      <p className="text-foreground">{description}</p>
                    </div>
                  )}

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-foreground">
                        {durationOptions.find(d => d.value === duration)?.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-foreground">
                        {dateRange?.from && dateRange?.to && (
                          <>
                            {format(dateRange.from, 'MMM d')} - {format(dateRange.to, 'MMM d, yyyy')}
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Participants ({participants.length})
                    </p>
                    {participants.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {participants.map(p => (
                          <Badge
                            key={p.id}
                            variant={p.isKnown ? 'default' : 'secondary'}
                            className="gap-1"
                          >
                            <Mail className="h-3 w-3" />
                            {p.name}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground">No participants added</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <div className="mt-6 flex items-center justify-between">
        <Button
          variant="outline"
          onClick={() => (step === 1 ? navigate('/') : setStep(s => s - 1))}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          {step === 1 ? 'Cancel' : 'Back'}
        </Button>

        {step < 3 ? (
          <Button
            onClick={() => setStep(s => s + 1)}
            disabled={!canProceed()}
            className="gap-2"
          >
            Next
            <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={handleCreate} className="gap-2 shadow-glow">
            <Check className="h-4 w-4" />
            Create Meeting
          </Button>
        )}
      </div>
    </div>
  );
}
