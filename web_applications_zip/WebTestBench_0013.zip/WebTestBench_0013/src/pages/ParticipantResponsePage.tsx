import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Star, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/context/AppContext';
import { formatTimeSlot } from '@/lib/scheduling';
import { ParticipantResponse } from '@/types/meeting';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const preferenceOptions: { value: ParticipantResponse['preference']; label: string; icon: React.ComponentType<{ className?: string }>; className: string }[] = [
  { value: 'preferred', label: 'Preferred', icon: Star, className: 'bg-success-light text-success border-success' },
  { value: 'available', label: 'Available', icon: Check, className: 'bg-primary-light text-primary border-primary' },
  { value: 'last-resort', label: 'Last Resort', icon: AlertTriangle, className: 'bg-warning-light text-warning-foreground border-warning' },
  { value: 'unavailable', label: 'Unavailable', icon: Clock, className: 'bg-destructive/10 text-destructive border-destructive' },
];

export default function ParticipantResponsePage() {
  const { meetingId, participantId } = useParams<{ meetingId: string; participantId: string }>();
  const navigate = useNavigate();
  const { meetings, updateParticipantResponse } = useApp();

  const meeting = meetings.find(m => m.id === meetingId);
  const participant = meeting?.participants.find(p => p.id === participantId);

  const [responses, setResponses] = useState<Record<string, ParticipantResponse['preference']>>(() => {
    const initial: Record<string, ParticipantResponse['preference']> = {};
    participant?.responses.forEach(r => {
      initial[r.slotId] = r.preference;
    });
    return initial;
  });

  if (!meeting || !participant) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h1 className="text-2xl font-bold text-foreground">Meeting or participant not found</h1>
        <Link to="/" className="mt-4 text-primary hover:underline">
          Return to Dashboard
        </Link>
      </div>
    );
  }

  const handlePreferenceChange = (slotId: string, preference: ParticipantResponse['preference']) => {
    setResponses(prev => ({ ...prev, [slotId]: preference }));
  };

  const handleSubmit = () => {
    Object.entries(responses).forEach(([slotId, preference]) => {
      updateParticipantResponse(meeting.id, participant.id, slotId, preference);
    });
    toast.success('Your availability has been saved!');
    navigate(`/meeting/${meeting.id}`);
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(`/meeting/${meeting.id}`)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
            Respond to: {meeting.title}
          </h1>
          <p className="mt-1 text-muted-foreground">
            Hello {participant.name}, please mark your availability for each time slot.
          </p>
        </div>
      </div>

      {/* Meeting Info */}
      <Card className="border-0 shadow-md">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              {meeting.duration} minutes
            </div>
            <div className="text-muted-foreground">
              {format(meeting.dateRange.start, 'MMM d')} - {format(meeting.dateRange.end, 'MMM d, yyyy')}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Legend */}
      <div className="flex flex-wrap gap-2">
        {preferenceOptions.map(opt => {
          const Icon = opt.icon;
          return (
            <Badge key={opt.value} variant="outline" className={cn('gap-1', opt.className)}>
              <Icon className="h-3 w-3" />
              {opt.label}
            </Badge>
          );
        })}
      </div>

      {/* Time Slots */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Select Your Availability</CardTitle>
          <CardDescription>
            Click on each time slot to indicate your preference
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {meeting.suggestedSlots.map((slot, index) => {
              const currentPreference = responses[slot.id] || 'available';
              const currentOption = preferenceOptions.find(o => o.value === currentPreference);

              return (
                <motion.div
                  key={slot.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="rounded-lg border border-border p-4"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="font-medium text-foreground">
                        {formatTimeSlot(slot)}
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {preferenceOptions.map(opt => {
                        const Icon = opt.icon;
                        const isSelected = currentPreference === opt.value;

                        return (
                          <Button
                            key={opt.value}
                            variant="outline"
                            size="sm"
                            onClick={() => handlePreferenceChange(slot.id, opt.value)}
                            className={cn(
                              'gap-1 transition-all',
                              isSelected && opt.className,
                              isSelected && 'ring-2 ring-offset-2'
                            )}
                          >
                            <Icon className="h-3 w-3" />
                            <span className="hidden sm:inline">{opt.label}</span>
                          </Button>
                        );
                      })}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Submit */}
      <div className="flex justify-end">
        <Button size="lg" onClick={handleSubmit} className="gap-2 shadow-glow">
          <Check className="h-5 w-5" />
          Save My Availability
        </Button>
      </div>
    </div>
  );
}
