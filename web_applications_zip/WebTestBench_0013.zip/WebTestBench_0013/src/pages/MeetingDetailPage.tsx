import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Calendar,
  Clock,
  Users,
  CheckCircle2,
  AlertTriangle,
  Star,
  AlertCircle,
  UserPlus,
  X,
  RotateCcw,
  Trash2,
  Mail,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useApp } from '@/context/AppContext';
import { formatTimeSlot } from '@/lib/scheduling';
import { TimeSlot } from '@/types/meeting';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const statusConfig = {
  draft: { label: 'Draft', className: 'bg-muted text-muted-foreground' },
  polling: { label: 'Polling Participants', className: 'bg-warning-light text-warning-foreground' },
  confirmed: { label: 'Confirmed', className: 'bg-success-light text-success' },
  reopened: { label: 'Reopened', className: 'bg-accent-light text-accent' },
};

export default function MeetingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    meetings,
    addParticipant,
    removeParticipant,
    confirmMeetingSlot,
    reopenMeeting,
    deleteMeeting,
    generateSlotsForMeeting,
  } = useApp();

  const meeting = meetings.find(m => m.id === id);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [addDialogOpen, setAddDialogOpen] = useState(false);

  if (!meeting) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h1 className="text-2xl font-bold text-foreground">Meeting not found</h1>
        <Link to="/" className="mt-4 text-primary hover:underline">
          Return to Dashboard
        </Link>
      </div>
    );
  }

  const status = statusConfig[meeting.status];

  const handleAddParticipant = () => {
    if (!newName.trim() || !newEmail.trim()) {
      toast.error('Please enter both name and email');
      return;
    }
    addParticipant(meeting.id, newName, newEmail);
    generateSlotsForMeeting(meeting.id);
    setNewName('');
    setNewEmail('');
    setAddDialogOpen(false);
    toast.success('Participant added');
  };

  const handleConfirmSlot = (slot: TimeSlot) => {
    confirmMeetingSlot(meeting.id, slot.id);
    toast.success('Meeting time confirmed!');
  };

  const handleReopen = () => {
    reopenMeeting(meeting.id);
    toast.info('Meeting reopened for rescheduling');
  };

  const handleDelete = () => {
    deleteMeeting(meeting.id);
    navigate('/');
    toast.success('Meeting deleted');
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-warning';
    return 'text-destructive';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-success-light';
    if (score >= 60) return 'bg-warning-light';
    return 'bg-destructive/10';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
                {meeting.title}
              </h1>
              <Badge className={status.className}>{status.label}</Badge>
            </div>
            {meeting.description && (
              <p className="mt-1 text-muted-foreground">{meeting.description}</p>
            )}
          </div>
        </div>

        <div className="flex gap-2">
          {meeting.status === 'confirmed' && (
            <Button variant="outline" onClick={handleReopen} className="gap-2">
              <RotateCcw className="h-4 w-4" />
              Reopen
            </Button>
          )}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="text-destructive hover:text-destructive">
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Meeting</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this meeting? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Meeting Info */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-0 shadow-md">
          <CardContent className="flex items-center gap-3 p-4">
            <Clock className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Duration</p>
              <p className="font-medium text-foreground">{meeting.duration} minutes</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="flex items-center gap-3 p-4">
            <Calendar className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Date Range</p>
              <p className="font-medium text-foreground">
                {format(meeting.dateRange.start, 'MMM d')} - {format(meeting.dateRange.end, 'MMM d')}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="flex items-center gap-3 p-4">
            <Users className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Participants</p>
              <p className="font-medium text-foreground">{meeting.participants.length} invited</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmed Time */}
      {meeting.confirmedSlot && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <Card className="border-2 border-success bg-success-light/30">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success text-success-foreground">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div>
                <p className="font-semibold text-success">Confirmed Time</p>
                <p className="text-lg font-medium text-foreground">
                  {formatTimeSlot(meeting.confirmedSlot)}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Participants */}
        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Participants</CardTitle>
              <CardDescription>People invited to this meeting</CardDescription>
            </div>
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-2">
                  <UserPlus className="h-4 w-4" />
                  Add
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Participant</DialogTitle>
                  <DialogDescription>
                    Add a new participant to this meeting
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={newName}
                      onChange={e => setNewName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@example.com"
                      value={newEmail}
                      onChange={e => setNewEmail(e.target.value)}
                    />
                  </div>
                  <Button onClick={handleAddParticipant} className="w-full">
                    Add Participant
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {meeting.participants.length === 0 ? (
              <div className="flex flex-col items-center py-8 text-center">
                <Users className="mb-3 h-10 w-10 text-muted-foreground" />
                <p className="text-muted-foreground">No participants yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {meeting.participants.map(p => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between rounded-lg border border-border p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          'flex h-9 w-9 items-center justify-center rounded-full text-sm font-medium',
                          p.isKnown ? 'bg-success-light text-success' : 'bg-muted text-muted-foreground'
                        )}
                      >
                        {p.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={p.isKnown ? 'default' : 'secondary'} className="text-xs">
                        {p.isKnown ? 'Known' : 'External'}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          removeParticipant(meeting.id, p.id);
                          generateSlotsForMeeting(meeting.id);
                        }}
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Time Slots */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Suggested Times</CardTitle>
            <CardDescription>
              Ranked by availability scores
            </CardDescription>
          </CardHeader>
          <CardContent>
            {meeting.suggestedSlots.length === 0 ? (
              <div className="flex flex-col items-center py-8 text-center">
                <Clock className="mb-3 h-10 w-10 text-muted-foreground" />
                <p className="text-muted-foreground">No time slots available</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                {meeting.suggestedSlots.slice(0, 10).map((slot, index) => {
                  const isConfirmed = meeting.confirmedSlot?.id === slot.id;
                  const hasTie = index > 0 && meeting.suggestedSlots[index - 1].score === slot.score;

                  return (
                    <motion.div
                      key={slot.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className={cn(
                        'rounded-lg border p-3 transition-all',
                        isConfirmed
                          ? 'border-success bg-success-light/30'
                          : 'border-border hover:border-primary/30 hover:shadow-sm'
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-foreground">
                              {formatTimeSlot(slot)}
                            </p>
                            {hasTie && (
                              <Badge variant="outline" className="text-xs">
                                Tied
                              </Badge>
                            )}
                          </div>

                          {/* Indicators */}
                          <div className="mt-2 flex flex-wrap gap-1">
                            {slot.preferredBy.length > 0 && (
                              <Badge variant="secondary" className="gap-1 bg-success-light text-success text-xs">
                                <Star className="h-3 w-3" />
                                {slot.preferredBy.length} preferred
                              </Badge>
                            )}
                            {slot.lastResortFor.length > 0 && (
                              <Badge variant="secondary" className="gap-1 bg-warning-light text-warning-foreground text-xs">
                                <AlertTriangle className="h-3 w-3" />
                                {slot.lastResortFor.length} last resort
                              </Badge>
                            )}
                            {slot.conflicts.length > 0 && (
                              <Badge variant="secondary" className="gap-1 bg-destructive/10 text-destructive text-xs">
                                <AlertCircle className="h-3 w-3" />
                                {slot.conflicts.length} conflict{slot.conflicts.length > 1 ? 's' : ''}
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <div
                            className={cn(
                              'flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold',
                              getScoreBg(slot.score),
                              getScoreColor(slot.score)
                            )}
                          >
                            {slot.score}
                          </div>
                          {meeting.status !== 'confirmed' && (
                            <Button
                              size="sm"
                              onClick={() => handleConfirmSlot(slot)}
                              className="gap-1"
                            >
                              <CheckCircle2 className="h-4 w-4" />
                              Confirm
                            </Button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
