import { Link } from 'react-router-dom';
import { Plus, Calendar, Users, Clock, CheckCircle2, AlertCircle, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/context/AppContext';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const statusConfig = {
  draft: { label: 'Draft', icon: Clock, className: 'bg-muted text-muted-foreground' },
  polling: { label: 'Polling', icon: Users, className: 'bg-warning-light text-warning-foreground' },
  confirmed: { label: 'Confirmed', icon: CheckCircle2, className: 'bg-success-light text-success' },
  reopened: { label: 'Reopened', icon: RotateCcw, className: 'bg-accent-light text-accent' },
};

export default function Dashboard() {
  const { meetings, currentUser } = useApp();

  const myMeetings = meetings.filter(m => m.organizerId === currentUser.id);
  const upcomingConfirmed = myMeetings.filter(m => m.status === 'confirmed');
  const needsAttention = myMeetings.filter(m => m.status === 'polling' || m.status === 'reopened');

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Welcome back, {currentUser.name.split(' ')[0]}
          </h1>
          <p className="mt-1 text-muted-foreground">
            Manage your meetings and availability
          </p>
        </div>
        <Link to="/meeting/new">
          <Button size="lg" className="gap-2 shadow-glow">
            <Plus className="h-5 w-5" />
            Schedule Meeting
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-0 shadow-md animate-fade-in">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-light">
              <Calendar className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{myMeetings.length}</p>
              <p className="text-sm text-muted-foreground">Total Meetings</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success-light">
              <CheckCircle2 className="h-6 w-6 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{upcomingConfirmed.length}</p>
              <p className="text-sm text-muted-foreground">Confirmed</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-warning-light">
              <AlertCircle className="h-6 w-6 text-warning" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{needsAttention.length}</p>
              <p className="text-sm text-muted-foreground">Needs Attention</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Meeting List */}
      <div className="animate-slide-up">
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Your Meetings</CardTitle>
            <CardDescription>
              Meetings you've organized
            </CardDescription>
          </CardHeader>
          <CardContent>
            {myMeetings.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <Calendar className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="mb-2 text-lg font-medium text-foreground">No meetings yet</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  Create your first meeting to get started
                </p>
                <Link to="/meeting/new">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Meeting
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {myMeetings.map((meeting, index) => {
                  const status = statusConfig[meeting.status];
                  const StatusIcon = status.icon;

                  return (
                    <div key={meeting.id} className="animate-fade-in">
                      <Link to={`/meeting/${meeting.id}`}>
                        <div className="group flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-md">
                          <div className="flex items-center gap-4">
                            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-primary">
                              <Calendar className="h-5 w-5 text-primary-foreground" />
                            </div>
                            <div>
                              <h3 className="font-medium text-foreground group-hover:text-primary">
                                {meeting.title}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {format(meeting.dateRange.start, 'MMM d')} - {format(meeting.dateRange.end, 'MMM d, yyyy')}
                                {' • '}
                                {meeting.duration} min
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <div className="hidden items-center gap-1 text-sm text-muted-foreground sm:flex">
                              <Users className="h-4 w-4" />
                              {meeting.participants.length}
                            </div>
                            <Badge className={cn('gap-1', status.className)}>
                              <StatusIcon className="h-3 w-3" />
                              {status.label}
                            </Badge>
                          </div>
                        </div>
                      </Link>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
