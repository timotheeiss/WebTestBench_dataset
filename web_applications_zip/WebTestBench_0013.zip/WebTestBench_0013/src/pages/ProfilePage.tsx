import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Clock, Coffee, CalendarX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useApp } from '@/context/AppContext';
import { toast } from 'sonner';

const daysOfWeek = [
  { value: 0, label: 'Sunday' },
  { value: 1, label: 'Monday' },
  { value: 2, label: 'Tuesday' },
  { value: 3, label: 'Wednesday' },
  { value: 4, label: 'Thursday' },
  { value: 5, label: 'Friday' },
  { value: 6, label: 'Saturday' },
];

export default function ProfilePage() {
  const { currentUser, updateProfile } = useApp();
  const [workingHours, setWorkingHours] = useState(currentUser.workingHours);
  const [breakTimes, setBreakTimes] = useState(currentUser.breakTimes);
  const [neverMeetDays, setNeverMeetDays] = useState<number[]>(currentUser.neverMeetDays);

  const handleSave = () => {
    updateProfile({
      workingHours,
      breakTimes,
      neverMeetDays,
    });
    toast.success('Profile updated successfully');
  };

  const toggleNeverMeetDay = (day: number) => {
    setNeverMeetDays(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const addBreakTime = () => {
    setBreakTimes(prev => [...prev, { start: '12:00', end: '13:00' }]);
  };

  const removeBreakTime = (index: number) => {
    setBreakTimes(prev => prev.filter((_, i) => i !== index));
  };

  const updateBreakTime = (index: number, field: 'start' | 'end', value: string) => {
    setBreakTimes(prev =>
      prev.map((bt, i) => (i === index ? { ...bt, [field]: value } : bt))
    );
  };

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold text-foreground">My Availability</h1>
        <p className="mt-1 text-muted-foreground">
          Set your default availability preferences for scheduling meetings
        </p>
      </motion.div>

      {/* Working Hours */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-light">
                <Clock className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Working Hours</CardTitle>
                <CardDescription>Your typical available hours</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="start-time">Start Time</Label>
                <Input
                  id="start-time"
                  type="time"
                  value={workingHours.start}
                  onChange={e => setWorkingHours(prev => ({ ...prev, start: e.target.value }))}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-time">End Time</Label>
                <Input
                  id="end-time"
                  type="time"
                  value={workingHours.end}
                  onChange={e => setWorkingHours(prev => ({ ...prev, end: e.target.value }))}
                  className="h-11"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Break Times */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent-light">
                  <Coffee className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <CardTitle>Break Times</CardTitle>
                  <CardDescription>Times when you're not available</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={addBreakTime}>
                Add Break
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {breakTimes.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">
                No break times configured
              </p>
            ) : (
              <div className="space-y-3">
                {breakTimes.map((breakTime, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Input
                      type="time"
                      value={breakTime.start}
                      onChange={e => updateBreakTime(index, 'start', e.target.value)}
                      className="h-10"
                    />
                    <span className="text-muted-foreground">to</span>
                    <Input
                      type="time"
                      value={breakTime.end}
                      onChange={e => updateBreakTime(index, 'end', e.target.value)}
                      className="h-10"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBreakTime(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Never Meet Days */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                <CalendarX className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <CardTitle>Days Off</CardTitle>
                <CardDescription>Days when you never schedule meetings</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {daysOfWeek.map(day => (
                <div
                  key={day.value}
                  className="flex items-center space-x-2 rounded-lg border border-border p-3 transition-colors hover:bg-muted/50"
                >
                  <Checkbox
                    id={`day-${day.value}`}
                    checked={neverMeetDays.includes(day.value)}
                    onCheckedChange={() => toggleNeverMeetDay(day.value)}
                  />
                  <Label
                    htmlFor={`day-${day.value}`}
                    className="cursor-pointer text-sm font-medium"
                  >
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Save Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="flex justify-end"
      >
        <Button size="lg" onClick={handleSave} className="gap-2 shadow-glow">
          <Save className="h-5 w-5" />
          Save Changes
        </Button>
      </motion.div>
    </div>
  );
}
